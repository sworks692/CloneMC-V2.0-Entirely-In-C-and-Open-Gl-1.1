# CloneMC V150.1.4.0 Implementation Report

## Scope

V150.1.4.0 is a focused renderer/performance and visual-parity revision built on the V150.1.3 tree. The work was constrained to changes that materially improve Java fidelity, renderer efficiency, debugging clarity, or developer maintainability espeically. 

The wrriten codebase mainly concentrated on `ClippingHelper`, `ClippingHelperImpl`, `Frustrum`, `WorldRenderer`, `RenderGlobal`, `RenderBlocks`, `BlockLeaves`, `BlockLeavesBase`, and `EntityRenderer`.

## 1. Hierarchical frustum culling

### Java behavior retained

Java's clipping helper rejects an axis-aligned box only when all eight box corners are outside at least one of the six frustum planes. The native classifier preserves that exact visible set.

### V150.1.4 extension

`CloneMCClippingHelper_ClassifyBoxMask()` and `CloneMCFrustrum_ClassifyBoxMask()` add hierarchy without changing the mathematical reject rule. The caller supplies a six-bit active-plane mask. For each active plane:

1. the support corner farthest along the plane normal is evaluated; if that maximum signed distance is <= 0, the box is outside and is rejected exactly;
2. the opposite/minimum support corner is evaluated only to determine containment;
3. when the minimum support corner is > 0, the complete parent is inside that plane and the plane bit is removed from the child mask;
4. intersecting planes remain active for children.

This means child sections only test planes that could still reject them.

### Chunk-column hierarchy

`RenderGlobal.c` now builds a `candidateSections` bit mask before doing fine culling. Candidate status includes current geometry plus sections that are dirty/urgent/building so visibility cannot accidentally starve a required rebuild.

The coarse column test then:

- ignores built sections known to be all-air;
- computes the lowest/highest candidate section and uses that tighter vertical AABB;
- rejects all children if the parent is outside;
- accepts all candidates immediately if the parent is fully inside all active planes;
- otherwise classifies each child using only the parent's remaining plane mask.

The existing near-camera safety path and frustum-reject hysteresis are retained.

### Diagnostics

New counters record:

- actual frustum plane evaluations;
- plane evaluations skipped by hierarchy;
- coarse parents completely contained by the frustum;
- empty-section child tests avoided.

These are displayed on the advanced F3 line.

## 2. Surface-compaction meshing

### Problem

V150 already had an excellent fast path for a completely solid four-layer build slice, but mixed slices—caves, tunnels, ores, internal terrain boundaries—still sent every non-air full cube into `RenderBlocks`, even when all six faces were guaranteed to be hidden.

### Implemented path

`WorldRenderer.c` now performs a conservative six-neighbor rejection before querying metadata/light/AO/UV state. A block is skipped only when:

- the source block is a standard full opaque cube; and
- all six adjacent cells are also standard full opaque cubes.

Because Java `RenderBlocks` would emit zero faces for such a cube, this is lossless surface compaction rather than an approximation.

### Cache behavior

A small per-build `CloneMCWorldRendererOcclusionCache` stores:

- the center renderer/chunk;
- west/east/north/south neighboring chunk pointers;
- a 256-entry `standardOpaque` material table.

Chunk boundaries therefore use direct array reads rather than repeated provider/world lookups. An unloaded neighbor is intentionally treated as air so the optimization is conservative and can never hide an exposed boundary face. Below Y=0 is treated as the existing opaque world boundary; Y>=128 is air.

### Why no generic greedy mesher

A generic greedy rectangle merge was intentionally not introduced. CloneMC's target renderer uses a texture atlas, texture repetition semantics, per-face light, and ambient-occlusion values under fixed-function OpenGL 1.1. Merging arbitrary differently lit/UV-repeated faces would either change visible output or require shader-era texture sampling/extra vertex formats. The chosen path removes invisible CPU work without changing Java-shaped UV/light results.

## 3. Fast leaves

The supplied Java trees switch leaves between two real behaviors through `setGraphicsLevel()`:

- fancy: non-opaque/cutout leaves, internal neighboring-leaf faces may render;
- fast: leaves become opaque and faces directly adjoining the same leaf block are suppressed.

CloneMC previously changed the leaf texture but kept leaves permanently cutout/non-occluding, causing dense internal canopy geometry and the wrong fast-mode appearance.

V150.1.4 makes render-pass, standard-opaque, and face-occlusion decisions depend on the current fancy-graphics flag. Changing the setting already marks the world renderers dirty, so the correct geometry is rebuilt.

## 4. Glass and translucent blocks

Both supplied Java `BlockGlass` implementations render in pass 0. Native V150.1.3 instead grouped glass with water/ice/portal in the sorted blended pass and applied translucent vertex alpha. That produced faded glass and unnecessary blend sorting.

V150.1.4 moves glass to CloneMC's alpha-tested/cutout non-blended bucket. Same-glass internal-face suppression remains intact.

Water, ice, and portal remain translucent-pass blocks.

## 5. Vertex-alpha parity

Java `RenderBlocks`, including fluid rendering, supplies opaque vertex color and relies on texture alpha and blending for translucency. CloneMC was multiplying the atlas alpha again with a hard-coded 190/255 vertex alpha in several paths.

V150.1.4 removes that multiplier. Water/ice/portal now preserve their texture-provided alpha instead of being artificially washed out.

## 6. More Diagnostics Added

The advanced F3 display now reports enough data to tell whether renderer work is disappearing for the intended reasons rather than merely reporting a final FPS number. Counters include:

- plane tests and estimated tests saved;
- parent AABBs wholly inside the frustum;
- all-air sections skipped;
- fully enclosed opaque blocks rejected before tessellation;
- old solid-slice culls;
- display-list/batch activity.

The deterministic benchmark and focused verifier are also shipped under `tools/` so future renderer edits can be regression-checked without requiring a GPU benchmark for every source change.

The focused verifier explicitly rejects shader/VBO-era entry points including `glGenBuffers`, `glBindBuffer`, `glBufferData`, `glUseProgram`, `glCreateShader`, and ARB occlusion-query dependencies.

