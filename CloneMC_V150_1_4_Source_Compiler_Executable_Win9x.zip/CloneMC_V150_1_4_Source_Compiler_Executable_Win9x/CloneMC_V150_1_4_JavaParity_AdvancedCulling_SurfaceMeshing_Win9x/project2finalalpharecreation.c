/*
 * CloneMC V150.0 dual-stage Java-shaped chunk-streaming source release with
 * verified OpenGL 1.1 display-list transactions.
 *
 * This cumulative Open Watcom C89/OpenGL 1.1 unity build retains V137/V138
 * rendering and progression work, the licensed post-Beta terrain atlas and
 * registries, Java third-person equipment and mob passes, chunk residency,
 * section-atomic meshes, coarse culling, and bounded driver compilation.
 */
/* Winsock 2 must precede windows.h.  WIN32_LEAN_AND_MEAN prevents windows.h
 * from pulling in the incompatible Winsock 1.1 declarations first. */
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include "clonemc_version.h"

#include "src/00_core/clonemc_java_port_00_core_unity.inc"
#include "src/10_save/clonemc_java_port_10_save_unity.inc"
#include "src/20_entity/clonemc_java_port_20_entity_unity.inc"
#include "src/30_item/clonemc_java_port_30_item_unity.inc"
#include "src/40_world/clonemc_java_port_40_world_unity.inc"
#include "src/50_lighting/clonemc_java_port_50_lighting_unity.inc"
#include "src/60_ui/clonemc_java_port_60_ui_unity.inc"
#include "src/70_render/clonemc_java_port_70_render_unity.inc"
#include "src/NETWORK/clonemc_java_port_network_unity.inc"
#include "src/00_core/clonemc_java_port_registry.inc"

int WINAPI WinMain(HINSTANCE instance, HINSTANCE previousInstance, LPSTR commandLine, int showCommand)
{
    char bootstrapDirectory[MAX_PATH];
    DWORD bootstrapLength;
    (void)previousInstance;
    CloneMCPlatform_UseDataRoot();
    CloneMCPlatform_InstallCrashHandlers();
    remove(CLONEMC_LOG_FILE);
    remove("clonemc_crash.log");
    bootstrapLength=GetCurrentDirectoryA(MAX_PATH,bootstrapDirectory);
    if(bootstrapLength>0&&bootstrapLength<MAX_PATH){
        char line[MAX_PATH+64];
        sprintf(line,"BOOTSTRAP 00: data root is %s",bootstrapDirectory);
        CloneMCPlatform_Log(line);
    }
    {
        char line[192];
        sprintf(line,"%s: WinMain reached; registering %lu Java-mapped native modules",
            CLONEMC_VERSION_DISPLAY,g_cloneMCJavaPortModuleCount);
        CloneMCPlatform_Log(line);
    }
    CloneMCJavaPort_RegisterAll();
    CloneMCPlatform_Log("BOOTSTRAP 00: native module registration complete");
    return CloneMCMinecraftImpl_Run((void *)instance, commandLine, showCommand);
}
