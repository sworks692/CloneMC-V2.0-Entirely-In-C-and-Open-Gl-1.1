/*
 * CloneMC Java port scaffold: MetadataChunkBlock
 *
 * Java source: MetadataChunkBlock.java
 * Java type: class MetadataChunkBlock
 * Package: net.minecraft.src
 * Assigned subsystem: src/50_lighting
 * Mapping reason: skylight, blocklight, or packed-nibble lighting class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 9747f05ee73e5a4795fc930253e80bfbeb2f3847d75b7489af28731558ce15d6
 * Java lines: 238
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: World, Chunk, Block, EnumSkyBlock, l1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final EnumSkyBlock field_1299_a
 * - public int field_1298_b
 * - public int field_1304_c
 * - public int field_1303_d
 * - public int field_1302_e
 * - public int field_1301_f
 * - public int field_1300_g
 *
 * Java method/constructor inventory:
 * - public MetadataChunkBlock(EnumSkyBlock enumskyblock, int i, int j, int k, int l, int i1, int j1)
 * - public void func_4127_a(World world)
 * - public boolean func_866_a(int i, int j, int k, int l, int i1, int j1)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_50_lighting.h"
#include "../40_world/clonemc_java_port_40_world.h"

void CloneMCJ_MetadataChunkBlock_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MetadataChunkBlock_JavaName(void)
{
    return "net.minecraft.src.MetadataChunkBlock";
}

const char *CloneMCJ_MetadataChunkBlock_AssignedFolder(void)
{
    return "src/50_lighting";
}

unsigned long CloneMCJ_MetadataChunkBlock_JavaSourceHash32(void)
{
    return 0x9747F05EUL;
}

/* Priority 3 bounded light-region helper from MetadataChunkBlock.java. */
void CloneMCJ_MetadataChunkBlock_Initialize(CloneMCJ_MetadataChunkBlock *region, int skyBlock, int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
{
    if (!region) { return; }
    region->skyBlock = skyBlock;
    region->minX = minX;
    region->minY = minY;
    region->minZ = minZ;
    region->maxX = maxX;
    region->maxY = maxY;
    region->maxZ = maxZ;
}

int CloneMCJ_MetadataChunkBlock_CanCombine(CloneMCJ_MetadataChunkBlock *region, int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
{
    int oldVolume;
    int newMinX;
    int newMinY;
    int newMinZ;
    int newMaxX;
    int newMaxY;
    int newMaxZ;
    int newVolume;
    if (!region) { return 0; }
    if (minX >= region->minX && minY >= region->minY && minZ >= region->minZ &&
        maxX <= region->maxX && maxY <= region->maxY && maxZ <= region->maxZ) { return 1; }
    if (minX < region->minX - 1 || minY < region->minY - 1 || minZ < region->minZ - 1 ||
        maxX > region->maxX + 1 || maxY > region->maxY + 1 || maxZ > region->maxZ + 1) { return 0; }
    oldVolume = (region->maxX - region->minX) * (region->maxY - region->minY) * (region->maxZ - region->minZ);
    newMinX = minX < region->minX ? minX : region->minX;
    newMinY = minY < region->minY ? minY : region->minY;
    newMinZ = minZ < region->minZ ? minZ : region->minZ;
    newMaxX = maxX > region->maxX ? maxX : region->maxX;
    newMaxY = maxY > region->maxY ? maxY : region->maxY;
    newMaxZ = maxZ > region->maxZ ? maxZ : region->maxZ;
    newVolume = (newMaxX - newMinX) * (newMaxY - newMinY) * (newMaxZ - newMinZ);
    if (newVolume - oldVolume > 2) { return 0; }
    region->minX = newMinX;
    region->minY = newMinY;
    region->minZ = newMinZ;
    region->maxX = newMaxX;
    region->maxY = newMaxY;
    region->maxZ = newMaxZ;
    return 1;
}

int CloneMCJ_MetadataChunkBlock_Process(CloneMCJ_MetadataChunkBlock *region, CloneMCJ_World *world)
{
    int width;
    int height;
    int depth;
    int x;
    int y;
    int z;
    int oldLight;
    int newLight;
    int blockID;
    int opacity;
    int source;
    int neighbor;
    int changed;
    CloneMCJ_Chunk *chunk;
    if (!region || !world) { return 0; }
    width = region->maxX - region->minX + 1;
    height = region->maxY - region->minY + 1;
    depth = region->maxZ - region->minZ + 1;
    if (width <= 0 || height <= 0 || depth <= 0 || width * height * depth > 32768) { return 0; }
    if (region->minY < 0) { region->minY = 0; }
    if (region->maxY >= CLONEMC_J_CHUNK_HEIGHT) { region->maxY = CLONEMC_J_CHUNK_HEIGHT - 1; }
    changed = 0;
    for (x = region->minX; x <= region->maxX; ++x) {
        for (z = region->minZ; z <= region->maxZ; ++z) {
            /* Java reads missing neighbors as darkness; it does not require
             * diagonal chunks merely to update a cell in the current chunk.
             * Keeping this loaded-only avoids hidden terrain generation. */
            if (!CloneMCJ_World_IsChunkLoaded(world,
                    CloneMCJ_World_GlobalToChunk(x), CloneMCJ_World_GlobalToChunk(z))) { continue; }
            for (y = region->minY; y <= region->maxY; ++y) {
                oldLight = CloneMCJ_World_GetSavedLightValue(world, region->skyBlock, x, y, z);
                blockID = CloneMCJ_World_GetBlockId(world, x, y, z);
                opacity = CloneMCJ_World_GetBlockLightOpacity(blockID);
                if (opacity == 0) { opacity = 1; }
                source = 0;
                if (region->skyBlock == CLONEMC_J_ENUM_SKY_BLOCK_SKY) {
                    if (CloneMCJ_World_CanExistingBlockSeeTheSky(world, x, y, z)) { source = 15; }
                } else {
                    source = CloneMCJ_World_GetBlockLightEmission(blockID);
                }
                if (opacity >= 15 && source == 0) {
                    newLight = 0;
                } else {
                    newLight = CloneMCJ_World_GetSavedLightValue(world, region->skyBlock, x - 1, y, z);
                    neighbor = CloneMCJ_World_GetSavedLightValue(world, region->skyBlock, x + 1, y, z); if (neighbor > newLight) { newLight = neighbor; }
                    neighbor = CloneMCJ_World_GetSavedLightValue(world, region->skyBlock, x, y - 1, z); if (neighbor > newLight) { newLight = neighbor; }
                    neighbor = CloneMCJ_World_GetSavedLightValue(world, region->skyBlock, x, y + 1, z); if (neighbor > newLight) { newLight = neighbor; }
                    neighbor = CloneMCJ_World_GetSavedLightValue(world, region->skyBlock, x, y, z - 1); if (neighbor > newLight) { newLight = neighbor; }
                    neighbor = CloneMCJ_World_GetSavedLightValue(world, region->skyBlock, x, y, z + 1); if (neighbor > newLight) { newLight = neighbor; }
                    newLight -= opacity;
                    if (newLight < 0) { newLight = 0; }
                    if (source > newLight) { newLight = source; }
                }
                if (oldLight != newLight) {
                    int propagated;
                    /* The old wrapper searched the provider and dirtied edge
                     * neighbors for every changed cell.  A light flood can
                     * touch thousands of cells, so write the known loaded
                     * owner directly and batch neighbor mesh invalidation once
                     * at the end of the rectangular region. */
                    chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,
                        CloneMCJ_World_GlobalToChunk(x),CloneMCJ_World_GlobalToChunk(z));
                    if(chunk)CloneMCJ_Chunk_SetLightValue(chunk,region->skyBlock,
                        CloneMCJ_World_GlobalToLocal(x),y,
                        CloneMCJ_World_GlobalToLocal(z),newLight);
                    propagated = newLight > 0 ? newLight - 1 : 0;
                    CloneMCJ_World_NeighborLightPropagationChanged(world, region->skyBlock, x - 1, y, z, propagated);
                    CloneMCJ_World_NeighborLightPropagationChanged(world, region->skyBlock, x, y - 1, z, propagated);
                    CloneMCJ_World_NeighborLightPropagationChanged(world, region->skyBlock, x, y, z - 1, propagated);
                    if (x + 1 >= region->maxX) { CloneMCJ_World_NeighborLightPropagationChanged(world, region->skyBlock, x + 1, y, z, propagated); }
                    if (y + 1 >= region->maxY) { CloneMCJ_World_NeighborLightPropagationChanged(world, region->skyBlock, x, y + 1, z, propagated); }
                    if (z + 1 >= region->maxZ) { CloneMCJ_World_NeighborLightPropagationChanged(world, region->skyBlock, x, y, z + 1, propagated); }
                    ++changed;
                }
            }
        }
    }
    if(changed>0)CloneMCJ_World_MarkLightingRegionDirty(world,
        region->minX,region->minY,region->minZ,
        region->maxX,region->maxY,region->maxZ);
    return changed;
}
