/*
 * CloneMC Java port scaffold: ChunkProviderLoadOrGenerate
 *
 * Java source: ChunkProviderLoadOrGenerate.java
 * Java type: class ChunkProviderLoadOrGenerate
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IChunkProvider
 * Source SHA-256: b0669630c02f0243a5690dc3a1e1f43c479f44ebf5568aeec3ed44224f288ecb
 * Java lines: 266
 * Discovered declared fields: 8
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: IChunkProvider, Chunk, World, IChunkLoader, IProgressUpdate
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Chunk blankChunk
 * - private IChunkProvider chunkProvider
 * - private IChunkLoader chunkLoader
 * - private Chunk chunks[]
 * - private World worldObj
 * - private Chunk lastQueriedChunk
 * - private int curChunkX
 * - private int curChunkY
 *
 * Java method/constructor inventory:
 * - public void setCurrentChunkOver(int i, int j)
 * - public boolean canChunkExist(int i, int j)
 * - public boolean chunkExists(int i, int j)
 * - public Chunk prepareChunk(int i, int j)
 * - public Chunk provideChunk(int i, int j)
 * - private Chunk func_542_c(int i, int j)
 * - private void saveExtraChunkData(Chunk chunk)
 * - private void saveChunk(Chunk chunk)
 * - public void populate(IChunkProvider ichunkprovider, int i, int j)
 * - public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
 * - public boolean unload100OldestChunks()
 * - public boolean canSave()
 * - public String makeString()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"
#include <stdlib.h>
#include <string.h>


static int CloneMCJ_Provider_V119TestGenerate(CloneMCJ_Chunk *chunk,
    int chunkX, int chunkZ, void *userData)
{
    (void)userData;
    CloneMCJ_Chunk_Initialize(chunk, chunkX, chunkZ);
    chunk->isModified = 0;
    chunk->state = CLONEMC_J_CHUNK_STATE_READY;
    return 1;
}

static int CloneMCJ_Provider_V119TestSave(const CloneMCJ_Chunk *chunk,
    int force, void *userData)
{
    (void)chunk; (void)force; (void)userData;
    return 1;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_RunV119SelfTests(char *message,
    unsigned int capacity)
{
    CloneMCJ_ChunkProviderLoadOrGenerate provider;
    int x;
    int z;
    int allowed;
    int ok;
    CloneMCJ_Chunk *chunk;
    unsigned long serialBeforeLoads;
    unsigned long serialBeforeEviction;
    memset(&provider, 0, sizeof(provider));
    CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&provider, (CloneMCJLong)1);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(&provider, 0, 0,
        CloneMCJ_Provider_V119TestGenerate, 0,
        CloneMCJ_Provider_V119TestSave, 0);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(&provider, 0, 0);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&provider, 48);
    allowed = 0;
    for (z = -8; z <= 8; ++z)
        for (x = -8; x <= 8; ++x)
            if (CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(
                    &provider, x, z)) ++allowed;
    ok = allowed == 48 && provider.allowedChunkCount == 48;
    if (ok) {
        CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&provider, 4);
        serialBeforeLoads=provider.residentSerial;
        chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,0,0);
        if (!chunk || chunk == &provider.blankChunk) ok = 0;
        chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,0,-1);
        if (!chunk || chunk == &provider.blankChunk) ok = 0;
        chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,1,0);
        if (!chunk || chunk == &provider.blankChunk) ok = 0;
        chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,0,1);
        if (!chunk || chunk == &provider.blankChunk) ok = 0;
    }
    if (ok && (provider.residentCount != 4 ||
        provider.residentSerial==serialBeforeLoads)) ok = 0;
    if (ok) {
        serialBeforeEviction=provider.residentSerial;
        CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(&provider,1,0);
        chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,2,0);
        if (!chunk || chunk == &provider.blankChunk ||
            provider.residentCount > 4 || provider.budgetEvictions == 0UL ||
            provider.residentSerial==serialBeforeEviction) ok = 0;
    }
    CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&provider);
    if (message && capacity) {
        strncpy(message, ok ?
            "V142 V135 nearest-set ownership and resident-serial tests passed" :
            "V142 nearest-set ownership/resident-serial test failed", capacity - 1U);
        message[capacity - 1U] = '\0';
    }
    return ok;
}

void CloneMCJ_ChunkProviderLoadOrGenerate_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkProviderLoadOrGenerate_JavaName(void)
{
    return "net.minecraft.src.ChunkProviderLoadOrGenerate";
}

const char *CloneMCJ_ChunkProviderLoadOrGenerate_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkProviderLoadOrGenerate_JavaSourceHash32(void)
{
    return 0xB0669630UL;
}

/* Priority 3 fixed-capacity chunk provider from ChunkProviderLoadOrGenerate.java. */

static int CloneMCJ_ChunkProvider_DefaultGenerator(CloneMCJ_Chunk *chunk, int chunkX, int chunkZ, void *userData)
{
    (void)userData;
    CloneMCJ_Chunk_Initialize(chunk, chunkX, chunkZ);
    chunk->state = CLONEMC_J_CHUNK_STATE_GENERATING_BASE;
    chunk->isTerrainPopulated = 0;
    chunk->state = CLONEMC_J_CHUNK_STATE_WAITING_FOR_NEIGHBORS;
    return 1;
}

static int CloneMCJ_Provider_I_ChunkExists(void *instance, int chunkX, int chunkZ)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists((const CloneMCJ_ChunkProviderLoadOrGenerate *)instance, chunkX, chunkZ);
}

static CloneMCJ_Chunk *CloneMCJ_Provider_I_ProvideChunk(void *instance, int chunkX, int chunkZ)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_ProvideChunk((CloneMCJ_ChunkProviderLoadOrGenerate *)instance, chunkX, chunkZ);
}

static CloneMCJ_Chunk *CloneMCJ_Provider_I_PrepareChunk(void *instance, int chunkX, int chunkZ)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk((CloneMCJ_ChunkProviderLoadOrGenerate *)instance, chunkX, chunkZ);
}

static void CloneMCJ_Provider_I_Populate(void *instance, CloneMCJ_IChunkProvider *provider, int chunkX, int chunkZ)
{
    (void)provider;
    CloneMCJ_ChunkProviderLoadOrGenerate_Populate((CloneMCJ_ChunkProviderLoadOrGenerate *)instance, chunkX, chunkZ);
}

static int CloneMCJ_Provider_I_SaveChunks(void *instance, int force, void *progressUpdate)
{
    (void)progressUpdate;
    return CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunks((CloneMCJ_ChunkProviderLoadOrGenerate *)instance, force);
}

static int CloneMCJ_Provider_I_Unload100(void *instance)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_Unload100OldestChunks((CloneMCJ_ChunkProviderLoadOrGenerate *)instance);
}

static int CloneMCJ_Provider_I_CanSave(void *instance)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_CanSave((const CloneMCJ_ChunkProviderLoadOrGenerate *)instance);
}

static const char *CloneMCJ_Provider_I_MakeString(void *instance)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_MakeString((const CloneMCJ_ChunkProviderLoadOrGenerate *)instance);
}

void CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(CloneMCJ_ChunkProviderLoadOrGenerate *provider, CloneMCJLong worldSeed)
{
    int i;
    if (!provider) { return; }
    memset(provider, 0, sizeof(*provider));
    provider->worldSeed = worldSeed;
    provider->curChunkX = 0;
    provider->curChunkZ = 0;
    provider->allowedRadius = CLONEMC_J_CHUNK_PROVIDER_RADIUS;
    provider->allowedChunkCount = 1 + 2 * CLONEMC_J_CHUNK_PROVIDER_RADIUS *
        (CLONEMC_J_CHUNK_PROVIDER_RADIUS + 1);
    provider->runtimeMemoryBudgetBytes=CLONEMC_J_CHUNK_MEMORY_BUDGET_BYTES;
    provider->accessClock = 1UL;
    provider->residentSerial = 1UL;
    provider->residentCount = 0;
    provider->saveCursor = 0;
    provider->allocationFailures = 0UL;
    provider->chunksSavedIncrementally = 0UL;
    provider->chunksSavedForced = 0UL;
    CloneMCJ_EmptyChunk_Initialize(&provider->blankChunk, 0, 0);
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) { provider->slots[i].used = 0; }
    provider->generator = CloneMCJ_ChunkProvider_DefaultGenerator;
    provider->providerInterface.instance = provider;
    provider->providerInterface.chunkExists = CloneMCJ_Provider_I_ChunkExists;
    provider->providerInterface.provideChunk = CloneMCJ_Provider_I_ProvideChunk;
    provider->providerInterface.prepareChunk = CloneMCJ_Provider_I_PrepareChunk;
    provider->providerInterface.populate = CloneMCJ_Provider_I_Populate;
    provider->providerInterface.saveChunks = CloneMCJ_Provider_I_SaveChunks;
    provider->providerInterface.unload100OldestChunks = CloneMCJ_Provider_I_Unload100;
    provider->providerInterface.canSave = CloneMCJ_Provider_I_CanSave;
    provider->providerInterface.makeString = CloneMCJ_Provider_I_MakeString;
}

void CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    int i;
    if (!provider) { return; }
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) {
        if (provider->slots[i].used && provider->slots[i].chunk) { CloneMCJ_Chunk_Destroy(provider->slots[i].chunk); free(provider->slots[i].chunk); }
        provider->slots[i].chunk = 0;
        provider->slots[i].used = 0;
    }
    provider->residentCount = 0;
    CloneMCJ_Chunk_Destroy(&provider->blankChunk);
}

void CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(CloneMCJ_ChunkProviderLoadOrGenerate *provider,
    CloneMCJ_ChunkLoaderProc loader, void *loaderUser,
    CloneMCJ_ChunkGeneratorProc generator, void *generatorUser,
    CloneMCJ_ChunkSaverProc saver, void *saverUser)
{
    if (!provider) { return; }
    provider->loader = loader;
    provider->loaderUser = loaderUser;
    provider->generator = generator ? generator : CloneMCJ_ChunkProvider_DefaultGenerator;
    provider->generatorUser = generatorUser;
    provider->saver = saver;
    provider->saverUser = saverUser;
}

void CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkX, int chunkZ)
{
    if (!provider) { return; }
    provider->curChunkX = chunkX;
    provider->curChunkZ = chunkZ;
}

static int CloneMCJ_ChunkProvider_RadiusForCount(int count)
{
    int radius;
    int total;
    if (count < 1) count = 1;
    radius = 0;
    total = 1;
    while (total < count && radius < CLONEMC_J_CHUNK_PROVIDER_RADIUS) {
        ++radius;
        total = 1 + 2 * radius * (radius + 1);
    }
    return radius;
}

void CloneMCJ_ChunkProviderLoadOrGenerate_SetAllowedRadius(CloneMCJ_ChunkProviderLoadOrGenerate *provider, int radius)
{
    if (!provider) { return; }
    if (radius < 0) radius = 0;
    if (radius > CLONEMC_J_CHUNK_PROVIDER_RADIUS) radius = CLONEMC_J_CHUNK_PROVIDER_RADIUS;
    provider->allowedRadius = radius;
    provider->allowedChunkCount = 1 + 2 * radius * (radius + 1);
}

void CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkCount)
{
    int maximum;
    if (!provider) return;
    maximum = 1 + 2 * CLONEMC_J_CHUNK_PROVIDER_RADIUS *
        (CLONEMC_J_CHUNK_PROVIDER_RADIUS + 1);
    if (chunkCount < 1) chunkCount = 1;
    if (chunkCount > maximum) chunkCount = maximum;
    provider->allowedChunkCount = chunkCount;
    provider->allowedRadius = CloneMCJ_ChunkProvider_RadiusForCount(chunkCount);
}

void CloneMCJ_ChunkProviderLoadOrGenerate_SetMemoryBudget(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider,unsigned long budgetBytes)
{
    unsigned long minimumBytes;
    if(!provider)return;
    minimumBytes=(unsigned long)sizeof(CloneMCJ_Chunk);
    if(budgetBytes<minimumBytes)budgetBytes=minimumBytes;
    if(budgetBytes>CLONEMC_J_CHUNK_MEMORY_BUDGET_BYTES)
        budgetBytes=CLONEMC_J_CHUNK_MEMORY_BUDGET_BYTES;
    provider->runtimeMemoryBudgetBytes=budgetBytes;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_ChunkRank(
    const CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkX, int chunkZ)
{
    int dx;
    int dz;
    int radius;
    int before;
    int offset;
    if (!provider) return -1;
    dx = chunkX - provider->curChunkX;
    dz = chunkZ - provider->curChunkZ;
    radius = (dx < 0 ? -dx : dx) + (dz < 0 ? -dz : dz);
    if (radius == 0) return 0;
    if (radius > CLONEMC_J_CHUNK_PROVIDER_RADIUS) return -1;
    before = 1 + 2 * (radius - 1) * radius;
    /* Exact perimeter order used by World_StreamCoordinate.  V142 restores
     * the V135 contract: the user option is an exact nearest-chunk budget,
     * while this rank gives the deterministic admission order for that budget. */
    if (dz < 0 && dx >= 0) offset = dx;
    else if (dx > 0 && dz >= 0) offset = radius + dz;
    else if (dz > 0 && dx <= 0) offset = radius * 2 - dx;
    else offset = radius * 3 - dz;
    return before + offset;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(const CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkX, int chunkZ)
{
    int rank;
    if (!provider) return 0;
    rank = CloneMCJ_ChunkProviderLoadOrGenerate_ChunkRank(provider, chunkX, chunkZ);
    return rank >= 0 && rank < provider->allowedChunkCount;
}

static int CloneMCJ_Provider_IsWithinResidentSet(
    const CloneMCJ_ChunkProviderLoadOrGenerate *provider,int chunkX,int chunkZ)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(provider,chunkX,chunkZ);
}

static int CloneMCJ_Provider_FindSlot(const CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkX, int chunkZ)
{
    int i;
    if (!provider) { return -1; }
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) {
        if (provider->slots[i].used && provider->slots[i].chunk && CloneMCJ_Chunk_IsAtLocation(provider->slots[i].chunk, chunkX, chunkZ)) { return i; }
    }
    return -1;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(const CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkX, int chunkZ)
{
    return CloneMCJ_Provider_FindSlot(provider, chunkX, chunkZ) >= 0;
}

static int CloneMCJ_Provider_SaveSlotIfNeeded(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider, int slot, int force);

static int CloneMCJ_Provider_ChooseSlot(CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    int i;
    int best;
    unsigned long bestStamp;
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) { if (!provider->slots[i].used) { return i; } }
    best = -1;
    bestStamp = 0xFFFFFFFFUL;
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) {
        if (!provider->slots[i].locked && provider->slots[i].lastAccess <= bestStamp) {
            best = i;
            bestStamp = provider->slots[i].lastAccess;
        }
    }
    return best >= 0 ? best : 0;
}

static int CloneMCJ_Provider_FindOldestOutsideBudget(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    int i;
    int best;
    unsigned long bestStamp;
    CloneMCJ_Chunk *chunk;
    if (!provider) return -1;
    best = -1;
    bestStamp = 0xFFFFFFFFUL;
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) {
        if (!provider->slots[i].used || provider->slots[i].locked ||
            !provider->slots[i].chunk) continue;
        chunk = provider->slots[i].chunk;
        if (CloneMCJ_Provider_IsWithinResidentSet(provider,
                chunk->xPosition, chunk->zPosition)) continue;
        if (provider->slots[i].lastAccess <= bestStamp) {
            bestStamp = provider->slots[i].lastAccess;
            best = i;
        }
    }
    return best;
}

/* V142 removed the V139 farthest-resident movement eviction path. */

static int CloneMCJ_Provider_ReleaseSlotForBudget(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider, int slot)
{
    if (!provider || slot < 0 || slot >= CLONEMC_J_CHUNK_CACHE_CAPACITY)
        return 0;
    if (!provider->slots[slot].used) return 1;
    if (!CloneMCJ_Provider_SaveSlotIfNeeded(provider, slot, 0)) return 0;
    if (provider->slots[slot].chunk) {
        CloneMCJ_Chunk_Destroy(provider->slots[slot].chunk);
        free(provider->slots[slot].chunk);
        provider->slots[slot].chunk = 0;
        if (provider->residentCount > 0) --provider->residentCount;
    }
    provider->slots[slot].used = 0;
    provider->slots[slot].locked = 0;
    provider->slots[slot].lastAccess = 0UL;
    ++provider->residentSerial;
    if(provider->residentSerial==0UL)provider->residentSerial=1UL;
    ++provider->budgetEvictions;
    return 1;
}

static int CloneMCJ_Provider_SaveSlotIfNeeded(CloneMCJ_ChunkProviderLoadOrGenerate *provider, int slot, int force)
{
    CloneMCJ_Chunk *chunk;
    CloneMCJLong worldTime;
    if (!provider || slot < 0 || slot >= CLONEMC_J_CHUNK_CACHE_CAPACITY) return 0;
    if (!provider->slots[slot].used) return 1;
    chunk = provider->slots[slot].chunk;
    if (!chunk) return 1;
    worldTime = provider->worldTimePointer ? *provider->worldTimePointer : (CloneMCJLong)0;
    if (!CloneMCJ_Chunk_NeedsSaving(chunk, force, worldTime)) return 1;
    /* V116: a dirty chunk may never be discarded merely because its region
     * write failed.  The old void helper silently returned and every eviction
     * path freed the chunk anyway, which reproduced the reported edits that
     * vanished after walking away or changing render distance. */
    if (!provider->saver || !provider->saver(chunk, force, provider->saverUser)) {
        chunk->isModified = 1;
        return 0;
    }
    chunk->isModified = 0;
    chunk->lastSaveTime = worldTime;
    chunk->state = CLONEMC_J_CHUNK_STATE_READY;
    return 1;
}

void CloneMCJ_ChunkProviderLoadOrGenerate_SetWorldTimePointer(CloneMCJ_ChunkProviderLoadOrGenerate *provider, CloneMCJLong *worldTimePointer)
{
    if (provider) { provider->worldTimePointer = worldTimePointer; }
}

static CloneMCJ_Chunk *CloneMCJ_Provider_PrepareChunkInternal(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider,int chunkX,int chunkZ,
    int movementPriority)
{
    int slot;
    int loaded;
    int evictSlot;
    if (!provider) { return 0; }
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(provider,
            chunkX, chunkZ)) return &provider->blankChunk;
    slot = CloneMCJ_Provider_FindSlot(provider, chunkX, chunkZ);
    if (slot >= 0) {
        provider->slots[slot].lastAccess = ++provider->accessClock;
        provider->slots[slot].chunk->lruStamp = provider->slots[slot].lastAccess;
        return provider->slots[slot].chunk;
    }
    /* Enforce the exact nearest resident set before allocating.  Gameplay and
     * collision queries are not allowed to replace an in-range chunk.  This
     * restores the V135 ownership rule and prevents movement from turning into
     * synchronous save/free/load/generate churn. */
    while (provider->residentCount >= provider->allowedChunkCount) {
        evictSlot = CloneMCJ_Provider_FindOldestOutsideBudget(provider);
        (void)movementPriority;
        if (evictSlot < 0 ||
            !CloneMCJ_Provider_ReleaseSlotForBudget(provider, evictSlot)) {
            ++provider->budgetDeferrals;
            return &provider->blankChunk;
        }
    }
    /* Retain a second hard byte ceiling for fragmented 32-bit heaps. */
    if ((unsigned long)provider->residentCount >=
        provider->runtimeMemoryBudgetBytes / (unsigned long)sizeof(CloneMCJ_Chunk)) {
        ++provider->allocationFailures;
        return &provider->blankChunk;
    }
    slot = CloneMCJ_Provider_ChooseSlot(provider);
    if (slot < 0 || !CloneMCJ_Provider_SaveSlotIfNeeded(provider, slot, 0)) {
        ++provider->allocationFailures;
        return &provider->blankChunk;
    }
    if (provider->slots[slot].chunk) {
        CloneMCJ_Chunk_Destroy(provider->slots[slot].chunk);
        free(provider->slots[slot].chunk);
        provider->slots[slot].chunk = 0;
        if (provider->residentCount > 0) --provider->residentCount;
    }
    provider->slots[slot].chunk = (CloneMCJ_Chunk *)malloc(sizeof(CloneMCJ_Chunk));
    if (!provider->slots[slot].chunk) {
        provider->slots[slot].used = 0;
        ++provider->allocationFailures;
        return &provider->blankChunk;
    }
    ++provider->residentCount;
    provider->slots[slot].used = 1;
    provider->slots[slot].lastAccess = ++provider->accessClock;
    loaded = 0;
    if (provider->loader) { loaded = provider->loader(provider->slots[slot].chunk, chunkX, chunkZ, provider->loaderUser); }
    if (loaded < 0) {
        ++provider->chunkLoadFailures;
        provider->lastFailedChunkX = chunkX; provider->lastFailedChunkZ = chunkZ;
        CloneMCJ_Chunk_Destroy(provider->slots[slot].chunk);
        free(provider->slots[slot].chunk);
        provider->slots[slot].chunk = 0; provider->slots[slot].used = 0;
        if (provider->residentCount > 0) --provider->residentCount;
        return &provider->blankChunk;
    }
    if (loaded == 0) {
        provider->slots[slot].chunk->state = CLONEMC_J_CHUNK_STATE_GENERATING_BASE;
        if (!provider->generator(provider->slots[slot].chunk, chunkX, chunkZ, provider->generatorUser)) {
            CloneMCJ_Chunk_Destroy(provider->slots[slot].chunk);
            free(provider->slots[slot].chunk); provider->slots[slot].chunk = 0;
            provider->slots[slot].used = 0; if (provider->residentCount > 0) --provider->residentCount;
            ++provider->allocationFailures; return &provider->blankChunk;
        }
        ++provider->chunksGeneratedNew;
    } else {
        ++provider->chunksLoadedFromDisk;
    }
    if ((unsigned long)provider->residentCount > provider->residentHighWaterMark)
        provider->residentHighWaterMark = (unsigned long)provider->residentCount;
    provider->slots[slot].chunk->lruStamp = provider->slots[slot].lastAccess;
    provider->slots[slot].chunk->loaded = 1;
    provider->slots[slot].chunk->isChunkLoaded = 1;
    ++provider->residentSerial;
    if(provider->residentSerial==0UL)provider->residentSerial=1UL;
    return provider->slots[slot].chunk;
}

CloneMCJ_Chunk *CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider,int chunkX,int chunkZ)
{
    return CloneMCJ_Provider_PrepareChunkInternal(provider,chunkX,chunkZ,0);
}

CloneMCJ_Chunk *CloneMCJ_ChunkProviderLoadOrGenerate_PreparePriorityChunk(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider,int chunkX,int chunkZ)
{
    return CloneMCJ_Provider_PrepareChunkInternal(provider,chunkX,chunkZ,0);
}

CloneMCJ_Chunk *CloneMCJ_ChunkProviderLoadOrGenerate_ProvideChunk(CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkX, int chunkZ)
{
    if (!provider) { return 0; }
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(provider, chunkX, chunkZ)) { return &provider->blankChunk; }
    return CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(provider, chunkX, chunkZ);
}

void CloneMCJ_ChunkProviderLoadOrGenerate_Populate(CloneMCJ_ChunkProviderLoadOrGenerate *provider, int chunkX, int chunkZ)
{
    CloneMCJ_Chunk *chunk;
    if (!provider ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(provider, chunkX, chunkZ)) {
        return;
    }
    chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(provider, chunkX, chunkZ);
    if (!chunk || chunk->neverSave) { return; }
    chunk->state = CLONEMC_J_CHUNK_STATE_POPULATING;
    chunk->isTerrainPopulated = 1;
    chunk->state = CLONEMC_J_CHUNK_STATE_LIGHTING;
    chunk->lightDirty = 1;
    chunk->state = CLONEMC_J_CHUNK_STATE_MESH_QUEUED;
    chunk->meshDirty = 1;
    chunk->meshDirtySections=0xFFU;
    chunk->state = CLONEMC_J_CHUNK_STATE_READY;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_CountChunksNeedingSave(
    const CloneMCJ_ChunkProviderLoadOrGenerate *provider, int force)
{
    int i;
    int count;
    CloneMCJLong worldTime;
    if (!provider) return 0;
    count = 0;
    worldTime = provider->worldTimePointer ? *provider->worldTimePointer :
        (CloneMCJLong)0;
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) {
        if (provider->slots[i].used && provider->slots[i].chunk &&
            CloneMCJ_Chunk_NeedsSaving(provider->slots[i].chunk, force,
                worldTime)) ++count;
    }
    return count;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunksBudget(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider, int force, int maximum,
    int *remaining)
{
    int scanned;
    int saved;
    int slot;
    int needed;
    if (remaining) *remaining = 0;
    if (!provider) return -1;
    if (maximum < 1) maximum = 1;
    saved = 0;
    scanned = 0;
    /* ChunkProviderLoadOrGenerate.java saves at most two chunks during a
     * non-forced autosave.  Start at a persistent cursor so a busy low-index
     * chunk cannot starve later chunks forever.  Forced saves still walk the
     * complete resident set, but callers may split them into small batches to
     * keep the loading screen and Win32 message queue responsive. */
    while (scanned < CLONEMC_J_CHUNK_CACHE_CAPACITY && saved < maximum) {
        slot = provider->saveCursor;
        ++provider->saveCursor;
        if (provider->saveCursor >= CLONEMC_J_CHUNK_CACHE_CAPACITY)
            provider->saveCursor = 0;
        ++scanned;
        if (!provider->slots[slot].used || !provider->slots[slot].chunk)
            continue;
        if (!CloneMCJ_Chunk_NeedsSaving(provider->slots[slot].chunk, force,
                provider->worldTimePointer ? *provider->worldTimePointer :
                (CloneMCJLong)0)) continue;
        if (!CloneMCJ_Provider_SaveSlotIfNeeded(provider, slot, force)) {
            if (remaining)
                *remaining = CloneMCJ_ChunkProviderLoadOrGenerate_CountChunksNeedingSave(
                    provider, force);
            return -1;
        }
        ++saved;
        if (force) ++provider->chunksSavedForced;
        else ++provider->chunksSavedIncrementally;
    }
    needed = CloneMCJ_ChunkProviderLoadOrGenerate_CountChunksNeedingSave(
        provider, force);
    if (remaining) *remaining = needed;
    return saved;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunks(
    CloneMCJ_ChunkProviderLoadOrGenerate *provider, int force)
{
    int remaining;
    int total;
    int saved;
    int budget;
    if (!provider) return -1;
    total = 0;
    budget = force ? CLONEMC_J_CHUNK_CACHE_CAPACITY : 2;
    do {
        saved = CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunksBudget(provider,
            force, budget, &remaining);
        if (saved < 0) return -1;
        total += saved;
        /* Non-forced Java autosaves intentionally stop after two chunks. */
        if (!force) break;
    } while (remaining > 0 && saved > 0);
    return total;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_UnloadOldestChunks(CloneMCJ_ChunkProviderLoadOrGenerate *provider, int maximum)
{
    int removed;
    int pass;
    int best;
    unsigned long bestStamp;
    int i;
    if (!provider || maximum <= 0) { return 0; }
    removed = 0;
    for (pass = 0; pass < maximum; ++pass) {
        best = -1;
        bestStamp = 0xFFFFFFFFUL;
        for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) {
            if (provider->slots[i].used && provider->slots[i].chunk &&
                !provider->slots[i].locked && provider->slots[i].lastAccess < bestStamp &&
                !CloneMCJ_Provider_IsWithinResidentSet(provider,
                    provider->slots[i].chunk->xPosition,
                    provider->slots[i].chunk->zPosition)) {
                best = i;
                bestStamp = provider->slots[i].lastAccess;
            }
        }
        if (best < 0) { break; }
        if (!CloneMCJ_Provider_SaveSlotIfNeeded(provider, best, 0)) {
            /* Keep the dirty resident chunk and stop this bounded unload pass. */
            provider->slots[best].lastAccess = ++provider->accessClock;
            break;
        }
        if (provider->slots[best].chunk) {
            CloneMCJ_Chunk_Destroy(provider->slots[best].chunk);
            free(provider->slots[best].chunk);
            provider->slots[best].chunk = 0;
            if (provider->residentCount > 0) --provider->residentCount;
        }
        provider->slots[best].used = 0;
        ++provider->residentSerial;
        if(provider->residentSerial==0UL)provider->residentSerial=1UL;
        ++removed;
    }
    return removed;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_Unload100OldestChunks(CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    return CloneMCJ_ChunkProviderLoadOrGenerate_UnloadOldestChunks(provider, 100) > 0;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_CanSave(const CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    (void)provider;
    return 1;
}

const char *CloneMCJ_ChunkProviderLoadOrGenerate_MakeString(const CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    (void)provider;
    return "ServerChunkCache: Priority3RealChunks";
}

CloneMCJ_IChunkProvider *CloneMCJ_ChunkProviderLoadOrGenerate_AsIChunkProvider(CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    return provider ? &provider->providerInterface : 0;
}


int CloneMCJ_ChunkProviderLoadOrGenerate_RunLimitSelfTests(char *message,
    unsigned int capacity)
{
    CloneMCJ_ChunkProviderLoadOrGenerate provider;
    static const int limits[6]={1,2,8,16,32,48};
    int limitIndex;
    int dx;
    int dz;
    int admitted;
    int rank;
    int seen[48];
    CloneMCJ_Chunk *firstChunk;
    CloneMCJ_Chunk *secondChunk;
    CloneMCJ_Chunk *blockedChunk;
    int ok;
    ok=1;
    CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&provider,(CloneMCJLong)1);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(&provider,17,-23);
    for(limitIndex=0;limitIndex<6&&ok;++limitIndex){
        memset(seen,0,sizeof(seen));
        CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&provider,limits[limitIndex]);
        admitted=0;
        for(dz=-CLONEMC_J_CHUNK_PROVIDER_RADIUS;
            dz<=CLONEMC_J_CHUNK_PROVIDER_RADIUS;++dz){
            for(dx=-CLONEMC_J_CHUNK_PROVIDER_RADIUS;
                dx<=CLONEMC_J_CHUNK_PROVIDER_RADIUS;++dx){
                if(!CloneMCJ_Provider_IsWithinResidentSet(&provider,
                    provider.curChunkX+dx,provider.curChunkZ+dz))continue;
                rank=CloneMCJ_ChunkProviderLoadOrGenerate_ChunkRank(&provider,
                    provider.curChunkX+dx,provider.curChunkZ+dz);
                if(rank<0||rank>=limits[limitIndex]||rank>=48||seen[rank]){
                    ok=0;break;
                }
                seen[rank]=1;++admitted;
            }
            if(!ok)break;
        }
        if(admitted!=limits[limitIndex])ok=0;
        for(rank=0;rank<limits[limitIndex]&&ok;++rank)
            if(!seen[rank])ok=0;
    }
    if(ok){
        admitted=0;
        for(dz=-CLONEMC_J_CHUNK_PROVIDER_RADIUS;
            dz<=CLONEMC_J_CHUNK_PROVIDER_RADIUS;++dz)
            for(dx=-CLONEMC_J_CHUNK_PROVIDER_RADIUS;
                dx<=CLONEMC_J_CHUNK_PROVIDER_RADIUS;++dx)
                if(CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(&provider,
                    provider.curChunkX+dx,provider.curChunkZ+dz))++admitted;
        if(admitted!=provider.allowedChunkCount)ok=0;
    }
    if(ok){
        CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(&provider,0,0);
        CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&provider,4);
        CloneMCJ_ChunkProviderLoadOrGenerate_SetMemoryBudget(&provider,
            2UL*(unsigned long)sizeof(CloneMCJ_Chunk));
        firstChunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,0,0);
        secondChunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,0,-1);
        blockedChunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider,1,0);
        if(!firstChunk||!secondChunk||
           firstChunk==&provider.blankChunk||secondChunk==&provider.blankChunk||
           blockedChunk!=&provider.blankChunk||provider.residentCount!=2||
           provider.allocationFailures==0UL)ok=0;
    }
    CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&provider);
    if(message&&capacity){
        strncpy(message,ok?
            "V142 V135 resident ranking and runtime byte-ceiling tests passed":
            "V142 resident ranking/runtime-budget test failed",capacity-1U);
        message[capacity-1U]='\0';
    }
    return ok;
}

int CloneMCJ_ChunkProviderLoadOrGenerate_CountLoaded(const CloneMCJ_ChunkProviderLoadOrGenerate *provider)
{
    int count;
    if (!provider) { return 0; }
    count = provider->residentCount;
    if (count < 0) count = 0;
    return count;
}
