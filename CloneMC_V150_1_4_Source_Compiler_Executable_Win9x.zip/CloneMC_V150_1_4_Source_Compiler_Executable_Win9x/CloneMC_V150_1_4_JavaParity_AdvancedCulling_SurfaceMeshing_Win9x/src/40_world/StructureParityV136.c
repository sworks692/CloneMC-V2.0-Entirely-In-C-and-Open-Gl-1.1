/*
 * V136 deterministic recursive ports of the Java 1.2.3 structure piece graphs.
 *
 * Java retains StructureStart objects and generates each component against a
 * chunk bounding box.  This C89 port reconstructs the same kind of weighted
 * graph from its start seed and emits only the currently populated chunk.  It
 * therefore permits cross-chunk structures without forcing their full extent
 * into the fixed Windows 98 resident-chunk cache.
 */
#include "clonemc_java_port_40_world.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define V136_MAX_PIECES 256
#define V136_STRUCTURE_RADIUS 112
#define V136_STRONGHOLD_RETRY_LIMIT 64

typedef struct V136PieceTag {
    short type,depth,direction,pool,width,height,length;
    int ox,oy,oz,minX,minY,minZ,maxX,maxY,maxZ;
    unsigned long seed;
    /* Constructor-time Java component state.  Keeping these values on the
     * bounded piece record avoids rerolling visual/branch variants when a
     * structure is reconstructed for a neighboring chunk. */
    unsigned char doorType,variantA,variantB,variantC;
} V136Piece;

typedef struct V136GraphTag {
    V136Piece piece[V136_MAX_PIECES];
    int count,rootX,rootZ;
    unsigned char portal,overflow;
} V136Graph;

static const int v136RX[4]={1,0,-1,0};
static const int v136RZ[4]={0,1,0,-1};
static const int v136FX[4]={0,-1,0,1};
static const int v136FZ[4]={1,0,-1,0};

static int V136FloorDiv(int value,int divisor)
{
    int q;q=value/divisor;if(value<0&&value%divisor)--q;return q;
}

static unsigned long V136Hash(int x,int y,int z,unsigned long seed)
{
    unsigned long h;
    h=seed^(unsigned long)x*0x8DA6B343UL^(unsigned long)y*0xD8163841UL^
        (unsigned long)z*0xCB1AB31FUL;
    h^=h>>13;h*=0x85EBCA6BUL;h^=h>>16;return h;
}

static void V136Transform(const V136Piece *p,int lx,int ly,int lz,
    int *x,int *y,int *z)
{
    int d;d=p->direction&3;
    *x=p->ox+v136RX[d]*lx+v136FX[d]*lz;
    *y=p->oy+ly;
    *z=p->oz+v136RZ[d]*lx+v136FZ[d]*lz;
}

static void V136Bounds(V136Piece *p)
{
    int x[4],z[4],y,i;
    V136Transform(p,0,0,0,&x[0],&y,&z[0]);
    V136Transform(p,p->width-1,0,0,&x[1],&y,&z[1]);
    V136Transform(p,0,0,p->length-1,&x[2],&y,&z[2]);
    V136Transform(p,p->width-1,0,p->length-1,&x[3],&y,&z[3]);
    p->minX=p->maxX=x[0];p->minZ=p->maxZ=z[0];
    for(i=1;i<4;++i){
        if(x[i]<p->minX)p->minX=x[i];if(x[i]>p->maxX)p->maxX=x[i];
        if(z[i]<p->minZ)p->minZ=z[i];if(z[i]>p->maxZ)p->maxZ=z[i];
    }
    p->minY=p->oy;p->maxY=p->oy+p->height-1;
}

static int V136BoxesIntersect(const V136Piece *a,const V136Piece *b)
{
    return a->maxX>=b->minX&&a->minX<=b->maxX&&
        a->maxY>=b->minY&&a->minY<=b->maxY&&
        a->maxZ>=b->minZ&&a->minZ<=b->maxZ;
}

static int V136ChunkIntersect(const V136Piece *p,int cx,int cz)
{
    int x,z;x=cx*16;z=cz*16;
    return p->maxX>=x&&p->minX<=x+15&&p->maxZ>=z&&p->minZ<=z+15;
}

static int V136Add(V136Graph *g,int type,int centerX,int y,int centerZ,
    int direction,int depth,int width,int height,int length,int pool,
    unsigned long seed)
{
    V136Piece *p;int i,half;
    if(g->count>=V136_MAX_PIECES){g->overflow=1;return -1;}
    p=&g->piece[g->count];memset(p,0,sizeof(*p));
    p->type=(short)type;p->depth=(short)depth;p->direction=(short)(direction&3);
    p->pool=(short)pool;p->width=(short)width;p->height=(short)height;
    p->length=(short)length;p->oy=y;p->seed=seed;half=width/2;
    p->ox=centerX-v136RX[p->direction]*half;
    p->oz=centerZ-v136RZ[p->direction]*half;V136Bounds(p);
    if(abs(p->minX-g->rootX)>V136_STRUCTURE_RADIUS||
       abs(p->maxX-g->rootX)>V136_STRUCTURE_RADIUS||
       abs(p->minZ-g->rootZ)>V136_STRUCTURE_RADIUS||
       abs(p->maxZ-g->rootZ)>V136_STRUCTURE_RADIUS)return -1;
    for(i=0;i<g->count;++i)if(V136BoxesIntersect(p,&g->piece[i]))return -1;
    return g->count++;
}

static void V136Connection(const V136Piece *p,int lx,int ly,int lz,
    int *x,int *y,int *z){V136Transform(p,lx,ly,lz,x,y,z);}

static void V136SetWorld(CloneMCJ_World *world,int cx,int cz,int x,int y,int z,
    int id,int meta)
{
    if(!world||y<0||y>=128||V136FloorDiv(x,16)!=cx||V136FloorDiv(z,16)!=cz)
        return;
    CloneMCJ_World_SetBlockWithMetadata(world,x,y,z,id,meta);
}

static void V136SetLocal(CloneMCJ_World *world,int cx,int cz,const V136Piece *p,
    int lx,int ly,int lz,int id,int meta)
{
    int x,y,z;V136Transform(p,lx,ly,lz,&x,&y,&z);
    V136SetWorld(world,cx,cz,x,y,z,id,meta);
}


static void V136FillLocal(CloneMCJ_World *world,int cx,int cz,
    const V136Piece *p,int x1,int y1,int z1,int x2,int y2,int z2,
    int id,int meta)
{
    int x,y,z;
    if(x1>x2){x=x1;x1=x2;x2=x;}if(y1>y2){y=y1;y1=y2;y2=y;}
    if(z1>z2){z=z1;z1=z2;z2=z;}
    for(x=x1;x<=x2;++x)for(y=y1;y<=y2;++y)for(z=z1;z<=z2;++z)
        V136SetLocal(world,cx,cz,p,x,y,z,id,meta);
}

static int V136RotateMeta(const V136Piece *p,int blockID,int meta)
{
    int d;if(!p)return meta;d=p->direction&3;
    /* StructureComponent.getMetadataWithOffset from the supplied Java 1.2.3
     * tree.  Only structure-relevant directional blocks are handled here. */
    if(blockID==66){
        if(d==1||d==3)return meta!=1?1:0;
    }else if(blockID==64||blockID==71){
        if(d==0){if(meta==0)return 2;if(meta==2)return 0;}
        else if(d==1)return (meta+1)&3;
        else if(d==3)return (meta+3)&3;
    }else if(blockID==67||blockID==53||blockID==114||blockID==109){
        if(d==0){if(meta==2)return 3;if(meta==3)return 2;}
        else if(d==1){if(meta==0)return 2;if(meta==1)return 3;
            if(meta==2)return 0;if(meta==3)return 1;}
        else if(d==3){if(meta==0)return 2;if(meta==1)return 3;
            if(meta==2)return 1;if(meta==3)return 0;}
    }else if(blockID==65){
        if(d==0){if(meta==2)return 3;if(meta==3)return 2;}
        else if(d==1){if(meta==2)return 4;if(meta==3)return 5;
            if(meta==4)return 2;if(meta==5)return 3;}
        else if(d==3){if(meta==2)return 5;if(meta==3)return 4;
            if(meta==4)return 2;if(meta==5)return 3;}
    }else if(blockID==77){
        if(d==0){if(meta==3)return 4;if(meta==4)return 3;}
        else if(d==1){if(meta==3)return 1;if(meta==4)return 2;
            if(meta==2)return 3;if(meta==1)return 4;}
        else if(d==3){if(meta==3)return 2;if(meta==4)return 1;
            if(meta==2)return 3;if(meta==1)return 4;}
    }
    return meta;
}

static void V136FillDown(CloneMCJ_World *world,int cx,int cz,
    const V136Piece *p,int lx,int ly,int lz,int id,int meta)
{
    int wx,wy,wz,current;
    V136Transform(p,lx,ly,lz,&wx,&wy,&wz);
    while(wy>1){
        CloneMCJ_Chunk *chunk;
        chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,
            V136FloorDiv(wx,16),V136FloorDiv(wz,16));
        if(!chunk)break;
        current=CloneMCJ_Chunk_GetBlockID(chunk,wx&15,wy,wz&15);
        if(current!=0&&current!=8&&current!=9&&current!=10&&current!=11)break;
        V136SetWorld(world,cx,cz,wx,wy,wz,id,meta);--wy;
    }
}

static void V136ClearUp(CloneMCJ_World *world,int cx,int cz,
    const V136Piece *p,int lx,int ly,int lz)
{
    int wx,wy,wz,current;
    V136Transform(p,lx,ly,lz,&wx,&wy,&wz);
    while(wy<127){
        CloneMCJ_Chunk *chunk;
        chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,
            V136FloorDiv(wx,16),V136FloorDiv(wz,16));
        if(!chunk)break;
        current=CloneMCJ_Chunk_GetBlockID(chunk,wx&15,wy,wz&15);
        if(current==0)break;
        V136SetWorld(world,cx,cz,wx,wy,wz,0,0);++wy;
    }
}

static int V136StrongholdStone(CloneMCJavaRandom *r,int *meta)
{
    float f;if(!r||!meta){if(meta)*meta=0;return 98;}
    f=CloneMCJavaRandom_NextFloat(r);
    if(f<0.2F){*meta=2;return 98;}
    if(f<0.5F){*meta=1;return 98;}
    if(f<0.55F){*meta=2;return 97;}
    *meta=0;return 98;
}

static void V136StrongholdRandomFill(CloneMCJ_World *world,int cx,int cz,
    const V136Piece *p,CloneMCJavaRandom *r,int x1,int y1,int z1,
    int x2,int y2,int z2,int boundaryOnly)
{
    int x,y,z,edge,id,meta;
    for(x=x1;x<=x2;++x)for(y=y1;y<=y2;++y)for(z=z1;z<=z2;++z){
        edge=x==x1||x==x2||y==y1||y==y2||z==z1||z==z2;
        if(boundaryOnly&&!edge){V136SetLocal(world,cx,cz,p,x,y,z,0,0);continue;}
        id=V136StrongholdStone(r,&meta);
        V136SetLocal(world,cx,cz,p,x,y,z,id,meta);
    }
}

static void V136StrongholdDoor(CloneMCJ_World *world,int cx,int cz,
    const V136Piece *p,int door,int x,int y,int z)
{
    int meta;
    if(door==0){V136FillLocal(world,cx,cz,p,x,y,z,x+2,y+2,z,0,0);return;}
    if(door==1){
        V136SetLocal(world,cx,cz,p,x,y,z,98,0);V136SetLocal(world,cx,cz,p,x,y+1,z,98,0);
        V136SetLocal(world,cx,cz,p,x,y+2,z,98,0);V136SetLocal(world,cx,cz,p,x+1,y+2,z,98,0);
        V136SetLocal(world,cx,cz,p,x+2,y+2,z,98,0);V136SetLocal(world,cx,cz,p,x+2,y+1,z,98,0);
        V136SetLocal(world,cx,cz,p,x+2,y,z,98,0);
        meta=V136RotateMeta(p,64,0);V136SetLocal(world,cx,cz,p,x+1,y,z,64,meta);
        V136SetLocal(world,cx,cz,p,x+1,y+1,z,64,meta|8);return;
    }
    if(door==2){
        V136SetLocal(world,cx,cz,p,x+1,y,z,0,0);V136SetLocal(world,cx,cz,p,x+1,y+1,z,0,0);
        V136SetLocal(world,cx,cz,p,x,y,z,101,0);V136SetLocal(world,cx,cz,p,x,y+1,z,101,0);
        V136SetLocal(world,cx,cz,p,x,y+2,z,101,0);V136SetLocal(world,cx,cz,p,x+1,y+2,z,101,0);
        V136SetLocal(world,cx,cz,p,x+2,y+2,z,101,0);V136SetLocal(world,cx,cz,p,x+2,y+1,z,101,0);
        V136SetLocal(world,cx,cz,p,x+2,y,z,101,0);return;
    }
    /* IRON_DOOR */
    V136SetLocal(world,cx,cz,p,x,y,z,98,0);V136SetLocal(world,cx,cz,p,x,y+1,z,98,0);
    V136SetLocal(world,cx,cz,p,x,y+2,z,98,0);V136SetLocal(world,cx,cz,p,x+1,y+2,z,98,0);
    V136SetLocal(world,cx,cz,p,x+2,y+2,z,98,0);V136SetLocal(world,cx,cz,p,x+2,y+1,z,98,0);
    V136SetLocal(world,cx,cz,p,x+2,y,z,98,0);
    meta=V136RotateMeta(p,71,0);V136SetLocal(world,cx,cz,p,x+1,y,z,71,meta);
    V136SetLocal(world,cx,cz,p,x+1,y+1,z,71,meta|8);
    V136SetLocal(world,cx,cz,p,x+2,y+1,z+1,77,V136RotateMeta(p,77,4));
    V136SetLocal(world,cx,cz,p,x+2,y+1,z-1,77,V136RotateMeta(p,77,3));
}

static int V136SetSpawner(CloneMCJ_World *world,int cx,int cz,int x,int y,int z,
    const char *mobID)
{
    CloneMCJ_Chunk *chunk;
    CloneMCJ_TileEntity *tile;
    if(!world||!mobID||y<0||y>=128||V136FloorDiv(x,16)!=cx||
       V136FloorDiv(z,16)!=cz)return 0;
    CloneMCJ_World_SetBlockWithMetadata(world,x,y,z,52,0);
    chunk=CloneMCJ_World_GetChunkFromBlockCoords(world,x,z);
    if(!chunk)return 0;
    tile=(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(chunk,x&15,y,z&15);
    if(tile&&tile->type!=CLONEMC_J_TILE_MOB_SPAWNER){
        CloneMCJ_Chunk_RemoveTileEntity(chunk,x&15,y,z&15);
        CloneMCJ_TileEntity_Destroy(tile);tile=(CloneMCJ_TileEntity *)0;
    }
    if(!tile){
        tile=CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_MOB_SPAWNER,
            world,x,y,z);
        if(!tile)return 0;
        if(!CloneMCJ_Chunk_SetTileEntity(chunk,x&15,y,z&15,tile)){
            CloneMCJ_TileEntity_Destroy(tile);return 0;
        }
    }
    strncpy(tile->mobID,mobID,sizeof(tile->mobID)-1U);
    tile->mobID[sizeof(tile->mobID)-1U]='\0';tile->spawnDelay=20;
    CloneMCJ_Chunk_SetModified(chunk);return 1;
}

typedef struct V136LootTag {
    short item,metadata,minimum,maximum,weight;
} V136Loot;

static void V136ChestLoot(CloneMCJ_World *world,int cx,int cz,
    const V136Piece *piece,int lx,int ly,int lz,const V136Loot *table,
    int entries,int minimumRolls,int extraRolls,unsigned long salt)
{
    CloneMCJ_Chunk *chunk;CloneMCJ_TileEntity *chest;
    CloneMCJ_ItemStack stack;CloneMCJavaRandom random;
    int x,y,z,localX,localZ,i,j,total,roll,count,slot;
    if(!world||!piece||!table||entries<=0)return;
    V136Transform(piece,lx,ly,lz,&x,&y,&z);
    if(V136FloorDiv(x,16)!=cx||V136FloorDiv(z,16)!=cz)return;
    V136SetWorld(world,cx,cz,x,y,z,54,0);
    chunk=CloneMCJ_World_GetChunkFromBlockCoords(world,x,z);
    if(!chunk)return;localX=x&15;localZ=z&15;
    chest=(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(
        chunk,localX,y,localZ);
    if(chest&&chest->type==CLONEMC_J_TILE_CHEST)return;
    chest=CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_CHEST,world,x,y,z);
    if(!chest)return;
    if(!CloneMCJ_Chunk_SetTileEntity(chunk,localX,y,localZ,chest)){
        CloneMCJ_TileEntity_Destroy(chest);return;
    }
    CloneMCJavaRandom_SetSeed(&random,(CloneMCJLong)(
        piece->seed^salt^(unsigned long)x*31UL^(unsigned long)z*131UL));
    count=minimumRolls;
    if(extraRolls>0)count+=CloneMCJavaRandom_NextIntBound(
        &random,extraRolls+1);
    total=0;for(i=0;i<entries;++i)total+=table[i].weight;
    for(i=0;i<count&&total>0;++i){
        roll=CloneMCJavaRandom_NextIntBound(&random,total);
        for(j=0;j<entries;++j){roll-=table[j].weight;if(roll<0)break;}
        if(j>=entries)j=entries-1;
        roll=table[j].minimum;
        if(table[j].maximum>table[j].minimum)
            roll+=CloneMCJavaRandom_NextIntBound(&random,
                table[j].maximum-table[j].minimum+1);
        CloneMCJ_ItemStack_Initialize(&stack,table[j].item,roll,
            table[j].metadata);
        slot=CloneMCJavaRandom_NextIntBound(&random,chest->itemCount);
        CloneMCJ_TileEntity_SetStack(chest,slot,&stack);
    }
    chunk->isModified=1;
}

static const V136Loot v136StrongholdCorridorLoot[]={
    {368,0,1,1,10},{264,0,1,3,3},{265,0,1,5,10},
    {266,0,1,3,5},{331,0,4,9,5},{297,0,1,3,15},
    {260,0,1,3,15},{257,0,1,1,5},{267,0,1,1,5},
    {307,0,1,1,5},{306,0,1,1,5},{308,0,1,1,5},
    {309,0,1,1,5},{322,0,1,1,1}
};
static const V136Loot v136StrongholdLibraryLoot[]={
    {340,0,1,3,20},{339,0,2,7,20},{358,0,1,1,1},
    {345,0,1,1,1}
};
static const V136Loot v136StrongholdRoomLoot[]={
    {265,0,1,5,10},{266,0,1,3,5},{331,0,4,9,5},
    {263,0,3,8,10},{297,0,1,3,15},{260,0,1,3,15},
    {257,0,1,1,1}
};
static const V136Loot v136VillageSmithLoot[]={
    {264,0,1,3,3},{265,0,1,5,10},{266,0,1,3,5},
    {297,0,1,3,15},{260,0,1,3,15},{257,0,1,1,5},
    {267,0,1,1,5},{307,0,1,1,5},{306,0,1,1,5},
    {308,0,1,1,5},{309,0,1,1,5},{49,0,3,7,5},
    {6,0,3,7,5}
};

/* ---------------------------- Strongholds ---------------------------- */
enum {
    SH_START=0,SH_STRAIGHT,SH_PRISON,SH_LEFT,SH_RIGHT,SH_ROOM,
    SH_STAIRS_STRAIGHT,SH_STAIRS,SH_CROSSING,SH_CHEST,SH_LIBRARY,
    SH_PORTAL,SH_CORRIDOR
};

static void SHSize(int type,CloneMCJavaRandom *r,int *w,int *h,int *l)
{
    static const unsigned char s[13][3]={
        {5,11,5},{5,5,7},{9,5,11},{5,5,5},{5,5,5},{11,7,11},
        {5,11,8},{5,11,5},{10,9,11},{5,5,7},{14,11,15},
        {11,8,16},{5,5,4}};
    *w=s[type][0];*h=s[type][1];*l=s[type][2];
    if(type==SH_LIBRARY&&CloneMCJavaRandom_NextIntBound(r,3)==0)*h=6;
}

static int SHSelect(V136Graph *g,CloneMCJavaRandom *r,int depth,int used[13])
{
    static const int weight[12]={0,40,5,20,20,10,5,5,5,5,10,20};
    static const int limit[12]={0,0,5,0,0,6,5,5,4,4,2,1};
    int total,roll,type;
    total=0;
    for(type=1;type<=SH_PORTAL;++type){
        if(limit[type]&&used[type]>=limit[type])continue;
        if(type==SH_LIBRARY&&depth<=4)continue;
        if(type==SH_PORTAL&&(depth<=5||g->portal))continue;
        total+=weight[type];
    }
    if(total<=0)return SH_CORRIDOR;
    roll=CloneMCJavaRandom_NextIntBound(r,total);
    for(type=1;type<=SH_PORTAL;++type){
        if(limit[type]&&used[type]>=limit[type])continue;
        if(type==SH_LIBRARY&&depth<=4)continue;
        if(type==SH_PORTAL&&(depth<=5||g->portal))continue;
        roll-=weight[type];if(roll<0)return type;
    }
    return SH_CORRIDOR;
}

static int SHAppend(V136Graph *g,CloneMCJavaRandom *r,const V136Piece *from,
    int lx,int ly,int lz,int direction,int used[13])
{
    int x,y,z,type,w,h,l,added,attempt;
    V136Connection(from,lx,ly,lz,&x,&y,&z);
    for(attempt=0;attempt<5;++attempt){
        type=SHSelect(g,r,from->depth+1,used);SHSize(type,r,&w,&h,&l);
        added=V136Add(g,type,x,y,z,direction,from->depth+1,w,h,l,0,
            (unsigned long)CloneMCJavaRandom_NextInt(r));
        if(added>=0){++used[type];if(type==SH_PORTAL)g->portal=1;return added;}
    }
    SHSize(SH_CORRIDOR,r,&w,&h,&l);
    return V136Add(g,SH_CORRIDOR,x,y,z,direction,from->depth+1,w,h,l,0,
        (unsigned long)CloneMCJavaRandom_NextInt(r));
}

static void SHBuildOnce(CloneMCJLong seed,int startX,int startZ,
    unsigned long retry,V136Graph *g)
{
    CloneMCJavaRandom r;V136Piece p;int used[13],i,d,w,h,l,x,y,z;
    memset(g,0,sizeof(*g));memset(used,0,sizeof(used));
    g->rootX=startX*16+2;g->rootZ=startZ*16+2;
    CloneMCJavaRandom_SetSeed(&r,seed+(CloneMCJLong)startX*341873128712LL+
        (CloneMCJLong)startZ*132897987541LL+
        (CloneMCJLong)retry*42317861LL);
    d=CloneMCJavaRandom_NextIntBound(&r,4);SHSize(SH_START,&r,&w,&h,&l);
    V136Add(g,SH_START,g->rootX,30,g->rootZ,d,0,w,h,l,0,
        (unsigned long)CloneMCJavaRandom_NextInt(&r));used[SH_START]=1;
    for(i=0;i<g->count&&i<V136_MAX_PIECES;++i){
        p=g->piece[i];
        if(p.depth>=18||p.type==SH_PORTAL||p.type==SH_LIBRARY||
           p.type==SH_CORRIDOR)continue;
        if(p.type==SH_LEFT||p.type==SH_RIGHT){
            d=(p.direction+(p.type==SH_LEFT?3:1))&3;
            SHAppend(g,&r,&p,p.type==SH_LEFT?-1:p.width,1,p.length/2,d,used);
            continue;
        }
        SHAppend(g,&r,&p,p.width/2,1,p.length,p.direction,used);
        if(p.type==SH_START||p.type==SH_ROOM||p.type==SH_CROSSING||
           (p.type==SH_STRAIGHT&&CloneMCJavaRandom_NextIntBound(&r,2)==0))
            SHAppend(g,&r,&p,-1,1,p.length/2,(p.direction+3)&3,used);
        if(p.type==SH_START||p.type==SH_ROOM||p.type==SH_CROSSING||
           (p.type==SH_STRAIGHT&&CloneMCJavaRandom_NextIntBound(&r,2)==0))
            SHAppend(g,&r,&p,p.width,1,p.length/2,(p.direction+1)&3,used);
    }
    if(!g->portal&&g->count<V136_MAX_PIECES){
        p=g->piece[g->count-1];V136Connection(&p,p.width/2,1,p.length,&x,&y,&z);
        SHSize(SH_PORTAL,&r,&w,&h,&l);
        if(V136Add(g,SH_PORTAL,x,y,z,p.direction,p.depth+1,w,h,l,0,
            (unsigned long)CloneMCJavaRandom_NextInt(&r))>=0)g->portal=1;
    }
}

static void SHBuild(CloneMCJLong seed,int startX,int startZ,V136Graph *g)
{
    V136Graph trial;
    unsigned long retry;
    if(!g)return;
    memset(g,0,sizeof(*g));
    /* MapGenStronghold repeatedly constructs a start until it owns a portal
     * room.  Bound that Java loop for old systems and advance a deterministic
     * salt for each complete reconstruction; truncated graphs are rejected. */
    for(retry=0UL;retry<V136_STRONGHOLD_RETRY_LIMIT;++retry){
        SHBuildOnce(seed,startX,startZ,retry,&trial);
        *g=trial;
        if(g->portal&&!g->overflow)return;
    }
}

static void SHShell(CloneMCJ_World *world,int cx,int cz,const V136Piece *p)
{
    int x,y,z,edge,meta;
    for(x=0;x<p->width;++x)for(y=0;y<p->height;++y)
        for(z=0;z<p->length;++z){
            edge=x==0||x==p->width-1||y==0||y==p->height-1||
                z==0||z==p->length-1;
            meta=0;if(edge){unsigned long v;v=V136Hash(x,y,z,p->seed);
                meta=v%20UL==0?2:(v%12UL==0?1:0);}
            V136SetLocal(world,cx,cz,p,x,y,z,edge?98:0,meta);
        }
    for(y=1;y<=3&&y<p->height-1;++y){
        V136SetLocal(world,cx,cz,p,p->width/2,y,0,0,0);
        V136SetLocal(world,cx,cz,p,p->width/2,y,p->length-1,0,0);
    }
}

static void SHRender(CloneMCJ_World *world,int cx,int cz,const V136Piece *p)
{
    int x,y,z,meta;SHShell(world,cx,cz,p);
    if(p->type==SH_PRISON){
        for(z=2;z<p->length-2;z+=3)for(y=1;y<=3;++y){
            V136SetLocal(world,cx,cz,p,3,y,z,101,0);
            V136SetLocal(world,cx,cz,p,6,y,z,101,0);}
    }else if(p->type==SH_STAIRS||p->type==SH_STAIRS_STRAIGHT){
        for(z=1;z<p->length-1;++z){y=1+z*(p->height-3)/(p->length-2);
            V136SetLocal(world,cx,cz,p,p->width/2,y,z,109,3);}
    }else if(p->type==SH_ROOM||p->type==SH_CROSSING){
        for(x=2;x<p->width-2;++x)for(z=2;z<p->length-2;++z)
            if(x==p->width/2||z==p->length/2)
                V136SetLocal(world,cx,cz,p,x,1,z,44,5);
        V136SetLocal(world,cx,cz,p,p->width/2,3,p->length/2,50,0);
        if(p->height>5&&(V136Hash(3,4,8,p->seed)%5UL)==2UL)
            V136ChestLoot(world,cx,cz,p,3,4,8,v136StrongholdRoomLoot,
                sizeof(v136StrongholdRoomLoot)/sizeof(v136StrongholdRoomLoot[0]),
                1,3,0x35061CUL);
    }else if(p->type==SH_CHEST){
        V136ChestLoot(world,cx,cz,p,3,1,3,v136StrongholdCorridorLoot,
            sizeof(v136StrongholdCorridorLoot)/
                sizeof(v136StrongholdCorridorLoot[0]),2,1,0x40013AUL);
    }else if(p->type==SH_LIBRARY){
        for(z=1;z<p->length-1;++z)if((z&3)!=0)
            for(y=1;y<p->height-2&&y<=4;++y){
                V136SetLocal(world,cx,cz,p,1,y,z,47,0);
                V136SetLocal(world,cx,cz,p,p->width-2,y,z,47,0);}
        for(z=3;z<p->length-2;z+=4)for(x=3;x<p->width-3;x+=3)
            V136SetLocal(world,cx,cz,p,x,1,z,47,0);
        V136ChestLoot(world,cx,cz,p,3,1,5,v136StrongholdLibraryLoot,
            sizeof(v136StrongholdLibraryLoot)/
                sizeof(v136StrongholdLibraryLoot[0]),1,3,0x35056BUL);
        if(p->height>6)
            V136ChestLoot(world,cx,cz,p,p->width-2,p->height-3,1,
                v136StrongholdLibraryLoot,
                sizeof(v136StrongholdLibraryLoot)/
                    sizeof(v136StrongholdLibraryLoot[0]),
                1,3,0x35056CUL);
        if(p->height>6)for(y=1;y<p->height-1;++y)
            V136SetLocal(world,cx,cz,p,p->width-4,y,p->length-2,65,3);
    }else if(p->type==SH_PORTAL){
        for(x=4;x<=6;++x){
            V136SetLocal(world,cx,cz,p,x,1,5,109,3);
            V136SetLocal(world,cx,cz,p,x,2,6,109,3);
            V136SetLocal(world,cx,cz,p,x,3,7,109,3);
            meta=V136Hash(x,3,8,p->seed)%10UL==0;
            V136SetLocal(world,cx,cz,p,x,3,8,120,meta?4:0);
            meta=V136Hash(x,3,12,p->seed)%10UL==0;
            V136SetLocal(world,cx,cz,p,x,3,12,120,2|(meta?4:0));
        }
        for(z=9;z<=11;++z){
            meta=V136Hash(3,3,z,p->seed)%10UL==0;
            V136SetLocal(world,cx,cz,p,3,3,z,120,3|(meta?4:0));
            meta=V136Hash(7,3,z,p->seed)%10UL==0;
            V136SetLocal(world,cx,cz,p,7,3,z,120,1|(meta?4:0));
        }
        for(x=4;x<=6;++x)for(z=9;z<=11;++z)
            V136SetLocal(world,cx,cz,p,x,2,z,10,0);
        V136Transform(p,5,3,6,&x,&y,&z);
        V136SetSpawner(world,cx,cz,x,y,z,"Silverfish");
    }
}

/* ------------------------------ Villages ----------------------------- */
enum {
    VG_WELL=0,VG_ROAD,VG_GARDEN,VG_CHURCH,VG_HOUSE1,VG_HUT,VG_HALL,
    VG_FIELD,VG_FIELD2,VG_HOUSE2,VG_HOUSE3,VG_TORCH
};

static void VGSize(int type,CloneMCJavaRandom *r,int *w,int *h,int *l)
{
    static const unsigned char s[12][3]={
        {6,15,6},{3,3,15},{5,6,5},{5,12,9},{9,9,6},{4,6,5},
        {9,7,11},{13,4,9},{7,4,9},{10,6,7},{9,7,12},{3,4,2}};
    *w=s[type][0];*h=s[type][1];*l=s[type][2];
    if(type==VG_ROAD)*l=7+CloneMCJavaRandom_NextIntBound(r,8)*2;
}

static int VGAdd(V136Graph *g,CloneMCJavaRandom *r,int type,int x,int z,
    int d,int depth,int used[12])
{
    int w,h,l,a;VGSize(type,r,&w,&h,&l);
    a=V136Add(g,type,x,64,z,d,depth,w,h,l,type==VG_ROAD,
        (unsigned long)CloneMCJavaRandom_NextInt(r));
    if(a>=0)++used[type];return a;
}

static int VGSelect(CloneMCJavaRandom *r,int used[12],int size)
{
    static const int wt[12]={0,0,4,20,20,3,15,3,3,15,8,0};
    int lim[12],total,type,roll;
    memset(lim,0,sizeof(lim));lim[VG_GARDEN]=4+size*2;
    lim[VG_CHURCH]=1+size;lim[VG_HOUSE1]=2+size;lim[VG_HUT]=5+size*3;
    lim[VG_HALL]=2+size;lim[VG_FIELD]=4+size;lim[VG_FIELD2]=4+size*2;
    lim[VG_HOUSE2]=1+size;lim[VG_HOUSE3]=3+size*2;total=0;
    for(type=VG_GARDEN;type<=VG_HOUSE3;++type)
        if(used[type]<lim[type])total+=wt[type];
    if(!total)return VG_TORCH;roll=CloneMCJavaRandom_NextIntBound(r,total);
    for(type=VG_GARDEN;type<=VG_HOUSE3;++type){
        if(used[type]>=lim[type])continue;roll-=wt[type];if(roll<0)return type;}
    return VG_TORCH;
}

static void VGBuild(CloneMCJLong seed,int startX,int startZ,V136Graph *g)
{
    CloneMCJavaRandom r;V136Piece road;int used[12],size,d,i,side,off,x,y,z,type;
    memset(g,0,sizeof(*g));memset(used,0,sizeof(used));
    g->rootX=startX*16+2;g->rootZ=startZ*16+2;
    CloneMCJavaRandom_SetSeed(&r,seed+(CloneMCJLong)startX*341873128712LL+
        (CloneMCJLong)startZ*132897987541LL+0x9E7F70L);
    size=CloneMCJavaRandom_NextIntBound(&r,2);
    d=CloneMCJavaRandom_NextIntBound(&r,4);
    VGAdd(g,&r,VG_WELL,g->rootX,g->rootZ,d,0,used);
    for(side=0;side<4;++side)
        VGAdd(g,&r,VG_ROAD,g->rootX+v136FX[side]*4,
            g->rootZ+v136FZ[side]*4,side,0,used);
    for(i=1;i<g->count&&i<V136_MAX_PIECES;++i){
        road=g->piece[i];if(road.type!=VG_ROAD||road.depth>4)continue;
        for(off=2;off<road.length-2;off+=3+CloneMCJavaRandom_NextIntBound(&r,4))
            for(side=-1;side<=1;side+=2){
                type=VGSelect(&r,used,size);
                V136Connection(&road,side<0?-3:road.width+3,0,off,&x,&y,&z);
                VGAdd(g,&r,type,x,z,(road.direction+(side<0?1:3))&3,
                    road.depth+1,used);
            }
        if(road.depth<4){
            V136Connection(&road,road.width/2,0,road.length,&x,&y,&z);
            VGAdd(g,&r,VG_ROAD,x,z,road.direction,road.depth+1,used);
            if(CloneMCJavaRandom_NextIntBound(&r,3)>0){
                side=CloneMCJavaRandom_NextIntBound(&r,2)?1:-1;
                V136Connection(&road,side<0?-1:road.width,0,road.length-2,
                    &x,&y,&z);
                VGAdd(g,&r,VG_ROAD,x,z,(road.direction+(side<0?3:1))&3,
                    road.depth+1,used);
            }
        }
    }
}

static int VGIsSizeable(const V136Graph *g)
{
    int count,i;
    if(!g||g->overflow)return 0;
    count=0;
    for(i=0;i<g->count;++i)if(!g->piece[i].pool)++count;
    /* StructureVillageStart.isSizeableStructure counts non-road pieces. */
    return count>2;
}

static int VGGround(CloneMCJ_World *world,const V136Piece *p)
{
    int x,y,z;V136Transform(p,p->width/2,0,p->length/2,&x,&y,&z);
    y=CloneMCJ_World_FindTopSolidBlock(world,x,z);return y<4||y>119?64:y;
}

static void VGBox(CloneMCJ_World *world,int cx,int cz,const V136Piece *source,
    int ground,int wall,int roof)
{
    V136Piece p;int x,y,z,edge,wx,wy,wz;
    p=*source;p.oy=ground;V136Bounds(&p);
    for(x=0;x<p.width;++x)for(y=0;y<p.height;++y)for(z=0;z<p.length;++z){
        edge=y==0||y==p.height-1||x==0||x==p.width-1||
            z==0||z==p.length-1;
        V136SetLocal(world,cx,cz,&p,x,y,z,edge?(y==p.height-1?roof:wall):0,0);
    }
    V136SetLocal(world,cx,cz,&p,p.width/2,1,0,64,1);
    V136SetLocal(world,cx,cz,&p,p.width/2,2,0,64,9);
    V136Transform(&p,p.width/2,1,0,&wx,&wy,&wz);
    if(V136FloorDiv(wx,16)==cx&&V136FloorDiv(wz,16)==cz)
        CloneMCJ_V136_RegisterVillageDoor(world,wx,wy,wz,p.direction);
    V136SetLocal(world,cx,cz,&p,0,2,p.length/2,20,0);
    V136SetLocal(world,cx,cz,&p,p.width-1,2,p.length/2,20,0);
    V136SetLocal(world,cx,cz,&p,p.width/2,3,p.length-2,50,3);
}

static void VGRender(CloneMCJ_World *world,int cx,int cz,const V136Piece *source,
    int desert,int ground)
{
    V136Piece p;int x,y,z,wx,wz,wall,roof;
    p=*source;p.oy=ground;V136Bounds(&p);
    wall=desert?24:5;roof=desert?24:53;
    if(p.type==VG_ROAD){
        for(x=0;x<p.width;++x)for(z=0;z<p.length;++z){
            V136Transform(&p,x,0,z,&wx,&y,&wz);
            y=CloneMCJ_World_FindTopSolidBlock(world,wx,wz);
            if(y>0&&y<127)V136SetWorld(world,cx,cz,wx,y-1,wz,13,0);}
        return;
    }
    if(p.type==VG_WELL){
        for(x=0;x<6;++x)for(z=0;z<6;++z){
            V136SetLocal(world,cx,cz,&p,x,0,z,4,0);
            V136SetLocal(world,cx,cz,&p,x,1,z,
                x==0||x==5||z==0||z==5?4:9,0);}
        for(y=2;y<=4;++y)for(x=0;x<=5;x+=5)for(z=0;z<=5;z+=5)
            V136SetLocal(world,cx,cz,&p,x,y,z,85,0);
        for(x=0;x<6;++x)for(z=0;z<6;++z)
            V136SetLocal(world,cx,cz,&p,x,5,z,44,0);
        return;
    }
    if(p.type==VG_FIELD||p.type==VG_FIELD2){
        for(x=0;x<p.width;++x)for(z=0;z<p.length;++z){
            V136SetLocal(world,cx,cz,&p,x,0,z,x==p.width/2?9:60,7);
            if(x!=p.width/2)V136SetLocal(world,cx,cz,&p,x,1,z,
                59,(int)(V136Hash(x,1,z,p.seed)&7UL));}
        return;
    }
    if(p.type==VG_TORCH){
        V136SetLocal(world,cx,cz,&p,1,0,1,85,0);
        V136SetLocal(world,cx,cz,&p,1,1,1,85,0);
        V136SetLocal(world,cx,cz,&p,1,2,1,50,5);return;
    }
    if(p.type==VG_CHURCH){
        VGBox(world,cx,cz,&p,ground,desert?24:4,desert?24:4);
        for(y=4;y<p.height-1;++y)
            V136SetLocal(world,cx,cz,&p,p.width/2,y,p.length-2,65,3);
        return;
    }
    VGBox(world,cx,cz,&p,ground,wall,roof);
    if(p.type==VG_HALL||p.type==VG_HOUSE2){
        V136ChestLoot(world,cx,cz,&p,p.width/2,1,p.length/2,
            v136VillageSmithLoot,
            sizeof(v136VillageSmithLoot)/sizeof(v136VillageSmithLoot[0]),
            3,5,0x46002AUL);
        V136SetLocal(world,cx,cz,&p,2,1,p.length/2,61,2);
    }else if(p.type==VG_GARDEN){
        V136SetLocal(world,cx,cz,&p,1,1,p.length-2,60,7);
        V136SetLocal(world,cx,cz,&p,1,2,p.length-2,59,7);
    }
}

static int VGResidentInfo(int type,int *localX,int *localZ,int *count)
{
    if(!localX||!localZ||!count)return 0;
    *count=1;
    switch(type){
    case VG_GARDEN:*localX=1;*localZ=2;return 1;
    case VG_CHURCH:*localX=2;*localZ=2;return 1;
    case VG_HOUSE1:*localX=2;*localZ=2;return 1;
    case VG_HUT:*localX=1;*localZ=2;return 1;
    case VG_HALL:*localX=4;*localZ=2;*count=2;return 1;
    case VG_HOUSE2:*localX=7;*localZ=1;return 1;
    case VG_HOUSE3:*localX=4;*localZ=2;*count=2;return 1;
    default:return 0;
    }
}

static int VGResidentProfession(int type,int resident)
{
    if(type==VG_CHURCH)return 2;
    if(type==VG_HOUSE1)return 1;
    if(type==VG_HOUSE2)return 3;
    if(type==VG_HALL&&resident==0)return 4;
    return 0;
}

static int VGCandidate(CloneMCJLong seed,int rx,int rz,
    CloneMCJ_WorldChunkManager *manager,int *cx,int *cz)
{
    CloneMCJavaRandom r;const CloneMCJ_BiomeGenBase *b;int x,z;
    CloneMCJavaRandom_SetSeed(&r,(CloneMCJLong)rx*
        ((((CloneMCJLong)0x4F9939F5L)<<8)|8L)+(CloneMCJLong)rz*
        ((((CloneMCJLong)0x1EF1565BL)<<8)|0xD5L)+seed+0x9E7F70L);
    x=rx*32+CloneMCJavaRandom_NextIntBound(&r,24);
    z=rz*32+CloneMCJavaRandom_NextIntBound(&r,24);
    b=manager?CloneMCJ_WorldChunkManager_GetBiomeGenAt(manager,x*16+8,z*16+8):0;
    if(!b||(b->biomeID!=CLONEMC_J_BIOME_PLAINS&&
           b->biomeID!=CLONEMC_J_BIOME_DESERT))return 0;
    *cx=x;*cz=z;return 1;
}

/* -------------------------- Nether fortresses ------------------------ */
enum {
    NB_START=0,NB_STRAIGHT,NB_CROSSING3,NB_CROSSING,NB_STAIRS,NB_THRONE,
    NB_ENTRANCE,NB_CORRIDOR5,NB_CROSSING2,NB_CORRIDOR2,NB_CORRIDOR,
    NB_CORRIDOR3,NB_CORRIDOR4,NB_STALK,NB_END
};

static void NBSize(int type,int *w,int *h,int *l)
{
    static const unsigned char s[15][3]={
        {19,10,19},{5,10,19},{19,10,19},{7,9,7},{7,11,7},{7,8,9},
        {13,14,13},{5,7,5},{5,7,5},{5,7,5},{5,7,5},{5,14,10},
        {9,7,9},{13,14,13},{5,10,8}};
    *w=s[type][0];*h=s[type][1];*l=s[type][2];
}

static int NBSelect(CloneMCJavaRandom *r,int secondary,int used[15])
{
    static const int pt[6]={NB_STRAIGHT,NB_CROSSING3,NB_CROSSING,NB_STAIRS,
        NB_THRONE,NB_ENTRANCE},pw[6]={30,10,10,10,5,5},pl[6]={0,4,4,3,2,1};
    static const int st[7]={NB_CORRIDOR5,NB_CROSSING2,NB_CORRIDOR2,NB_CORRIDOR,
        NB_CORRIDOR3,NB_CORRIDOR4,NB_STALK},sw[7]={25,15,5,5,10,7,5},
        sl[7]={0,5,10,10,3,2,2};
    int i,n,type,limit,total,roll;n=secondary?7:6;total=0;
    for(i=0;i<n;++i){type=secondary?st[i]:pt[i];limit=secondary?sl[i]:pl[i];
        if(!limit||used[type]<limit)total+=secondary?sw[i]:pw[i];}
    if(!total)return NB_END;roll=CloneMCJavaRandom_NextIntBound(r,total);
    for(i=0;i<n;++i){type=secondary?st[i]:pt[i];limit=secondary?sl[i]:pl[i];
        if(limit&&used[type]>=limit)continue;roll-=secondary?sw[i]:pw[i];
        if(roll<0)return type;}return NB_END;
}

static int NBAppend(V136Graph *g,CloneMCJavaRandom *r,const V136Piece *from,
    int lx,int ly,int lz,int d,int secondary,int used[15])
{
    int x,y,z,type,w,h,l,a,attempt;V136Connection(from,lx,ly,lz,&x,&y,&z);
    for(attempt=0;attempt<5;++attempt){
        type=from->depth>30?NB_END:NBSelect(r,secondary,used);NBSize(type,&w,&h,&l);
        a=V136Add(g,type,x,y,z,d,from->depth+1,w,h,l,secondary,
            (unsigned long)CloneMCJavaRandom_NextInt(r));
        if(a>=0){++used[type];return a;}
    }
    NBSize(NB_END,&w,&h,&l);return V136Add(g,NB_END,x,y,z,d,from->depth+1,
        w,h,l,secondary,(unsigned long)CloneMCJavaRandom_NextInt(r));
}

static void NBBuild(CloneMCJLong seed,int startX,int startZ,V136Graph *g)
{
    CloneMCJavaRandom r;V136Piece p;
    int used[15],i,d,branch,minY,maxY,height,range,targetY,offset;
    memset(g,0,sizeof(*g));memset(used,0,sizeof(used));
    g->rootX=startX*16+8;g->rootZ=startZ*16+8;
    CloneMCJavaRandom_SetSeed(&r,seed+(CloneMCJLong)startX*341873128712LL+
        (CloneMCJLong)startZ*132897987541LL);
    d=CloneMCJavaRandom_NextIntBound(&r,4);
    V136Add(g,NB_START,g->rootX,64,g->rootZ,d,0,19,10,19,0,
        (unsigned long)CloneMCJavaRandom_NextInt(&r));used[NB_START]=1;
    for(i=0;i<g->count&&i<V136_MAX_PIECES;++i){
        p=g->piece[i];if(p.depth>=30||p.type==NB_END||p.type==NB_THRONE)continue;
        NBAppend(g,&r,&p,p.width/2,p.type==NB_CORRIDOR3?7:0,p.length,
            p.direction,p.pool||p.type==NB_ENTRANCE||p.type==NB_STALK,used);
        branch=p.type==NB_START||p.type==NB_CROSSING3||p.type==NB_CROSSING||
            p.type==NB_CROSSING2||p.type==NB_CORRIDOR4;
        if(branch){
            NBAppend(g,&r,&p,-1,0,p.length/2,(p.direction+3)&3,p.pool,used);
            NBAppend(g,&r,&p,p.width,0,p.length/2,(p.direction+1)&3,p.pool,used);
        }
    }
    /* StructureStart.setRandomHeight(world,random,48,70): move the complete
     * graph as one unit so stairs/corridors keep their relative elevations. */
    if(g->count>0){
        minY=g->piece[0].minY;maxY=g->piece[0].maxY;
        for(i=1;i<g->count;++i){
            if(g->piece[i].minY<minY)minY=g->piece[i].minY;
            if(g->piece[i].maxY>maxY)maxY=g->piece[i].maxY;
        }
        height=maxY-minY+1;range=(70-48+1)-height;
        targetY=range>1?48+CloneMCJavaRandom_NextIntBound(&r,range):48;
        offset=targetY-minY;
        for(i=0;i<g->count;++i){
            g->piece[i].oy+=offset;V136Bounds(&g->piece[i]);
        }
    }
}

/*
 * Fortress containment is queried repeatedly by SpawnerAnimals.  Rebuilding
 * a 160-piece recursive graph for every Blaze/Pig-Zombie candidate dominated
 * the old Win98 tick budget.  Four fixed resident entries cover the regions
 * around a player without heap allocation or unbounded retention.
 */
typedef struct V136FortressCacheTag {
    CloneMCJLong seed;
    int startX,startZ;
    unsigned long stamp;
    unsigned char valid;
    V136Graph graph;
} V136FortressCache;

static V136FortressCache v136FortressCache[4];
static unsigned long v136FortressCacheStamp;

static const V136Graph *V136CachedFortress(CloneMCJLong seed,
    int startX,int startZ)
{
    int i,replace;unsigned long oldest;
    ++v136FortressCacheStamp;if(v136FortressCacheStamp==0)
        v136FortressCacheStamp=1;
    replace=0;oldest=0xffffffffUL;
    for(i=0;i<4;++i){
        if(v136FortressCache[i].valid&&
           v136FortressCache[i].seed==seed&&
           v136FortressCache[i].startX==startX&&
           v136FortressCache[i].startZ==startZ){
            v136FortressCache[i].stamp=v136FortressCacheStamp;
            return &v136FortressCache[i].graph;
        }
        if(!v136FortressCache[i].valid){replace=i;oldest=0;break;}
        if(v136FortressCache[i].stamp<oldest){
            oldest=v136FortressCache[i].stamp;replace=i;
        }
    }
    v136FortressCache[replace].seed=seed;
    v136FortressCache[replace].startX=startX;
    v136FortressCache[replace].startZ=startZ;
    v136FortressCache[replace].stamp=v136FortressCacheStamp;
    v136FortressCache[replace].valid=1;
    NBBuild(seed,startX,startZ,&v136FortressCache[replace].graph);
    return &v136FortressCache[replace].graph;
}

static int NBStart(CloneMCJLong seed,int rx,int rz,int *cx,int *cz)
{
    CloneMCJavaRandom r;int mixed;
    mixed=(int)((unsigned int)rx^((unsigned int)rz<<4));
    CloneMCJavaRandom_SetSeed(&r,(CloneMCJLong)mixed^seed);
    (void)CloneMCJavaRandom_NextInt(&r);
    if(CloneMCJavaRandom_NextIntBound(&r,3)!=0)return 0;
    *cx=rx*16+4+CloneMCJavaRandom_NextIntBound(&r,8);
    *cz=rz*16+4+CloneMCJavaRandom_NextIntBound(&r,8);return 1;
}

static void NBSet(CloneMCJ_Chunk *chunk,int baseX,int baseZ,int x,int y,int z,
    int id,int meta)
{
    int lx,lz;lx=x-baseX;lz=z-baseZ;
    if(!chunk||lx<0||lx>=16||lz<0||lz>=16||y<0||y>=128)return;
    chunk->blocks[CloneMCJ_Chunk_BlockIndex(lx,y,lz)]=(unsigned char)id;
    CloneMCJ_NibbleArray_SetNibble(&chunk->data,lx,y,lz,meta);
}

static void NBLocal(CloneMCJ_Chunk *chunk,int baseX,int baseZ,const V136Piece *p,
    int lx,int ly,int lz,int id,int meta)
{
    int x,y,z;V136Transform(p,lx,ly,lz,&x,&y,&z);
    NBSet(chunk,baseX,baseZ,x,y,z,id,meta);
}

static void NBRender(CloneMCJ_World *world,CloneMCJ_Chunk *chunk,int baseX,
    int baseZ,const V136Piece *p)
{
    int x,y,z,edge,enclosed,wx,wy,wz;
    enclosed=p->pool||p->type==NB_ENTRANCE||p->type==NB_STALK;
    for(x=0;x<p->width;++x)for(z=0;z<p->length;++z){
        for(y=0;y<=2&&y<p->height;++y)NBLocal(chunk,baseX,baseZ,p,x,y,z,112,0);
        for(y=3;y<p->height;++y){edge=enclosed&&(x==0||x==p->width-1||
            y==p->height-1);NBLocal(chunk,baseX,baseZ,p,x,y,z,edge?112:0,0);}
    }
    for(z=1;z<p->length-1;++z){
        NBLocal(chunk,baseX,baseZ,p,0,4,z,113,0);
        NBLocal(chunk,baseX,baseZ,p,p->width-1,4,z,113,0);}
    if(p->type==NB_STAIRS||p->type==NB_CORRIDOR3)
        for(z=1;z<p->length-1;++z){y=3+z*(p->height-5)/(p->length-2);
            NBLocal(chunk,baseX,baseZ,p,p->width/2,y,z,114,2);}
    else if(p->type==NB_STALK)
        for(z=3;z<p->length-2;++z)for(x=2;x<p->width-2;++x)
            if((x>=2&&x<=4)||(x>=p->width-5&&x<=p->width-3)){
                NBLocal(chunk,baseX,baseZ,p,x,3,z,88,0);
                NBLocal(chunk,baseX,baseZ,p,x,4,z,115,3);}
    else if(p->type==NB_ENTRANCE)
        NBLocal(chunk,baseX,baseZ,p,p->width/2,3,p->length/2,10,0);
    else if(p->type==NB_THRONE){
        /* ComponentNetherBridgeThrone places its spawner at local 3,5,5. */
        V136Transform(p,3,5,5,&wx,&wy,&wz);
        V136SetSpawner(world,V136FloorDiv(baseX,16),
            V136FloorDiv(baseZ,16),wx,wy,wz,"Blaze");
    }
    /* ComponentNetherBridgePiece.fillCurrentPositionBlocksDownwards. */
    for(x=0;x<p->width;++x)for(z=0;z<p->length;++z)
        if(x==0||x==p->width-1||z==0||z==p->length-1){
            V136Transform(p,x,0,z,&wx,&wy,&wz);
            if(V136FloorDiv(wx,16)!=V136FloorDiv(baseX,16)||
               V136FloorDiv(wz,16)!=V136FloorDiv(baseZ,16))continue;
            for(y=p->oy-1;y>=1;--y){
                if(CloneMCJ_Chunk_GetBlockID(chunk,wx-baseX,y,wz-baseZ)!=0)break;
                NBSet(chunk,baseX,baseZ,wx,y,wz,112,0);}}
}

void CloneMCJ_StructureV136_PopulateOverworld(CloneMCJ_ChunkProviderGenerate *p,
    CloneMCJ_World *world,int cx,int cz)
{
    V136Graph g;const CloneMCJ_BiomeGenBase *b;
    int sx[3],sz[3],i,j,minRX,maxRX,minRZ,maxRZ,rx,rz,startX,startZ,desert;
    int residentX,residentY,residentZ,profession,residentLocalX;
    int residentLocalZ,residentCount,residentIndex,ground;
    if(!p||!world)return;
    CloneMCJ_ChunkProviderGenerate_StrongholdCoordinates(p->worldSeed,sx,sz);
    for(i=0;i<3;++i)if(abs(cx-sx[i])<=8&&abs(cz-sz[i])<=8){
        SHBuild(p->worldSeed,sx[i],sz[i],&g);
        if(g.portal&&!g.overflow)
            for(j=0;j<g.count;++j)if(V136ChunkIntersect(&g.piece[j],cx,cz))
                SHRender(world,cx,cz,&g.piece[j]);}
    /* Pieces are accepted up to 112 blocks from their start.  Eight chunks
     * includes that radius plus the width of the destination chunk. */
    minRX=V136FloorDiv(cx-8,32);maxRX=V136FloorDiv(cx+8,32);
    minRZ=V136FloorDiv(cz-8,32);maxRZ=V136FloorDiv(cz+8,32);
    for(rx=minRX;rx<=maxRX;++rx)for(rz=minRZ;rz<=maxRZ;++rz){
        if(!VGCandidate(p->worldSeed,rx,rz,p->worldChunkManager,&startX,&startZ))
            continue;
        VGBuild(p->worldSeed,startX,startZ,&g);
        if(!VGIsSizeable(&g))continue;
        b=CloneMCJ_WorldChunkManager_GetBiomeGenAt(p->worldChunkManager,
            startX*16+8,startZ*16+8);
        desert=b&&b->biomeID==CLONEMC_J_BIOME_DESERT;
        for(j=0;j<g.count;++j)if(V136ChunkIntersect(&g.piece[j],cx,cz)){
            V136Piece residentPiece;
            ground=VGGround(world,&g.piece[j]);
            VGRender(world,cx,cz,&g.piece[j],desert,ground);
            if(VGResidentInfo(g.piece[j].type,&residentLocalX,
                &residentLocalZ,&residentCount)){
                residentPiece=g.piece[j];residentPiece.oy=ground;
                for(residentIndex=0;residentIndex<residentCount;
                    ++residentIndex){
                    V136Transform(&residentPiece,residentLocalX+residentIndex,1,
                        residentLocalZ,&residentX,&residentY,&residentZ);
                    if(V136FloorDiv(residentX,16)!=cx||
                       V136FloorDiv(residentZ,16)!=cz)continue;
                    profession=VGResidentProfession(g.piece[j].type,
                        residentIndex);
                    CloneMCJ_Gameplay_SpawnVillageResident(world,
                        residentX,residentY,residentZ,profession);
                }
            }
        }
    }
}

void CloneMCJ_StructureV136_PopulateFortress(CloneMCJ_ChunkProviderHell *p,
    CloneMCJ_World *world,CloneMCJ_Chunk *chunk,int cx,int cz)
{
    const V136Graph *g;int minRX,maxRX,minRZ,maxRZ,rx,rz,sx,sz,i;
    if(!p||!world||!chunk)return;
    minRX=V136FloorDiv(cx-8,16);maxRX=V136FloorDiv(cx+8,16);
    minRZ=V136FloorDiv(cz-8,16);maxRZ=V136FloorDiv(cz+8,16);
    for(rx=minRX;rx<=maxRX;++rx)for(rz=minRZ;rz<=maxRZ;++rz){
        if(!NBStart(p->worldSeed,rx,rz,&sx,&sz))continue;
        g=V136CachedFortress(p->worldSeed,sx,sz);
        if(g->overflow)continue;
        for(i=0;i<g->count;++i)if(V136ChunkIntersect(&g->piece[i],cx,cz))
            NBRender(world,chunk,cx*16,cz*16,&g->piece[i]);}
}

int CloneMCJ_StructureV136_FortressContains(CloneMCJLong seed,int x,int z)
{
    const V136Graph *g;int cx,cz,minRX,maxRX,minRZ,maxRZ,rx,rz,sx,sz,i;
    cx=V136FloorDiv(x,16);cz=V136FloorDiv(z,16);
    minRX=V136FloorDiv(cx-8,16);maxRX=V136FloorDiv(cx+8,16);
    minRZ=V136FloorDiv(cz-8,16);maxRZ=V136FloorDiv(cz+8,16);
    for(rx=minRX;rx<=maxRX;++rx)for(rz=minRZ;rz<=maxRZ;++rz){
        if(!NBStart(seed,rx,rz,&sx,&sz))continue;
        g=V136CachedFortress(seed,sx,sz);
        if(g->overflow)continue;
        for(i=0;i<g->count;++i)
            if(x>=g->piece[i].minX&&x<=g->piece[i].maxX&&
               z>=g->piece[i].minZ&&z<=g->piece[i].maxZ)return 1;}
    return 0;
}

int CloneMCJ_StructureV136_RunSelfTests(char *message,unsigned int capacity)
{
    V136Graph a,b;int i,pa,ha,hb,stress,thrones,lx,lz,count;
    SHBuild((CloneMCJLong)12345L,7,23,&a);SHBuild((CloneMCJLong)12345L,7,23,&b);
    pa=ha=hb=0;
    for(i=0;i<a.count;++i){if(a.piece[i].type==SH_PORTAL)++pa;
        ha=ha*33+a.piece[i].type*7+a.piece[i].minX+a.piece[i].minZ;}
    for(i=0;i<b.count;++i)
        hb=hb*33+b.piece[i].type*7+b.piece[i].minX+b.piece[i].minZ;
    if(a.count<8||a.count!=b.count||ha!=hb||pa!=1||a.overflow){
        if(message&&capacity)snprintf(message,capacity,
            "V136 recursive stronghold graph test failed");return 0;}
    NBBuild((CloneMCJLong)12345L,4,4,&a);VGBuild((CloneMCJLong)12345L,7,23,&b);
    if(a.count<8||b.count<8||a.overflow||b.overflow){
        if(message&&capacity)snprintf(message,capacity,
            "V136 fortress/village graph capacity test failed");return 0;}
    thrones=0;
    for(stress=0;stress<32;++stress){
        SHBuild((CloneMCJLong)(stress*7919-50000),stress-16,23-stress,&a);
        pa=0;for(i=0;i<a.count;++i)if(a.piece[i].type==SH_PORTAL)++pa;
        if(a.overflow||pa!=1){
            if(message&&capacity)snprintf(message,capacity,
                "V136 bounded stronghold retry test failed at %d",stress);
            return 0;
        }
        NBBuild((CloneMCJLong)(stress*7919-50000),stress-8,stress+4,&a);
        if(a.overflow){
            if(message&&capacity)snprintf(message,capacity,
                "V136 bounded fortress graph overflowed at %d",stress);
            return 0;
        }
        for(i=0;i<a.count;++i)if(a.piece[i].type==NB_THRONE)++thrones;
        VGBuild((CloneMCJLong)(stress*7919-50000),stress-12,18-stress,&b);
        if(b.overflow){
            if(message&&capacity)snprintf(message,capacity,
                "V136 bounded village graph overflowed at %d",stress);
            return 0;
        }
    }
    if(thrones<1||!VGResidentInfo(VG_GARDEN,&lx,&lz,&count)||
       lx!=1||lz!=2||count!=1||
       !VGResidentInfo(VG_HALL,&lx,&lz,&count)||count!=2||
       VGResidentProfession(VG_HALL,0)!=4||
       VGResidentProfession(VG_HALL,1)!=0){
        if(message&&capacity)snprintf(message,capacity,
            "V136 Java resident/throne mapping test failed");return 0;
    }
    if(message&&capacity)snprintf(message,capacity,
        "V136 structures passed: 32 stress starts, %d throne pieces",thrones);
    return 1;
}
