/*
 * Direct post-Beta class boundary for ChunkProviderEnd.java.
 * Storage remains layout-compatible with CloneMCJ_ChunkProviderSky so old
 * V134-V137 save/runtime ownership does not change.
 */
#include "clonemc_java_port_40_world.h"

int CloneMCJ_ChunkProviderEnd_Initialize(CloneMCJ_ChunkProviderEnd *provider,
    CloneMCJLong seed)
{
    return CloneMCJ_ChunkProviderSky_Initialize(provider,seed);
}

void CloneMCJ_ChunkProviderEnd_Destroy(CloneMCJ_ChunkProviderEnd *provider)
{
    CloneMCJ_ChunkProviderSky_Destroy(provider);
}

int CloneMCJ_ChunkProviderEnd_GenerateChunk(CloneMCJ_ChunkProviderEnd *provider,
    CloneMCJ_Chunk *chunk,int chunkX,int chunkZ)
{
    return CloneMCJ_ChunkProviderSky_GenerateChunk(provider,chunk,chunkX,chunkZ);
}

void CloneMCJ_ChunkProviderEnd_PopulateWorldChunk(
    CloneMCJ_ChunkProviderEnd *provider,CloneMCJ_World *world,
    int chunkX,int chunkZ)
{
    CloneMCJ_ChunkProviderSky_PopulateWorldChunk(provider,world,chunkX,chunkZ);
}

void CloneMCJ_ChunkProviderEnd_Register(void)
{
}

const char *CloneMCJ_ChunkProviderEnd_JavaName(void)
{
    return "net.minecraft.src.ChunkProviderEnd";
}

const char *CloneMCJ_ChunkProviderEnd_AssignedFolder(void)
{
    return "src/40_world";
}
