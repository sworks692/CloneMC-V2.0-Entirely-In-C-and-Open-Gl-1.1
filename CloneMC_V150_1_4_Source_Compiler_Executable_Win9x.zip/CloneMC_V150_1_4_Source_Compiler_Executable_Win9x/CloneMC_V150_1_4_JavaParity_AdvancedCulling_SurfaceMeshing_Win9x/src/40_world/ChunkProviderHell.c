/*
 * CloneMC Java port scaffold: ChunkProviderHell
 *
 * Java source: ChunkProviderHell.java
 * Java type: class ChunkProviderHell
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IChunkProvider
 * Source SHA-256: 144060f7fb27aebce38d4b10eff9612d3b167c3716f5d03171cbab11a2f324f3
 * Java lines: 435
 * Discovered declared fields: 14
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: IChunkProvider, MapGenCavesHell, NoiseGeneratorOctaves, Block, MapGenBase, Chunk, BlockSand, WorldGenHellLava, WorldGenFire, WorldGenGlowStone1, WorldGenGlowStone2, WorldGenFlowers, BlockFlower, World, IProgressUpdate, k, byte2
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Random hellRNG
 * - private NoiseGeneratorOctaves field_4169_i
 * - private NoiseGeneratorOctaves field_4168_j
 * - private NoiseGeneratorOctaves field_4167_k
 * - private NoiseGeneratorOctaves field_4166_l
 * - private NoiseGeneratorOctaves field_4165_m
 * - public NoiseGeneratorOctaves field_4177_a
 * - public NoiseGeneratorOctaves field_4176_b
 * - private World worldObj
 * - private double field_4163_o[]
 * - private double field_4162_p[]
 * - private double field_4161_q[]
 * - private double field_4160_r[]
 * - private MapGenBase field_4159_s
 *
 * Java method/constructor inventory:
 * - public ChunkProviderHell(World world, long l)
 * - public void func_4059_a(int i, int j, byte abyte0[])
 * - public void func_4058_b(int i, int j, byte abyte0[])
 * - public Chunk prepareChunk(int i, int j)
 * - public Chunk provideChunk(int i, int j)
 * - private double[] func_4057_a(double ad[], int i, int j, int k, int l, int i1, int j1)
 * - public boolean chunkExists(int i, int j)
 * - public void populate(IChunkProvider ichunkprovider, int i, int j)
 * - public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
 * - public boolean unload100OldestChunks()
 * - public boolean canSave()
 * - public String makeString()
 *
 * Priority 11 directly implements the Java seven-octave provider ownership,
 * density interpolation, surface replacement and Nether population below.
 */
#include "clonemc_java_port_40_world.h"
#include "../30_item/clonemc_java_port_30_item.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

static CloneMCJLong CloneMCJ_CPH_SeedA(void)
{
    return ((CloneMCJLong)0x4F9939F5L << 8) | (CloneMCJLong)0x08L;
}

static CloneMCJLong CloneMCJ_CPH_SeedB(void)
{
    return ((CloneMCJLong)0x1EF1565BL << 8) | (CloneMCJLong)0xD5L;
}

int CloneMCJ_ChunkProviderHell_Initialize(CloneMCJ_ChunkProviderHell *provider,
    CloneMCJLong worldSeed)
{
    CloneMCJavaRandom random;
    if (!provider) return 0;
    memset(provider, 0, sizeof(*provider));
    provider->worldSeed = worldSeed;
    CloneMCJavaRandom_SetSeed(&random, worldSeed);
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_4169_i, &random, 16) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_4168_j, &random, 16) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_4167_k, &random, 8) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_4166_l, &random, 4) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_4165_m, &random, 4) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_4177_a, &random, 10) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_4176_b, &random, 16)) {
        CloneMCJ_ChunkProviderHell_Destroy(provider);
        return 0;
    }
    provider->hellRNG = random;
    provider->initialized = 1;
    return 1;
}

void CloneMCJ_ChunkProviderHell_Destroy(CloneMCJ_ChunkProviderHell *provider)
{
    if (!provider) return;
    CloneMCNoiseOctaves_Destroy(&provider->field_4169_i);
    CloneMCNoiseOctaves_Destroy(&provider->field_4168_j);
    CloneMCNoiseOctaves_Destroy(&provider->field_4167_k);
    CloneMCNoiseOctaves_Destroy(&provider->field_4166_l);
    CloneMCNoiseOctaves_Destroy(&provider->field_4165_m);
    CloneMCNoiseOctaves_Destroy(&provider->field_4177_a);
    CloneMCNoiseOctaves_Destroy(&provider->field_4176_b);
    provider->initialized = 0;
}

static void CloneMCJ_CPH_InitializeDensity(CloneMCJ_ChunkProviderHell *provider,
    int startX, int startZ)
{
    int x;
    int z;
    int y;
    int column;
    int index;
    double heightNoise;
    double weirdNoise;
    double edge;
    double vertical;
    double lower;
    double upper;
    double selector;
    double density;
    CloneMCNoiseOctaves_Generate(&provider->field_4177_a, provider->scale, 25UL,
        (double)startX, 0.0, (double)startZ, 5, 1, 5, 1.0, 0.0, 1.0);
    CloneMCNoiseOctaves_Generate(&provider->field_4176_b, provider->depth, 25UL,
        (double)startX, 0.0, (double)startZ, 5, 1, 5, 100.0, 0.0, 100.0);
    CloneMCNoiseOctaves_Generate(&provider->field_4167_k, provider->blend, 425UL,
        (double)startX, 0.0, (double)startZ, 5, 17, 5,
        684.412 / 80.0, 2053.236 / 60.0, 684.412 / 80.0);
    CloneMCNoiseOctaves_Generate(&provider->field_4169_i, provider->lower, 425UL,
        (double)startX, 0.0, (double)startZ, 5, 17, 5,
        684.412, 2053.236, 684.412);
    CloneMCNoiseOctaves_Generate(&provider->field_4168_j, provider->upper, 425UL,
        (double)startX, 0.0, (double)startZ, 5, 17, 5,
        684.412, 2053.236, 684.412);
    index = 0;
    column = 0;
    for (x = 0; x < 5; ++x) for (z = 0; z < 5; ++z) {
        heightNoise = (provider->scale[column] + 256.0) / 512.0;
        if (heightNoise > 1.0) heightNoise = 1.0;
        weirdNoise = provider->depth[column] / 8000.0;
        if (weirdNoise < 0.0) weirdNoise = -weirdNoise;
        weirdNoise = weirdNoise * 3.0 - 3.0;
        if (weirdNoise < 0.0) {
            weirdNoise /= 2.0;
            if (weirdNoise < -1.0) weirdNoise = -1.0;
            weirdNoise /= 1.4;
            weirdNoise /= 2.0;
            heightNoise = 0.0;
        } else {
            if (weirdNoise > 1.0) weirdNoise = 1.0;
            weirdNoise /= 6.0;
        }
        (void)heightNoise;
        (void)weirdNoise;
        ++column;
        for (y = 0; y < 17; ++y) {
            edge = (double)y;
            if (y > 8) edge = 16.0 - (double)y;
            vertical = cos(((double)y * 3.1415926535897931 * 6.0) / 17.0) * 2.0;
            if (edge < 4.0) {
                edge = 4.0 - edge;
                vertical -= edge * edge * edge * 10.0;
            }
            lower = provider->lower[index] / 512.0;
            upper = provider->upper[index] / 512.0;
            selector = (provider->blend[index] / 10.0 + 1.0) / 2.0;
            if (selector < 0.0) density = lower;
            else if (selector > 1.0) density = upper;
            else density = lower + (upper - lower) * selector;
            density -= vertical;
            if (y > 13) {
                double fade;
                fade = (double)(y - 13) / 3.0;
                density = density * (1.0 - fade) - 10.0 * fade;
            }
            provider->density[index++] = density;
        }
    }
}

static void CloneMCJ_CPH_GenerateTerrain(CloneMCJ_ChunkProviderHell *provider,
    int chunkX, int chunkZ, CloneMCJ_Chunk *chunk)
{
    int cellX, cellZ, cellY, stepY, stepX, stepZ;
    CloneMCJ_CPH_InitializeDensity(provider, chunkX * 4, chunkZ * 4);
    for (cellX = 0; cellX < 4; ++cellX) for (cellZ = 0; cellZ < 4; ++cellZ)
        for (cellY = 0; cellY < 16; ++cellY) {
            double d1, d2, d3, d4, yd1, yd2, yd3, yd4;
            d1 = provider->density[((cellX + 0) * 5 + cellZ + 0) * 17 + cellY];
            d2 = provider->density[((cellX + 0) * 5 + cellZ + 1) * 17 + cellY];
            d3 = provider->density[((cellX + 1) * 5 + cellZ + 0) * 17 + cellY];
            d4 = provider->density[((cellX + 1) * 5 + cellZ + 1) * 17 + cellY];
            yd1 = (provider->density[((cellX + 0) * 5 + cellZ + 0) * 17 + cellY + 1] - d1) * 0.125;
            yd2 = (provider->density[((cellX + 0) * 5 + cellZ + 1) * 17 + cellY + 1] - d2) * 0.125;
            yd3 = (provider->density[((cellX + 1) * 5 + cellZ + 0) * 17 + cellY + 1] - d3) * 0.125;
            yd4 = (provider->density[((cellX + 1) * 5 + cellZ + 1) * 17 + cellY + 1] - d4) * 0.125;
            for (stepY = 0; stepY < 8; ++stepY) {
                double x0, x1, xd0, xd1;
                x0 = d1; x1 = d2; xd0 = (d3 - d1) * 0.25; xd1 = (d4 - d2) * 0.25;
                for (stepX = 0; stepX < 4; ++stepX) {
                    double value, zd;
                    value = x0; zd = (x1 - x0) * 0.25;
                    for (stepZ = 0; stepZ < 4; ++stepZ) {
                        int x, y, z, id;
                        x = cellX * 4 + stepX;
                        y = cellY * 8 + stepY;
                        z = cellZ * 4 + stepZ;
                        id = y < 32 ? 11 : 0;
                        if (value > 0.0) id = 87;
                        chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)id;
                        value += zd;
                    }
                    x0 += xd0; x1 += xd1;
                }
                d1 += yd1; d2 += yd2; d3 += yd3; d4 += yd4;
            }
        }
}

static void CloneMCJ_CPH_ReplaceSurface(CloneMCJ_ChunkProviderHell *provider,
    int chunkX, int chunkZ, CloneMCJ_Chunk *chunk)
{
    int x, z, y, layer, thickness, top, filler, soul, gravel, id;
    double scale;
    scale = 0.03125;
    CloneMCNoiseOctaves_Generate(&provider->field_4166_l, provider->surfaceA, 256UL,
        chunkX * 16.0, chunkZ * 16.0, 0.0, 16, 16, 1, scale, scale, 1.0);
    CloneMCNoiseOctaves_Generate(&provider->field_4166_l, provider->surfaceB, 256UL,
        chunkX * 16.0, 109.0134, chunkZ * 16.0, 16, 1, 16, scale, 1.0, scale);
    CloneMCNoiseOctaves_Generate(&provider->field_4165_m, provider->surfaceDepth, 256UL,
        chunkX * 16.0, chunkZ * 16.0, 0.0, 16, 16, 1,
        scale * 2.0, scale * 2.0, scale * 2.0);
    for (x = 0; x < 16; ++x) for (z = 0; z < 16; ++z) {
        soul = provider->surfaceA[x + z * 16] + CloneMCJavaRandom_NextDouble(&provider->hellRNG) * 0.2 > 0.0;
        gravel = provider->surfaceB[x + z * 16] + CloneMCJavaRandom_NextDouble(&provider->hellRNG) * 0.2 > 0.0;
        thickness = (int)(provider->surfaceDepth[x + z * 16] / 3.0 + 3.0 +
            CloneMCJavaRandom_NextDouble(&provider->hellRNG) * 0.25);
        layer = -1; top = 87; filler = 87;
        for (y = 127; y >= 0; --y) {
            if (y >= 127 - CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 5) ||
                y <= CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 5)) {
                chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = 7; continue;
            }
            id = CloneMCJ_Chunk_GetBlockID(chunk, x, y, z);
            if (id == 0) { layer = -1; continue; }
            if (id != 87) continue;
            if (layer == -1) {
                top = thickness <= 0 ? 0 : 87; filler = 87;
                if (y >= 60 && y <= 65) {
                    if (gravel) top = 13;
                    if (soul) top = filler = 88;
                }
                if (y < 64 && top == 0) top = 11;
                layer = thickness;
                chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] =
                    (unsigned char)(y >= 63 ? top : filler);
            } else if (layer > 0) {
                --layer;
                chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)filler;
            }
        }
    }
}

int CloneMCJ_ChunkProviderHell_GenerateChunk(CloneMCJ_ChunkProviderHell *provider,
    CloneMCJ_Chunk *chunk, int chunkX, int chunkZ)
{
    if (!provider || !provider->initialized || !chunk) return 0;
    CloneMCJ_Chunk_Initialize(chunk, chunkX, chunkZ);
    chunk->state = CLONEMC_J_CHUNK_STATE_GENERATING_BASE;
    CloneMCJavaRandom_SetSeed(&provider->hellRNG,
        (CloneMCJLong)chunkX * CloneMCJ_CPH_SeedA() +
        (CloneMCJLong)chunkZ * CloneMCJ_CPH_SeedB());
    CloneMCJ_CPH_GenerateTerrain(provider, chunkX, chunkZ, chunk);
    CloneMCJ_CPH_ReplaceSurface(provider, chunkX, chunkZ, chunk);
    CloneMCJ_MapGenCavesHell_Generate(provider->worldSeed, chunkX, chunkZ, chunk);
    CloneMCJ_Chunk_GenerateHeightMap(chunk, 0, 0);
    chunk->isTerrainPopulated = 0;
    chunk->state = CLONEMC_J_CHUNK_STATE_WAITING_FOR_NEIGHBORS;
    chunk->isModified = 0;
    return 1;
}

static int CloneMCJ_CPH_FloorDiv16(int value)
{
    int quotient;
    quotient=value/16;
    if(value<0&&value%16)--quotient;
    return quotient;
}

static int CloneMCJ_CPH_FortressStart(CloneMCJLong worldSeed,
    int regionX,int regionZ,int *startChunkX,int *startChunkZ,int *orientation)
{
    CloneMCJavaRandom random;
    int mixed;
    /* MapGenNetherBridge.canSpawnStructureAtCoords: retain the Java int
     * shift/XOR before promoting the seed to a Java long. */
    mixed=(int)((unsigned int)regionX^((unsigned int)regionZ<<4));
    CloneMCJavaRandom_SetSeed(&random,(CloneMCJLong)mixed^worldSeed);
    (void)CloneMCJavaRandom_NextInt(&random);
    if(CloneMCJavaRandom_NextIntBound(&random,3)!=0)return 0;
    if(startChunkX)*startChunkX=regionX*16+4+
        CloneMCJavaRandom_NextIntBound(&random,8);
    else (void)CloneMCJavaRandom_NextIntBound(&random,8);
    if(startChunkZ)*startChunkZ=regionZ*16+4+
        CloneMCJavaRandom_NextIntBound(&random,8);
    else (void)CloneMCJavaRandom_NextIntBound(&random,8);
    if(orientation)*orientation=CloneMCJavaRandom_NextIntBound(&random,2);
    return 1;
}

static int CloneMCJ_CPH_FortressLocal(CloneMCJLong worldSeed,
    int worldX,int worldZ,int *localX,int *localZ)
{
    int chunkX,chunkZ,regionMinX,regionMaxX,regionMinZ,regionMaxZ;
    int regionX,regionZ,startX,startZ,orientation,dx,dz,rx,rz;
    chunkX=CloneMCJ_CPH_FloorDiv16(worldX);
    chunkZ=CloneMCJ_CPH_FloorDiv16(worldZ);
    regionMinX=CloneMCJ_CPH_FloorDiv16(chunkX-8);
    regionMaxX=CloneMCJ_CPH_FloorDiv16(chunkX+8);
    regionMinZ=CloneMCJ_CPH_FloorDiv16(chunkZ-8);
    regionMaxZ=CloneMCJ_CPH_FloorDiv16(chunkZ+8);
    for(regionX=regionMinX;regionX<=regionMaxX;++regionX)
        for(regionZ=regionMinZ;regionZ<=regionMaxZ;++regionZ){
            if(!CloneMCJ_CPH_FortressStart(worldSeed,regionX,regionZ,
                &startX,&startZ,&orientation))continue;
            dx=worldX-(startX*16+8);dz=worldZ-(startZ*16+8);
            rx=orientation?dz:dx;rz=orientation?-dx:dz;
            if((abs(rx)<=2&&abs(rz)<=96)||
               (abs(rz)<=2&&abs(rx)<=64)||
               (abs(rx)<=9&&abs(rz)<=9)||
               (abs(rx)<=6&&rz>=52&&rz<=64)||
               (abs(rx)<=4&&rz>=-66&&rz<=-56)){
                if(localX)*localX=rx;
                if(localZ)*localZ=rz;
                return 1;
            }
        }
    return 0;
}

int CloneMCJ_ChunkProviderHell_IsFortressAt(CloneMCJLong worldSeed,
    int worldX,int worldZ)
{
    return CloneMCJ_StructureV136_FortressContains(worldSeed,worldX,worldZ);
}

static void CloneMCJ_CPH_SetRaw(CloneMCJ_Chunk *chunk,
    int x,int y,int z,int blockID,int metadata)
{
    if(!chunk||x<0||x>=16||z<0||z>=16||y<0||y>=128)return;
    chunk->blocks[CloneMCJ_Chunk_BlockIndex(x,y,z)]=(unsigned char)blockID;
    CloneMCJ_NibbleArray_SetNibble(&chunk->data,x,y,z,metadata);
}

static void CloneMCJ_CPH_PopulateFortress(CloneMCJ_ChunkProviderHell *provider,
    CloneMCJ_World *world,CloneMCJ_Chunk *chunk,int baseX,int baseZ)
{
    CloneMCJ_TileEntity *tile;
    int lx,lz,worldX,worldZ,rx,rz,y,id,metadata;
    if(!provider||!world||!chunk)return;
    for(lx=0;lx<16;++lx)for(lz=0;lz<16;++lz){
        worldX=baseX+lx;worldZ=baseZ+lz;
        if(!CloneMCJ_CPH_FortressLocal(provider->worldSeed,
            worldX,worldZ,&rx,&rz))continue;
        /* Java Straight/Crossing3 proportions: thick nether-brick deck,
         * five blocks of headroom, fenced edges, and a brick top rail. */
        for(y=62;y<=64;++y)CloneMCJ_CPH_SetRaw(chunk,lx,y,lz,112,0);
        for(y=65;y<=69;++y)CloneMCJ_CPH_SetRaw(chunk,lx,y,lz,0,0);
        if((abs(rx)==2&&abs(rz)>9)||(abs(rz)==2&&abs(rx)>9)){
            CloneMCJ_CPH_SetRaw(chunk,lx,66,lz,113,0);
            CloneMCJ_CPH_SetRaw(chunk,lx,69,lz,112,0);
        }
        /* StructureNetherBridgePieces' 13x13 Nether-stalk room: paired
         * soul-sand beds, mature wart, perimeter brick/fence, and entry stair. */
        if(abs(rx)<=6&&rz>=52&&rz<=64){
            if(abs(rx)==6||rz==52||rz==64)
                for(y=65;y<=70;++y)CloneMCJ_CPH_SetRaw(chunk,lx,y,lz,
                    y==67||y==69?113:112,0);
            if((rx>=-4&&rx<=-3)||(rx>=3&&rx<=4)){
                CloneMCJ_CPH_SetRaw(chunk,lx,65,lz,88,0);
                CloneMCJ_CPH_SetRaw(chunk,lx,66,lz,115,3);
            }
            if(rz>=52&&rz<=56&&abs(rx)<=2){
                metadata=rz-52;if(metadata>3)metadata=3;
                CloneMCJ_CPH_SetRaw(chunk,lx,65,lz,114,metadata);
            }
        }
        /* The throne terminus owns the Blaze spawner.  Use World placement
         * for this one block so the normal tile-entity lifecycle and NBT run. */
        if(rx==0&&rz==-61){
            id=CloneMCJ_World_GetBlockId(world,worldX,66,worldZ);
            if(id!=52)CloneMCJ_World_SetBlockWithMetadata(world,
                worldX,66,worldZ,52,0);
            tile=(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(
                chunk,lx,66,lz);
            if(tile&&tile->type==CLONEMC_J_TILE_MOB_SPAWNER){
                strcpy(tile->mobID,"Blaze");tile->spawnDelay=20;
                CloneMCJ_Chunk_SetModified(chunk);
            }
        }
    }
}

void CloneMCJ_ChunkProviderHell_PopulateWorldChunk(CloneMCJ_ChunkProviderHell *provider,
    CloneMCJ_World *world, int chunkX, int chunkZ)
{
    CloneMCJ_Chunk *chunk;
    int baseX, baseZ, i, count, x, y, z;
    if (!provider || !provider->initialized || !world) return;
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX, chunkZ) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX + 1, chunkZ) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX, chunkZ + 1) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX + 1, chunkZ + 1)) return;
    chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider, chunkX, chunkZ);
    if (!chunk || chunk->neverSave || chunk->isTerrainPopulated) return;
    chunk->state = CLONEMC_J_CHUNK_STATE_POPULATING;
    chunk->isTerrainPopulated = 1;
    baseX = chunkX * 16; baseZ = chunkZ * 16;
    CloneMCJavaRandom_SetSeed(&provider->hellRNG,
        (CloneMCJLong)chunkX * CloneMCJ_CPH_SeedA() +
        (CloneMCJLong)chunkZ * CloneMCJ_CPH_SeedB());
    CloneMCJ_StructureV136_PopulateFortress(provider,world,chunk,chunkX,chunkZ);
    for (i = 0; i < 8; ++i) {
        x = baseX + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        y = CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 120) + 4;
        z = baseZ + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        CloneMCJ_WorldGenHellLava_Generate(world, &provider->hellRNG, x, y, z, 10);
    }
    count = CloneMCJavaRandom_NextIntBound(&provider->hellRNG,
        CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 10) + 1) + 1;
    for (i = 0; i < count; ++i) {
        x = baseX + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        y = CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 120) + 4;
        z = baseZ + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        CloneMCJ_WorldGenFire_Generate(world, &provider->hellRNG, x, y, z);
    }
    count = CloneMCJavaRandom_NextIntBound(&provider->hellRNG,
        CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 10) + 1);
    for (i = 0; i < count; ++i) {
        x = baseX + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        y = CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 128);
        z = baseZ + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        CloneMCJ_WorldGenGlowStone1_Generate(world, &provider->hellRNG, x, y, z);
    }
    for (i = 0; i < 10; ++i) {
        x = baseX + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        y = CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 128);
        z = baseZ + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        CloneMCJ_WorldGenGlowStone2_Generate(world, &provider->hellRNG, x, y, z);
    }
    if (CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 1) == 0) {
        x = baseX + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        y = CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 128);
        z = baseZ + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        CloneMCJ_WorldGenFlowers_Generate(world, &provider->hellRNG, x, y, z, 39);
    }
    if (CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 1) == 0) {
        x = baseX + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        y = CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 128);
        z = baseZ + CloneMCJavaRandom_NextIntBound(&provider->hellRNG, 16) + 8;
        CloneMCJ_WorldGenFlowers_Generate(world, &provider->hellRNG, x, y, z, 40);
    }
    CloneMCJ_Chunk_GenerateHeightMap(chunk, 0, 0);
    chunk->lightDirty = 1; chunk->meshDirty = 1;
    chunk->meshDirtySections=0xFFU; chunk->isModified = 1;
    chunk->state = CLONEMC_J_CHUNK_STATE_READY;
}

void CloneMCJ_ChunkProviderHell_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkProviderHell_JavaName(void)
{
    return "net.minecraft.src.ChunkProviderHell";
}

const char *CloneMCJ_ChunkProviderHell_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkProviderHell_JavaSourceHash32(void)
{
    return 0x144060F7UL;
}
