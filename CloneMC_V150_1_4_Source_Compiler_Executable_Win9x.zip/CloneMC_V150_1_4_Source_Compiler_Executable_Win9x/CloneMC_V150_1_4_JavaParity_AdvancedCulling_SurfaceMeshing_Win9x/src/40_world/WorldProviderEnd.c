/*
 * Direct post-Beta class boundary for WorldProviderEnd.java.
 * The V134 implementation previously lived under WorldProviderSky symbols.
 * V138 makes the End provider explicit while preserving those legacy wrappers.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldProviderEnd_Initialize(CloneMCJ_WorldProvider *provider)
{
    CloneMCJ_WorldProviderSky_Initialize(provider);
}

void CloneMCJ_WorldProviderEnd_GetFogColor(float celestialAngle,
    float *red,float *green,float *blue)
{
    CloneMCJ_WorldProviderSky_GetSkyColor(celestialAngle,red,green,blue);
}

void CloneMCJ_WorldProviderEnd_Register(void)
{
}

const char *CloneMCJ_WorldProviderEnd_JavaName(void)
{
    return "net.minecraft.src.WorldProviderEnd";
}

const char *CloneMCJ_WorldProviderEnd_AssignedFolder(void)
{
    return "src/40_world";
}
