/*
 * CloneMC Java port scaffold: ChunkProviderClient
 *
 * Java source: ChunkProviderClient.java
 * Java type: class ChunkProviderClient
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IChunkProvider
 * Source SHA-256: 74ce05835e354b50d79f587f1844933d6de3c66077576c8a47f0365260feb0ff
 * Java lines: 101
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: IChunkProvider, EmptyChunk, ChunkCoordIntPair, Chunk, NibbleArray, World, IProgressUpdate, abyte0, i, re
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Chunk blankChunk
 * - private Map chunkMapping
 * - private List field_889_c
 * - private World worldObj
 *
 * Java method/constructor inventory:
 * - public ChunkProviderClient(World world)
 * - public boolean chunkExists(int i, int j)
 * - public void func_539_c(int i, int j)
 * - public Chunk prepareChunk(int i, int j)
 * - public Chunk provideChunk(int i, int j)
 * - public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
 * - public boolean unload100OldestChunks()
 * - public boolean canSave()
 * - public void populate(IChunkProvider ichunkprovider, int i, int j)
 * - public String makeString()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_ChunkProviderClient_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkProviderClient_JavaName(void)
{
    return "net.minecraft.src.ChunkProviderClient";
}

const char *CloneMCJ_ChunkProviderClient_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkProviderClient_JavaSourceHash32(void)
{
    return 0x74CE0583UL;
}

/* Priority 3 ChunkProviderClient implementation. */
#include <string.h>
#include <stdlib.h>

static int CloneMCJ_ChunkProviderClient_FindSlot(const CloneMCJ_ChunkProviderClient *provider, int chunkX, int chunkZ)
{
    int i;
    if (!provider) { return -1; }
    for (i = 0; i < CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY; ++i) {
        if (provider->slots[i].used && provider->slots[i].chunk && provider->slots[i].chunkX == chunkX && provider->slots[i].chunkZ == chunkZ) { return i; }
    }
    return -1;
}

static int CloneMCJ_ChunkProviderClient_SelectSlot(CloneMCJ_ChunkProviderClient *provider,
    int incomingX,int incomingZ)
{
    CloneMCJ_WorldClient *client;
    CloneMCJ_World *world;
    int i,best,centerX,centerZ,distance,bestDistance,incomingDistance;
    unsigned long bestAge;
    best=-1;bestDistance=-1;bestAge=0UL;
    for (i = 0; i < CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY; ++i) {
        if (!provider->slots[i].used) { return i; }
    }
    /* A render-frame LRU makes the video-distance slider accidentally control
     * the network cache: visible chunks are touched every frame, so incoming
     * Packet50/51 data repeatedly evicts useful movement chunks.  Once full,
     * retain the nearest authoritative chunks to the player and use age only
     * as a deterministic tie-breaker. */
    client=(CloneMCJ_WorldClient *)provider->worldObj;
    world=client?&client->baseWorld:(CloneMCJ_World *)0;
    if(!world||!world->playerChunkInitialized){
        best=0;bestAge=provider->slots[0].lastAccess;
        for(i=1;i<CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY;++i)
            if(provider->slots[i].lastAccess<bestAge){
                bestAge=provider->slots[i].lastAccess;best=i;
            }
        return best;
    }
    centerX=world->playerChunkX;centerZ=world->playerChunkZ;
    incomingDistance=abs(incomingX-centerX)+abs(incomingZ-centerZ);
    for(i=0;i<CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY;++i){
        distance=abs(provider->slots[i].chunkX-centerX)+
            abs(provider->slots[i].chunkZ-centerZ);
        if(distance>bestDistance||(distance==bestDistance&&
           (best<0||provider->slots[i].lastAccess<bestAge))){
            best=i;bestDistance=distance;bestAge=provider->slots[i].lastAccess;
        }
    }
    /* A farther server pre-chunk announcement must not evict a nearer ready
     * chunk.  As the player crosses a boundary, the distance ordering changes
     * and the new movement-side chunks naturally replace the trailing edge. */
    if(bestDistance<incomingDistance)return -1;
    return best;
}

static int CloneMCJ_ChunkProviderClient_IChunkExists(void *instance, int chunkX, int chunkZ)
{ return CloneMCJ_ChunkProviderClient_ChunkExists((CloneMCJ_ChunkProviderClient *)instance, chunkX, chunkZ); }
static CloneMCJ_Chunk *CloneMCJ_ChunkProviderClient_IProvide(void *instance, int chunkX, int chunkZ)
{ return CloneMCJ_ChunkProviderClient_ProvideChunk((CloneMCJ_ChunkProviderClient *)instance, chunkX, chunkZ); }
static CloneMCJ_Chunk *CloneMCJ_ChunkProviderClient_IPrepare(void *instance, int chunkX, int chunkZ)
{ return CloneMCJ_ChunkProviderClient_PrepareChunk((CloneMCJ_ChunkProviderClient *)instance, chunkX, chunkZ); }
static void CloneMCJ_ChunkProviderClient_IPopulate(void *instance, CloneMCJ_IChunkProvider *provider, int chunkX, int chunkZ)
{ (void)provider; (void)chunkX; (void)chunkZ; (void)instance; }
static int CloneMCJ_ChunkProviderClient_ISave(void *instance, int force, void *progressUpdate)
{ (void)progressUpdate; return CloneMCJ_ChunkProviderClient_SaveChunks((CloneMCJ_ChunkProviderClient *)instance, force); }
static int CloneMCJ_ChunkProviderClient_IUnload(void *instance)
{ return CloneMCJ_ChunkProviderClient_Unload100OldestChunks((CloneMCJ_ChunkProviderClient *)instance); }
static int CloneMCJ_ChunkProviderClient_ICanSave(void *instance)
{ return CloneMCJ_ChunkProviderClient_CanSave((CloneMCJ_ChunkProviderClient *)instance); }
static const char *CloneMCJ_ChunkProviderClient_IMakeString(void *instance)
{ return CloneMCJ_ChunkProviderClient_MakeString((CloneMCJ_ChunkProviderClient *)instance); }

void CloneMCJ_ChunkProviderClient_Initialize(CloneMCJ_ChunkProviderClient *provider, void *worldObj)
{
    if (!provider) { return; }
    memset(provider, 0, sizeof(*provider));
    provider->residentSerial = 1UL;
    provider->worldObj = worldObj;
    CloneMCJ_EmptyChunk_Initialize(&provider->blankChunk, 0, 0);
    provider->providerInterface.instance = provider;
    provider->providerInterface.chunkExists = CloneMCJ_ChunkProviderClient_IChunkExists;
    provider->providerInterface.provideChunk = CloneMCJ_ChunkProviderClient_IProvide;
    provider->providerInterface.prepareChunk = CloneMCJ_ChunkProviderClient_IPrepare;
    provider->providerInterface.populate = CloneMCJ_ChunkProviderClient_IPopulate;
    provider->providerInterface.saveChunks = CloneMCJ_ChunkProviderClient_ISave;
    provider->providerInterface.unload100OldestChunks = CloneMCJ_ChunkProviderClient_IUnload;
    provider->providerInterface.canSave = CloneMCJ_ChunkProviderClient_ICanSave;
    provider->providerInterface.makeString = CloneMCJ_ChunkProviderClient_IMakeString;
}

void CloneMCJ_ChunkProviderClient_Destroy(CloneMCJ_ChunkProviderClient *provider)
{
    int i;
    if (!provider) { return; }
    for (i = 0; i < CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY; ++i) {
        if (provider->slots[i].used && provider->slots[i].chunk) { CloneMCJ_Chunk_Destroy(provider->slots[i].chunk); free(provider->slots[i].chunk); }
        provider->slots[i].chunk = 0; provider->slots[i].used = 0;
    }
    CloneMCJ_Chunk_Destroy(&provider->blankChunk);
}

int CloneMCJ_ChunkProviderClient_ChunkExists(const CloneMCJ_ChunkProviderClient *provider, int chunkX, int chunkZ)
{
    return CloneMCJ_ChunkProviderClient_FindSlot(provider, chunkX, chunkZ) >= 0;
}

void CloneMCJ_ChunkProviderClient_DoPreChunk(CloneMCJ_ChunkProviderClient *provider, int chunkX, int chunkZ, int load)
{
    int slot;
    if (!provider) { return; }
    slot = CloneMCJ_ChunkProviderClient_FindSlot(provider, chunkX, chunkZ);
    if (!load) {
        if (slot >= 0) {
            CloneMCJ_Chunk_Destroy(provider->slots[slot].chunk);
            free(provider->slots[slot].chunk);
            provider->slots[slot].chunk = 0;
            provider->slots[slot].used = 0;
            ++provider->residentSerial;
            if(provider->residentSerial==0UL)provider->residentSerial=1UL;
        }
        return;
    }
    if (slot < 0) {
        slot = CloneMCJ_ChunkProviderClient_SelectSlot(provider,chunkX,chunkZ);
        if(slot<0)return;
        if (provider->slots[slot].used && provider->slots[slot].chunk) { CloneMCJ_Chunk_Destroy(provider->slots[slot].chunk); free(provider->slots[slot].chunk); provider->slots[slot].chunk = 0; }
        provider->slots[slot].chunk = (CloneMCJ_Chunk *)malloc(sizeof(CloneMCJ_Chunk));
        if (!provider->slots[slot].chunk) {
            provider->slots[slot].used = 0;
            ++provider->residentSerial;
            if(provider->residentSerial==0UL)provider->residentSerial=1UL;
            return;
        }
        CloneMCJ_Chunk_Initialize(provider->slots[slot].chunk, chunkX, chunkZ);
        provider->slots[slot].chunkX = chunkX;
        provider->slots[slot].chunkZ = chunkZ;
        provider->slots[slot].used = 1;
        ++provider->residentSerial;
        if(provider->residentSerial==0UL)provider->residentSerial=1UL;
    }
    provider->slots[slot].lastAccess = ++provider->accessClock;
}

CloneMCJ_Chunk *CloneMCJ_ChunkProviderClient_PrepareChunk(CloneMCJ_ChunkProviderClient *provider, int chunkX, int chunkZ)
{
    return CloneMCJ_ChunkProviderClient_ProvideChunk(provider, chunkX, chunkZ);
}

CloneMCJ_Chunk *CloneMCJ_ChunkProviderClient_ProvideChunk(CloneMCJ_ChunkProviderClient *provider, int chunkX, int chunkZ)
{
    int slot;
    if (!provider) { return 0; }
    slot = CloneMCJ_ChunkProviderClient_FindSlot(provider, chunkX, chunkZ);
    if (slot < 0) { return &provider->blankChunk; }
    provider->slots[slot].lastAccess = ++provider->accessClock;
    return provider->slots[slot].chunk;
}

int CloneMCJ_ChunkProviderClient_SaveChunks(CloneMCJ_ChunkProviderClient *provider, int force)
{ (void)provider; (void)force; return 1; }
int CloneMCJ_ChunkProviderClient_Unload100OldestChunks(CloneMCJ_ChunkProviderClient *provider)
{ (void)provider; return 0; }
int CloneMCJ_ChunkProviderClient_CanSave(const CloneMCJ_ChunkProviderClient *provider)
{ (void)provider; return 0; }
const char *CloneMCJ_ChunkProviderClient_MakeString(const CloneMCJ_ChunkProviderClient *provider)
{ (void)provider; return "MultiplayerChunkCache"; }
CloneMCJ_IChunkProvider *CloneMCJ_ChunkProviderClient_AsIChunkProvider(CloneMCJ_ChunkProviderClient *provider)
{ return provider ? &provider->providerInterface : 0; }
