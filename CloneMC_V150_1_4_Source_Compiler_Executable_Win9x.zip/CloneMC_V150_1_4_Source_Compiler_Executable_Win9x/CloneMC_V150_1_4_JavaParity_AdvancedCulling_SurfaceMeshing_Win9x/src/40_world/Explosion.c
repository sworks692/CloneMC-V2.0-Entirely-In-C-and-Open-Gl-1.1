/*
 * CloneMC Java port scaffold: Explosion
 *
 * Java source: Explosion.java
 * Java type: class Explosion
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 3496c4630bd8a5685ffe13dffc6b7125e96ae7b4d70ffa8ccb45ba21339e75a9
 * Java lines: 191
 * Discovered declared fields: 9
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: World, MathHelper, Block, ChunkPosition, AxisAlignedBB, Vec3D, Entity, BlockFire, do
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public boolean isFlaming
 * - private Random ExplosionRNG
 * - private World worldObj
 * - public double explosionX
 * - public double explosionY
 * - public double explosionZ
 * - public Entity exploder
 * - public float explosionSize
 * - public Set destroyedBlockPositions
 *
 * Java method/constructor inventory:
 * - public Explosion(World world, Entity entity, double d, double d1, double d2, float f)
 * - public void doExplosionA()
 * - public void doExplosionB(boolean flag)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../30_item/clonemc_java_port_30_item.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

/* Bounded direct port of Explosion.doExplosionA/B.  A compact local occupancy
 * cube replaces Java's HashSet, retaining ray order and avoiding duplicate
 * block destruction without dynamic per-position allocations. */
static void CloneMCJ_Explosion_QueueEvent(CloneMCJ_GameplayState *gameplay,
    double x,double y,double z,float strength,int flaming)
{
    unsigned long sequence;unsigned long slot;CloneMCJ_ExplosionEvent *event;
    if(!gameplay)return;sequence=++gameplay->explosionEventSequence;
    slot=(sequence-1UL)%CLONEMC_J_EXPLOSION_EVENT_CAPACITY;
    event=&gameplay->explosionEvents[slot];event->sequence=sequence;
    event->x=x;event->y=y;event->z=z;event->strength=strength;
    event->flaming=(unsigned char)(flaming?1:0);
}

int CloneMCJ_Gameplay_GetExplosionEvent(const CloneMCJ_GameplayState *gameplay,
    unsigned long sequence,CloneMCJ_ExplosionEvent *out)
{
    const CloneMCJ_ExplosionEvent *event;unsigned long slot;
    if(!gameplay||!out||!sequence||sequence>gameplay->explosionEventSequence)return 0;
    if(gameplay->explosionEventSequence-sequence>=CLONEMC_J_EXPLOSION_EVENT_CAPACITY)return 0;
    slot=(sequence-1UL)%CLONEMC_J_EXPLOSION_EVENT_CAPACITY;
    event=&gameplay->explosionEvents[slot];if(event->sequence!=sequence)return 0;
    *out=*event;return 1;
}

static double CloneMCJ_Explosion_Distance(double ax,double ay,double az,
    double bx,double by,double bz)
{double dx,dy,dz;dx=ax-bx;dy=ay-by;dz=az-bz;return sqrt(dx*dx+dy*dy+dz*dz);}

static double CloneMCJ_Explosion_Exposure(CloneMCJ_World *world,double x,double y,
    double z,const CloneMCJ_Entity *target)
{
    CloneMCJ_Entity source,sample;int visible,total,ix,iy,iz;
    if(!world||!target)return 0.0;memset(&source,0,sizeof(source));source.worldObj=world;
    source.posX=x;source.posY=y;source.posZ=z;source.height=0.0F;sample=*target;
    sample.worldObj=world;sample.height=0.0F;visible=0;total=0;
    for(ix=0;ix<2;++ix)for(iy=0;iy<3;++iy)for(iz=0;iz<2;++iz){
        sample.posX=target->boundingBox.minX+
            (target->boundingBox.maxX-target->boundingBox.minX)*(0.2+0.6*(double)ix);
        sample.posY=target->boundingBox.minY+
            (target->boundingBox.maxY-target->boundingBox.minY)*(0.1+0.4*(double)iy);
        sample.posZ=target->boundingBox.minZ+
            (target->boundingBox.maxZ-target->boundingBox.minZ)*(0.2+0.6*(double)iz);
        if(CloneMCJ_EntityLiving_CanSeeEntity(&source,&sample))++visible;++total;
    }
    return total?(double)visible/(double)total:0.0;
}

static void CloneMCJ_Explosion_DamageEntity(CloneMCJ_World *world,
    CloneMCJ_Entity *entity,int *health,const CloneMCJ_Entity *exploder,
    double x,double y,double z,float size)
{
    double distance,normal,impact,exposure,dx,dy,dz,length;int damage;
    if(!world||!entity||!health||*health<=0)return;
    distance=CloneMCJ_Explosion_Distance(entity->posX,entity->posY+entity->height*0.5,
        entity->posZ,x,y,z);normal=distance/((double)size*2.0);if(normal>1.0)return;
    exposure=CloneMCJ_Explosion_Exposure(world,x,y,z,entity);
    impact=(1.0-normal)*exposure;
    damage=(int)(((impact*impact+impact)*0.5)*8.0*(double)size+1.0);
    if(damage<1)return;*health-=damage;if(*health<0)*health=0;
    dx=entity->posX-x;dy=(entity->posY+entity->height*0.5)-y;dz=entity->posZ-z;
    length=sqrt(dx*dx+dy*dy+dz*dz);if(length<0.001)length=0.001;
    entity->motionX+=dx/length*impact;entity->motionY+=dy/length*impact;
    entity->motionZ+=dz/length*impact;(void)exploder;
}

int CloneMCJ_Explosion_Execute(CloneMCJ_World *world,const CloneMCJ_Entity *exploder,
    double x,double y,double z,float size,int flaming)
{
    CloneMCJ_GameplayState *gameplay;CloneMCJavaRandom *random;
    unsigned char *marked;int radius,diameter,total,sx,sy,sz,bx,by,bz,index,id,metadata;
    int ix,iy,iz,step;double dx,dy,dz,length,px,py,pz;float energy;
    const CloneMCJ_BlockDefinition *block;CloneMCJ_ItemStack drop;
    if(!world||size<=0.0F)return 0;gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
    random=exploder?(CloneMCJavaRandom *)&exploder->rand:&world->rand;
    radius=(int)ceil((double)size*2.0)+2;if(radius<4)radius=4;if(radius>16)radius=16;
    diameter=radius*2+1;total=diameter*diameter*diameter;
    marked=(unsigned char *)calloc((unsigned long)total,1);if(!marked)return 0;
    for(sx=0;sx<16;++sx)for(sy=0;sy<16;++sy)for(sz=0;sz<16;++sz){
        if(sx!=0&&sx!=15&&sy!=0&&sy!=15&&sz!=0&&sz!=15)continue;
        dx=(double)sx/15.0*2.0-1.0;dy=(double)sy/15.0*2.0-1.0;
        dz=(double)sz/15.0*2.0-1.0;length=sqrt(dx*dx+dy*dy+dz*dz);
        if(length<0.001)continue;dx/=length;dy/=length;dz/=length;
        energy=size*(0.7F+CloneMCJavaRandom_NextFloat(random)*0.6F);
        px=x;py=y;pz=z;step=0;
        while(energy>0.0F&&step++<160){
            bx=CloneMCJava_FloorDouble(px);by=CloneMCJava_FloorDouble(py);bz=CloneMCJava_FloorDouble(pz);
            id=CloneMCJ_World_GetLoadedBlockId(world,bx,by,bz);
            if(id>0){block=CloneMCJ_BlockRegistry_Get(id);
                energy-=(float)(((block?(double)block->resistance:0.0)+0.3)*0.3);
                if(energy>0.0F){ix=bx-CloneMCJava_FloorDouble(x)+radius;
                    iy=by-CloneMCJava_FloorDouble(y)+radius;
                    iz=bz-CloneMCJava_FloorDouble(z)+radius;
                    if(ix>=0&&ix<diameter&&iy>=0&&iy<diameter&&iz>=0&&iz<diameter)
                        marked[(ix*diameter+iy)*diameter+iz]=1;}}
            px+=dx*0.3;py+=dy*0.3;pz+=dz*0.3;energy-=0.225F;
        }
    }
    if(gameplay){
        int playerHealthBefore;
        int playerExplosionDamage;
        playerHealthBefore=gameplay->player.health;
        CloneMCJ_Explosion_DamageEntity(world,&gameplay->player.entity,
            &gameplay->player.health,exploder,x,y,z,size);
        playerExplosionDamage=playerHealthBefore-gameplay->player.health;
        gameplay->player.health=playerHealthBefore;
        if(playerExplosionDamage>0)
            CloneMCJ_Progression_AttackPlayerProtected(&gameplay->player,
                exploder,playerExplosionDamage,
                CLONEMC_J_ENCHANT_BLAST_PROTECTION);
        for(index=0;index<CLONEMC_J_MAX_MOBS;++index)if(gameplay->mobs[index].active&&
            (!exploder||&gameplay->mobs[index].entity!=exploder)){
            CloneMCJ_Explosion_DamageEntity(world,&gameplay->mobs[index].entity,
                &gameplay->mobs[index].health,exploder,x,y,z,size);
            if(gameplay->mobs[index].health<=0)gameplay->mobs[index].deathTime=1;
        }
    }
    for(ix=0;ix<diameter;++ix)for(iy=0;iy<diameter;++iy)for(iz=0;iz<diameter;++iz){
        if(!marked[(ix*diameter+iy)*diameter+iz])continue;
        bx=CloneMCJava_FloorDouble(x)+ix-radius;by=CloneMCJava_FloorDouble(y)+iy-radius;
        bz=CloneMCJava_FloorDouble(z)+iz-radius;id=CloneMCJ_World_GetLoadedBlockId(world,bx,by,bz);
        if(id<=0||id==7)continue;metadata=CloneMCJ_World_GetLoadedBlockMetadata(world,bx,by,bz);
        /* Explosion.doExplosionB uses dropBlockAsItemWithChance(..., 0.3F). */
        if(gameplay&&CloneMCJavaRandom_NextFloat(random)<=0.3F&&
           CloneMCJ_Block_GetDroppedStack(id,metadata,random,&drop))
            CloneMCJ_Gameplay_SpawnDrop(gameplay,(double)bx+0.5,(double)by+0.5,
                (double)bz+0.5,&drop,10,0);
        CloneMCJ_World_SetBlockNotify(world,bx,by,bz,0);
    }
    if(flaming){
        for(ix=0;ix<diameter;++ix)for(iy=0;iy<diameter;++iy)for(iz=0;iz<diameter;++iz){
            if(!marked[(ix*diameter+iy)*diameter+iz])continue;
            bx=CloneMCJava_FloorDouble(x)+ix-radius;by=CloneMCJava_FloorDouble(y)+iy-radius;
            bz=CloneMCJava_FloorDouble(z)+iz-radius;
            if(CloneMCJ_World_GetLoadedBlockId(world,bx,by,bz)==0&&
               CloneMCJ_World_GetLoadedBlockId(world,bx,by-1,bz)>0&&
               CloneMCJavaRandom_NextIntBound(random,3)==0)
                CloneMCJ_World_SetBlockNotify(world,bx,by,bz,51);
        }
    }
    free(marked);CloneMCJ_Explosion_QueueEvent(gameplay,x,y,z,size,flaming);return 1;
}

void CloneMCJ_Explosion_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Explosion_JavaName(void)
{
    return "net.minecraft.src.Explosion";
}

const char *CloneMCJ_Explosion_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_Explosion_JavaSourceHash32(void)
{
    return 0x3496C463UL;
}
