/*
 * CloneMC Java port scaffold: WorldProviderSky
 *
 * Java source: WorldProviderSky.java
 * Java type: class WorldProviderSky
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldProvider
 * Implements: (none declared)
 * Source SHA-256: 38a24cf7826b141ebb267954daaf253f40f59490f3dc2d161aad207b03a76374
 * Java lines: 84
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: WorldProvider, WorldChunkManagerHell, BiomeGenBase, ChunkProviderSky, World, MathHelper, Vec3D, Block, Material, IChunkProvider, f4
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldProviderSky()
 * - public void registerWorldChunkManager()
 * - public IChunkProvider getChunkProvider()
 * - public float calculateCelestialAngle(long l, float f)
 * - public float[] calcSunriseSunsetColors(float f, float f1)
 * - public Vec3D func_4096_a(float f, float f1)
 * - public boolean func_28112_c()
 * - public float getCloudHeight()
 * - public boolean canCoordinateBeSpawn(int i, int j)
 *
 * V134 replaces the pre-release Sky Dimension behavior with the uploaded
 * Minecraft 1.2.3 WorldProviderEnd behavior.  The historical C symbol names
 * stay stable for save/provider ABI compatibility: dimension +1 is still
 * stored in DIM1, but it now has no sky, fixed celestial angle zero, the End
 * fog tint, no respawn, and ChunkProviderEnd terrain.
 */
#include "clonemc_java_port_40_world.h"
#include <string.h>

void CloneMCJ_WorldProviderSky_Initialize(CloneMCJ_WorldProvider *provider)
{
    if (!provider) return;
    memset(provider, 0, sizeof(*provider));
    provider->worldType = 1;
    provider->hasNoSky = 1;
    CloneMCJ_WorldProvider_GenerateLightBrightnessTable(provider);
}

void CloneMCJ_WorldProviderSky_GetSkyColor(float celestialAngle,
    float *red, float *green, float *blue)
{
    (void)celestialAngle;
    /* WorldProviderEnd.getFogColor: 0x8080a0 multiplied by 0.15. */
    if (red) *red = (128.0F / 255.0F) * 0.15F;
    if (green) *green = (128.0F / 255.0F) * 0.15F;
    if (blue) *blue = (160.0F / 255.0F) * 0.15F;
}

void CloneMCJ_WorldProviderSky_Register(void)
{
    /* Runtime state is value-owned by World. */
}

const char *CloneMCJ_WorldProviderSky_JavaName(void)
{
    return "net.minecraft.src.WorldProviderSky";
}

const char *CloneMCJ_WorldProviderSky_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldProviderSky_JavaSourceHash32(void)
{
    return 0x38A24CF7UL;
}
