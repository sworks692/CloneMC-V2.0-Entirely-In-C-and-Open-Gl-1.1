/*
 * V136 parity layer.
 *
 * EntityVillager/Village/VillageCollection and EntityDragon are unusually
 * stateful Java classes.  This file keeps their large, rarely-used state out
 * of every CloneMCJ_Mob and in the fixed GameplayState pools.  All arrays are
 * bounded for Windows 9x and no allocation occurs in a tick.
 */
#include "clonemc_java_port_20_entity.h"

enum {
    V136_DRAGON_HEAD=0,V136_DRAGON_BODY,V136_DRAGON_TAIL1,
    V136_DRAGON_TAIL2,V136_DRAGON_TAIL3,V136_DRAGON_WING1,
    V136_DRAGON_WING2
};

static CloneMCJ_Mob *V136FindMobByEntityId(CloneMCJ_GameplayState *,int);

static double V136DistanceSquared(double ax,double ay,double az,
    double bx,double by,double bz)
{
    double dx,dy,dz;dx=ax-bx;dy=ay-by;dz=az-bz;
    return dx*dx+dy*dy+dz*dz;
}

static void V136RecalculateVillage(CloneMCJ_VillageNative *village)
{
    int i,sumX,sumY,sumZ,furthest,dx,dy,dz,distance;
    if(!village)return;
    sumX=sumY=sumZ=furthest=0;village->doorCount=0;
    for(i=0;i<CLONEMC_J_MAX_VILLAGE_DOORS;++i)
        if(village->doors[i].active){
            ++village->doorCount;sumX+=village->doors[i].x;
            sumY+=village->doors[i].y;sumZ+=village->doors[i].z;
        }
    if(village->doorCount<=0){memset(village,0,sizeof(*village));return;}
    village->centerX=sumX/village->doorCount;
    village->centerY=sumY/village->doorCount;
    village->centerZ=sumZ/village->doorCount;
    for(i=0;i<CLONEMC_J_MAX_VILLAGE_DOORS;++i)
        if(village->doors[i].active){
            dx=village->doors[i].x-village->centerX;
            dy=village->doors[i].y-village->centerY;
            dz=village->doors[i].z-village->centerZ;
            distance=dx*dx+dy*dy+dz*dz;
            if(distance>furthest)furthest=distance;
        }
    village->radius=(int)sqrt((double)furthest)+1;
    if(village->radius<32)village->radius=32;
    village->active=1;
}

static CloneMCJ_VillageNative *V136NearestVillage(
    CloneMCJ_GameplayState *state,int x,int y,int z,int extra)
{
    CloneMCJ_VillageNative *best,*village;
    int i,dx,dy,dz,range,distance,bestDistance;
    if(!state)return (CloneMCJ_VillageNative *)0;
    best=(CloneMCJ_VillageNative *)0;bestDistance=0x7fffffff;
    for(i=0;i<CLONEMC_J_MAX_VILLAGES;++i){
        village=&state->villages[i];if(!village->active)continue;
        dx=x-village->centerX;dy=y-village->centerY;dz=z-village->centerZ;
        distance=dx*dx+dy*dy+dz*dz;range=village->radius+extra;
        if(distance<=range*range&&distance<bestDistance){
            best=village;bestDistance=distance;
        }
    }
    return best;
}

void CloneMCJ_V136_RegisterVillageDoor(CloneMCJ_World *world,
    int x,int y,int z,int direction)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_VillageNative *village;
    CloneMCJ_VillageDoorNative *door;
    int i,j,slot,dx,dz;
    static const signed char insideX[4]={0,-1,0,1};
    static const signed char insideZ[4]={1,0,-1,0};
    if(!world||!world->gameplayUserData)return;
    state=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(state->world!=world)return;
    for(i=0;i<CLONEMC_J_MAX_VILLAGES;++i)
        for(j=0;j<CLONEMC_J_MAX_VILLAGE_DOORS;++j)
            if(state->villages[i].doors[j].active&&
               state->villages[i].doors[j].x==x&&
               state->villages[i].doors[j].y==y&&
               state->villages[i].doors[j].z==z){
                state->villages[i].doors[j].lastActivityTick=state->ticksRun;
                return;
            }
    village=V136NearestVillage(state,x,y,z,32);
    if(!village){
        for(i=0;i<CLONEMC_J_MAX_VILLAGES;++i)
            if(!state->villages[i].active)break;
        if(i>=CLONEMC_J_MAX_VILLAGES)return;
        village=&state->villages[i];memset(village,0,sizeof(*village));
        village->active=1;village->centerX=x;village->centerY=y;
        village->centerZ=z;village->radius=32;
    }
    slot=-1;
    for(i=0;i<CLONEMC_J_MAX_VILLAGE_DOORS;++i)
        if(!village->doors[i].active){slot=i;break;}
    if(slot<0)return;
    door=&village->doors[slot];memset(door,0,sizeof(*door));
    door->active=1;door->x=x;door->y=y;door->z=z;
    dx=(int)insideX[direction&3];dz=(int)insideZ[direction&3];
    door->insideX=dx;door->insideZ=dz;
    door->lastActivityTick=state->ticksRun;
    V136RecalculateVillage(village);
}

static int V136FindFreeMob(CloneMCJ_GameplayState *state)
{
    int i;for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(!state->mobs[i].active)return i;return -1;
}

static void V136TickVillagerPopulation(CloneMCJ_GameplayState *state,
    CloneMCJ_VillageNative *village)
{
    CloneMCJ_Mob *child;
    int i,count;
    double d1;
    count=0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i){
        child=&state->mobs[i];
        if(!child->active||child->health<=0||
           child->type!=CLONEMC_J_MOB_VILLAGER)continue;
        d1=V136DistanceSquared(child->entity.posX,child->entity.posY,
            child->entity.posZ,(double)village->centerX,
            (double)village->centerY,(double)village->centerZ);
        if(d1>(double)(village->radius*village->radius))continue;
        ++count;
    }
    village->population=count;
}

void CloneMCJ_V136_TickWorldSystems(CloneMCJ_GameplayState *state)
{
    CloneMCJ_VillageNative *village;
    CloneMCJ_VillageDoorNative *door;
    int i,j,dirty;
    if(!state||!state->world)return;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&
           state->mobs[i].type==CLONEMC_J_MOB_VILLAGER){
            if(state->mobs[i].growingAge<0)++state->mobs[i].growingAge;
            else if(state->mobs[i].growingAge>0)--state->mobs[i].growingAge;
        }
    if((state->ticksRun%20UL)!=0UL)return;
    for(i=0;i<CLONEMC_J_MAX_VILLAGES;++i){
        village=&state->villages[i];if(!village->active)continue;
        dirty=0;
        for(j=0;j<CLONEMC_J_MAX_VILLAGE_DOORS;++j){
            door=&village->doors[j];if(!door->active)continue;
            if(CloneMCJ_World_GetLoadedBlockId(state->world,
                door->x,door->y,door->z)!=64||
               state->ticksRun-door->lastActivityTick>1200UL){
                door->active=0;dirty=1;
            }else door->lastActivityTick=state->ticksRun;
        }
        if(dirty)V136RecalculateVillage(village);
        if(village->active)V136TickVillagerPopulation(state,village);
        village->lastUpdateTick=state->ticksRun;
    }
}

static CloneMCJ_VillageDoorNative *V136NearestDoor(
    CloneMCJ_VillageNative *village,double x,double y,double z)
{
    CloneMCJ_VillageDoorNative *best,*door;
    double distance,bestDistance;int i;
    best=(CloneMCJ_VillageDoorNative *)0;bestDistance=1.0e30;
    if(!village)return best;
    for(i=0;i<CLONEMC_J_MAX_VILLAGE_DOORS;++i){
        door=&village->doors[i];if(!door->active)continue;
        distance=V136DistanceSquared(x,y,z,(double)door->x,
            (double)door->y,(double)door->z);
        if(distance<bestDistance){best=door;bestDistance=distance;}
    }
    return best;
}

static int V136VillageCanBreed(const CloneMCJ_VillageNative *village)
{
    int capacity;
    if(!village)return 0;
    capacity=(int)((double)village->doorCount*0.35);
    return village->population<capacity;
}

static void V136ResetVillagerMate(CloneMCJ_Mob *mob)
{
    if(!mob)return;
    mob->villagerMateEntityId=0;mob->villagerMateTicks=0;
    mob->inLove=0;
}

static int V136FinishVillagerMating(CloneMCJ_GameplayState *state,
    CloneMCJ_VillageNative *village,CloneMCJ_Mob *first,CloneMCJ_Mob *second)
{
    CloneMCJ_Mob *child;int slot;
    if(!state||!village||!first||!second||
       !V136VillageCanBreed(village))return 0;
    slot=V136FindFreeMob(state);if(slot<0)return 0;
    child=&state->mobs[slot];
    CloneMCJ_EntityLiving_InitializeMob(child,CLONEMC_J_MOB_VILLAGER,
        state->world,first->entity.posX,first->entity.posY,
        first->entity.posZ);
    child->growingAge=-24000;child->renderScale=0.5F;
    child->profession=CloneMCJavaRandom_NextIntBound(
        &first->entity.rand,5);
    child->persistenceRequired=1;
    if(state->nextEntityId<=child->entity.entityId)
        state->nextEntityId=child->entity.entityId+1;
    first->growingAge=second->growingAge=6000;
    V136ResetVillagerMate(first);V136ResetVillagerMate(second);
    if(slot>=state->mobCount)state->mobCount=slot+1;
    ++village->population;return 1;
}

/*
 * EntityAIVillagerMate: a per-villager 1/500 start roll, an adult mate inside
 * an 8x3x8 search box, and the full 300-tick courtship.  Both native mobs hold
 * the pairing so the lower entity id alone performs the final spawn.
 */
static int V136TickVillagerMate(CloneMCJ_GameplayState *state,
    CloneMCJ_VillageNative *village,CloneMCJ_Mob *mob)
{
    CloneMCJ_Mob *mate,*other;double distance,best;int i;
    if(!state||!mob||mob->growingAge!=0||!V136VillageCanBreed(village)){
        V136ResetVillagerMate(mob);return 0;
    }
    if(mob->villagerMateTicks>0){
        mate=V136FindMobByEntityId(state,mob->villagerMateEntityId);
        if(!mate||mate->type!=CLONEMC_J_MOB_VILLAGER||
           mate->health<=0||mate->growingAge!=0||
           mate->villagerMateEntityId!=mob->entity.entityId){
            V136ResetVillagerMate(mob);return 0;
        }
        --mob->villagerMateTicks;
        if((mob->villagerMateTicks%35)==0)mob->inLove=5;
        else if(mob->inLove>0)--mob->inLove;
        distance=V136DistanceSquared(mob->entity.posX,mob->entity.posY,
            mob->entity.posZ,mate->entity.posX,mate->entity.posY,
            mate->entity.posZ);
        if(distance>2.25){
            mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePath(
                state->world,&mob->entity,mate->entity.posX,
                mate->entity.posY,mate->entity.posZ,16.0F,&mob->path);
            mob->moveSpeed=0.5F;mob->pathAge=0;
        }else if(mob->villagerMateTicks==0&&
                 mob->entity.entityId<mate->entity.entityId)
            V136FinishVillagerMating(state,village,mob,mate);
        return 1;
    }
    if(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,500)!=0)return 0;
    mate=(CloneMCJ_Mob *)0;best=1.0e30;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i){
        other=&state->mobs[i];
        if(other==mob||!other->active||other->health<=0||
           other->type!=CLONEMC_J_MOB_VILLAGER||
           other->growingAge!=0||other->villagerMateTicks>0)continue;
        if(fabs(other->entity.posX-mob->entity.posX)>8.0||
           fabs(other->entity.posY-mob->entity.posY)>3.0||
           fabs(other->entity.posZ-mob->entity.posZ)>8.0)continue;
        distance=V136DistanceSquared(mob->entity.posX,mob->entity.posY,
            mob->entity.posZ,other->entity.posX,other->entity.posY,
            other->entity.posZ);
        if(distance<best){best=distance;mate=other;}
    }
    if(!mate)return 0;
    mob->villagerMateEntityId=mate->entity.entityId;
    mate->villagerMateEntityId=mob->entity.entityId;
    mob->villagerMateTicks=mate->villagerMateTicks=300;
    mob->inLove=mate->inLove=5;return 1;
}

static int V136TickVillagerPlay(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob)
{
    CloneMCJ_Mob *playmate,*other;double distance,best;int i;
    if(!state||!mob||mob->growingAge>=0){
        if(mob){mob->villagerPlayTicks=0;
            mob->villagerPlaymateEntityId=0;}return 0;
    }
    if(mob->villagerPlayTicks>0){
        --mob->villagerPlayTicks;
        playmate=V136FindMobByEntityId(state,mob->villagerPlaymateEntityId);
        if(playmate&&playmate->type==CLONEMC_J_MOB_VILLAGER&&
           playmate->growingAge<0){
            distance=V136DistanceSquared(mob->entity.posX,mob->entity.posY,
                mob->entity.posZ,playmate->entity.posX,
                playmate->entity.posY,playmate->entity.posZ);
            if(distance>4.0&&!mob->hasPath){
                mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePath(
                    state->world,&mob->entity,playmate->entity.posX,
                    playmate->entity.posY,playmate->entity.posZ,
                    16.0F,&mob->path);
                mob->moveSpeed=0.64F;mob->pathAge=0;
            }
        }else mob->villagerPlaymateEntityId=0;
        if(mob->villagerPlayTicks==0)mob->villagerPlaymateEntityId=0;
        return 1;
    }
    if(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,400)!=0)return 0;
    playmate=(CloneMCJ_Mob *)0;best=1.0e30;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i){
        other=&state->mobs[i];
        if(other==mob||!other->active||
           other->type!=CLONEMC_J_MOB_VILLAGER||
           other->growingAge>=0||other->villagerPlayTicks>0)continue;
        if(fabs(other->entity.posX-mob->entity.posX)>6.0||
           fabs(other->entity.posY-mob->entity.posY)>3.0||
           fabs(other->entity.posZ-mob->entity.posZ)>6.0)continue;
        distance=V136DistanceSquared(mob->entity.posX,mob->entity.posY,
            mob->entity.posZ,other->entity.posX,other->entity.posY,
            other->entity.posZ);
        if(distance<=best){best=distance;playmate=other;}
    }
    mob->villagerPlayTicks=1000;
    mob->villagerPlaymateEntityId=playmate?
        playmate->entity.entityId:0;
    if(!playmate&&!mob->hasPath){
        int tx,tz;
        tx=CloneMCJava_FloorDouble(mob->entity.posX)+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,33)-16;
        tz=CloneMCJava_FloorDouble(mob->entity.posZ)+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,33)-16;
        mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePath(
            state->world,&mob->entity,(double)tx+0.5,mob->entity.posY,
            (double)tz+0.5,20.0F,&mob->path);
        mob->moveSpeed=0.64F;mob->pathAge=0;
    }
    return 1;
}

void CloneMCJ_V136_TickVillager(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_VillageNative *village;
    CloneMCJ_VillageDoorNative *door;
    CloneMCJ_Mob *other,*zombie;
    CloneMCJ_World *world;
    double dx,dz,distance,best;
    int i,night,raining,targetX,targetY,targetZ,metadata,restrictedAction;
    if(!mob||mob->type!=CLONEMC_J_MOB_VILLAGER||
       !mob->entity.worldObj)return;
    world=mob->entity.worldObj;
    state=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(!state||state->world!=world)return;
    if(--mob->villagerAITimer<=0){
        mob->villagerAITimer=70+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,50);
        village=V136NearestVillage(state,
            CloneMCJava_FloorDouble(mob->entity.posX),
            CloneMCJava_FloorDouble(mob->entity.posY),
            CloneMCJava_FloorDouble(mob->entity.posZ),32);
        if(village){
            mob->villagerHomeX=village->centerX;
            mob->villagerHomeY=village->centerY;
            mob->villagerHomeZ=village->centerZ;
            mob->villagerHomeRadius=village->radius;
        }else mob->villagerHomeRadius=0;
    }
    village=V136NearestVillage(state,
        CloneMCJava_FloorDouble(mob->entity.posX),
        CloneMCJava_FloorDouble(mob->entity.posY),
        CloneMCJava_FloorDouble(mob->entity.posZ),32);
    /* Priority 1: EntityAIAvoidEntity(EntityZombie, 8, .3, .35). */
    zombie=(CloneMCJ_Mob *)0;best=64.0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i){
        other=&state->mobs[i];
        if(!other->active||other->health<=0||
           other->type!=CLONEMC_J_MOB_ZOMBIE)continue;
        distance=V136DistanceSquared(mob->entity.posX,mob->entity.posY,
            mob->entity.posZ,other->entity.posX,other->entity.posY,
            other->entity.posZ);
        if(distance<best){best=distance;zombie=other;}
    }
    if(zombie){
        dx=mob->entity.posX-zombie->entity.posX;
        dz=mob->entity.posZ-zombie->entity.posZ;
        distance=sqrt(dx*dx+dz*dz);if(distance<0.01)distance=0.01;
        targetX=CloneMCJava_FloorDouble(mob->entity.posX+dx/distance*12.0);
        targetY=CloneMCJava_FloorDouble(mob->entity.posY);
        targetZ=CloneMCJava_FloorDouble(mob->entity.posZ+dz/distance*12.0);
        mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePath(world,
            &mob->entity,(double)targetX+0.5,(double)targetY,
            (double)targetZ+0.5,16.0F,&mob->path);
        mob->moveSpeed=best<49.0?0.70F:0.60F;
        mob->pathAge=0;mob->pathRecalcDelay=20;return;
    }
    mob->moveSpeed=0.5F;
    /* Priorities 2-5: seek and open a village door after dusk/in rain, or
     * return to the village restriction when outside its radius. */
    night=(world->worldTime%24000L)>=12000L;
    raining=world->worldInfo.raining?1:0;
    restrictedAction=0;
    if(village&&((night||raining)&&
       CloneMCJavaRandom_NextIntBound(&mob->entity.rand,50)==0)){
        door=V136NearestDoor(village,mob->entity.posX,
            mob->entity.posY,mob->entity.posZ);
        if(door){
            targetX=door->x+door->insideX*2;
            targetY=door->y;targetZ=door->z+door->insideZ*2;
            mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePath(world,
                &mob->entity,(double)targetX+0.5,(double)targetY,
                (double)targetZ+0.5,32.0F,&mob->path);
            mob->pathAge=0;mob->pathRecalcDelay=30;
            restrictedAction=mob->hasPath?1:0;
            if(V136DistanceSquared(mob->entity.posX,mob->entity.posY,
                mob->entity.posZ,(double)door->x,(double)door->y,
                (double)door->z)<4.0){
                metadata=CloneMCJ_World_GetBlockMetadata(world,
                    door->x,door->y,door->z);
                if(!(metadata&4))CloneMCJ_World_SetBlockMetadataNotify(
                    world,door->x,door->y,door->z,metadata|4);
            }
        }
    }else if(village&&V136DistanceSquared(mob->entity.posX,
        mob->entity.posY,mob->entity.posZ,(double)village->centerX,
        (double)village->centerY,(double)village->centerZ)>
        (double)(village->radius*village->radius)){
        mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePath(world,
            &mob->entity,(double)village->centerX+0.5,
            (double)village->centerY,(double)village->centerZ+0.5,
            32.0F,&mob->path);
        mob->pathAge=0;mob->pathRecalcDelay=30;
        restrictedAction=mob->hasPath?1:0;
    }
    /* Priorities 6 and 8: the uploaded EntityAIVillagerMate and EntityAIPlay
     * state machines, including their 300/1000 tick execution windows. */
    if(restrictedAction)return;
    if(V136TickVillagerMate(state,village,mob))return;
    V136TickVillagerPlay(state,mob);
    (void)player;
}

/* Minecraft Java 1.2.3 EntityVillager has village AI and professions but no
 * merchant recipes.  V144 restores CloneMC's explicitly post-1.2.3 bounded
 * extension: five deterministic offers per profession, two inputs, one
 * protected output, finite use counts and persistent use exhaustion. */
static void V136SetTrade(CloneMCJ_Mob *mob,int slot,int buy,int buyCount,
    int buy2,int buy2Count,int sell,int sellCount,int maximumUses)
{
    CloneMCJ_VillagerTrade *trade;
    if(!mob||slot<0||slot>=CLONEMC_J_MAX_VILLAGER_TRADES)return;
    trade=&mob->trades[slot];memset(trade,0,sizeof(*trade));
    trade->buyItemID=(short)buy;trade->buyCount=(short)buyCount;
    trade->secondBuyItemID=(short)buy2;
    trade->secondBuyCount=(short)buy2Count;
    trade->sellItemID=(short)sell;trade->sellCount=(short)sellCount;
    trade->maximumUses=(short)maximumUses;
}

void CloneMCJ_V136_InitializeVillagerTrades(CloneMCJ_Mob *mob)
{
    short savedUses[CLONEMC_J_MAX_VILLAGER_TRADES];
    int i;
    if(!mob||mob->tradesInitialized)return;
    for(i=0;i<CLONEMC_J_MAX_VILLAGER_TRADES;++i)
        savedUses[i]=mob->trades[i].uses;
    memset(mob->trades,0,sizeof(mob->trades));mob->tradeCount=5;
    switch(mob->profession){
    case 0:
        V136SetTrade(mob,0,296,18,0,0,388,1,7);
        V136SetTrade(mob,1,35,18,0,0,388,1,7);
        V136SetTrade(mob,2,388,1,0,0,297,3,12);
        V136SetTrade(mob,3,388,1,0,0,262,8,12);
        V136SetTrade(mob,4,388,3,0,0,359,1,5);break;
    case 1:
        V136SetTrade(mob,0,339,24,0,0,388,1,7);
        V136SetTrade(mob,1,340,12,0,0,388,1,7);
        V136SetTrade(mob,2,388,3,0,0,47,1,12);
        V136SetTrade(mob,3,388,1,0,0,20,5,12);
        V136SetTrade(mob,4,388,10,0,0,345,1,5);break;
    case 2:
        V136SetTrade(mob,0,266,4,0,0,388,1,7);
        V136SetTrade(mob,1,388,1,0,0,331,4,12);
        V136SetTrade(mob,2,388,1,0,0,351,2,12);
        V136SetTrade(mob,3,388,3,0,0,348,2,12);
        V136SetTrade(mob,4,388,7,0,0,368,1,5);break;
    case 3:
        V136SetTrade(mob,0,263,16,0,0,388,1,7);
        V136SetTrade(mob,1,265,8,0,0,388,1,7);
        V136SetTrade(mob,2,388,7,0,0,257,1,7);
        V136SetTrade(mob,3,388,8,0,0,267,1,7);
        V136SetTrade(mob,4,388,12,0,0,306,1,5);break;
    default:
        V136SetTrade(mob,0,319,14,0,0,388,1,7);
        V136SetTrade(mob,1,363,14,0,0,388,1,7);
        V136SetTrade(mob,2,365,14,0,0,388,1,7);
        V136SetTrade(mob,3,388,1,0,0,320,5,12);
        V136SetTrade(mob,4,388,7,0,0,329,1,5);break;
    }
    for(i=0;i<mob->tradeCount;++i){
        mob->trades[i].uses=savedUses[i];
        if(mob->trades[i].uses<0)mob->trades[i].uses=0;
        if(mob->trades[i].uses>mob->trades[i].maximumUses)
            mob->trades[i].uses=mob->trades[i].maximumUses;
    }
    mob->selectedTrade=0;mob->tradesInitialized=1;
}

static void V136AddMerchantPlayerSlots(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory)
{
    int row,column,index;
    container->playerSlotStart=container->slotCount;
    for(row=0;row<3;++row)for(column=0;column<9;++column){
        index=column+(row+1)*9;
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[index],64,CLONEMC_J_SLOT_NORMAL,
            -1,index,8+column*18,84+row*18);
    }
    container->hotbarSlotStart=container->slotCount;
    for(column=0;column<9;++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column],64,CLONEMC_J_SLOT_NORMAL,
            -1,column,8+column*18,142);
    container->hotbarSlotEnd=container->slotCount-1;
    container->playerSlotEnd=container->hotbarSlotEnd;
}

static int V136StackMatches(const CloneMCJ_ItemStack *stack,int id,int count)
{
    if(id<=0)return CloneMCJ_ItemStack_IsEmpty(stack);
    return stack&&!CloneMCJ_ItemStack_IsEmpty(stack)&&
        stack->itemID==id&&stack->stackSize>=count;
}

void CloneMCJ_V136_RefreshMerchantResult(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *mob;CloneMCJ_VillagerTrade *trade;
    if(!state||state->openContainer.type!=CLONEMC_J_CONTAINER_MERCHANT||
       state->openMerchantMobIndex<0||
       state->openMerchantMobIndex>=CLONEMC_J_MAX_MOBS)return;
    mob=&state->mobs[state->openMerchantMobIndex];
    CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[2]);
    if(!mob->active||mob->selectedTrade<0||
       mob->selectedTrade>=mob->tradeCount)return;
    trade=&mob->trades[mob->selectedTrade];
    if(trade->uses>=trade->maximumUses)return;
    if(!V136StackMatches(&state->openContainerTile.items[0],
        trade->buyItemID,trade->buyCount)||
       !V136StackMatches(&state->openContainerTile.items[1],
        trade->secondBuyItemID,trade->secondBuyCount))return;
    CloneMCJ_ItemStack_Initialize(&state->openContainerTile.items[2],
        trade->sellItemID,trade->sellCount,trade->sellItemDamage);
}

int CloneMCJ_V136_OpenMerchant(CloneMCJ_GameplayState *state,int mobIndex)
{
    CloneMCJ_Mob *mob;int i;
    if(!state||mobIndex<0||mobIndex>=CLONEMC_J_MAX_MOBS)return 0;
    mob=&state->mobs[mobIndex];
    if(!mob->active||mob->health<=0||
       mob->type!=CLONEMC_J_MOB_VILLAGER)return 0;
    if(state->openContainerActive)CloneMCJ_Gameplay_CloseOpenContainer(state);
    CloneMCJ_V136_InitializeVillagerTrades(mob);
    memset(&state->openContainerTile,0,sizeof(state->openContainerTile));
    state->openContainerTile.itemCount=3;
    for(i=0;i<3;++i)
        CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[i]);
    CloneMCJ_Container_Initialize(&state->openContainer);
    state->openContainer.type=CLONEMC_J_CONTAINER_MERCHANT;
    state->openContainer.playerInventory=&state->player.inventory;
    state->openContainer.tileEntity=&state->openContainerTile;
    state->openContainer.tileSlotStart=0;
    CloneMCJ_Container_AddTypedSlot(&state->openContainer,
        &state->openContainerTile.items[0],64,CLONEMC_J_SLOT_NORMAL,
        -1,0,36,31);
    CloneMCJ_Container_AddTypedSlot(&state->openContainer,
        &state->openContainerTile.items[1],64,CLONEMC_J_SLOT_NORMAL,
        -1,1,62,31);
    CloneMCJ_Container_AddTypedSlot(&state->openContainer,
        &state->openContainerTile.items[2],64,
        CLONEMC_J_SLOT_MERCHANT_OUTPUT,-1,2,120,31);
    state->openContainer.tileSlotEnd=2;
    V136AddMerchantPlayerSlots(&state->openContainer,
        &state->player.inventory);
    state->openMerchantMobIndex=mobIndex;
    mob->customerEntityId=state->player.entity.entityId;
    state->openContainerActive=1;state->openContainerIsBlock=0;
    CloneMCJ_V136_RefreshMerchantResult(state);
    return 1;
}

int CloneMCJ_V136_SelectMerchantTrade(CloneMCJ_GameplayState *state,int index)
{
    CloneMCJ_Mob *mob;
    if(!state||state->openContainer.type!=CLONEMC_J_CONTAINER_MERCHANT||
       state->openMerchantMobIndex<0)return 0;
    mob=&state->mobs[state->openMerchantMobIndex];
    if(index<0||index>=mob->tradeCount)return 0;
    mob->selectedTrade=index;CloneMCJ_V136_RefreshMerchantResult(state);
    return 1;
}

int CloneMCJ_V136_CompleteMerchantTrade(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *mob;CloneMCJ_VillagerTrade *trade;
    CloneMCJ_ItemStack output,*carried;int room;
    if(!state||state->openContainer.type!=CLONEMC_J_CONTAINER_MERCHANT||
       state->openMerchantMobIndex<0)return 0;
    mob=&state->mobs[state->openMerchantMobIndex];
    if(!mob->active||mob->selectedTrade<0||
       mob->selectedTrade>=mob->tradeCount)return 0;
    trade=&mob->trades[mob->selectedTrade];
    CloneMCJ_V136_RefreshMerchantResult(state);
    if(CloneMCJ_ItemStack_IsEmpty(&state->openContainerTile.items[2]))return 0;
    output=state->openContainerTile.items[2];
    carried=&state->player.inventory.carriedStack;
    if(!CloneMCJ_ItemStack_IsEmpty(carried)){
        if(!CloneMCJ_ItemStack_IsStackableWith(carried,&output))return 0;
        room=CloneMCJ_ItemStack_GetMaxStackSize(carried)-carried->stackSize;
        if(room<output.stackSize)return 0;
        carried->stackSize+=output.stackSize;
    }else *carried=output;
    state->openContainerTile.items[0].stackSize-=trade->buyCount;
    if(state->openContainerTile.items[0].stackSize<=0)
        CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[0]);
    if(trade->secondBuyItemID>0){
        state->openContainerTile.items[1].stackSize-=trade->secondBuyCount;
        if(state->openContainerTile.items[1].stackSize<=0)
            CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[1]);
    }
    ++trade->uses;state->player.inventory.inventoryChanged=1;
    CloneMCJ_V136_RefreshMerchantResult(state);return 1;
}

static CloneMCJ_DragonNative *V136DragonState(CloneMCJ_GameplayState *state,
    int entityId,int create)
{
    int i,freeSlot;freeSlot=-1;
    if(!state||entityId<=0)return (CloneMCJ_DragonNative *)0;
    for(i=0;i<CLONEMC_J_MAX_DRAGONS;++i){
        if(state->dragons[i].active&&state->dragons[i].entityId==entityId)
            return &state->dragons[i];
        if(!state->dragons[i].active&&freeSlot<0)freeSlot=i;
    }
    if(!create||freeSlot<0)return (CloneMCJ_DragonNative *)0;
    memset(&state->dragons[freeSlot],0,sizeof(state->dragons[freeSlot]));
    state->dragons[freeSlot].active=1;
    state->dragons[freeSlot].entityId=entityId;
    state->dragons[freeSlot].historyIndex=-1;
    return &state->dragons[freeSlot];
}

const CloneMCJ_DragonNative *CloneMCJ_V136_GetDragonState(
    const CloneMCJ_GameplayState *state,int entityId)
{
    int i;if(!state)return (const CloneMCJ_DragonNative *)0;
    for(i=0;i<CLONEMC_J_MAX_DRAGONS;++i)
        if(state->dragons[i].active&&state->dragons[i].entityId==entityId)
            return &state->dragons[i];
    return (const CloneMCJ_DragonNative *)0;
}

static CloneMCJ_Mob *V136FindMobByEntityId(CloneMCJ_GameplayState *state,
    int entityId)
{
    int i;
    if(!state||entityId<=0)return (CloneMCJ_Mob *)0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&
           state->mobs[i].entity.entityId==entityId)return &state->mobs[i];
    return (CloneMCJ_Mob *)0;
}

/*
 * EntityDragon.updateDragonEnderCrystal retains its selected crystal between
 * scans.  Healing occurs every ten dragon ticks, while destroying that
 * selected crystal routes ten points of explosion damage through the head.
 */
static void V136UpdateDragonCrystal(CloneMCJ_GameplayState *state,
    CloneMCJ_DragonNative *dragon,CloneMCJ_Mob *mob)
{
    CloneMCJ_Mob *crystal,*candidate;
    double distance,best;
    int i;
    if(!state||!dragon||!mob)return;
    crystal=V136FindMobByEntityId(state,dragon->healingCrystalEntityId);
    if(dragon->healingCrystalEntityId!=0&&
       (!crystal||crystal->health<=0||
        crystal->type!=CLONEMC_J_MOB_ENDER_CRYSTAL)){
        CloneMCJ_EntityLiving_AttackMobFrom(mob,
            (const CloneMCJ_Entity *)0,10);
        dragon->healingCrystalEntityId=0;crystal=(CloneMCJ_Mob *)0;
    }else if(crystal&&(mob->entity.ticksExisted%10)==0&&
             mob->health<mob->maxHealth)++mob->health;
    if(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,10)!=0)return;
    best=1024.0;candidate=(CloneMCJ_Mob *)0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&state->mobs[i].health>0&&
           state->mobs[i].type==CLONEMC_J_MOB_ENDER_CRYSTAL){
            distance=V136DistanceSquared(mob->entity.posX,
                mob->entity.posY,mob->entity.posZ,
                state->mobs[i].entity.posX,state->mobs[i].entity.posY,
                state->mobs[i].entity.posZ);
            if(distance<best){best=distance;candidate=&state->mobs[i];}
        }
    dragon->healingCrystalEntityId=candidate?
        candidate->entity.entityId:0;
}

static void V136DragonHistory(const CloneMCJ_DragonNative *dragon,int back,
    double result[3])
{
    int index;if(!dragon||dragon->historyIndex<0){
        result[0]=result[1]=result[2]=0.0;return;}
    index=(dragon->historyIndex-back)&63;
    result[0]=dragon->history[index][0];
    result[1]=dragon->history[index][1];
    result[2]=dragon->history[index][2];
}

static double V136WrapAngle(double value)
{
    while(value>=180.0)value-=360.0;
    while(value<-180.0)value+=360.0;return value;
}

static void V136SetDragonPart(CloneMCJ_DragonPartNative *part,
    double x,double y,double z,float width,float height)
{
    part->x=x;part->y=y;part->z=z;part->width=width;part->height=height;
}

static int V136DragonDestroyBox(CloneMCJ_World *world,
    const CloneMCJ_DragonPartNative *part)
{
    int x,y,z,minX,maxX,minY,maxY,minZ,maxZ,id,protectedBlock;
    if(!world||!part)return 0;protectedBlock=0;
    minX=CloneMCJava_FloorDouble(part->x-(double)part->width*0.5);
    maxX=CloneMCJava_FloorDouble(part->x+(double)part->width*0.5);
    minY=CloneMCJava_FloorDouble(part->y);
    maxY=CloneMCJava_FloorDouble(part->y+(double)part->height);
    minZ=CloneMCJava_FloorDouble(part->z-(double)part->width*0.5);
    maxZ=CloneMCJava_FloorDouble(part->z+(double)part->width*0.5);
    for(x=minX;x<=maxX;++x)for(y=minY;y<=maxY;++y)
        for(z=minZ;z<=maxZ;++z){
            id=CloneMCJ_World_GetLoadedBlockId(world,x,y,z);if(!id)continue;
            if(id==49||id==121||id==7)protectedBlock=1;
            else CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
        }
    return protectedBlock;
}

static void V136UpdateDragonParts(CloneMCJ_DragonNative *dragon,
    CloneMCJ_Mob *mob,CloneMCJ_EntityPlayer *player)
{
    double a5[3],a0[3],a[3],yaw,curve,cosCurve,sinCurve;
    double bodyX,bodyZ,dx,dz,d2;float sy,cy,tailYaw;
    int i;
    V136DragonHistory(dragon,5,a5);V136DragonHistory(dragon,0,a0);
    /* The expression above cannot be represented by a Java temporary-array
     * alias in C; fetch history 10 explicitly. */
    V136DragonHistory(dragon,10,a);
    curve=((a5[1]-a[1])*10.0/180.0)*3.14159265358979323846;
    cosCurve=cos(curve);sinCurve=-sin(curve);
    yaw=(double)mob->entity.rotationYaw*3.14159265358979323846/180.0;
    sy=(float)sin(yaw);cy=(float)cos(yaw);
    bodyX=mob->entity.posX+(double)sy*0.5;
    bodyZ=mob->entity.posZ-(double)cy*0.5;
    V136SetDragonPart(&dragon->parts[V136_DRAGON_BODY],bodyX,
        mob->entity.posY,bodyZ,5.0F,3.0F);
    V136SetDragonPart(&dragon->parts[V136_DRAGON_WING1],
        mob->entity.posX+(double)cy*4.5,mob->entity.posY+2.0,
        mob->entity.posZ+(double)sy*4.5,4.0F,2.0F);
    V136SetDragonPart(&dragon->parts[V136_DRAGON_WING2],
        mob->entity.posX-(double)cy*4.5,mob->entity.posY+2.0,
        mob->entity.posZ-(double)sy*4.5,4.0F,3.0F);
    tailYaw=(float)(yaw-(double)mob->randomYawVelocity*0.01);
    V136SetDragonPart(&dragon->parts[V136_DRAGON_HEAD],
        mob->entity.posX+sin((double)tailYaw)*5.5*cosCurve,
        mob->entity.posY+(a0[1]-a5[1])+sinCurve*5.5,
        mob->entity.posZ-cos((double)tailYaw)*5.5*cosCurve,3.0F,3.0F);
    for(i=0;i<3;++i){
        V136DragonHistory(dragon,12+i*2,a);
        tailYaw=(float)(yaw+V136WrapAngle(a[0]-a5[0])*
            3.14159265358979323846/180.0);
        V136SetDragonPart(&dragon->parts[V136_DRAGON_TAIL1+i],
            mob->entity.posX-((double)sy*1.5+
                sin((double)tailYaw)*(double)(i+1)*2.0)*cosCurve,
            mob->entity.posY+(a[1]-a5[1])-
                ((double)(i+1)*2.0+1.5)*sinCurve+1.5,
            mob->entity.posZ+((double)cy*1.5+
                cos((double)tailYaw)*(double)(i+1)*2.0)*cosCurve,
            2.0F,2.0F);
    }
    if(!player||mob->attackTime>0)return;
    if(player->entity.posX>=dragon->parts[V136_DRAGON_HEAD].x-2.5&&
       player->entity.posX<=dragon->parts[V136_DRAGON_HEAD].x+2.5&&
       player->entity.posY+player->entity.height>=
            dragon->parts[V136_DRAGON_HEAD].y-1.0&&
       player->entity.posY<=dragon->parts[V136_DRAGON_HEAD].y+
            dragon->parts[V136_DRAGON_HEAD].height+1.0&&
       player->entity.posZ>=dragon->parts[V136_DRAGON_HEAD].z-2.5&&
       player->entity.posZ<=dragon->parts[V136_DRAGON_HEAD].z+2.5){
        CloneMCJ_EntityPlayer_AttackFrom(player,&mob->entity,10);
        mob->attackTime=10;return;
    }
    for(i=V136_DRAGON_WING1;i<=V136_DRAGON_WING2;++i){
        if(player->entity.posX>=dragon->parts[i].x-6.0&&
           player->entity.posX<=dragon->parts[i].x+6.0&&
           player->entity.posY+player->entity.height>=
                dragon->parts[i].y-2.0&&
           player->entity.posY<=dragon->parts[i].y+
                dragon->parts[i].height+2.0&&
           player->entity.posZ>=dragon->parts[i].z-6.0&&
           player->entity.posZ<=dragon->parts[i].z+6.0){
            dx=player->entity.posX-
                dragon->parts[V136_DRAGON_BODY].x;
            dz=player->entity.posZ-
                dragon->parts[V136_DRAGON_BODY].z;d2=dx*dx+dz*dz;
            if(d2<0.01)d2=0.01;
            player->entity.motionX+=dx/d2*4.0;
            player->entity.motionY+=0.2;
            player->entity.motionZ+=dz/d2*4.0;
        }
    }
}

void CloneMCJ_V136_UpdateDragon(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_GameplayState *state;CloneMCJ_DragonNative *dragon;
    CloneMCJ_Entity *entity;double dx,dy,dz,distance,horizontal;
    double targetYaw,delta,speed,forwardX,forwardZ,dot,alignment;
    double targetDX,targetDY,targetDZ,targetLength,motionLength;
    float increment;int i;
    if(!mob||!mob->entity.worldObj)return;entity=&mob->entity;
    state=(CloneMCJ_GameplayState *)entity->worldObj->gameplayUserData;
    dragon=V136DragonState(state,entity->entityId,1);if(!dragon)return;
    V136UpdateDragonCrystal(state,dragon,mob);
    if(mob->health<=0)return;
    dragon->previousAnimation=dragon->animation;
    speed=sqrt(entity->motionX*entity->motionX+
        entity->motionZ*entity->motionZ);
    increment=0.2F/(float)(speed*10.0+1.0);
    increment*=(float)pow(2.0,entity->motionY);
    if(dragon->slowedByProtectedBlock)increment*=0.5F;
    dragon->animation+=increment;
    while(entity->rotationYaw>=180.0F)entity->rotationYaw-=360.0F;
    while(entity->rotationYaw<-180.0F)entity->rotationYaw+=360.0F;
    if(dragon->historyIndex<0){
        for(i=0;i<64;++i){
            dragon->history[i][0]=(double)entity->rotationYaw;
            dragon->history[i][1]=entity->posY;
            dragon->history[i][2]=0.0;
        }
        dragon->historyIndex=0;dragon->initialized=1;
    }else dragon->historyIndex=(dragon->historyIndex+1)&63;
    dragon->history[dragon->historyIndex][0]=(double)entity->rotationYaw;
    dragon->history[dragon->historyIndex][1]=entity->posY;
    dragon->history[dragon->historyIndex][2]=0.0;
    dx=mob->waypointX-entity->posX;dy=mob->waypointY-entity->posY;
    dz=mob->waypointZ-entity->posZ;distance=dx*dx+dy*dy+dz*dz;
    if(player&&mob->targetEntityId==player->entity.entityId){
        mob->waypointX=player->entity.posX;mob->waypointZ=player->entity.posZ;
        horizontal=sqrt(dx*dx+dz*dz);
        mob->waypointY=player->entity.boundingBox.minY+
            ((0.4+horizontal/80.0)-1.0>10.0?
            10.0:(0.4+horizontal/80.0)-1.0);
    }else{
        mob->waypointX+=CloneMCJavaRandom_NextGaussian(&entity->rand)*2.0;
        mob->waypointZ+=CloneMCJavaRandom_NextGaussian(&entity->rand)*2.0;
    }
    if(distance<100.0||distance>22500.0||
       entity->collidedHorizontally||entity->collidedVertically){
        if(player&&CloneMCJavaRandom_NextIntBound(&entity->rand,2)==0){
            mob->targetEntityId=player->entity.entityId;
            mob->waypointX=player->entity.posX;
            mob->waypointY=player->entity.posY+4.0;
            mob->waypointZ=player->entity.posZ;
        }else{
            mob->targetEntityId=0;
            do{
                mob->waypointX=(CloneMCJavaRandom_NextFloat(
                    &entity->rand)*120.0F)-60.0F;
                mob->waypointY=70.0+
                    CloneMCJavaRandom_NextFloat(&entity->rand)*50.0F;
                mob->waypointZ=(CloneMCJavaRandom_NextFloat(
                    &entity->rand)*120.0F)-60.0F;
                dx=entity->posX-mob->waypointX;
                dy=entity->posY-mob->waypointY;
                dz=entity->posZ-mob->waypointZ;
            }while(dx*dx+dy*dy+dz*dz<=100.0);
        }
    }
    dx=mob->waypointX-entity->posX;dy=mob->waypointY-entity->posY;
    dz=mob->waypointZ-entity->posZ;
    horizontal=sqrt(dx*dx+dz*dz);if(horizontal<0.001)horizontal=0.001;
    dy/=horizontal;if(dy<-.6)dy=-.6;if(dy>.6)dy=.6;
    entity->motionY+=dy*.1;
    targetYaw=180.0-atan2(dx,dz)*180.0/3.14159265358979323846;
    delta=V136WrapAngle(targetYaw-(double)entity->rotationYaw);
    if(delta>50.0)delta=50.0;if(delta<-50.0)delta=-50.0;
    speed=sqrt(entity->motionX*entity->motionX+
        entity->motionZ*entity->motionZ)+1.0;
    horizontal=speed;if(horizontal>40.0)horizontal=40.0;
    forwardX=sin((double)entity->rotationYaw*
        3.14159265358979323846/180.0);
    forwardZ=-cos((double)entity->rotationYaw*
        3.14159265358979323846/180.0);
    targetDX=mob->waypointX-entity->posX;
    targetDY=mob->waypointY-entity->posY;
    targetDZ=mob->waypointZ-entity->posZ;
    targetLength=sqrt(targetDX*targetDX+targetDY*targetDY+
        targetDZ*targetDZ);
    if(targetLength<0.001)targetLength=0.001;
    motionLength=sqrt(forwardX*forwardX+
        entity->motionY*entity->motionY+forwardZ*forwardZ);
    if(motionLength<0.001)motionLength=0.001;
    dot=(forwardX/motionLength)*(targetDX/targetLength)+
        (entity->motionY/motionLength)*(targetDY/targetLength)+
        (forwardZ/motionLength)*(targetDZ/targetLength);
    alignment=(dot+0.5)/1.5;if(alignment<0.0)alignment=0.0;
    mob->randomYawVelocity*=0.8F;
    mob->randomYawVelocity+=(float)(delta*(0.7/horizontal/speed));
    entity->rotationYaw+=mob->randomYawVelocity*0.1F;
    speed=2.0/(horizontal+1.0);
    entity->motionX+=sin((double)entity->rotationYaw*
        3.14159265358979323846/180.0)*0.06*
        (alignment*speed+(1.0-speed));
    entity->motionZ+=-cos((double)entity->rotationYaw*
        3.14159265358979323846/180.0)*0.06*
        (alignment*speed+(1.0-speed));
    CloneMCJ_Entity_Move(entity,
        entity->motionX*(dragon->slowedByProtectedBlock?0.8:1.0),
        entity->motionY*(dragon->slowedByProtectedBlock?0.8:1.0),
        entity->motionZ*(dragon->slowedByProtectedBlock?0.8:1.0));
    motionLength=sqrt(entity->motionX*entity->motionX+
        entity->motionY*entity->motionY+
        entity->motionZ*entity->motionZ);
    if(motionLength<0.001)motionLength=0.001;
    targetLength=sqrt(forwardX*forwardX+
        entity->motionY*entity->motionY+forwardZ*forwardZ);
    if(targetLength<0.001)targetLength=0.001;
    dot=(entity->motionX/motionLength)*(forwardX/targetLength)+
        (entity->motionY/motionLength)*(entity->motionY/targetLength)+
        (entity->motionZ/motionLength)*(forwardZ/targetLength);
    alignment=0.8+0.15*((dot+1.0)/2.0);
    entity->motionX*=alignment;entity->motionZ*=alignment;
    entity->motionY*=0.91;mob->renderYawOffset=entity->rotationYaw;
    V136UpdateDragonParts(dragon,mob,player);
    dragon->slowedByProtectedBlock=(unsigned char)(
        V136DragonDestroyBox(entity->worldObj,
            &dragon->parts[V136_DRAGON_HEAD])|
        V136DragonDestroyBox(entity->worldObj,
            &dragon->parts[V136_DRAGON_BODY]));
}

static int V136ApplyDragonPartDamage(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob,const CloneMCJ_Entity *source,int part,int damage)
{
    double yaw;
    if(!state||!mob||part<0||part>=CLONEMC_J_DRAGON_PART_COUNT)return 0;
    if(part!=V136_DRAGON_HEAD)damage=damage/4+1;
    yaw=(double)mob->entity.rotationYaw*
        3.14159265358979323846/180.0;
    mob->waypointX=mob->entity.posX+sin(yaw)*5.0+
        (CloneMCJavaRandom_NextFloat(&mob->entity.rand)-0.5F)*2.0F;
    mob->waypointY=mob->entity.posY+
        CloneMCJavaRandom_NextFloat(&mob->entity.rand)*3.0F+1.0F;
    mob->waypointZ=mob->entity.posZ-cos(yaw)*5.0+
        (CloneMCJavaRandom_NextFloat(&mob->entity.rand)-0.5F)*2.0F;
    mob->targetEntityId=0;
    return CloneMCJ_EntityLiving_AttackMobFrom(mob,source,damage);
}

int CloneMCJ_V136_DamageDragonAt(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob,const CloneMCJ_Entity *source,double x,double y,
    double z,int damage)
{
    const CloneMCJ_DragonNative *dragon;int i;
    if(!state||!mob||mob->type!=CLONEMC_J_MOB_ENDER_DRAGON||
       damage<=0)return 0;
    dragon=CloneMCJ_V136_GetDragonState(state,mob->entity.entityId);
    if(!dragon)return 0;
    for(i=0;i<CLONEMC_J_DRAGON_PART_COUNT;++i)
        if(x>=dragon->parts[i].x-dragon->parts[i].width*0.5-0.35&&
           x<=dragon->parts[i].x+dragon->parts[i].width*0.5+0.35&&
           y>=dragon->parts[i].y-0.35&&
           y<=dragon->parts[i].y+dragon->parts[i].height+0.35&&
           z>=dragon->parts[i].z-dragon->parts[i].width*0.5-0.35&&
           z<=dragon->parts[i].z+dragon->parts[i].width*0.5+0.35)
            return V136ApplyDragonPartDamage(state,mob,source,i,damage);
    return 0;
}

int CloneMCJ_V136_DamageDragon(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob,int damage)
{
    const CloneMCJ_DragonNative *dragon;double yaw,pitch,lookX,lookY,lookZ;
    double originX,originY,originZ,bestT,tMin,tMax,t1,t2,swap;
    double minimum[3],maximum[3],origin[3],direction[3];
    int i,axis,part;
    if(!state||!mob||mob->type!=CLONEMC_J_MOB_ENDER_DRAGON)return 0;
    dragon=CloneMCJ_V136_GetDragonState(state,mob->entity.entityId);
    part=-1;bestT=5.0;
    yaw=(double)state->player.entity.rotationYaw*
        3.14159265358979323846/180.0;
    pitch=(double)state->player.entity.rotationPitch*
        3.14159265358979323846/180.0;
    lookX=-sin(yaw)*cos(pitch);lookZ=cos(yaw)*cos(pitch);
    lookY=-sin(pitch);
    originX=state->player.entity.posX;
    originY=state->player.entity.posY+1.62;
    originZ=state->player.entity.posZ;
    origin[0]=originX;origin[1]=originY;origin[2]=originZ;
    direction[0]=lookX;direction[1]=lookY;direction[2]=lookZ;
    if(dragon)for(i=0;i<CLONEMC_J_DRAGON_PART_COUNT;++i){
        minimum[0]=dragon->parts[i].x-dragon->parts[i].width*0.5;
        maximum[0]=dragon->parts[i].x+dragon->parts[i].width*0.5;
        minimum[1]=dragon->parts[i].y;
        maximum[1]=dragon->parts[i].y+dragon->parts[i].height;
        minimum[2]=dragon->parts[i].z-dragon->parts[i].width*0.5;
        maximum[2]=dragon->parts[i].z+dragon->parts[i].width*0.5;
        tMin=0.0;tMax=5.0;
        for(axis=0;axis<3;++axis){
            if(fabs(direction[axis])<0.000001){
                if(origin[axis]<minimum[axis]||
                   origin[axis]>maximum[axis]){tMin=6.0;break;}
            }else{
                t1=(minimum[axis]-origin[axis])/direction[axis];
                t2=(maximum[axis]-origin[axis])/direction[axis];
                if(t1>t2){swap=t1;t1=t2;t2=swap;}
                if(t1>tMin)tMin=t1;if(t2<tMax)tMax=t2;
                if(tMax<tMin){tMin=6.0;break;}
            }
        }
        if(tMin>=0.0&&tMin<=bestT){bestT=tMin;part=i;}
    }
    if(part<0)return 0;
    return V136ApplyDragonPartDamage(state,mob,&state->player.entity,
        part,damage);
}

static void V136CreateEndPortal(CloneMCJ_World *world,int centerX,int centerZ)
{
    int y,x,z;double dx,dz,distance;const int baseY=64;
    for(y=baseY-1;y<=baseY+32;++y)
        for(x=centerX-4;x<=centerX+4;++x)
            for(z=centerZ-4;z<=centerZ+4;++z){
                dx=(double)(x-centerX);dz=(double)(z-centerZ);
                distance=sqrt(dx*dx+dz*dz);if(distance>3.5)continue;
                if(y<baseY){
                    if(distance<=2.5)CloneMCJ_World_SetBlockNotify(
                        world,x,y,z,7);
                }else if(y>baseY)CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
                else CloneMCJ_World_SetBlockNotify(world,x,y,z,
                    distance>2.5?7:119);
            }
    for(y=baseY;y<=baseY+3;++y)
        CloneMCJ_World_SetBlockNotify(world,centerX,y,centerZ,7);
    CloneMCJ_World_SetBlockWithMetadataNotify(world,
        centerX-1,baseY+2,centerZ,50,1);
    CloneMCJ_World_SetBlockWithMetadataNotify(world,
        centerX+1,baseY+2,centerZ,50,2);
    CloneMCJ_World_SetBlockWithMetadataNotify(world,
        centerX,baseY+2,centerZ-1,50,3);
    CloneMCJ_World_SetBlockWithMetadataNotify(world,
        centerX,baseY+2,centerZ+1,50,4);
    CloneMCJ_World_SetBlockNotify(world,centerX,baseY+4,centerZ,122);
}

int CloneMCJ_V136_TickDragonDeath(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob)
{
    CloneMCJ_DragonNative *dragon;
    if(!state||!mob)return 0;
    dragon=V136DragonState(state,mob->entity.entityId,1);if(!dragon)return 0;
    ++dragon->deathTicks;mob->deathTime=dragon->deathTicks;
    mob->entity.posY+=0.1;mob->entity.rotationYaw+=20.0F;
    mob->renderYawOffset=mob->entity.rotationYaw;
    if(dragon->deathTicks>150&&dragon->deathTicks%5==0)
        CloneMCJ_Progression_SpawnExperience(state,mob->entity.posX,
            mob->entity.posY,mob->entity.posZ,1000);
    if(dragon->deathTicks<200)return 0;
    CloneMCJ_Progression_SpawnExperience(state,mob->entity.posX,
        mob->entity.posY,mob->entity.posZ,10000);
    V136CreateEndPortal(state->world,
        CloneMCJava_FloorDouble(mob->entity.posX),
        CloneMCJava_FloorDouble(mob->entity.posZ));
    mob->lootDropped=1;mob->active=0;dragon->active=0;return 1;
}

int CloneMCJ_V136_RunGameplaySelfTests(char *message,unsigned int capacity)
{
    CloneMCJ_Mob villager;
    int ok;
    ok=V136WrapAngle(181.0)==-179.0&&V136WrapAngle(-181.0)==179.0;
    memset(&villager,0,sizeof(villager));
    villager.profession=0;
    CloneMCJ_V136_InitializeVillagerTrades(&villager);
    ok=ok&&villager.tradesInitialized&&villager.tradeCount==5&&
        villager.trades[0].buyItemID==296&&
        villager.trades[0].buyCount==18&&
        villager.trades[0].sellItemID==388&&
        villager.trades[0].sellCount==1&&
        villager.trades[0].maximumUses==7;
    if(message&&capacity)snprintf(message,capacity,ok?
        "V144 village/dragon/trading fixed-state tests passed":
        "V144 village/dragon/trading fixed-state test failed");
    return ok;
}
