/*
 * CloneMC fixed-capacity post-Beta progression extension.
 *
 * This module deliberately keeps the later mechanics separate from the Beta
 * simulation.  It uses release-era numeric IDs and behavior, but stores at
 * most three enchantments and four active effects per object.  There are no
 * per-tick allocations, hash tables, or unbounded lists.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>
#include <string.h>

static int CloneMCJ_Progression_XPThreshold(int level)
{
    if(level<0)level=0;
    /* EntityPlayer.xpBarCap in the uploaded 1.2.3 source.  The piecewise
     * formula previously used here belongs to substantially later releases. */
    return 7+((level*7)>>1);
}

void CloneMCJ_Progression_AddExperience(CloneMCJ_EntityPlayer *player, int amount)
{
    int threshold;
    float points;
    if (!player || amount <= 0) return;
    if (player->experienceTotal <= 0x7FFFFFFF - amount)
        player->experienceTotal += amount;
    else
        player->experienceTotal = 0x7FFFFFFF;
    points = player->experienceProgress *
        (float)CloneMCJ_Progression_XPThreshold(player->experienceLevel);
    points += (float)amount;
    threshold = CloneMCJ_Progression_XPThreshold(player->experienceLevel);
    while (points >= (float)threshold && player->experienceLevel < 21863) {
        points -= (float)threshold;
        ++player->experienceLevel;
        threshold = CloneMCJ_Progression_XPThreshold(player->experienceLevel);
    }
    player->experienceProgress = threshold > 0 ?
        points / (float)threshold : 0.0F;
}

static int CloneMCJ_Progression_XPSplit(int amount)
{
    if (amount >= 2477) return 2477;
    if (amount >= 1237) return 1237;
    if (amount >= 617) return 617;
    if (amount >= 307) return 307;
    if (amount >= 149) return 149;
    if (amount >= 73) return 73;
    if (amount >= 37) return 37;
    if (amount >= 17) return 17;
    if (amount >= 7) return 7;
    if (amount >= 3) return 3;
    return 1;
}

void CloneMCJ_Progression_SpawnExperience(CloneMCJ_GameplayState *state,
    double x,double y,double z,int amount)
{
    int i;
    int value;
    CloneMCJ_ExperienceOrb *orb;
    if(!state||!state->world||amount<=0)return;
    while(amount>0){
        value=CloneMCJ_Progression_XPSplit(amount);
        for(i=0;i<CLONEMC_J_MAX_EXPERIENCE_ORBS;++i)
            if(!state->experienceOrbs[i].active)break;
        if(i>=CLONEMC_J_MAX_EXPERIENCE_ORBS){
            /*
             * Coalesce instead of dropping XP or allocating.  The first live
             * orb remains collectable and preserves the total reward.
             */
            orb=&state->experienceOrbs[0];
            if(orb->active&&orb->value<=0x7FFFFFFF-amount)
                orb->value+=amount;
            else
                CloneMCJ_Progression_AddExperience(&state->player,amount);
            return;
        }
        orb=&state->experienceOrbs[i];
        memset(orb,0,sizeof(*orb));
        CloneMCJ_Entity_Initialize(&orb->entity,state->world);
        CloneMCJ_Entity_SetSize(&orb->entity,0.5F,0.5F);
        CloneMCJ_Entity_SetPosition(&orb->entity,x,y,z);
        orb->entity.entityId=state->nextEntityId++;
        orb->entity.motionX=(CloneMCJavaRandom_NextFloat(
            &state->player.entity.rand)-0.5F)*0.2F;
        orb->entity.motionY=0.2F;
        orb->entity.motionZ=(CloneMCJavaRandom_NextFloat(
            &state->player.entity.rand)-0.5F)*0.2F;
        orb->value=value;
        orb->pickupDelay=2;
        orb->active=1;
        if(i>=state->experienceOrbCount)state->experienceOrbCount=i+1;
        amount-=value;
    }
}

void CloneMCJ_Progression_TickExperienceOrbs(CloneMCJ_GameplayState *state)
{
    int i;
    int chunkX;
    int chunkZ;
    double dx,dy,dz,distance,attraction;
    float groundFriction;
    int blockId;
    const CloneMCJ_BlockDefinition *block;
    CloneMCJ_ExperienceOrb *orb;
    if(!state||!state->world)return;
    for(i=0;i<state->experienceOrbCount;++i){
        orb=&state->experienceOrbs[i];
        if(!orb->active)continue;
        chunkX=CloneMCJ_World_GlobalToChunk(
            CloneMCJava_FloorDouble(orb->entity.posX));
        chunkZ=CloneMCJ_World_GlobalToChunk(
            CloneMCJava_FloorDouble(orb->entity.posZ));
        /*
         * Match the dropped-item chunk-safety contract: unloaded chunks freeze
         * the orb and its despawn clock, so neither gravity nor age can make it
         * disappear through an absent collision map.
         */
        if(!CloneMCJ_World_IsChunkLoaded(state->world,chunkX,chunkZ))continue;
        orb->entity.prevPosX=orb->entity.posX;
        orb->entity.prevPosY=orb->entity.posY;
        orb->entity.prevPosZ=orb->entity.posZ;
        if(orb->pickupDelay>0)--orb->pickupDelay;
        orb->entity.motionY-=0.03;
        blockId=CloneMCJ_World_GetLoadedBlockId(state->world,
            CloneMCJava_FloorDouble(orb->entity.posX),
            CloneMCJava_FloorDouble(orb->entity.posY),
            CloneMCJava_FloorDouble(orb->entity.posZ));
        if(blockId==10||blockId==11){
            orb->entity.motionY=0.2;
            orb->entity.motionX=(CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand)-CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand))*0.2F;
            orb->entity.motionZ=(CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand)-CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand))*0.2F;
        }
        dx=state->player.entity.posX-orb->entity.posX;
        dy=state->player.entity.posY+state->player.entity.height*0.5-
            orb->entity.posY;
        dz=state->player.entity.posZ-orb->entity.posZ;
        distance=sqrt(dx*dx+dy*dy+dz*dz);
        if(distance>0.001&&distance<8.0){
            attraction=1.0-distance/8.0;
            attraction=attraction*attraction*0.1;
            orb->entity.motionX+=dx/distance*attraction;
            orb->entity.motionY+=dy/distance*attraction;
            orb->entity.motionZ+=dz/distance*attraction;
        }
        CloneMCJ_Entity_Move(&orb->entity,orb->entity.motionX,
            orb->entity.motionY,orb->entity.motionZ);
        groundFriction=0.98F;
        if(orb->entity.onGround){
            groundFriction=0.5880001F;
            blockId=CloneMCJ_World_GetLoadedBlockId(state->world,
                CloneMCJava_FloorDouble(orb->entity.posX),
                CloneMCJava_FloorDouble(orb->entity.boundingBox.minY)-1,
                CloneMCJava_FloorDouble(orb->entity.posZ));
            block=CloneMCJ_BlockRegistry_Get(blockId);
            if(blockId>0&&block)groundFriction=block->slipperiness*0.98F;
        }
        orb->entity.motionX*=groundFriction;
        orb->entity.motionY*=0.98;
        orb->entity.motionZ*=groundFriction;
        if(orb->entity.onGround){
            orb->entity.motionY*=-0.9;
        }
        ++orb->age;
        dx=state->player.entity.posX-orb->entity.posX;
        dy=state->player.entity.posY+0.5-orb->entity.posY;
        dz=state->player.entity.posZ-orb->entity.posZ;
        if(orb->pickupDelay<=0&&dx*dx+dy*dy+dz*dz<2.25){
            CloneMCJ_Progression_AddExperience(&state->player,orb->value);
            orb->active=0;
        }else if(orb->age>=6000||orb->entity.posY<-64.0)
            orb->active=0;
    }
    while(state->experienceOrbCount>0&&
          !state->experienceOrbs[state->experienceOrbCount-1].active)
        --state->experienceOrbCount;
}

int CloneMCJ_Progression_HasEffect(const CloneMCJ_EntityPlayer *player,
    int effectId, int *amplifier)
{
    int i;
    if (amplifier) *amplifier = 0;
    if (!player) return 0;
    for (i = 0; i < CLONEMC_J_MAX_ACTIVE_EFFECTS; ++i)
        if (player->activeEffectDuration[i] > 0 &&
            player->activeEffectId[i] == effectId) {
            if (amplifier) *amplifier = player->activeEffectAmplifier[i];
            return 1;
        }
    return 0;
}

static void CloneMCJ_Progression_AddEffect(CloneMCJ_EntityPlayer *player,
    int effectId, int duration, int amplifier)
{
    int i;
    int replacement;
    if (!player || duration <= 0) return;
    replacement = 0;
    for (i = 0; i < CLONEMC_J_MAX_ACTIVE_EFFECTS; ++i) {
        if (player->activeEffectDuration[i] <= 0 ||
            player->activeEffectId[i] == effectId) {
            replacement = i;
            break;
        }
        if (player->activeEffectDuration[i] <
            player->activeEffectDuration[replacement]) replacement = i;
    }
    if (player->activeEffectId[replacement] == effectId &&
        player->activeEffectAmplifier[replacement] > amplifier &&
        player->activeEffectDuration[replacement] >= duration) return;
    player->activeEffectId[replacement] = (unsigned char)effectId;
    player->activeEffectAmplifier[replacement] = (unsigned char)amplifier;
    player->activeEffectDuration[replacement] = duration;
}

static int CloneMCJ_Progression_MobIsUndead(const CloneMCJ_Mob *mob)
{
    if(!mob)return 0;
    return mob->type==CLONEMC_J_MOB_ZOMBIE||
        mob->type==CLONEMC_J_MOB_GIANT||
        mob->type==CLONEMC_J_MOB_PIG_ZOMBIE||
        mob->type==CLONEMC_J_MOB_SKELETON;
}

static void CloneMCJ_Progression_AddMobEffect(CloneMCJ_Mob *mob,
    int effectId,int duration,int amplifier)
{
    int index;
    int replacement;
    if(!mob||duration<=0)return;
    replacement=0;
    for(index=0;index<CLONEMC_J_MAX_ACTIVE_EFFECTS;++index){
        if(mob->activeEffectDuration[index]<=0||
           mob->activeEffectId[index]==effectId){replacement=index;break;}
        if(mob->activeEffectDuration[index]<
           mob->activeEffectDuration[replacement])replacement=index;
    }
    if(mob->activeEffectId[replacement]==effectId&&
       mob->activeEffectAmplifier[replacement]>amplifier&&
       mob->activeEffectDuration[replacement]>=duration)return;
    mob->activeEffectId[replacement]=(unsigned char)effectId;
    mob->activeEffectAmplifier[replacement]=(unsigned char)amplifier;
    mob->activeEffectDuration[replacement]=duration;
}

static void CloneMCJ_Progression_ApplyInstantToPlayer(
    CloneMCJ_EntityPlayer *player,int effectId,int amplifier,double factor)
{
    int amount;
    if(!player)return;
    amount=(int)(factor*(double)(6<<amplifier)+0.5);
    if(amount<=0)return;
    if(effectId==CLONEMC_J_EFFECT_HEAL){
        player->health+=amount;
        if(player->health>20)player->health=20;
    }else if(effectId==CLONEMC_J_EFFECT_HARM)
        CloneMCJ_EntityPlayer_AttackFrom(player,
            (const CloneMCJ_Entity *)0,amount);
}

static void CloneMCJ_Progression_ApplyInstantToMob(CloneMCJ_Mob *mob,
    int effectId,int amplifier,double factor)
{
    int amount;
    int heals;
    if(!mob)return;
    amount=(int)(factor*(double)(6<<amplifier)+0.5);
    if(amount<=0)return;
    heals=(effectId==CLONEMC_J_EFFECT_HEAL&&
        !CloneMCJ_Progression_MobIsUndead(mob))||
        (effectId==CLONEMC_J_EFFECT_HARM&&
        CloneMCJ_Progression_MobIsUndead(mob));
    if(heals){
        mob->health+=amount;
        if(mob->health>mob->maxHealth)mob->health=mob->maxHealth;
    }else CloneMCJ_EntityLiving_AttackMobFrom(mob,
        (const CloneMCJ_Entity *)0,amount);
}

void CloneMCJ_Progression_ApplySplashPotion(CloneMCJ_GameplayState *state,
    double x,double y,double z,int damage)
{
    CloneMCJ_PotionEffectNative effects[16];
    CloneMCJ_Mob *mob;
    double dx;
    double dy;
    double dz;
    double distanceSquared;
    double factor;
    int effectCount;
    int effectIndex;
    int duration;
    int mobIndex;
    if(!state)return;
    effectCount=CloneMCJ_PotionHelper_GetEffects(damage,0,effects,16);
    if(effectCount<=0)return;
    dx=state->player.entity.posX-x;
    dy=state->player.entity.posY+0.9-y;
    dz=state->player.entity.posZ-z;
    distanceSquared=dx*dx+dy*dy+dz*dz;
    if(distanceSquared<16.0&&state->player.health>0){
        factor=1.0-sqrt(distanceSquared)/4.0;
        if(factor<0.0)factor=0.0;
        for(effectIndex=0;effectIndex<effectCount;++effectIndex){
            if(effects[effectIndex].instant)
                CloneMCJ_Progression_ApplyInstantToPlayer(&state->player,
                    effects[effectIndex].effectId,
                    effects[effectIndex].amplifier,factor);
            else{
                duration=(int)(factor*(double)effects[effectIndex].duration+0.5);
                if(duration>20)CloneMCJ_Progression_AddEffect(&state->player,
                    effects[effectIndex].effectId,duration,
                    effects[effectIndex].amplifier);
            }
        }
    }
    for(mobIndex=0;mobIndex<CLONEMC_J_MAX_MOBS;++mobIndex){
        mob=&state->mobs[mobIndex];
        if(!mob->active||mob->health<=0)continue;
        dx=mob->entity.posX-x;
        dy=mob->entity.posY+(double)mob->entity.height*0.5-y;
        dz=mob->entity.posZ-z;
        distanceSquared=dx*dx+dy*dy+dz*dz;
        if(distanceSquared>=16.0)continue;
        factor=1.0-sqrt(distanceSquared)/4.0;
        for(effectIndex=0;effectIndex<effectCount;++effectIndex){
            if(effects[effectIndex].instant)
                CloneMCJ_Progression_ApplyInstantToMob(mob,
                    effects[effectIndex].effectId,
                    effects[effectIndex].amplifier,factor);
            else{
                duration=(int)(factor*(double)effects[effectIndex].duration+0.5);
                if(duration>20)CloneMCJ_Progression_AddMobEffect(mob,
                    effects[effectIndex].effectId,duration,
                    effects[effectIndex].amplifier);
            }
        }
    }
}

void CloneMCJ_Progression_TickPlayerEffects(CloneMCJ_EntityPlayer *player)
{
    int index;
    int amplifier;
    int interval;
    if(!player)return;
    for(index=0;index<CLONEMC_J_MAX_ACTIVE_EFFECTS;++index){
        if(player->activeEffectDuration[index]<=0)continue;
        amplifier=player->activeEffectAmplifier[index];
        if(player->activeEffectId[index]==CLONEMC_J_EFFECT_REGENERATION||
           player->activeEffectId[index]==CLONEMC_J_EFFECT_POISON){
            interval=25>>amplifier;
            if(interval<1)interval=1;
            if((player->activeEffectDuration[index]%interval)==0){
                if(player->activeEffectId[index]==CLONEMC_J_EFFECT_REGENERATION&&
                   player->health>0&&player->health<20)++player->health;
                else if(player->activeEffectId[index]==CLONEMC_J_EFFECT_POISON&&
                    player->health>1)
                    CloneMCJ_EntityPlayer_AttackFrom(player,
                        (const CloneMCJ_Entity *)0,1);
            }
        }
        --player->activeEffectDuration[index];
        if(player->activeEffectDuration[index]<=0){
            player->activeEffectId[index]=0;
            player->activeEffectAmplifier[index]=0;
        }
    }
}

void CloneMCJ_Progression_TickMobEffects(CloneMCJ_Mob *mob)
{
    int index;
    int amplifier;
    int interval;
    if(!mob||!mob->active)return;
    for(index=0;index<CLONEMC_J_MAX_ACTIVE_EFFECTS;++index){
        if(mob->activeEffectDuration[index]<=0)continue;
        amplifier=mob->activeEffectAmplifier[index];
        if(mob->activeEffectId[index]==CLONEMC_J_EFFECT_REGENERATION||
           mob->activeEffectId[index]==CLONEMC_J_EFFECT_POISON){
            interval=25>>amplifier;
            if(interval<1)interval=1;
            if((mob->activeEffectDuration[index]%interval)==0){
                if(mob->activeEffectId[index]==CLONEMC_J_EFFECT_REGENERATION&&
                   mob->health>0&&mob->health<mob->maxHealth)++mob->health;
                else if(mob->activeEffectId[index]==CLONEMC_J_EFFECT_POISON&&
                    mob->health>1)
                    CloneMCJ_EntityLiving_AttackMobFrom(mob,
                        (const CloneMCJ_Entity *)0,1);
            }
        }
        --mob->activeEffectDuration[index];
        if(mob->activeEffectDuration[index]<=0){
            mob->activeEffectId[index]=0;
            mob->activeEffectAmplifier[index]=0;
        }
    }
}

int CloneMCJ_Progression_EnchantLevel(const CloneMCJ_ItemStack *stack,
    int enchantmentId)
{
    int i;
    if (!stack || CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    for (i = 0; i < (int)stack->enchantmentCount &&
         i < CLONEMC_J_MAX_ITEM_ENCHANTMENTS; ++i)
        if (stack->enchantmentId[i] == enchantmentId)
            return stack->enchantmentLevel[i];
    return 0;
}

int CloneMCJ_Progression_AttackPlayerProtected(
    CloneMCJ_EntityPlayer *player,const CloneMCJ_Entity *source,int damage,
    int protectionEnchantment)
{
    int i;
    int protection;
    if(!player||damage<=0)return 0;
    protection=0;
    for(i=0;i<CLONEMC_J_ARMOR_INVENTORY_SIZE;++i)
        protection+=CloneMCJ_Progression_EnchantLevel(
            &player->inventory.armorInventory[i],protectionEnchantment)*2;
    if(protection>20)protection=20;
    damage=damage*(25-protection)/25;
    if(damage<1)damage=1;
    return CloneMCJ_EntityPlayer_AttackFrom(player,source,damage);
}

static int CloneMCJ_Progression_CountBookshelves(CloneMCJ_World *world,
    int x, int y, int z)
{
    int dx;
    int dz;
    int count;
    if (!world) return 0;
    count = 0;
    for (dx = -1; dx <= 1 && count < 30; ++dx)
        for (dz = -1; dz <= 1 && count < 30; ++dz) {
            if (dx == 0 && dz == 0) continue;
            if (CloneMCJ_World_GetBlockId(world, x + dx, y, z + dz) != 0 ||
                CloneMCJ_World_GetBlockId(world, x + dx, y + 1, z + dz) != 0)
                continue;
            if (CloneMCJ_World_GetBlockId(world, x + dx * 2, y,
                z + dz * 2) == 47) ++count;
            if (count < 30 && CloneMCJ_World_GetBlockId(world, x + dx * 2,
                y + 1, z + dz * 2) == 47) ++count;
            if (dx != 0 && dz != 0) {
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx * 2, y, z + dz) == 47) ++count;
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx * 2, y + 1, z + dz) == 47) ++count;
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx, y, z + dz * 2) == 47) ++count;
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx, y + 1, z + dz * 2) == 47) ++count;
            }
        }
    return count;
}

static void CloneMCJ_Progression_RebuildOffers(CloneMCJ_GameplayState *state)
{
    int power;
    int base;
    int shelves;
    int offer;
    CloneMCJLong seed;
    if (!state) return;
    shelves = state->enchantmentBookshelves;
    if(shelves>30)shelves=30;
    if(!state->enchantmentRandomInitialized){
        seed=state->world?state->world->worldInfo.randomSeed:(CloneMCJLong)0;
        seed^=(CloneMCJLong)state->player.entity.entityId*
            ((CloneMCJLong)0x4F9939F5UL*(CloneMCJLong)256+
                (CloneMCJLong)8);
        seed^=(CloneMCJLong)state->ticksRun;
        CloneMCJavaRandom_SetSeed(&state->enchantmentRandom,seed);
        state->enchantmentRandomInitialized=1;
    }
    /* ContainerEnchantment.onCraftMatrixChanged first consumes nextLong for
     * EnchantmentNameParts, then computes all three costs from the same
     * persistent java.util.Random instance. */
    state->enchantmentSeed=(unsigned long)CloneMCJavaRandom_NextLong(
        &state->enchantmentRandom);
    for(offer=0;offer<3;++offer){
        power=1+(shelves>>1)+(int)CloneMCJavaRandom_NextIntBound(
            &state->enchantmentRandom,shelves+1);
        base=(int)CloneMCJavaRandom_NextIntBound(
            &state->enchantmentRandom,5)+power;
        if(offer==0)state->enchantmentOffers[offer]=(base>>1)+1;
        else if(offer==1)state->enchantmentOffers[offer]=base*2/3+1;
        else state->enchantmentOffers[offer]=base;
    }
}

void CloneMCJ_Progression_RefreshEnchantOffers(
    CloneMCJ_GameplayState *state)
{
    CloneMCJ_ItemStack *stack;
    const CloneMCJ_ItemDefinition *item;
    int enchantable;
    if(!state||state->openContainer.type!=
       CLONEMC_J_CONTAINER_ENCHANTMENT)return;
    stack=&state->openContainerTile.items[0];
    enchantable=0;
    if(!CloneMCJ_ItemStack_IsEmpty(stack)&&stack->enchantmentCount==0){
        item=CloneMCJ_ItemRegistry_Get(stack->itemID);
        enchantable=(stack->itemID>=298&&stack->itemID<=317)||
            (item&&item->toolClass!=CLONEMC_J_TOOL_NONE);
    }
    if(!enchantable){
        state->enchantmentOffers[0]=0;
        state->enchantmentOffers[1]=0;
        state->enchantmentOffers[2]=0;
        return;
    }
    CloneMCJ_Progression_RebuildOffers(state);
}

static void CloneMCJ_Progression_AddPlayerSlots(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, int inventoryY, int hotbarY)
{
    int row;
    int column;
    int index;
    container->playerSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 9; ++column) {
            index = column + (row + 1) * 9;
            CloneMCJ_Container_AddTypedSlot(container,
                &inventory->mainInventory[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 8 + column * 18, inventoryY + row * 18);
        }
    container->hotbarSlotStart = container->slotCount;
    for (column = 0; column < 9; ++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column], 64, CLONEMC_J_SLOT_NORMAL,
            -1, column, 8 + column * 18, hotbarY);
    container->hotbarSlotEnd = container->slotCount - 1;
    container->playerSlotEnd = container->hotbarSlotEnd;
}

int CloneMCJ_Progression_OpenBlock(CloneMCJ_GameplayState *state, int blockId,
    int x, int y, int z)
{
    int i;
    if (!state || !state->world || blockId != 116) return 0;
    CloneMCJ_Container_Initialize(&state->openContainer);
    memset(&state->openContainerTile, 0, sizeof(state->openContainerTile));
    state->openContainerTile.type = CLONEMC_J_TILE_NONE;
    state->openContainerTile.itemCount = 1;
    for (i = 0; i < CLONEMC_J_CHEST_INVENTORY_SIZE; ++i)
        CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[i]);
    state->openContainer.type = CLONEMC_J_CONTAINER_ENCHANTMENT;
    state->openContainer.playerInventory = &state->player.inventory;
    state->openContainer.tileEntity = &state->openContainerTile;
    state->openContainer.tileSlotStart = state->openContainer.slotCount;
    CloneMCJ_Container_AddTypedSlot(&state->openContainer,
        &state->openContainerTile.items[0], 1, CLONEMC_J_SLOT_ENCHANT_INPUT,
        -1, 0, 15, 47);
    state->openContainer.tileSlotEnd = state->openContainer.slotCount - 1;
    CloneMCJ_Progression_AddPlayerSlots(&state->openContainer,
        &state->player.inventory, 84, 142);
    state->enchantmentBookshelves =
        CloneMCJ_Progression_CountBookshelves(state->world, x, y, z);
    CloneMCJ_Progression_RefreshEnchantOffers(state);
    return 1;
}

static int CloneMCJ_Progression_IsArmor(int itemId)
{
    return itemId >= 298 && itemId <= 317;
}

typedef enum CloneMCJ_EnchantTypeTag {
    CLONEMC_J_ENCHANT_TYPE_ARMOR=0,
    CLONEMC_J_ENCHANT_TYPE_ARMOR_FEET,
    CLONEMC_J_ENCHANT_TYPE_ARMOR_HEAD,
    CLONEMC_J_ENCHANT_TYPE_WEAPON,
    CLONEMC_J_ENCHANT_TYPE_DIGGER,
    CLONEMC_J_ENCHANT_TYPE_BOW
} CloneMCJ_EnchantType;

typedef struct CloneMCJ_EnchantDefinitionTag {
    unsigned char id;
    unsigned char weight;
    unsigned char maxLevel;
    unsigned char type;
    signed char subtype;
} CloneMCJ_EnchantDefinition;

typedef struct CloneMCJ_ProgressionEnchantCandidateTag {
    int id;
    int level;
    int weight;
    unsigned char available;
} CloneMCJ_ProgressionEnchantCandidate;

static const CloneMCJ_EnchantDefinition g_cloneMCEnchantments[]={
    {0,10,4,CLONEMC_J_ENCHANT_TYPE_ARMOR,0},
    {1,5,4,CLONEMC_J_ENCHANT_TYPE_ARMOR,1},
    {2,5,4,CLONEMC_J_ENCHANT_TYPE_ARMOR_FEET,2},
    {3,2,4,CLONEMC_J_ENCHANT_TYPE_ARMOR,3},
    {4,5,4,CLONEMC_J_ENCHANT_TYPE_ARMOR,4},
    {5,2,3,CLONEMC_J_ENCHANT_TYPE_ARMOR_HEAD,-1},
    {6,2,1,CLONEMC_J_ENCHANT_TYPE_ARMOR_HEAD,-1},
    {16,10,5,CLONEMC_J_ENCHANT_TYPE_WEAPON,0},
    {17,5,5,CLONEMC_J_ENCHANT_TYPE_WEAPON,1},
    {18,5,5,CLONEMC_J_ENCHANT_TYPE_WEAPON,2},
    {19,5,2,CLONEMC_J_ENCHANT_TYPE_WEAPON,-1},
    {20,2,2,CLONEMC_J_ENCHANT_TYPE_WEAPON,-1},
    {21,2,3,CLONEMC_J_ENCHANT_TYPE_WEAPON,-1},
    {32,10,5,CLONEMC_J_ENCHANT_TYPE_DIGGER,-1},
    {33,1,1,CLONEMC_J_ENCHANT_TYPE_DIGGER,-1},
    {34,5,3,CLONEMC_J_ENCHANT_TYPE_DIGGER,-1},
    {35,2,3,CLONEMC_J_ENCHANT_TYPE_DIGGER,-1},
    {48,10,5,CLONEMC_J_ENCHANT_TYPE_BOW,-1},
    {49,2,2,CLONEMC_J_ENCHANT_TYPE_BOW,-1},
    {50,2,1,CLONEMC_J_ENCHANT_TYPE_BOW,-1},
    {51,1,1,CLONEMC_J_ENCHANT_TYPE_BOW,-1}
};

#define CLONEMC_J_ENCHANTMENT_DEFINITION_COUNT \
    ((int)(sizeof(g_cloneMCEnchantments)/sizeof(g_cloneMCEnchantments[0])))

static const CloneMCJ_EnchantDefinition *CloneMCJ_Progression_EnchantDef(
    int enchantmentId)
{
    int i;
    for(i=0;i<CLONEMC_J_ENCHANTMENT_DEFINITION_COUNT;++i)
        if(g_cloneMCEnchantments[i].id==enchantmentId)
            return &g_cloneMCEnchantments[i];
    return (const CloneMCJ_EnchantDefinition *)0;
}

static int CloneMCJ_Progression_ItemEnchantability(int itemId)
{
    if(itemId>=298&&itemId<=301)return 15;
    if(itemId>=302&&itemId<=305)return 12;
    if(itemId>=306&&itemId<=309)return 9;
    if(itemId>=310&&itemId<=313)return 10;
    if(itemId>=314&&itemId<=317)return 25;
    if(itemId==268||itemId==269||itemId==270||itemId==271||itemId==290)
        return 15;
    if((itemId>=272&&itemId<=275)||itemId==291)return 5;
    if(itemId==256||itemId==257||itemId==258||itemId==267||itemId==292)
        return 14;
    if((itemId>=276&&itemId<=279)||itemId==293)return 10;
    if((itemId>=283&&itemId<=286)||itemId==294)return 22;
    if(itemId==261)return 1;
    return 0;
}

static int CloneMCJ_Progression_EnchantMin(int enchantmentId,int level)
{
    static const int protectionBase[5]={1,10,5,5,3};
    static const int protectionStep[5]={16,8,6,8,6};
    static const int damageBase[3]={1,5,5};
    static const int damageStep[3]={16,8,8};
    const CloneMCJ_EnchantDefinition *definition;
    definition=CloneMCJ_Progression_EnchantDef(enchantmentId);
    if(!definition)return 1+level*10;
    if(enchantmentId>=0&&enchantmentId<=4)
        return protectionBase[definition->subtype]+(level-1)*
            protectionStep[definition->subtype];
    if(enchantmentId==5)return 10*level;
    if(enchantmentId==6)return 1;
    if(enchantmentId>=16&&enchantmentId<=18)
        return damageBase[definition->subtype]+(level-1)*
            damageStep[definition->subtype];
    if(enchantmentId==19)return 5+20*(level-1);
    if(enchantmentId==20)return 10+20*(level-1);
    if(enchantmentId==21||enchantmentId==35)return 20+(level-1)*12;
    if(enchantmentId==32)return 1+15*(level-1);
    if(enchantmentId==33)return 25;
    if(enchantmentId==34)return 5+(level-1)*10;
    if(enchantmentId==48)return 1+(level-1)*10;
    if(enchantmentId==49)return 12+(level-1)*20;
    if(enchantmentId==50||enchantmentId==51)return 20;
    return 1+level*10;
}

static int CloneMCJ_Progression_EnchantMax(int enchantmentId,int level)
{
    static const int protectionThreshold[5]={20,12,10,12,15};
    const CloneMCJ_EnchantDefinition *definition;
    int minimum;
    definition=CloneMCJ_Progression_EnchantDef(enchantmentId);
    minimum=CloneMCJ_Progression_EnchantMin(enchantmentId,level);
    if(!definition)return minimum+5;
    if(enchantmentId>=0&&enchantmentId<=4)
        return minimum+protectionThreshold[definition->subtype];
    if(enchantmentId==5)return minimum+30;
    if(enchantmentId==6)return minimum+40;
    if(enchantmentId>=16&&enchantmentId<=18)return minimum+20;
    if(enchantmentId==48)return minimum+15;
    if(enchantmentId==49)return minimum+25;
    if(enchantmentId==50||enchantmentId==51)return 50;
    /* These Java subclasses explicitly call Enchantment.getMinEnchantability
     * instead of their own override when computing the maximum. */
    return 51+level*10;
}

static int CloneMCJ_Progression_EnchantApplies(
    const CloneMCJ_ItemStack *stack,int enchantmentId)
{
    const CloneMCJ_EnchantDefinition *definition;
    const CloneMCJ_ItemDefinition *item;
    int armorType;
    if(!stack)return 0;
    definition=CloneMCJ_Progression_EnchantDef(enchantmentId);
    if(!definition)return 0;
    item=CloneMCJ_ItemRegistry_Get(stack->itemID);
    if(definition->type==CLONEMC_J_ENCHANT_TYPE_ARMOR)
        return CloneMCJ_Progression_IsArmor(stack->itemID);
    if(definition->type==CLONEMC_J_ENCHANT_TYPE_ARMOR_FEET||
       definition->type==CLONEMC_J_ENCHANT_TYPE_ARMOR_HEAD){
        if(!CloneMCJ_Progression_IsArmor(stack->itemID))return 0;
        armorType=(stack->itemID-298)%4;
        if(definition->type==CLONEMC_J_ENCHANT_TYPE_ARMOR_HEAD)
            return armorType==0;
        return armorType==3;
    }
    if(definition->type==CLONEMC_J_ENCHANT_TYPE_WEAPON)
        return item&&item->toolClass==CLONEMC_J_TOOL_SWORD;
    if(definition->type==CLONEMC_J_ENCHANT_TYPE_DIGGER)
        return item&&(item->toolClass==CLONEMC_J_TOOL_PICKAXE||
            item->toolClass==CLONEMC_J_TOOL_AXE||
            item->toolClass==CLONEMC_J_TOOL_SHOVEL);
    if(definition->type==CLONEMC_J_ENCHANT_TYPE_BOW)
        return stack->itemID==261;
    return 0;
}

static int CloneMCJ_Progression_BuildCandidates(const CloneMCJ_ItemStack *stack,
    int power,CloneMCJ_ProgressionEnchantCandidate *candidates)
{
    const CloneMCJ_EnchantDefinition *definition;
    int index;
    int level;
    int selectedLevel;
    int count;
    count=0;
    for(index=0;index<CLONEMC_J_ENCHANTMENT_DEFINITION_COUNT;++index){
        definition=&g_cloneMCEnchantments[index];
        if(!CloneMCJ_Progression_EnchantApplies(stack,definition->id))continue;
        /* EnchantmentHelper stores candidates in a HashMap keyed by the
         * Enchantment object.  Iterating levels therefore replaces the prior
         * value, leaving one entry at the highest matching level rather than
         * multiple weighted copies of the same enchantment. */
        selectedLevel=0;
        for(level=1;level<=definition->maxLevel;++level)
            if(power>=CloneMCJ_Progression_EnchantMin(definition->id,level)&&
               power<=CloneMCJ_Progression_EnchantMax(definition->id,level))
                selectedLevel=level;
        if(selectedLevel>0){
            candidates[count].id=definition->id;
            candidates[count].level=selectedLevel;
            candidates[count].weight=definition->weight;
            candidates[count].available=1;
            ++count;
        }
    }
    return count;
}

static int CloneMCJ_Progression_WeightedCandidate(CloneMCJavaRandom *random,
    CloneMCJ_ProgressionEnchantCandidate *candidates,int count)
{
    int index;
    int total;
    int choice;
    total=0;
    for(index=0;index<count;++index)
        if(candidates[index].available)total+=candidates[index].weight;
    if(total<=0)return -1;
    choice=(int)CloneMCJavaRandom_NextIntBound(random,total);
    for(index=0;index<count;++index)if(candidates[index].available){
        choice-=candidates[index].weight;
        if(choice<0)return index;
    }
    return -1;
}

static int CloneMCJ_Progression_EnchantsCompatible(int first,int second)
{
    const CloneMCJ_EnchantDefinition *firstDefinition;
    const CloneMCJ_EnchantDefinition *secondDefinition;
    if(first==second)return 0;
    firstDefinition=CloneMCJ_Progression_EnchantDef(first);
    secondDefinition=CloneMCJ_Progression_EnchantDef(second);
    if(!firstDefinition||!secondDefinition)return 1;
    if(first>=0&&first<=4&&second>=0&&second<=4)
        return first==CLONEMC_J_ENCHANT_FEATHER_FALLING||
            second==CLONEMC_J_ENCHANT_FEATHER_FALLING;
    if(first>=16&&first<=18&&second>=16&&second<=18)return 0;
    if((first==CLONEMC_J_ENCHANT_SILK_TOUCH&&
        second==CLONEMC_J_ENCHANT_FORTUNE)||
       (second==CLONEMC_J_ENCHANT_SILK_TOUCH&&
        first==CLONEMC_J_ENCHANT_FORTUNE))return 0;
    return 1;
}

int CloneMCJ_Progression_EnchantStackRandom(CloneMCJ_ItemStack *stack,
    int level,CloneMCJavaRandom *random)
{
    CloneMCJ_ProgressionEnchantCandidate candidates[64];
    int selectedIds[CLONEMC_J_MAX_ITEM_ENCHANTMENTS];
    int enchantability,power,candidateCount,selected,count,i,j,loopPower;
    float variance;
    if(!stack||!random||CloneMCJ_ItemStack_IsEmpty(stack)||
       stack->enchantmentCount>0||level<=0)return 0;
    enchantability=CloneMCJ_Progression_ItemEnchantability(stack->itemID);
    if(enchantability<=0)return 0;
    power=1+(int)CloneMCJavaRandom_NextIntBound(random,
        (enchantability>>1)+1)+(int)CloneMCJavaRandom_NextIntBound(random,
        (enchantability>>1)+1)+level;
    variance=(CloneMCJavaRandom_NextFloat(random)+
        CloneMCJavaRandom_NextFloat(random)-1.0F)*0.25F;
    power=(int)((float)power*(1.0F+variance)+0.5F);
    candidateCount=CloneMCJ_Progression_BuildCandidates(stack,power,candidates);
    selected=CloneMCJ_Progression_WeightedCandidate(random,candidates,
        candidateCount);
    if(selected<0)return 0;
    count=0;
    stack->enchantmentId[count]=(unsigned char)candidates[selected].id;
    stack->enchantmentLevel[count]=(unsigned char)candidates[selected].level;
    selectedIds[count]=candidates[selected].id;
    ++count;
    for(loopPower=power>>1;
        count<CLONEMC_J_MAX_ITEM_ENCHANTMENTS&&
        CloneMCJavaRandom_NextIntBound(random,50)<=loopPower;
        loopPower>>=1){
        for(i=0;i<candidateCount;++i)if(candidates[i].available){
            for(j=0;j<count;++j)
                if(!CloneMCJ_Progression_EnchantsCompatible(selectedIds[j],
                    candidates[i].id)){
                    candidates[i].available=0;
                    break;
                }
        }
        selected=CloneMCJ_Progression_WeightedCandidate(random,candidates,
            candidateCount);
        if(selected<0)break;
        stack->enchantmentId[count]=(unsigned char)candidates[selected].id;
        stack->enchantmentLevel[count]=(unsigned char)candidates[selected].level;
        selectedIds[count]=candidates[selected].id;
        ++count;
    }
    stack->enchantmentCount=(unsigned char)count;
    return count>0;
}

int CloneMCJ_Progression_ClickEnchant(CloneMCJ_GameplayState *state,
    int offerIndex)
{
    CloneMCJ_ItemStack *stack;
    CloneMCJ_ProgressionEnchantCandidate candidates[64];
    int selectedIds[CLONEMC_J_MAX_ITEM_ENCHANTMENTS];
    int cost;
    int enchantability;
    int power;
    float variance;
    int candidateCount;
    int selected;
    int count;
    int i;
    int j;
    int loopPower;
    if (!state || !state->openContainerActive ||
        state->openContainer.type != CLONEMC_J_CONTAINER_ENCHANTMENT ||
        offerIndex < 0 || offerIndex > 2) return 0;
    stack = &state->openContainerTile.items[0];
    if (CloneMCJ_ItemStack_IsEmpty(stack) || stack->enchantmentCount > 0)
        return 0;
    cost = state->enchantmentOffers[offerIndex];
    if (cost <= 0 || (state->player.gameMode == CLONEMC_J_GAMEMODE_SURVIVAL &&
        state->player.experienceLevel < cost)) return 0;
    enchantability=CloneMCJ_Progression_ItemEnchantability(stack->itemID);
    if(enchantability<=0)return 0;
    if(!state->enchantmentRandomInitialized){
        CloneMCJavaRandom_SetSeed(&state->enchantmentRandom,
            state->world->worldInfo.randomSeed);
        state->enchantmentRandomInitialized=1;
    }
    power=1+(int)CloneMCJavaRandom_NextIntBound(&state->enchantmentRandom,
        (enchantability>>1)+1)+(int)CloneMCJavaRandom_NextIntBound(
        &state->enchantmentRandom,(enchantability>>1)+1)+cost;
    variance=(CloneMCJavaRandom_NextFloat(&state->enchantmentRandom)+
        CloneMCJavaRandom_NextFloat(&state->enchantmentRandom)-1.0F)*0.25F;
    power=(int)((float)power*(1.0F+variance)+0.5F);
    candidateCount=CloneMCJ_Progression_BuildCandidates(stack,power,candidates);
    selected=CloneMCJ_Progression_WeightedCandidate(&state->enchantmentRandom,
        candidates,candidateCount);
    if(selected<0)return 0;
    stack->enchantmentCount=0;
    count=0;
    stack->enchantmentId[count]=(unsigned char)candidates[selected].id;
    stack->enchantmentLevel[count]=(unsigned char)candidates[selected].level;
    selectedIds[count]=candidates[selected].id;
    ++count;
    for(loopPower=power>>1;
        count<CLONEMC_J_MAX_ITEM_ENCHANTMENTS&&
        CloneMCJavaRandom_NextIntBound(&state->enchantmentRandom,50)<=loopPower;
        loopPower>>=1){
        for(i=0;i<candidateCount;++i)if(candidates[i].available){
            for(j=0;j<count;++j)
                if(!CloneMCJ_Progression_EnchantsCompatible(selectedIds[j],
                    candidates[i].id)){
                    candidates[i].available=0;
                    break;
                }
        }
        selected=CloneMCJ_Progression_WeightedCandidate(
            &state->enchantmentRandom,candidates,candidateCount);
        if(selected<0)break;
        stack->enchantmentId[count]=(unsigned char)candidates[selected].id;
        stack->enchantmentLevel[count]=(unsigned char)candidates[selected].level;
        selectedIds[count]=candidates[selected].id;
        ++count;
    }
    stack->enchantmentCount=(unsigned char)count;
    if (state->player.gameMode == CLONEMC_J_GAMEMODE_SURVIVAL) {
        state->player.experienceLevel -= cost;
        if (state->player.experienceLevel < 0) state->player.experienceLevel = 0;
    }
    state->player.inventory.inventoryChanged = 1;
    CloneMCJ_Progression_RefreshEnchantOffers(state);
    return 1;
}

void CloneMCJ_Progression_InitializeBrewingContainer(
    CloneMCJ_Container *container, CloneMCJ_InventoryPlayer *inventory,
    CloneMCJ_TileEntity *tile)
{
    int i;
    if (!container || !inventory || !tile ||
        tile->type != CLONEMC_J_TILE_BREWING_STAND) return;
    CloneMCJ_Container_Initialize(container);
    container->type = CLONEMC_J_CONTAINER_BREWING;
    container->playerInventory = inventory;
    container->tileEntity = tile;
    container->tileSlotStart = container->slotCount;
    for (i = 0; i < 3; ++i)
        CloneMCJ_Container_AddTypedSlot(container, &tile->items[i], 1,
            CLONEMC_J_SLOT_BREWING_BOTTLE, -1, i,
            i == 0 ? 56 : (i == 1 ? 79 : 102), 51);
    CloneMCJ_Container_AddTypedSlot(container, &tile->items[3], 64,
        CLONEMC_J_SLOT_BREWING_INGREDIENT, -1, 3, 79, 17);
    container->tileSlotEnd = container->slotCount - 1;
    CloneMCJ_Progression_AddPlayerSlots(container, inventory, 84, 142);
}

int CloneMCJ_Progression_IsBrewingIngredient(int itemId)
{
    return CloneMCJ_PotionHelper_IngredientEffect(itemId)!=(const char *)0;
}

int CloneMCJ_Progression_PotionResult(int potionDamage, int ingredientId)
{
    return CloneMCJ_PotionHelper_Result(potionDamage,ingredientId);
}

static int CloneMCJ_Progression_CanBrew(const CloneMCJ_TileEntity *tile)
{
    int index;
    int oldDamage;
    int newDamage;
    int oldCount;
    int newCount;
    if(!tile||tile->type!=CLONEMC_J_TILE_BREWING_STAND||
       CloneMCJ_ItemStack_IsEmpty(&tile->items[3])||
       !CloneMCJ_Progression_IsBrewingIngredient(tile->items[3].itemID))
        return 0;
    for(index=0;index<3;++index){
        if(CloneMCJ_ItemStack_IsEmpty(&tile->items[index])||
           tile->items[index].itemID!=373)continue;
        oldDamage=tile->items[index].itemDamage;
        newDamage=CloneMCJ_Progression_PotionResult(oldDamage,
            tile->items[3].itemID);
        if((oldDamage&CLONEMC_J_POTION_SPLASH)==0&&
           (newDamage&CLONEMC_J_POTION_SPLASH)!=0)return 1;
        oldCount=CloneMCJ_PotionHelper_GetEffects(oldDamage,0,
            (CloneMCJ_PotionEffectNative *)0,0);
        newCount=CloneMCJ_PotionHelper_GetEffects(newDamage,0,
            (CloneMCJ_PotionEffectNative *)0,0);
        if(oldDamage>0&&oldCount==0&&newCount==0)continue;
        if(oldCount>0&&(CloneMCJ_PotionHelper_EffectsEqual(oldDamage,newDamage)||
           newCount==0))continue;
        if(oldDamage==newDamage)continue;
        return 1;
    }
    return 0;
}

static void CloneMCJ_Progression_MarkTileDirty(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_Chunk *chunk;
    if (!tile || !tile->worldObj) return;
    chunk = CloneMCJ_World_GetLoadedChunkFromChunkCoords(tile->worldObj,
        CloneMCJava_FloorDouble((double)tile->xCoord / 16.0),
        CloneMCJava_FloorDouble((double)tile->zCoord / 16.0));
    if (chunk) chunk->isModified = 1;
}

void CloneMCJ_Progression_TickBrewing(CloneMCJ_TileEntity *tile)
{
    int ingredientId;
    int i;
    if (!tile || tile->type != CLONEMC_J_TILE_BREWING_STAND) return;
    if (tile->brewingTime > 0) {
        --tile->brewingTime;
        if (tile->brewingTime == 0) {
            if (CloneMCJ_Progression_CanBrew(tile) &&
                tile->brewingIngredientId == tile->items[3].itemID) {
                ingredientId = tile->items[3].itemID;
                for (i = 0; i < 3; ++i)
                    if (!CloneMCJ_ItemStack_IsEmpty(&tile->items[i]) &&
                        tile->items[i].itemID == 373)
                        tile->items[i].itemDamage =
                            CloneMCJ_Progression_PotionResult(
                                tile->items[i].itemDamage, ingredientId);
                --tile->items[3].stackSize;
                if (tile->items[3].stackSize <= 0)
                    CloneMCJ_ItemStack_Clear(&tile->items[3]);
                CloneMCJ_Progression_MarkTileDirty(tile);
            }
        } else if (!CloneMCJ_Progression_CanBrew(tile) ||
            tile->brewingIngredientId != tile->items[3].itemID) {
            tile->brewingTime = 0;
        }
    } else if (CloneMCJ_Progression_CanBrew(tile)) {
        tile->brewingTime = 400;
        tile->brewingIngredientId = tile->items[3].itemID;
        CloneMCJ_Progression_MarkTileDirty(tile);
    }
}

static void CloneMCJ_Progression_NetherWartTick(CloneMCJ_World *world,
    int x, int y, int z, int blockId, CloneMCJavaRandom *random,
    void *userData)
{
    int metadata;
    (void)blockId;
    (void)userData;
    if (!world || !random) return;
    if (CloneMCJ_World_GetBlockId(world, x, y - 1, z) != 88) {
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
        return;
    }
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (metadata < 3 && CloneMCJavaRandom_NextIntBound(random, 10) == 0)
        CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, metadata + 1);
}

void CloneMCJ_Progression_RegisterWorldTicks(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    if (!world) return;
    block = CloneMCJ_BlockRegistry_GetMutable(115);
    if (block) block->tickRandomly = 1;
    CloneMCJ_World_RegisterBlockTick(world, 115, 1,
        CloneMCJ_Progression_NetherWartTick, (void *)0);
}

int CloneMCJ_Progression_UsePotion(CloneMCJ_GameplayState *state,
    CloneMCJ_ItemStack *stack)
{
    CloneMCJ_PotionEffectNative effects[16];
    CloneMCJ_ItemStack bottle;
    int effectCount;
    int effectIndex;
    if(!state||!stack||stack->itemID!=373||stack->stackSize<=0)return 0;
    if((stack->itemDamage&CLONEMC_J_POTION_SPLASH)!=0)return 0;
    effectCount=CloneMCJ_PotionHelper_GetEffects(stack->itemDamage,0,
        effects,16);
    for(effectIndex=0;effectIndex<effectCount;++effectIndex){
        if(effects[effectIndex].instant)
            CloneMCJ_Progression_ApplyInstantToPlayer(&state->player,
                effects[effectIndex].effectId,effects[effectIndex].amplifier,1.0);
        else CloneMCJ_Progression_AddEffect(&state->player,
            effects[effectIndex].effectId,effects[effectIndex].duration,
            effects[effectIndex].amplifier);
    }
    --stack->stackSize;
    CloneMCJ_ItemStack_Initialize(&bottle,374,1,0);
    /* ItemPotion.onFoodEaten returns the glass bottle directly into the
     * active slot when the consumed potion was the final stack item.  Only a
     * surviving stack adds the bottle elsewhere in inventory. */
    if(stack->stackSize<=0)*stack=bottle;
    else if(!CloneMCJ_InventoryPlayer_AddItemStack(&state->player.inventory,
        &bottle)&&!CloneMCJ_ItemStack_IsEmpty(&bottle))
        CloneMCJ_Gameplay_SpawnDrop(state,state->player.entity.posX,
            state->player.entity.posY+1.0,state->player.entity.posZ,
            &bottle,20,0);
    state->player.inventory.inventoryChanged=1;
    return 1;
}

static int CloneMCJ_Progression_IsBreedable(const CloneMCJ_Mob *mob)
{
    if(!mob)return 0;
    return mob->type==CLONEMC_J_MOB_PIG||
        mob->type==CLONEMC_J_MOB_SHEEP||
        mob->type==CLONEMC_J_MOB_COW||
        mob->type==CLONEMC_J_MOB_CHICKEN||
        mob->type==CLONEMC_J_MOB_MOOSHROOM||
        mob->type==CLONEMC_J_MOB_WOLF||
        mob->type==CLONEMC_J_MOB_OCELOT;
}

static int CloneMCJ_Progression_IsBreedingFood(const CloneMCJ_Mob *mob,
    const CloneMCJ_ItemStack *stack)
{
    const CloneMCJ_ItemDefinition *item;
    if(!mob||!stack||CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    if(mob->type==CLONEMC_J_MOB_WOLF){
        item=CloneMCJ_ItemRegistry_Get(stack->itemID);
        return mob->tamed&&item&&item->wolfsFavoriteMeat;
    }
    if(mob->type==CLONEMC_J_MOB_OCELOT)
        return mob->tamed&&stack->itemID==349;
    return stack->itemID==296;
}

static int CloneMCJ_Progression_CanMate(const CloneMCJ_Mob *first,
    const CloneMCJ_Mob *second)
{
    if(!first||!second||first==second||first->type!=second->type||
       first->growingAge!=0||second->growingAge!=0||
       first->inLove<=0||second->inLove<=0)return 0;
    if(first->type==CLONEMC_J_MOB_WOLF)
        return first->tamed&&second->tamed&&!second->sitting;
    if(first->type==CLONEMC_J_MOB_OCELOT)
        return first->tamed&&second->tamed;
    return 1;
}

int CloneMCJ_Progression_InteractBreeding(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob)
{
    CloneMCJ_ItemStack *held;
    if(!state||!mob||!mob->active||mob->health<=0||
       !CloneMCJ_Progression_IsBreedable(mob)||mob->growingAge!=0||
       mob->inLove>0)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if(!CloneMCJ_Progression_IsBreedingFood(mob,held))return 0;
    if(state->player.gameMode==CLONEMC_J_GAMEMODE_SURVIVAL){
        --held->stackSize;
        if(held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
    }
    mob->inLove=600;
    mob->breedingTicks=0;
    mob->combatTarget=(CloneMCJ_Mob *)0;
    mob->targetEntityId=0;
    mob->persistenceRequired=1;
    state->player.inventory.inventoryChanged=1;
    return 1;
}

static int CloneMCJ_Progression_FindFreeMobSlot(CloneMCJ_GameplayState *state)
{
    int index;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
        if(!state->mobs[index].active)return index;
    return -1;
}

static int CloneMCJ_Progression_EntityChunkLoaded(
    CloneMCJ_GameplayState *state,const CloneMCJ_Entity *entity)
{
    int chunkX;
    int chunkZ;
    if(!state||!state->world||!entity)return 0;
    chunkX=CloneMCJ_World_GlobalToChunk(CloneMCJava_FloorDouble(entity->posX));
    chunkZ=CloneMCJ_World_GlobalToChunk(CloneMCJava_FloorDouble(entity->posZ));
    return CloneMCJ_World_IsChunkLoaded(state->world,chunkX,chunkZ);
}

void CloneMCJ_Progression_TickBreeding(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *mob;
    CloneMCJ_Mob *mate;
    CloneMCJ_Mob *child;
    int index;
    int candidate;
    int slot;
    double dx;
    double dy;
    double dz;
    double distanceSquared;
    if(!state||!state->world||state->world->multiplayerWorld)return;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index){
        mob=&state->mobs[index];
        if(!mob->active||!CloneMCJ_Progression_IsBreedable(mob)||
           !CloneMCJ_Progression_EntityChunkLoaded(state,&mob->entity))continue;
        if(mob->growingAge<0)++mob->growingAge;
        else if(mob->growingAge>0)--mob->growingAge;
        mob->renderScale=mob->growingAge<0?0.5F:1.0F;
        if(mob->inLove>0)--mob->inLove;
        else{mob->breedingTicks=0;continue;}
        if(mob->growingAge!=0)continue;
        mate=(CloneMCJ_Mob *)0;
        distanceSquared=64.0;
        for(candidate=0;candidate<CLONEMC_J_MAX_MOBS;++candidate){
            double candidateDistance;
            if(!CloneMCJ_Progression_CanMate(mob,&state->mobs[candidate])||
               !CloneMCJ_Progression_EntityChunkLoaded(state,
                    &state->mobs[candidate].entity))continue;
            dx=state->mobs[candidate].entity.posX-mob->entity.posX;
            dy=state->mobs[candidate].entity.posY-mob->entity.posY;
            dz=state->mobs[candidate].entity.posZ-mob->entity.posZ;
            candidateDistance=dx*dx+dy*dy+dz*dz;
            if(candidateDistance<distanceSquared){
                distanceSquared=candidateDistance;
                mate=&state->mobs[candidate];
            }
        }
        if(!mate){mob->breedingTicks=0;continue;}
        dx=mate->entity.posX-mob->entity.posX;
        dz=mate->entity.posZ-mob->entity.posZ;
        if(distanceSquared>2.25){
            double length;
            length=sqrt(dx*dx+dz*dz);
            if(length>0.001){
                mob->entity.motionX+=dx/length*0.02;
                mob->entity.motionZ+=dz/length*0.02;
            }
            mob->breedingTicks=0;
            continue;
        }
        ++mob->breedingTicks;
        if(mob->breedingTicks<60||mate->breedingTicks>=60)continue;
        slot=CloneMCJ_Progression_FindFreeMobSlot(state);
        if(slot<0){mob->breedingTicks=0;continue;}
        child=&state->mobs[slot];
        CloneMCJ_EntityLiving_InitializeMob(child,mob->type,state->world,
            mob->entity.posX,mob->entity.posY,mob->entity.posZ);
        child->growingAge=-24000;
        child->renderScale=0.5F;
        child->persistenceRequired=1;
        if(mob->type==CLONEMC_J_MOB_WOLF){
            child->tamed=1;
            child->maxHealth=20;
            child->health=20;
            strncpy(child->owner,mob->owner,sizeof(child->owner)-1U);
            child->owner[sizeof(child->owner)-1U]='\0';
        }else if(mob->type==CLONEMC_J_MOB_OCELOT){
            child->tamed=1;
            child->catType=mob->catType;
            strncpy(child->owner,mob->owner,sizeof(child->owner)-1U);
            child->owner[sizeof(child->owner)-1U]='\0';
        }
        mob->growingAge=6000;
        mate->growingAge=6000;
        mob->inLove=0;
        mate->inLove=0;
        mob->breedingTicks=0;
        mate->breedingTicks=0;
        if(slot>=state->mobCount)state->mobCount=slot+1;
        /* EntityAIMate in the supplied 1.2.3 source creates seven heart
         * particles but does not spawn the later breeding XP reward. */
    }
}

int CloneMCJ_Progression_RunSelfTests(char *message,unsigned int capacity)
{
    CloneMCJ_EntityPlayer player;
    CloneMCJ_TileEntity stand;
    CloneMCJ_ItemStack enchanted;
    CloneMCJ_ItemStack restored;
    CloneMCJ_NBTTagCompound *tag;
    int i;
    int ok;
    ok=1;
    memset(&player,0,sizeof(player));
    CloneMCJ_Progression_AddExperience(&player,7);
    if(player.experienceLevel!=1||player.experienceProgress!=0.0F||
       player.experienceTotal!=7)ok=0;
    if(CloneMCJ_Progression_XPSplit(1)!=1||
       CloneMCJ_Progression_XPSplit(3)!=3||
       CloneMCJ_Progression_XPSplit(17)!=17||
       CloneMCJ_Progression_XPSplit(2477)!=2477||
       CloneMCJ_Progression_XPSplit(3000)!=2477)ok=0;
    if(CloneMCJ_Progression_PotionResult(0,372)!=16||
       CloneMCJ_Progression_PotionResult(16,353)!=8194||
       CloneMCJ_Progression_PotionResult(16,370)!=8193||
       CloneMCJ_Progression_PotionResult(16,378)!=8195||
       CloneMCJ_Progression_PotionResult(16,382)!=8197||
       CloneMCJ_Progression_PotionResult(16,377)!=8201||
       CloneMCJ_Progression_PotionResult(16,375)!=8196||
       CloneMCJ_Progression_PotionResult(8194,348)!=8226||
       CloneMCJ_Progression_PotionResult(8194,331)!=8258||
       CloneMCJ_Progression_PotionResult(8194,289)!=16386||
       CloneMCJ_PotionHelper_Color(8194)!=0x7CAFC6)ok=0;
    memset(&stand,0,sizeof(stand));
    stand.type=CLONEMC_J_TILE_BREWING_STAND;
    stand.itemCount=4;
    for(i=0;i<CLONEMC_J_CHEST_INVENTORY_SIZE;++i)
        CloneMCJ_ItemStack_Clear(&stand.items[i]);
    for(i=0;i<3;++i)CloneMCJ_ItemStack_Initialize(&stand.items[i],373,1,0);
    CloneMCJ_ItemStack_Initialize(&stand.items[3],372,1,0);
    for(i=0;i<=400;++i)CloneMCJ_Progression_TickBrewing(&stand);
    if(stand.brewingTime!=0||!CloneMCJ_ItemStack_IsEmpty(&stand.items[3])||
       stand.items[0].itemDamage!=16||stand.items[1].itemDamage!=16||
       stand.items[2].itemDamage!=16)ok=0;
    CloneMCJ_ItemStack_Initialize(&enchanted,276,1,4);
    enchanted.enchantmentCount=2;
    enchanted.enchantmentId[0]=CLONEMC_J_ENCHANT_SHARPNESS;
    enchanted.enchantmentLevel[0]=3;
    enchanted.enchantmentId[1]=CLONEMC_J_ENCHANT_UNBREAKING;
    enchanted.enchantmentLevel[1]=2;
    tag=CloneMCJ_NBTTagCompound_Create();
    CloneMCJ_ItemStack_Clear(&restored);
    if(!tag||!CloneMCJ_ItemStack_WriteNBT(&enchanted,tag)||
       !CloneMCJ_ItemStack_ReadNBT(&restored,tag)||
       restored.enchantmentCount!=2||
       CloneMCJ_Progression_EnchantLevel(&restored,
           CLONEMC_J_ENCHANT_SHARPNESS)!=3||
       CloneMCJ_Progression_EnchantLevel(&restored,
           CLONEMC_J_ENCHANT_UNBREAKING)!=2)ok=0;
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);
    if(message&&capacity){
        strncpy(message,ok?
            "progression: Java 1.2.3 potion metadata, brewing, XP, and enchant NBT passed":
            "progression: fixed-capacity regression failed",capacity-1U);
        message[capacity-1U]='\0';
    }
    return ok;
}
