/*
 * CloneMC Java port scaffold: EntityItem
 *
 * Java source: EntityItem.java
 * Java type: class EntityItem
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 4e98ab09e9190710c79c86b48ea4b56fe44442088a3fd4cdc56841dfcf435f7d
 * Java lines: 167
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: Entity, MathHelper, World, Material, AxisAlignedBB, Block, NBTTagCompound, ItemStack, EntityPlayer, InventoryPlayer, AchievementList, Item, d1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public ItemStack item
 * - private int field_803_e
 * - public int age
 * - public int delayBeforeCanPickup
 * - private int health
 * - public float field_804_d
 *
 * Java method/constructor inventory:
 * - protected boolean canTriggerWalking()
 * - public EntityItem(World world)
 * - protected void entityInit()
 * - public void onUpdate()
 * - public boolean handleWaterMovement()
 * - protected void dealFireDamage(int i)
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void onCollideWithPlayer(EntityPlayer entityplayer)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>

void CloneMCJ_EntityItem_Initialize(CloneMCJ_EntityItem *dropped, CloneMCJ_World *world,
                                    double x, double y, double z, const CloneMCJ_ItemStack *stack)
{
    double angle;
    CloneMCJ_ItemStack empty;
    if (!dropped) return;
    CloneMCJ_Entity_Initialize(&dropped->entity, world);
    CloneMCJ_Entity_SetSize(&dropped->entity, 0.25F, 0.25F);
    CloneMCJ_Entity_SetPosition(&dropped->entity, x, y, z);
    CloneMCJ_ItemStack_Clear(&empty);
    dropped->item = stack ? *stack : empty;
    dropped->age = 0;
    /* Java fields default to zero.  Spawn paths explicitly install the
     * appropriate 10/40-tick pickup delay; NBT-loaded items therefore resume
     * with Java's zero delay instead of receiving an invented extra delay. */
    dropped->delayBeforeCanPickup = 0;
    dropped->health = 5;
    dropped->hoverStart = CloneMCJavaRandom_NextFloat(&dropped->entity.rand) * 6.283185307F;
    angle = CloneMCJavaRandom_NextDouble(&dropped->entity.rand) * 6.283185307179586;
    dropped->entity.motionX = -sin(angle) * 0.1;
    dropped->entity.motionY = 0.2;
    dropped->entity.motionZ = cos(angle) * 0.1;
    dropped->active = (unsigned char)!CloneMCJ_ItemStack_IsEmpty(&dropped->item);
}

int CloneMCJ_EntityItem_AttackEntityFrom(CloneMCJ_EntityItem *dropped,
    int damage)
{
    if(!dropped||!dropped->active||damage<=0)return 0;
    dropped->health-=damage;
    if(dropped->health<=0){
        dropped->entity.isDead=1;
    }
    return 1;
}

int CloneMCJ_EntityItem_CanUpdate(const CloneMCJ_EntityItem *dropped)
{
    if (!dropped || !dropped->active) return 0;
    return CloneMCJ_Entity_CanMoveSafely(&dropped->entity,
        dropped->entity.motionX, dropped->entity.motionY, dropped->entity.motionZ);
}

void CloneMCJ_EntityItem_TickLoaded(CloneMCJ_EntityItem *dropped)
{
    int blockID;
    int inLava;
    const CloneMCJ_BlockDefinition *block;
    float friction;
    if (!dropped || !dropped->active || dropped->entity.isDead) return;

    /* Entity.onEntityUpdate runs before EntityItem.onUpdate.  Preserve the
     * observable Java 1.2.3 order: existing fire damage, lava damage/fire,
     * then the item-specific gravity, bounce, motion, friction, and age. */
    ++dropped->entity.ticksExisted;
    dropped->entity.prevPosX=dropped->entity.posX;
    dropped->entity.prevPosY=dropped->entity.posY;
    dropped->entity.prevPosZ=dropped->entity.posZ;
    if(dropped->entity.fire>0){
        if(dropped->entity.fire%20==0)
            CloneMCJ_EntityItem_AttackEntityFrom(dropped,1);
        --dropped->entity.fire;
    }
    inLava=CloneMCJ_Entity_IsInsideMaterial(&dropped->entity,
        CLONEMC_J_MATERIAL_LAVA);
    dropped->entity.inLava=(unsigned char)(inLava!=0);
    if(inLava){
        CloneMCJ_EntityItem_AttackEntityFrom(dropped,4);
        if(dropped->entity.fire<300)dropped->entity.fire=300;
        dropped->entity.fallDistance*=0.5F;
    }
    if(dropped->entity.posY<-64.0)dropped->entity.isDead=1;

    if (dropped->delayBeforeCanPickup > 0) --dropped->delayBeforeCanPickup;
    dropped->entity.prevPosX = dropped->entity.posX;
    dropped->entity.prevPosY = dropped->entity.posY;
    dropped->entity.prevPosZ = dropped->entity.posZ;
    dropped->entity.motionY -= 0.04;
    if (inLava) {
        dropped->entity.motionY = 0.2;
        dropped->entity.motionX = (CloneMCJavaRandom_NextFloat(&dropped->entity.rand) -
            CloneMCJavaRandom_NextFloat(&dropped->entity.rand)) * 0.2;
        dropped->entity.motionZ = (CloneMCJavaRandom_NextFloat(&dropped->entity.rand) -
            CloneMCJavaRandom_NextFloat(&dropped->entity.rand)) * 0.2;
        /* The supplied sound engine does not expose EntityItem's precise
         * playSoundAtEntity hook; random.fizz remains queued by the material
         * event path rather than consuming an extra gameplay RNG stream here. */
    }
    CloneMCJ_Entity_Move(&dropped->entity, dropped->entity.motionX,
        dropped->entity.motionY, dropped->entity.motionZ);
    friction = 0.98F;
    if (dropped->entity.onGround) {
        blockID = CloneMCJ_World_GetBlockId(dropped->entity.worldObj,
            CloneMCJava_FloorDouble(dropped->entity.posX),
            CloneMCJava_FloorDouble(dropped->entity.boundingBox.minY) - 1,
            CloneMCJava_FloorDouble(dropped->entity.posZ));
        block = CloneMCJ_BlockRegistry_Get(blockID);
        if (block) friction = block->slipperiness * 0.98F;
    }
    dropped->entity.motionX *= friction;
    dropped->entity.motionY *= 0.98;
    dropped->entity.motionZ *= friction;
    if (dropped->entity.onGround) dropped->entity.motionY *= -0.5;
    ++dropped->age;
    if (dropped->age >= 6000 || dropped->health <= 0 ||
        dropped->entity.isDead || CloneMCJ_ItemStack_IsEmpty(&dropped->item)) {
        dropped->active = 0;
        dropped->entity.isDead = 1;
    }
}

void CloneMCJ_EntityItem_Tick(CloneMCJ_EntityItem *dropped)
{
    if(!CloneMCJ_EntityItem_CanUpdate(dropped))return;
    CloneMCJ_EntityItem_TickLoaded(dropped);
}

int CloneMCJ_EntityItem_TryPickup(CloneMCJ_EntityItem *dropped, CloneMCJ_EntityPlayer *player)
{
    double dx, dy, dz;
    int before;
    if (!dropped || !player || !dropped->active || dropped->delayBeforeCanPickup > 0) return 0;
    dx = dropped->entity.posX - player->entity.posX;
    dy = dropped->entity.posY - player->entity.posY;
    dz = dropped->entity.posZ - player->entity.posZ;
    if (dx * dx + dy * dy + dz * dz > 2.25) return 0;
    before = dropped->item.stackSize;
    CloneMCJ_InventoryPlayer_AddItemStack(&player->inventory, &dropped->item);
    if (dropped->item.stackSize < before) {
        player->itemsPickedUp += (unsigned long)(before - (dropped->item.stackSize > 0 ? dropped->item.stackSize : 0));
        if (CloneMCJ_ItemStack_IsEmpty(&dropped->item)) {
            dropped->active = 0;
            dropped->entity.isDead = 1;
        }
        return before - (dropped->item.stackSize > 0 ? dropped->item.stackSize : 0);
    }
    return 0;
}

int CloneMCJ_EntityItem_WriteNBT(const CloneMCJ_EntityItem *dropped, CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagCompound *itemTag;
    if (!dropped || !compound || !dropped->active) return 0;
    CloneMCJ_Entity_WriteNBT(&dropped->entity, compound, "Item");
    CloneMCJ_NBTTagCompound_SetShort(compound, "Health", (CloneMCJShort)dropped->health);
    CloneMCJ_NBTTagCompound_SetShort(compound, "Age", (CloneMCJShort)dropped->age);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "EntityId", dropped->entity.entityId);
    itemTag = CloneMCJ_NBTTagCompound_Create();
    if (!itemTag) return 0;
    CloneMCJ_ItemStack_WriteNBT(&dropped->item, itemTag);
    CloneMCJ_NBTTagCompound_SetTag(compound, "Item", (CloneMCJ_NBTBase *)itemTag);
    return 1;
}

int CloneMCJ_EntityItem_ReadNBT(CloneMCJ_EntityItem *dropped, const CloneMCJ_NBTTagCompound *compound, CloneMCJ_World *world)
{
    CloneMCJ_NBTTagCompound *itemTag;
    if (!dropped || !compound) return 0;
    CloneMCJ_EntityItem_Initialize(dropped, world, 0.0, 0.0, 0.0, (const CloneMCJ_ItemStack *)0);
    if(!CloneMCJ_Entity_ReadNBT(&dropped->entity, compound))return 0;
    dropped->health = CloneMCJ_NBTTagCompound_GetShort(compound, "Health");
    dropped->age = CloneMCJ_NBTTagCompound_GetShort(compound, "Age");
    {int storedID;storedID=CloneMCJ_NBTTagCompound_GetInteger(compound,"EntityId");
        if(storedID>0){dropped->entity.entityId=storedID;CloneMCJ_Entity_ReserveID(storedID);}}
    itemTag = CloneMCJ_NBTTagCompound_GetCompoundTag(compound, "Item");
    if (!CloneMCJ_ItemStack_ReadNBT(&dropped->item, itemTag)) return 0;
    dropped->entity.chunkCoordX=CloneMCJava_FloorDouble(dropped->entity.posX/16.0);
    dropped->entity.chunkCoordY=CloneMCJava_FloorDouble(dropped->entity.posY/16.0);
    if(dropped->entity.chunkCoordY<0)dropped->entity.chunkCoordY=0;
    if(dropped->entity.chunkCoordY>=CLONEMC_J_CHUNK_ENTITY_SLICES)
        dropped->entity.chunkCoordY=CLONEMC_J_CHUNK_ENTITY_SLICES-1;
    dropped->entity.chunkCoordZ=CloneMCJava_FloorDouble(dropped->entity.posZ/16.0);
    dropped->entity.addedToChunk=1;
    dropped->active = 1;
    return 1;
}

void CloneMCJ_EntityItem_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityItem_JavaName(void)
{
    return "net.minecraft.src.EntityItem";
}

const char *CloneMCJ_EntityItem_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityItem_JavaSourceHash32(void)
{
    return 0x4E98AB09UL;
}
