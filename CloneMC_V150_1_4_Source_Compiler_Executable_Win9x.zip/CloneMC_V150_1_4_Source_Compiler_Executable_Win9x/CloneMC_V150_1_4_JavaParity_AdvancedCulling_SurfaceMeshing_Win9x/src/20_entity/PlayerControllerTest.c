/*
 * CloneMC Java port scaffold: PlayerControllerTest
 *
 * Java source: PlayerControllerTest.java
 * Java type: class PlayerControllerTest
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: PlayerController
 * Implements: (none declared)
 * Source SHA-256: 91e7b01eaebe5024a5b93330b30252fd13a4f1322216df6d61fc80f4bde329c0
 * Java lines: 52
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: PlayerController, EntityPlayer, InventoryPlayer, EntityPlayerSP, ItemStack, Session, Block, World
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public PlayerControllerTest(Minecraft minecraft)
 * - public void func_6473_b(EntityPlayer entityplayer)
 * - public boolean shouldDrawHUD()
 * - public void func_717_a(World world)
 * - public void updateController()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <time.h>
#if defined(_WIN32)
#include <direct.h>
#define CLONEMC_P16_RMDIR _rmdir
#else
#include <unistd.h>
#define CLONEMC_P16_RMDIR rmdir
#endif
#include <stdlib.h>
#include <string.h>
#include <math.h>

static void CloneMCJ_Priority7_SetMessage(char *message, unsigned int capacity, const char *text)
{
    if (!message || capacity == 0U) return;
    strncpy(message, text, capacity - 1U);
    message[capacity - 1U] = '\0';
}

static int CloneMCJ_V116_FailingChunkSaver(const CloneMCJ_Chunk *chunk,
    int force, void *userData)
{
    (void)chunk; (void)force; (void)userData;
    return 0;
}

static int g_cloneMCV117SavedChunks = 0;

static int CloneMCJ_V117_CountingChunkSaver(const CloneMCJ_Chunk *chunk,
    int force, void *userData)
{
    (void)chunk; (void)force; (void)userData;
    ++g_cloneMCV117SavedChunks;
    return 1;
}

static int g_cloneMCV118UnexpectedGeneratorCalls = 0;

static int CloneMCJ_V118_CorruptChunkLoader(CloneMCJ_Chunk *chunk,
    int chunkX,int chunkZ,void *userData)
{
    (void)chunk;(void)chunkX;(void)chunkZ;(void)userData;
    return -1;
}

static int CloneMCJ_V118_CountingGenerator(CloneMCJ_Chunk *chunk,
    int chunkX,int chunkZ,void *userData)
{
    (void)chunk;(void)chunkX;(void)chunkZ;(void)userData;
    ++g_cloneMCV118UnexpectedGeneratorCalls;
    return 1;
}

int CloneMCJ_Priority7_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJ_InventoryPlayer inventory;
    CloneMCJ_ItemStack incoming, stack, decoded;
    CloneMCJ_NBTTagCompound *compound;
    CloneMCJ_TileEntity *furnace;
    CloneMCJ_TileEntity *movingA;
    CloneMCJ_TileEntity *movingB;
    CloneMCJ_EntityPlayer player;
    CloneMCJ_EntityPlayer placementPlayer;
    CloneMCJ_PlayerControllerSP placementController;
    CloneMCJ_InventoryPlayer decodedInventory;
    CloneMCJ_EntityItem dropped;
    CloneMCJ_EntityItem decodedDropped;
    CloneMCJ_GameplayState gameplay;
    CloneMCJ_BlockBreakEvent breakEvent;
    CloneMCJ_ChunkProviderLoadOrGenerate corruptProvider;
    CloneMCJ_World *world;
    CloneMCJ_Chunk *chunk;
    CloneMCJ_Chunk *saveChunk;
    CloneMCJ_Chunk *rejectedChunk;
    CloneMCJ_Entity collisionEntity;
    CloneMCAxisAlignedBB doorBoxes[3];
    CloneMCJavaRandom dropRandom;
    CloneMCJ_Mob wolf;
    CloneMCJ_Mob pig;
    CloneMCJ_Mob sheep;
    CloneMCJ_Mob cow;
    CloneMCJ_Mob targetMob;
    const char *failure;
    int i,attempts,saveResult,remaining,flintDrops,guard,foundTorchDrop;
    int appleDrops,saplingDrops;
    float lastDamage;
    static const int expectedWoolTexture[16]={64,210,194,178,162,146,130,114,225,209,193,177,161,145,129,113};
    failure = (const char *)0;
    CloneMCJ_BlockRegistry_Initialize();
    CloneMCJ_ItemRegistry_Initialize();
    if (CloneMCJ_BlockRegistry_Get(1)->material != CLONEMC_J_MATERIAL_ROCK ||
        CloneMCJ_BlockRegistry_Get(54)->hasTileEntity == 0 ||
        CloneMCJ_ItemRegistry_Get(270)->toolClass != CLONEMC_J_TOOL_PICKAXE) failure = "Priority 7 registry test failed";
    if(!failure&&(CloneMCJ_ItemRegistry_Get(319)->healAmount!=3||
        !CloneMCJ_ItemRegistry_Get(319)->wolfsFavoriteMeat||
        CloneMCJ_ItemRegistry_Get(319)->maxStackSize!=1))
        failure="Java ItemFood registry test failed";
    CloneMCJavaRandom_SetSeed(&dropRandom,1234);
    if(!failure&&(CloneMCJ_BlockRegistry_Get(2)->requiredTool!=CLONEMC_J_TOOL_NONE||
        CloneMCJ_BlockRegistry_Get(3)->requiredTool!=CLONEMC_J_TOOL_NONE))
        failure="V115 grass/dirt incorrectly require a pickaxe";
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(2,0,&dropRandom,&stack)||
        stack.itemID!=3||stack.stackSize!=1))
        failure="V115 grass must drop one dirt block";
    CloneMCJ_InventoryPlayer_Initialize(&inventory);
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&(CloneMCJ_BlockRegistry_Get(82)->material!=
            CLONEMC_J_MATERIAL_EARTH||
        !CloneMCJ_InventoryPlayer_CanHarvest(&inventory,82)||
        !CloneMCJ_Block_GetDroppedStack(82,0,&dropRandom,&stack)||
        stack.itemID!=337||stack.stackSize!=4))
        failure="V150 Java BlockClay harvest/drop conversion failed";
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&(CloneMCJ_BlockRegistry_Get(86)->material!=
            CLONEMC_J_MATERIAL_PLANT||
        !CloneMCJ_InventoryPlayer_CanHarvest(&inventory,86)||
        !CloneMCJ_Block_GetDroppedStack(86,2,&dropRandom,&stack)||
        stack.itemID!=86||stack.stackSize!=1))
        failure="V150 Java BlockPumpkin harvest/drop conversion failed";
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&(!CloneMCJ_InventoryPlayer_CanHarvest(&inventory,91)||
        !CloneMCJ_Block_GetDroppedStack(91,1,&dropRandom,&stack)||
        stack.itemID!=91||stack.stackSize!=1||
        CloneMCJ_World_GetBlockLightEmission(91)!=15))
        failure="V150 Java lit-pumpkin drop/light conversion failed";
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(39,0,&dropRandom,&stack)||
        stack.itemID!=39||stack.stackSize!=1))
        failure="V115 brown mushroom self-drop failed";
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&CloneMCJ_Block_GetDroppedStack(59,3,&dropRandom,&stack))
        failure="V115 immature crops incorrectly dropped wheat";
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(59,7,&dropRandom,&stack)||
        stack.itemID!=296))failure="V115 mature crop wheat drop failed";
    CloneMCJavaRandom_SetSeed(&dropRandom,1234);
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(1,0,&dropRandom,&stack)||
        stack.itemID!=4||stack.stackSize!=1||stack.itemDamage!=0))
        failure="V122 Java BlockStone must drop one cobblestone after a valid harvest";
    flintDrops=0;
    for(i=0;i<40&&!failure;++i){
        CloneMCJ_ItemStack_Clear(&stack);
        if(!CloneMCJ_Block_GetDroppedStack(13,0,&dropRandom,&stack)||
           (stack.itemID!=13&&stack.itemID!=318)||stack.stackSize!=1){
            failure="V122 Java BlockGravel returned an invalid drop";break;
        }
        if(stack.itemID==318){
            if(i!=3&&i!=4&&i!=10&&i!=16&&i!=34){
                failure="V122 Java gravel/flint Random call order changed";break;
            }
            ++flintDrops;
        }
    }
    if(!failure&&flintDrops!=5)
        failure="V122 Java gravel 1-in-10 flint sequence failed";
    CloneMCJ_ItemStack_Clear(&stack);
    if(!failure&&CloneMCJ_Block_GetDroppedStack(8,0,&dropRandom,&stack))
        failure="V122 Java fluid blocks must never drop placeable fluid blocks";
    if(!failure&&CloneMCJ_Block_GetDroppedStack(92,0,&dropRandom,&stack))
        failure="V122 Java cake block quantityDropped must remain zero";
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(75,0,&dropRandom,&stack)||
        stack.itemID!=76||stack.stackSize!=1))
        failure="V122 inactive redstone torch did not drop the active torch item/block";
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(62,0,&dropRandom,&stack)||
        stack.itemID!=61||stack.stackSize!=1))
        failure="V122 burning furnace did not drop the idle furnace block";
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(53,0,&dropRandom,&stack)||
        stack.itemID!=53||stack.stackSize!=1))
        failure="V132.2 wooden stair did not drop itself";
    if(!failure&&(!CloneMCJ_Block_GetDroppedStack(67,0,&dropRandom,&stack)||
        stack.itemID!=67||stack.stackSize!=1))
        failure="V132.2 cobblestone stair did not drop itself";
    appleDrops=0;saplingDrops=0;
    CloneMCJavaRandom_SetSeed(&dropRandom,187);
    for(i=0;i<4000&&!failure;++i){
        if(CloneMCJ_Block_GetDroppedStack(18,0,&dropRandom,&stack)){
            if(stack.itemID!=6){failure="V132.2 leaf primary drop was not a sapling";break;}
            ++saplingDrops;
        }
        if(CloneMCJ_Block_GetAdditionalDroppedStack(18,0,&dropRandom,&stack)){
            if(stack.itemID!=260){failure="V132.2 oak secondary drop was not an apple";break;}
            ++appleDrops;
        }
    }
    if(!failure&&(saplingDrops!=202||appleDrops!=19))
        failure="V132.2 deterministic Java leaf sapling/apple sequence changed";
    if(!failure&&CloneMCJ_Block_GetAdditionalDroppedStack(18,1,
        &dropRandom,&stack))
        failure="V132.2 spruce leaves incorrectly produced an apple";
    CloneMCJ_InventoryPlayer_Initialize(&inventory);
    for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE; ++i)
        CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[i], 1, 64, 0);
    inventory.mainInventory[0].stackSize = 60;
    CloneMCJ_ItemStack_Initialize(&incoming, 1, 10, 0);
    if (!failure && (!CloneMCJ_InventoryPlayer_AddItemStack(&inventory, &incoming) ||
        inventory.mainInventory[0].stackSize != 64 || incoming.stackSize != 6)) failure = "Priority 7 partial-pickup inventory test failed";
    CloneMCJ_InventoryPlayer_Initialize(&inventory);
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[9], 5, 5, 0);
    if (!failure && (!CloneMCJ_InventoryPlayer_ClickSlot(&inventory, 9, 0) ||
        !CloneMCJ_ItemStack_IsEmpty(&inventory.mainInventory[9]) ||
        inventory.carriedStack.itemID != 5 || inventory.carriedStack.stackSize != 5))
        failure = "Priority 7 GuiContainer left-click pickup test failed";
    if (!failure && (!CloneMCJ_InventoryPlayer_ClickSlot(&inventory, 0, 1) ||
        inventory.mainInventory[0].stackSize != 1 || inventory.carriedStack.stackSize != 4 ||
        !CloneMCJ_InventoryPlayer_ClickSlot(&inventory, 0, 1) ||
        inventory.mainInventory[0].stackSize != 2 || inventory.carriedStack.stackSize != 3))
        failure = "Priority 7 GuiContainer right-click split test failed";
    if (!failure && (!CloneMCJ_InventoryPlayer_ClickSlot(&inventory, 0, 0) ||
        inventory.mainInventory[0].stackSize != 5 ||
        !CloneMCJ_ItemStack_IsEmpty(&inventory.carriedStack)))
        failure = "Priority 7 GuiContainer merge test failed";
    CloneMCJ_ItemStack_Initialize(&stack, 270, 1, 0);
    for (i = 0; i <= CloneMCJ_ItemRegistry_Get(270)->maxDamage; ++i) CloneMCJ_ItemStack_Damage(&stack, 1);
    if (!failure && !CloneMCJ_ItemStack_IsEmpty(&stack)) failure = "Priority 7 tool durability test failed";
    /* ItemTool.getStrVsBlock uses each tool class's explicit Java
     * blocksEffectiveAgainst list.  Harvest eligibility is intentionally
     * separate from speed. */
    CloneMCJ_InventoryPlayer_Initialize(&inventory);
    inventory.currentItem=0;
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],271,1,0);
    if(!failure&&CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,17)!=2.0F)
        failure="V125 wooden axe did not use Java speed on logs";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],275,1,0);
    if(!failure&&CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,5)!=4.0F)
        failure="V125 stone axe did not use Java speed on planks";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],258,1,0);
    if(!failure&&CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,54)!=6.0F)
        failure="V125 iron axe did not use Java speed on chests";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],279,1,0);
    if(!failure&&CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,47)!=8.0F)
        failure="V125 diamond axe did not use Java speed on bookshelves";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],286,1,0);
    if(!failure&&CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,17)!=12.0F)
        failure="V125 gold axe did not retain Java efficiency";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],269,1,0);
    if(!failure&&(CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,2)!=2.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,3)!=2.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,12)!=2.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,13)!=2.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,60)!=2.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlock(&inventory,17)!=1.0F))
        failure="V125 shovel effective-block table differs from ItemSpade.java";
    if(!failure&&!CloneMCJ_InventoryPlayer_CanHarvest(&inventory,78))
        failure="V125 shovel could not harvest Java snow layer";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],270,1,0);
    if(!failure&&(CloneMCJ_InventoryPlayer_CanHarvest(&inventory,56)||
        !CloneMCJ_InventoryPlayer_CanHarvest(&inventory,1)))
        failure="V125 wooden pickaxe harvest thresholds differ from Java";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],271,1,0);
    if(!failure&&(CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
            &inventory,53,0)!=2.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
            &inventory,44,2)!=2.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
            &inventory,44,0)!=1.0F))
        failure="V132.2 axe stair/wood-slab speed mapping failed";
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[0],274,1,0);
    if(!failure&&(CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
            &inventory,67,0)!=4.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
            &inventory,44,0)!=4.0F||
        CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
            &inventory,44,2)!=1.0F||
        !CloneMCJ_InventoryPlayer_CanHarvestMetadata(&inventory,67,0)))
        failure="V132.2 pickaxe stone-stair/slab mapping failed";
    CloneMCJ_ItemStack_Clear(&inventory.mainInventory[0]);
    if(!failure&&(!CloneMCJ_InventoryPlayer_CanHarvestMetadata(
            &inventory,44,2)||
        CloneMCJ_InventoryPlayer_CanHarvestMetadata(&inventory,44,0)||
        !CloneMCJ_InventoryPlayer_CanHarvestMetadata(&inventory,53,0)||
        CloneMCJ_InventoryPlayer_CanHarvestMetadata(&inventory,67,0)))
        failure="V132.2 material-aware stair/slab harvest eligibility failed";
    CloneMCJ_ItemStack_Initialize(&stack, 5, 37, 2);
    compound = CloneMCJ_NBTTagCompound_Create();
    CloneMCJ_ItemStack_Clear(&decoded);
    if (!failure && (!compound || !CloneMCJ_ItemStack_WriteNBT(&stack, compound) ||
        !CloneMCJ_ItemStack_ReadNBT(&decoded, compound) || decoded.itemID != 5 ||
        decoded.stackSize != 37 || decoded.itemDamage != 2)) failure = "Priority 7 ItemStack NBT round-trip failed";
    if (compound) CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);
    CloneMCJ_InventoryPlayer_Initialize(&inventory);
    CloneMCJ_InventoryPlayer_Initialize(&decodedInventory);
    inventory.currentItem = 4;
    CloneMCJ_ItemStack_Initialize(&inventory.mainInventory[4], 5, 37, 2);
    CloneMCJ_ItemStack_Initialize(&inventory.armorInventory[3], 298, 1, 7);
    compound = CloneMCJ_NBTTagCompound_Create();
    if (!failure && (!compound || !CloneMCJ_InventoryPlayer_WriteNBT(&inventory, compound) ||
        !CloneMCJ_InventoryPlayer_ReadNBT(&decodedInventory, compound) ||
        decodedInventory.currentItem != 4 || decodedInventory.mainInventory[4].itemID != 5 ||
        decodedInventory.mainInventory[4].stackSize != 37 ||
        decodedInventory.mainInventory[4].itemDamage != 2 ||
        decodedInventory.armorInventory[3].itemID != 298 ||
        decodedInventory.armorInventory[3].stackSize != 1))
        failure = "V116 inventory selected-slot/count NBT round-trip failed";
    if (compound) CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);
    furnace = CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_FURNACE, (CloneMCJ_World *)0, 1, 2, 3);
    if (furnace) {
        CloneMCJ_ItemStack_Initialize(&furnace->items[0], 15, 1, 0);
        CloneMCJ_ItemStack_Initialize(&furnace->items[1], 263, 1, 0);
        for (i = 0; i < 200; ++i) CloneMCJ_TileEntity_Update(furnace);
    }
    if (!failure && (!furnace || furnace->items[2].itemID != 265 || furnace->items[2].stackSize != 1)) failure = "Priority 7 furnace recipe/timing test failed";
    CloneMCJ_TileEntity_Destroy(furnace);
    CloneMCJ_EntityPlayer_Initialize(&player, (CloneMCJ_World *)0, "TestPlayer");
    player.health=10;CloneMCJ_ItemStack_Initialize(&player.inventory.mainInventory[0],319,1,0);
    if(!failure&&(CloneMCJ_ItemFood_Use(&player.inventory.mainInventory[0],&player)!=3||
        player.health!=13||!CloneMCJ_ItemStack_IsEmpty(&player.inventory.mainInventory[0])))
        failure="Java ItemFood right-click healing test failed";
    player.health=20;CloneMCJ_ItemStack_Initialize(&player.inventory.mainInventory[0],260,1,0);
    if(!failure&&(CloneMCJ_ItemFood_Use(&player.inventory.mainInventory[0],&player)!=0||
        !CloneMCJ_ItemStack_IsEmpty(&player.inventory.mainInventory[0])))
        failure="Java Beta full-health food consumption test failed";
    player.health=10;CloneMCJ_ItemStack_Initialize(&player.inventory.mainInventory[0],282,1,0);
    if(!failure&&(CloneMCJ_ItemSoup_Use(&player.inventory.mainInventory[0],&player)!=10||
        player.inventory.mainInventory[0].itemID!=281||
        player.inventory.mainInventory[0].stackSize!=1))
        failure="Java ItemSoup empty-bowl return test failed";
    CloneMCJ_EntityLiving_InitializeMob(&wolf,CLONEMC_J_MOB_WOLF,(CloneMCJ_World *)0,0,0,2);
    if(!failure&&(CloneMCJ_EntityWolf_GetTailRotation(&wolf)<0.6282F||
        CloneMCJ_EntityWolf_GetTailRotation(&wolf)>0.6284F))
        failure="Java untamed wolf tail rotation test failed";
    CloneMCJ_ItemStack_Initialize(&player.inventory.mainInventory[0],352,32,0);
    attempts=0;while(!wolf.tamed&&attempts<32){CloneMCJ_EntityWolf_Interact(&wolf,&player);++attempts;}
    if(!failure&&(!wolf.tamed||!wolf.sitting||wolf.health!=20||strcmp(wolf.owner,"TestPlayer")))
        failure="Java EntityWolf taming/owner/sitting test failed";
    CloneMCJ_EntityLiving_InitializeMob(&pig,CLONEMC_J_MOB_PIG,(CloneMCJ_World *)0,0,0,2);
    CloneMCJ_ItemStack_Initialize(&player.inventory.mainInventory[0],329,1,0);
    if(!failure&&(!CloneMCJ_EntityPig_InteractNative(&pig,&player)||!pig.saddled||
        !CloneMCJ_ItemStack_IsEmpty(&player.inventory.mainInventory[0])||
        !CloneMCJ_EntityPig_InteractNative(&pig,&player)||
        player.ridingEntityId!=pig.entity.entityId||pig.riderEntityId!=player.entity.entityId||
        !CloneMCJ_EntityPig_InteractNative(&pig,&player)||player.ridingEntityId!=0))
        failure="Java ItemSaddle and EntityPig mount/dismount test failed";
    memset(&gameplay,0,sizeof(gameplay));
    for(i=0;i<CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY+3;++i)
        CloneMCJ_Gameplay_QueueBlockBreakEvent(&gameplay,2,i&15,
            100+i,64,-100-i);
    if(!failure&&(CloneMCJ_Gameplay_GetBlockBreakEvent(&gameplay,1UL,
            &breakEvent)||
        !CloneMCJ_Gameplay_GetBlockBreakEvent(&gameplay,
            gameplay.blockBreakEventSequence,&breakEvent)||
        breakEvent.blockID!=2||breakEvent.metadata!=2||
        breakEvent.x!=100+CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY+2))
        failure="V118 independent bounded block-break event queue failed";
    CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&corruptProvider,
        (CloneMCJLong)42);
    g_cloneMCV118UnexpectedGeneratorCalls=0;
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(&corruptProvider,
        CloneMCJ_V118_CorruptChunkLoader,(void *)0,
        CloneMCJ_V118_CountingGenerator,(void *)0,
        (CloneMCJ_ChunkSaverProc)0,(void *)0);
    rejectedChunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(
        &corruptProvider,3,-4);
    if(!failure&&(rejectedChunk!=&corruptProvider.blankChunk||
        g_cloneMCV118UnexpectedGeneratorCalls!=0||
        corruptProvider.chunkLoadFailures!=1UL||
        corruptProvider.residentCount!=0))
        failure="V118 corrupt present chunk was regenerated or retained";
    CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&corruptProvider);
    CloneMCJ_EntityPlayer_Initialize(&gameplay.player,(CloneMCJ_World *)0,"Shearer");
    CloneMCJ_EntityLiving_InitializeMob(&sheep,CLONEMC_J_MOB_SHEEP,(CloneMCJ_World *)0,0,0,2);
    CloneMCJ_ItemStack_Initialize(&gameplay.player.inventory.mainInventory[0],359,1,0);
    CloneMCJ_EntitySheep_InteractNative(&gameplay,&sheep,&gameplay.player);
    if(!failure&&(!sheep.sheared||gameplay.droppedItemCount<2||
        gameplay.droppedItemCount>4||gameplay.player.inventory.mainInventory[0].itemDamage!=1))
        failure="Java EntitySheep shearing/drop/durability test failed";
    CloneMCJ_EntityLiving_InitializeMob(&cow,CLONEMC_J_MOB_COW,(CloneMCJ_World *)0,0,0,2);
    CloneMCJ_ItemStack_Initialize(&gameplay.player.inventory.mainInventory[0],325,1,0);
    if(!failure&&(!CloneMCJ_EntityCow_InteractNative(&cow,&gameplay.player)||
        gameplay.player.inventory.mainInventory[0].itemID!=335))
        failure="Java EntityCow bucket-to-milk interaction test failed";
    CloneMCJ_Entity_SetPosition(&player.entity,0,0,0);
    memset(&gameplay,0,sizeof(gameplay));gameplay.player=player;
    CloneMCJ_EntityLiving_InitializeMob(&targetMob,CLONEMC_J_MOB_ZOMBIE,(CloneMCJ_World *)0,0,0,2);
    gameplay.mobs[0]=targetMob;CloneMCJ_ItemStack_Initialize(&gameplay.player.inventory.mainInventory[0],276,1,0);
    gameplay.player.inventory.currentItem=0;
    if(!failure&&(CloneMCJ_Gameplay_FindTargetMob(&gameplay,5.0,(double *)0)!=0||
        !CloneMCJ_Gameplay_AttackMob(&gameplay,0)||gameplay.mobs[0].health!=13||
        gameplay.player.inventory.mainInventory[0].itemDamage!=1))
        failure="Java entity ray-target/melee/tool-durability test failed";
    CloneMCJ_EntityPlayer_Initialize(&player, (CloneMCJ_World *)0, "TestPlayer");
    for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE; ++i)
        CloneMCJ_ItemStack_Initialize(&player.inventory.mainInventory[i], 1, 64, 0);
    player.inventory.mainInventory[0].stackSize = 60;
    CloneMCJ_ItemStack_Initialize(&stack, 1, 10, 0);
    CloneMCJ_EntityItem_Initialize(&dropped, (CloneMCJ_World *)0, player.entity.posX,
        player.entity.posY, player.entity.posZ, &stack);
    dropped.delayBeforeCanPickup = 0;
    if (!failure && (CloneMCJ_EntityItem_TryPickup(&dropped, &player) != 4 ||
        dropped.item.stackSize != 6 || !dropped.active)) failure = "Priority 7 dropped-item partial pickup test failed";
    memset(&gameplay, 0, sizeof(gameplay));
    CloneMCJ_EntityPlayer_Initialize(&gameplay.player, (CloneMCJ_World *)0, "DropTest");
    CloneMCJ_ItemStack_Initialize(&gameplay.player.inventory.mainInventory[0], 5, 3, 0);
    if (!failure && (!CloneMCJ_Gameplay_DropCurrentItem(&gameplay, 0) ||
        gameplay.player.inventory.mainInventory[0].stackSize != 2 ||
        !gameplay.droppedItems[0].active || gameplay.droppedItems[0].delayBeforeCanPickup != 40))
        failure = "Priority 7 Q-drop direction/delay test failed";
    world = (CloneMCJ_World *)malloc(sizeof(*world));
    if (!world && !failure) failure = "Priority 7 collision test allocation failed";
    if (world) {
        memset(world, 0, sizeof(*world));
        CloneMCJavaRandom_SetSeed(&world->rand, 1);
        CloneMCJ_WorldProvider_InitializeSurface(&world->worldProvider);
        CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&world->chunkProvider, 1);
        CloneMCJ_BlockSimulation_RegisterWorld(world);
        chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider, 0, 0);
        if (chunk) CloneMCJ_Chunk_SetBlockID(chunk, 0, 0, 0, 1, (CloneMCJ_BlockLightOpacityProc)0, 0);
        if(chunk){
            /* V132.3: World.updateEntityWithOptionalForce gates EntityItem
             * before onUpdate, so neither gravity, pickup delay nor Age moves
             * while required collision terrain is absent. */
            CloneMCJ_Chunk_SetBlockID(chunk,8,0,8,1,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_ItemStack_Initialize(&stack,4,3,0);
            CloneMCJ_EntityItem_Initialize(&dropped,world,8.5,1.0,8.5,&stack);
            dropped.delayBeforeCanPickup=10;
            dropped.entity.motionX=0.0;dropped.entity.motionY=0.0;
            dropped.entity.motionZ=0.0;
            CloneMCJ_EntityItem_Tick(&dropped);
            if(!failure&&(dropped.age!=1||dropped.delayBeforeCanPickup!=9||
                !dropped.active||!dropped.entity.onGround||
                world->chunkProvider.residentCount!=1))
                failure="V132.3 loaded dropped-item active tick/ground collision failed";

            CloneMCJ_EntityItem_Initialize(&dropped,world,16.25,64.0,8.5,&stack);
            dropped.age=1234;dropped.delayBeforeCanPickup=40;
            dropped.entity.motionX=-0.3;dropped.entity.motionY=-0.2;
            CloneMCJ_EntityItem_Tick(&dropped);
            if(!failure&&(dropped.age!=1234||
                dropped.delayBeforeCanPickup!=40||
                dropped.entity.posX!=16.25||dropped.entity.posY!=64.0||
                world->chunkProvider.residentCount!=1))
                failure="V132.3 unloaded-chunk item suspension advanced physics or timer";

            compound=CloneMCJ_NBTTagCompound_Create();
            memset(&decodedDropped,0,sizeof(decodedDropped));
            if(!failure&&(!compound||
                !CloneMCJ_EntityItem_WriteNBT(&dropped,compound)||
                !CloneMCJ_EntityItem_ReadNBT(&decodedDropped,compound,world)||
                decodedDropped.age!=1234||decodedDropped.item.itemID!=4||
                decodedDropped.item.stackSize!=3||
                decodedDropped.delayBeforeCanPickup!=0))
                failure="V132.3 dropped-item Java Age/Item NBT round trip failed";
            if(compound)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);

            CloneMCJ_EntityItem_Initialize(&dropped,world,8.5,1.0,8.5,&stack);
            dropped.age=5999;
            CloneMCJ_EntityItem_Tick(&dropped);
            if(!failure&&(dropped.active||!dropped.entity.isDead||
                dropped.age!=6000))
                failure="V132.3 dropped item did not despawn at 6000 active ticks";
        }
        if(chunk){
            /* BlockCloth.java preserves metadata and maps the sixteen wool
             * colors to their exact terrain-atlas tiles. */
            for(i=0;i<16&&!failure;++i){
                CloneMCJ_ItemStack_Clear(&stack);
                if(CloneMCJ_BlockCloth_TextureNative(i)!=expectedWoolTexture[i]||
                   !CloneMCJ_Block_GetDroppedStack(35,i,&dropRandom,&stack)||
                   stack.itemID!=35||stack.stackSize!=1||stack.itemDamage!=i)
                    failure="V125 BlockCloth texture/drop metadata mapping failed";
            }
            if(!failure&&(CloneMCJ_BlockRegistry_Get(35)->material!=
                CLONEMC_J_MATERIAL_CLOTH||!CloneMCJ_BlockRegistry_Get(35)->solid||
                !CloneMCJ_BlockRegistry_Get(35)->opaque||
                !CloneMCJ_BlockRegistry_Get(35)->collidable||
                CloneMCJ_BlockRegistry_Get(35)->minY!=0.0||
                CloneMCJ_BlockRegistry_Get(35)->maxY!=1.0))
                failure="V126 wool was not registered as a full solid cloth cube";

            /* ItemBucket.java traces from the eye along the Java look vector,
             * collects only metadata-zero sources, and offsets full-bucket
             * placement onto the selected face. */
            CloneMCJ_EntityPlayer_Initialize(&player,world,"BucketTest");
            CloneMCJ_Entity_SetPosition(&player.entity,1.5,1.38,1.5);
            CloneMCJ_Entity_SetRotation(&player.entity,0.0F,0.0F);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,1,3,3,9,0);
            CloneMCJ_ItemStack_Initialize(&stack,325,1,0);
            if(!failure&&(!CloneMCJ_ItemBucket_UseNative(world,&player,&stack)||
                stack.itemID!=326||CloneMCJ_World_GetBlockId(world,1,3,3)!=0))
                failure="V126 empty bucket did not collect the viewed water source";
            CloneMCJ_World_SetBlockWithMetadataNotify(world,1,3,3,1,0);
            if(!failure&&(!CloneMCJ_ItemBucket_UseNative(world,&player,&stack)||
                stack.itemID!=325||CloneMCJ_World_GetBlockId(world,1,3,2)!=8||
                CloneMCJ_World_GetBlockMetadata(world,1,3,2)!=0))
                failure="V126 water bucket did not place a source and become empty";
            CloneMCJ_World_SetBlockNotify(world,1,3,2,0);
            CloneMCJ_World_SetBlockNotify(world,1,3,3,0);
            /* Bucket liquid placement schedules fluid work. Keep the
             * following redstone timing checks independent. */
            chunk->scheduledTickCount=0;
            /* Metadata 1 attaches to the block west of the button. */
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,0,2,1,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,2,1,1,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,1,2,1,77,1,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,2,2,1,55,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_BlockButton_RegisterRuntime(world);
            CloneMCJ_BlockRedstoneWire_RegisterRuntime(world);
            if(!failure&&(!CloneMCJ_BlockButton_CanPlaceOnSideNative(world,1,2,1,5)||
                CloneMCJ_BlockButton_CanPlaceOnSideNative(world,1,2,1,4)))
                failure="Java BlockButton side-support placement test failed";
            if(!failure&&(!CloneMCJ_BlockButton_ActivateNative(world,1,2,1)||
                CloneMCJ_World_GetBlockMetadata(world,1,2,1)!=9||
                CloneMCJ_World_GetBlockMetadata(world,2,2,1)!=15||
                chunk->scheduledTickCount!=1))
                failure="Java BlockButton press/redstone-power/schedule test failed";
            CloneMCJ_World_TickTime(world,20);CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&(CloneMCJ_World_GetBlockMetadata(world,1,2,1)!=1||
                CloneMCJ_World_GetBlockMetadata(world,2,2,1)!=0))
                failure="Java BlockButton 20-tick release/redstone decay test failed";
            CloneMCJ_World_SetBlockNotify(world,0,2,1,0);
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,0,2,1,1);
            if(!failure&&CloneMCJ_World_GetBlockId(world,1,2,1)!=0)
                failure="Java BlockButton did not detach when its support was removed";
            /* A real Java door requires a normal supporting cube. Keep the
             * paired-half activation test physically valid so neighbor
             * notifications do not correctly remove the unsupported door. */
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,2,0,1,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,2,1,1,64,2,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,2,2,1,64,10,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&(!CloneMCJ_BlockDoor_ActivateNative(world,2,2,1)||
                CloneMCJ_World_GetBlockMetadata(world,2,1,1)!=6||
                CloneMCJ_World_GetBlockMetadata(world,2,2,1)!=14))
                failure="Java BlockDoor paired-half metadata test failed";
            if(!failure&&(CloneMCJ_Block_GetCollisionBoxes(world,2,1,1,doorBoxes,3)!=1||
                CloneMCJ_Block_GetCollisionBoxes(world,2,2,1,doorBoxes+1,2)!=1||
                doorBoxes[0].minZ<1.81||doorBoxes[1].minZ<1.81))
                failure="V115 open-door lower/upper collision state failed";
            CloneMCJ_Entity_SetPosition(&player.entity,2.5,1.0,1.9);
            if(!failure&&CloneMCJ_Entity_IsInsideOpaqueBlock(&player.entity,1.62F))
                failure="V149 non-opaque door top half caused suffocation damage";
            /* Iron doors use the same paired geometry/top-half ownership but
             * reject manual activation, exactly as BlockDoor.java. */
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,5,0,1,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,5,1,1,71,2,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,5,2,1,71,10,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&(!CloneMCJ_BlockDoor_ActivateNative(world,5,2,1)||
                CloneMCJ_World_GetBlockMetadata(world,5,1,1)!=2||
                CloneMCJ_World_GetBlockMetadata(world,5,2,1)!=10||
                CloneMCJ_Block_GetCollisionBoxes(world,5,1,1,doorBoxes,3)!=1||
                CloneMCJ_Block_GetCollisionBoxes(world,5,2,1,doorBoxes+1,2)!=1))
                failure="V149 iron-door paired top/collision/manual activation failed";
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,3,2,3,96,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&(CloneMCJ_Block_GetCollisionBoxes(world,3,2,3,doorBoxes,3)!=1||
                doorBoxes[0].minY!=2.0||doorBoxes[0].maxY<2.1874||doorBoxes[0].maxY>2.1876))
                failure="V122 closed trapdoor collision did not use the Java 3/16 slab";
            if(!failure&&(!CloneMCJ_BlockTrapDoor_ActivateNative(world,3,2,3)||
                (CloneMCJ_World_GetBlockMetadata(world,3,2,3)&4)==0||
                CloneMCJ_Block_GetCollisionBoxes(world,3,2,3,doorBoxes,3)!=1||
                doorBoxes[0].minZ<3.8124||doorBoxes[0].maxZ!=4.0))
                failure="V122 open trapdoor collision did not move to its vertical edge";
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,10,100,10,60,1,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,10,101,10,0,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_ItemStack_Initialize(&stack,295,2,0);
            if(!failure&&(!CloneMCJ_ItemSeeds_UseNative(world,&stack,10,100,10,1)||
                CloneMCJ_World_GetBlockId(world,10,101,10)!=59||stack.stackSize!=1))
                failure="V122 ItemSeeds did not plant crops on the top of farmland";
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,11,1,11,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,11,5,11,12,0);
            CloneMCJ_World_TickTime(world,3);
            CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&(CloneMCJ_World_GetBlockId(world,11,5,11)!=0||
                CloneMCJ_World_GetBlockId(world,11,2,11)!=12))
                failure="V122 scheduled sand gravity did not preserve and land the block";
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,12,0,11,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,12,6,11,13,2);
            CloneMCJ_World_TickTime(world,3);
            CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&(CloneMCJ_World_GetBlockId(world,12,6,11)!=0||
                CloneMCJ_World_GetBlockId(world,12,1,11)!=13||
                CloneMCJ_World_GetBlockMetadata(world,12,1,11)!=2))
                failure="V122 scheduled gravel gravity lost its metadata or failed to land";
            /* Lever.java: powered state is metadata bit 3, the support
             * orientation controls strong power, and removing the attached
             * cube removes the lever and its final power notification. */
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,0,4,4,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,2,3,4,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,1,4,4,69,1);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,2,4,4,55,0);
            if(!failure&&(!CloneMCJ_BlockLever_ActivateNative(world,1,4,4)||
                CloneMCJ_World_GetBlockMetadata(world,1,4,4)!=9||
                CloneMCJ_World_GetBlockMetadata(world,2,4,4)!=15))
                failure="V125 Java lever power/wire propagation failed";
            if(!failure&&(!CloneMCJ_BlockLever_ActivateNative(world,1,4,4)||
                CloneMCJ_World_GetBlockMetadata(world,1,4,4)!=1||
                CloneMCJ_World_GetBlockMetadata(world,2,4,4)!=0))
                failure="V125 Java lever power-off/wire decay failed";
            /* BlockRedstoneLight.java swaps the unlit/lit block IDs
             * immediately on neighbor power changes. The registry emission
             * values drive the bounded block-light update queue. */
            CloneMCJ_World_SetBlockNotify(world,1,4,3,123);
            if(!failure&&(!CloneMCJ_BlockLever_ActivateNative(world,1,4,4)||
                CloneMCJ_World_GetBlockId(world,1,4,3)!=124||
                CloneMCJ_BlockRegistry_Get(124)->lightEmission!=15))
                failure="V147 powered redstone lamp did not light";
            if(!failure&&(!CloneMCJ_BlockLever_ActivateNative(world,1,4,4)||
                CloneMCJ_World_GetBlockId(world,1,4,3)!=123||
                CloneMCJ_BlockRegistry_Get(123)->lightEmission!=0))
                failure="V147 unpowered redstone lamp did not extinguish";
            /* A powered lever must also drive ordinary redstone consumers
             * directly through neighborChanged, not only wire. */
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,1,3,5,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,1,4,5,64,0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,1,5,5,64,8);
            if(!failure&&(!CloneMCJ_BlockLever_ActivateNative(world,1,4,4)||
                (CloneMCJ_World_GetBlockMetadata(world,1,4,5)&4)==0))
                failure="V126 powered lever did not open an adjacent wooden door";
            if(!failure&&(!CloneMCJ_BlockLever_ActivateNative(world,1,4,4)||
                (CloneMCJ_World_GetBlockMetadata(world,1,4,5)&4)!=0))
                failure="V126 unpowered lever did not close an adjacent wooden door";
            CloneMCJ_World_SetBlockNotify(world,0,4,4,0);
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,0,4,4,1);
            if(!failure&&CloneMCJ_World_GetBlockId(world,1,4,4)!=0)
                failure="V125 Java lever attachment-loss removal failed";

            /* Repeater.java: orientation zero reads from +Z, delay metadata
             * cycles 1..4 redstone ticks, and active output is directional.
             * Java ScheduledTickTreeSet de-duplicates by x/y/z/block ID. The
             * onBlockAdded neighbor notifications can therefore install the
             * normal two-tick delay before onBlockPlacedBy requests its one-
             * tick bootstrap; the earlier entry remains authoritative. */
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,4,3,4,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,4,3,5,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,4,3,6,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,4,4,6,69,13);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,4,4,5,55,0);
            if(!failure&&CloneMCJ_World_GetBlockMetadata(world,4,4,5)!=15)
                failure="V125 repeater test source did not power its input wire";
            CloneMCJ_World_SetBlockWithMetadataNotify(world,4,4,4,93,0);
            CloneMCJ_BlockRedstoneRepeater_OnPlacedByNative(world,4,4,4);
            CloneMCJ_World_TickTime(world,1);
            CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&CloneMCJ_World_GetBlockId(world,4,4,4)!=93)
                failure="V125 repeater ignored Java duplicate scheduled-tick ordering";
            CloneMCJ_World_TickTime(world,1);
            CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&(CloneMCJ_World_GetBlockId(world,4,4,4)!=94||
                !CloneMCJ_World_IsBlockProvidingPowerTo(world,4,4,4,3)||
                CloneMCJ_World_IsBlockProvidingPowerTo(world,4,4,4,2)))
                failure="V125 Java repeater delayed directional output failed";
            if(!failure&&(!CloneMCJ_BlockRedstoneRepeater_ActivateNative(
                world,4,4,4)||CloneMCJ_World_GetBlockMetadata(world,4,4,4)!=4))
                failure="V125 Java repeater delay-cycle metadata failed";
            CloneMCJ_BlockLever_ActivateNative(world,4,4,6);
            if(!failure&&CloneMCJ_World_GetBlockMetadata(world,4,4,5)!=0)
                failure="V125 repeater input wire did not decay after source removal";
            CloneMCJ_World_TickTime(world,3);
            CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&CloneMCJ_World_GetBlockId(world,4,4,4)!=94)
                failure="V125 repeater ignored selected four-tick off delay";
            CloneMCJ_World_TickTime(world,1);
            CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&CloneMCJ_World_GetBlockId(world,4,4,4)!=93)
                failure="V125 repeater did not switch off after selected delay";

            /* Stone plates trigger living entities; wooden plates also trigger
             * dropped items. Both release after the Java 20-tick recheck. */
            world->gameplayUserData=&gameplay;
            gameplay.player.entity.worldObj=world;
            CloneMCJ_Entity_SetPosition(&gameplay.player.entity,7.5,4.05,7.5);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,7,3,7,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,7,4,7,70,0);
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,7,4,7);
            if(!failure&&CloneMCJ_World_GetBlockMetadata(world,7,4,7)!=1)
                failure="V125 stone pressure plate did not detect player";
            CloneMCJ_Entity_SetPosition(&gameplay.player.entity,12.5,4.0,12.5);
            CloneMCJ_World_TickTime(world,20);
            CloneMCJ_World_ProcessScheduledTicks(world,0);
            if(!failure&&CloneMCJ_World_GetBlockMetadata(world,7,4,7)!=0)
                failure="V125 stone pressure plate did not release after 20 ticks";
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,8,3,7,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,8,4,7,72,0);
            gameplay.droppedItems[0].active=1;
            gameplay.droppedItems[0].entity.worldObj=world;
            CloneMCJ_Entity_SetPosition(&gameplay.droppedItems[0].entity,
                8.5,4.05,7.5);
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,8,4,7);
            if(!failure&&CloneMCJ_World_GetBlockMetadata(world,8,4,7)!=1)
                failure="V125 wooden pressure plate did not detect dropped item";
            gameplay.droppedItems[0].active=0;
            /* V150.1 environmental replacement/support loss must queue the
             * exact block item before clearing it.  This covers both the
             * missing BlockTorch lifecycle and BlockFlowing.flowIntoBlock. */
            gameplay.world=world;
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,10,3,7,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,10,4,7,50,5);
            CloneMCJ_World_SetBlockNotify(world,10,3,7,0);
            foundTorchDrop=0;
            for(i=0;i<gameplay.droppedItemCount;++i)
                if(gameplay.droppedItems[i].active&&
                   gameplay.droppedItems[i].item.itemID==50)foundTorchDrop=1;
            if(!failure&&(CloneMCJ_World_GetBlockId(world,10,4,7)!=0||
                !foundTorchDrop))
                failure="V150.1 unsupported torch disappeared without an item drop";
            for(i=0;i<gameplay.droppedItemCount;++i)
                gameplay.droppedItems[i].active=0;
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,11,3,7,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,11,4,7,50,5);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,11,5,7,8,0);
            CloneMCJ_BlockFlowing_UpdateTick(world,11,5,7,8,&world->rand,
                (void *)0);
            foundTorchDrop=0;
            for(i=0;i<gameplay.droppedItemCount;++i)
                if(gameplay.droppedItems[i].active&&
                   gameplay.droppedItems[i].item.itemID==50)foundTorchDrop=1;
            if(!failure&&(CloneMCJ_World_GetBlockId(world,11,4,7)!=8||
                !foundTorchDrop))
                failure="V150.1 flowing water erased a displaced torch drop";
            for(i=0;i<gameplay.droppedItemCount;++i)
                gameplay.droppedItems[i].active=0;
            world->gameplayUserData=(void *)0;

            /* PistonBase/TileEntityPiston: extension and retraction use block
             * 36 moving tiles for three update calls; normal pistons leave the
             * pushed block, sticky pistons pull it back by one block. */
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,9,4,4,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,8,4,4,33,5);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,8,5,4,69,13);
            if(!failure&&((CloneMCJ_World_GetBlockMetadata(world,8,4,4)&8)==0||
                CloneMCJ_World_GetBlockId(world,9,4,4)!=36||
                CloneMCJ_World_GetBlockId(world,10,4,4)!=36))
                failure="V125 piston did not create moving extension tiles";
            for(guard=0;guard<3;++guard){
                movingA=CloneMCJ_Chunk_GetTileEntity(chunk,9,4,4);
                movingB=CloneMCJ_Chunk_GetTileEntity(chunk,10,4,4);
                if(movingA)CloneMCJ_TileEntity_Update(movingA);
                if(movingB)CloneMCJ_TileEntity_Update(movingB);
            }
            if(!failure&&(CloneMCJ_World_GetBlockId(world,9,4,4)!=34||
                CloneMCJ_World_GetBlockId(world,10,4,4)!=1))
                failure="V125 piston extension did not finalize head/pushed block";
            CloneMCJ_World_SetBlockMetadataNotify(world,8,5,4,5);
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,8,5,4,69);
            if(!failure&&CloneMCJ_World_GetBlockId(world,8,4,4)!=36)
                failure="V125 piston did not create retracting base tile";
            for(guard=0;guard<3;++guard){
                movingA=CloneMCJ_Chunk_GetTileEntity(chunk,8,4,4);
                if(movingA)CloneMCJ_TileEntity_Update(movingA);
            }
            if(!failure&&(CloneMCJ_World_GetBlockId(world,8,4,4)!=33||
                CloneMCJ_World_GetBlockId(world,9,4,4)!=0||
                CloneMCJ_World_GetBlockId(world,10,4,4)!=1))
                failure="V125 normal piston retraction final state failed";

            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,9,4,8,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,8,4,8,29,5);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,8,5,8,69,13);
            for(guard=0;guard<3;++guard){
                movingA=CloneMCJ_Chunk_GetTileEntity(chunk,9,4,8);
                movingB=CloneMCJ_Chunk_GetTileEntity(chunk,10,4,8);
                if(movingA)CloneMCJ_TileEntity_Update(movingA);
                if(movingB)CloneMCJ_TileEntity_Update(movingB);
            }
            CloneMCJ_World_SetBlockMetadataNotify(world,8,5,8,5);
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,8,5,8,69);
            if(!failure&&(CloneMCJ_World_GetBlockId(world,8,4,8)!=36||
                CloneMCJ_World_GetBlockId(world,9,4,8)!=36))
                failure="V125 sticky piston did not create pull/retract tiles";
            for(guard=0;guard<3;++guard){
                movingA=CloneMCJ_Chunk_GetTileEntity(chunk,8,4,8);
                movingB=CloneMCJ_Chunk_GetTileEntity(chunk,9,4,8);
                if(movingA)CloneMCJ_TileEntity_Update(movingA);
                if(movingB)CloneMCJ_TileEntity_Update(movingB);
            }
            if(!failure&&(CloneMCJ_World_GetBlockId(world,8,4,8)!=29||
                CloneMCJ_World_GetBlockId(world,9,4,8)!=1||
                CloneMCJ_World_GetBlockId(world,10,4,8)!=0))
                failure="V125 sticky piston did not pull the block back";
            CloneMCJ_EntityPlayer_Initialize(&placementPlayer, world, "Builder");
            CloneMCJ_Entity_SetPosition(&placementPlayer.entity, 12.5, 103.0, 12.5);
            placementPlayer.inventory.currentItem = 0;
            CloneMCJ_ItemStack_Initialize(&placementPlayer.inventory.mainInventory[0], 1, 2, 0);
            CloneMCJ_PlayerControllerSP_Initialize(&placementController, world, &placementPlayer);
            /* PlayerControllerSP.java keeps one continuous curBlockDamage value
             * for the selected coordinate. RenderGlobal converts it to stages
             * 0..9 and the overlay remains until the block is actually removed. */
            CloneMCJ_ItemStack_Initialize(
                &placementPlayer.inventory.mainInventory[0],270,1,0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,14,100,14,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&!CloneMCJ_PlayerControllerSP_ClickBlock(
                &placementController,14,100,14))
                failure="V125 break animation could not start on stone";
            lastDamage=0.0F;guard=0;
            while(!failure&&CloneMCJ_World_GetBlockId(world,14,100,14)!=0&&
                  guard<200){
                CloneMCJ_PlayerControllerSP_DamageBlock(
                    &placementController,14,100,14);
                if(CloneMCJ_World_GetBlockId(world,14,100,14)!=0){
                    if(!placementController.hittingBlock||
                       placementController.currentBlockDamage<lastDamage||
                       placementController.currentBlockDamage<=0.0F||
                       placementController.currentBlockDamage>=1.0F)
                        failure="V125 break animation did not persist monotonically until harvest";
                    lastDamage=placementController.currentBlockDamage;
                }
                ++guard;
            }
            if(!failure&&(CloneMCJ_World_GetBlockId(world,14,100,14)!=0||
                placementController.hittingBlock||
                placementController.currentBlockDamage!=0.0F||
                placementController.currentBlockX!=-999999))
                failure="V125 break animation state did not clear exactly after block removal";
            /* ItemHoe.java: dirt tills regardless of clicked side because &&
             * binds before ||; grass requires a non-bottom side and air above. */
            CloneMCJ_ItemStack_Initialize(&placementPlayer.inventory.mainInventory[0],290,1,0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,6,100,6,3,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,6,101,6,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&(!CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,6,100,6,0)||
                CloneMCJ_World_GetBlockId(world,6,100,6)!=60||
                placementPlayer.inventory.mainInventory[0].itemDamage!=1))
                failure="V125 Java hoe dirt precedence/durability test failed";
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,7,100,6,2,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,7,101,6,0,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,7,100,6,0))
                failure="V125 hoe incorrectly tilled grass through the bottom face";
            if(!failure&&(!CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,7,100,6,1)||
                CloneMCJ_World_GetBlockId(world,7,100,6)!=60||
                placementPlayer.inventory.mainInventory[0].itemDamage!=2))
                failure="V125 hoe did not till Java-valid grass";
            /* ItemRedstone.java offsets to the clicked face, requires a
             * normal cube below, places wire 55, and consumes one dust. */
            CloneMCJ_ItemStack_Initialize(&placementPlayer.inventory.mainInventory[0],331,2,0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,9,100,9,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,9,101,9,0,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&(!CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,9,100,9,1)||
                CloneMCJ_World_GetBlockId(world,9,101,9)!=55||
                placementPlayer.inventory.mainInventory[0].stackSize!=1))
                failure="V125 ItemRedstone placement/support/consumption test failed";
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,10,100,9,0,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&CloneMCJ_ItemRedstone_UseNative(world,
                &placementPlayer.inventory.mainInventory[0],&placementPlayer,
                10,100,9,1))
                failure="V125 ItemRedstone placed without a supporting cube";
            /* ItemBed.java places foot and head with the yaw-derived direction
             * and head bit 8, consuming exactly one bed item. */
            CloneMCJ_ItemStack_Initialize(&placementPlayer.inventory.mainInventory[0],355,1,0);
            placementPlayer.entity.rotationYaw=0.0F;
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,12,99,12,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,12,99,13,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&(!CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,12,99,12,1)||
                CloneMCJ_World_GetBlockId(world,12,100,12)!=26||
                CloneMCJ_World_GetBlockId(world,12,100,13)!=26||
                CloneMCJ_World_GetBlockMetadata(world,12,100,12)!=0||
                CloneMCJ_World_GetBlockMetadata(world,12,100,13)!=8||
                !CloneMCJ_ItemStack_IsEmpty(&placementPlayer.inventory.mainInventory[0])))
                failure="V125 Java bed two-block placement/direction test failed";
            CloneMCJ_ItemStack_Initialize(&placementPlayer.inventory.mainInventory[0],1,2,0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,8,100,8,1,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,8,101,8,0,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,8,102,8,0,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,8,103,8,0,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&(!CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,8,100,8,1)||
                placementPlayer.inventory.mainInventory[0].stackSize!=1||
                CloneMCJ_World_GetBlockId(world,8,101,8)!=1||
                !CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,8,101,8,1)||
                !CloneMCJ_ItemStack_IsEmpty(&placementPlayer.inventory.mainInventory[0])||
                CloneMCJ_World_GetBlockId(world,8,102,8)!=1||
                CloneMCJ_PlayerControllerSP_PlaceBlock(&placementController,8,102,8,1)||
                CloneMCJ_World_GetBlockId(world,8,103,8)!=0))
                failure="V116 placement count/infinite-placement regression test failed";
            /* Beta ChunkProviderLoadOrGenerate.saveChunks(false) performs at
             * most two writes.  Verify the native round-robin budget so the
             * 600-tick (30-second) autosave cannot freeze generation/rendering by
             * flushing the complete resident set. */
            g_cloneMCV117SavedChunks=0;
            world->chunkProvider.saver=CloneMCJ_V117_CountingChunkSaver;
            world->chunkProvider.saverUser=(void *)0;
            /* The mechanics above intentionally dirty/load supporting chunks.
             * Isolate the autosave-budget assertion to exactly five chunks. */
            for(i=0;i<CLONEMC_J_CHUNK_CACHE_CAPACITY;++i){
                if(world->chunkProvider.slots[i].used&&
                   world->chunkProvider.slots[i].chunk){
                    world->chunkProvider.slots[i].chunk->isModified=0;
                    if(world->chunkProvider.slots[i].chunk->state==
                       CLONEMC_J_CHUNK_STATE_DIRTY_SAVE_QUEUED)
                        world->chunkProvider.slots[i].chunk->state=
                            CLONEMC_J_CHUNK_STATE_READY;
                }
            }
            chunk->state=CLONEMC_J_CHUNK_STATE_READY;
            chunk->isModified=0;
            CloneMCJ_Chunk_SetBlockMetadata(chunk,8,100,8,3);
            if(!failure&&(!chunk->isModified||
                chunk->state!=CLONEMC_J_CHUNK_STATE_DIRTY_SAVE_QUEUED))
                failure="V118 metadata-only edit did not enter dirty-save queue";
            chunk->isModified=1;
            for(i=2;i<6;++i){
                saveChunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(
                    &world->chunkProvider,i,0);
                if(saveChunk)saveChunk->isModified=1;
            }
            remaining=-1;
            saveResult=CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunksBudget(
                &world->chunkProvider,0,2,&remaining);
            if(!failure&&(saveResult!=2||remaining!=3||
                g_cloneMCV117SavedChunks!=2))
                failure="V117 two-chunk incremental autosave budget failed";
            saveResult=CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunksBudget(
                &world->chunkProvider,0,2,&remaining);
            if(!failure&&(saveResult!=2||remaining!=1||
                g_cloneMCV117SavedChunks!=4))
                failure="V117 autosave round-robin continuation failed";
            saveResult=CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunksBudget(
                &world->chunkProvider,0,2,&remaining);
            if(!failure&&(saveResult!=1||remaining!=0||
                g_cloneMCV117SavedChunks!=5))
                failure="V117 autosave final bounded batch failed";
            CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(
                &world->chunkProvider,1);
            CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(
                &world->chunkProvider,0,0);
            CloneMCJ_ChunkProviderLoadOrGenerate_UnloadOldestChunks(
                &world->chunkProvider,CLONEMC_J_CHUNK_CACHE_CAPACITY);
            if(!failure&&world->chunkProvider.residentCount!=1)
                failure="V117 autosave test cleanup retained distant chunks";
            chunk->isModified = 1;
            world->chunkProvider.saver = CloneMCJ_V116_FailingChunkSaver;
            world->chunkProvider.saverUser = (void *)0;
            CloneMCJ_ChunkProviderLoadOrGenerate_SetAllowedRadius(&world->chunkProvider,1);
            CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(&world->chunkProvider,10,10);
            if(!failure&&(CloneMCJ_ChunkProviderLoadOrGenerate_UnloadOldestChunks(
                &world->chunkProvider,1)!=0||world->chunkProvider.residentCount!=1||
                !chunk->isModified||!chunk->loaded))
                failure="V116 dirty chunk was discarded after failed save";
            /* Restore the provider center before the collision test.  The dirty
               chunk intentionally remained resident outside the prior radius. */
            CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(
                &world->chunkProvider,0,0);
        }
        CloneMCJ_Entity_Initialize(&collisionEntity, world);
        CloneMCJ_Entity_SetPosition(&collisionEntity, 0.5, 2.0, 0.5);
        CloneMCJ_Entity_Move(&collisionEntity, 0.0, -3.0, 0.0);
        if (!failure && (!collisionEntity.onGround || collisionEntity.posY < 0.999 || collisionEntity.posY > 1.001))
            failure = "Priority 7 AABB ground collision test failed";
        CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&world->chunkProvider);
        free(world);
    }
    if (failure) {
        CloneMCJ_Priority7_SetMessage(message, messageCapacity, failure);
        return 0;
    }
    CloneMCJ_Priority7_SetMessage(message, messageCapacity,
        "Priority 7/V132.3 gameplay tests passed: Java redstone, tools, drops, chunk-safe item suspension, 6000-tick despawn, persistence, mobs and collision");
    return 1;
}

int CloneMCJ_Priority12_RunSelfTests(char *message,unsigned int messageCapacity)
{
    CloneMCJ_EntityPlayer player;CloneMCJ_Mob wolf,decodedWolf;
    CloneMCJ_Mob zombie,slime,decodedSlime;
    CloneMCJ_Vehicle cart,decodedCart,otherCart,painting;
    CloneMCJ_Projectile arrow,fireball,decodedFireball;
    CloneMCJ_Entity storedEntity,decodedEntity,freshEntity,owner;
    CloneMCJ_NBTTagCompound *tag;CloneMCJ_World *world;CloneMCJ_Chunk *chunk;
    CloneMCJ_GameplayState *gameplay;
    CloneMCJ_PathEntityNative nativePath;
    CloneMCJ_MobType mappedType;
    const char *failure;int pathIndex,pathAvoidsObstacle;
    failure=(const char *)0;CloneMCJ_EntityPlayer_Initialize(&player,(CloneMCJ_World *)0,"P12");
    CloneMCJ_ItemStack_Initialize(&player.inventory.armorInventory[0],310,1,0);
    CloneMCJ_ItemStack_Initialize(&player.inventory.armorInventory[1],311,1,0);
    CloneMCJ_ItemStack_Initialize(&player.inventory.armorInventory[2],312,1,0);
    CloneMCJ_ItemStack_Initialize(&player.inventory.armorInventory[3],313,1,0);
    if(CloneMCJ_InventoryPlayer_GetTotalArmorValue(&player.inventory)!=20)failure="Priority 12 armor value failed";
    if(!failure&&(!CloneMCJ_EntityList_MobTypeForName("Giant",&mappedType)||mappedType!=CLONEMC_J_MOB_GIANT||
        !CloneMCJ_EntityList_MobTypeForName("Ghast",&mappedType)||mappedType!=CLONEMC_J_MOB_GHAST||
        !CloneMCJ_EntityList_MobTypeForName("PigZombie",&mappedType)||mappedType!=CLONEMC_J_MOB_PIG_ZOMBIE))
        failure="Priority 12 complete EntityList mob IDs failed";
    if(!failure&&(!CloneMCJ_EntityList_NameForNumericID(50)||
        strcmp(CloneMCJ_EntityList_NameForNumericID(50),"Creeper")||
        CloneMCJ_EntityList_NumericIDForName("Wolf")!=95||
        CloneMCJ_EntityList_NumericIDForName("NotAnEntity")!=-1))
        failure="Priority 12 Java numeric/string EntityList mapping failed";
    if(!failure){CloneMCJ_EntityLiving_InitializeMob(&wolf,CLONEMC_J_MOB_WOLF,(CloneMCJ_World *)0,1,2,3);
        wolf.tamed=1;wolf.sitting=1;strcpy(wolf.owner,"P12");tag=CloneMCJ_NBTTagCompound_Create();
        if(!tag||!CloneMCJ_Mob_WriteNBT(&wolf,tag)||!CloneMCJ_Mob_ReadNBT(&decodedWolf,tag,(CloneMCJ_World *)0)||
            decodedWolf.type!=CLONEMC_J_MOB_WOLF||!decodedWolf.tamed||
            !decodedWolf.persistenceRequired||strcmp(decodedWolf.owner,"P12"))
            failure="Priority 12 mob EntityList/NBT failed";
        if(tag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);}
    if(!failure){CloneMCJ_Vehicle_Initialize(&cart,CLONEMC_J_VEHICLE_MINECART,(CloneMCJ_World *)0,1,2,3,2);
        cart.fuel=1200;cart.pushX=0.25;cart.pushZ=-0.5;tag=CloneMCJ_NBTTagCompound_Create();
        if(!tag||!CloneMCJ_Vehicle_WriteNBT(&cart,tag)||!CloneMCJ_Vehicle_ReadNBT(&decodedCart,tag,(CloneMCJ_World *)0)||
            decodedCart.minecartType!=2||decodedCart.fuel!=1200||decodedCart.pushX!=0.25||decodedCart.pushZ!=-0.5)
            failure="Priority 12 furnace minecart NBT failed";
        if(tag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);}
    if(!failure){CloneMCJ_Vehicle_Initialize(&cart,CLONEMC_J_VEHICLE_MINECART,(CloneMCJ_World *)0,1,2,3,1);
        CloneMCJ_ItemStack_Initialize(&cart.cargo[4],265,12,0);tag=CloneMCJ_NBTTagCompound_Create();
        if(!tag||!CloneMCJ_Vehicle_WriteNBT(&cart,tag)||!CloneMCJ_Vehicle_ReadNBT(&decodedCart,tag,(CloneMCJ_World *)0)||
            decodedCart.minecartType!=1||decodedCart.cargo[4].itemID!=265||decodedCart.cargo[4].stackSize!=12)
            failure="Priority 12 vehicle cargo NBT failed";
        if(tag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);}
    if(!failure){CloneMCJ_EntityLiving_InitializeMob(&zombie,CLONEMC_J_MOB_ZOMBIE,
            (CloneMCJ_World *)0,0,0,0);zombie.entityAge=700;zombie.entity.motionY=0.0;
        if(zombie.health!=20||zombie.moveSpeed!=0.5F||
            !CloneMCJ_EntityLiving_AttackMobFrom(&zombie,(const CloneMCJ_Entity *)0,2)||
            zombie.health!=18||zombie.entityAge!=0||zombie.entity.motionY!=0.0)
            failure="Priority 12 Java living damage/knockback constants failed";}
    if(!failure){CloneMCJ_EntityLiving_InitializeMob(&slime,CLONEMC_J_MOB_SLIME,
            (CloneMCJ_World *)0,0,0,0);tag=CloneMCJ_NBTTagCompound_Create();
        if(tag){CloneMCJ_Mob_WriteNBT(&slime,tag);CloneMCJ_NBTTagCompound_SetInteger(tag,"Size",999);}
        if(!tag||!CloneMCJ_Mob_ReadNBT(&decodedSlime,tag,(CloneMCJ_World *)0)||
            decodedSlime.slimeSize!=16)failure="Priority 12 hostile NBT bounds failed";
        if(tag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);}
    if(!failure){CloneMCJ_Entity_Initialize(&storedEntity,(CloneMCJ_World *)0);
        storedEntity.entityId=40000;storedEntity.motionX=25.0;CloneMCJ_Entity_SetPosition(&storedEntity,1,2,3);
        tag=CloneMCJ_NBTTagCompound_Create();
        if(!tag||!CloneMCJ_Entity_WriteNBT(&storedEntity,tag,"Mob"))failure="Priority 12 identity NBT write failed";
        if(!failure){CloneMCJ_Entity_Initialize(&decodedEntity,(CloneMCJ_World *)0);
            if(!CloneMCJ_Entity_ReadNBT(&decodedEntity,tag)||decodedEntity.entityId!=40000||
                decodedEntity.motionX!=0.0)failure="Priority 12 safe identity/motion restore failed";}
        CloneMCJ_Entity_Initialize(&freshEntity,(CloneMCJ_World *)0);
        if(!failure&&freshEntity.entityId<=40000)failure="Priority 12 restored identity reservation failed";
        if(tag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);}
    if(!failure){CloneMCJ_Projectile_Initialize(&fireball,CLONEMC_J_PROJECTILE_FIREBALL,
            (CloneMCJ_World *)0,(const CloneMCJ_Entity *)0,1,0);fireball.accelerationX=0.07;
        fireball.accelerationY=-0.02;fireball.accelerationZ=0.03;tag=CloneMCJ_NBTTagCompound_Create();
        if(!tag||!CloneMCJ_Projectile_WriteNBT(&fireball,tag)||
            !CloneMCJ_Projectile_ReadNBT(&decodedFireball,tag,(CloneMCJ_World *)0)||
            decodedFireball.accelerationX!=0.07||decodedFireball.accelerationY!=-0.02||
            decodedFireball.accelerationZ!=0.03)failure="Priority 12 fireball flight persistence failed";
        if(tag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);}
    if(!failure){CloneMCJ_Vehicle_Initialize(&cart,CLONEMC_J_VEHICLE_MINECART,
            (CloneMCJ_World *)0,0,0,0,0);CloneMCJ_Vehicle_Initialize(&otherCart,
            CLONEMC_J_VEHICLE_MINECART,(CloneMCJ_World *)0,1,0,0,2);
        cart.entity.motionX=0.2;otherCart.entity.motionX=-0.1;
        CloneMCJ_Vehicle_ApplyCollision(&cart,&otherCart);
        if(cart.entity.motionX==0.2&&otherCart.entity.motionX==-0.1)
            failure="Priority 12 minecart collision/engine priority failed";}
    world=(CloneMCJ_World *)malloc(sizeof(*world));gameplay=(CloneMCJ_GameplayState *)malloc(sizeof(*gameplay));
    if((!world||!gameplay)&&!failure)failure="Priority 12 bounded runtime allocation failed";
    if(world&&gameplay){memset(world,0,sizeof(*world));memset(gameplay,0,sizeof(*gameplay));
        CloneMCJavaRandom_SetSeed(&world->rand,12);CloneMCJ_WorldProvider_InitializeSurface(&world->worldProvider);
        CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&world->chunkProvider,1);
        chunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider,0,0);
        gameplay->world=world;CloneMCJ_EntityPlayer_Initialize(&gameplay->player,world,"Target");
        CloneMCJ_Entity_SetPosition(&gameplay->player.entity,1.0,2.0,0.5);
        CloneMCJ_Entity_Initialize(&owner,world);CloneMCJ_Entity_SetPosition(&owner,0.0,2.9,0.5);
        CloneMCJ_Projectile_Initialize(&arrow,CLONEMC_J_PROJECTILE_ARROW,world,&owner,1,0);
        CloneMCJ_Entity_SetPosition(&arrow.entity,0.0,2.9,0.5);arrow.entity.motionX=2.0;
        arrow.entity.motionY=arrow.entity.motionZ=0.0;CloneMCJ_Projectile_Tick(&arrow,gameplay);
        if(!failure&&(arrow.active||gameplay->player.health!=16))
            failure="Priority 12 swept arrow/player collision failed";
        if(chunk){int groundX,groundZ;
            for(groundX=0;groundX<8;++groundX)for(groundZ=0;groundZ<5;++groundZ)
                CloneMCJ_Chunk_SetBlockID(chunk,groundX,0,groundZ,1,
                    (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockID(chunk,3,1,2,1,(CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockID(chunk,3,2,2,1,(CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Entity_SetPosition(&owner,1.5,1.0,2.5);
            memset(&nativePath,0,sizeof(nativePath));
            if(!failure&&!CloneMCJ_Pathfinder_CreatePath(world,&owner,5.5,1.0,2.5,
                    16.0F,&nativePath))failure="Priority 12 Java Pathfinder route failed";
            pathAvoidsObstacle=1;
            for(pathIndex=0;pathIndex<nativePath.pathLength;++pathIndex)
                if(nativePath.points[pathIndex].xCoord==3&&
                    nativePath.points[pathIndex].zCoord==2&&
                    nativePath.points[pathIndex].yCoord<3)pathAvoidsObstacle=0;
            if(!failure&&!pathAvoidsObstacle)
                failure="Priority 12 Pathfinder solid-obstacle avoidance failed";
        }
        CloneMCJ_Vehicle_Initialize(&gameplay->vehicles[0],CLONEMC_J_VEHICLE_MINECART,
            world,2.0,1.0,2.0,1);gameplay->vehicleCount=1;
        gameplay->openVehicleInventoryId=gameplay->vehicles[0].entity.entityId;
        if(!failure&&CloneMCJ_Gameplay_GetOpenVehicleInventory(gameplay)!=&gameplay->vehicles[0])
            failure="Priority 12 chest minecart container identity failed";
        gameplay->vehicles[0].active=0;
        if(!failure&&CloneMCJ_Gameplay_GetOpenVehicleInventory(gameplay)!=(CloneMCJ_Vehicle *)0)
            failure="Priority 12 stale vehicle container guard failed";
        if(chunk){CloneMCJ_Chunk_SetBlockID(chunk,4,2,5,1,(CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Vehicle_Initialize(&painting,CLONEMC_J_VEHICLE_PAINTING,world,4.5,2.5,4.5,0);
            if(!failure&&!CloneMCJ_Vehicle_ConfigurePainting(&painting,0,4,2,5))
                failure="Priority 12 Java painting surface/art selection failed";
            CloneMCJ_Chunk_SetBlockID(chunk,4,2,5,0,(CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Vehicle_Initialize(&painting,CLONEMC_J_VEHICLE_PAINTING,world,4.5,2.5,4.5,0);
            if(!failure&&CloneMCJ_Vehicle_ConfigurePainting(&painting,0,4,2,5))
                failure="Priority 12 invalid painting rejection failed";}
        CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&world->chunkProvider);}
    if(gameplay)free(gameplay);
    if(world)free(world);
    if(failure){CloneMCJ_Priority7_SetMessage(message,messageCapacity,failure);return 0;}
    CloneMCJ_Priority7_SetMessage(message,messageCapacity,
        "Priority 12 entities, combat, swept projectiles, vehicles and persistence tests passed");
    return 1;
}


int CloneMCJ_Priority14_RunSelfTests(char *message,unsigned int messageCapacity)
{
    CloneMCJ_World *world;
    CloneMCJ_Chunk *chunk;
    CloneMCJ_EntityPlayer player;
    CloneMCJ_Mob zombie,skeleton,creeper,wolf,slime,magma,decoded;
    CloneMCJ_NBTTagCompound *tag;
    const char *failure;
    int x,z,initialFuse;
    double distanceSquared;
    failure=(const char *)0;world=(CloneMCJ_World *)0;tag=(CloneMCJ_NBTTagCompound *)0;
    CloneMCJ_BlockRegistry_Initialize();CloneMCJ_ItemRegistry_Initialize();

    CloneMCJ_EntityLiving_InitializeMob(&slime,CLONEMC_J_MOB_SLIME,
        (CloneMCJ_World *)0,0.0,0.0,0.0);
    CloneMCJ_EntitySlime_SetSizeNative(&slime,4);
    if(slime.slimeSize!=4||slime.health!=16||slime.maxHealth!=16||
        slime.attackStrength!=4||slime.entity.width<2.39F)
        failure="Priority 14 slime size-derived state failed";
    CloneMCJ_EntityLiving_InitializeMob(&magma,CLONEMC_J_MOB_MAGMA_CUBE,
        (CloneMCJ_World *)0,0.0,0.0,0.0);
    CloneMCJ_EntitySlime_SetSizeNative(&magma,4);
    if(!failure&&(magma.slimeSize!=4||magma.health!=16||
       magma.maxHealth!=16||magma.attackStrength!=6||
       magma.entity.width<2.39F))
        failure="Priority 14 magma-cube size/damage state failed";

    if(!failure){
        CloneMCJ_EntityLiving_InitializeMob(&creeper,CLONEMC_J_MOB_CREEPER,
            (CloneMCJ_World *)0,1.0,2.0,3.0);
        creeper.angry=1;creeper.timeSinceIgnited=12;creeper.lastActiveTime=11;
        creeper.creeperState=1;creeper.entityAge=777;creeper.targetMemoryTicks=42;
        tag=CloneMCJ_NBTTagCompound_Create();
        if(!tag||!CloneMCJ_Mob_WriteNBT(&creeper,tag)||
            !CloneMCJ_Mob_ReadNBT(&decoded,tag,(CloneMCJ_World *)0)||
            !decoded.angry||decoded.timeSinceIgnited!=12||decoded.creeperState!=1||
            decoded.entityAge!=777||decoded.targetMemoryTicks!=42)
            failure="Priority 14 creeper AI-state persistence failed";
        if(tag){CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);tag=(CloneMCJ_NBTTagCompound *)0;}
    }
    if(!failure){
        CloneMCJ_EntityLiving_InitializeMob(&wolf,CLONEMC_J_MOB_WOLF,
            (CloneMCJ_World *)0,1.0,2.0,3.0);
        wolf.tamed=1;wolf.sitting=1;wolf.health=18;wolf.maxHealth=20;
        strcpy(wolf.owner,"Priority14Owner");wolf.persistenceRequired=1;
        tag=CloneMCJ_NBTTagCompound_Create();
        if(!tag||!CloneMCJ_Mob_WriteNBT(&wolf,tag)||
            !CloneMCJ_Mob_ReadNBT(&decoded,tag,(CloneMCJ_World *)0)||
            !decoded.tamed||decoded.maxHealth!=20||decoded.health!=18||
            !decoded.persistenceRequired||strcmp(decoded.owner,"Priority14Owner"))
            failure="Priority 14 tamed wolf persistence/max-health failed";
        if(tag){CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);tag=(CloneMCJ_NBTTagCompound *)0;}
    }

    world=(CloneMCJ_World *)malloc(sizeof(*world));
    if(!world&&!failure)failure="Priority 14 bounded world allocation failed";
    if(world){
        memset(world,0,sizeof(*world));CloneMCJavaRandom_SetSeed(&world->rand,14014);
        CloneMCJ_WorldProvider_InitializeSurface(&world->worldProvider);
        CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&world->chunkProvider,14014);
        chunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider,0,0);
        if(!chunk&&!failure)failure="Priority 14 test chunk preparation failed";
        if(chunk){
            for(x=0;x<16;++x)for(z=0;z<16;++z)
                CloneMCJ_Chunk_SetBlockID(chunk,x,0,z,1,
                    (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_EntityPlayer_Initialize(&player,world,"Target");
            CloneMCJ_Entity_SetPosition(&player.entity,5.5,1.0,2.5);
            CloneMCJ_EntityLiving_InitializeMob(&zombie,CLONEMC_J_MOB_ZOMBIE,
                world,1.5,1.0,2.5);
            if(!failure&&!CloneMCJ_EntityLiving_CanSeeEntity(&zombie.entity,&player.entity))
                failure="Priority 14 unobstructed perception failed";
            CloneMCJ_Chunk_SetBlockID(chunk,3,1,2,1,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockID(chunk,3,2,2,1,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            if(!failure&&CloneMCJ_EntityLiving_CanSeeEntity(&zombie.entity,&player.entity))
                failure="Priority 14 occluded line-of-sight failed";
            CloneMCJ_Chunk_SetBlockID(chunk,3,1,2,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockID(chunk,3,2,2,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);

            CloneMCJ_EntityLiving_InitializeMob(&skeleton,CLONEMC_J_MOB_SKELETON,
                world,1.5,1.0,2.5);
            CloneMCJ_EntityLiving_TickMob(&skeleton,&player);
            if(!failure&&(!skeleton.targetAcquired||!skeleton.rangedAttackPending||
                skeleton.attackTime!=30))
                failure="Priority 14 skeleton ranged cadence failed";

            CloneMCJ_Entity_SetPosition(&player.entity,3.5,1.0,2.5);
            CloneMCJ_EntityLiving_InitializeMob(&creeper,CLONEMC_J_MOB_CREEPER,
                world,1.5,1.0,2.5);
            CloneMCJ_EntityLiving_TickMob(&creeper,&player);initialFuse=creeper.timeSinceIgnited;
            CloneMCJ_Chunk_SetBlockID(chunk,2,1,2,1,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockID(chunk,2,2,2,1,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_EntityLiving_TickMob(&creeper,&player);
            if(!failure&&(initialFuse<=0||creeper.timeSinceIgnited>=initialFuse||
                creeper.creeperState!=-1))
                failure="Priority 14 creeper fuse cancellation failed";
            CloneMCJ_Chunk_SetBlockID(chunk,2,1,2,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);
            CloneMCJ_Chunk_SetBlockID(chunk,2,2,2,0,
                (CloneMCJ_BlockLightOpacityProc)0,(void *)0);

            CloneMCJ_Entity_SetPosition(&player.entity,12.5,1.0,12.5);
            CloneMCJ_EntityLiving_InitializeMob(&wolf,CLONEMC_J_MOB_WOLF,
                world,1.5,1.0,1.5);wolf.tamed=1;wolf.maxHealth=20;
            wolf.persistenceRequired=1;strcpy(wolf.owner,"Target");
            CloneMCJ_EntityLiving_TickMob(&wolf,&player);
            distanceSquared=(wolf.entity.posX-player.entity.posX)*
                (wolf.entity.posX-player.entity.posX)+
                (wolf.entity.posZ-player.entity.posZ)*
                (wolf.entity.posZ-player.entity.posZ);
            if(!failure&&distanceSquared>36.0&&!wolf.hasPath)
                failure="Priority 14 tamed wolf owner catch-up failed";

            CloneMCJ_Entity_SetPosition(&player.entity,8.5,1.0,8.5);
            CloneMCJ_EntityLiving_InitializeMob(&wolf,CLONEMC_J_MOB_WOLF,
                world,1.5,1.0,1.5);wolf.tamed=1;wolf.maxHealth=20;
            wolf.health=20;wolf.persistenceRequired=1;strcpy(wolf.owner,"Target");
            CloneMCJ_EntityLiving_InitializeMob(&zombie,CLONEMC_J_MOB_ZOMBIE,
                world,2.5,1.0,1.5);wolf.combatTarget=&zombie;
            CloneMCJ_EntityLiving_TickMob(&wolf,&player);
            if(!failure&&(zombie.health>=zombie.maxHealth||player.health<20))
                failure="Priority 14 tamed wolf combat-target attack failed";

            CloneMCJ_Entity_SetPosition(&player.entity,220.0,1.0,220.0);
            CloneMCJ_EntityLiving_InitializeMob(&zombie,CLONEMC_J_MOB_ZOMBIE,
                world,1.5,1.0,1.5);CloneMCJ_EntityLiving_TickMob(&zombie,&player);
            if(!failure&&zombie.active)
                failure="Priority 14 hard-distance despawn failed";
        }
        CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&world->chunkProvider);
        free(world);
    }
    if(failure){CloneMCJ_Priority7_SetMessage(message,messageCapacity,failure);return 0;}
    CloneMCJ_Priority7_SetMessage(message,messageCapacity,
        "Priority 14 perception, targeting, mob AI, ranged cadence, fuse, wolf combat, persistence and despawn tests passed");
    return 1;
}


int CloneMCJ_Priority16_RunSelfTests(char *message,unsigned int messageCapacity)
{
    CloneMCJ_World *world;CloneMCJ_GameplayState *gameplay;CloneMCJ_SaveHandler *saveHandler;
    const char *failure;char root[96];unsigned long nonce;
    int x,y,z,i,count,portalNear,dropBefore,catchResult;double netherX,returnX;
    CloneMCJ_Vehicle boat,minecart,loadedCart,painting;
    CloneMCJ_Projectile fish;
    CloneMCJ_NBTTagCompound *vehicleTag;
    failure=(const char *)0;world=(CloneMCJ_World *)malloc(sizeof(CloneMCJ_World));
    gameplay=(CloneMCJ_GameplayState *)malloc(sizeof(CloneMCJ_GameplayState));
    saveHandler=(CloneMCJ_SaveHandler *)malloc(sizeof(CloneMCJ_SaveHandler));
    nonce=(unsigned long)time(0)^((unsigned long)clock()<<1);
    sprintf(root,"v117_portal_selftest_%lu",nonce);
    (void)CloneMCJ_SaveFormatOld_DeleteWorld(root,"World");
    if(!world||!gameplay||!saveHandler)failure="Priority 16 allocation failed";
    if(!failure){
        memset(saveHandler,0,sizeof(*saveHandler));
        CloneMCJ_BlockRegistry_Initialize();CloneMCJ_ItemRegistry_Initialize();
        CloneMCJ_World_InitializeDeferred(world,(CloneMCJLong)24681357,2);
        if(!CloneMCJ_SaveHandler_Initialize(saveHandler,root,"World",1)||
           !CloneMCJ_World_AttachSaveHandler(world,saveHandler,"V117 Portal Test"))
            failure="Priority 16 save-backed world initialization failed";
    }
    if(!failure){
        CloneMCJ_World_SetPlayerGlobalPosition(world,80.5,0.5);
        CloneMCJ_Gameplay_Initialize(gameplay,world,"PortalTest");
        CloneMCJ_Entity_SetPosition(&gameplay->player.entity,80.5,70.0,0.5);
        CloneMCJ_World_SetPlayerGlobalPosition(world,80.5,0.5);
        for(x=79;x<=82;++x){CloneMCJ_World_SetBlockNotify(world,x,69,0,49);
            CloneMCJ_World_SetBlockNotify(world,x,73,0,49);}
        for(y=70;y<=72;++y){CloneMCJ_World_SetBlockNotify(world,79,y,0,49);
            CloneMCJ_World_SetBlockNotify(world,82,y,0,49);}
        CloneMCJ_World_SetBlockNotify(world,80,70,0,51);
        if(!CloneMCJ_BlockPortal_TryCreate(world,80,70,0))failure="Priority 16 portal frame creation failed";
        count=0;for(x=80;x<=81;++x)for(y=70;y<=72;++y)
            if(CloneMCJ_World_GetBlockId(world,x,y,0)==90)++count;
        if(!failure&&count!=6)failure="Priority 16 portal interior fill failed";
        gameplay->player.timeUntilPortal=0;
        for(i=0;i<90&&!failure&&world->worldInfo.dimension==0;++i)
            CloneMCJ_Gameplay_Tick(world,gameplay);
        if(!failure&&world->worldInfo.dimension!=-1)
            failure="Priority 16 Survival automatic portal transfer failed";
        netherX=gameplay->player.entity.posX;
        if(!failure&&(world->worldInfo.dimension!=-1||!world->worldProvider.isHellWorld||netherX<7.0||netherX>13.0))
            failure="Priority 16 Nether provider or 8:1 coordinate scale failed";
        portalNear=0;for(x=CloneMCJava_FloorDouble(gameplay->player.entity.posX)-2;
            x<=CloneMCJava_FloorDouble(gameplay->player.entity.posX)+2;++x)
            for(y=CloneMCJava_FloorDouble(gameplay->player.entity.posY)-2;
                y<=CloneMCJava_FloorDouble(gameplay->player.entity.posY)+3;++y)
                if(CloneMCJ_World_GetBlockId(world,x,y,CloneMCJava_FloorDouble(gameplay->player.entity.posZ))==90)portalNear=1;
        if(!failure&&!portalNear)failure="Priority 16 destination portal construction failed";
        gameplay->player.timeUntilPortal=0;gameplay->player.timeInPortal=1.0F;
        if(!failure&&!CloneMCJ_Gameplay_UsePortal(gameplay))failure="Priority 16 Nether-to-Overworld return failed";
        returnX=gameplay->player.entity.posX;
        /* The source portal was transactionally persisted before the provider
         * switch, so the return search should recover the original frame rather
         * than constructing an unrelated replacement. */
        if(!failure&&(world->worldInfo.dimension!=0||world->worldProvider.isHellWorld||returnX<79.0||returnX>82.0))
            failure="Priority 16 persisted return portal recovery failed";
        if(!failure&&(CloneMCJ_World_GetBlockId(world,80,70,0)!=90||
            CloneMCJ_World_GetBlockId(world,81,72,0)!=90))
            failure="Priority 16 Overworld portal edit did not survive dimension round trip";

        /* Creative uses the same BlockPortal collision and EntityPlayerSP
         * charge/transfer state machine as Survival.  Invulnerability must
         * suppress damage only, never portal collision. */
        if(!failure){
            gameplay->player.gameMode=CLONEMC_J_GAMEMODE_CREATIVE;
            gameplay->player.allowFlying=1;gameplay->player.flying=0;
            gameplay->player.invulnerable=1;
            gameplay->player.timeUntilPortal=0;
            gameplay->player.timeInPortal=0.0F;
            gameplay->player.prevTimeInPortal=0.0F;
            CloneMCJ_Entity_SetPosition(&gameplay->player.entity,80.5,70.0,0.5);
            for(i=0;i<90&&world->worldInfo.dimension==0;++i)
                CloneMCJ_Gameplay_Tick(world,gameplay);
            if(world->worldInfo.dimension!=-1)
                failure="Priority 16 Creative automatic portal transfer failed";
        }
        if(!failure){
            gameplay->player.timeUntilPortal=0;
            gameplay->player.timeInPortal=1.0F;
            if(!CloneMCJ_Gameplay_UsePortal(gameplay)||
               world->worldInfo.dimension!=0)
                failure="Priority 16 Creative Nether return failed";
        }
        gameplay->player.gameMode=CLONEMC_J_GAMEMODE_SURVIVAL;
        gameplay->player.allowFlying=0;gameplay->player.flying=0;
        gameplay->player.invulnerable=0;

        /* Beds use the actual two-block metadata, nighttime gate, occupied bit,
         * wake-up search, and persistent player spawn coordinates. */
        if(!failure){
            for(x=83;x<=85;++x)for(z=3;z<=5;++z){
                CloneMCJ_World_SetBlockNotify(world,x,68,z,1);
                for(y=69;y<=72;++y)CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
            }
            CloneMCJ_World_SetBlockWithMetadataNotify(world,84,69,4,26,0);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,84,69,5,26,8);
            world->worldTime=13000;
            CloneMCJ_Entity_SetPosition(&gameplay->player.entity,84.5,69.0,4.5);
            if(CloneMCJ_EntityPlayer_TrySleep(&gameplay->player,84,69,5)!=1||
               !gameplay->player.sleeping)failure="Priority 16 bed sleep entry failed";
            if(!failure){CloneMCJ_EntityPlayer_Wake(&gameplay->player,0,1);
                if(gameplay->player.sleeping||!gameplay->player.hasBedSpawn||
                   gameplay->player.spawnX!=84||gameplay->player.spawnZ!=5)
                    failure="Priority 16 bed wake or respawn persistence failed";}
        }

        /* Boat buoyancy, rail-constrained minecart motion, and storage-cart NBT
         * exercise the shared transportation runtime used by single-player and
         * the authoritative multiplayer entity registry. */
        if(!failure){
            for(x=87;x<=89;++x)for(z=3;z<=5;++z){
                CloneMCJ_World_SetBlockNotify(world,x,68,z,1);
                CloneMCJ_World_SetBlockNotify(world,x,69,z,9);
                CloneMCJ_World_SetBlockNotify(world,x,70,z,9);
                CloneMCJ_World_SetBlockNotify(world,x,71,z,0);
            }
            CloneMCJ_Vehicle_Initialize(&boat,CLONEMC_J_VEHICLE_BOAT,world,88.5,70.0,4.5,0);
            boat.entity.motionY=-0.02;CloneMCJ_Vehicle_Tick(&boat,gameplay);
            if(boat.entity.motionY<=-0.02)failure="Priority 16 boat buoyancy failed";
        }
        if(!failure){
            for(x=86;x<=90;++x){CloneMCJ_World_SetBlockNotify(world,x,68,8,1);
                CloneMCJ_World_SetBlockWithMetadataNotify(world,x,69,8,66,1);
                CloneMCJ_World_SetBlockNotify(world,x,70,8,0);}
            CloneMCJ_EntityMinecart_InitializeNative(&minecart,world,87.5,69.5,8.5,1);
            minecart.entity.motionX=0.2;minecart.entity.motionZ=0.0;
            CloneMCJ_ItemStack_Initialize(&minecart.cargo[0],264,3,0);
            CloneMCJ_Vehicle_Tick(&minecart,gameplay);
            if(minecart.entity.posX<=87.5||fabs(minecart.entity.posZ-8.5)>0.1)
                failure="Priority 16 rail-constrained minecart movement failed";
            vehicleTag=CloneMCJ_NBTTagCompound_Create();
            if(!failure&&(!vehicleTag||!CloneMCJ_Vehicle_WriteNBT(&minecart,vehicleTag)||
               !CloneMCJ_Vehicle_ReadNBT(&loadedCart,vehicleTag,world)||
               loadedCart.minecartType!=1||loadedCart.cargo[0].itemID!=264||
               loadedCart.cargo[0].stackSize!=3))
                failure="Priority 16 storage minecart NBT failed";
            CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)vehicleTag);
        }

        /* Painting art selection uses exact EnumArt dimensions and requires a
         * solid backing surface for every sixteen-pixel segment. */
        if(!failure){
            for(x=80;x<=88;++x)for(y=68;y<=76;++y){
                CloneMCJ_World_SetBlockNotify(world,x,y,9,1);
                CloneMCJ_World_SetBlockNotify(world,x,y,8,0);
            }
            CloneMCJ_EntityPainting_InitializeNative(&painting,world,84,72,9,0,(const char *)0);
            if(!CloneMCJ_Vehicle_ConfigurePainting(&painting,0,84,72,9)||
               !CloneMCJ_EnumArt_Find(painting.art))
                failure="Priority 16 painting art/support selection failed";
        }

        /* A catchable fishing hook creates the fish entity item at the bobber
         * and applies Java's pull impulse toward the angler. */
        if(!failure){
            CloneMCJ_Entity_SetPosition(&gameplay->player.entity,84.5,70.0,4.5);
            CloneMCJ_EntityFish_InitializeNative(&fish,world,&gameplay->player.entity);
            CloneMCJ_Entity_SetPosition(&fish.entity,82.5,70.0,4.5);fish.ticksCatchable=5;
            dropBefore=gameplay->droppedItemCount;catchResult=CloneMCJ_EntityFish_Catch(&fish,gameplay);
            if(catchResult!=1||gameplay->droppedItemCount<=dropBefore||
               gameplay->droppedItems[gameplay->droppedItemCount-1].item.itemID!=349||
               gameplay->droppedItems[gameplay->droppedItemCount-1].entity.motionX<=0.0)
                failure="Priority 16 fishing catch/retraction failed";
        }
    }
    if(gameplay&&world&&world->gameplayUserData==gameplay)CloneMCJ_Gameplay_Destroy(gameplay);
    if(world)CloneMCJ_World_Destroy(world);
    if(saveHandler)CloneMCJ_SaveHandler_Destroy(saveHandler);
    (void)CloneMCJ_SaveFormatOld_DeleteWorld(root,"World");
    (void)CLONEMC_P16_RMDIR(root);
    if(gameplay)free(gameplay);if(world)free(world);if(saveHandler)free(saveHandler);
    if(failure){CloneMCJ_Priority7_SetMessage(message,messageCapacity,failure);return 0;}
    CloneMCJ_Priority7_SetMessage(message,messageCapacity,
        "Priority 16 portals, beds, boats, minecarts, paintings and fishing tests passed");
    return 1;
}

void CloneMCJ_PlayerControllerTest_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_PlayerControllerTest_JavaName(void)
{
    return "net.minecraft.src.PlayerControllerTest";
}

const char *CloneMCJ_PlayerControllerTest_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_PlayerControllerTest_JavaSourceHash32(void)
{
    return 0x91E7B01EUL;
}
