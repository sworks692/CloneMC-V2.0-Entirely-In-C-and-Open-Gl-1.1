/*
 * CloneMC Java port scaffold: PlayerControllerSP
 *
 * Java source: PlayerControllerSP.java
 * Java type: class PlayerControllerSP
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: PlayerController
 * Implements: (none declared)
 * Source SHA-256: c3bb81d150af34045cb0f650913e0380f1088255c7fe82d836758612be1c289e
 * Java lines: 155
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: PlayerController, EntityPlayer, World, EntityPlayerSP, Block, ItemStack, StepSound, SoundManager, GuiIngame, RenderGlobal, j, k, i, mc.thePlayer, sendBloc
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_1074_c
 * - private int field_1073_d
 * - private int field_1072_e
 * - private float curBlockDamage
 * - private float prevBlockDamage
 * - private float field_1069_h
 * - private int blockHitWait
 *
 * Java method/constructor inventory:
 * - public PlayerControllerSP(Minecraft minecraft)
 * - public void flipPlayer(EntityPlayer entityplayer)
 * - public boolean sendBlockRemoved(int i, int j, int k, int l)
 * - public void clickBlock(int i, int j, int k, int l)
 * - public void resetBlockRemoving()
 * - public void sendBlockRemoving(int i, int j, int k, int l)
 * - public void setPartialTime(float f)
 * - public float getBlockReachDistance()
 * - public void func_717_a(World world)
 * - public void updateController()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <string.h>
#include <math.h>

void CloneMCJ_PlayerControllerSP_Initialize(CloneMCJ_PlayerControllerSP *controller, CloneMCJ_World *world, CloneMCJ_EntityPlayer *player)
{
    if (!controller) return;
    memset(controller, 0, sizeof(*controller));
    controller->world = world;
    controller->player = player;
    controller->currentBlockX = controller->currentBlockY = controller->currentBlockZ = -999999;
}

int CloneMCJ_PlayerControllerSP_ClickBlock(CloneMCJ_PlayerControllerSP *controller, int x, int y, int z)
{
    int blockID;
    const CloneMCJ_BlockDefinition *block;
    if (!controller || !controller->world || !controller->player) return 0;
    if(controller->player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR)return 0;
    blockID = CloneMCJ_World_GetBlockId(controller->world, x, y, z);
    if(blockID==25)CloneMCJ_BlockNote_ClickNative(controller->world,x,y,z);
    if(controller->player->gameMode==CLONEMC_J_GAMEMODE_CREATIVE)
        return CloneMCJ_PlayerControllerSP_HarvestBlock(controller,x,y,z);
    if(blockID==92){
        if(CloneMCJ_BlockCake_ActivateNative(controller->world,x,y,z,
                controller->player)){
            controller->player->lastActivatedBlockID=92;
            controller->player->lastActivatedMetadata=
                CloneMCJ_World_GetBlockMetadata(controller->world,x,y,z);
            controller->player->lastActivatedX=x;
            controller->player->lastActivatedY=y;
            controller->player->lastActivatedZ=z;
            ++controller->player->blocksActivated;
            return 1;
        }
    }
    block = CloneMCJ_BlockRegistry_Get(blockID);
    if (!block || blockID == 0 || block->hardness < 0.0F) return 0;
    controller->currentBlockX = x;
    controller->currentBlockY = y;
    controller->currentBlockZ = z;
    controller->currentBlockDamage = 0.0F;
    controller->previousBlockDamage = 0.0F;
    controller->hittingBlock = 1;
    if (block->hardness == 0.0F) return CloneMCJ_PlayerControllerSP_HarvestBlock(controller, x, y, z);
    return 1;
}

int CloneMCJ_PlayerControllerSP_DamageBlock(CloneMCJ_PlayerControllerSP *controller, int x, int y, int z)
{
    int blockID,metadata;
    const CloneMCJ_BlockDefinition *block;
    float strength;
    if (!controller||!controller->player) return 0;
    if(controller->player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR)return 0;
    if(controller->player->gameMode==CLONEMC_J_GAMEMODE_CREATIVE)
        return CloneMCJ_PlayerControllerSP_HarvestBlock(controller,x,y,z);
    if (controller->blockHitDelay > 0) { --controller->blockHitDelay; return 0; }
    if (!controller->hittingBlock || x != controller->currentBlockX || y != controller->currentBlockY || z != controller->currentBlockZ) {
        return CloneMCJ_PlayerControllerSP_ClickBlock(controller, x, y, z);
    }
    blockID = CloneMCJ_World_GetBlockId(controller->world, x, y, z);
    metadata = CloneMCJ_World_GetBlockMetadata(controller->world, x, y, z);
    block = CloneMCJ_BlockRegistry_Get(blockID);
    if (!block || blockID == 0 || block->hardness < 0.0F) { controller->hittingBlock = 0; return 0; }
    controller->previousBlockDamage = controller->currentBlockDamage;
    strength = CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
        &controller->player->inventory,blockID,metadata);
    if (CloneMCJ_InventoryPlayer_CanHarvestMetadata(
        &controller->player->inventory,blockID,metadata))
        controller->currentBlockDamage += strength / block->hardness / 30.0F;
    else controller->currentBlockDamage += 1.0F / block->hardness / 100.0F;
    if (controller->currentBlockDamage >= 1.0F) {
        int harvested;
        controller->hittingBlock = 0;
        controller->blockHitDelay = 5;
        harvested = CloneMCJ_PlayerControllerSP_HarvestBlock(controller, x, y, z);
        controller->currentBlockDamage = 0.0F;
        controller->previousBlockDamage = 0.0F;
        controller->currentBlockX = -999999;
        controller->currentBlockY = -999999;
        controller->currentBlockZ = -999999;
        return harvested;
    }
    return 1;
}

static int CloneMCJ_PlayerControllerSP_CountTileStacks(
    const CloneMCJ_TileEntity *tile)
{
    int i;
    int count;
    int limit;
    if (!tile) return 0;
    limit = tile->itemCount;
    if (limit < 0) limit = 0;
    if (limit > CLONEMC_J_CHEST_INVENTORY_SIZE)
        limit = CLONEMC_J_CHEST_INVENTORY_SIZE;
    count = 0;
    for (i = 0; i < limit; ++i)
        if (!CloneMCJ_ItemStack_IsEmpty(&tile->items[i])) ++count;
    return count;
}

static int CloneMCJ_PlayerControllerSP_CountFreeDrops(
    const CloneMCJ_GameplayState *gameplay)
{
    return CloneMCJ_Gameplay_GetDropQueueCapacity(gameplay);
}

static void CloneMCJ_PlayerControllerSP_DropTileContents(
    CloneMCJ_GameplayState *gameplay, CloneMCJ_TileEntity *tile,
    int x, int y, int z)
{
    CloneMCJ_ItemStack stack;
    int i;
    int limit;
    if (!gameplay || !tile) return;
    limit = tile->itemCount;
    if (limit < 0) limit = 0;
    if (limit > CLONEMC_J_CHEST_INVENTORY_SIZE)
        limit = CLONEMC_J_CHEST_INVENTORY_SIZE;
    for (i = 0; i < limit; ++i) {
        if (CloneMCJ_ItemStack_IsEmpty(&tile->items[i])) continue;
        stack = tile->items[i];
        if (CloneMCJ_Gameplay_SpawnDrop(gameplay, x + 0.5,
            y + 0.5, z + 0.5, &stack, 10, 0) ||
            CloneMCJ_InventoryPlayer_AddItemStack(
                &gameplay->player.inventory, &stack))
            CloneMCJ_ItemStack_Clear(&tile->items[i]);
    }
}

int CloneMCJ_PlayerControllerSP_HarvestBlock(CloneMCJ_PlayerControllerSP *controller, int x, int y, int z)
{
    CloneMCJ_GameplayState *gameplay;
    CloneMCJ_ItemStack drop;
    CloneMCJ_ItemStack *tool;
    CloneMCJ_Chunk *chunk;
    CloneMCJ_TileEntity *tile;
    int blockID, metadata, canHarvest;
    int tileStacks;
    int dropSlotsNeeded;
    int shearingLeaves;
    if (!controller || !controller->world || !controller->player) return 0;
    blockID = CloneMCJ_World_GetBlockId(controller->world, x, y, z);
    metadata = CloneMCJ_World_GetBlockMetadata(controller->world, x, y, z);
    if (blockID <= 0) return 0;
    gameplay = (CloneMCJ_GameplayState *)controller->world->gameplayUserData;
    canHarvest = controller->player->gameMode==CLONEMC_J_GAMEMODE_CREATIVE?0:
        CloneMCJ_InventoryPlayer_CanHarvestMetadata(
            &controller->player->inventory,blockID,metadata);
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(controller->world, x, z);
    tile = chunk ? (CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(
        chunk, x & 15, y, z & 15) : (CloneMCJ_TileEntity *)0;
    if (gameplay && gameplay->openContainerActive &&
        gameplay->openContainerIsBlock && gameplay->openContainerX == x &&
        gameplay->openContainerY == y && gameplay->openContainerZ == z)
        CloneMCJ_Gameplay_CloseOpenContainer(gameplay);
    tileStacks = CloneMCJ_PlayerControllerSP_CountTileStacks(tile);
    shearingLeaves=0;
    if(canHarvest&&gameplay){
        tool=CloneMCJ_InventoryPlayer_GetCurrent(&controller->player->inventory);
        shearingLeaves=blockID==18&&tool&&
            !CloneMCJ_ItemStack_IsEmpty(tool)&&tool->itemID==359;
    }
    /* Reserve all entities before changing the block.  The former code only
     * counted chest contents and could turn the block to air before the fixed
     * 256-entry pool rejected its normal, extra, or crop drops. */
    dropSlotsNeeded=tileStacks;
    if(canHarvest&&gameplay){
        if(shearingLeaves)++dropSlotsNeeded;
        else{
            dropSlotsNeeded+=2; /* normal plus additional/rare stack */
            if(blockID==59)dropSlotsNeeded+=3; /* independent seed rolls */
        }
    }
    if(dropSlotsNeeded>0&&(!gameplay||
       CloneMCJ_PlayerControllerSP_CountFreeDrops(gameplay)<dropSlotsNeeded))
        return 0;
    if (!CloneMCJ_World_SetBlockNotify(controller->world, x, y, z, 0)) return 0;
    CloneMCJ_World_MarkMeshSectionUrgent(controller->world,x,y,z);
    if (tile) {
        CloneMCJ_PlayerControllerSP_DropTileContents(gameplay, tile, x, y, z);
        CloneMCJ_Chunk_RemoveTileEntity(chunk, x & 15, y, z & 15);
        CloneMCJ_TileEntity_Destroy(tile);
    }
    if(canHarvest&&gameplay){
        tool=CloneMCJ_InventoryPlayer_GetCurrent(&controller->player->inventory);
        if(shearingLeaves){
            CloneMCJ_ItemStack_Initialize(&drop,18,1,metadata&3);
            CloneMCJ_Gameplay_SpawnDrop(gameplay,x+0.5,y+0.5,z+0.5,
                &drop,10,0);
        }else{
            if(CloneMCJ_Block_GetDroppedStack(blockID,metadata,
                &controller->player->entity.rand,&drop))
                CloneMCJ_Gameplay_SpawnDrop(gameplay,x+0.5,y+0.5,
                    z+0.5,&drop,10,0);
            if(CloneMCJ_Block_GetAdditionalDroppedStack(blockID,metadata,
                &controller->player->entity.rand,&drop))
                CloneMCJ_Gameplay_SpawnDrop(gameplay,x+0.5,y+0.5,
                    z+0.5,&drop,10,0);
        }
    }
    /* BlockCrops.dropBlockAsItemWithChance performs three independent seed
     * rolls in addition to the mature wheat result.  Immature crops therefore
     * never create wheat, but can still return seeds according to growth. */
    if(canHarvest&&gameplay&&blockID==59){
        int seedRoll;
        for(seedRoll=0;seedRoll<3;++seedRoll){
            if(CloneMCJavaRandom_NextIntBound(&controller->player->entity.rand,15)<=metadata){
                CloneMCJ_ItemStack_Initialize(&drop,295,1,0);
                CloneMCJ_Gameplay_SpawnDrop(gameplay,x+0.5,y+0.5,z+0.5,&drop,10,0);
            }
        }
    }
    tool = CloneMCJ_InventoryPlayer_GetCurrent(&controller->player->inventory);
    if (tool&&controller->player->gameMode!=CLONEMC_J_GAMEMODE_CREATIVE){
        int unbreaking;
        unbreaking=CloneMCJ_Progression_EnchantLevel(tool,
            CLONEMC_J_ENCHANT_UNBREAKING);
        if(unbreaking<=0||CloneMCJavaRandom_NextIntBound(
            &controller->player->entity.rand,unbreaking+1)==0)
            CloneMCJ_ItemStack_Damage(tool,1);
    }
    controller->player->lastMinedBlockID=blockID;
    controller->player->lastMinedMetadata=metadata;
    controller->player->lastMinedX=x;controller->player->lastMinedY=y;
    controller->player->lastMinedZ=z;
    if(gameplay)CloneMCJ_Gameplay_QueueBlockBreakEvent(gameplay,blockID,metadata,x,y,z);
    controller->player->inventory.inventoryChanged=1;
    ++controller->player->blocksMined;
    return 1;
}


static int CloneMCJ_PlayerControllerSP_YawQuadrant(float yaw)
{
    int value;
    value = (int)floor((double)(yaw * 4.0F / 360.0F) + 0.5);
    return value & 3;
}

static int CloneMCJ_PlayerControllerSP_HorizontalFacing(float yaw)
{
    static const unsigned char facing[4] = { 2, 5, 3, 4 };
    return facing[CloneMCJ_PlayerControllerSP_YawQuadrant(yaw)];
}

static int CloneMCJ_PlayerControllerSP_PlacementMetadata(
    int blockID, int side, const CloneMCJ_EntityPlayer *player,
    const CloneMCJ_ItemStack *stack, int x, int y, int z)
{
    int quadrant;
    int metadata;
    double eyeY;
    metadata = stack ? (stack->itemDamage & 15) : 0;
    quadrant = player ? CloneMCJ_PlayerControllerSP_YawQuadrant(
        player->entity.rotationYaw) : 0;
    switch (blockID) {
    case 17: /* Logs preserve wood species; newly placed logs are vertical. */
    case 18:
    case 35:
    case 43:
    case 44:
        return metadata;
    case 23: /* dispenser */
    case 54: /* chest: retained metadata gives deterministic native facing */
    case 61: case 62: /* furnace */
        return player ? CloneMCJ_PlayerControllerSP_HorizontalFacing(
            player->entity.rotationYaw) : 3;
    case 33: case 29: /* piston / sticky piston */
        if (player) {
            eyeY = player->entity.posY + 1.62;
            if (fabs(player->entity.posX - (double)x) < 2.0 &&
                fabs(player->entity.posZ - (double)z) < 2.0) {
                if (eyeY - (double)y > 2.0) return 1;
                if ((double)y - eyeY > 0.0) return 0;
            }
            return CloneMCJ_PlayerControllerSP_HorizontalFacing(
                player->entity.rotationYaw);
        }
        return 2;
    case 53: case 67: /* wooden and cobblestone stairs */
        { static const unsigned char stair[4] = { 2, 1, 3, 0 };
          return stair[quadrant]; }
    case 86: case 91: /* pumpkin and jack-o-lantern */
        if (player)
            return ((int)floor((double)(player->entity.rotationYaw *
                4.0F / 360.0F) + 2.5)) & 3;
        return 0;
    case 27: case 28: case 66: /* rails begin aligned with the placer */
        return (quadrant & 1) ? 1 : 0;
    case 69: /* BlockLever.onBlockPlaced selects the final metadata. */
        return 0;
    case 93: case 94: /* repeater */
        return (quadrant + 2) & 3;
    case 50: case 75: case 76: /* torch families */
        if (side == 1) return 5;
        if (side == 2) return 4;
        if (side == 3) return 3;
        if (side == 4) return 2;
        if (side == 5) return 1;
        return 0;
    case 65: case 68: /* ladder and wall sign */
        return (side >= 2 && side <= 5) ? side : 2;
    case 63: /* standing sign */
        if (player)
            return ((int)floor((double)(player->entity.rotationYaw *
                16.0F / 360.0F) + 0.5)) & 15;
        return 0;
    case 77: /* stone button */
        if (side == 2) return 4;
        if (side == 3) return 3;
        if (side == 4) return 2;
        if (side == 5) return 1;
        return 0;
    case 96: /* trapdoor: four horizontal support faces */
        if (side == 2) return 0;
        if (side == 3) return 2;
        if (side == 4) return 3;
        if (side == 5) return 1;
        return 0;
    default:
        break;
    }
    return metadata;
}

static int CloneMCJ_PlayerControllerSP_CountAdjacentChests(
    CloneMCJ_World *world, int x, int y, int z)
{
    int count;
    if (!world) return 0;
    count = 0;
    if (CloneMCJ_World_GetBlockId(world, x - 1, y, z) == 54) ++count;
    if (CloneMCJ_World_GetBlockId(world, x + 1, y, z) == 54) ++count;
    if (CloneMCJ_World_GetBlockId(world, x, y, z - 1) == 54) ++count;
    if (CloneMCJ_World_GetBlockId(world, x, y, z + 1) == 54) ++count;
    return count;
}

static int CloneMCJ_PlayerControllerSP_CanPlaceChest(
    CloneMCJ_World *world, int x, int y, int z)
{
    if (CloneMCJ_PlayerControllerSP_CountAdjacentChests(world, x, y, z) > 1)
        return 0;
    if (CloneMCJ_World_GetBlockId(world, x - 1, y, z) == 54 &&
        CloneMCJ_PlayerControllerSP_CountAdjacentChests(world, x - 1, y, z) > 0)
        return 0;
    if (CloneMCJ_World_GetBlockId(world, x + 1, y, z) == 54 &&
        CloneMCJ_PlayerControllerSP_CountAdjacentChests(world, x + 1, y, z) > 0)
        return 0;
    if (CloneMCJ_World_GetBlockId(world, x, y, z - 1) == 54 &&
        CloneMCJ_PlayerControllerSP_CountAdjacentChests(world, x, y, z - 1) > 0)
        return 0;
    if (CloneMCJ_World_GetBlockId(world, x, y, z + 1) == 54 &&
        CloneMCJ_PlayerControllerSP_CountAdjacentChests(world, x, y, z + 1) > 0)
        return 0;
    return 1;
}

static int CloneMCJ_PlayerControllerSP_IsNormalCube(CloneMCJ_World *world,
    int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *definition;
    int id;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    definition=CloneMCJ_BlockRegistry_Get(id);
    return definition&&definition->opaque&&definition->collidable;
}

static int CloneMCJ_PlayerControllerSP_ConsumePlacedItem(
    CloneMCJ_PlayerControllerSP *controller,CloneMCJ_ItemStack *stack)
{
    if(!controller||!stack||CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    if(controller->player&&controller->player->gameMode==CLONEMC_J_GAMEMODE_CREATIVE){
        ++controller->player->blocksPlaced;return 1;}
    --stack->stackSize;
    if(stack->stackSize<=0)CloneMCJ_ItemStack_Clear(stack);
    controller->player->inventory.inventoryChanged=1;
    ++controller->player->blocksPlaced;
    return 1;
}

static int CloneMCJ_PlayerControllerSP_PlaceDoorItem(
    CloneMCJ_PlayerControllerSP *controller,CloneMCJ_ItemStack *stack,
    int x,int y,int z,int side,int blockId)
{
    int direction,offsetX,offsetZ,leftSolid,rightSolid,leftDoor,rightDoor,hinge;
    if(!controller||!stack||side!=1||y>=CLONEMC_J_CHUNK_HEIGHT-1)return 0;
    ++y;
    if(!CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,x,y-1,z)||
       CloneMCJ_World_GetBlockId(controller->world,x,y,z)!=0||
       CloneMCJ_World_GetBlockId(controller->world,x,y+1,z)!=0)return 0;
    direction=((int)floor((double)(((controller->player->entity.rotationYaw+180.0F)*
        4.0F)/360.0F)-0.5))&3;
    offsetX=offsetZ=0;
    if(direction==0)offsetZ=1;else if(direction==1)offsetX=-1;
    else if(direction==2)offsetZ=-1;else offsetX=1;
    leftSolid=(CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,
        x-offsetX,y,z-offsetZ)?1:0)+
        (CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,
        x-offsetX,y+1,z-offsetZ)?1:0);
    rightSolid=(CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,
        x+offsetX,y,z+offsetZ)?1:0)+
        (CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,
        x+offsetX,y+1,z+offsetZ)?1:0);
    leftDoor=CloneMCJ_World_GetBlockId(controller->world,x-offsetX,y,z-offsetZ)==blockId||
        CloneMCJ_World_GetBlockId(controller->world,x-offsetX,y+1,z-offsetZ)==blockId;
    rightDoor=CloneMCJ_World_GetBlockId(controller->world,x+offsetX,y,z+offsetZ)==blockId||
        CloneMCJ_World_GetBlockId(controller->world,x+offsetX,y+1,z+offsetZ)==blockId;
    hinge=(leftDoor&&!rightDoor)||rightSolid>leftSolid;
    if(hinge){direction=(direction-1)&3;direction|=4;}
    if(!CloneMCJ_World_SetBlockWithMetadataNotify(controller->world,
        x,y,z,blockId,direction))return 0;
    if(!CloneMCJ_World_SetBlockWithMetadataNotify(controller->world,
        x,y+1,z,blockId,direction+8)){
        CloneMCJ_World_SetBlockNotify(controller->world,x,y,z,0);return 0;
    }
    CloneMCJ_World_NotifyBlocksOfNeighborChange(controller->world,x,y,z,blockId);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(controller->world,x,y+1,z,blockId);
    CloneMCJ_World_MarkMeshSectionUrgent(controller->world,x,y,z);
    CloneMCJ_World_MarkMeshSectionUrgent(controller->world,x,y+1,z);
    controller->player->lastPlacedBlockID=blockId;
    controller->player->lastPlacedMetadata=direction;
    controller->player->lastPlacedX=x;controller->player->lastPlacedY=y;
    controller->player->lastPlacedZ=z;
    return CloneMCJ_PlayerControllerSP_ConsumePlacedItem(controller,stack);
}

static int CloneMCJ_PlayerControllerSP_PlaceBedItem(
    CloneMCJ_PlayerControllerSP *controller,CloneMCJ_ItemStack *stack,
    int x,int y,int z,int side)
{
    static const signed char offsetX[4]={0,-1,0,1};
    static const signed char offsetZ[4]={1,0,-1,0};
    int direction,headX,headZ;
    if(!controller||!stack||side!=1||y>=CLONEMC_J_CHUNK_HEIGHT-1)return 0;
    ++y;direction=CloneMCJ_PlayerControllerSP_YawQuadrant(
        controller->player->entity.rotationYaw);
    headX=x+(int)offsetX[direction];headZ=z+(int)offsetZ[direction];
    if(CloneMCJ_World_GetBlockId(controller->world,x,y,z)!=0||
       CloneMCJ_World_GetBlockId(controller->world,headX,y,headZ)!=0||
       !CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,x,y-1,z)||
       !CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,headX,y-1,headZ))return 0;
    if(!CloneMCJ_World_SetBlockWithMetadataNotify(controller->world,
        x,y,z,26,direction))return 0;
    if(!CloneMCJ_World_SetBlockWithMetadataNotify(controller->world,
        headX,y,headZ,26,direction|8)){
        CloneMCJ_World_SetBlockNotify(controller->world,x,y,z,0);return 0;
    }
    CloneMCJ_World_NotifyBlocksOfNeighborChange(controller->world,x,y,z,26);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(controller->world,headX,y,headZ,26);
    CloneMCJ_World_MarkMeshSectionUrgent(controller->world,x,y,z);
    CloneMCJ_World_MarkMeshSectionUrgent(controller->world,headX,y,headZ);
    controller->player->lastPlacedBlockID=26;
    controller->player->lastPlacedMetadata=direction;
    controller->player->lastPlacedX=x;controller->player->lastPlacedY=y;
    controller->player->lastPlacedZ=z;
    return CloneMCJ_PlayerControllerSP_ConsumePlacedItem(controller,stack);
}

int CloneMCJ_PlayerControllerSP_PlaceBlock(CloneMCJ_PlayerControllerSP *controller,
    int x,int y,int z,int side)
{
    CloneMCJ_ItemStack *stack;
    const CloneMCJ_ItemDefinition *item;
    const CloneMCJ_BlockDefinition *block;
    CloneMCJ_Chunk *chunk;
    CloneMCJ_TileEntity *tile;
    CloneMCJ_TileEntityType tileType;
    int targetID,placeBlockID,placedMetadata;
    if(!controller||!controller->world||!controller->player)return 0;
    if(controller->player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR)return 0;
    targetID=CloneMCJ_World_GetBlockId(controller->world,x,y,z);
    if(targetID==63||targetID==68){
        CloneMCJ_GameplayState *gameplay;
        gameplay=(CloneMCJ_GameplayState *)controller->world->gameplayUserData;
        if(gameplay){gameplay->editSignX=x;gameplay->editSignY=y;
            gameplay->editSignZ=z;gameplay->editSignRequested=1;}
        return 1;
    }
    if(CloneMCJ_Block_Activate(controller->world,x,y,z,controller->player)){
        if(targetID==64||targetID==71||targetID==69||targetID==77||
           targetID==92||targetID==93||targetID==94||targetID==96)
            CloneMCJ_World_MarkMeshSectionUrgent(controller->world,x,y,z);
        controller->player->lastActivatedBlockID=targetID;
        controller->player->lastActivatedMetadata=
            CloneMCJ_World_GetBlockMetadata(controller->world,x,y,z);
        controller->player->lastActivatedX=x;controller->player->lastActivatedY=y;
        controller->player->lastActivatedZ=z;++controller->player->blocksActivated;
        return 1;
    }
    stack=CloneMCJ_InventoryPlayer_GetCurrent(&controller->player->inventory);
    if(CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    if(CloneMCJ_ItemRecord_NameForIdNative(stack->itemID)){
        int used;
        used=CloneMCJ_ItemRecord_UseNative(controller->world,stack,x,y,z);
        if(used){controller->player->inventory.inventoryChanged=1;
            controller->player->lastActivatedBlockID=84;
            controller->player->lastActivatedMetadata=1;
            controller->player->lastActivatedX=x;controller->player->lastActivatedY=y;
            controller->player->lastActivatedZ=z;++controller->player->blocksActivated;}
        return used;
    }
    item=CloneMCJ_ItemRegistry_Get(stack->itemID);
    if(item&&item->toolClass==CLONEMC_J_TOOL_HOE)
        return CloneMCJ_ItemHoe_UseNative(controller->world,stack,controller->player,
            x,y,z,side);
    if(stack->itemID==331){
        int placed;
        placed=CloneMCJ_ItemRedstone_UseNative(controller->world,stack,
            controller->player,x,y,z,side);
        if(placed){
            controller->player->lastPlacedBlockID=55;
            controller->player->lastPlacedMetadata=0;
            controller->player->lastPlacedX=x;controller->player->lastPlacedY=y;
            controller->player->lastPlacedZ=z;
            controller->player->inventory.inventoryChanged=1;
            ++controller->player->blocksPlaced;
        }
        return placed;
    }
    if(!item||item->placeBlockID<=0)return 0;
    if(stack->itemID==324||stack->itemID==330)
        return CloneMCJ_PlayerControllerSP_PlaceDoorItem(controller,stack,
            x,y,z,side,stack->itemID==324?64:71);
    if(stack->itemID==355)
        return CloneMCJ_PlayerControllerSP_PlaceBedItem(controller,stack,
            x,y,z,side);
    placeBlockID=item->placeBlockID;
    if(stack->itemID==323){
        if(side==1)placeBlockID=63;
        else if(side>=2&&side<=5)placeBlockID=68;
        else return 0;
    }
    targetID=CloneMCJ_World_GetBlockId(controller->world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(targetID);
    if(!block||!block->replaceable){
        if(side==0)--y;else if(side==1)++y;else if(side==2)--z;
        else if(side==3)++z;else if(side==4)--x;else if(side==5)++x;
    }
    if(placeBlockID==54&&
       !CloneMCJ_PlayerControllerSP_CanPlaceChest(controller->world,x,y,z))return 0;
    if(placeBlockID==77&&
       !CloneMCJ_BlockButton_CanPlaceOnSideNative(controller->world,x,y,z,side))
        return 0;
    if(placeBlockID==69&&
       !CloneMCJ_BlockLever_CanPlaceOnSideNative(controller->world,x,y,z,side))
        return 0;
    if((placeBlockID==50||placeBlockID==75||placeBlockID==76)&&
       !CloneMCJ_BlockTorch_CanPlaceOnSideNative(controller->world,x,y,z,side))
        return 0;
    if(placeBlockID==65&&
       !CloneMCJ_BlockLadder_CanPlaceOnSideNative(controller->world,x,y,z,side))
        return 0;
    if(placeBlockID==96&&
       !((side==2&&CloneMCJ_PlayerControllerSP_IsNormalCube(
            controller->world,x,y,z+1))||
         (side==3&&CloneMCJ_PlayerControllerSP_IsNormalCube(
            controller->world,x,y,z-1))||
         (side==4&&CloneMCJ_PlayerControllerSP_IsNormalCube(
            controller->world,x+1,y,z))||
         (side==5&&CloneMCJ_PlayerControllerSP_IsNormalCube(
            controller->world,x-1,y,z))))return 0;
    if((placeBlockID==27||placeBlockID==28||placeBlockID==66)&&
       !CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,x,y-1,z))
        return 0;
    if((placeBlockID==70||placeBlockID==72||placeBlockID==93||placeBlockID==94)&&
       !CloneMCJ_PlayerControllerSP_IsNormalCube(controller->world,x,y-1,z))
        return 0;
    if(placeBlockID==115&&
       CloneMCJ_World_GetBlockId(controller->world,x,y-1,z)!=88)
        return 0;
    if(!CloneMCJ_Block_CanPlaceAt(controller->world,placeBlockID,x,y,z,
        &controller->player->entity.boundingBox))return 0;
    placedMetadata=CloneMCJ_PlayerControllerSP_PlacementMetadata(
        placeBlockID,side,controller->player,stack,x,y,z);
    if((placeBlockID==63||placeBlockID==68)&&
       !CloneMCJ_BlockSign_CanStayNative(controller->world,placeBlockID,
            x,y,z,placedMetadata))return 0;
    if(placeBlockID==92&&
       !CloneMCJ_BlockCake_CanStayNative(controller->world,x,y,z))return 0;
    if(!CloneMCJ_World_SetBlockWithMetadataNotify(controller->world,
        x,y,z,placeBlockID,placedMetadata))return 0;
    if(placeBlockID==69&&!CloneMCJ_BlockLever_OnPlacedNative(
            controller->world,x,y,z,side))return 0;
    if(placeBlockID==93||placeBlockID==94)
        CloneMCJ_BlockRedstoneRepeater_OnPlacedByNative(
            controller->world,x,y,z);
    controller->player->lastPlacedBlockID=placeBlockID;
    controller->player->lastPlacedMetadata=placedMetadata;
    controller->player->lastPlacedX=x;controller->player->lastPlacedY=y;
    controller->player->lastPlacedZ=z;
    block=CloneMCJ_BlockRegistry_Get(placeBlockID);
    if(block&&block->hasTileEntity){
        tileType=CLONEMC_J_TILE_NONE;
        if(placeBlockID==54)tileType=CLONEMC_J_TILE_CHEST;
        else if(placeBlockID==61||placeBlockID==62)tileType=CLONEMC_J_TILE_FURNACE;
        else if(placeBlockID==23)tileType=CLONEMC_J_TILE_DISPENSER;
        else if(placeBlockID==117)tileType=CLONEMC_J_TILE_BREWING_STAND;
        else if(placeBlockID==116)tileType=CLONEMC_J_TILE_ENCHANTMENT_TABLE;
        else if(placeBlockID==25)tileType=CLONEMC_J_TILE_NOTE;
        else if(placeBlockID==84)tileType=CLONEMC_J_TILE_RECORD_PLAYER;
        else if(placeBlockID==63||placeBlockID==68)tileType=CLONEMC_J_TILE_SIGN;
        tile=tileType!=CLONEMC_J_TILE_NONE?
            CloneMCJ_TileEntity_Create(tileType,controller->world,x,y,z):
            (CloneMCJ_TileEntity *)0;
        chunk=CloneMCJ_World_GetChunkFromBlockCoords(controller->world,x,z);
        if(!tile||!chunk||!CloneMCJ_Chunk_SetTileEntity(chunk,
            x&15,y,z&15,tile)){
            CloneMCJ_TileEntity_Destroy(tile);
            CloneMCJ_World_SetBlockNotify(controller->world,x,y,z,0);return 0;
        }
        if(placeBlockID==63||placeBlockID==68){
            CloneMCJ_GameplayState *gameplay;
            gameplay=(CloneMCJ_GameplayState *)controller->world->gameplayUserData;
            if(gameplay){gameplay->editSignX=x;gameplay->editSignY=y;
                gameplay->editSignZ=z;gameplay->editSignRequested=1;}
        }
        if(placeBlockID==25){
            tile->previousRedstoneState=(unsigned char)(
                CloneMCJ_World_IsBlockGettingPowered(controller->world,x,y,z)?1:0);
            if(tile->previousRedstoneState)CloneMCJ_TileEntityNote_TriggerNative(tile);
        }
    }
    if(placeBlockID==54){
        if(CloneMCJ_World_GetBlockId(controller->world,x-1,y,z)==54)
            CloneMCJ_World_SetBlockMetadataNotify(controller->world,x-1,y,z,placedMetadata);
        if(CloneMCJ_World_GetBlockId(controller->world,x+1,y,z)==54)
            CloneMCJ_World_SetBlockMetadataNotify(controller->world,x+1,y,z,placedMetadata);
        if(CloneMCJ_World_GetBlockId(controller->world,x,y,z-1)==54)
            CloneMCJ_World_SetBlockMetadataNotify(controller->world,x,y,z-1,placedMetadata);
        if(CloneMCJ_World_GetBlockId(controller->world,x,y,z+1)==54)
            CloneMCJ_World_SetBlockMetadataNotify(controller->world,x,y,z+1,placedMetadata);
    }
    CloneMCJ_World_NotifyBlocksOfNeighborChange(controller->world,x,y,z,placeBlockID);
    CloneMCJ_World_MarkMeshSectionUrgent(controller->world,x,y,z);
    return CloneMCJ_PlayerControllerSP_ConsumePlacedItem(controller,stack);
}
void CloneMCJ_PlayerControllerSP_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_PlayerControllerSP_JavaName(void)
{
    return "net.minecraft.src.PlayerControllerSP";
}

const char *CloneMCJ_PlayerControllerSP_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_PlayerControllerSP_JavaSourceHash32(void)
{
    return 0xC3BB81D1UL;
}
