/*
 * CloneMC Java port scaffold: Entity
 *
 * Java source: Entity.java
 * Java type: class Entity
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: b58c3a3d9529392d2bb3569ca4a8bfc1ee98344c687ac5214a72a8888ebf2379
 * Java lines: 1318
 * Discovered declared fields: 66
 * Discovered declared methods/constructors: 84
 * Referenced Java classes: AxisAlignedBB, DataWatcher, World, MathHelper, Block, StepSound, Material, BlockFluid, Vec3D, NBTTagCompound, NBTTagList, NBTTagDouble, NBTTagFloat, EntityList, ItemStack, EntityItem, EntityPlayer, EntityLightningBolt, EntityLiving
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static int nextEntityID = 0
 * - public int entityId
 * - public double renderDistanceWeight
 * - public boolean preventEntitySpawning
 * - public Entity riddenByEntity
 * - public Entity ridingEntity
 * - public World worldObj
 * - public double prevPosX
 * - public double prevPosY
 * - public double prevPosZ
 * - public double posX
 * - public double posY
 * - public double posZ
 * - public double motionX
 * - public double motionY
 * - public double motionZ
 * - public float rotationYaw
 * - public float rotationPitch
 * - public float prevRotationYaw
 * - public float prevRotationPitch
 * - public boolean onGround
 * - public boolean isCollidedHorizontally
 * - public boolean isCollidedVertically
 * - public boolean isCollided
 * - public boolean beenAttacked
 * - public boolean isInWeb
 * - public boolean field_9293_aM
 * - public boolean isDead
 * - public float yOffset
 * - public float width
 * - public float height
 * - public float prevDistanceWalkedModified
 * - public float distanceWalkedModified
 * - protected float fallDistance
 * - private int nextStepDistance
 * - public double lastTickPosX
 * - public double lastTickPosY
 * - public double lastTickPosZ
 * - public float ySize
 * - public float stepHeight
 * - public boolean noClip
 * - public float entityCollisionReduction
 * - protected Random rand
 * - public int ticksExisted
 * - public int fireResistance
 * - public int fire
 * - protected int maxAir
 * - protected boolean inWater
 * - public int heartsLife
 * - public int air
 * - private boolean isFirstUpdate
 * - public String skinUrl
 * - public String cloakUrl
 * - protected boolean isImmuneToFire
 * - protected DataWatcher dataWatcher
 * - public float entityBrightness
 * - private double entityRiderPitchDelta
 * - private double entityRiderYawDelta
 * - public boolean addedToChunk
 * - public int chunkCoordX
 * - public int chunkCoordY
 * - public int chunkCoordZ
 * - public int serverPosX
 * - public int serverPosY
 * - public int serverPosZ
 * - public boolean ignoreFrustumCheck
 *
 * Java method/constructor inventory:
 * - public Entity(World world)
 * - protected abstract void entityInit()
 * - public DataWatcher getDataWatcher()
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - protected void preparePlayerToSpawn()
 * - public void setEntityDead()
 * - protected void setSize(float f, float f1)
 * - protected void setRotation(float f, float f1)
 * - public void setPosition(double d, double d1, double d2)
 * - public void func_346_d(float f, float f1)
 * - public void onUpdate()
 * - public void onEntityUpdate()
 * - protected void setOnFireFromLava()
 * - protected void kill()
 * - public boolean isOffsetPositionInLiquid(double d, double d1, double d2)
 * - public void moveEntity(double d, double d1, double d2)
 * - protected boolean canTriggerWalking()
 * - protected void updateFallState(double d, boolean flag)
 * - public AxisAlignedBB getBoundingBox()
 * - protected void dealFireDamage(int i)
 * - protected void fall(float f)
 * - public boolean isWet()
 * - public boolean isInWater()
 * - public boolean handleWaterMovement()
 * - public boolean isInsideOfMaterial(Material material)
 * - public float getEyeHeight()
 * - public boolean handleLavaMovement()
 * - public void moveFlying(float f, float f1, float f2)
 * - public float getEntityBrightness(float f)
 * - public void setWorld(World world)
 * - public float getDistanceToEntity(Entity entity)
 * - public double getDistanceSq(double d, double d1, double d2)
 * - public double getDistance(double d, double d1, double d2)
 * - public double getDistanceSqToEntity(Entity entity)
 * - public void onCollideWithPlayer(EntityPlayer entityplayer)
 * - public void applyEntityCollision(Entity entity)
 * - public void addVelocity(double d, double d1, double d2)
 * - protected void setBeenAttacked()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public boolean canBeCollidedWith()
 * - public boolean canBePushed()
 * - public void addToPlayerScore(Entity entity, int i)
 * - public boolean isInRangeToRenderVec3D(Vec3D vec3d)
 * - public boolean isInRangeToRenderDist(double d)
 * - public String getEntityTexture()
 * - public boolean addEntityID(NBTTagCompound nbttagcompound)
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - protected final String getEntityString()
 * - protected abstract void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected abstract void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - protected NBTTagList newDoubleNBTList(double ad[])
 * - protected NBTTagList newFloatNBTList(float af[])
 * - public float getShadowSize()
 * - public EntityItem dropItem(int i, int j)
 * - public EntityItem dropItemWithOffset(int i, int j, float f)
 * - public EntityItem entityDropItem(ItemStack itemstack, float f)
 * - public boolean isEntityAlive()
 * - public boolean isEntityInsideOpaqueBlock()
 * - public boolean interact(EntityPlayer entityplayer)
 * - public AxisAlignedBB getCollisionBox(Entity entity)
 * - public void updateRidden()
 * - public void updateRiderPosition()
 * - public double getYOffset()
 * - public double getMountedYOffset()
 * - public void mountEntity(Entity entity)
 * - public float getCollisionBorderSize()
 * - public Vec3D getLookVec()
 * - public void setInPortal()
 * - public void setVelocity(double d, double d1, double d2)
 * - public void handleHealthUpdate(byte byte0)
 * - public void performHurtAnimation()
 * - public void updateCloak()
 * - public void outfitWithItem(int i, int j, int k)
 * - public boolean isBurning()
 * - public boolean isRiding()
 * - public boolean isSneaking()
 * - protected boolean getEntityFlag(int i)
 * - protected void setEntityFlag(int i, boolean flag)
 * - public void onStruckByLightning(EntityLightningBolt entitylightningbolt)
 * - public void onKillEntity(EntityLiving entityliving)
 * - protected boolean pushOutOfBlocks(double d, double d1, double d2)
 * - public final AxisAlignedBB boundingBox = AxisAlignedBB.getBoundingBox(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>
#include <string.h>

static int CloneMCJ_Entity_NextID = 1;

void CloneMCJ_Entity_ReserveID(int entityID)
{
    if (entityID >= CloneMCJ_Entity_NextID && entityID < 2147483647)
        CloneMCJ_Entity_NextID = entityID + 1;
}

static int CloneMCJ_Entity_IsSafeNumber(double value, double limit)
{
    /* C89/Open Watcom has no portable isfinite().  NaN is the only value that
     * is unequal to itself; the range check also rejects infinities. */
    return value == value && value >= -limit && value <= limit;
}

static int CloneMCJ_Entity_BoxRange(const CloneMCAxisAlignedBB *box, int *minX, int *minY, int *minZ,
                                    int *maxX, int *maxY, int *maxZ)
{
    *minX = CloneMCJava_FloorDouble(box->minX);
    *minY = CloneMCJava_FloorDouble(box->minY);
    *minZ = CloneMCJava_FloorDouble(box->minZ);
    *maxX = CloneMCJava_FloorDouble(box->maxX + 1.0);
    *maxY = CloneMCJava_FloorDouble(box->maxY + 1.0);
    *maxZ = CloneMCJava_FloorDouble(box->maxZ + 1.0);
    return 1;
}

static int CloneMCJ_Entity_ColumnLoaded(CloneMCJ_World *world,int x,int z)
{
    if(!world)return 0;
    return CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,
        CloneMCJ_World_GlobalToChunk(x),CloneMCJ_World_GlobalToChunk(z))!=0;
}

static CloneMCAxisAlignedBB CloneMCJ_Entity_MissingChunkBarrier(int x,int y,int z)
{
    return CloneMCAABB_Create((double)x,(double)y,(double)z,
        (double)x+1.0,(double)y+1.0,(double)z+1.0);
}

static int CloneMCJ_Entity_BoxCollides(CloneMCJ_World *world,
    const CloneMCAxisAlignedBB *query,int missingMode)
{
    int minX, minY, minZ, maxX, maxY, maxZ, x, y, z, i, count;
    CloneMCAxisAlignedBB boxes[3];
    CloneMCJ_Entity_BoxRange(query, &minX, &minY, &minZ, &maxX, &maxY, &maxZ);
    for (x = minX; x < maxX; ++x) for (z = minZ; z < maxZ; ++z) {
        int loaded;
        loaded=CloneMCJ_Entity_ColumnLoaded(world,x,z);
        for (y = minY; y < maxY; ++y) {
            if(!loaded&&missingMode==1&&y>=0&&y<CLONEMC_J_CHUNK_HEIGHT)return 1;
            if(!loaded)continue;
            count = CloneMCJ_Block_GetCollisionBoxes(world, x, y, z, boxes, 3);
            for (i = 0; i < count; ++i) if (CloneMCAABB_Intersects(query, &boxes[i])) return 1;
        }
    }
    return 0;
}

static double CloneMCJ_Entity_ClipY(CloneMCJ_World *world, const CloneMCAxisAlignedBB *query,
    const CloneMCAxisAlignedBB *moving,double offset,int missingMode)
{
    int minX, minY, minZ, maxX, maxY, maxZ, x, y, z, i, count;
    CloneMCAxisAlignedBB boxes[3];
    CloneMCJ_Entity_BoxRange(query, &minX, &minY, &minZ, &maxX, &maxY, &maxZ);
    for (x = minX; x < maxX; ++x) for (z = minZ; z < maxZ; ++z) {
        int loaded;
        loaded=CloneMCJ_Entity_ColumnLoaded(world,x,z);
        for (y = minY; y < maxY; ++y) {
            if(!loaded&&(missingMode==1||(missingMode==2&&offset<0.0))&&
               y>=0&&y<CLONEMC_J_CHUNK_HEIGHT){
                CloneMCAxisAlignedBB barrier;
                barrier=CloneMCJ_Entity_MissingChunkBarrier(x,y,z);
                offset=CloneMCAABB_CalculateYOffset(&barrier,moving,offset);
                continue;
            }
            if(!loaded)continue;
            count = CloneMCJ_Block_GetCollisionBoxes(world, x, y, z, boxes, 3);
            for (i = 0; i < count; ++i) offset = CloneMCAABB_CalculateYOffset(&boxes[i], moving, offset);
        }
    }
    return offset;
}

static double CloneMCJ_Entity_ClipX(CloneMCJ_World *world, const CloneMCAxisAlignedBB *query,
    const CloneMCAxisAlignedBB *moving,double offset,int missingMode)
{
    int minX, minY, minZ, maxX, maxY, maxZ, x, y, z, i, count;
    CloneMCAxisAlignedBB boxes[3];
    CloneMCJ_Entity_BoxRange(query, &minX, &minY, &minZ, &maxX, &maxY, &maxZ);
    for (x = minX; x < maxX; ++x) for (z = minZ; z < maxZ; ++z) {
        int loaded;
        loaded=CloneMCJ_Entity_ColumnLoaded(world,x,z);
        for (y = minY; y < maxY; ++y) {
            if(!loaded&&missingMode==1&&y>=0&&y<CLONEMC_J_CHUNK_HEIGHT){
                CloneMCAxisAlignedBB barrier;
                barrier=CloneMCJ_Entity_MissingChunkBarrier(x,y,z);
                offset=CloneMCAABB_CalculateXOffset(&barrier,moving,offset);
                continue;
            }
            if(!loaded)continue;
            count = CloneMCJ_Block_GetCollisionBoxes(world, x, y, z, boxes, 3);
            for (i = 0; i < count; ++i) offset = CloneMCAABB_CalculateXOffset(&boxes[i], moving, offset);
        }
    }
    return offset;
}

static double CloneMCJ_Entity_ClipZ(CloneMCJ_World *world, const CloneMCAxisAlignedBB *query,
    const CloneMCAxisAlignedBB *moving,double offset,int missingMode)
{
    int minX, minY, minZ, maxX, maxY, maxZ, x, y, z, i, count;
    CloneMCAxisAlignedBB boxes[3];
    CloneMCJ_Entity_BoxRange(query, &minX, &minY, &minZ, &maxX, &maxY, &maxZ);
    for (x = minX; x < maxX; ++x) for (z = minZ; z < maxZ; ++z) {
        int loaded;
        loaded=CloneMCJ_Entity_ColumnLoaded(world,x,z);
        for (y = minY; y < maxY; ++y) {
            if(!loaded&&missingMode==1&&y>=0&&y<CLONEMC_J_CHUNK_HEIGHT){
                CloneMCAxisAlignedBB barrier;
                barrier=CloneMCJ_Entity_MissingChunkBarrier(x,y,z);
                offset=CloneMCAABB_CalculateZOffset(&barrier,moving,offset);
                continue;
            }
            if(!loaded)continue;
            count = CloneMCJ_Block_GetCollisionBoxes(world, x, y, z, boxes, 3);
            for (i = 0; i < count; ++i) offset = CloneMCAABB_CalculateZOffset(&boxes[i], moving, offset);
        }
    }
    return offset;
}

void CloneMCJ_Entity_Initialize(CloneMCJ_Entity *entity, CloneMCJ_World *world)
{
    if (!entity) return;
    memset(entity, 0, sizeof(*entity));
    entity->worldObj = world;
    entity->entityId = CloneMCJ_Entity_NextID;
    if(CloneMCJ_Entity_NextID<2147483647)++CloneMCJ_Entity_NextID;
    else CloneMCJ_Entity_NextID=1;
    entity->width = 0.6F;
    entity->height = 1.8F;
    entity->air = 300;
    CloneMCJavaRandom_SetSeed(&entity->rand, (CloneMCJLong)(entity->entityId * 9973 + 17));
    CloneMCJ_Entity_SetPosition(entity, 0.0, 0.0, 0.0);
}

float CloneMCJ_Entity_GetBrightness(const CloneMCJ_Entity *entity)
{
    CloneMCJ_World *world;
    double sampleHeight;
    int x;
    int y;
    int z;
    int light;
    float brightness;
    if(!entity)return 0.0F;
    world=entity->worldObj;
    if(!world)return entity->entityBrightness;
    /* Direct Entity.getEntityBrightness port.  The native entity position is
     * the AABB floor, so yOffset is normally zero and the 0.66-height sample
     * still lands in the Java torso-lighting cell. */
    if(!CloneMCJ_World_CheckChunksExist(world,
        CloneMCJava_FloorDouble(entity->boundingBox.minX),
        CloneMCJava_FloorDouble(entity->boundingBox.minY),
        CloneMCJava_FloorDouble(entity->boundingBox.minZ),
        CloneMCJava_FloorDouble(entity->boundingBox.maxX),
        CloneMCJava_FloorDouble(entity->boundingBox.maxY),
        CloneMCJava_FloorDouble(entity->boundingBox.maxZ)))
        return entity->entityBrightness;
    x=CloneMCJava_FloorDouble(entity->posX);
    sampleHeight=(entity->boundingBox.maxY-entity->boundingBox.minY)*0.66;
    y=CloneMCJava_FloorDouble((entity->posY-(double)entity->yOffset)+sampleHeight);
    z=CloneMCJava_FloorDouble(entity->posZ);
    light=CloneMCJ_World_GetBlockLightValue(world,x,y,z);
    if(light<0)light=0;
    if(light>15)light=15;
    brightness=world->worldProvider.lightBrightnessTable[light];
    return brightness<entity->entityBrightness?entity->entityBrightness:brightness;
}

int CloneMCJ_Entity_IsInsideOpaqueBlock(const CloneMCJ_Entity *entity,
    float eyeHeight)
{
    int sample;
    if(!entity||!entity->worldObj)return 0;
    for(sample=0;sample<8;++sample){
        float offsetX;
        float offsetY;
        float offsetZ;
        int x;
        int y;
        int z;
        const CloneMCJ_BlockDefinition *block;
        offsetX=((float)(sample&1)-0.5F)*entity->width*0.9F;
        offsetY=((float)((sample>>1)&1)-0.5F)*0.1F;
        offsetZ=((float)((sample>>2)&1)-0.5F)*entity->width*0.9F;
        x=CloneMCJava_FloorDouble(entity->posX+(double)offsetX);
        y=CloneMCJava_FloorDouble(entity->posY+(double)eyeHeight+
            (double)offsetY);
        z=CloneMCJava_FloorDouble(entity->posZ+(double)offsetZ);
        block=CloneMCJ_BlockRegistry_Get(CloneMCJ_World_GetBlockId(
            entity->worldObj,x,y,z));
        if(block&&block->opaque&&block->collidable)return 1;
    }
    return 0;
}

void CloneMCJ_Entity_SetSize(CloneMCJ_Entity *entity, float width, float height)
{
    if (!entity || width <= 0.0F || height <= 0.0F) return;
    entity->width = width;
    entity->height = height;
    CloneMCJ_Entity_SetPosition(entity, entity->posX, entity->posY, entity->posZ);
}

void CloneMCJ_Entity_SetPosition(CloneMCJ_Entity *entity, double x, double y, double z)
{
    double half;
    if (!entity) return;
    entity->posX = x;
    entity->posY = y;
    entity->posZ = z;
    half = (double)entity->width / 2.0;
    entity->boundingBox = CloneMCAABB_Create(x - half, y, z - half, x + half, y + entity->height, z + half);
}

void CloneMCJ_Entity_SetRotation(CloneMCJ_Entity *entity, float yaw, float pitch)
{
    if (!entity) return;
    entity->rotationYaw = yaw;
    if (pitch < -90.0F) pitch = -90.0F;
    if (pitch > 90.0F) pitch = 90.0F;
    entity->rotationPitch = pitch;
}

void CloneMCJ_Entity_MoveFlying(CloneMCJ_Entity *entity, float strafe, float forward, float friction)
{
    float length;
    float sine;
    float cosine;
    if (!entity) return;
    length = strafe * strafe + forward * forward;
    if (length < 0.0001F) return;
    length = (float)sqrt((double)length);
    if (length < 1.0F) length = 1.0F;
    length = friction / length;
    strafe *= length;
    forward *= length;
    sine = (float)sin((double)(entity->rotationYaw * 3.14159265358979323846F / 180.0F));
    cosine = (float)cos((double)(entity->rotationYaw * 3.14159265358979323846F / 180.0F));
    entity->motionX += (double)(strafe * cosine - forward * sine);
    entity->motionZ += (double)(forward * cosine + strafe * sine);
}

int CloneMCJ_Entity_CanMoveSafely(const CloneMCJ_Entity *entity,
    double xMove,double yMove,double zMove)
{
    CloneMCJ_World *world;
    double minX,minZ,maxX,maxZ;
    int blockMinX,blockMinZ,blockMaxX,blockMaxZ;
    (void)yMove;
    if(!entity||entity->isDead)return 0;
    world=entity->worldObj;if(!world)return 0;
    minX=entity->boundingBox.minX;minZ=entity->boundingBox.minZ;
    maxX=entity->boundingBox.maxX;maxZ=entity->boundingBox.maxZ;
    if(xMove<0.0)minX+=xMove;else maxX+=xMove;
    if(zMove<0.0)minZ+=zMove;else maxZ+=zMove;
    blockMinX=CloneMCJava_FloorDouble(minX-1.0);
    blockMinZ=CloneMCJava_FloorDouble(minZ-1.0);
    blockMaxX=CloneMCJava_FloorDouble(maxX+1.0);
    blockMaxZ=CloneMCJava_FloorDouble(maxZ+1.0);
    return CloneMCJ_World_CheckChunksExist(world,blockMinX,0,blockMinZ,
        blockMaxX,CLONEMC_J_CHUNK_HEIGHT-1,blockMaxZ);
}

int CloneMCJ_Entity_CanUpdateSafely(const CloneMCJ_Entity *entity,
    double xMove,double yMove,double zMove)
{
    CloneMCJ_World *world;
    int centerX,centerZ;
    if(!entity||entity->isDead)return 0;
    world=entity->worldObj;if(!world)return 0;
    /* Keep the Java update-neighborhood query available to diagnostics and
     * packet-driven worlds.  Singleplayer movement no longer reuses this
     * broad gate; collision safety is determined by the swept AABB below. */
    if(world->multiplayerWorld){
        centerX=CloneMCJava_FloorDouble(entity->posX);
        centerZ=CloneMCJava_FloorDouble(entity->posZ);
        return CloneMCJ_World_CheckChunksExist(world,centerX-32,0,centerZ-32,
            centerX+32,CLONEMC_J_CHUNK_HEIGHT-1,centerZ+32);
    }
    return CloneMCJ_Entity_CanMoveSafely(entity,xMove,yMove,zMove);
}

void CloneMCJ_Entity_Move(CloneMCJ_Entity *entity, double xMove, double yMove, double zMove)
{
    double originalX, originalY, originalZ;
    CloneMCAxisAlignedBB originalBox;
    CloneMCAxisAlignedBB query;
    CloneMCAxisAlignedBB sneakBox;
    int missingMode;
    if(!entity||!entity->worldObj)return;
    missingMode=entity==entity->worldObj->localPlayerEntity?2:1;
    if (entity->noClip) {
        CloneMCAABB_Offset(&entity->boundingBox, xMove, yMove, zMove);
        entity->posX = (entity->boundingBox.minX + entity->boundingBox.maxX) / 2.0;
        entity->posY = entity->boundingBox.minY;
        entity->posZ = (entity->boundingBox.minZ + entity->boundingBox.maxZ) / 2.0;
        return;
    }
    /* V142: entity movement performs collision only.  It never owns chunk
     * admission, eviction, saving, allocation, generation, population, or
     * lighting.  Missing columns are represented by the collision barrier in
     * the clip helpers until the central streamer publishes them.  The local
     * player retains V135 horizontal continuity while downward motion is held
     * for at most the transition tick; its normal end-of-tick center update then
     * publishes the newly entered center chunk. */
    if (entity->inWeb) {
        entity->inWeb = 0;
        xMove *= 0.25;
        yMove *= 0.05;
        zMove *= 0.25;
        entity->motionX = entity->motionY = entity->motionZ = 0.0;
    }
    originalX = xMove;
    originalY = yMove;
    originalZ = zMove;
    originalBox = entity->boundingBox;
    if (entity->sneaking && entity->onGround) {
        sneakBox = CloneMCAABB_OffsetCopy(&entity->boundingBox, xMove, -1.0, 0.0);
        while (xMove != 0.0 && !CloneMCJ_Entity_BoxCollides(entity->worldObj,&sneakBox,missingMode)) {
            if (xMove < 0.05 && xMove >= -0.05) xMove = 0.0; else if (xMove > 0.0) xMove -= 0.05; else xMove += 0.05;
            sneakBox = CloneMCAABB_OffsetCopy(&entity->boundingBox, xMove, -1.0, 0.0);
        }
        sneakBox = CloneMCAABB_OffsetCopy(&entity->boundingBox, 0.0, -1.0, zMove);
        while (zMove != 0.0 && !CloneMCJ_Entity_BoxCollides(entity->worldObj,&sneakBox,missingMode)) {
            if (zMove < 0.05 && zMove >= -0.05) zMove = 0.0; else if (zMove > 0.0) zMove -= 0.05; else zMove += 0.05;
            sneakBox = CloneMCAABB_OffsetCopy(&entity->boundingBox, 0.0, -1.0, zMove);
        }
    }
    query = CloneMCAABB_AddCoord(&entity->boundingBox, xMove, yMove, zMove);
    yMove = CloneMCJ_Entity_ClipY(entity->worldObj,&query,&entity->boundingBox,yMove,missingMode);
    CloneMCAABB_Offset(&entity->boundingBox, 0.0, yMove, 0.0);
    xMove = CloneMCJ_Entity_ClipX(entity->worldObj,&query,&entity->boundingBox,xMove,missingMode);
    CloneMCAABB_Offset(&entity->boundingBox, xMove, 0.0, 0.0);
    zMove = CloneMCJ_Entity_ClipZ(entity->worldObj,&query,&entity->boundingBox,zMove,missingMode);
    CloneMCAABB_Offset(&entity->boundingBox, 0.0, 0.0, zMove);
    if (entity->stepHeight > 0.0F && (originalX != xMove || originalZ != zMove) &&
        (entity->onGround || (originalY != yMove && originalY < 0.0))) {
        CloneMCAxisAlignedBB stepBox;
        CloneMCAxisAlignedBB stepQuery;
        double sx, sy, sz, down;
        stepBox = originalBox;
        sx = originalX;
        sy = entity->stepHeight;
        sz = originalZ;
        stepQuery = CloneMCAABB_AddCoord(&stepBox, sx, sy, sz);
        sy = CloneMCJ_Entity_ClipY(entity->worldObj,&stepQuery,&stepBox,sy,missingMode);
        CloneMCAABB_Offset(&stepBox, 0.0, sy, 0.0);
        sx = CloneMCJ_Entity_ClipX(entity->worldObj,&stepQuery,&stepBox,sx,missingMode);
        CloneMCAABB_Offset(&stepBox, sx, 0.0, 0.0);
        sz = CloneMCJ_Entity_ClipZ(entity->worldObj,&stepQuery,&stepBox,sz,missingMode);
        CloneMCAABB_Offset(&stepBox, 0.0, 0.0, sz);
        down = -sy;
        down = CloneMCJ_Entity_ClipY(entity->worldObj,&stepQuery,&stepBox,down,missingMode);
        CloneMCAABB_Offset(&stepBox, 0.0, down, 0.0);
        if (sx * sx + sz * sz > xMove * xMove + zMove * zMove) {
            entity->boundingBox = stepBox;
            xMove = sx;
            yMove = sy + down;
            zMove = sz;
        }
    }
    entity->collidedHorizontally = (originalX != xMove || originalZ != zMove);
    entity->collidedVertically = originalY != yMove;
    entity->onGround = entity->collidedVertically && originalY < 0.0;
    entity->collided = entity->collidedHorizontally || entity->collidedVertically;
    entity->posX = (entity->boundingBox.minX + entity->boundingBox.maxX) / 2.0;
    entity->posY = entity->boundingBox.minY;
    entity->posZ = (entity->boundingBox.minZ + entity->boundingBox.maxZ) / 2.0;
    if (originalX != xMove) entity->motionX = 0.0;
    if (originalY != yMove) entity->motionY = 0.0;
    if (originalZ != zMove) entity->motionZ = 0.0;
    if (entity->onGround) entity->fallDistance = 0.0F;
    else if (yMove < 0.0) entity->fallDistance -= (float)yMove;
}

int CloneMCJ_Entity_IsInsideMaterial(const CloneMCJ_Entity *entity, CloneMCJ_MaterialKind material)
{
    int minX, minY, minZ, maxX, maxY, maxZ, x, y, z;
    if (!entity || !entity->worldObj) return 0;
    CloneMCJ_Entity_BoxRange(&entity->boundingBox, &minX, &minY, &minZ, &maxX, &maxY, &maxZ);
    for (x = minX; x < maxX; ++x) for (z = minZ; z < maxZ; ++z) for (y = minY; y < maxY; ++y) {
        const CloneMCJ_BlockDefinition *block;
        block = CloneMCJ_BlockRegistry_Get(CloneMCJ_World_GetLoadedBlockId(entity->worldObj, x, y, z));
        if (block && block->material == material) return 1;
    }
    return 0;
}

int CloneMCJ_Entity_WriteNBT(const CloneMCJ_Entity *entity, CloneMCJ_NBTTagCompound *compound, const char *id)
{
    CloneMCJ_NBTTagList *position;
    CloneMCJ_NBTTagList *motion;
    CloneMCJ_NBTTagList *rotation;
    if (!entity || !compound) return 0;
    if (id) CloneMCJ_NBTTagCompound_SetString(compound, "id", id);
    position = CloneMCJ_NBTTagList_Create();
    motion = CloneMCJ_NBTTagList_Create();
    rotation = CloneMCJ_NBTTagList_Create();
    if (!position || !motion || !rotation) {
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)position);
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)motion);
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)rotation);
        return 0;
    }
    CloneMCJ_NBTTagList_Append(position, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(entity->posX));
    CloneMCJ_NBTTagList_Append(position, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(entity->posY));
    CloneMCJ_NBTTagList_Append(position, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(entity->posZ));
    CloneMCJ_NBTTagList_Append(motion, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(entity->motionX));
    CloneMCJ_NBTTagList_Append(motion, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(entity->motionY));
    CloneMCJ_NBTTagList_Append(motion, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(entity->motionZ));
    CloneMCJ_NBTTagList_Append(rotation, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagFloat_Create(entity->rotationYaw));
    CloneMCJ_NBTTagList_Append(rotation, (CloneMCJ_NBTBase *)CloneMCJ_NBTTagFloat_Create(entity->rotationPitch));
    CloneMCJ_NBTTagCompound_SetTag(compound, "Pos", (CloneMCJ_NBTBase *)position);
    CloneMCJ_NBTTagCompound_SetTag(compound, "Motion", (CloneMCJ_NBTBase *)motion);
    CloneMCJ_NBTTagCompound_SetTag(compound, "Rotation", (CloneMCJ_NBTBase *)rotation);
    CloneMCJ_NBTTagCompound_SetFloat(compound, "FallDistance", entity->fallDistance);
    CloneMCJ_NBTTagCompound_SetShort(compound, "Fire", (CloneMCJShort)entity->fire);
    CloneMCJ_NBTTagCompound_SetShort(compound, "Air", (CloneMCJShort)entity->air);
    CloneMCJ_NBTTagCompound_SetBoolean(compound, "OnGround", entity->onGround);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "EntityId", entity->entityId);
    return 1;
}

int CloneMCJ_Entity_ReadNBT(CloneMCJ_Entity *entity, const CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagList *position;
    CloneMCJ_NBTTagList *motion;
    CloneMCJ_NBTTagList *rotation;
    CloneMCJ_NBTBase *tag;
    double x, y, z;
    int storedID;
    if (!entity || !compound) return 0;
    position = CloneMCJ_NBTTagCompound_GetTagList(compound, "Pos");
    motion = CloneMCJ_NBTTagCompound_GetTagList(compound, "Motion");
    rotation = CloneMCJ_NBTTagCompound_GetTagList(compound, "Rotation");
    if (CloneMCJ_NBTTagList_Count(position) < 3) return 0;
    tag = CloneMCJ_NBTTagList_Get(position, 0); if(!tag||tag->type!=CLONEMC_J_NBT_TAG_DOUBLE)return 0; x=tag->value.doubleValue;
    tag = CloneMCJ_NBTTagList_Get(position, 1); if(!tag||tag->type!=CLONEMC_J_NBT_TAG_DOUBLE)return 0; y=tag->value.doubleValue;
    tag = CloneMCJ_NBTTagList_Get(position, 2); if(!tag||tag->type!=CLONEMC_J_NBT_TAG_DOUBLE)return 0; z=tag->value.doubleValue;
    if(!CloneMCJ_Entity_IsSafeNumber(x,32000000.0)||
       !CloneMCJ_Entity_IsSafeNumber(y,32000000.0)||
       !CloneMCJ_Entity_IsSafeNumber(z,32000000.0))return 0;
    if (CloneMCJ_NBTTagList_Count(motion) >= 3) {
        tag=CloneMCJ_NBTTagList_Get(motion,0);entity->motionX=tag&&tag->type==CLONEMC_J_NBT_TAG_DOUBLE?tag->value.doubleValue:0.0;
        tag=CloneMCJ_NBTTagList_Get(motion,1);entity->motionY=tag&&tag->type==CLONEMC_J_NBT_TAG_DOUBLE?tag->value.doubleValue:0.0;
        tag=CloneMCJ_NBTTagList_Get(motion,2);entity->motionZ=tag&&tag->type==CLONEMC_J_NBT_TAG_DOUBLE?tag->value.doubleValue:0.0;
        if(!CloneMCJ_Entity_IsSafeNumber(entity->motionX,10.0))entity->motionX=0.0;
        if(!CloneMCJ_Entity_IsSafeNumber(entity->motionY,10.0))entity->motionY=0.0;
        if(!CloneMCJ_Entity_IsSafeNumber(entity->motionZ,10.0))entity->motionZ=0.0;
    }
    if (CloneMCJ_NBTTagList_Count(rotation) >= 2) {
        tag=CloneMCJ_NBTTagList_Get(rotation,0);entity->rotationYaw=tag&&tag->type==CLONEMC_J_NBT_TAG_FLOAT?tag->value.floatValue:0.0F;
        tag=CloneMCJ_NBTTagList_Get(rotation,1);entity->rotationPitch=tag&&tag->type==CLONEMC_J_NBT_TAG_FLOAT?tag->value.floatValue:0.0F;
        if(!CloneMCJ_Entity_IsSafeNumber((double)entity->rotationYaw,360000.0))entity->rotationYaw=0.0F;
        if(!CloneMCJ_Entity_IsSafeNumber((double)entity->rotationPitch,360000.0))entity->rotationPitch=0.0F;
    }
    entity->fallDistance = CloneMCJ_NBTTagCompound_GetFloat(compound, "FallDistance");
    entity->fire = CloneMCJ_NBTTagCompound_GetShort(compound, "Fire");
    entity->air = CloneMCJ_NBTTagCompound_GetShort(compound, "Air");
    entity->onGround = (unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound, "OnGround");
    storedID=CloneMCJ_NBTTagCompound_GetInteger(compound,"EntityId");
    if(storedID>0){entity->entityId=storedID;CloneMCJ_Entity_ReserveID(storedID);}
    CloneMCJ_Entity_SetPosition(entity, x, y, z);
    return 1;
}

void CloneMCJ_Entity_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Entity_JavaName(void)
{
    return "net.minecraft.src.Entity";
}

const char *CloneMCJ_Entity_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_Entity_JavaSourceHash32(void)
{
    return 0xB58C3A3DUL;
}
