/*
 * Fixed-capacity Open Watcom C port of EntityAIBase, EntityAITaskEntry and
 * EntityAITasks from the uploaded Minecraft 1.2.3 source.  The scheduler
 * preserves task-list order, Java priority arbitration, mutex compatibility,
 * continuous-task blocking, start/reset ordering and per-tick updates.
 */
#include "clonemc_java_port_20_entity.h"
#include <string.h>

void CloneMCJ_EntityAITasks_Initialize(CloneMCJ_EntityAITasksNative *tasks)
{
    if(tasks)memset(tasks,0,sizeof(*tasks));
}

int CloneMCJ_EntityAITasks_AddTask(CloneMCJ_EntityAITasksNative *tasks,
    int priority,const CloneMCJ_EntityAIBaseNative *action)
{
    CloneMCJ_EntityAITaskEntryNative *entry;
    if(!tasks||!action||!action->shouldExecute||
       tasks->count>=CLONEMC_J_MAX_AI_TASKS)return 0;
    entry=&tasks->entries[tasks->count++];
    memset(entry,0,sizeof(*entry));
    entry->priority=priority;
    entry->action=*action;
    return 1;
}

static int CloneMCJ_EntityAITasks_Compatible(
    const CloneMCJ_EntityAITaskEntryNative *first,
    const CloneMCJ_EntityAITaskEntryNative *second)
{
    return (first->action.mutexBits&second->action.mutexBits)==0;
}

static int CloneMCJ_EntityAITasks_CanUse(
    const CloneMCJ_EntityAITasksNative *tasks,int candidateIndex)
{
    const CloneMCJ_EntityAITaskEntryNative *candidate;
    const CloneMCJ_EntityAITaskEntryNative *other;
    int index;
    candidate=&tasks->entries[candidateIndex];
    for(index=0;index<tasks->count;++index){
        if(index==candidateIndex)continue;
        other=&tasks->entries[index];
        if(candidate->priority<other->priority){
            if(other->executing&&
               !CloneMCJ_EntityAITasks_Compatible(candidate,other))return 0;
        }else if(other->executing&&other->action.continuous)return 0;
    }
    return 1;
}

void CloneMCJ_EntityAITasks_Update(CloneMCJ_EntityAITasksNative *tasks)
{
    CloneMCJ_EntityAITaskEntryNative *entry;
    int started[CLONEMC_J_MAX_AI_TASKS];
    int startedCount,index,canContinue;
    if(!tasks)return;
    startedCount=0;
    for(index=0;index<tasks->count;++index){
        entry=&tasks->entries[index];
        if(entry->executing){
            canContinue=CloneMCJ_EntityAITasks_CanUse(tasks,index);
            if(canContinue){
                if(entry->action.continueExecuting)
                    canContinue=entry->action.continueExecuting(
                        entry->action.userData);
                else canContinue=entry->action.shouldExecute(
                    entry->action.userData);
            }
            if(canContinue)continue;
            if(entry->action.resetTask)
                entry->action.resetTask(entry->action.userData);
            entry->executing=0;
        }
        if(CloneMCJ_EntityAITasks_CanUse(tasks,index)&&
           entry->action.shouldExecute(entry->action.userData)){
            entry->executing=1;
            started[startedCount++]=index;
        }
    }
    for(index=0;index<startedCount;++index){
        entry=&tasks->entries[started[index]];
        if(entry->action.startTask)
            entry->action.startTask(entry->action.userData);
    }
    for(index=0;index<tasks->count;++index){
        entry=&tasks->entries[index];
        if(entry->executing&&entry->action.updateTask)
            entry->action.updateTask(entry->action.userData);
    }
}

typedef struct CloneMCJ_AITestStateTag {
    int enabled,started,reset,updated;
} CloneMCJ_AITestState;

static int CloneMCJ_AITest_Should(void *data)
{
    return ((CloneMCJ_AITestState *)data)->enabled;
}
static void CloneMCJ_AITest_Start(void *data)
{
    ++((CloneMCJ_AITestState *)data)->started;
}
static void CloneMCJ_AITest_Reset(void *data)
{
    ++((CloneMCJ_AITestState *)data)->reset;
}
static void CloneMCJ_AITest_Update(void *data)
{
    ++((CloneMCJ_AITestState *)data)->updated;
}

int CloneMCJ_EntityAITasks_RunSelfTests(char *message,unsigned int capacity)
{
    CloneMCJ_EntityAITasksNative tasks;
    CloneMCJ_EntityAIBaseNative action;
    CloneMCJ_AITestState high,low;
    int ok;
    memset(&high,0,sizeof(high));memset(&low,0,sizeof(low));
    memset(&action,0,sizeof(action));
    CloneMCJ_EntityAITasks_Initialize(&tasks);
    high.enabled=1;low.enabled=1;
    action.shouldExecute=CloneMCJ_AITest_Should;
    action.startTask=CloneMCJ_AITest_Start;
    action.resetTask=CloneMCJ_AITest_Reset;
    action.updateTask=CloneMCJ_AITest_Update;
    action.mutexBits=1;action.continuous=1;action.userData=&high;
    CloneMCJ_EntityAITasks_AddTask(&tasks,1,&action);
    action.userData=&low;
    CloneMCJ_EntityAITasks_AddTask(&tasks,2,&action);
    CloneMCJ_EntityAITasks_Update(&tasks);
    CloneMCJ_EntityAITasks_Update(&tasks);
    high.enabled=0;
    CloneMCJ_EntityAITasks_Update(&tasks);
    ok=high.started==1&&high.updated==2&&high.reset==1&&
       low.started==1&&low.updated==1;
    if(message&&capacity){
        const char *text;
        text=ok?"EntityAITasks priority/mutex scheduler passed":
            "EntityAITasks scheduler failed";
        strncpy(message,text,capacity-1U);message[capacity-1U]='\0';
    }
    return ok;
}
