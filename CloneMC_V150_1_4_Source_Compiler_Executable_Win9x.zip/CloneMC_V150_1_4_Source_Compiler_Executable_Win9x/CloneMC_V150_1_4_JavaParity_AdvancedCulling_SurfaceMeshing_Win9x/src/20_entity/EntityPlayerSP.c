/*
 * CloneMC Java port scaffold: EntityPlayerSP
 *
 * Java source: EntityPlayerSP.java
 * Java type: class EntityPlayerSP
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityPlayer
 * Implements: (none declared)
 * Source SHA-256: 5278272540cfbd23155b4dcef4d74e637b0e45158c0f5c6f307d703d51023bc1
 * Java lines: 306
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 25
 * Referenced Java classes: EntityPlayer, MouseFilter, Session, MovementInput, AchievementList, StatFileWriter, GuiAchievement, World, SoundManager, AxisAlignedBB, NBTTagCompound, GuiEditSign, GuiChest, GuiCrafting, GuiFurnace, GuiDispenser, EntityPickupFX, EffectRenderer, InventoryPlayer, GuiIngame, StatBase, Achievement, MathHelper, TileEntitySign, IInventory, TileEntityFurnace, TileEntityDispenser, Entity, d1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public MovementInput movementInput
 * - protected Minecraft mc
 * - private MouseFilter field_21903_bJ
 * - private MouseFilter field_21904_bK
 * - private MouseFilter field_21902_bL
 *
 * Java method/constructor inventory:
 * - public EntityPlayerSP(Minecraft minecraft, World world, Session session, int i)
 * - public void moveEntity(double d, double d1, double d2)
 * - public void updatePlayerActionState()
 * - public void onLivingUpdate()
 * - public void resetPlayerKeyState()
 * - public void handleKeyPress(int i, boolean flag)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void closeScreen()
 * - public void displayGUIEditSign(TileEntitySign tileentitysign)
 * - public void displayGUIChest(IInventory iinventory)
 * - public void displayWorkbenchGUI(int i, int j, int k)
 * - public void displayGUIFurnace(TileEntityFurnace tileentityfurnace)
 * - public void displayGUIDispenser(TileEntityDispenser tileentitydispenser)
 * - public void onItemPickup(Entity entity, int i)
 * - public int getPlayerArmorValue()
 * - public void sendChatMessage(String s)
 * - public boolean isSneaking()
 * - public void setHealth(int i)
 * - public void respawnPlayer()
 * - public void func_6420_o()
 * - public void addChatMessage(String s)
 * - public void addStat(StatBase statbase, int i)
 * - private boolean isBlockTranslucent(int i, int j, int k)
 * - protected boolean pushOutOfBlocks(double d, double d1, double d2)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>
#include <string.h>

static int CloneMCJ_Gameplay_SynchronizeChunkEntities(CloneMCJ_GameplayState *,int);
static int CloneMCJ_Gameplay_AddEntityToLoadedChunk(CloneMCJ_World *,void *,
    CloneMCJ_Entity *);
static void CloneMCJ_Gameplay_UpdateDroppedItemChunk(CloneMCJ_GameplayState *,
    CloneMCJ_EntityItem *);
static int CloneMCJ_Gameplay_EntityChunkLoaded(
    CloneMCJ_GameplayState *,const CloneMCJ_Entity *);

static int CloneMCJ_Gameplay_WriteEntityHook(void *entity, CloneMCJ_NBTTagCompound *compound, void *userData)
{
    CloneMCJ_GameplayState *state;
    int i;
    state=(CloneMCJ_GameplayState *)userData;if(!state||!entity||!compound)return 0;
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(entity==&state->droppedItems[i])
        return CloneMCJ_EntityItem_WriteNBT(&state->droppedItems[i],compound);
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(entity==&state->mobs[i])
        return CloneMCJ_Mob_WriteNBT(&state->mobs[i],compound);
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(entity==&state->projectiles[i]&&
        state->projectiles[i].type!=CLONEMC_J_PROJECTILE_FISHING&&
        state->projectiles[i].type!=CLONEMC_J_PROJECTILE_ENDER_EYE)
        return CloneMCJ_Projectile_WriteNBT(&state->projectiles[i],compound);
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(entity==&state->vehicles[i])
        return CloneMCJ_Vehicle_WriteNBT(&state->vehicles[i],compound);
    return 0;
}

static void *CloneMCJ_Gameplay_ReadEntityHook(const CloneMCJ_NBTTagCompound *compound, void *userData)
{
    CloneMCJ_GameplayState *state;
    const char *id;
    int i,entityID;
    CloneMCJ_MobType mobType;
    state = (CloneMCJ_GameplayState *)userData;
    if (!state || !compound) return (void *)0;
    id = CloneMCJ_NBTTagCompound_GetString(compound, "id");
    if(!id)return (void *)0;
    entityID=CloneMCJ_NBTTagCompound_GetInteger(compound,"EntityId");
    if(entityID>0){
        for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)
            if(state->droppedItems[i].active&&
               state->droppedItems[i].entity.entityId==entityID){
                CloneMCJ_Entity *entity;
                entity=&state->droppedItems[i].entity;
                entity->chunkCoordX=CloneMCJava_FloorDouble(entity->posX/16.0);
                entity->chunkCoordY=CloneMCJava_FloorDouble(entity->posY/16.0);
                if(entity->chunkCoordY<0)entity->chunkCoordY=0;
                if(entity->chunkCoordY>=CLONEMC_J_CHUNK_ENTITY_SLICES)
                    entity->chunkCoordY=CLONEMC_J_CHUNK_ENTITY_SLICES-1;
                entity->chunkCoordZ=CloneMCJava_FloorDouble(entity->posZ/16.0);
                /* ChunkLoader adds this returned pointer immediately after
                 * the hook. Marking membership now prevents a second copy on
                 * the first resumed item tick. */
                entity->addedToChunk=1;
                return &state->droppedItems[i];
            }
        for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&state->mobs[i].entity.entityId==entityID)return &state->mobs[i];
        for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(state->projectiles[i].active&&state->projectiles[i].entity.entityId==entityID)return &state->projectiles[i];
        for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(state->vehicles[i].active&&state->vehicles[i].entity.entityId==entityID)return &state->vehicles[i];
    }
    if(!strcmp(id,"Item"))for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(!state->droppedItems[i].active){
        if(CloneMCJ_EntityItem_ReadNBT(&state->droppedItems[i],compound,state->world)){if(i>=state->droppedItemCount)state->droppedItemCount=i+1;return &state->droppedItems[i];}return (void *)0;}
    if(CloneMCJ_EntityList_MobTypeForName(id,&mobType))for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(!state->mobs[i].active){
        if(CloneMCJ_Mob_ReadNBT(&state->mobs[i],compound,state->world)){if(i>=state->mobCount)state->mobCount=i+1;return &state->mobs[i];}return (void *)0;}
    if(!strcmp(id,"Arrow")||!strcmp(id,"Snowball")||!strcmp(id,"Egg")||!strcmp(id,"Fireball"))
        for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(!state->projectiles[i].active){if(CloneMCJ_Projectile_ReadNBT(&state->projectiles[i],compound,state->world)){if(i>=state->projectileCount)state->projectileCount=i+1;return &state->projectiles[i];}return (void *)0;}
    if(!strcmp(id,"Boat")||!strcmp(id,"Minecart")||!strcmp(id,"PrimedTnt")||!strcmp(id,"FallingSand")||!strcmp(id,"Painting"))
        for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(!state->vehicles[i].active){if(CloneMCJ_Vehicle_ReadNBT(&state->vehicles[i],compound,state->world)){if(i>=state->vehicleCount)state->vehicleCount=i+1;return &state->vehicles[i];}return (void *)0;}
    return (void *)0;
}

static double CloneMCJ_Gameplay_GetEntityYHook(void *entity, void *userData)
{
    (void)userData;
    return entity ? ((CloneMCJ_Entity *)entity)->posY : 0.0;
}

static int CloneMCJ_Gameplay_WriteTileHook(void *tile, CloneMCJ_NBTTagCompound *compound, void *userData)
{
    (void)userData;
    return CloneMCJ_TileEntity_WriteNBT((CloneMCJ_TileEntity *)tile, compound);
}

static void *CloneMCJ_Gameplay_ReadTileHook(const CloneMCJ_NBTTagCompound *compound, void *userData)
{
    CloneMCJ_GameplayState *state;
    state = (CloneMCJ_GameplayState *)userData;
    return state ? CloneMCJ_TileEntity_ReadNBT(compound, state->world) : (void *)0;
}

void CloneMCJ_Gameplay_QueueBlockBreakEvent(CloneMCJ_GameplayState *state,int blockID,int metadata,int x,int y,int z)
{
    unsigned long sequence;CloneMCJ_BlockBreakEvent *event;
    if(!state||blockID<=0)return;
    sequence=++state->blockBreakEventSequence;
    event=&state->blockBreakEvents[(sequence-1UL)%CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY];
    event->sequence=sequence;event->blockID=blockID;event->metadata=metadata;
    event->x=x;event->y=y;event->z=z;
}

int CloneMCJ_Gameplay_GetBlockBreakEvent(const CloneMCJ_GameplayState *state,
    unsigned long sequence,CloneMCJ_BlockBreakEvent *eventOut)
{
    const CloneMCJ_BlockBreakEvent *event;
    if(!state||!eventOut||sequence==0UL||sequence>state->blockBreakEventSequence)return 0;
    event=&state->blockBreakEvents[(sequence-1UL)%CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY];
    if(event->sequence!=sequence)return 0;*eventOut=*event;return 1;
}

void CloneMCJ_Gameplay_QueueAudioEvent(CloneMCJ_GameplayState *state,
    const char *name,float x,float y,float z,float volume,float pitch,int streaming)
{
    unsigned long sequence;
    CloneMCJ_GameplayAudioEvent *event;
    if(!state)return;
    sequence=++state->audioEventSequence;
    event=&state->audioEvents[(sequence-1UL)%CLONEMC_J_GAMEPLAY_AUDIO_EVENT_CAPACITY];
    memset(event,0,sizeof(*event));
    event->sequence=sequence;
    if(name){strncpy(event->name,name,sizeof(event->name)-1U);
        event->name[sizeof(event->name)-1U]='\0';}
    event->x=x;event->y=y;event->z=z;
    event->volume=volume;event->pitch=pitch;
    event->streaming=(unsigned char)(streaming?1:0);
}

int CloneMCJ_Gameplay_GetAudioEvent(const CloneMCJ_GameplayState *state,
    unsigned long sequence,CloneMCJ_GameplayAudioEvent *eventOut)
{
    const CloneMCJ_GameplayAudioEvent *event;
    if(!state||!eventOut||sequence==0UL||sequence>state->audioEventSequence)return 0;
    event=&state->audioEvents[(sequence-1UL)%CLONEMC_J_GAMEPLAY_AUDIO_EVENT_CAPACITY];
    if(event->sequence!=sequence)return 0;
    *eventOut=*event;
    return 1;
}

void CloneMCJ_Gameplay_Initialize(CloneMCJ_GameplayState *state, CloneMCJ_World *world, const char *username)
{
    CloneMCJ_McRegionChunkLoader *loader;
    CloneMCJ_Chunk *chunk;
    int slot;
    if (!state) return;
    memset(state, 0, sizeof(*state));
    state->world = world;
    state->difficulty=2;
    state->openMerchantMobIndex=-1;
    CloneMCJ_BlockRegistry_Initialize();
    CloneMCJ_ItemRegistry_Initialize();
    CloneMCJ_CraftingManager_InitializeNative();
    CloneMCJ_Container_Initialize(&state->openContainer);
    CloneMCJ_InventoryCrafting_Initialize(&state->openCraftMatrix, 2, 2);
    CloneMCJ_InventoryCraftResult_Initialize(&state->openCraftResult);
    CloneMCJ_EntityPlayer_Initialize(&state->player, world, username);
    state->nextEntityId=state->player.entity.entityId+1;
    if (world && world->worldInfo.playerTag)
        CloneMCJ_EntityPlayer_ReadNBT(&state->player, (CloneMCJ_NBTTagCompound *)world->worldInfo.playerTag);
    /* Entity_ReadNBT sets the authoritative current transform.  Synchronize the
     * interpolation endpoints before the first rendered frame and move the
     * chunk streamer from spawn to the saved player location immediately. */
    state->player.entity.prevPosX=state->player.entity.posX;
    state->player.entity.prevPosY=state->player.entity.posY;
    state->player.entity.prevPosZ=state->player.entity.posZ;
    state->player.entity.prevRotationYaw=state->player.entity.rotationYaw;
    state->player.entity.prevRotationPitch=state->player.entity.rotationPitch;
    if(world){
        world->localPlayerEntity=&state->player.entity;
        CloneMCJ_World_SetPlayerGlobalPosition(world,state->player.entity.posX,
            state->player.entity.posZ);
    }
    CloneMCJ_PlayerControllerSP_Initialize(&state->controller, world, &state->player);
    if (world) {
        CloneMCJ_World_SetGameplayHooks(world, CloneMCJ_Gameplay_Tick, CloneMCJ_Gameplay_PrepareSave, state);
        CloneMCJ_World_SetGameplayDimensionHook(world,CloneMCJ_Gameplay_OnDimensionChanged);
        CloneMCJ_BlockButton_RegisterRuntime(world);
    }
    CloneMCJ_Gameplay_AttachSaveHooks(state);
    /* World construction prepares the spawn window before the player runtime is
     * attached.  Re-read only already-loaded saved chunks after installing the
     * entity factory so their Entities list is not silently discarded. */
    loader=world&&world->saveHandler?CloneMCJ_SaveHandler_GetChunkLoader(
        world->saveHandler,world->worldInfo.dimension):(CloneMCJ_McRegionChunkLoader *)0;
    if(loader)for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot)
        if(world->chunkProvider.slots[slot].used&&world->chunkProvider.slots[slot].chunk){
            chunk=world->chunkProvider.slots[slot].chunk;
            CloneMCJ_McRegionChunkLoader_Load(loader,chunk,chunk->xPosition,chunk->zPosition);
        }
}

void CloneMCJ_Gameplay_Destroy(CloneMCJ_GameplayState *state)
{
    CloneMCJ_ChunkSerializationHooks hooks;
    CloneMCJ_McRegionChunkLoader *loader;
    if (!state) return;
    if (state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    if (state->world) {
        if(state->world->localPlayerEntity==&state->player.entity)
            state->world->localPlayerEntity=(struct CloneMCJ_EntityTag *)0;
        CloneMCJ_World_SetGameplayHooks(state->world, (CloneMCJ_GameplayTickProc)0,
            (CloneMCJ_GameplayPrepareSaveProc)0, (void *)0);
        CloneMCJ_World_SetGameplayDimensionHook(state->world,(CloneMCJ_GameplayDimensionProc)0);
        if (state->world->saveHandler) {
            loader = CloneMCJ_SaveHandler_GetChunkLoader(state->world->saveHandler,
                state->world->worldInfo.dimension);
            if (loader) {
                memset(&hooks, 0, sizeof(hooks));
                CloneMCJ_McRegionChunkLoader_SetHooks(loader, &hooks);
            }
        }
    }
    memset(state, 0, sizeof(*state));
}

void CloneMCJ_Gameplay_SetInput(CloneMCJ_GameplayState *state, float strafe, float forward,
                                int jump, int sneak, int attack, int use)
{
    if (!state) return;
    CloneMCJ_EntityPlayer_SetInput(&state->player, strafe, forward, jump, sneak);
    state->attackInput = (unsigned char)(attack != 0);
    state->useInput = (unsigned char)(use != 0);
}

void CloneMCJ_Gameplay_AddLook(CloneMCJ_GameplayState *state, float yawDelta, float pitchDelta)
{
    float yaw, pitch;
    if (!state) return;
    yaw = state->player.entity.rotationYaw + yawDelta;
    pitch = state->player.entity.rotationPitch + pitchDelta;
    CloneMCJ_Entity_SetRotation(&state->player.entity, yaw, pitch);
}

static CloneMCJ_EntityItem *CloneMCJ_Gameplay_InstallDrop(
    CloneMCJ_GameplayState *state, const CloneMCJ_EntityItem *prepared)
{
    CloneMCJ_EntityItem *drop;
    int i;
    if(!state||!prepared)return (CloneMCJ_EntityItem *)0;
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)
        if(!state->droppedItems[i].active)break;
    if(i<CLONEMC_J_MAX_DROPPED_ITEMS){
        drop=&state->droppedItems[i];
        *drop=*prepared;
        if(i>=state->droppedItemCount)state->droppedItemCount=i+1;
        if(state->world&&CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,
                drop,&drop->entity)){
            CloneMCJ_Chunk *chunk;
            chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(state->world,
                drop->entity.chunkCoordX,drop->entity.chunkCoordZ);
            if(chunk)CloneMCJ_Chunk_SetModified(chunk);
        }
        return drop;
    }
    for(i=0;i<CLONEMC_J_MAX_PENDING_DROPS;++i)
        if(!state->pendingDrops[i].active)break;
    if(i>=CLONEMC_J_MAX_PENDING_DROPS){
        ++state->rejectedDropCount;
        return (CloneMCJ_EntityItem *)0;
    }
    state->pendingDrops[i].itemEntity=*prepared;
    state->pendingDrops[i].itemEntity.entity.addedToChunk=0;
    state->pendingDrops[i].active=1;
    if(i>=state->pendingDropCount)state->pendingDropCount=i+1;
    ++state->queuedDropCount;
    return &state->pendingDrops[i].itemEntity;
}

CloneMCJ_EntityItem *CloneMCJ_Gameplay_SpawnDropEntity(
    CloneMCJ_GameplayState *state,double x,double y,double z,
    const CloneMCJ_ItemStack *stack,int pickupDelay,int directed)
{
    CloneMCJ_EntityItem prepared;
    float yaw,pitch;
    double speed;
    if(!state||CloneMCJ_ItemStack_IsEmpty(stack))
        return (CloneMCJ_EntityItem *)0;
    memset(&prepared,0,sizeof(prepared));
    CloneMCJ_EntityItem_Initialize(&prepared,state->world,x,y,z,stack);
    prepared.delayBeforeCanPickup=pickupDelay;
    if(directed){
        yaw=state->player.entity.rotationYaw*3.14159265358979323846F/180.0F;
        pitch=state->player.entity.rotationPitch*3.14159265358979323846F/180.0F;
        speed=0.3;
        prepared.entity.motionX=-(double)sin(yaw)*(double)cos(pitch)*speed;
        prepared.entity.motionZ=(double)cos(yaw)*(double)cos(pitch)*speed;
        prepared.entity.motionY=-(double)sin(pitch)*speed+0.1;
        prepared.entity.motionX+=(CloneMCJavaRandom_NextFloat(
            &state->player.entity.rand)-0.5F)*0.02;
        prepared.entity.motionY+=(CloneMCJavaRandom_NextFloat(
            &state->player.entity.rand)-0.5F)*0.02;
        prepared.entity.motionZ+=(CloneMCJavaRandom_NextFloat(
            &state->player.entity.rand)-0.5F)*0.02;
    }
    return CloneMCJ_Gameplay_InstallDrop(state,&prepared);
}

int CloneMCJ_Gameplay_SpawnDrop(CloneMCJ_GameplayState *state,double x,double y,
    double z,const CloneMCJ_ItemStack *stack,int pickupDelay,int directed)
{
    return CloneMCJ_Gameplay_SpawnDropEntity(state,x,y,z,stack,pickupDelay,
        directed)!=(CloneMCJ_EntityItem *)0;
}

int CloneMCJ_Gameplay_GetDropQueueCapacity(const CloneMCJ_GameplayState *state)
{
    int i;
    int capacity;
    if(!state)return 0;
    capacity=0;
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)
        if(!state->droppedItems[i].active)++capacity;
    for(i=0;i<CLONEMC_J_MAX_PENDING_DROPS;++i)
        if(!state->pendingDrops[i].active)++capacity;
    return capacity;
}

void CloneMCJ_Gameplay_FlushPendingDrops(CloneMCJ_GameplayState *state)
{
    int pending;
    int slot;
    if(!state)return;
    for(pending=0;pending<state->pendingDropCount;++pending){
        if(!state->pendingDrops[pending].active)continue;
        for(slot=0;slot<CLONEMC_J_MAX_DROPPED_ITEMS;++slot)
            if(!state->droppedItems[slot].active)break;
        if(slot>=CLONEMC_J_MAX_DROPPED_ITEMS)return;
        state->droppedItems[slot]=state->pendingDrops[pending].itemEntity;
        state->pendingDrops[pending].active=0;
        if(slot>=state->droppedItemCount)state->droppedItemCount=slot+1;
        if(state->world&&CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,
                &state->droppedItems[slot],&state->droppedItems[slot].entity)){
            CloneMCJ_Chunk *chunk;
            chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(state->world,
                state->droppedItems[slot].entity.chunkCoordX,
                state->droppedItems[slot].entity.chunkCoordZ);
            if(chunk)CloneMCJ_Chunk_SetModified(chunk);
        }
    }
    while(state->pendingDropCount>0&&
          !state->pendingDrops[state->pendingDropCount-1].active)
        --state->pendingDropCount;
}

static int CloneMCJ_Gameplay_SpawnDeathDrop(CloneMCJ_GameplayState *state,
    const CloneMCJ_ItemStack *stack)
{
    CloneMCJ_EntityItem *drop;
    double speed,angle;
    if(!state||CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    drop=CloneMCJ_Gameplay_SpawnDropEntity(state,state->player.entity.posX,
        state->player.entity.posY+0.5,state->player.entity.posZ,stack,40,0);
    if(!drop)return 0;
    /* EntityPlayer.dropPlayerItemWithRandomChoice(stack, true): death loot is
     * scattered around the body instead of fired along the player's look ray. */
    speed=(double)CloneMCJavaRandom_NextFloat(&state->player.entity.rand)*0.5;
    angle=(double)CloneMCJavaRandom_NextFloat(&state->player.entity.rand)*
        6.28318530717958647692;
    drop->entity.motionX=-sin(angle)*speed;
    drop->entity.motionZ=cos(angle)*speed;
    drop->entity.motionY=0.2;
    return 1;
}

int CloneMCJ_Gameplay_DropCurrentItem(CloneMCJ_GameplayState *state, int wholeStack)
{
    CloneMCJ_ItemStack *current;
    CloneMCJ_ItemStack dropped;
    if (!state) return 0;
    if(state->world&&state->world->multiplayerWorld&&state->sendDigIntent)
        return state->sendDigIntent(state->multiplayerController,4,0,0,0,0);
    current = CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if (CloneMCJ_ItemStack_IsEmpty(current)) return 0;
    dropped = CloneMCJ_ItemStack_Split(current, wholeStack ? current->stackSize : 1);
    if (!CloneMCJ_Gameplay_SpawnDrop(state, state->player.entity.posX,
        state->player.entity.posY + 1.32, state->player.entity.posZ, &dropped, 40, 1)) {
        CloneMCJ_InventoryPlayer_AddItemStack(&state->player.inventory, &dropped);
        return 0;
    }
    return 1;
}

void CloneMCJ_Gameplay_HandlePlayerDeath(CloneMCJ_GameplayState *state)
{
    CloneMCJ_InventoryPlayer *inventory;
    CloneMCJ_ItemStack dropped;
    int i;
    int experienceDrop;
    if(!state||!state->world||state->world->multiplayerWorld||state->deathHandled)return;
    inventory=&state->player.inventory;
    /* EntityPlayer.onDeath -> InventoryPlayer.dropAllItems.  Each complete
     * stack becomes a world entity and the inventory slot is cleared only
     * after the drop was accepted. */
    for(i=0;i<CLONEMC_J_MAIN_INVENTORY_SIZE;++i)
        if(!CloneMCJ_ItemStack_IsEmpty(&inventory->mainInventory[i])){
            dropped=inventory->mainInventory[i];
            if(CloneMCJ_Gameplay_SpawnDeathDrop(state,&dropped))
                CloneMCJ_ItemStack_Clear(&inventory->mainInventory[i]);
        }
    for(i=0;i<CLONEMC_J_ARMOR_INVENTORY_SIZE;++i)
        if(!CloneMCJ_ItemStack_IsEmpty(&inventory->armorInventory[i])){
            dropped=inventory->armorInventory[i];
            if(CloneMCJ_Gameplay_SpawnDeathDrop(state,&dropped))
                CloneMCJ_ItemStack_Clear(&inventory->armorInventory[i]);
        }
    if(!CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)){
        dropped=inventory->carriedStack;
        if(CloneMCJ_Gameplay_SpawnDeathDrop(state,&dropped))
            CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
    }
    /* EntityPlayer.getExperiencePoints: seven points per level, capped at
     * 100.  Respawn reconstructs the player with zero XP; these bounded orbs
     * remain in the death chunk for recovery. */
    experienceDrop=state->player.experienceLevel*7;
    if(experienceDrop>100)experienceDrop=100;
    if(experienceDrop>0)
        CloneMCJ_Progression_SpawnExperience(state,
            state->player.entity.posX,state->player.entity.posY+0.5,
            state->player.entity.posZ,experienceDrop);
    /* Attach new item entities to their chunks immediately.  This makes the
     * chunk dirty before respawn/recentering or an emergency save can evict it,
     * so the five-minute Java item lifetime is preserved across respawn/save. */
    (void)CloneMCJ_Gameplay_SynchronizeChunkEntities(state,1);
    state->player.ridingEntityId=0;
    state->player.entity.entityRiderYawDelta=0.0;
    state->player.entity.entityRiderPitchDelta=0.0;
    state->player.entity.motionX=0.0;state->player.entity.motionY=0.1;
    state->player.entity.motionZ=0.0;state->deathHandled=1;
}

void CloneMCJ_Gameplay_RespawnPlayer(CloneMCJ_GameplayState *state)
{
    char username[64];
    int score,gameMode,bedSpawnX,bedSpawnY,bedSpawnZ,hasBedSpawn,surfaceReady;
    int safeX,safeY,safeZ,worldSpawnY;
    unsigned long picked,mined,placed,activated;
    int minedID,minedMeta,minedX,minedY,minedZ;
    int placedID,placedMeta,placedX,placedY,placedZ;
    int activatedID,activatedMeta,activatedX,activatedY,activatedZ;
    if(!state||!state->world)return;
    strncpy(username,state->player.username,sizeof(username)-1);
    username[sizeof(username)-1]='\0';score=state->player.score;
    gameMode=state->player.gameMode;
    bedSpawnX=state->player.spawnX;bedSpawnY=state->player.spawnY;
    bedSpawnZ=state->player.spawnZ;hasBedSpawn=state->player.hasBedSpawn;
    picked=state->player.itemsPickedUp;mined=state->player.blocksMined;
    placed=state->player.blocksPlaced;activated=state->player.blocksActivated;
    minedID=state->player.lastMinedBlockID;minedMeta=state->player.lastMinedMetadata;
    minedX=state->player.lastMinedX;minedY=state->player.lastMinedY;minedZ=state->player.lastMinedZ;
    placedID=state->player.lastPlacedBlockID;placedMeta=state->player.lastPlacedMetadata;
    placedX=state->player.lastPlacedX;placedY=state->player.lastPlacedY;placedZ=state->player.lastPlacedZ;
    activatedID=state->player.lastActivatedBlockID;activatedMeta=state->player.lastActivatedMetadata;
    activatedX=state->player.lastActivatedX;activatedY=state->player.lastActivatedY;activatedZ=state->player.lastActivatedZ;
    /* EntityPlayerSP.respawn(false, 0): local deaths always reconstruct the
     * player in the surface dimension.  This prevents Nether roof/floor
     * coordinates from being reused as an Overworld spawn. */
    surfaceReady=state->world->worldInfo.dimension==0;
    if(!surfaceReady)surfaceReady=CloneMCJ_World_SetDimension(state->world,0,0);
    CloneMCJ_EntityPlayer_Initialize(&state->player,state->world,username);
    state->player.gameMode=gameMode;
    state->player.allowFlying=(unsigned char)(gameMode!=CLONEMC_J_GAMEMODE_SURVIVAL);
    state->player.flying=(unsigned char)(gameMode==CLONEMC_J_GAMEMODE_SPECTATOR);
    state->player.invulnerable=state->player.allowFlying;
    state->player.dimension=state->world->worldInfo.dimension;
    if(hasBedSpawn&&surfaceReady&&state->world->worldInfo.dimension==0){
        state->player.spawnX=bedSpawnX;state->player.spawnY=bedSpawnY;
        state->player.spawnZ=bedSpawnZ;state->player.hasBedSpawn=1;
        CloneMCJ_World_SetPlayerGlobalPosition(state->world,
            (double)bedSpawnX+0.5,(double)bedSpawnZ+0.5);
        /* The bed can sit on a chunk edge.  Read both edge neighbors before
         * testing the Java 3x3 escape squares. */
        (void)CloneMCJ_World_GetChunkFromBlockCoords(state->world,
            bedSpawnX-1,bedSpawnZ-1);
        (void)CloneMCJ_World_GetChunkFromBlockCoords(state->world,
            bedSpawnX+1,bedSpawnZ+1);
        if(CloneMCJ_EntityPlayer_FindSafeBedSpawn(state->world,bedSpawnX,
            bedSpawnY,bedSpawnZ,&safeX,&safeY,&safeZ))
            CloneMCJ_Entity_SetPosition(&state->player.entity,
                (double)safeX+0.5,(double)safeY,(double)safeZ+0.5);
        else state->player.hasBedSpawn=0;
    }
    if(!state->player.hasBedSpawn){
        safeX=state->world->worldInfo.spawnX;
        safeZ=state->world->worldInfo.spawnZ;
        CloneMCJ_World_SetPlayerGlobalPosition(state->world,
            (double)safeX+0.5,(double)safeZ+0.5);
        worldSpawnY=CloneMCJ_World_FindTopSolidBlock(state->world,safeX,safeZ)+1;
        if(worldSpawnY<1||worldSpawnY>125)worldSpawnY=65;
        while(worldSpawnY<126&&
             (CloneMCJ_World_GetBlockId(state->world,safeX,worldSpawnY,safeZ)!=0||
              CloneMCJ_World_GetBlockId(state->world,safeX,worldSpawnY+1,safeZ)!=0))
            ++worldSpawnY;
        CloneMCJ_Entity_SetPosition(&state->player.entity,(double)safeX+0.5,
            (double)worldSpawnY,(double)safeZ+0.5);
        state->player.spawnX=safeX;state->player.spawnY=worldSpawnY;
        state->player.spawnZ=safeZ;
    }
    state->player.score=score;state->player.itemsPickedUp=picked;
    state->player.blocksMined=mined;state->player.blocksPlaced=placed;
    state->player.blocksActivated=activated;
    state->player.lastMinedBlockID=minedID;state->player.lastMinedMetadata=minedMeta;
    state->player.lastMinedX=minedX;state->player.lastMinedY=minedY;state->player.lastMinedZ=minedZ;
    state->player.lastPlacedBlockID=placedID;state->player.lastPlacedMetadata=placedMeta;
    state->player.lastPlacedX=placedX;state->player.lastPlacedY=placedY;state->player.lastPlacedZ=placedZ;
    state->player.lastActivatedBlockID=activatedID;state->player.lastActivatedMetadata=activatedMeta;
    state->player.lastActivatedX=activatedX;state->player.lastActivatedY=activatedY;state->player.lastActivatedZ=activatedZ;
    CloneMCJ_PlayerControllerSP_Initialize(&state->controller,state->world,&state->player);
    if(state->player.entity.entityId>=state->nextEntityId)
        state->nextEntityId=state->player.entity.entityId+1;
    state->attackInput=state->useInput=state->previousAttack=state->previousUse=0;
    state->intentDigging=0;state->deathHandled=0;
    CloneMCJ_World_SetPlayerGlobalPosition(state->world,state->player.entity.posX,
        state->player.entity.posZ);
}

static int CloneMCJ_Gameplay_BlockRayBox(double ox,double oy,double oz,
    double dx,double dy,double dz,const CloneMCAxisAlignedBB *box,
    double limit,double *hitDistance,int *hitSide)
{
    double minimum,maximum,t1,t2,inverse;
    int axis,nearSide,farSide,entrySide;
    double origins[3],directions[3],mins[3],maxs[3];
    origins[0]=ox;origins[1]=oy;origins[2]=oz;
    directions[0]=dx;directions[1]=dy;directions[2]=dz;
    mins[0]=box->minX;mins[1]=box->minY;mins[2]=box->minZ;
    maxs[0]=box->maxX;maxs[1]=box->maxY;maxs[2]=box->maxZ;
    minimum=0.0;maximum=limit;entrySide=-1;
    for(axis=0;axis<3;++axis){
        if(directions[axis]>-0.0000001&&directions[axis]<0.0000001){
            if(origins[axis]<mins[axis]||origins[axis]>maxs[axis])return 0;
        }else{
            inverse=1.0/directions[axis];
            t1=(mins[axis]-origins[axis])*inverse;
            t2=(maxs[axis]-origins[axis])*inverse;
            nearSide=axis==0?4:(axis==1?0:2);
            farSide=axis==0?5:(axis==1?1:3);
            if(t1>t2){
                double swap;
                int swapSide;
                swap=t1;t1=t2;t2=swap;
                swapSide=nearSide;nearSide=farSide;farSide=swapSide;
            }
            if(t1>minimum){minimum=t1;entrySide=nearSide;}
            if(t2<maximum)maximum=t2;
            if(maximum<minimum)return 0;
        }
    }
    if(minimum<0.0||minimum>limit||maximum<0.0)return 0;
    if(hitDistance)*hitDistance=minimum;
    if(hitSide)*hitSide=entrySide;
    return 1;
}

static CloneMCJ_MovingObjectPosition CloneMCJ_Gameplay_RayTraceInternal(
    const CloneMCJ_EntityPlayer *player,double distance,int stopOnSourceLiquid)
{
    CloneMCJ_MovingObjectPosition result;
    CloneMCAxisAlignedBB selection;
    double yaw,pitch,lookX,lookY,lookZ,eyeX,eyeY,eyeZ,hitDistance;
    double endX,endY,endZ,boundary,tMaxX,tMaxY,tMaxZ;
    double tDeltaX,tDeltaY,tDeltaZ;
    int x,y,z,endCellX,endCellY,endCellZ,stepX,stepY,stepZ;
    int blockID,iteration,hitSide;
    memset(&result, 0, sizeof(result));
    result.sideHit = -1;
    if (!player || !player->entity.worldObj || distance <= 0.0) return result;
    yaw = player->entity.rotationYaw * 3.14159265358979323846 / 180.0;
    pitch = player->entity.rotationPitch * 3.14159265358979323846 / 180.0;
    lookX = -sin(yaw) * cos(pitch);
    lookY = -sin(pitch);
    lookZ = cos(yaw) * cos(pitch);
    eyeX = player->entity.posX;
    eyeY = player->entity.posY + 1.62;
    eyeZ = player->entity.posZ;
    endX=eyeX+lookX*distance;
    endY=eyeY+lookY*distance;
    endZ=eyeZ+lookZ*distance;
    x=CloneMCJava_FloorDouble(eyeX);
    y=CloneMCJava_FloorDouble(eyeY);
    z=CloneMCJava_FloorDouble(eyeZ);
    endCellX=CloneMCJava_FloorDouble(endX);
    endCellY=CloneMCJava_FloorDouble(endY);
    endCellZ=CloneMCJava_FloorDouble(endZ);
    stepX=lookX>0.0?1:(lookX<0.0?-1:0);
    stepY=lookY>0.0?1:(lookY<0.0?-1:0);
    stepZ=lookZ>0.0?1:(lookZ<0.0?-1:0);
    if(stepX){boundary=(double)(stepX>0?x+1:x);
        tMaxX=(boundary-eyeX)/lookX;tDeltaX=1.0/fabs(lookX);}
    else tMaxX=tDeltaX=999.0;
    if(stepY){boundary=(double)(stepY>0?y+1:y);
        tMaxY=(boundary-eyeY)/lookY;tDeltaY=1.0/fabs(lookY);}
    else tMaxY=tDeltaY=999.0;
    if(stepZ){boundary=(double)(stepZ>0?z+1:z);
        tMaxZ=(boundary-eyeZ)/lookZ;tDeltaZ=1.0/fabs(lookZ);}
    else tMaxZ=tDeltaZ=999.0;
    /* Direct World.func_28105_a-style cell traversal.  This replaces the
     * former 0.025-block floating-point sampler (up to 201 iterations for a
     * five-block reach) while keeping partial-block selection bounds exact. */
    for(iteration=0;iteration<=200;++iteration){
        blockID = CloneMCJ_World_GetBlockId(player->entity.worldObj, x, y, z);
        /* Block.rayTrace uses selection bounds, not the collision box.
         * Flowers, mushrooms, tall grass, wire, torches and signs deliberately
         * have no collision box but must still be mineable and selectable. */
        if (blockID != 0 &&
            ((blockID!=8&&blockID!=9)||
             (stopOnSourceLiquid&&
              CloneMCJ_World_GetBlockMetadata(player->entity.worldObj,x,y,z)==0)) &&
            blockID != 10 && blockID != 11 && blockID != 51 && blockID != 90) {
            int hasSelection;
            if((blockID==8||blockID==9)&&stopOnSourceLiquid){
                selection.minX=(double)x;selection.minY=(double)y;
                selection.minZ=(double)z;selection.maxX=(double)x+1.0;
                selection.maxY=(double)y+1.0;selection.maxZ=(double)z+1.0;
                hasSelection=1;
            }else hasSelection=CloneMCJ_Block_GetSelectionBox(
                player->entity.worldObj,x,y,z,&selection);
            if(!hasSelection||
               !CloneMCJ_Gameplay_BlockRayBox(eyeX,eyeY,eyeZ,lookX,lookY,lookZ,
                    &selection,distance,&hitDistance,&hitSide)){
                /* The ray crossed this cell but missed its partial bounds. */
            }else{
                result.hit = 1;
                result.blockX = x; result.blockY = y; result.blockZ = z;
                result.sideHit=hitSide;
                result.hitVec.xCoord=eyeX+lookX*hitDistance;
                result.hitVec.yCoord=eyeY+lookY*hitDistance;
                result.hitVec.zCoord=eyeZ+lookZ*hitDistance;
                return result;
            }
        }
        if(x==endCellX&&y==endCellY&&z==endCellZ)break;
        if(tMaxX<tMaxY&&tMaxX<tMaxZ){
            if(tMaxX>distance)break;x+=stepX;tMaxX+=tDeltaX;
        }else if(tMaxY<tMaxZ){
            if(tMaxY>distance)break;y+=stepY;tMaxY+=tDeltaY;
        }else{
            if(tMaxZ>distance)break;z+=stepZ;tMaxZ+=tDeltaZ;
        }
    }
    return result;
}

CloneMCJ_MovingObjectPosition CloneMCJ_Gameplay_RayTrace(
    const CloneMCJ_EntityPlayer *player,double distance)
{
    return CloneMCJ_Gameplay_RayTraceInternal(player,distance,0);
}

static int CloneMCJ_Gameplay_RayBox(double ox,double oy,double oz,double dx,double dy,double dz,
    const CloneMCAxisAlignedBB *box,double limit,double *hitDistance)
{
    double minimum,maximum,t1,t2,inverse;
    int axis;
    double origins[3],directions[3],mins[3],maxs[3];
    origins[0]=ox;origins[1]=oy;origins[2]=oz;
    directions[0]=dx;directions[1]=dy;directions[2]=dz;
    mins[0]=box->minX-0.3;mins[1]=box->minY-0.3;mins[2]=box->minZ-0.3;
    maxs[0]=box->maxX+0.3;maxs[1]=box->maxY+0.3;maxs[2]=box->maxZ+0.3;
    minimum=0.0;maximum=limit;
    for(axis=0;axis<3;++axis){
        if(directions[axis]>-0.0000001&&directions[axis]<0.0000001){
            if(origins[axis]<mins[axis]||origins[axis]>maxs[axis])return 0;
        }else{
            inverse=1.0/directions[axis];
            t1=(mins[axis]-origins[axis])*inverse;t2=(maxs[axis]-origins[axis])*inverse;
            if(t1>t2){double swap;swap=t1;t1=t2;t2=swap;}
            if(t1>minimum)minimum=t1;
            if(t2<maximum)maximum=t2;
            if(maximum<minimum)return 0;
        }
    }
    if(hitDistance)*hitDistance=minimum;
    return minimum<=limit&&maximum>=0.0;
}

int CloneMCJ_Gameplay_FindTargetMob(const CloneMCJ_GameplayState *state,double distance,
    double *hitDistance)
{
    const CloneMCJ_EntityPlayer *player;
    double yaw,pitch,lookX,lookY,lookZ,eyeX,eyeY,eyeZ;
    double nearest,hit;
    CloneMCAxisAlignedBB targetBox;
    int index,best;
    if(hitDistance)*hitDistance=distance;
    if(!state||distance<=0.0)return -1;
    player=&state->player;
    yaw=player->entity.rotationYaw*3.14159265358979323846/180.0;
    pitch=player->entity.rotationPitch*3.14159265358979323846/180.0;
    lookX=-sin(yaw)*cos(pitch);lookY=-sin(pitch);lookZ=cos(yaw)*cos(pitch);
    eyeX=player->entity.posX;eyeY=player->entity.posY+1.62;eyeZ=player->entity.posZ;
    nearest=distance;best=-1;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index){
        if(!state->mobs[index].active||state->mobs[index].health<=0)continue;
        targetBox=CloneMCAABB_Expand(&state->mobs[index].entity.boundingBox,0.1,0.1,0.1);
        if(CloneMCJ_Gameplay_RayBox(eyeX,eyeY,eyeZ,lookX,lookY,lookZ,
            &targetBox,nearest,&hit)){
            nearest=hit;best=index;
        }
    }
    if(hitDistance)*hitDistance=nearest;
    return best;
}

static int CloneMCJ_Gameplay_FindTargetVehicle(const CloneMCJ_GameplayState *state,
    double distance,double *hitDistance)
{
    const CloneMCJ_EntityPlayer *player;double yaw,pitch,lookX,lookY,lookZ,eyeX,eyeY,eyeZ;
    double nearest,hit;CloneMCAxisAlignedBB box;int index,best;
    if(hitDistance)*hitDistance=distance;
    if(!state||distance<=0.0)return -1;
    player=&state->player;
    yaw=player->entity.rotationYaw*3.14159265358979323846/180.0;pitch=player->entity.rotationPitch*3.14159265358979323846/180.0;
    lookX=-sin(yaw)*cos(pitch);lookY=-sin(pitch);lookZ=cos(yaw)*cos(pitch);eyeX=player->entity.posX;eyeY=player->entity.posY+1.62;eyeZ=player->entity.posZ;
    nearest=distance;best=-1;for(index=0;index<CLONEMC_J_MAX_VEHICLES;++index){if(!state->vehicles[index].active||
        state->vehicles[index].type==CLONEMC_J_VEHICLE_LIGHTNING)continue;
        box=CloneMCAABB_Expand(&state->vehicles[index].entity.boundingBox,0.1,0.1,0.1);
        if(CloneMCJ_Gameplay_RayBox(eyeX,eyeY,eyeZ,lookX,lookY,lookZ,&box,nearest,&hit)){nearest=hit;best=index;}}
    if(hitDistance)*hitDistance=nearest;
    return best;
}

static int CloneMCJ_Gameplay_ConsumeItem(CloneMCJ_InventoryPlayer *inventory,int itemID)
{
    int i;if(!inventory)return 0;for(i=0;i<CLONEMC_J_MAIN_INVENTORY_SIZE;++i)
        if(!CloneMCJ_ItemStack_IsEmpty(&inventory->mainInventory[i])&&inventory->mainInventory[i].itemID==itemID){
            if(--inventory->mainInventory[i].stackSize<=0)CloneMCJ_ItemStack_Clear(&inventory->mainInventory[i]);
            inventory->inventoryChanged=1;return 1;}
    return 0;
}

static int CloneMCJ_Gameplay_UseSpawnEgg(CloneMCJ_GameplayState *state,
    CloneMCJ_ItemStack *stack,const CloneMCJ_MovingObjectPosition *target)
{
    const char *name;CloneMCJ_MobType type;int slot,x,y,z,clickedID;
    double vertical;
    if(!state||!stack||!target||!target->hit||stack->itemID!=383)return 0;
    name=CloneMCJ_EntityList_NameForNumericID(stack->itemDamage);
    if(!name||!CloneMCJ_EntityList_MobTypeForName(name,&type)||
       type==CLONEMC_J_MOB_ENDER_DRAGON||
       type==CLONEMC_J_MOB_ENDER_CRYSTAL)return 0;
    for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)
        if(!state->mobs[slot].active)break;
    if(slot>=CLONEMC_J_MAX_MOBS)return 0;
    x=target->blockX;y=target->blockY;z=target->blockZ;
    clickedID=CloneMCJ_World_GetBlockId(state->world,x,y,z);
    if(target->sideHit==0)--y;else if(target->sideHit==1)++y;
    else if(target->sideHit==2)--z;else if(target->sideHit==3)++z;
    else if(target->sideHit==4)--x;else if(target->sideHit==5)++x;
    vertical=(clickedID==85||clickedID==107||clickedID==113)?0.5:0.0;
    CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],type,state->world,
        (double)x+0.5,(double)y+vertical,(double)z+0.5);
    state->mobs[slot].entity.rotationYaw=
        CloneMCJavaRandom_NextFloat(&state->player.entity.rand)*360.0F;
    state->mobs[slot].entity.prevRotationYaw=
        state->mobs[slot].entity.rotationYaw;
    state->mobs[slot].persistenceRequired=1;
    if(state->nextEntityId<=state->mobs[slot].entity.entityId)
        state->nextEntityId=state->mobs[slot].entity.entityId+1;
    if(slot>=state->mobCount)state->mobCount=slot+1;
    if(--stack->stackSize<=0)CloneMCJ_ItemStack_Clear(stack);
    state->player.inventory.inventoryChanged=1;
    return 1;
}

static int CloneMCJ_Gameplay_UseEntityItem(CloneMCJ_GameplayState *state,
    const CloneMCJ_MovingObjectPosition *target)
{
    CloneMCJ_ItemStack *held;CloneMCJ_MovingObjectPosition liquidTarget;
    int x,y,z,id,i,result;
    if(!state)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if(CloneMCJ_ItemStack_IsEmpty(held))return 0;
    id=held->itemID;
    if(id==373)return CloneMCJ_Progression_UsePotion(state,held);
    /* Requested convenience: right-clicking an armor piece equips it into the
     * matching empty SlotArmor destination. The type/slot mapping comes from
     * the uploaded ItemArmor and ContainerPlayer classes. */
    if(CloneMCJ_ItemArmor_EquipRightClickNative(&state->player.inventory,held))
        return 1;
    if(id==325||id==326||id==327){
        if(CloneMCJ_ItemBucket_UseNative(state->world,&state->player,held)){
            state->player.inventory.inventoryChanged=1;return 1;
        }
        return 0;
    }
    if(id==261){if(!CloneMCJ_Gameplay_ConsumeItem(&state->player.inventory,262))return 0;
        CloneMCJ_Gameplay_SpawnProjectile(state,CLONEMC_J_PROJECTILE_ARROW,&state->player.entity,1.5F,1.0F);CloneMCJ_ItemStack_Damage(held,1);return 1;}
    if(id==332||id==344){if(!CloneMCJ_Gameplay_SpawnProjectile(state,id==332?CLONEMC_J_PROJECTILE_SNOWBALL:CLONEMC_J_PROJECTILE_EGG,&state->player.entity,1.5F,1.0F))return 0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        return 1;}
    if(id==368){
        if(!CloneMCJ_Gameplay_SpawnProjectile(state,
            CLONEMC_J_PROJECTILE_ENDER_PEARL,&state->player.entity,
            1.5F,1.0F))return 0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;
    }
    if(id==381&&!target){
        int targetX,targetZ,projectileIndex;double dx,dz,distance;
        CloneMCJ_ChunkProviderGenerate_FindClosestStronghold(
            state->world->randomSeed,state->player.entity.posX,
            state->player.entity.posZ,&targetX,&targetZ);
        if(!CloneMCJ_Gameplay_SpawnProjectile(state,
            CLONEMC_J_PROJECTILE_ENDER_EYE,&state->player.entity,
            0.0F,0.0F))return 0;
        for(projectileIndex=0;projectileIndex<CLONEMC_J_MAX_PROJECTILES;
            ++projectileIndex)
            if(state->projectiles[projectileIndex].active&&
               state->projectiles[projectileIndex].type==
                    CLONEMC_J_PROJECTILE_ENDER_EYE&&
               state->projectiles[projectileIndex].age==0)break;
        if(projectileIndex>=CLONEMC_J_MAX_PROJECTILES)return 0;
        dx=(double)targetX-state->player.entity.posX;
        dz=(double)targetZ-state->player.entity.posZ;
        distance=sqrt(dx*dx+dz*dz);
        if(distance>12.0){
            state->projectiles[projectileIndex].accelerationX=
                state->player.entity.posX+dx/distance*12.0;
            state->projectiles[projectileIndex].accelerationZ=
                state->player.entity.posZ+dz/distance*12.0;
            state->projectiles[projectileIndex].accelerationY=
                state->player.entity.posY+8.0;
        }else{
            state->projectiles[projectileIndex].accelerationX=(double)targetX;
            state->projectiles[projectileIndex].accelerationZ=(double)targetZ;
            state->projectiles[projectileIndex].accelerationY=64.0;
        }
        state->projectiles[projectileIndex].entity.motionX=0.0;
        state->projectiles[projectileIndex].entity.motionY=0.0;
        state->projectiles[projectileIndex].entity.motionZ=0.0;
        state->projectiles[projectileIndex].payloadDamage=
            CloneMCJavaRandom_NextIntBound(&state->player.entity.rand,5)>0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;
    }
    if(id==346){for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(state->projectiles[i].active&&
            state->projectiles[i].type==CLONEMC_J_PROJECTILE_FISHING&&
            state->projectiles[i].ownerEntityId==state->player.entity.entityId)break;
        if(i<CLONEMC_J_MAX_PROJECTILES){result=CloneMCJ_EntityFish_Catch(&state->projectiles[i],state);
            if(result>0)CloneMCJ_ItemStack_Damage(held,result);
            return 1;}
        return CloneMCJ_Gameplay_SpawnProjectile(state,CLONEMC_J_PROJECTILE_FISHING,
            &state->player.entity,1.5F,1.0F);}
    /* ItemGlassBottle calls Item.getMovingObjectPositionFromPlayer(...,true),
     * independently of EntityRenderer's ordinary mouse-over ray.  BlockFluid
     * accepts that ray only for metadata zero, so a source-water cell may be
     * selected even though ordinary mining/placement rays ignore liquids. */
    if(id==374){
        liquidTarget=CloneMCJ_Gameplay_RayTraceInternal(&state->player,5.0,1);
        target=liquidTarget.hit?&liquidTarget:
            (const CloneMCJ_MovingObjectPosition *)0;
    }
    if(!target||!target->hit)return 0;
    x=target->blockX;y=target->blockY;z=target->blockZ;
    if(id==383)return CloneMCJ_Gameplay_UseSpawnEgg(state,held,target);
    if(id==381&&CloneMCJ_World_GetBlockId(state->world,x,y,z)==120){
        int metadata,cx,cz,tryX,tryZ,n,complete;
        metadata=CloneMCJ_World_GetBlockMetadata(state->world,x,y,z);
        if(metadata&4)return 1;
        CloneMCJ_World_SetBlockMetadataNotify(state->world,x,y,z,metadata|4);
        if(state->player.gameMode!=CLONEMC_J_GAMEMODE_CREATIVE){
            --held->stackSize;
            if(held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
            state->player.inventory.inventoryChanged=1;
        }
        /* ItemEnderEye searches for the 12-frame ring.  Testing the compact
         * five-by-five candidate area is bounded and also accepts rings loaded
         * from Java worlds whose directional metadata is already established. */
        complete=0;cx=x;cz=z;
        for(tryX=x-2;tryX<=x+2&&!complete;++tryX)
            for(tryZ=z-2;tryZ<=z+2&&!complete;++tryZ){
                complete=1;
                for(n=-1;n<=1;++n){
                    if(CloneMCJ_World_GetBlockId(state->world,
                        tryX+n,y,tryZ-2)!=120||
                       !(CloneMCJ_World_GetBlockMetadata(state->world,
                        tryX+n,y,tryZ-2)&4)||
                       CloneMCJ_World_GetBlockId(state->world,
                        tryX+n,y,tryZ+2)!=120||
                       !(CloneMCJ_World_GetBlockMetadata(state->world,
                        tryX+n,y,tryZ+2)&4)||
                       CloneMCJ_World_GetBlockId(state->world,
                        tryX-2,y,tryZ+n)!=120||
                       !(CloneMCJ_World_GetBlockMetadata(state->world,
                        tryX-2,y,tryZ+n)&4)||
                       CloneMCJ_World_GetBlockId(state->world,
                        tryX+2,y,tryZ+n)!=120||
                       !(CloneMCJ_World_GetBlockMetadata(state->world,
                        tryX+2,y,tryZ+n)&4)){complete=0;break;}
                }
                if(complete){cx=tryX;cz=tryZ;}
            }
        if(complete)
            for(tryX=cx-1;tryX<=cx+1;++tryX)
                for(tryZ=cz-1;tryZ<=cz+1;++tryZ)
                    CloneMCJ_World_SetBlockNotify(state->world,
                        tryX,y,tryZ,119);
        return 1;
    }
    if(id==295||id==361||id==362){
        if(!CloneMCJ_ItemSeeds_UseNative(state->world,held,x,y,z,target->sideHit))return 0;
        state->player.inventory.inventoryChanged=1;return 1;
    }
    if(id==351){
        if(!CloneMCJ_ItemDye_UseNative(state->world,held,x,y,z,
            target->sideHit))return 0;
        state->player.inventory.inventoryChanged=1;return 1;
    }
    /* The second liquid-aware ray above matches Java BlockFluid.canCollideCheck
     * (source metadata zero).  Filling never consumes the water block. */
    if(id==374&&(CloneMCJ_World_GetBlockId(state->world,x,y,z)==8||
        CloneMCJ_World_GetBlockId(state->world,x,y,z)==9)){
        CloneMCJ_ItemStack waterPotion;
        CloneMCJ_ItemStack_Initialize(&waterPotion,373,1,0);
        --held->stackSize;
        if(held->stackSize<=0)*held=waterPotion;
        else if(!CloneMCJ_InventoryPlayer_AddItemStack(
            &state->player.inventory,&waterPotion)&&
            !CloneMCJ_ItemStack_IsEmpty(&waterPotion))
            CloneMCJ_Gameplay_SpawnDrop(state,state->player.entity.posX,
                state->player.entity.posY+1.0,state->player.entity.posZ,
                &waterPotion,20,0);
        state->player.inventory.inventoryChanged=1;
        return 1;
    }
    if(id==333){if(target->sideHit==0)--y;else if(target->sideHit==1)++y;else if(target->sideHit==2)--z;else if(target->sideHit==3)++z;else if(target->sideHit==4)--x;else if(target->sideHit==5)++x;
        if(!CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_BOAT,(double)x+0.5,(double)y+1.0,(double)z+0.5,0))return 0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;}
    if((id==328||id==342||id==343)&&
       (CloneMCJ_World_GetBlockId(state->world,x,y,z)==66||
        CloneMCJ_World_GetBlockId(state->world,x,y,z)==27||
        CloneMCJ_World_GetBlockId(state->world,x,y,z)==28)){
        int minecartType;minecartType=id==342?1:(id==343?2:0);
        if(!CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_MINECART,
            (double)x+0.5,(double)y+0.5,(double)z+0.5,minecartType))return 0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;}
    if(id==321&&target->sideHit>=2&&target->sideHit<=5){int direction,vehicleSlot;
        direction=target->sideHit==2?0:(target->sideHit==4?1:(target->sideHit==3?2:3));
        if(!CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_PAINTING,(double)x+0.5,(double)y+0.5,(double)z+0.5,0))return 0;
        for(vehicleSlot=0;vehicleSlot<CLONEMC_J_MAX_VEHICLES;++vehicleSlot)if(state->vehicles[vehicleSlot].active&&
            state->vehicles[vehicleSlot].entity.entityId==state->nextEntityId-1)break;
        if(vehicleSlot>=CLONEMC_J_MAX_VEHICLES||!CloneMCJ_Vehicle_ConfigurePainting(
            &state->vehicles[vehicleSlot],direction,x,y,z)){
            if(vehicleSlot<CLONEMC_J_MAX_VEHICLES)state->vehicles[vehicleSlot].active=0;
            return 0;}
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;}
    if(id==259){
        if(CloneMCJ_World_GetBlockId(state->world,x,y,z)==46){CloneMCJ_World_SetBlock(state->world,x,y,z,0);
            CloneMCJ_World_MarkMeshSectionUrgent(state->world,x,y,z);
            CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_PRIMED_TNT,(double)x+0.5,(double)y+0.5,(double)z+0.5,0);
            CloneMCJ_ItemStack_Damage(held,1);return 1;}
        return CloneMCJ_ItemFlintAndSteel_UseNative(state->world,held,
            &state->player,x,y,z,target->sideHit);
    }
    return 0;
}

static void CloneMCJ_Gameplay_SpawnLootStack(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob,int itemId,int count,int metadata)
{
    CloneMCJ_ItemStack stack;
    int index;
    if(!state||!mob||itemId<=0||count<=0)return;
    for(index=0;index<count;++index){
        CloneMCJ_ItemStack_Initialize(&stack,itemId,1,metadata);
        CloneMCJ_Gameplay_SpawnDrop(state,mob->entity.posX,
            mob->entity.posY,mob->entity.posZ,&stack,10,0);
    }
}

void CloneMCJ_Gameplay_SplitSlime(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob,CloneMCJ_MobType type)
{
    int childCount,index,slot,size;
    if(!state||!mob||mob->slimeSize<=1)return;
    size=mob->slimeSize/2;
    childCount=2+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
    for(index=0;index<childCount;++index){
        for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)
            if(!state->mobs[slot].active)break;
        if(slot>=CLONEMC_J_MAX_MOBS)break;
        CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],type,
            state->world,mob->entity.posX+
            (double)((index%2)-0.5F)*(double)mob->slimeSize/4.0,
            mob->entity.posY+0.5,mob->entity.posZ+
            (double)((index/2)-0.5F)*(double)mob->slimeSize/4.0);
        CloneMCJ_EntitySlime_SetSizeNative(&state->mobs[slot],size);
        state->mobs[slot].entity.rotationYaw=
            CloneMCJavaRandom_NextFloat(&mob->entity.rand)*360.0F;
    }
}

static void CloneMCJ_Gameplay_SpawnRareMobLoot(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob,int enchanted)
{
    int choice,itemId;
    if(!state||!mob)return;
    itemId=0;
    if(mob->type==CLONEMC_J_MOB_ZOMBIE||
       mob->type==CLONEMC_J_MOB_GIANT){
        choice=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,4);
        itemId=choice==0?267:(choice==1?306:(choice==2?265:256));
    }else if(mob->type==CLONEMC_J_MOB_SKELETON)itemId=261;
    else if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE){
        choice=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        itemId=choice==0?266:(choice==1?283:314);
    }
    if(itemId>0){
        CloneMCJ_ItemStack stack;
        CloneMCJ_ItemStack_Initialize(&stack,itemId,1,0);
        if(enchanted)
            CloneMCJ_Progression_EnchantStackRandom(&stack,5,
                &mob->entity.rand);
        CloneMCJ_Gameplay_SpawnDrop(state,mob->entity.posX,
            mob->entity.posY,mob->entity.posZ,&stack,10,0);
    }
}

static void CloneMCJ_Gameplay_SpawnMobLoot(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob)
{
    CloneMCJ_ItemStack *held;
    int count,looting,killedByPlayer,rareRoll;
    if(!state||!mob||mob->lootDropped)return;
    mob->lootDropped=1;
    /* EntityLiving.onDeath does not call dropFewItems for children. */
    if(mob->growingAge<0)return;
    killedByPlayer=mob->recentlyHit>0;
    held=killedByPlayer?
        CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory):
        (CloneMCJ_ItemStack *)0;
    looting=killedByPlayer?CloneMCJ_Progression_EnchantLevel(held,
        CLONEMC_J_ENCHANT_LOOTING):0;
    if(looting<0)looting=0;
    switch(mob->type){
    case CLONEMC_J_MOB_PIG:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        if(looting>0)count+=CloneMCJavaRandom_NextIntBound(
            &mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,
            mob->entity.fire>0?320:319,count,0);
        break;
    case CLONEMC_J_MOB_SHEEP:
        if(!mob->sheared)CloneMCJ_Gameplay_SpawnLootStack(state,mob,35,1,
            mob->woolColor&15);
        break;
    case CLONEMC_J_MOB_COW:
    case CLONEMC_J_MOB_MOOSHROOM:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3)+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,334,count,0);
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3)+1+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,
            mob->entity.fire>0?364:363,count,0);
        break;
    case CLONEMC_J_MOB_CHICKEN:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3)+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,288,count,0);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,
            mob->entity.fire>0?366:365,1,0);
        break;
    case CLONEMC_J_MOB_ZOMBIE:
    case CLONEMC_J_MOB_GIANT:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        if(looting>0)count+=CloneMCJavaRandom_NextIntBound(
            &mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,367,count,0);
        break;
    case CLONEMC_J_MOB_GHAST:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,2)+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,370,count,0);
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3)+
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,289,count,0);
        break;
    case CLONEMC_J_MOB_PIG_ZOMBIE:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,2+looting);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,367,count,0);
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,2+looting);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,371,count,0);
        break;
    case CLONEMC_J_MOB_SKELETON:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3+looting);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,262,count,0);
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3+looting);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,352,count,0);
        break;
    case CLONEMC_J_MOB_CREEPER:
        if(mob->killedBySkeleton)
            CloneMCJ_Gameplay_SpawnLootStack(state,mob,
                2256+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,10),1,0);
        else{
            count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
            if(looting>0)count+=CloneMCJavaRandom_NextIntBound(
                &mob->entity.rand,looting+1);
            CloneMCJ_Gameplay_SpawnLootStack(state,mob,289,count,0);
        }
        break;
    case CLONEMC_J_MOB_SPIDER:
    case CLONEMC_J_MOB_CAVE_SPIDER:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        if(looting>0)count+=CloneMCJavaRandom_NextIntBound(
            &mob->entity.rand,looting+1);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,287,count,0);
        if(killedByPlayer&&
           (CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3)==0||
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,looting+1)>0))
            CloneMCJ_Gameplay_SpawnLootStack(state,mob,375,1,0);
        break;
    case CLONEMC_J_MOB_SLIME:
        if(mob->slimeSize==1){
            count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
            if(looting>0)count+=CloneMCJavaRandom_NextIntBound(
                &mob->entity.rand,looting+1);
            CloneMCJ_Gameplay_SpawnLootStack(state,mob,341,count,0);
        }
        /* EntitySlime.setEntityDead() performs child creation only when the
         * dying parent is finally removed.  Do not split during dropFewItems. */
        break;
    case CLONEMC_J_MOB_SQUID:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3+looting)+1;
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,351,count,0);
        break;
    case CLONEMC_J_MOB_ENDERMAN:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,2+looting);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,368,count,0);
        break;
    case CLONEMC_J_MOB_BLAZE:
        if(killedByPlayer){
            count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,2+looting);
            CloneMCJ_Gameplay_SpawnLootStack(state,mob,369,count,0);
        }
        break;
    case CLONEMC_J_MOB_MAGMA_CUBE:
        if(mob->slimeSize>1){
            count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,4)-2;
            if(looting>0)count+=CloneMCJavaRandom_NextIntBound(
                &mob->entity.rand,looting+1);
            CloneMCJ_Gameplay_SpawnLootStack(state,mob,378,count,0);
        }
        /* EntityMagmaCube inherits EntitySlime.setEntityDead split timing. */
        break;
    case CLONEMC_J_MOB_SNOWMAN:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,16);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,332,count,0);
        break;
    case CLONEMC_J_MOB_IRON_GOLEM:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,38,count,0);
        count=3+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        CloneMCJ_Gameplay_SpawnLootStack(state,mob,265,count,0);
        break;
    case CLONEMC_J_MOB_ENDER_DRAGON:
        {
            int px,pz,py,xx,zz;
            px=CloneMCJava_FloorDouble(mob->entity.posX);
            pz=CloneMCJava_FloorDouble(mob->entity.posZ);
            py=CloneMCJ_World_FindTopSolidBlock(state->world,px,pz)+1;
            if(py<2)py=64;if(py>122)py=122;
            for(xx=-3;xx<=3;++xx)for(zz=-3;zz<=3;++zz){
                int radius;radius=xx*xx+zz*zz;
                if(radius<=12)
                    CloneMCJ_World_SetBlockNotify(state->world,px+xx,py,
                        pz+zz,radius<=4?119:7);
            }
            CloneMCJ_World_SetBlockNotify(state->world,px,py+1,pz,122);
            CloneMCJ_Progression_SpawnExperience(state,mob->entity.posX,
                mob->entity.posY,mob->entity.posZ,12000);
        }
        break;
    default:break;
    }
    if(killedByPlayer&&(mob->type==CLONEMC_J_MOB_ZOMBIE||
       mob->type==CLONEMC_J_MOB_GIANT||
       mob->type==CLONEMC_J_MOB_SKELETON||
       mob->type==CLONEMC_J_MOB_PIG_ZOMBIE)){
        rareRoll=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,200)-looting;
        if(rareRoll<5)
            CloneMCJ_Gameplay_SpawnRareMobLoot(state,mob,rareRoll<=0);
    }
}

int CloneMCJ_Gameplay_AttackMob(CloneMCJ_GameplayState *state,int mobIndex)
{
    CloneMCJ_Mob *mob;
    CloneMCJ_ItemStack *held;
    const CloneMCJ_ItemDefinition *item;
    int damage,i;
    int sharpness;
    int knockback;
    int unbreaking;
    int awardExperience;
    if(!state||mobIndex<0||mobIndex>=CLONEMC_J_MAX_MOBS)return 0;
    mob=&state->mobs[mobIndex];if(!mob->active||mob->health<=0)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    item=held&&!CloneMCJ_ItemStack_IsEmpty(held)?CloneMCJ_ItemRegistry_Get(held->itemID):0;
    damage=item?item->damageVsEntity:1;if(damage<1)damage=1;
    sharpness=CloneMCJ_Progression_EnchantLevel(held,
        CLONEMC_J_ENCHANT_SHARPNESS);
    if(sharpness>0)damage+=1+(sharpness*5)/4;
    knockback=CloneMCJ_Progression_EnchantLevel(held,
        CLONEMC_J_ENCHANT_KNOCKBACK);
    if(state->player.entity.motionY<0.0)++damage;
    if(mob->type==CLONEMC_J_MOB_WOLF){mob->sitting=0;if(!mob->tamed){mob->angry=1;mob->hostile=1;}}
    if(mob->type==CLONEMC_J_MOB_WOLF&&!mob->tamed){for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_WOLF&&!state->mobs[i].tamed){
            double wx,wy,wz;wx=state->mobs[i].entity.posX-mob->entity.posX;
            wy=state->mobs[i].entity.posY-mob->entity.posY;wz=state->mobs[i].entity.posZ-mob->entity.posZ;
            if(wx*wx+wy*wy+wz*wz<=256.0){state->mobs[i].angry=1;state->mobs[i].hostile=1;
                state->mobs[i].targetMemoryTicks=200;}}}
    if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE){for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_PIG_ZOMBIE){
            double dx,dy,dz;dx=state->mobs[i].entity.posX-mob->entity.posX;
            dy=state->mobs[i].entity.posY-mob->entity.posY;dz=state->mobs[i].entity.posZ-mob->entity.posZ;
            if(dx*dx+dy*dy+dz*dz<=1024.0)CloneMCJ_EntityLiving_AngerPigZombie(&state->mobs[i]);}}
    if(mob->type==CLONEMC_J_MOB_ENDER_DRAGON){
        if(!CloneMCJ_V136_DamageDragon(state,mob,damage))return 0;
    }else if(!CloneMCJ_EntityLiving_AttackMobFrom(
        mob,&state->player.entity,damage))return 0;
    if(knockback>0){
        double yawRadians;
        yawRadians=(double)state->player.entity.rotationYaw*
            3.14159265358979323846/180.0;
        mob->entity.motionX-=sin(yawRadians)*0.5*(double)knockback;
        mob->entity.motionZ+=cos(yawRadians)*0.5*(double)knockback;
        mob->entity.motionY+=0.1*(double)knockback;
    }
    state->player.lastAttackTargetEntityId=mob->entity.entityId;
    if(item&&item->maxDamage>0){
        unbreaking=CloneMCJ_Progression_EnchantLevel(held,
            CLONEMC_J_ENCHANT_UNBREAKING);
        if(unbreaking<=0||CloneMCJavaRandom_NextIntBound(
            &state->player.entity.rand,unbreaking+1)==0)
            CloneMCJ_ItemStack_Damage(held,1);
    }
    if(mob->health<=0&&mob->type!=CLONEMC_J_MOB_ENDER_DRAGON){
        awardExperience=CloneMCJ_EntityLiving_IsHostileType(mob->type)?5:2;
        if(mob->type==CLONEMC_J_MOB_GHAST)awardExperience=5;
        if(mob->type==CLONEMC_J_MOB_SLIME||
           mob->type==CLONEMC_J_MOB_MAGMA_CUBE)
            awardExperience=mob->slimeSize;
        CloneMCJ_Progression_SpawnExperience(state,mob->entity.posX,
            mob->entity.posY+0.5,mob->entity.posZ,awardExperience);
        if(mob->type==CLONEMC_J_MOB_ENDER_CRYSTAL)
            CloneMCJ_Explosion_Execute(state->world,&mob->entity,
                mob->entity.posX,mob->entity.posY,mob->entity.posZ,
                6.0F,0);
        CloneMCJ_Gameplay_SpawnMobLoot(state,mob);
    }
    return 1;
}

static int CloneMCJ_Gameplay_InteractMooshroom(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob)
{
    CloneMCJ_ItemStack *held;
    CloneMCJ_ItemStack stack;
    int slot,index;
    if(!state||!mob)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if(!held||CloneMCJ_ItemStack_IsEmpty(held))return 0;
    if(held->itemID==281&&mob->growingAge>=0){
        CloneMCJ_ItemStack_Initialize(held,282,1,0);
        state->player.inventory.inventoryChanged=1;
        return 1;
    }
    if(held->itemID!=359||mob->growingAge<0)return 0;
    for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)
        if(!state->mobs[slot].active)break;
    if(slot>=CLONEMC_J_MAX_MOBS)return 0;
    CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],CLONEMC_J_MOB_COW,
        state->world,mob->entity.posX,mob->entity.posY,mob->entity.posZ);
    state->mobs[slot].health=mob->health;
    state->mobs[slot].prevHealth=mob->health;
    state->mobs[slot].entity.rotationYaw=mob->entity.rotationYaw;
    state->mobs[slot].entity.rotationPitch=mob->entity.rotationPitch;
    state->mobs[slot].renderYawOffset=mob->renderYawOffset;
    if(slot>=state->mobCount)state->mobCount=slot+1;
    mob->active=0;
    CloneMCJ_ItemStack_Initialize(&stack,40,1,0);
    for(index=0;index<5;++index)
        CloneMCJ_Gameplay_SpawnDrop(state,mob->entity.posX,
            mob->entity.posY+(double)mob->entity.height,mob->entity.posZ,
            &stack,10,0);
    return 1;
}

static int CloneMCJ_Gameplay_InteractOcelot(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob)
{
    CloneMCJ_ItemStack *held;
    double dx,dy,dz;
    if(!state||!mob)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if(!mob->tamed){
        if(!held||CloneMCJ_ItemStack_IsEmpty(held)||held->itemID!=349)
            return 1;
        dx=state->player.entity.posX-mob->entity.posX;
        dy=state->player.entity.posY-mob->entity.posY;
        dz=state->player.entity.posZ-mob->entity.posZ;
        if(dx*dx+dy*dy+dz*dz>=9.0)return 1;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        if(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3)==0){
            mob->tamed=1;
            mob->catType=1+CloneMCJavaRandom_NextIntBound(
                &state->world->rand,3);
            strncpy(mob->owner,state->player.username,
                sizeof(mob->owner)-1U);
            mob->owner[sizeof(mob->owner)-1U]='\0';
            mob->sitting=1;
            mob->persistenceRequired=1;
        }else mob->sitting=0;
        return 1;
    }
    if(!strcmp(mob->owner,state->player.username)&&
       (!held||CloneMCJ_ItemStack_IsEmpty(held)||held->itemID!=349)){
        mob->sitting=(unsigned char)!mob->sitting;
        return 1;
    }
    return 0;
}

int CloneMCJ_Gameplay_InteractMob(CloneMCJ_GameplayState *state,int mobIndex)
{
    CloneMCJ_Mob *mob;
    if(!state||mobIndex<0||mobIndex>=CLONEMC_J_MAX_MOBS)return 0;
    mob=&state->mobs[mobIndex];if(!mob->active||mob->health<=0)return 0;
    if(mob->type==CLONEMC_J_MOB_WOLF&&
       CloneMCJ_EntityWolf_Interact(mob,&state->player))return 1;
    if(mob->type==CLONEMC_J_MOB_OCELOT&&
       CloneMCJ_Gameplay_InteractOcelot(state,mob))return 1;
    if(CloneMCJ_Progression_InteractBreeding(state,mob))return 1;
    if(mob->type==CLONEMC_J_MOB_MOOSHROOM&&
       CloneMCJ_Gameplay_InteractMooshroom(state,mob))return 1;
    if(mob->type==CLONEMC_J_MOB_SHEEP)
        return CloneMCJ_EntitySheep_InteractNative(state,mob,&state->player);
    if(mob->type==CLONEMC_J_MOB_COW||
       mob->type==CLONEMC_J_MOB_MOOSHROOM)
        return CloneMCJ_EntityCow_InteractNative(mob,&state->player);
    if(mob->type==CLONEMC_J_MOB_PIG)return CloneMCJ_EntityPig_InteractNative(mob,&state->player);
    if(mob->type==CLONEMC_J_MOB_VILLAGER)
        return CloneMCJ_V136_OpenMerchant(state,mobIndex);
    return 0;
}

static CloneMCJ_Mob *CloneMCJ_Gameplay_FindRidingMob(CloneMCJ_GameplayState *state)
{
    int index;
    if(!state||state->player.ridingEntityId==0)return (CloneMCJ_Mob *)0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
        if(state->mobs[index].active&&state->mobs[index].health>0&&
            state->mobs[index].entity.entityId==state->player.ridingEntityId)
            return &state->mobs[index];
    return (CloneMCJ_Mob *)0;
}

static CloneMCJ_Vehicle *CloneMCJ_Gameplay_FindRidingVehicle(CloneMCJ_GameplayState *state)
{
    int index;if(!state||state->player.ridingEntityId==0)return (CloneMCJ_Vehicle *)0;
    for(index=0;index<CLONEMC_J_MAX_VEHICLES;++index)if(state->vehicles[index].active&&
        state->vehicles[index].entity.entityId==state->player.ridingEntityId)return &state->vehicles[index];
    return (CloneMCJ_Vehicle *)0;
}

void CloneMCJ_Gameplay_BeginRidingTickNative(CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_Entity *entity;
    if(!player)return;
    entity=&player->entity;
    /* World.updateEntityWithOptionalForce snapshots these values once before
     * Entity.updateRidden.  V131 called the rider-position helper both before
     * and after the vehicle tick, overwriting prevPos twice and producing a
     * zero-length segment followed by a full-tick camera jump. */
    entity->prevPosX=entity->posX;
    entity->prevPosY=entity->posY;
    entity->prevPosZ=entity->posZ;
    entity->prevRotationYaw=entity->rotationYaw;
    entity->prevRotationPitch=entity->rotationPitch;
    entity->motionX=0.0;
    entity->motionY=0.0;
    entity->motionZ=0.0;
    ++entity->ticksExisted;
    if(player->hurtTime>0)--player->hurtTime;
    if(player->hurtResistantTime>0)--player->hurtResistantTime;
    if(player->timeUntilPortal>0)--player->timeUntilPortal;
}

static void CloneMCJ_Gameplay_ApplyRiderRotation(CloneMCJ_EntityPlayer *player,
    const CloneMCJ_Entity *mount)
{
    double yawChange,pitchChange,releasedYaw,releasedPitch;
    const double maximum=10.0;
    if(!player||!mount)return;
    yawChange=(double)mount->rotationYaw-(double)mount->prevRotationYaw;
    pitchChange=(double)mount->rotationPitch-(double)mount->prevRotationPitch;
    player->entity.entityRiderYawDelta+=yawChange;
    player->entity.entityRiderPitchDelta+=pitchChange;
    while(player->entity.entityRiderYawDelta>=180.0)
        player->entity.entityRiderYawDelta-=360.0;
    while(player->entity.entityRiderYawDelta<-180.0)
        player->entity.entityRiderYawDelta+=360.0;
    while(player->entity.entityRiderPitchDelta>=180.0)
        player->entity.entityRiderPitchDelta-=360.0;
    while(player->entity.entityRiderPitchDelta<-180.0)
        player->entity.entityRiderPitchDelta+=360.0;
    releasedYaw=player->entity.entityRiderYawDelta*0.5;
    releasedPitch=player->entity.entityRiderPitchDelta*0.5;
    if(releasedYaw>maximum)releasedYaw=maximum;
    if(releasedYaw<-maximum)releasedYaw=-maximum;
    if(releasedPitch>maximum)releasedPitch=maximum;
    if(releasedPitch<-maximum)releasedPitch=-maximum;
    player->entity.entityRiderYawDelta-=releasedYaw;
    player->entity.entityRiderPitchDelta-=releasedPitch;
    player->entity.rotationYaw+=(float)releasedYaw;
    player->entity.rotationPitch+=(float)releasedPitch;
    if(player->entity.rotationPitch>90.0F)player->entity.rotationPitch=90.0F;
    if(player->entity.rotationPitch<-90.0F)player->entity.rotationPitch=-90.0F;
}

static void CloneMCJ_Gameplay_UpdateRider(CloneMCJ_EntityPlayer *player,
    const CloneMCJ_Mob *mount)
{
    if(!player||!mount)return;
    player->entity.motionX=0.0;player->entity.motionY=0.0;player->entity.motionZ=0.0;
    CloneMCJ_Entity_SetPosition(&player->entity,mount->entity.posX,
        mount->entity.posY+(double)mount->entity.height,mount->entity.posZ);
    CloneMCJ_Gameplay_ApplyRiderRotation(player,&mount->entity);
    if(player->entity.worldObj)CloneMCJ_World_SetPlayerGlobalPosition(
        player->entity.worldObj,player->entity.posX,player->entity.posZ);
}


void CloneMCJ_Gameplay_UpdateVehicleRiderNative(CloneMCJ_EntityPlayer *player,
    const CloneMCJ_Vehicle *vehicle)
{
    double x,y,z,yawRadians;
    if(!player||!vehicle)return;
    x=vehicle->entity.posX;
    z=vehicle->entity.posZ;
    /* EntityBoat.updateRiderPosition places the seat 0.4 blocks forward.
     * Minecart uses Entity.updateRiderPosition and remains centered. */
    if(vehicle->type==CLONEMC_J_VEHICLE_BOAT){
        yawRadians=(double)vehicle->entity.rotationYaw*
            3.14159265358979323846/180.0;
        x+=cos(yawRadians)*0.4;
        z+=sin(yawRadians)*0.4;
        /* C entity.posY is the bounding-box floor.  Converting Java's
         * getMountedYOffset(-0.3)+EntityPlayer.getYOffset(1.12) and the
         * player's 1.62 eye offset yields vehicle floor - 0.5. */
        y=vehicle->entity.posY-0.5;
    }else{
        /* The native minecart retains Java's center-Y convention
         * (floor + height/2), so the equivalent player floor is center-0.8. */
        y=vehicle->entity.posY-0.8;
    }
    player->entity.motionX=0.0;
    player->entity.motionY=0.0;
    player->entity.motionZ=0.0;
    CloneMCJ_Entity_SetPosition(&player->entity,x,y,z);
    CloneMCJ_Gameplay_ApplyRiderRotation(player,&vehicle->entity);
    if(player->entity.worldObj)CloneMCJ_World_SetPlayerGlobalPosition(player->entity.worldObj,
        player->entity.posX,player->entity.posZ);
}


static CloneMCJ_Mob *CloneMCJ_Gameplay_FindLivingMobById(CloneMCJ_GameplayState *state,int entityId)
{
    int index;
    if(!state||entityId<=0)return (CloneMCJ_Mob *)0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
        if(state->mobs[index].active&&state->mobs[index].health>0&&
            state->mobs[index].entity.entityId==entityId)return &state->mobs[index];
    return (CloneMCJ_Mob *)0;
}

static void CloneMCJ_Gameplay_AssignTamedWolfTargets(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *attacked,*attacker,*target,*wolf;
    int index;
    if(!state)return;
    attacked=CloneMCJ_Gameplay_FindLivingMobById(state,
        state->player.lastAttackTargetEntityId);
    if(attacked&&(attacked->recentlyHit<=0||
       !CloneMCJ_Gameplay_EntityChunkLoaded(state,&attacked->entity)))
        attacked=(CloneMCJ_Mob *)0;
    attacker=CloneMCJ_Gameplay_FindLivingMobById(state,
        state->player.lastAttackerEntityId);
    if(attacker&&(state->player.hurtTime<=0||
       !CloneMCJ_Gameplay_EntityChunkLoaded(state,&attacker->entity)))
        attacker=(CloneMCJ_Mob *)0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index){
        wolf=&state->mobs[index];if(!wolf->active||wolf->health<=0||
            wolf->type!=CLONEMC_J_MOB_WOLF||!wolf->tamed)continue;
        if(!CloneMCJ_Gameplay_EntityChunkLoaded(state,&wolf->entity)){
            wolf->combatTarget=(CloneMCJ_Mob *)0;
            continue;
        }
        if(strcmp(wolf->owner,state->player.username)!=0){
            wolf->combatTarget=(CloneMCJ_Mob *)0;continue;
        }
        target=(CloneMCJ_Mob *)0;
        if(!wolf->sitting&&attacked&&attacked!=wolf&&
            attacked->type!=CLONEMC_J_MOB_CREEPER&&attacked->type!=CLONEMC_J_MOB_GHAST)
            target=attacked;
        else if(attacker&&attacker!=wolf&&
            attacker->type!=CLONEMC_J_MOB_CREEPER&&attacker->type!=CLONEMC_J_MOB_GHAST)
            target=attacker;
        if(target){
            double dx,dy,dz;dx=wolf->entity.posX-state->player.entity.posX;
            dy=wolf->entity.posY-state->player.entity.posY;dz=wolf->entity.posZ-state->player.entity.posZ;
            if(dx*dx+dy*dy+dz*dz<=272.0){wolf->combatTarget=target;wolf->sitting=0;}
            else wolf->combatTarget=(CloneMCJ_Mob *)0;
        }else wolf->combatTarget=(CloneMCJ_Mob *)0;
    }
    if(!attacked)state->player.lastAttackTargetEntityId=0;
    if(!attacker)state->player.lastAttackerEntityId=0;
}


static void CloneMCJ_Gameplay_ClearMount(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *mob;CloneMCJ_Vehicle *vehicle;
    if(!state)return;mob=CloneMCJ_Gameplay_FindRidingMob(state);
    vehicle=CloneMCJ_Gameplay_FindRidingVehicle(state);
    if(mob)mob->riderEntityId=0;if(vehicle)vehicle->riderEntityId=0;
    state->player.ridingEntityId=0;
    state->player.entity.entityRiderYawDelta=0.0;
    state->player.entity.entityRiderPitchDelta=0.0;
}

int CloneMCJ_Gameplay_UsePortal(CloneMCJ_GameplayState *state)
{
    CloneMCJ_World *world;int sourceDimension,targetDimension;double targetX,targetZ,targetY;
    double sourceX,sourceY,sourceZ;float sourceYaw,sourcePitch;
    if(!state||!state->world)return 0;world=state->world;
    if(world->multiplayerWorld)return 0;
    sourceDimension=world->worldInfo.dimension;
    sourceX=state->player.entity.posX;sourceY=state->player.entity.posY;sourceZ=state->player.entity.posZ;
    sourceYaw=state->player.entity.rotationYaw;sourcePitch=state->player.entity.rotationPitch;
    if(sourceDimension==-1){targetDimension=0;targetX=state->player.entity.posX*8.0;
        targetZ=state->player.entity.posZ*8.0;}
    else{targetDimension=-1;targetX=state->player.entity.posX/8.0;
        targetZ=state->player.entity.posZ/8.0;}
    if(targetX<-29999872.0)targetX=-29999872.0;if(targetX>29999872.0)targetX=29999872.0;
    if(targetZ<-29999872.0)targetZ=-29999872.0;if(targetZ>29999872.0)targetZ=29999872.0;
    targetY=state->player.entity.posY;if(targetY<10.0)targetY=10.0;if(targetY>118.0)targetY=118.0;
    CloneMCJ_Gameplay_ClearMount(state);
    if(state->openContainerActive)CloneMCJ_Gameplay_CloseOpenContainer(state);
    if(!CloneMCJ_World_SetDimension(world,targetDimension,0))return 0;
    state->player.entity.worldObj=world;state->player.dimension=targetDimension;
    CloneMCJ_Entity_SetPosition(&state->player.entity,targetX,targetY,targetZ);
    state->player.entity.motionX=state->player.entity.motionY=state->player.entity.motionZ=0.0;
    CloneMCJ_World_SetPlayerGlobalPosition(world,targetX,targetZ);
    if(!CloneMCJ_Teleporter_PlaceInPortal(world,&state->player.entity)){
        /* A failed target portal search/build must not strand the player in a
         * half-switched provider.  Return to the saved source dimension and
         * exact transform; source chunks were committed before replacement. */
        if(CloneMCJ_World_SetDimension(world,sourceDimension,0)){
            state->player.entity.worldObj=world;state->player.dimension=sourceDimension;
            CloneMCJ_Entity_SetPosition(&state->player.entity,sourceX,sourceY,sourceZ);
            state->player.entity.rotationYaw=sourceYaw;state->player.entity.prevRotationYaw=sourceYaw;
            state->player.entity.rotationPitch=sourcePitch;state->player.entity.prevRotationPitch=sourcePitch;
            CloneMCJ_World_SetPlayerGlobalPosition(world,sourceX,sourceZ);
        }
        return 0;
    }
    CloneMCJ_World_SetPlayerGlobalPosition(world,state->player.entity.posX,state->player.entity.posZ);
    state->player.timeUntilPortal=10;state->player.timeInPortal=0.0F;
    state->player.prevTimeInPortal=0.0F;state->player.inPortal=0;
    state->player.inventory.inventoryChanged=1;
    return 1;
}

static void CloneMCJ_Gameplay_ExplodeBed(CloneMCJ_GameplayState *state,int x,int y,int z)
{
    int dx,dy,dz,id;double distance;
    if(!state||!state->world)return;
    for(dx=-5;dx<=5;++dx)for(dy=-5;dy<=5;++dy)for(dz=-5;dz<=5;++dz){
        distance=sqrt((double)(dx*dx+dy*dy+dz*dz));if(distance>5.0)continue;
        id=CloneMCJ_World_GetBlockId(state->world,x+dx,y+dy,z+dz);
        if(id!=0&&id!=7&&id!=49&&CloneMCJavaRandom_NextFloat(&state->world->rand)>
            (float)(distance/6.0))CloneMCJ_World_SetBlockNotify(state->world,x+dx,y+dy,z+dz,0);
    }
    CloneMCJ_EntityPlayer_AttackFrom(&state->player,(const CloneMCJ_Entity *)0,10);
}

int CloneMCJ_Gameplay_ActivateBed(CloneMCJ_GameplayState *state,int x,int y,int z)
{
    int i,result,metadata,direction;static const int directionMap[4][2]={{0,1},{-1,0},{0,-1},{1,0}};
    if(!state||!state->world||CloneMCJ_World_GetBlockId(state->world,x,y,z)!=26)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(state->world,x,y,z);direction=metadata&3;
    if(!(metadata&8)){x+=directionMap[direction][0];z+=directionMap[direction][1];
        if(CloneMCJ_World_GetBlockId(state->world,x,y,z)!=26)return 1;}
    if(state->world->worldInfo.dimension!=0){
        CloneMCJ_World_SetBlockNotify(state->world,x,y,z,0);
        CloneMCJ_World_SetBlockNotify(state->world,x-directionMap[direction][0],y,
            z-directionMap[direction][1],0);
        CloneMCJ_Gameplay_ExplodeBed(state,x,y,z);return 1;
    }
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&state->mobs[i].health>0&&
        CloneMCJ_EntityLiving_IsHostileNow(&state->mobs[i])){
        double dx,dy,dz;dx=state->mobs[i].entity.posX-(double)x;
        dy=state->mobs[i].entity.posY-(double)y;dz=state->mobs[i].entity.posZ-(double)z;
        if(dx*dx/64.0+dy*dy/25.0+dz*dz/64.0<=1.0)return 1;
    }
    result=CloneMCJ_EntityPlayer_TrySleep(&state->player,x,y,z);
    return result!=0;
}

static int CloneMCJ_Gameplay_OverlapsEndPortal(
    const CloneMCJ_EntityPlayer *player)
{
    int minX,minY,minZ,maxX,maxY,maxZ,x,y,z;
    const CloneMCAxisAlignedBB *box;
    if(!player||!player->entity.worldObj)return 0;
    box=&player->entity.boundingBox;
    minX=CloneMCJava_FloorDouble(box->minX);
    minY=CloneMCJava_FloorDouble(box->minY);
    minZ=CloneMCJava_FloorDouble(box->minZ);
    maxX=CloneMCJava_FloorDouble(box->maxX+0.000001);
    maxY=CloneMCJava_FloorDouble(box->maxY+0.000001);
    maxZ=CloneMCJava_FloorDouble(box->maxZ+0.000001);
    for(x=minX;x<=maxX;++x)for(y=minY;y<=maxY;++y)
        for(z=minZ;z<=maxZ;++z)
            if(CloneMCJ_World_GetBlockId(player->entity.worldObj,x,y,z)==119)
                return 1;
    return 0;
}

static int CloneMCJ_Gameplay_UseEndPortal(CloneMCJ_GameplayState *state)
{
    CloneMCJ_World *world;
    int source,target,x,y,z;
    double targetX,targetY,targetZ;
    if(!state||!state->world||state->world->multiplayerWorld)return 0;
    world=state->world;source=world->worldInfo.dimension;
    if(source==1){
        target=0;targetX=(double)world->worldInfo.spawnX+0.5;
        targetY=(double)world->worldInfo.spawnY;
        targetZ=(double)world->worldInfo.spawnZ+0.5;
    }else if(source==0){
        target=1;targetX=100.5;targetY=50.0;targetZ=0.5;
    }else return 0;
    CloneMCJ_Gameplay_ClearMount(state);
    if(state->openContainerActive)CloneMCJ_Gameplay_CloseOpenContainer(state);
    if(!CloneMCJ_World_SetDimension(world,target,0))return 0;
    state->player.entity.worldObj=world;state->player.dimension=target;
    if(target==1){
        /* Teleporter.java's End branch creates a 5x5 obsidian landing pad at
         * (100,48,0) and clears three blocks of headroom. */
        for(x=-2;x<=2;++x)for(z=-2;z<=2;++z){
            CloneMCJ_World_SetBlockWithMetadata(world,100+x,48,z,49,0);
            for(y=49;y<=52;++y)
                CloneMCJ_World_SetBlockWithMetadata(world,100+x,y,z,0,0);
        }
    }
    CloneMCJ_Entity_SetPosition(&state->player.entity,
        targetX,targetY,targetZ);
    state->player.entity.motionX=0.0;state->player.entity.motionY=0.0;
    state->player.entity.motionZ=0.0;
    CloneMCJ_World_SetPlayerGlobalPosition(world,targetX,targetZ);
    state->player.timeUntilPortal=10;
    state->endPortalCooldown=20;
    if(source==1)state->endCreditsRequested=1;
    return 1;
}

static int CloneMCJ_Gameplay_FindFreeMobSlot(CloneMCJ_GameplayState *state)
{
    int slot;
    if(!state)return -1;
    for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)
        if(!state->mobs[slot].active)return slot;
    return -1;
}

void CloneMCJ_Gameplay_SpawnVillageResidents(CloneMCJ_World *world,
    int x,int y,int z,CloneMCJavaRandom *random)
{
    CloneMCJ_GameplayState *state;
    int i,slot,count;
    double dx,dz;
    if(!world||!world->gameplayUserData)return;
    state=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(state->world!=world)return;
    /* Population is persistent, but this guard also makes regeneration or a
     * recovered partially-populated chunk unable to duplicate residents. */
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&
           state->mobs[i].type==CLONEMC_J_MOB_VILLAGER){
            dx=state->mobs[i].entity.posX-(double)x;
            dz=state->mobs[i].entity.posZ-(double)z;
            if(dx*dx+dz*dz<576.0)return;
        }
    for(count=0;count<3;++count){
        slot=CloneMCJ_Gameplay_FindFreeMobSlot(state);
        if(slot<0)return;
        CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],
            CLONEMC_J_MOB_VILLAGER,world,(double)x+0.5+(double)(count*2),
            (double)y,(double)z+0.5+(double)(count&1)*2.0);
        state->mobs[slot].profession=random?
            CloneMCJavaRandom_NextIntBound(random,5):count;
        state->mobs[slot].persistenceRequired=1;
        if(state->nextEntityId<=state->mobs[slot].entity.entityId)
            state->nextEntityId=state->mobs[slot].entity.entityId+1;
        if(slot>=state->mobCount)state->mobCount=slot+1;
    }
}

void CloneMCJ_Gameplay_SpawnVillageResident(CloneMCJ_World *world,
    int x,int y,int z,int profession)
{
    CloneMCJ_GameplayState *state;CloneMCJ_Mob *mob;
    int i,slot;double dx,dy,dz;
    if(!world||!world->gameplayUserData)return;
    state=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(state->world!=world)return;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i){
        mob=&state->mobs[i];
        if(!mob->active||mob->type!=CLONEMC_J_MOB_VILLAGER)continue;
        dx=mob->entity.posX-((double)x+0.5);
        dy=mob->entity.posY-(double)y;
        dz=mob->entity.posZ-((double)z+0.5);
        if(dx*dx+dy*dy+dz*dz<9.0)return;
    }
    slot=CloneMCJ_Gameplay_FindFreeMobSlot(state);if(slot<0)return;
    mob=&state->mobs[slot];
    CloneMCJ_EntityLiving_InitializeMob(mob,CLONEMC_J_MOB_VILLAGER,
        world,(double)x+0.5,(double)y,(double)z+0.5);
    mob->profession=profession<0?0:(profession>4?4:profession);
    mob->persistenceRequired=1;
    if(state->nextEntityId<=mob->entity.entityId)
        state->nextEntityId=mob->entity.entityId+1;
    if(slot>=state->mobCount)state->mobCount=slot+1;
}

static void CloneMCJ_Gameplay_SpawnEndMob(CloneMCJ_GameplayState *state,
    CloneMCJ_MobType type,double x,double y,double z)
{
    int slot;
    slot=CloneMCJ_Gameplay_FindFreeMobSlot(state);if(slot<0)return;
    CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],type,
        state->world,x,y,z);
    state->mobs[slot].persistenceRequired=1;
    if(state->nextEntityId<=state->mobs[slot].entity.entityId)
        state->nextEntityId=state->mobs[slot].entity.entityId+1;
    if(slot>=state->mobCount)state->mobCount=slot+1;
}

static int CloneMCJ_Gameplay_HasEndMobNear(const CloneMCJ_GameplayState *state,
    CloneMCJ_MobType type,double x,double y,double z,double maximumSquared)
{
    double dx,dy,dz;
    int slot;
    if(!state)return 0;
    for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)
        if(state->mobs[slot].active&&state->mobs[slot].health>0&&
           state->mobs[slot].type==type){
            dx=state->mobs[slot].entity.posX-x;
            dy=state->mobs[slot].entity.posY-y;
            dz=state->mobs[slot].entity.posZ-z;
            if(dx*dx+dy*dy+dz*dz<=maximumSquared)return 1;
        }
    return 0;
}

static void CloneMCJ_Gameplay_TickEndSetup(CloneMCJ_GameplayState *state)
{
    static const signed char pillarX[10]={
        42,34,13,-13,-34,-42,-34,-13,13,34};
    static const signed char pillarZ[10]={
        0,25,40,40,25,0,-25,-40,-40,-25};
    CloneMCJ_World *world;
    int index,cx,cz,radius,top,base,x,y,z;
    if(!state||!state->world||state->world->worldInfo.dimension!=1||
       state->endSetupStage==255)return;
    world=state->world;
    if(state->endSetupStage==0){
        if(CloneMCJ_World_GetBlockId(world,0,127,0)==7){
            state->endSetupStage=255;return;
        }
        state->endSetupStage=1;return;
    }
    if(state->endSetupStage<=10){
        index=(int)state->endSetupStage-1;
        cx=(int)pillarX[index];cz=(int)pillarZ[index];
        radius=2+(index%3==0?1:0);
        base=CloneMCJ_World_FindTopSolidBlock(world,cx,cz);
        if(base<40)base=40;
        top=70+(index*7)%31;
        for(x=-radius;x<=radius;++x)
            for(z=-radius;z<=radius;++z)
                if(x*x+z*z<=radius*radius+1)
                    for(y=base;y<=top;++y)
                        CloneMCJ_World_SetBlockWithMetadata(world,
                            cx+x,y,cz+z,49,0);
        CloneMCJ_World_SetBlockWithMetadata(world,cx,top+1,cz,7,0);
        if(!CloneMCJ_Gameplay_HasEndMobNear(state,
            CLONEMC_J_MOB_ENDER_CRYSTAL,
            (double)cx+0.5,(double)top+2.0,(double)cz+0.5,4.0))
            CloneMCJ_Gameplay_SpawnEndMob(state,
                CLONEMC_J_MOB_ENDER_CRYSTAL,
                (double)cx+0.5,(double)top+2.0,(double)cz+0.5);
        ++state->endSetupStage;return;
    }
    if(state->endSetupStage==11){
        if(!CloneMCJ_Gameplay_HasEndMobNear(state,
            CLONEMC_J_MOB_ENDER_DRAGON,0.0,80.0,0.0,65536.0))
            CloneMCJ_Gameplay_SpawnEndMob(state,CLONEMC_J_MOB_ENDER_DRAGON,
                0.0,80.0,0.0);
        /* Write the persistent completion marker last.  If dimension travel or
         * a save interrupts staged pillar construction, the next End visit
         * safely replays the idempotent block writes instead of accepting a
         * half-built arena as complete. */
        CloneMCJ_World_SetBlockWithMetadata(world,0,127,0,7,0);
        state->endSetupStage=255;
    }
}

/* V142 removed the V139 global entity-prefetch scanner.  Loaded-chunk
 * eligibility is checked below without admitting terrain. */
static int CloneMCJ_Gameplay_EntityChunkLoaded(
    CloneMCJ_GameplayState *state,const CloneMCJ_Entity *entity)
{
    int chunkX;
    int chunkZ;
    if(!state||!state->world||!entity)return 0;
    chunkX=CloneMCJ_World_GlobalToChunk(CloneMCJava_FloorDouble(entity->posX));
    chunkZ=CloneMCJ_World_GlobalToChunk(CloneMCJava_FloorDouble(entity->posZ));
    return CloneMCJ_World_IsChunkLoaded(state->world,chunkX,chunkZ);
}

void CloneMCJ_Gameplay_Tick(CloneMCJ_World *world, void *userData)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_Mob *mount;
    CloneMCJ_Vehicle *vehicleMount;
    CloneMCJ_MovingObjectPosition target;
    double blockDistance;
    int i,slot,mobIndex,vehicleIndex;
    state = (CloneMCJ_GameplayState *)userData;
    if (!state || world != state->world) return;
    state->player.dimension = world->worldInfo.dimension;
    if(state->endPortalCooldown>0)--state->endPortalCooldown;
    mount=CloneMCJ_Gameplay_FindRidingMob(state);
    vehicleMount=CloneMCJ_Gameplay_FindRidingVehicle(state);
    if((mount||vehicleMount)&&state->player.movementInput.sneak){
        state->player.ridingEntityId=0;if(mount)mount->riderEntityId=0;if(vehicleMount)vehicleMount->riderEntityId=0;
        state->player.entity.entityRiderYawDelta=0.0;
        state->player.entity.entityRiderPitchDelta=0.0;
        CloneMCJ_Entity_SetPosition(&state->player.entity,mount?mount->entity.posX+1.0:vehicleMount->entity.posX+1.0,
            mount?mount->entity.posY:vehicleMount->entity.posY,mount?mount->entity.posZ:vehicleMount->entity.posZ);
        mount=(CloneMCJ_Mob *)0;vehicleMount=(CloneMCJ_Vehicle *)0;
    }
    if(mount||vehicleMount)CloneMCJ_Gameplay_BeginRidingTickNative(&state->player);
    else CloneMCJ_EntityPlayer_Tick(&state->player);
    /* Chunk admission is serviced once by World_Tick before gameplay. */
    if(!world->multiplayerWorld&&state->endPortalCooldown==0&&
       CloneMCJ_Gameplay_OverlapsEndPortal(&state->player)){
        if(CloneMCJ_Gameplay_UseEndPortal(state)){
            state->previousAttack=state->attackInput;
            state->previousUse=state->useInput;++state->ticksRun;return;
        }
    }
    CloneMCJ_Gameplay_TickEndSetup(state);
    if(state->player.inPortal&&(mount||vehicleMount))CloneMCJ_Gameplay_ClearMount(state);
    if(!world->multiplayerWorld&&state->player.timeInPortal>=1.0F&&
       state->player.timeUntilPortal<=0){
        if(CloneMCJ_Gameplay_UsePortal(state)){state->previousAttack=state->attackInput;
            state->previousUse=state->useInput;++state->ticksRun;return;}
    }
    if(state->player.sleeping){
        ++state->player.sleepTimer;
        if(state->player.sleepTimer>=100){
            world->worldTime=((world->worldTime+CLONEMC_J_WORLD_DAY_TICKS-1L)/
                CLONEMC_J_WORLD_DAY_TICKS)*CLONEMC_J_WORLD_DAY_TICKS;
            CloneMCJ_World_StopPrecipitation(world);
            CloneMCJ_EntityPlayer_Wake(&state->player,0,1);
        }
        state->previousAttack=state->attackInput;state->previousUse=state->useInput;
        ++state->ticksRun;return;
    }
    target = CloneMCJ_Gameplay_RayTrace(&state->player, 5.0);
    if(target.hit){
        double ex,ey,ez;
        ex=state->player.entity.posX;ey=state->player.entity.posY+1.62;
        ez=state->player.entity.posZ;
        ex=target.hitVec.xCoord-ex;ey=target.hitVec.yCoord-ey;ez=target.hitVec.zCoord-ez;
        blockDistance=sqrt(ex*ex+ey*ey+ez*ez);
    }else blockDistance=5.0;
    if(blockDistance>3.0)blockDistance=3.0;
    mobIndex=CloneMCJ_Gameplay_FindTargetMob(state,blockDistance,(double *)0);
    vehicleIndex=CloneMCJ_Gameplay_FindTargetVehicle(state,blockDistance,(double *)0);
    if(state->player.gameMode==CLONEMC_J_GAMEMODE_SPECTATOR){
        /* Spectator is an observation-only compatibility mode.  Do not send
         * dig/use packets or mutate local entities/blocks, and cancel any
         * partially accumulated mining overlay when the mode changes. */
        state->attackInput=0;state->useInput=0;state->intentDigging=0;
        state->controller.hittingBlock=0;
        state->controller.currentBlockDamage=0.0F;
        state->controller.previousBlockDamage=0.0F;
        state->controller.currentBlockX=-999999;
        state->controller.currentBlockY=-999999;
        state->controller.currentBlockZ=-999999;
        mobIndex=-1;vehicleIndex=-1;
    }
    if(state->attackInput&&!state->previousAttack&&
       state->player.gameMode!=CLONEMC_J_GAMEMODE_SPECTATOR)
        CloneMCJ_EntityPlayer_SwingItem(&state->player);
    if(world->multiplayerWorld&&state->sendDigIntent){
        /* EntityRenderer replaces the block hit with the nearer entity hit in
         * the Java client.  Preserve that ordering here and keep the server
         * authoritative: local mobs/vehicles are not damaged or mounted until
         * their response packets arrive. */
        if(state->attackInput&&!state->previousAttack){
            int targetEntityId;targetEntityId=0;
            if(vehicleIndex>=0)targetEntityId=state->vehicles[vehicleIndex].entity.entityId;
            else if(mobIndex>=0)targetEntityId=state->mobs[mobIndex].entity.entityId;
            if(targetEntityId&&state->sendUseEntityIntent){
                if(state->sendAnimationIntent)state->sendAnimationIntent(state->multiplayerController,
                    state->player.entity.entityId,1);
                state->sendUseEntityIntent(state->multiplayerController,
                    state->player.entity.entityId,targetEntityId,1);
            }else if(target.hit){
                state->intentBlockX=target.blockX;state->intentBlockY=target.blockY;
                state->intentBlockZ=target.blockZ;state->intentFace=target.sideHit;
                state->intentDigging=1;
                state->sendDigIntent(state->multiplayerController,0,target.blockX,target.blockY,
                    target.blockZ,target.sideHit);
            }else if(state->sendAnimationIntent)state->sendAnimationIntent(
                state->multiplayerController,state->player.entity.entityId,1);
        }else if(!state->attackInput&&state->previousAttack&&state->intentDigging){
            state->sendDigIntent(state->multiplayerController,1,state->intentBlockX,
                state->intentBlockY,state->intentBlockZ,state->intentFace);
            state->intentDigging=0;
        }
        if(state->useInput&&!state->previousUse){
            int targetEntityId;targetEntityId=0;
            if(vehicleIndex>=0)targetEntityId=state->vehicles[vehicleIndex].entity.entityId;
            else if(mobIndex>=0)targetEntityId=state->mobs[mobIndex].entity.entityId;
            if(targetEntityId&&state->sendUseEntityIntent)
                state->sendUseEntityIntent(state->multiplayerController,
                    state->player.entity.entityId,targetEntityId,0);
            else if(state->sendPlaceIntent){
                if(target.hit)state->sendPlaceIntent(state->multiplayerController,target.blockX,
                    target.blockY,target.blockZ,target.sideHit,
                    CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory));
                else state->sendPlaceIntent(state->multiplayerController,-1,-1,-1,255,
                    CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory));
            }
        }
    }else{
        if(state->attackInput&&!state->previousAttack&&vehicleIndex>=0)
            CloneMCJ_Vehicle_Attack(&state->vehicles[vehicleIndex],state,1);
        else if(state->attackInput&&!state->previousAttack&&mobIndex>=0)
            CloneMCJ_Gameplay_AttackMob(state,mobIndex);
        else if (state->attackInput && target.hit&&mobIndex<0&&vehicleIndex<0)
            CloneMCJ_PlayerControllerSP_DamageBlock(&state->controller, target.blockX, target.blockY, target.blockZ);
        else if (!state->attackInput) {
            state->controller.hittingBlock = 0;
            state->controller.currentBlockDamage = 0.0F;
            state->controller.previousBlockDamage = 0.0F;
            state->controller.currentBlockX = -999999;
            state->controller.currentBlockY = -999999;
            state->controller.currentBlockZ = -999999;
        }
        if(state->useInput&&!state->previousUse){
            CloneMCJ_ItemStack creativeHeldBefore;CloneMCJ_ItemStack *creativeHeld;
            int creativeRestore,creativeSlot;
            creativeRestore=0;creativeSlot=state->player.inventory.currentItem;
            creativeHeld=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
            if(state->player.gameMode==CLONEMC_J_GAMEMODE_CREATIVE&&creativeHeld&&
               !CloneMCJ_ItemStack_IsEmpty(creativeHeld)){
                creativeHeldBefore=*creativeHeld;creativeRestore=1;
            }
            if(vehicleIndex>=0&&(state->vehicles[vehicleIndex].type==CLONEMC_J_VEHICLE_BOAT||
                state->vehicles[vehicleIndex].type==CLONEMC_J_VEHICLE_MINECART)){
                CloneMCJ_Vehicle *clickedVehicle;CloneMCJ_ItemStack *held;clickedVehicle=&state->vehicles[vehicleIndex];
                held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
                if(clickedVehicle->type==CLONEMC_J_VEHICLE_MINECART&&clickedVehicle->minecartType==1)
                    state->openVehicleInventoryId=clickedVehicle->entity.entityId;
                else if(clickedVehicle->type==CLONEMC_J_VEHICLE_MINECART&&clickedVehicle->minecartType==2){
                    if(held&&!CloneMCJ_ItemStack_IsEmpty(held)&&held->itemID==263){
                        CloneMCJ_Gameplay_ConsumeItem(&state->player.inventory,263);clickedVehicle->fuel+=1200;}
                    clickedVehicle->pushX=clickedVehicle->entity.posX-state->player.entity.posX;
                    clickedVehicle->pushZ=clickedVehicle->entity.posZ-state->player.entity.posZ;
                }else{state->player.ridingEntityId=clickedVehicle->entity.entityId;
                    state->player.entity.entityRiderYawDelta=0.0;
                    state->player.entity.entityRiderPitchDelta=0.0;
                    clickedVehicle->riderEntityId=state->player.entity.entityId;}
            }else if(mobIndex>=0)CloneMCJ_Gameplay_InteractMob(state,mobIndex);
            else if(target.hit){
                if(!CloneMCJ_Gameplay_ActivateBed(state,target.blockX,target.blockY,target.blockZ)&&
                   !CloneMCJ_Gameplay_OpenBlockContainer(state,target.blockX,
                    target.blockY,target.blockZ)&&
                   !CloneMCJ_Gameplay_UseEntityItem(state,&target)&&
                   !CloneMCJ_PlayerControllerSP_PlaceBlock(&state->controller,
                    target.blockX,target.blockY,target.blockZ,target.sideHit))
                    CloneMCJ_ItemFood_Use(CloneMCJ_InventoryPlayer_GetCurrent(
                        &state->player.inventory),&state->player);
            }
            else if(!CloneMCJ_Gameplay_UseEntityItem(state,(const CloneMCJ_MovingObjectPosition *)0))
                CloneMCJ_ItemFood_Use(CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory),&state->player);
            if(creativeRestore&&creativeSlot>=0&&creativeSlot<9){
                state->player.inventory.mainInventory[creativeSlot]=creativeHeldBefore;
                state->player.inventory.inventoryChanged=1;
            }
        }
    }
    if(!world->multiplayerWorld){
        CloneMCJ_Gameplay_FlushPendingDrops(state);
        /* Beta pressure plates react through onEntityCollidedWithBlock rather
         * than polling only their scheduled tick.  Refresh the candidate under
         * each entity before motion advances the rest of the world. */
        CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
            CloneMCJava_FloorDouble(state->player.entity.posX),
            CloneMCJava_FloorDouble(state->player.entity.boundingBox.minY),
            CloneMCJava_FloorDouble(state->player.entity.posZ));
        CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
            CloneMCJava_FloorDouble(state->player.entity.posX),
            CloneMCJava_FloorDouble(state->player.entity.boundingBox.minY)-1,
            CloneMCJava_FloorDouble(state->player.entity.posZ));
        for (i = 0; i < state->droppedItemCount; ++i) if (state->droppedItems[i].active) {
            int wasActive;
            if(!CloneMCJ_Gameplay_EntityChunkLoaded(state,
                    &state->droppedItems[i].entity)){
                ++state->droppedItemTicksSuspended;
                continue;
            }
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->droppedItems[i].entity.posX),
                CloneMCJava_FloorDouble(state->droppedItems[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->droppedItems[i].entity.posZ));
            wasActive=state->droppedItems[i].active;
            CloneMCJ_EntityItem_TickLoaded(&state->droppedItems[i]);
            ++state->droppedItemTicks;
            if(state->droppedItems[i].active)
                CloneMCJ_EntityItem_TryPickup(&state->droppedItems[i], &state->player);
            if(wasActive&&!state->droppedItems[i].active)
                ++state->droppedItemsDespawned;
            CloneMCJ_Gameplay_UpdateDroppedItemChunk(state,&state->droppedItems[i]);
        }
        CloneMCJ_Progression_TickExperienceOrbs(state);
        CloneMCJ_Gameplay_AssignTamedWolfTargets(state);
        for (i = 0; i < CLONEMC_J_MAX_MOBS; ++i) if (state->mobs[i].active){
            if(!CloneMCJ_Gameplay_EntityChunkLoaded(state,&state->mobs[i].entity)){
                ++state->mobTicksSuspended;
                continue;
            }
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->mobs[i].entity.posX),
                CloneMCJava_FloorDouble(state->mobs[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->mobs[i].entity.posZ));
            CloneMCJ_EntityLiving_TickMob(&state->mobs[i], &state->player);
            CloneMCJ_Progression_TickMobEffects(&state->mobs[i]);
            if(state->mobs[i].health<=0&&!state->mobs[i].lootDropped&&
               state->mobs[i].type!=CLONEMC_J_MOB_ENDER_DRAGON)
                CloneMCJ_Gameplay_SpawnMobLoot(state,&state->mobs[i]);
            if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_CHICKEN&&state->mobs[i].specialTimer<=0){
                CloneMCJ_ItemStack egg;CloneMCJ_ItemStack_Initialize(&egg,344,1,0);CloneMCJ_Gameplay_SpawnDrop(state,
                    state->mobs[i].entity.posX,state->mobs[i].entity.posY,state->mobs[i].entity.posZ,&egg,10,0);
                state->mobs[i].specialTimer=6000+CloneMCJavaRandom_NextIntBound(&state->mobs[i].entity.rand,6000);}
            if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_SKELETON&&state->mobs[i].rangedAttackPending){
                int projectileSlot;double dx,dy,dz,horizontal;
                if(CloneMCJ_Gameplay_SpawnProjectile(state,CLONEMC_J_PROJECTILE_ARROW,&state->mobs[i].entity,0.6F,12.0F)){
                    for(projectileSlot=0;projectileSlot<CLONEMC_J_MAX_PROJECTILES;++projectileSlot)
                        if(state->projectiles[projectileSlot].active&&state->projectiles[projectileSlot].entity.entityId==state->nextEntityId-1)break;
                    if(projectileSlot<CLONEMC_J_MAX_PROJECTILES){state->projectiles[projectileSlot].belongsToPlayer=0;
                        dx=state->player.entity.posX-state->mobs[i].entity.posX;dz=state->player.entity.posZ-state->mobs[i].entity.posZ;
                        horizontal=sqrt(dx*dx+dz*dz);dy=state->player.entity.posY+1.0-state->mobs[i].entity.posY+horizontal*0.2;
                        CloneMCJ_Projectile_SetHeading(&state->projectiles[projectileSlot],dx,dy,dz,0.6F,12.0F);}}
            }
            if(state->mobs[i].active&&
               (state->mobs[i].type==CLONEMC_J_MOB_GHAST||
                state->mobs[i].type==CLONEMC_J_MOB_BLAZE)&&
               state->mobs[i].rangedAttackPending){
                int projectileSlot;double dx,dy,dz,length,spread;
                CloneMCJ_ProjectileType projectileType;
                projectileType=state->mobs[i].type==CLONEMC_J_MOB_BLAZE?
                    CLONEMC_J_PROJECTILE_SMALL_FIREBALL:
                    CLONEMC_J_PROJECTILE_FIREBALL;
                if(CloneMCJ_Gameplay_SpawnProjectile(state,projectileType,
                    &state->mobs[i].entity,1.0F,0.0F)){
                    for(projectileSlot=0;projectileSlot<CLONEMC_J_MAX_PROJECTILES;++projectileSlot)
                        if(state->projectiles[projectileSlot].active&&state->projectiles[projectileSlot].entity.entityId==state->nextEntityId-1)break;
                    if(projectileSlot<CLONEMC_J_MAX_PROJECTILES){double yawRadians,lookX,lookZ;
                        dx=state->player.entity.posX-state->mobs[i].entity.posX;
                        dy=(state->player.entity.boundingBox.minY+state->player.entity.height*0.5)-
                            (state->mobs[i].entity.posY+state->mobs[i].entity.height*0.5);
                        dz=state->player.entity.posZ-state->mobs[i].entity.posZ;
                        length=sqrt(dx*dx+dy*dy+dz*dz);if(length<0.001)length=0.001;
                        if(state->mobs[i].type==CLONEMC_J_MOB_BLAZE){
                            /* EntityBlaze adds sqrt(distance)*0.5 horizontal
                             * spread, then EntityFireball adds its own 0.4
                             * Gaussian perturbation to all three axes. */
                            spread=sqrt(length)*0.5;
                            dx+=CloneMCJavaRandom_NextGaussian(
                                &state->mobs[i].entity.rand)*spread;
                            dz+=CloneMCJavaRandom_NextGaussian(
                                &state->mobs[i].entity.rand)*spread;
                            dx+=CloneMCJavaRandom_NextGaussian(
                                &state->projectiles[projectileSlot].entity.rand)*0.4;
                            dy+=CloneMCJavaRandom_NextGaussian(
                                &state->projectiles[projectileSlot].entity.rand)*0.4;
                            dz+=CloneMCJavaRandom_NextGaussian(
                                &state->projectiles[projectileSlot].entity.rand)*0.4;
                            length=sqrt(dx*dx+dy*dy+dz*dz);
                            if(length<0.001)length=0.001;
                        }
                        yawRadians=(double)state->mobs[i].entity.rotationYaw*0.017453292519943295;
                        lookX=-sin(yawRadians);lookZ=cos(yawRadians);
                        state->projectiles[projectileSlot].entity.posX=
                            state->mobs[i].entity.posX+lookX*
                            (state->mobs[i].type==CLONEMC_J_MOB_GHAST?4.0:0.6);
                        state->projectiles[projectileSlot].entity.posY=state->mobs[i].entity.posY+
                            state->mobs[i].entity.height*0.5+0.5;
                        state->projectiles[projectileSlot].entity.posZ=
                            state->mobs[i].entity.posZ+lookZ*
                            (state->mobs[i].type==CLONEMC_J_MOB_GHAST?4.0:0.6);
                        CloneMCJ_Entity_SetPosition(&state->projectiles[projectileSlot].entity,
                            state->projectiles[projectileSlot].entity.posX,
                            state->projectiles[projectileSlot].entity.posY,
                            state->projectiles[projectileSlot].entity.posZ);
                        CloneMCJ_Projectile_SetHeading(&state->projectiles[projectileSlot],dx,dy,dz,1.0F,0.0F);
                        state->projectiles[projectileSlot].belongsToPlayer=0;
                        state->projectiles[projectileSlot].accelerationX=dx/length*0.1;
                        state->projectiles[projectileSlot].accelerationY=dy/length*0.1;
                        state->projectiles[projectileSlot].accelerationZ=dz/length*0.1;}}
            }
        }
        CloneMCJ_Progression_TickBreeding(state);
        CloneMCJ_V136_TickWorldSystems(state);
        for(i=0;i<state->projectileCount;++i)if(state->projectiles[i].active){
            if(!CloneMCJ_Gameplay_EntityChunkLoaded(state,
                    &state->projectiles[i].entity)){
                ++state->projectileTicksSuspended;
                continue;
            }
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->projectiles[i].entity.posX),
                CloneMCJava_FloorDouble(state->projectiles[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->projectiles[i].entity.posZ));
            CloneMCJ_Projectile_Tick(&state->projectiles[i],state);
        }
        for(i=0;i<state->vehicleCount;++i)if(state->vehicles[i].active){
            if(!CloneMCJ_Gameplay_EntityChunkLoaded(state,
                    &state->vehicles[i].entity)){
                ++state->vehicleTicksSuspended;
                continue;
            }
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->vehicles[i].entity.posX),
                CloneMCJava_FloorDouble(state->vehicles[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->vehicles[i].entity.posZ));
            CloneMCJ_Vehicle_Tick(&state->vehicles[i],state);
        }
        for(i=0;i<state->vehicleCount;++i)if(state->vehicles[i].active){int otherVehicle;
            for(otherVehicle=i+1;otherVehicle<state->vehicleCount;++otherVehicle)
                if(state->vehicles[otherVehicle].active)CloneMCJ_Vehicle_ApplyCollision(
                    &state->vehicles[i],&state->vehicles[otherVehicle]);}
        if((state->ticksRun%20UL)==0UL)(void)CloneMCJ_Gameplay_SynchronizeChunkEntities(state,0);
        CloneMCJ_SpawnerAnimals_Tick(state);
        for (slot = 0; slot < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++slot) {
            CloneMCJ_Chunk *chunk;
            int tileIndex;
            if (!world->chunkProvider.slots[slot].used) continue;
            chunk = world->chunkProvider.slots[slot].chunk;
            if (!chunk) continue;
            for (tileIndex = 0; tileIndex < chunk->tileEntityCount; ++tileIndex)
                CloneMCJ_TileEntity_Update((CloneMCJ_TileEntity *)chunk->tileEntities[tileIndex]);
        }
    }
    /* Packet-driven multiplayer vehicles skip the local entity-physics branch,
     * but Entity.updateRidden still applies their latest authoritative mount
     * transform.  Finish the rider update here for both local and remote
     * mounts so the camera follows continuously in either mode. */
    mount=CloneMCJ_Gameplay_FindRidingMob(state);
    if(mount)CloneMCJ_Gameplay_UpdateRider(&state->player,mount);
    else{
        vehicleMount=CloneMCJ_Gameplay_FindRidingVehicle(state);
        if(vehicleMount)
            CloneMCJ_Gameplay_UpdateVehicleRiderNative(&state->player,
                vehicleMount);
        else if(state->player.ridingEntityId!=0){
            state->player.ridingEntityId=0;
            state->player.entity.entityRiderYawDelta=0.0;
            state->player.entity.entityRiderPitchDelta=0.0;
        }
    }
    state->previousAttack = state->attackInput;
    state->previousUse = state->useInput;
    ++state->ticksRun;
}

void CloneMCJ_Gameplay_SetMultiplayerIntentHooks(CloneMCJ_GameplayState *state,void *controller,
    int (*dig)(void *,int,int,int,int,int),
    int (*place)(void *,int,int,int,int,const CloneMCJ_ItemStack *))
{
    if(!state)return;
    state->multiplayerController=controller;state->sendDigIntent=dig;state->sendPlaceIntent=place;
}

void CloneMCJ_Gameplay_AttachSaveHooks(CloneMCJ_GameplayState *state)
{
    CloneMCJ_McRegionChunkLoader *loader;
    CloneMCJ_ChunkSerializationHooks hooks;
    if (!state || !state->world || !state->world->saveHandler) return;
    loader = CloneMCJ_SaveHandler_GetChunkLoader(state->world->saveHandler,
        state->world->worldInfo.dimension);
    if (!loader) return;
    memset(&hooks, 0, sizeof(hooks));
    hooks.writeEntity = CloneMCJ_Gameplay_WriteEntityHook;
    hooks.readEntity = CloneMCJ_Gameplay_ReadEntityHook;
    hooks.getEntityY = CloneMCJ_Gameplay_GetEntityYHook;
    hooks.writeTileEntity = CloneMCJ_Gameplay_WriteTileHook;
    hooks.readTileEntity = CloneMCJ_Gameplay_ReadTileHook;
    hooks.userData = state;
    CloneMCJ_McRegionChunkLoader_SetHooks(loader, &hooks);
}

static int CloneMCJ_Gameplay_AddEntityToLoadedChunk(CloneMCJ_World *world,void *object,
    CloneMCJ_Entity *entity)
{
    CloneMCJ_Chunk *chunk;int chunkX,chunkY,chunkZ;
    if(!world||!object||!entity)return 0;
    chunkX=CloneMCJava_FloorDouble(entity->posX/16.0);
    chunkY=CloneMCJava_FloorDouble(entity->posY/16.0);
    if(chunkY<0)chunkY=0;
    if(chunkY>=CLONEMC_J_CHUNK_ENTITY_SLICES)
        chunkY=CLONEMC_J_CHUNK_ENTITY_SLICES-1;
    chunkZ=CloneMCJava_FloorDouble(entity->posZ/16.0);
    chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,chunkX,chunkZ);
    if(!chunk||!CloneMCJ_Chunk_AddEntity(chunk,object,entity->posY)){
        entity->addedToChunk=0;
        return 0;
    }
    entity->addedToChunk=1;
    entity->chunkCoordX=chunkX;
    entity->chunkCoordY=chunkY;
    entity->chunkCoordZ=chunkZ;
    return 1;
}

static void CloneMCJ_Gameplay_UpdateDroppedItemChunk(CloneMCJ_GameplayState *state,
    CloneMCJ_EntityItem *item)
{
    CloneMCJ_Entity *entity;
    CloneMCJ_Chunk *chunk;
    int chunkX,chunkY,chunkZ;
    if(!state||!state->world||!item)return;
    entity=&item->entity;
    chunkX=CloneMCJava_FloorDouble(entity->posX/16.0);
    chunkY=CloneMCJava_FloorDouble(entity->posY/16.0);
    if(chunkY<0)chunkY=0;
    if(chunkY>=CLONEMC_J_CHUNK_ENTITY_SLICES)
        chunkY=CLONEMC_J_CHUNK_ENTITY_SLICES-1;
    chunkZ=CloneMCJava_FloorDouble(entity->posZ/16.0);
    if(entity->addedToChunk&&(!item->active||
       entity->chunkCoordX!=chunkX||entity->chunkCoordY!=chunkY||
       entity->chunkCoordZ!=chunkZ)){
        chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(state->world,
            entity->chunkCoordX,entity->chunkCoordZ);
        if(chunk){
            CloneMCJ_Chunk_RemoveEntity(chunk,item,entity->chunkCoordY);
            CloneMCJ_Chunk_SetModified(chunk);
        }
        entity->addedToChunk=0;
    }
    if(item->active&&!entity->addedToChunk&&
       CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,item,entity)){
        chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(state->world,
            entity->chunkCoordX,entity->chunkCoordZ);
        if(chunk)CloneMCJ_Chunk_SetModified(chunk);
    }
}

static int CloneMCJ_Gameplay_SynchronizeChunkEntities(CloneMCJ_GameplayState *state,int markModified)
{
    CloneMCJ_Chunk *chunk;int slot,slice,i,success;
    unsigned char hadEntities[CLONEMC_J_CHUNK_CACHE_CAPACITY];
    if(!state||!state->world)return 0;
    memset(hadEntities,0,sizeof(hadEntities));success=1;
    for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot)
        if(state->world->chunkProvider.slots[slot].used){
            chunk=state->world->chunkProvider.slots[slot].chunk;if(!chunk)continue;
            hadEntities[slot]=chunk->hasEntities;
            for(slice=0;slice<CLONEMC_J_CHUNK_ENTITY_SLICES;++slice)
                chunk->entityCount[slice]=0;
            chunk->hasEntities=0;
        }
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)
        state->droppedItems[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)state->mobs[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)
        state->projectiles[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)
        state->vehicles[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(state->droppedItems[i].active&&
        !CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->droppedItems[i],&state->droppedItems[i].entity))success=0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&
        !CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->mobs[i],&state->mobs[i].entity))success=0;
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(state->projectiles[i].active&&
        state->projectiles[i].type!=CLONEMC_J_PROJECTILE_FISHING)
        if(!CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->projectiles[i],&state->projectiles[i].entity))success=0;
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(state->vehicles[i].active&&
        state->vehicles[i].type!=CLONEMC_J_VEHICLE_LIGHTNING)
        if(!CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->vehicles[i],&state->vehicles[i].entity))success=0;
    if(markModified)for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot)
        if(state->world->chunkProvider.slots[slot].used){
            chunk=state->world->chunkProvider.slots[slot].chunk;
            if(chunk&&(hadEntities[slot]||chunk->hasEntities))
                CloneMCJ_Chunk_SetModified(chunk);
        }
    if(!success)++state->entitySyncFailures;
    return success;
}

void CloneMCJ_Gameplay_OnDimensionChanged(CloneMCJ_World *world,void *userData,int dimension)
{
    CloneMCJ_GameplayState *state;state=(CloneMCJ_GameplayState *)userData;
    if(!state||state->world!=world)return;
    if(state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    memset(state->droppedItems,0,sizeof(state->droppedItems));
    memset(state->experienceOrbs,0,sizeof(state->experienceOrbs));
    memset(state->mobs,0,sizeof(state->mobs));memset(state->projectiles,0,sizeof(state->projectiles));
    memset(state->vehicles,0,sizeof(state->vehicles));state->droppedItemCount=0;state->mobCount=0;
    state->experienceOrbCount=0;state->projectileCount=0;state->vehicleCount=0;
    state->player.ridingEntityId=0;
    state->player.entity.entityRiderYawDelta=0.0;
    state->player.entity.entityRiderPitchDelta=0.0;
    state->openVehicleInventoryId=0;
    state->endSetupStage=dimension==1?0:255;
    state->endPortalCooldown=20;
    state->player.dimension=dimension;CloneMCJ_Gameplay_AttachSaveHooks(state);
}

static CloneMCJ_TileEntity *CloneMCJ_Gameplay_GetBlockTile(
    CloneMCJ_GameplayState *state, int x, int y, int z,
    CloneMCJ_TileEntityType requiredType, int createMissing)
{
    CloneMCJ_Chunk *chunk;
    CloneMCJ_TileEntity *tile;
    if (!state || !state->world || y < 0 || y >= CLONEMC_J_CHUNK_HEIGHT)
        return (CloneMCJ_TileEntity *)0;
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(state->world, x, z);
    if (!chunk) return (CloneMCJ_TileEntity *)0;
    tile = (CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(chunk,
        x & 15, y, z & 15);
    if (tile && (tile->invalid || tile->type != requiredType)) {
        if (!createMissing) return (CloneMCJ_TileEntity *)0;
        CloneMCJ_Chunk_RemoveTileEntity(chunk, x & 15, y, z & 15);
        CloneMCJ_TileEntity_Destroy(tile);
        tile = (CloneMCJ_TileEntity *)0;
    }
    if (!tile && createMissing) {
        tile = CloneMCJ_TileEntity_Create(requiredType, state->world, x, y, z);
        if (!tile) return (CloneMCJ_TileEntity *)0;
        if (!CloneMCJ_Chunk_SetTileEntity(chunk, x & 15, y, z & 15, tile)) {
            CloneMCJ_TileEntity_Destroy(tile);
            return (CloneMCJ_TileEntity *)0;
        }
        chunk->isModified = 1;
    }
    return tile;
}

static int CloneMCJ_Gameplay_IsOpaqueAbove(CloneMCJ_GameplayState *state,
    int x, int y, int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if (!state || !state->world) return 1;
    id = CloneMCJ_World_GetBlockId(state->world, x, y + 1, z);
    block = CloneMCJ_BlockRegistry_Get(id);
    return block && block->solid && block->opaque;
}

int CloneMCJ_Gameplay_CloseOpenContainer(CloneMCJ_GameplayState *state)
{
    CloneMCJ_ItemStack leftovers[CLONEMC_J_MAX_RECIPE_CELLS];
    int count;
    int i;
    if (!state || !state->openContainerActive) return 0;
    count=0;
    for (i = 0; i < CLONEMC_J_MAX_RECIPE_CELLS; ++i)
        CloneMCJ_ItemStack_Clear(&leftovers[i]);
    if (state->openContainer.type == CLONEMC_J_CONTAINER_CHEST) {
        if (state->openContainer.tileEntity &&
            state->openContainer.tileEntity->numUsingPlayers > 0)
            --state->openContainer.tileEntity->numUsingPlayers;
        if (state->openContainer.secondTileEntity &&
            state->openContainer.secondTileEntity->numUsingPlayers > 0)
            --state->openContainer.secondTileEntity->numUsingPlayers;
    }
    if(state->openContainer.type==CLONEMC_J_CONTAINER_ENCHANTMENT&&
       !CloneMCJ_ItemStack_IsEmpty(&state->openContainerTile.items[0])){
        CloneMCJ_InventoryPlayer_AddItemStack(&state->player.inventory,
            &state->openContainerTile.items[0]);
        if(!CloneMCJ_ItemStack_IsEmpty(&state->openContainerTile.items[0])){
            leftovers[0]=state->openContainerTile.items[0];
            CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[0]);
        }
    }
    if(state->openContainer.type==CLONEMC_J_CONTAINER_MERCHANT){
        CloneMCJ_Mob *merchant;
        merchant=(state->openMerchantMobIndex>=0&&
            state->openMerchantMobIndex<CLONEMC_J_MAX_MOBS)?
            &state->mobs[state->openMerchantMobIndex]:(CloneMCJ_Mob *)0;
        if(merchant)merchant->customerEntityId=0;
        /* Inputs belong to the player and are returned; the synthetic result
         * is merely a recipe preview until CompleteMerchantTrade consumes it. */
        for(i=0;i<2;++i)
            if(!CloneMCJ_ItemStack_IsEmpty(&state->openContainerTile.items[i])){
                CloneMCJ_InventoryPlayer_AddItemStack(&state->player.inventory,
                    &state->openContainerTile.items[i]);
                if(!CloneMCJ_ItemStack_IsEmpty(&state->openContainerTile.items[i])&&
                   count<CLONEMC_J_MAX_RECIPE_CELLS)
                    leftovers[count++]=state->openContainerTile.items[i];
                CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[i]);
            }
        CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[2]);
    }
    count += CloneMCJ_Container_Close(&state->openContainer,
        &state->player.inventory, leftovers+count,
        CLONEMC_J_MAX_RECIPE_CELLS-count);
    if(!CloneMCJ_ItemStack_IsEmpty(&leftovers[0])&&count==0)count=1;
    for (i = 0; i < count; ++i) {
        if (!CloneMCJ_ItemStack_IsEmpty(&leftovers[i]))
            CloneMCJ_Gameplay_SpawnDrop(state, state->player.entity.posX,
                state->player.entity.posY + 1.32,
                state->player.entity.posZ, &leftovers[i], 40, 0);
    }
    CloneMCJ_Container_Initialize(&state->openContainer);
    CloneMCJ_InventoryCrafting_Initialize(&state->openCraftMatrix, 2, 2);
    CloneMCJ_InventoryCraftResult_Initialize(&state->openCraftResult);
    state->openContainerActive = 0;
    state->openContainerIsBlock = 0;
    state->openContainerX = 0;
    state->openContainerY = 0;
    state->openContainerZ = 0;
    state->openMerchantMobIndex=-1;
    return 1;
}

int CloneMCJ_Gameplay_OpenPlayerContainer(CloneMCJ_GameplayState *state)
{
    if (!state) return 0;
    if (state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    state->openVehicleInventoryId = 0;
    CloneMCJ_ContainerPlayer_InitializeNative(&state->openContainer,
        &state->player.inventory, &state->openCraftMatrix,
        &state->openCraftResult);
    state->openContainerActive = 1;
    state->openContainerIsBlock = 0;
    return 1;
}

int CloneMCJ_Gameplay_OpenBlockContainer(CloneMCJ_GameplayState *state,
    int x, int y, int z)
{
    CloneMCJ_TileEntity *tile;
    CloneMCJ_TileEntity *neighbor;
    CloneMCJ_TileEntity *first;
    CloneMCJ_TileEntity *second;
    int id;
    int neighborX;
    int neighborZ;
    if (!state || !state->world) return 0;
    id = CloneMCJ_World_GetBlockId(state->world, x, y, z);
    if (id != 58 && id != 54 && id != 61 && id != 62 && id != 23 &&
        id != 116 && id != 117)
        return 0;
    if (state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    state->openVehicleInventoryId = 0;
    if(id==116){
        tile=CloneMCJ_Gameplay_GetBlockTile(state,x,y,z,
            CLONEMC_J_TILE_ENCHANTMENT_TABLE,1);
        if(!tile)return 0;
        if(!CloneMCJ_Progression_OpenBlock(state,id,x,y,z))return 0;
    } else if (id == 58) {
        CloneMCJ_ContainerWorkbench_InitializeNative(&state->openContainer,
            &state->player.inventory, &state->openCraftMatrix,
            &state->openCraftResult, x, y, z);
    } else if (id == 54) {
        if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x, y, z)) return 0;
        tile = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z,
            CLONEMC_J_TILE_CHEST, 1);
        if (!tile) return 0;
        first = tile;
        second = (CloneMCJ_TileEntity *)0;
        neighborX = x - 1;
        neighborZ = z;
        if (CloneMCJ_World_GetBlockId(state->world, neighborX, y,
            neighborZ) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, neighborX, y,
                neighborZ)) return 0;
            neighbor = CloneMCJ_Gameplay_GetBlockTile(state, neighborX, y,
                neighborZ, CLONEMC_J_TILE_CHEST, 1);
            first = neighbor;
            second = tile;
        } else if (CloneMCJ_World_GetBlockId(state->world, x + 1, y, z) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x + 1, y, z)) return 0;
            second = CloneMCJ_Gameplay_GetBlockTile(state, x + 1, y, z,
                CLONEMC_J_TILE_CHEST, 1);
        } else if (CloneMCJ_World_GetBlockId(state->world, x, y, z - 1) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x, y, z - 1)) return 0;
            neighbor = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z - 1,
                CLONEMC_J_TILE_CHEST, 1);
            first = neighbor;
            second = tile;
        } else if (CloneMCJ_World_GetBlockId(state->world, x, y, z + 1) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x, y, z + 1)) return 0;
            second = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z + 1,
                CLONEMC_J_TILE_CHEST, 1);
        }
        if (!first || (second && second == first)) return 0;
        CloneMCJ_ContainerChest_InitializeDoubleNative(&state->openContainer,
            &state->player.inventory, first, second);
        ++first->numUsingPlayers;
        if (second) ++second->numUsingPlayers;
    } else if (id == 61 || id == 62) {
        tile = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z,
            CLONEMC_J_TILE_FURNACE, 1);
        if (!tile) return 0;
        CloneMCJ_ContainerFurnace_InitializeNative(&state->openContainer,
            &state->player.inventory, tile);
    } else if(id==117){
        tile=CloneMCJ_Gameplay_GetBlockTile(state,x,y,z,
            CLONEMC_J_TILE_BREWING_STAND,1);
        if(!tile)return 0;
        CloneMCJ_Progression_InitializeBrewingContainer(
            &state->openContainer,&state->player.inventory,tile);
    } else {
        tile = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z,
            CLONEMC_J_TILE_DISPENSER, 1);
        if (!tile) return 0;
        CloneMCJ_ContainerDispenser_InitializeNative(&state->openContainer,
            &state->player.inventory, tile);
    }
    state->openContainerX = x;
    state->openContainerY = y;
    state->openContainerZ = z;
    state->openContainerActive = 1;
    state->openContainerIsBlock = 1;
    return 1;
}

CloneMCJ_Container *CloneMCJ_Gameplay_GetOpenContainer(
    CloneMCJ_GameplayState *state)
{
    if (!state || !state->openContainerActive)
        return (CloneMCJ_Container *)0;
    return &state->openContainer;
}

int CloneMCJ_Gameplay_IsOpenContainerUsable(
    const CloneMCJ_GameplayState *state)
{
    double dx;
    double dy;
    double dz;
    int id;
    if (!state || !state->openContainerActive) return 0;
    if(state->openContainer.type==CLONEMC_J_CONTAINER_MERCHANT){
        const CloneMCJ_Mob *merchant;
        if(state->openMerchantMobIndex<0||
           state->openMerchantMobIndex>=CLONEMC_J_MAX_MOBS)return 0;
        merchant=&state->mobs[state->openMerchantMobIndex];
        if(!merchant->active||merchant->health<=0||
           merchant->customerEntityId!=state->player.entity.entityId)return 0;
        dx=state->player.entity.posX-merchant->entity.posX;
        dy=state->player.entity.posY-merchant->entity.posY;
        dz=state->player.entity.posZ-merchant->entity.posZ;
        return dx*dx+dy*dy+dz*dz<=64.0;
    }
    if (!state->openContainerIsBlock) return 1;
    dx = state->player.entity.posX -
        ((double)state->openContainerX + 0.5);
    dy = state->player.entity.posY -
        ((double)state->openContainerY + 0.5);
    dz = state->player.entity.posZ -
        ((double)state->openContainerZ + 0.5);
    if (dx * dx + dy * dy + dz * dz > 64.0) return 0;
    id = CloneMCJ_World_GetBlockId(state->world, state->openContainerX,
        state->openContainerY, state->openContainerZ);
    switch ((CloneMCJ_ContainerType)state->openContainer.type) {
    case CLONEMC_J_CONTAINER_WORKBENCH: return id == 58;
    case CLONEMC_J_CONTAINER_CHEST: return id == 54;
    case CLONEMC_J_CONTAINER_FURNACE: return id == 61 || id == 62;
    case CLONEMC_J_CONTAINER_DISPENSER: return id == 23;
    case CLONEMC_J_CONTAINER_ENCHANTMENT: return id == 116;
    case CLONEMC_J_CONTAINER_BREWING: return id == 117;
    default: return 1;
    }
}

CloneMCJ_Vehicle *CloneMCJ_Gameplay_GetOpenVehicleInventory(CloneMCJ_GameplayState *state)
{
    int i;if(!state||state->openVehicleInventoryId<=0)return (CloneMCJ_Vehicle *)0;
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(state->vehicles[i].active&&
        state->vehicles[i].type==CLONEMC_J_VEHICLE_MINECART&&state->vehicles[i].minecartType==1&&
        state->vehicles[i].entity.entityId==state->openVehicleInventoryId)return &state->vehicles[i];
    return (CloneMCJ_Vehicle *)0;
}

int CloneMCJ_Gameplay_PrepareSave(CloneMCJ_World *world, void *userData)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_NBTTagCompound *playerTag;
    CloneMCJ_NBTBase *clone;
    int entitySyncOk;
    state = (CloneMCJ_GameplayState *)userData;
    if (!world || !state) return 0;
    state->lastSaveError[0]='\0';
    world->lastSaveError[0]='\0';

    /* Java saves the player independently from the loaded-chunk entity lists.
     * A projectile crossing the resident-chunk boundary must not make Player
     * NBT impossible to capture.  Keep the diagnostic counter, but serialize
     * every entity that still belongs to a loaded chunk and continue. */
    entitySyncOk=CloneMCJ_Gameplay_SynchronizeChunkEntities(state,1);
    if(!entitySyncOk){
        strcpy(state->lastSaveError,
            "Some transient entities were outside the loaded chunk set; player and loaded entities were still captured");
    }
    state->player.dimension = world->worldInfo.dimension;

    /* Preserve unknown Java/mod tags by cloning the last valid Player compound
     * before overwriting the fields owned by EntityPlayer.  Publication is
     * transactional: the current worldInfo.playerTag is untouched until a
     * complete replacement exists. */
    playerTag=(CloneMCJ_NBTTagCompound *)0;
    if(world->worldInfo.playerTag&&world->worldInfo.playerTag->type==10){
        clone=CloneMCJ_NBTBase_Clone(world->worldInfo.playerTag);
        if(clone&&clone->type==10)playerTag=(CloneMCJ_NBTTagCompound *)clone;
        else if(clone)CloneMCJ_NBTBase_Free(clone);
    }
    if(!playerTag)playerTag=CloneMCJ_NBTTagCompound_Create();
    if(!playerTag){
        strcpy(state->lastSaveError,"Could not allocate the Player NBT snapshot");
        strcpy(world->lastSaveError,state->lastSaveError);
        return 0;
    }
    if(!CloneMCJ_EntityPlayer_WriteNBT(&state->player,playerTag)){
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)playerTag);
        /* One bounded retry with a clean compound avoids a partially cloned or
         * malformed legacy Player tag blocking an otherwise valid save. */
        playerTag=CloneMCJ_NBTTagCompound_Create();
        if(!playerTag||!CloneMCJ_EntityPlayer_WriteNBT(&state->player,playerTag)){
            if(playerTag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)playerTag);
            strcpy(state->lastSaveError,"Could not serialize current position, inventory, health, and dimension into Player NBT");
            strcpy(world->lastSaveError,state->lastSaveError);
            return 0;
        }
    }
    if (world->worldInfo.playerTag)
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)world->worldInfo.playerTag);
    world->worldInfo.playerTag = (CloneMCJ_NBTBase *)playerTag;
    world->worldInfo.dimension = state->player.dimension;
    return 1;
}

void CloneMCJ_EntityPlayerSP_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityPlayerSP_JavaName(void)
{
    return "net.minecraft.src.EntityPlayerSP";
}

const char *CloneMCJ_EntityPlayerSP_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityPlayerSP_JavaSourceHash32(void)
{
    return 0x52782725UL;
}
