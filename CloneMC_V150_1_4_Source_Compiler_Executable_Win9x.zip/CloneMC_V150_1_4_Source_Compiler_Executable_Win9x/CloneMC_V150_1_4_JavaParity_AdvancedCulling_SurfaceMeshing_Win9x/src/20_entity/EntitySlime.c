/*
 * CloneMC Java port scaffold: EntitySlime
 *
 * Java source: EntitySlime.java
 * Java type: class EntitySlime
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityLiving
 * Implements: IMob
 * Source SHA-256: 346d866b659977001938937d3062df1a2617a257fefddd79195af9472bc4ac93
 * Java lines: 183
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: EntityLiving, IMob, DataWatcher, NBTTagCompound, MathHelper, AxisAlignedBB, World, EntityPlayer, Item, Chunk, posY, p
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public float field_768_a
 * - public float field_767_b
 * - private int slimeJumpDelay
 *
 * Java method/constructor inventory:
 * - public EntitySlime(World world)
 * - protected void entityInit()
 * - public void setSlimeSize(int i)
 * - public int getSlimeSize()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void onUpdate()
 * - protected void updatePlayerActionState()
 * - public void setEntityDead()
 * - public void onCollideWithPlayer(EntityPlayer entityplayer)
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected int getDropItemId()
 * - public boolean getCanSpawnHere()
 * - protected float getSoundVolume()
 *
 * This class now owns typed construction and Java size/health updates; jumping,
 * contact damage, splitting and `Size` NBT use the shared mob runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntitySlime_InitializeNative(CloneMCJ_Mob *slime,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(slime,CLONEMC_J_MOB_SLIME,world,x,y,z);
}

void CloneMCJ_EntitySlime_SetSizeNative(CloneMCJ_Mob *slime,int size)
{
    double x,y,z;
    if(!slime)return;
    if(size<1)size=1;
    if(size>16)size=16;
    x=slime->entity.posX;y=slime->entity.posY;z=slime->entity.posZ;
    slime->slimeSize=size;
    slime->maxHealth=size*size;
    slime->health=slime->maxHealth;
    slime->prevHealth=slime->health;
    /* EntityMagmaCube.func_40130_ai adds two to inherited slime damage. This
     * shared setter is used by NBT restore and split children too, so restore
     * the type-specific value here rather than only in the constructor. */
    slime->attackStrength=slime->type==CLONEMC_J_MOB_MAGMA_CUBE?size+2:size;
    slime->slimeJumpDelay=10+CloneMCJavaRandom_NextIntBound(&slime->entity.rand,20);
    slime->slimeSquish=slime->prevSlimeSquish=0.0F;
    CloneMCJ_Entity_SetSize(&slime->entity,0.6F*(float)size,0.6F*(float)size);
    CloneMCJ_Entity_SetPosition(&slime->entity,x,y,z);
}

void CloneMCJ_EntitySlime_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntitySlime_JavaName(void)
{
    return "net.minecraft.src.EntitySlime";
}

const char *CloneMCJ_EntitySlime_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntitySlime_JavaSourceHash32(void)
{
    return 0x346D866BUL;
}
