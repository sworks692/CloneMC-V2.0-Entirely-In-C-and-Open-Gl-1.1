/*
 * Java 1.2.3 PotionHelper/Potion/PotionHealth behavior.
 *
 * The original class encodes potion recipes and effects in small boolean
 * expressions over the 15 low metadata bits.  Keeping that representation
 * avoids a later-version recipe table and preserves otherwise obscure
 * mundane/thick/awkward and corruption transitions.
 */
#include "clonemc_java_port_20_entity.h"
#include <math.h>
#include <string.h>

#define CLONEMC_J_POTION_EFFECT_DEFINITION_COUNT 9

typedef struct CloneMCJ_PotionEffectDefinitionTag {
    int id;
    const char *requirement;
    const char *amplifier;
    int color;
    double effectiveness;
    unsigned char instant;
} CloneMCJ_PotionEffectDefinition;

static const CloneMCJ_PotionEffectDefinition g_cloneMCPotionEffects[
    CLONEMC_J_POTION_EFFECT_DEFINITION_COUNT] = {
    {10,"0 & !1 & !2 & !3 & 0+6","5",0xcd5cab,0.25,0},
    { 1,"!0 & 1 & !2 & !3 & 1+6","5",0x7cafc6,1.00,0},
    {12,"0 & 1 & !2 & !3 & 0+6",(const char *)0,0xe49a3a,1.00,0},
    { 6,"0 & !1 & 2 & !3","5",0xf82423,1.00,1},
    {19,"!0 & !1 & 2 & !3 & 2+6","5",0x4e9331,0.25,0},
    {18,"!0 & !1 & !2 & 3 & 3+6",(const char *)0,0x484d48,0.50,0},
    { 7,"!0 & !1 & 2 & 3","5",0x430a09,0.50,1},
    { 2,"!0 & 1 & !2 & 3 & 3+6",(const char *)0,0x5a6c81,0.50,0},
    { 5,"0 & !1 & !2 & 3 & 3+6","5",0x932423,1.00,0}
};

static int CloneMCJ_PotionHelper_CheckFlag(int value,int bit)
{
    return (value&(1<<bit))!=0;
}

static int CloneMCJ_PotionHelper_CountFlags(int value)
{
    int count;
    count=0;
    while(value>0){value&=value-1;++count;}
    return count;
}

static int CloneMCJ_PotionHelper_Term(int flagUnset,int multiply,
    int negative,int comparison,int bit,int multiplier,int data)
{
    int value;
    value=0;
    if(flagUnset)
        value=CloneMCJ_PotionHelper_CheckFlag(data,bit)?0:1;
    else if(comparison!=-1){
        if(comparison==0&&CloneMCJ_PotionHelper_CountFlags(data)==bit)value=1;
        else if(comparison==1&&CloneMCJ_PotionHelper_CountFlags(data)>bit)
            value=1;
        else if(comparison==2&&CloneMCJ_PotionHelper_CountFlags(data)<bit)
            value=1;
    }else value=CloneMCJ_PotionHelper_CheckFlag(data,bit)?1:0;
    if(multiply)value*=multiplier;
    if(negative)value*=-1;
    return value;
}

static int CloneMCJ_PotionHelper_Find(const char *text,int start,int end,
    char wanted)
{
    int index;
    for(index=start;index<end&&text[index];++index)
        if(text[index]==wanted)return index;
    return -1;
}

static void CloneMCJ_PotionHelper_Trim(const char *text,int *start,int *end)
{
    while(*start<*end&&(text[*start]==' '||text[*start]=='\t'))++*start;
    while(*end>*start&&(text[*end-1]==' '||text[*end-1]=='\t'))--*end;
}

static int CloneMCJ_PotionHelper_Evaluate(const char *text,int start,int end,
    int data)
{
    int operatorIndex;
    int left;
    int right;
    int index;
    int flagMultiplier;
    int multiplierPresent;
    int digitPresent;
    int unset;
    int negative;
    int comparison;
    int bit;
    int multiplier;
    int total;
    char c;
    if(!text)return 0;
    CloneMCJ_PotionHelper_Trim(text,&start,&end);
    if(start>=end)return 0;
    operatorIndex=CloneMCJ_PotionHelper_Find(text,start,end,'|');
    if(operatorIndex>=0){
        left=CloneMCJ_PotionHelper_Evaluate(text,start,operatorIndex,data);
        if(left>0)return left;
        right=CloneMCJ_PotionHelper_Evaluate(text,operatorIndex+1,end,data);
        return right>0?right:0;
    }
    operatorIndex=CloneMCJ_PotionHelper_Find(text,start,end,'&');
    if(operatorIndex>=0){
        left=CloneMCJ_PotionHelper_Evaluate(text,start,operatorIndex,data);
        if(left<=0)return 0;
        right=CloneMCJ_PotionHelper_Evaluate(text,operatorIndex+1,end,data);
        if(right<=0)return 0;
        return left>right?left:right;
    }
    flagMultiplier=0;
    multiplierPresent=0;
    digitPresent=0;
    unset=0;
    negative=0;
    comparison=-1;
    bit=0;
    multiplier=0;
    total=0;
    for(index=start;index<end;++index){
        c=text[index];
        if(c>='0'&&c<='9'){
            if(flagMultiplier){multiplier=c-'0';multiplierPresent=1;}
            else{bit=bit*10+(c-'0');digitPresent=1;}
            continue;
        }
        if(c=='*'){flagMultiplier=1;continue;}
        if(c=='!'||c=='-'||c=='='||c=='<'||c=='>'||c=='+'){
            if((c=='!'||c=='-'||c=='='||c=='<'||c=='>')&&digitPresent){
                total+=CloneMCJ_PotionHelper_Term(unset,multiplierPresent,
                    negative,comparison,bit,multiplier,data);
                flagMultiplier=multiplierPresent=digitPresent=unset=negative=0;
                comparison=-1;bit=multiplier=0;
            }
            if(c=='!')unset=1;
            else if(c=='-')negative=1;
            else if(c=='=')comparison=0;
            else if(c=='<')comparison=2;
            else if(c=='>')comparison=1;
            else if(c=='+'&&digitPresent){
                total+=CloneMCJ_PotionHelper_Term(unset,multiplierPresent,
                    negative,comparison,bit,multiplier,data);
                flagMultiplier=multiplierPresent=digitPresent=unset=negative=0;
                comparison=-1;bit=multiplier=0;
            }
        }
    }
    if(digitPresent)
        total+=CloneMCJ_PotionHelper_Term(unset,multiplierPresent,negative,
            comparison,bit,multiplier,data);
    return total;
}

static int CloneMCJ_PotionHelper_BitOperation(int data,int bit,int remove,
    int toggle,int require)
{
    if(require){
        if(!CloneMCJ_PotionHelper_CheckFlag(data,bit))return 0;
    }else if(remove)data&=~(1<<bit);
    else if(toggle){
        if((data&(1<<bit))!=0)data&=~(1<<bit);
        else data|=1<<bit;
    }else data|=1<<bit;
    return data;
}

int CloneMCJ_PotionHelper_ApplyIngredient(int data,const char *effect)
{
    int length;
    int index;
    int number;
    int hasNumber;
    int toggle;
    int remove;
    int require;
    char c;
    if(!effect)return data;
    length=(int)strlen(effect);
    number=0;hasNumber=0;toggle=0;remove=0;require=0;
    for(index=0;index<length;++index){
        c=effect[index];
        if(c>='0'&&c<='9'){
            number=number*10+(c-'0');hasNumber=1;continue;
        }
        if(c=='!'||c=='-'||c=='+'||c=='&'){
            if(hasNumber){
                data=CloneMCJ_PotionHelper_BitOperation(data,number,remove,
                    toggle,require);
                hasNumber=toggle=remove=require=0;number=0;
            }
            if(c=='!')toggle=1;
            else if(c=='-')remove=1;
            else if(c=='&')require=1;
        }
    }
    if(hasNumber)data=CloneMCJ_PotionHelper_BitOperation(data,number,remove,
        toggle,require);
    return data&0x7fff;
}

const char *CloneMCJ_PotionHelper_IngredientEffect(int itemId)
{
    switch(itemId){
    case 372:return "+4";              /* Nether Wart */
    case 353:return "-0+1-2-3&4-4+13";/* Sugar */
    case 370:return "+0-1-2-3&4-4+13";/* Ghast Tear */
    case 375:return "-0-1+2-3&4-4+13";/* Spider Eye */
    case 376:return "-0+3-4+13";       /* Fermented Spider Eye */
    case 382:return "+0-1+2-3&4-4+13";/* Speckled Melon */
    case 377:return "+0-1-2+3&4-4+13";/* Blaze Powder */
    case 378:return "+0+1-2-3&4-4+13";/* Magma Cream */
    case 331:return "-5+6-7";           /* Redstone */
    case 348:return "+5-6-7";           /* Glowstone Dust */
    case 289:return "+14&13-13";        /* Gunpowder */
    default:return (const char *)0;
    }
}

int CloneMCJ_PotionHelper_Result(int potionDamage,int ingredientId)
{
    const char *effect;
    effect=CloneMCJ_PotionHelper_IngredientEffect(ingredientId);
    if(!effect)return potionDamage;
    return CloneMCJ_PotionHelper_ApplyIngredient(potionDamage,effect);
}

int CloneMCJ_PotionHelper_GetEffects(int potionDamage,int includeUnusable,
    CloneMCJ_PotionEffectNative *effects,int capacity)
{
    int index;
    int count;
    int durationPower;
    int amplifier;
    int duration;
    const CloneMCJ_PotionEffectDefinition *definition;
    (void)includeUnusable;
    count=0;
    for(index=0;index<CLONEMC_J_POTION_EFFECT_DEFINITION_COUNT;++index){
        definition=&g_cloneMCPotionEffects[index];
        durationPower=CloneMCJ_PotionHelper_Evaluate(definition->requirement,
            0,(int)strlen(definition->requirement),potionDamage);
        if(durationPower<=0)continue;
        amplifier=0;
        if(definition->amplifier){
            amplifier=CloneMCJ_PotionHelper_Evaluate(definition->amplifier,0,
                (int)strlen(definition->amplifier),potionDamage);
            if(amplifier<0)amplifier=0;
        }
        if(definition->instant)duration=1;
        else{
            duration=1200*(durationPower*3+(durationPower-1)*2);
            duration>>=amplifier;
            duration=(int)floor((double)duration*definition->effectiveness+0.5);
            if((potionDamage&CLONEMC_J_POTION_SPLASH)!=0)
                duration=(int)floor((double)duration*0.75+1.0);
        }
        if(effects&&count<capacity){
            effects[count].effectId=definition->id;
            effects[count].duration=duration;
            effects[count].amplifier=amplifier;
            effects[count].instant=definition->instant;
            effects[count].liquidColor=definition->color;
        }
        ++count;
    }
    return count;
}

int CloneMCJ_PotionHelper_EffectsEqual(int firstDamage,int secondDamage)
{
    CloneMCJ_PotionEffectNative first[16];
    CloneMCJ_PotionEffectNative second[16];
    int firstCount;
    int secondCount;
    int index;
    firstCount=CloneMCJ_PotionHelper_GetEffects(firstDamage,0,first,16);
    secondCount=CloneMCJ_PotionHelper_GetEffects(secondDamage,0,second,16);
    if(firstCount!=secondCount)return 0;
    for(index=0;index<firstCount;++index)
        if(first[index].effectId!=second[index].effectId||
           first[index].duration!=second[index].duration||
           first[index].amplifier!=second[index].amplifier)return 0;
    return 1;
}

int CloneMCJ_PotionHelper_Color(int potionDamage)
{
    CloneMCJ_PotionEffectNative effects[16];
    int count;
    int index;
    int repeat;
    float red;
    float green;
    float blue;
    float weight;
    count=CloneMCJ_PotionHelper_GetEffects(potionDamage,0,effects,16);
    if(count<=0)return 0x385dc6;
    red=green=blue=weight=0.0F;
    for(index=0;index<count;++index)
        for(repeat=0;repeat<=effects[index].amplifier;++repeat){
            red+=(float)((effects[index].liquidColor>>16)&255)/255.0F;
            green+=(float)((effects[index].liquidColor>>8)&255)/255.0F;
            blue+=(float)(effects[index].liquidColor&255)/255.0F;
            weight+=1.0F;
        }
    return ((int)(red/weight*255.0F)<<16)|
        ((int)(green/weight*255.0F)<<8)|(int)(blue/weight*255.0F);
}
