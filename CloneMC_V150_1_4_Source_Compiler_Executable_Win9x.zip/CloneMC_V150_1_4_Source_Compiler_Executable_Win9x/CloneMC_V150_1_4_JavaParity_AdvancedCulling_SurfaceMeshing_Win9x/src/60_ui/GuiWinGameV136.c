/*
 * Fixed-storage port of GuiWinGame.java from the supplied 1.2.3 archive.
 * Text is loaded once on entry; render frames perform no file I/O or
 * allocation.  The original uses 0.5 pixels per 20 Hz GUI update.
 */
#include "clonemc_java_port_60_ui.h"

/* Render subsystem is included after UI in the unity build. */
int CloneMCFontRenderer_GetWrappedHeight(const char *,int);

#define V136_CREDIT_LINES 384
#define V136_CREDIT_LINE_LENGTH 280

static char g_v136CreditLines[V136_CREDIT_LINES][V136_CREDIT_LINE_LENGTH];
static unsigned short g_v136CreditHeights[V136_CREDIT_LINES];
static int g_v136CreditLineCount;
static int g_v136CreditTotalHeight;
static unsigned long g_v136CreditTicks;
static unsigned char g_v136CreditsActive;

static void V136CreditsReplaceName(char *line,const char *username)
{
    char output[V136_CREDIT_LINE_LENGTH];
    const char *cursor,*match;unsigned int used,part,nameLength;
    if(!line)return;cursor=line;used=0;
    nameLength=username?(unsigned int)strlen(username):0U;
    while(*cursor&&used+1U<sizeof(output)){
        match=strstr(cursor,"PLAYERNAME");
        if(!match){
            part=(unsigned int)strlen(cursor);
            if(part>sizeof(output)-used-1U)part=sizeof(output)-used-1U;
            memcpy(output+used,cursor,part);used+=part;break;
        }
        part=(unsigned int)(match-cursor);
        if(part>sizeof(output)-used-1U)part=sizeof(output)-used-1U;
        memcpy(output+used,cursor,part);used+=part;
        if(nameLength>sizeof(output)-used-1U)
            nameLength=sizeof(output)-used-1U;
        if(nameLength){memcpy(output+used,username,nameLength);used+=nameLength;}
        cursor=match+10;
    }
    output[used]='\0';strcpy(line,output);
}

static void V136CreditsSanitize(char *line)
{
    unsigned char *read,*write;
    if(!line)return;read=(unsigned char *)line;write=(unsigned char *)line;
    while(*read){
        /* UTF-8 section sign plus the following formatting byte. */
        if(read[0]==0xC2U&&read[1]==0xA7U&&read[2]){
            read+=3;continue;
        }
        if(*read=='\t'){int i;for(i=0;i<4;++i)*write++=' ';++read;continue;}
        if(*read<32U||*read>126U){*write++=' ';++read;continue;}
        *write++=*read++;
    }
    *write='\0';
}

static void V136CreditsAddLine(const char *text)
{
    char *line;int height;
    if(g_v136CreditLineCount>=V136_CREDIT_LINES)return;
    line=g_v136CreditLines[g_v136CreditLineCount];
    strncpy(line,text?text:"",V136_CREDIT_LINE_LENGTH-1);
    line[V136_CREDIT_LINE_LENGTH-1]='\0';
    height=CloneMCFontRenderer_GetWrappedHeight(
        line[0]=='['&&line[1]=='C'&&line[2]==']'?line+3:line,274);
    if(height<8)height=8;
    g_v136CreditHeights[g_v136CreditLineCount]=(unsigned short)height;
    g_v136CreditTotalHeight+=height;++g_v136CreditLineCount;
}

static int V136CreditsLoadFile(const char *path,const char *username)
{
    FILE *file;char line[V136_CREDIT_LINE_LENGTH];int loaded;
    file=fopen(path,"rb");if(!file)return 0;loaded=0;
    while(fgets(line,sizeof(line),file)){
        unsigned int length;length=(unsigned int)strlen(line);
        while(length&&(line[length-1]=='\n'||line[length-1]=='\r'))
            line[--length]='\0';
        V136CreditsReplaceName(line,username);V136CreditsSanitize(line);
        /* GuiWinGame adds an empty line in the conditional and then again in
         * the unconditional add.  Preserve that observable Java ordering. */
        if(!line[0])V136CreditsAddLine("");
        V136CreditsAddLine(line);loaded=1;
    }
    fclose(file);return loaded;
}

int CloneMCJ_GuiWinGame_StartNative(const char *username)
{
    int i,win,credits;
    memset(g_v136CreditLines,0,sizeof(g_v136CreditLines));
    memset(g_v136CreditHeights,0,sizeof(g_v136CreditHeights));
    g_v136CreditLineCount=0;g_v136CreditTotalHeight=0;
    g_v136CreditTicks=0;
    win=V136CreditsLoadFile("assets/title/win.txt",username);
    for(i=0;i<16;++i)V136CreditsAddLine("");
    credits=V136CreditsLoadFile("assets/title/credits.txt",username);
    if(!win&&!credits){
        V136CreditsAddLine("[C]The End");
        V136CreditsAddLine("");
        V136CreditsAddLine("[C]Credits assets could not be opened.");
    }
    g_v136CreditsActive=1;return win&&credits;
}

int CloneMCJ_GuiWinGame_UpdateNative(int screenHeight)
{
    float finish;
    if(!g_v136CreditsActive)return 0;++g_v136CreditTicks;
    finish=(float)(g_v136CreditTotalHeight+screenHeight+screenHeight+24)/0.5F;
    if((float)g_v136CreditTicks>finish){
        g_v136CreditsActive=0;return 0;
    }
    return 1;
}

void CloneMCJ_GuiWinGame_FinishNative(void)
{
    g_v136CreditsActive=0;
}

int CloneMCJ_GuiWinGame_IsActiveNative(void)
{
    return g_v136CreditsActive?1:0;
}

unsigned long CloneMCJ_GuiWinGame_GetTicksNative(void)
{
    return g_v136CreditTicks;
}

int CloneMCJ_GuiWinGame_GetLineCountNative(void)
{
    return g_v136CreditLineCount;
}

const char *CloneMCJ_GuiWinGame_GetLineNative(int index,int *height)
{
    if(index<0||index>=g_v136CreditLineCount)return (const char *)0;
    if(height)*height=(int)g_v136CreditHeights[index];
    return g_v136CreditLines[index];
}

int CloneMCJ_GuiWinGame_GetTotalHeightNative(void)
{
    return g_v136CreditTotalHeight;
}
