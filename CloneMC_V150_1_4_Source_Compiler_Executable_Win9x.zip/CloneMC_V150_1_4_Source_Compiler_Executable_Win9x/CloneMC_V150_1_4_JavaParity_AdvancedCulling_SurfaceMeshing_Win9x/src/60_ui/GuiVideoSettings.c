/*
 * CloneMC Java port scaffold: GuiVideoSettings
 *
 * Java source: GuiVideoSettings.java
 * Java type: class GuiVideoSettings
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: e8e5f6ae73440a3edd1fa79da0072dbe3ce7d14d49a6ae551c6a48821630ea03
 * Java lines: 88
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: GuiScreen, StringTranslate, EnumOptions, GuiSmallButton, GameSettings, GuiSlider, GuiButton, ScaledResolution, enumoptions
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private GuiScreen field_22110_h
 * - protected String field_22107_a
 * - private GameSettings guiGameSettings
 * - private static EnumOptions field_22108_k[]
 *
 * Java method/constructor inventory:
 * - public GuiVideoSettings(GuiScreen guiscreen, GameSettings gamesettings)
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

static const int CloneMCJ_GuiVideo_Ordinals[9] = {
    CLONEMC_OPTION_GRAPHICS,CLONEMC_OPTION_RENDER_DISTANCE,
    CLONEMC_OPTION_AMBIENT_OCCLUSION,CLONEMC_OPTION_FRAMERATE_LIMIT,
    CLONEMC_OPTION_ANAGLYPH,CLONEMC_OPTION_VIEW_BOBBING,
    CLONEMC_OPTION_GUI_SCALE,CLONEMC_OPTION_ADVANCED_OPENGL,
    CLONEMC_OPTION_VOLUMETRIC_CLOUDS
};

static void CloneMCJ_GuiVideo_Refresh(CloneMCJ_GuiScreenState *screen,const CloneMCGameSettings *settings)
{
    int center,top,index,option;char text[72];CloneMCJ_GuiButtonNative *button;
    screen->buttonCount=0;screen->selectedButton=-1;
    center=screen->width/2;top=screen->height/6;
    for(index=0;index<9;++index){option=CloneMCJ_GuiVideo_Ordinals[index];
        CloneMCGameSettings_FormatOption(settings,option,text,sizeof(text));
        button=CloneMCJ_GuiScreen_AddButtonNative(screen,option,
            (center-155)+(index%2)*160,top+24*(index>>1),150,20,text);
        if(button){
            const CloneMCJ_EnumOptionDefinition *definition;
            definition=CloneMCJ_EnumOptions_GetNative(option);
            button->optionOrdinal=option;
            button->slider=definition&&definition->isFloat;
            button->sliderValue=CloneMCGameSettings_GetOptionFloat(settings,option);
            /* These switches rebuild render state or enlarge the GUI in ways
             * known to be unsafe on early 16-bit OpenGL ICDs.  Java ignores a
             * disabled GuiButton; mirror that behavior visibly instead of
             * letting compatibility settings be undone after startup. */
            if(settings->legacyCompatibility&&
               (option==CLONEMC_OPTION_GRAPHICS||
                option==CLONEMC_OPTION_AMBIENT_OCCLUSION||
                option==CLONEMC_OPTION_ANAGLYPH||
                option==CLONEMC_OPTION_GUI_SCALE||
                option==CLONEMC_OPTION_ADVANCED_OPENGL||
                option==CLONEMC_OPTION_VOLUMETRIC_CLOUDS))
                button->enabled=0;
        }
    }
    CloneMCJ_GuiScreen_AddButtonNative(screen,200,center-100,top+168,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("gui.done"));
}

void CloneMCJ_GuiVideoSettings_InitNative(CloneMCJ_GuiScreenState *screen,const CloneMCGameSettings *settings)
{
    int width,height,scale;if(!screen||!settings)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_VIDEO,
        CLONEMC_GUI_SCREEN_OPTIONS,scale);screen->width=width;screen->height=height;
    strncpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative("options.videoTitle"),
        sizeof(screen->title)-1);CloneMCJ_GuiVideo_Refresh(screen,settings);
}

int CloneMCJ_GuiVideoSettings_ActivateNative(CloneMCJ_GuiScreenState *screen,
    CloneMCGameSettings *settings,int id)
{
    const CloneMCJ_EnumOptionDefinition *definition;
    CloneMCJ_GuiButtonNative *button;
    int index;
    float value;
    if(!screen||!settings)return 0;
    definition=CloneMCJ_EnumOptions_GetNative(id);
    if(!definition)return 0;
    if(definition->isFloat){
        button=(CloneMCJ_GuiButtonNative *)0;
        for(index=0;index<screen->buttonCount;++index)
            if(screen->buttons[index].id==id&&screen->buttons[index].slider){
                button=&screen->buttons[index];break;
            }
        if(!button||button->width<=8)return 0;
        value=(float)(screen->mouseX-(button->xPosition+4))/(float)(button->width-8);
        if(!CloneMCGameSettings_SetOptionFloat(settings,id,value))return 0;
        button->sliderValue=CloneMCGameSettings_GetOptionFloat(settings,id);
        CloneMCGameSettings_FormatOption(settings,id,button->displayString,
            sizeof(button->displayString));
        return 1;
    }
    if(!CloneMCGameSettings_SetOptionValue(settings,id,1))return 0;
    CloneMCJ_GuiVideo_Refresh(screen,settings);return 1;
}

void CloneMCJ_GuiVideoSettings_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiVideoSettings_JavaName(void)
{
    return "net.minecraft.src.GuiVideoSettings";
}

const char *CloneMCJ_GuiVideoSettings_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiVideoSettings_JavaSourceHash32(void)
{
    return 0xE8E5F6AEUL;
}
