/*
 * CloneMC Java port scaffold: LoadingScreenRenderer
 *
 * Java source: LoadingScreenRenderer.java
 * Java type: class LoadingScreenRenderer
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: IProgressUpdate
 * Source SHA-256: d7c1da707f112c7d0f81fcf9d0304f46caa48c9471872b610cfea3181092bed2
 * Java lines: 164
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: IProgressUpdate, MinecraftError, ScaledResolution, Tessellator, RenderEngine, FontRenderer, mc.displayWidth, scaledresolution.field_25121_a, scaledresolution.field_25120_b
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private String field_1004_a
 * - private Minecraft mc
 * - private String field_1007_c
 * - private long field_1006_d
 * - private boolean field_1005_e
 *
 * Java method/constructor inventory:
 * - public LoadingScreenRenderer(Minecraft minecraft)
 * - public void printText(String s)
 * - public void func_594_b(String s)
 * - public void func_597_c(String s)
 * - public void displayLoadingString(String s)
 * - public void setLoadingProgress(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

static void CloneMCJ_LoadingScreenRenderer_Copy(char *destination,
    unsigned long capacity,const char *source)
{
    if(!destination||capacity==0)return;
    if(!source)source="";
    strncpy(destination,source,capacity-1);destination[capacity-1]='\0';
}

static void CloneMCJ_LoadingScreenRenderer_Synchronize(
    const CloneMCJ_LoadingScreenState *loading,CloneMCJ_GuiScreenState *screen)
{
    if(!loading||!screen)return;
    screen->screenType=CLONEMC_GUI_SCREEN_DOWNLOAD_TERRAIN;
    screen->buttonCount=0;screen->loadingProgress=loading->progress;
    CloneMCJ_LoadingScreenRenderer_Copy(screen->title,sizeof(screen->title),loading->title);
    CloneMCJ_LoadingScreenRenderer_Copy(screen->message,sizeof(screen->message),loading->message);
}

void CloneMCJ_LoadingScreenRenderer_InitializeNative(CloneMCJ_LoadingScreenState *loading)
{
    if(!loading)return;
    memset(loading,0,sizeof(*loading));loading->progress=-1;
    loading->running=1;
}

void CloneMCJ_LoadingScreenRenderer_PrintTextNative(CloneMCJ_LoadingScreenState *loading,
    CloneMCJ_GuiScreenState *screen,const char *text)
{
    if(!loading)return;
    loading->running=1;loading->progress=-1;loading->lastUpdateMilliseconds=0;
    CloneMCJ_LoadingScreenRenderer_Copy(loading->title,sizeof(loading->title),text);
    loading->message[0]='\0';CloneMCJ_LoadingScreenRenderer_Synchronize(loading,screen);
}

void CloneMCJ_LoadingScreenRenderer_DisplayStringNative(
    CloneMCJ_LoadingScreenState *loading,CloneMCJ_GuiScreenState *screen,const char *text)
{
    if(!loading)return;
    CloneMCJ_LoadingScreenRenderer_Copy(loading->message,sizeof(loading->message),text);
    loading->progress=-1;CloneMCJ_LoadingScreenRenderer_Synchronize(loading,screen);
}

int CloneMCJ_LoadingScreenRenderer_SetProgressNative(CloneMCJ_LoadingScreenState *loading,
    CloneMCJ_GuiScreenState *screen,int progress,unsigned long nowMilliseconds)
{
    if(!loading||!loading->running)return 0;
    if(progress<-1)progress=-1;
    if(progress>100)progress=100;
    loading->progress=progress;
    CloneMCJ_LoadingScreenRenderer_Synchronize(loading,screen);
    /* LoadingScreenRenderer.java presents at most once per 100 ms.  The old
     * C path recorded a 20 ms timestamp but ignored it and still redrew and
     * swapped for every generated chunk.  That saturated software OpenGL and
     * made disk/chunk loading appear to stutter on Win95/98. */
    if(loading->lastUpdateMilliseconds!=0&&
       nowMilliseconds-loading->lastUpdateMilliseconds<100UL)return 0;
    loading->lastUpdateMilliseconds=nowMilliseconds?nowMilliseconds:1UL;
    return 1;
}

void CloneMCJ_LoadingScreenRenderer_Register(void)
{
    /* IProgressUpdate behavior is provided by the Native functions above. */
}

const char *CloneMCJ_LoadingScreenRenderer_JavaName(void)
{
    return "net.minecraft.src.LoadingScreenRenderer";
}

const char *CloneMCJ_LoadingScreenRenderer_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_LoadingScreenRenderer_JavaSourceHash32(void)
{
    return 0xD7C1DA70UL;
}
