/*
 * CloneMC Java port scaffold: Timer
 *
 * Java source: Timer.java
 * Java type: class Timer
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: c3cb572295f622271532ca82aef6e97bd82e5ff846f145e46f47e44678654e51
 * Java lines: 82
 * Discovered declared fields: 10
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public float ticksPerSecond
 * - private double lastHRTime
 * - public int elapsedTicks
 * - public float renderPartialTicks
 * - public float timerSpeed
 * - public float elapsedPartialTicks
 * - private long lastSyncSysClock
 * - private long lastSyncHRClock
 * - private long field_28132_i
 * - private double timeSyncAdjustment
 *
 * Java method/constructor inventory:
 * - public Timer(float f)
 * - public void updateTimer()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_00_core.h"
#include <windows.h>
#include <mmsystem.h>
#include <string.h>

typedef BOOL (WINAPI *CloneMCQueryCounterProc)(LARGE_INTEGER *value);
typedef BOOL (WINAPI *CloneMCQueryFrequencyProc)(LARGE_INTEGER *value);

static CloneMCQueryCounterProc g_cloneMCQueryCounter = 0;
static CloneMCQueryFrequencyProc g_cloneMCQueryFrequency = 0;
static double g_cloneMCPerformanceFrequency = 0.0;
static int g_cloneMCPerformanceTrusted = 0;
static int g_cloneMCForceFallbackClock = 0;

static double CloneMCTimer_LargeIntegerToDouble(LARGE_INTEGER value)
{
    return (double)value.QuadPart;
}

static int CloneMCTimer_InitializePerformanceCounter(void)
{
    HMODULE kernel;
    LARGE_INTEGER frequency;
    LARGE_INTEGER counter;

    g_cloneMCPerformanceTrusted = 0;
    if(g_cloneMCForceFallbackClock)return 0;
    kernel = GetModuleHandleA("KERNEL32.DLL");
    if (!kernel) { return 0; }

    g_cloneMCQueryCounter = (CloneMCQueryCounterProc)GetProcAddress(kernel, "QueryPerformanceCounter");
    g_cloneMCQueryFrequency = (CloneMCQueryFrequencyProc)GetProcAddress(kernel, "QueryPerformanceFrequency");
    if (!g_cloneMCQueryCounter || !g_cloneMCQueryFrequency) {
        g_cloneMCQueryCounter = 0;
        g_cloneMCQueryFrequency = 0;
        return 0;
    }
    if (!g_cloneMCQueryFrequency(&frequency) || !g_cloneMCQueryCounter(&counter)) {
        g_cloneMCQueryCounter = 0;
        g_cloneMCQueryFrequency = 0;
        return 0;
    }
    g_cloneMCPerformanceFrequency = CloneMCTimer_LargeIntegerToDouble(frequency);
    if (g_cloneMCPerformanceFrequency <= 0.0) {
        g_cloneMCQueryCounter = 0;
        g_cloneMCQueryFrequency = 0;
        g_cloneMCPerformanceFrequency = 0.0;
        return 0;
    }
    g_cloneMCPerformanceTrusted = 1;
    return 1;
}

static double CloneMCTimer_ReadPerformanceSeconds(void)
{
    LARGE_INTEGER counter;
    if (!g_cloneMCQueryCounter || g_cloneMCPerformanceFrequency <= 0.0) { return 0.0; }
    if (!g_cloneMCQueryCounter(&counter)) { return 0.0; }
    return CloneMCTimer_LargeIntegerToDouble(counter) / g_cloneMCPerformanceFrequency;
}

void CloneMCJ_Timer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Timer_JavaName(void)
{
    return "net.minecraft.src.Timer";
}

const char *CloneMCJ_Timer_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_Timer_JavaSourceHash32(void)
{
    return 0xC3CB5722UL;
}

void CloneMCTimer_ForceFallbackClock(int enabled)
{
    g_cloneMCForceFallbackClock=enabled?1:0;
    if(g_cloneMCForceFallbackClock){
        g_cloneMCPerformanceTrusted=0;
        g_cloneMCQueryCounter=0;
        g_cloneMCQueryFrequency=0;
        g_cloneMCPerformanceFrequency=0.0;
    }
}

int CloneMCTimer_Initialize(CloneMCTimer *timer, double ticksPerSecond)
{
    if (!timer) { return 0; }
    memset(timer, 0, sizeof(*timer));
    if (ticksPerSecond <= 0.0) { ticksPerSecond = CLONEMC_TIMER_DEFAULT_TPS; }
    timer->ticksPerSecond = ticksPerSecond;
    timer->timerSpeed = 1.0;
    timer->usingPerformanceCounter = CloneMCTimer_InitializePerformanceCounter();
    timer->lastFallbackMilliseconds = (unsigned long)timeGetTime();
    timer->fallbackAccumulatedSeconds = 0.0;
    if (timer->usingPerformanceCounter) {
        timer->lastCounterSeconds = CloneMCTimer_ReadPerformanceSeconds();
    }
    timer->initialized = 1;
    CloneMCTimer_SetActive(timer, 1);
    return 1;
}

void CloneMCTimer_Shutdown(CloneMCTimer *timer)
{
    if (!timer) { return; }
    if (timer->multimediaPeriodActive) {
        timeEndPeriod(1);
        timer->multimediaPeriodActive = 0;
    }
    timer->timingActive = 0;
    timer->initialized = 0;
}

void CloneMCTimer_Reset(CloneMCTimer *timer)
{
    if (!timer || !timer->initialized) { return; }
    timer->elapsedTicks = 0;
    timer->elapsedPartialTicks = 0.0;
    timer->renderPartialTicks = 0.0;
    timer->lastFallbackMilliseconds = (unsigned long)timeGetTime();
    if (timer->usingPerformanceCounter) {
        timer->lastCounterSeconds = CloneMCTimer_ReadPerformanceSeconds();
    }
}

void CloneMCTimer_SetActive(CloneMCTimer *timer, int active)
{
    if (!timer || !timer->initialized) { return; }
    active = active ? 1 : 0;
    if (active == timer->timingActive) { return; }
    if (active) {
        if (!timer->multimediaPeriodActive &&
            timeBeginPeriod(1) == TIMERR_NOERROR) {
            timer->multimediaPeriodActive = 1;
        }
        timer->timingActive = 1;
        CloneMCTimer_Reset(timer);
    } else {
        if (timer->multimediaPeriodActive) {
            timeEndPeriod(1);
            timer->multimediaPeriodActive = 0;
        }
        timer->timingActive = 0;
    }
}

void CloneMCTimer_Update(CloneMCTimer *timer)
{
    double elapsedSeconds;
    double nowSeconds;
    double fallbackSeconds;
    double difference;
    unsigned long nowMilliseconds;
    unsigned long deltaMilliseconds;
    int wholeTicks;

    if (!timer || !timer->initialized) { return; }
    elapsedSeconds = 0.0;
    nowMilliseconds = (unsigned long)timeGetTime();
    deltaMilliseconds = nowMilliseconds - timer->lastFallbackMilliseconds;
    timer->lastFallbackMilliseconds = nowMilliseconds;
    fallbackSeconds = (double)deltaMilliseconds / 1000.0;

    if (timer->usingPerformanceCounter) {
        nowSeconds = CloneMCTimer_ReadPerformanceSeconds();
        if (nowSeconds > 0.0) {
            elapsedSeconds = nowSeconds - timer->lastCounterSeconds;
            timer->lastCounterSeconds = nowSeconds;
            difference = elapsedSeconds - fallbackSeconds;
            if (difference < 0.0) { difference = -difference; }
            /* Old chipsets and power-management BIOSes can expose a counter
             * that jumps even though the API exists.  Compare it with the
             * wrap-safe multimedia clock and permanently fall back if the two
             * clocks disagree by a visible amount. */
            if (elapsedSeconds < 0.0 || elapsedSeconds > 2.0 ||
                (fallbackSeconds <= 2.0 && difference > 0.25)) {
                timer->usingPerformanceCounter = 0;
                g_cloneMCPerformanceTrusted = 0;
                elapsedSeconds = fallbackSeconds;
            }
        } else {
            timer->usingPerformanceCounter = 0;
            g_cloneMCPerformanceTrusted = 0;
        }
    }

    if (!timer->usingPerformanceCounter) {
        elapsedSeconds = fallbackSeconds;
        timer->fallbackAccumulatedSeconds += elapsedSeconds;
    }

    if (elapsedSeconds < 0.0) { elapsedSeconds = 0.0; }
    if (elapsedSeconds > 1.0) { elapsedSeconds = 1.0; }

    timer->elapsedPartialTicks += elapsedSeconds * timer->timerSpeed * timer->ticksPerSecond;
    wholeTicks = (int)timer->elapsedPartialTicks;
    timer->elapsedPartialTicks -= (double)wholeTicks;
    if (wholeTicks > CLONEMC_TIMER_MAX_CATCHUP_TICKS) {
        wholeTicks = CLONEMC_TIMER_MAX_CATCHUP_TICKS;
    }
    if (wholeTicks < 0) { wholeTicks = 0; }
    timer->elapsedTicks = wholeTicks;
    timer->renderPartialTicks = timer->elapsedPartialTicks;
}

double CloneMCTimer_NowSeconds(void)
{
    double value;
    value = g_cloneMCPerformanceTrusted ? CloneMCTimer_ReadPerformanceSeconds() : 0.0;
    if (value > 0.0) { return value; }
    return (double)(unsigned long)timeGetTime() / 1000.0;
}
