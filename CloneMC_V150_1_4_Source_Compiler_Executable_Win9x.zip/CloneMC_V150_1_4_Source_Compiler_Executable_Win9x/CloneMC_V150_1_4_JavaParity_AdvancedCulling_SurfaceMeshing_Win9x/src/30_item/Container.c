/*
 * Direct C89 implementation of Container.java and Slot click semantics.
 * This module owns all inventory mutations used by player, workbench, chest,
 * furnace, dispenser, and multiplayer window containers.
 */
#include "clonemc_java_port_30_item.h"
#include <string.h>

static int CloneMCJ_Container_Minimum(int left, int right)
{
    return left < right ? left : right;
}

static int CloneMCJ_Container_ArmorTypeForItem(int itemID)
{
    if (itemID == 86) return 0;
    if (itemID >= 298 && itemID <= 317) return (itemID - 298) & 3;
    return -1;
}

static int CloneMCJ_Container_CanPlaceInSlot(const CloneMCJ_Container *container,
    int slotNumber, const CloneMCJ_ItemStack *stack)
{
    int armorType;
    if (!container || slotNumber < 0 || slotNumber >= container->slotCount ||
        !stack || CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    switch ((CloneMCJ_SlotKind)container->slotKind[slotNumber]) {
    case CLONEMC_J_SLOT_CRAFT_RESULT:
    case CLONEMC_J_SLOT_FURNACE_OUTPUT:
    case CLONEMC_J_SLOT_MERCHANT_OUTPUT:
        return 0;
    case CLONEMC_J_SLOT_ARMOR:
        armorType = CloneMCJ_Container_ArmorTypeForItem(stack->itemID);
        return armorType >= 0 &&
            armorType == container->slotArmorType[slotNumber];
    case CLONEMC_J_SLOT_FURNACE_INPUT:
        {
            CloneMCJ_ItemStack result;
            return CloneMCJ_FurnaceRecipes_GetResultNative(stack, &result);
        }
    case CLONEMC_J_SLOT_FURNACE_FUEL:
        return CloneMCJ_FurnaceRecipes_GetFuelTimeNative(stack) > 0;
    case CLONEMC_J_SLOT_ENCHANT_INPUT:
        return stack->stackSize == 1 &&
            (stack->itemID == 340 ||
             (CloneMCJ_ItemRegistry_Get(stack->itemID) &&
              CloneMCJ_ItemRegistry_Get(stack->itemID)->maxStackSize == 1));
    case CLONEMC_J_SLOT_BREWING_BOTTLE:
        return stack->itemID == 373;
    case CLONEMC_J_SLOT_BREWING_INGREDIENT:
        return CloneMCJ_Progression_IsBrewingIngredient(stack->itemID);
    default:
        return 1;
    }
}

static int CloneMCJ_Container_EffectiveLimit(const CloneMCJ_Container *container,
    int slotNumber, const CloneMCJ_ItemStack *stack)
{
    int limit;
    int itemLimit;
    if (!container || slotNumber < 0 || slotNumber >= container->slotCount)
        return 0;
    limit = container->slotLimit[slotNumber];
    if (limit < 1) limit = 64;
    itemLimit = CloneMCJ_ItemStack_GetMaxStackSize(stack);
    if (itemLimit < limit) limit = itemLimit;
    if (limit < 1) limit = 1;
    return limit;
}

static int CloneMCJ_Container_CanMergeFully(const CloneMCJ_Container *container,
    const CloneMCJ_ItemStack *source, int first, int last, int reverse)
{
    int index;
    int step;
    int remaining;
    int limit;
    const CloneMCJ_ItemStack *target;
    if (!container || !source || CloneMCJ_ItemStack_IsEmpty(source)) return 0;
    remaining = source->stackSize;
    index = reverse ? last : first;
    step = reverse ? -1 : 1;
    while ((reverse && index >= first) || (!reverse && index <= last)) {
        target = container->slots[index];
        if (target && target != source &&
            CloneMCJ_ItemStack_IsStackableWith(target, source) &&
            CloneMCJ_Container_CanPlaceInSlot(container, index, source)) {
            limit = CloneMCJ_Container_EffectiveLimit(container, index, source);
            if (target->stackSize < limit) remaining -= limit - target->stackSize;
            if (remaining <= 0) return 1;
        }
        index += step;
    }
    index = reverse ? last : first;
    while ((reverse && index >= first) || (!reverse && index <= last)) {
        target = container->slots[index];
        if (target && target != source && CloneMCJ_ItemStack_IsEmpty(target) &&
            CloneMCJ_Container_CanPlaceInSlot(container, index, source)) {
            remaining -= CloneMCJ_Container_EffectiveLimit(container, index, source);
            if (remaining <= 0) return 1;
        }
        index += step;
    }
    return 0;
}

static int CloneMCJ_Container_MergeRange(CloneMCJ_Container *container,
    CloneMCJ_ItemStack *source, int first, int last, int reverse)
{
    int index;
    int step;
    int limit;
    int room;
    int transfer;
    int changed;
    CloneMCJ_ItemStack *target;
    if (!container || !source || CloneMCJ_ItemStack_IsEmpty(source) ||
        first < 0 || last >= container->slotCount || first > last) return 0;
    changed = 0;
    index = reverse ? last : first;
    step = reverse ? -1 : 1;
    while (!CloneMCJ_ItemStack_IsEmpty(source) &&
           ((reverse && index >= first) || (!reverse && index <= last))) {
        target = container->slots[index];
        if (target && target != source &&
            CloneMCJ_ItemStack_IsStackableWith(target, source) &&
            CloneMCJ_Container_CanPlaceInSlot(container, index, source)) {
            limit = CloneMCJ_Container_EffectiveLimit(container, index, source);
            room = limit - target->stackSize;
            transfer = CloneMCJ_Container_Minimum(room, source->stackSize);
            if (transfer > 0) {
                target->stackSize += transfer;
                source->stackSize -= transfer;
                changed = 1;
            }
        }
        index += step;
    }
    index = reverse ? last : first;
    while (!CloneMCJ_ItemStack_IsEmpty(source) &&
           ((reverse && index >= first) || (!reverse && index <= last))) {
        target = container->slots[index];
        if (target && target != source && CloneMCJ_ItemStack_IsEmpty(target) &&
            CloneMCJ_Container_CanPlaceInSlot(container, index, source)) {
            limit = CloneMCJ_Container_EffectiveLimit(container, index, source);
            transfer = CloneMCJ_Container_Minimum(limit, source->stackSize);
            CloneMCJ_ItemStack_Initialize(target, source->itemID, transfer,
                source->itemDamage);
            source->stackSize -= transfer;
            changed = 1;
        }
        index += step;
    }
    if (source->stackSize <= 0) CloneMCJ_ItemStack_Clear(source);
    return changed;
}

static void CloneMCJ_Container_ReturnCraftRemainders(
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_ItemStack *remainders, int count)
{
    int i;
    for (i = 0; i < count; ++i) {
        if (CloneMCJ_ItemStack_IsEmpty(&remainders[i])) continue;
        CloneMCJ_InventoryPlayer_AddItemStack(inventory, &remainders[i]);
    }
}

void CloneMCJ_Container_Initialize(CloneMCJ_Container *container)
{
    int i;
    if (!container) return;
    memset(container, 0, sizeof(*container));
    container->resultSlot = -1;
    container->tileSlotStart = -1;
    container->tileSlotEnd = -1;
    container->playerSlotStart = -1;
    container->playerSlotEnd = -1;
    container->hotbarSlotStart = -1;
    container->hotbarSlotEnd = -1;
    container->lastCraftedItemID = -1;
    container->lastSmeltedItemID = -1;
    for (i = 0; i < CLONEMC_J_MAX_CONTAINER_SLOTS; ++i) {
        container->slotArmorType[i] = -1;
        container->slotInventoryIndex[i] = -1;
    }
    CloneMCJ_ItemStack_Clear(&container->lastDroppedStack);
}

int CloneMCJ_Container_AddTypedSlot(CloneMCJ_Container *container,
    CloneMCJ_ItemStack *stack, int limit, CloneMCJ_SlotKind kind,
    int armorType, int inventoryIndex, int x, int y)
{
    int index;
    if (!container || !stack ||
        container->slotCount >= CLONEMC_J_MAX_CONTAINER_SLOTS) return -1;
    index = container->slotCount++;
    container->slots[index] = stack;
    if (limit < 1 || limit > 64) limit = 64;
    container->slotLimit[index] = (unsigned char)limit;
    container->slotKind[index] = (unsigned char)kind;
    container->slotArmorType[index] = (signed char)armorType;
    container->slotInventoryIndex[index] = (short)inventoryIndex;
    container->slotX[index] = (short)x;
    container->slotY[index] = (short)y;
    return index;
}

int CloneMCJ_Container_AddSlot(CloneMCJ_Container *container,
    CloneMCJ_ItemStack *stack, int limit)
{
    return CloneMCJ_Container_AddTypedSlot(container, stack, limit,
        CLONEMC_J_SLOT_NORMAL, -1, -1, 0, 0);
}

int CloneMCJ_Container_GetSlotAt(const CloneMCJ_Container *container, int x, int y)
{
    int i;
    if (!container) return -1;
    for (i = container->slotCount - 1; i >= 0; --i) {
        if (x >= container->slotX[i] && x < container->slotX[i] + 16 &&
            y >= container->slotY[i] && y < container->slotY[i] + 16)
            return i;
    }
    return -1;
}

int CloneMCJ_Container_UpdateCraftResult(CloneMCJ_Container *container)
{
    CloneMCJ_ItemStack output;
    const CloneMCJ_Recipe *recipe;
    if (!container || !container->craftMatrix || !container->craftResult ||
        container->resultSlot < 0) return 0;
    recipe = CloneMCJ_CraftingManager_FindMatchingRecipeNative(
        container->craftMatrix, &output);
    if (recipe) CloneMCJ_InventoryCraftResult_Set(container->craftResult, &output);
    else CloneMCJ_InventoryCraftResult_Set(container->craftResult,
        (const CloneMCJ_ItemStack *)0);
    ++container->mutationSerial;
    return recipe != (const CloneMCJ_Recipe *)0;
}

static int CloneMCJ_Container_TakeCraftResult(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_ItemStack *resultSlot;
    CloneMCJ_ItemStack remainders[CLONEMC_J_MAX_RECIPE_CELLS];
    const CloneMCJ_Recipe *recipe;
    int remainderCount;
    int room;
    int i;
    if (!container || !inventory || !container->craftMatrix ||
        container->resultSlot < 0) return 0;
    resultSlot = container->slots[container->resultSlot];
    if (!resultSlot || CloneMCJ_ItemStack_IsEmpty(resultSlot)) return 0;
    output = *resultSlot;
    if (CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)) {
        /* Accepted below after recipe validation. */
    } else {
        if (!CloneMCJ_ItemStack_IsStackableWith(&inventory->carriedStack, &output))
            return 0;
        room = CloneMCJ_ItemStack_GetMaxStackSize(&inventory->carriedStack) -
            inventory->carriedStack.stackSize;
        if (room < output.stackSize) return 0;
    }
    recipe = CloneMCJ_CraftingManager_FindMatchingRecipeNative(
        container->craftMatrix, (CloneMCJ_ItemStack *)0);
    if (!recipe) return 0;
    for (i = 0; i < CLONEMC_J_MAX_RECIPE_CELLS; ++i)
        CloneMCJ_ItemStack_Clear(&remainders[i]);
    remainderCount = 0;
    if (!CloneMCJ_CraftingManager_ConsumeRecipeNative(container->craftMatrix,
        recipe, remainders, &remainderCount)) return 0;
    if (CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack))
        inventory->carriedStack = output;
    else inventory->carriedStack.stackSize += output.stackSize;
    CloneMCJ_Container_ReturnCraftRemainders(inventory, remainders,
        remainderCount);
    CloneMCJ_Container_UpdateCraftResult(container);
    inventory->inventoryChanged = 1;
    container->lastCraftedItemID=output.itemID;
    container->lastCraftedCount=output.stackSize;
    ++container->craftedSerial;
    ++container->mutationSerial;
    return 1;
}

int CloneMCJ_Container_QuickMove(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, int slotNumber)
{
    CloneMCJ_ItemStack *source;
    CloneMCJ_ItemStack output;
    CloneMCJ_ItemStack remainders[CLONEMC_J_MAX_RECIPE_CELLS];
    const CloneMCJ_Recipe *recipe;
    int count;
    int i;
    int changed;
    int destinationFirst;
    int destinationLast;
    int armorType;
    int armorSlot;
    int outputItemID;
    int outputCount;
    int outputBefore;
    if (!container || !inventory || slotNumber < 0 ||
        slotNumber >= container->slotCount) return 0;
    source = container->slots[slotNumber];
    if (!source || CloneMCJ_ItemStack_IsEmpty(source)) return 0;
    if (slotNumber == container->resultSlot) {
        changed = 0;outputItemID=-1;outputCount=0;
        for (i = 0; i < 64; ++i) {
            if (CloneMCJ_ItemStack_IsEmpty(source)) break;
            output = *source;outputItemID=output.itemID;outputCount+=output.stackSize;
            if (!CloneMCJ_Container_CanMergeFully(container, &output,
                container->playerSlotStart, container->hotbarSlotEnd, 1)) break;
            recipe = CloneMCJ_CraftingManager_FindMatchingRecipeNative(
                container->craftMatrix, (CloneMCJ_ItemStack *)0);
            if (!recipe) break;
            CloneMCJ_Container_MergeRange(container, &output,
                container->playerSlotStart, container->hotbarSlotEnd, 1);
            count = 0;
            if (!CloneMCJ_CraftingManager_ConsumeRecipeNative(
                container->craftMatrix, recipe, remainders, &count)) break;
            CloneMCJ_Container_ReturnCraftRemainders(inventory, remainders, count);
            CloneMCJ_Container_UpdateCraftResult(container);
            source = container->slots[slotNumber];
            changed = 1;
        }
        if (changed) {inventory->inventoryChanged = 1;container->lastCraftedItemID=outputItemID;
            container->lastCraftedCount=outputCount;++container->craftedSerial;}
        return changed;
    }

    outputItemID=-1;outputCount=0;outputBefore=source->stackSize;
    if(container->slotKind[slotNumber]==CLONEMC_J_SLOT_FURNACE_OUTPUT)outputItemID=source->itemID;
    changed = 0;
    if (slotNumber >= container->tileSlotStart &&
        slotNumber <= container->tileSlotEnd &&
        container->playerSlotStart >= 0) {
        changed = CloneMCJ_Container_MergeRange(container, source,
            container->playerSlotStart, container->hotbarSlotEnd, 1);
    } else if (slotNumber >= container->playerSlotStart &&
               slotNumber <= container->hotbarSlotEnd) {
        if (container->type == CLONEMC_J_CONTAINER_PLAYER) {
            armorType = CloneMCJ_Container_ArmorTypeForItem(source->itemID);
            armorSlot = armorType >= 0 ? 5 + armorType : -1;
            if (armorSlot >= 0 && armorSlot < container->slotCount &&
                container->slots[armorSlot] &&
                CloneMCJ_ItemStack_IsEmpty(container->slots[armorSlot]))
                changed = CloneMCJ_Container_MergeRange(container, source,
                    armorSlot, armorSlot, 0);
        }
        if (!changed && container->type == CLONEMC_J_CONTAINER_FURNACE &&
            container->tileSlotStart >= 0) {
            CloneMCJ_ItemStack smeltResult;
            if (CloneMCJ_FurnaceRecipes_GetResultNative(source, &smeltResult))
                changed = CloneMCJ_Container_MergeRange(container, source,
                    container->tileSlotStart, container->tileSlotStart, 0);
            if (!changed &&
                CloneMCJ_FurnaceRecipes_GetFuelTimeNative(source) > 0)
                changed = CloneMCJ_Container_MergeRange(container, source,
                    container->tileSlotStart + 1,
                    container->tileSlotStart + 1, 0);
        } else if (container->type == CLONEMC_J_CONTAINER_ENCHANTMENT &&
                   container->tileSlotStart >= 0 &&
                   CloneMCJ_Container_CanPlaceInSlot(container,
                       container->tileSlotStart, source)) {
            changed = CloneMCJ_Container_MergeRange(container, source,
                container->tileSlotStart, container->tileSlotStart, 0);
        } else if (container->type == CLONEMC_J_CONTAINER_BREWING &&
                   container->tileSlotStart >= 0) {
            if (source->itemID == 373)
                changed = CloneMCJ_Container_MergeRange(container, source,
                    container->tileSlotStart, container->tileSlotStart + 2, 0);
            else if (CloneMCJ_Progression_IsBrewingIngredient(source->itemID))
                changed = CloneMCJ_Container_MergeRange(container, source,
                    container->tileSlotStart + 3,
                    container->tileSlotStart + 3, 0);
        } else if ((container->type == CLONEMC_J_CONTAINER_CHEST ||
                    container->type == CLONEMC_J_CONTAINER_DISPENSER) &&
                   container->tileSlotStart >= 0) {
            changed = CloneMCJ_Container_MergeRange(container, source,
                container->tileSlotStart, container->tileSlotEnd, 0);
        }
        if (!changed) {
            if (slotNumber >= container->playerSlotStart &&
                slotNumber < container->hotbarSlotStart) {
                destinationFirst = container->hotbarSlotStart;
                destinationLast = container->hotbarSlotEnd;
            } else {
                destinationFirst = container->playerSlotStart;
                destinationLast = container->hotbarSlotStart - 1;
            }
            if (destinationFirst >= 0 && destinationLast >= destinationFirst)
                changed = CloneMCJ_Container_MergeRange(container, source,
                    destinationFirst, destinationLast, 0);
        }
    } else if (container->playerSlotStart >= 0) {
        changed = CloneMCJ_Container_MergeRange(container, source,
            container->playerSlotStart, container->hotbarSlotEnd, 1);
    }
    if (changed) {
        if(outputItemID>=0){outputCount=outputBefore-(CloneMCJ_ItemStack_IsEmpty(source)?0:source->stackSize);
            if(outputCount>0){container->lastSmeltedItemID=outputItemID;container->lastSmeltedCount=outputCount;++container->smeltedSerial;}}
        inventory->inventoryChanged = 1;
        ++container->mutationSerial;
        if (container->craftMatrix) CloneMCJ_Container_UpdateCraftResult(container);
    }
    return changed;
}

int CloneMCJ_Container_ClickEx(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, int slotNumber, int mouseButton,
    int shiftClick)
{
    CloneMCJ_ItemStack *slot;
    CloneMCJ_ItemStack temporary;
    int amount;
    int room;
    int limit;
    int outputItemID;
    int outputBefore;
    if (!container || !inventory) return 0;
    if (slotNumber == -999) {
        if (CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack) ||
            !CloneMCJ_ItemStack_IsEmpty(&container->lastDroppedStack)) return 0;
        if (mouseButton == 1)
            container->lastDroppedStack =
                CloneMCJ_ItemStack_Split(&inventory->carriedStack, 1);
        else {
            container->lastDroppedStack = inventory->carriedStack;
            CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
        }
        inventory->inventoryChanged = 1;
        ++container->mutationSerial;
        return 1;
    }
    if (slotNumber < 0 || slotNumber >= container->slotCount) return 0;
    if (shiftClick) return CloneMCJ_Container_QuickMove(container, inventory,
        slotNumber);
    if (slotNumber == container->resultSlot ||
        container->slotKind[slotNumber] == CLONEMC_J_SLOT_CRAFT_RESULT)
        return CloneMCJ_Container_TakeCraftResult(container, inventory);
    slot = container->slots[slotNumber];
    if (!slot) return 0;
    outputItemID=container->slotKind[slotNumber]==CLONEMC_J_SLOT_FURNACE_OUTPUT&&!CloneMCJ_ItemStack_IsEmpty(slot)?slot->itemID:-1;
    outputBefore=outputItemID>=0?slot->stackSize:0;
    limit = CloneMCJ_Container_EffectiveLimit(container, slotNumber,
        CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack) ?
        slot : &inventory->carriedStack);
    if (CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)) {
        if (CloneMCJ_ItemStack_IsEmpty(slot)) return 0;
        amount = mouseButton == 1 ? (slot->stackSize + 1) / 2 :
            slot->stackSize;
        inventory->carriedStack = CloneMCJ_ItemStack_Split(slot, amount);
    } else if (CloneMCJ_ItemStack_IsEmpty(slot)) {
        if (!CloneMCJ_Container_CanPlaceInSlot(container, slotNumber,
            &inventory->carriedStack)) return 0;
        amount = mouseButton == 1 ? 1 : inventory->carriedStack.stackSize;
        if (amount > limit) amount = limit;
        *slot = CloneMCJ_ItemStack_Split(&inventory->carriedStack, amount);
    } else if (CloneMCJ_ItemStack_IsStackableWith(slot,
               &inventory->carriedStack) &&
               CloneMCJ_Container_CanPlaceInSlot(container, slotNumber,
               &inventory->carriedStack)) {
        room = limit - slot->stackSize;
        amount = mouseButton == 1 ? 1 : inventory->carriedStack.stackSize;
        if (amount > room) amount = room;
        if (amount <= 0) return 0;
        slot->stackSize += amount;
        inventory->carriedStack.stackSize -= amount;
        if (inventory->carriedStack.stackSize <= 0)
            CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
    } else {
        if (!CloneMCJ_Container_CanPlaceInSlot(container, slotNumber,
            &inventory->carriedStack) ||
            inventory->carriedStack.stackSize > limit) return 0;
        temporary = *slot;
        *slot = inventory->carriedStack;
        inventory->carriedStack = temporary;
    }
    if(outputItemID>=0){int removed;removed=outputBefore-(CloneMCJ_ItemStack_IsEmpty(slot)?0:slot->stackSize);
        if(removed>0){container->lastSmeltedItemID=outputItemID;container->lastSmeltedCount=removed;++container->smeltedSerial;}}
    inventory->inventoryChanged = 1;
    ++container->mutationSerial;
    if (container->craftMatrix) CloneMCJ_Container_UpdateCraftResult(container);
    return 1;
}

int CloneMCJ_Container_Click(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, int slotNumber, int mouseButton)
{
    return CloneMCJ_Container_ClickEx(container, inventory, slotNumber,
        mouseButton, 0);
}

int CloneMCJ_Container_Close(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_ItemStack *leftovers,
    int leftoverCapacity)
{
    CloneMCJ_ItemStack *stack;
    int i;
    int count;
    int size;
    if (!container || !inventory) return 0;
    count = 0;
    if (container->craftMatrix) {
        size = CloneMCJ_InventoryCrafting_GetSize(container->craftMatrix);
        for (i = 0; i < size; ++i) {
            stack = CloneMCJ_InventoryCrafting_GetSlot(container->craftMatrix, i);
            if (!stack || CloneMCJ_ItemStack_IsEmpty(stack)) continue;
            CloneMCJ_InventoryPlayer_AddItemStack(inventory, stack);
            if (!CloneMCJ_ItemStack_IsEmpty(stack) && leftovers &&
                count < leftoverCapacity) {
                leftovers[count++] = *stack;
                CloneMCJ_ItemStack_Clear(stack);
            }
        }
        CloneMCJ_Container_UpdateCraftResult(container);
    }
    return count;
}

int CloneMCJ_Container_BeginTransactionWithId(CloneMCJ_Container *container,
    const CloneMCJ_InventoryPlayer *inventory, short transactionId)
{
    CloneMCJ_ContainerTransaction *transaction;
    int index;
    int i;
    if (!container || !inventory) return 0;
    index = ((unsigned short)transactionId) %
        CLONEMC_J_MAX_PENDING_TRANSACTIONS;
    transaction = &container->pending[index];
    /* Never overwrite an unacknowledged click merely because the bounded
     * ring wrapped.  Refusing one local prediction is safer than restoring
     * the wrong inventory state after a delayed server rejection. */
    if (transaction->active &&
        transaction->transactionId != transactionId) return 0;
    transaction->active = 1;
    transaction->transactionId = transactionId;
    transaction->carriedSnapshot = inventory->carriedStack;
    for (i = 0; i < container->slotCount; ++i) {
        if (container->slots[i]) transaction->slotSnapshot[i] =
            *container->slots[i];
        else CloneMCJ_ItemStack_Clear(&transaction->slotSnapshot[i]);
    }
    return 1;
}

short CloneMCJ_Container_BeginTransaction(CloneMCJ_Container *container,
    const CloneMCJ_InventoryPlayer *inventory)
{
    short transactionId;
    if (!container || !inventory) return (short)-1;
    transactionId = container->transactionId;
    ++container->transactionId;
    CloneMCJ_Container_BeginTransactionWithId(container, inventory,
        transactionId);
    return transactionId;
}

int CloneMCJ_Container_ResolveTransaction(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, short transactionId, int accepted)
{
    CloneMCJ_ContainerTransaction *transaction;
    int i;
    int index;
    if (!container || !inventory) return 0;
    index = ((unsigned short)transactionId) %
        CLONEMC_J_MAX_PENDING_TRANSACTIONS;
    transaction = &container->pending[index];
    if (!transaction->active ||
        transaction->transactionId != transactionId) return 0;
    if (!accepted) {
        for (i = 0; i < container->slotCount; ++i)
            if (container->slots[i])
                *container->slots[i] = transaction->slotSnapshot[i];
        inventory->carriedStack = transaction->carriedSnapshot;
        inventory->inventoryChanged = 1;
        if (container->craftMatrix) CloneMCJ_Container_UpdateCraftResult(container);
    }
    transaction->active = 0;
    return 1;
}

int CloneMCJ_Container_SetServerSlot(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, int slotNumber,
    const CloneMCJ_ItemStack *stack)
{
    if (!container || !inventory) return 0;
    if (slotNumber == -1) {
        if (stack) inventory->carriedStack = *stack;
        else CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
        inventory->inventoryChanged = 1;
        return 1;
    }
    if (slotNumber < 0 || slotNumber >= container->slotCount ||
        !container->slots[slotNumber]) return 0;
    if (stack) *container->slots[slotNumber] = *stack;
    else CloneMCJ_ItemStack_Clear(container->slots[slotNumber]);
    inventory->inventoryChanged = 1;
    if (container->craftMatrix) CloneMCJ_Container_UpdateCraftResult(container);
    return 1;
}

int CloneMCJ_Container_TakeDroppedStack(CloneMCJ_Container *container,
    CloneMCJ_ItemStack *stack)
{
    if (!container || !stack ||
        CloneMCJ_ItemStack_IsEmpty(&container->lastDroppedStack)) return 0;
    *stack = container->lastDroppedStack;
    CloneMCJ_ItemStack_Clear(&container->lastDroppedStack);
    return 1;
}

void CloneMCJ_Container_Register(void) { }
const char *CloneMCJ_Container_JavaName(void)
{ return "net.minecraft.src.Container"; }
const char *CloneMCJ_Container_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_Container_JavaSourceHash32(void)
{ return 0x89FFC37EUL; }
