/*
 * CloneMC Java port scaffold: BlockCactus
 *
 * Java source: BlockCactus.java
 * Java type: class BlockCactus
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 026146eefb1e8772616592c99e783d33a9828511e82cecbeb907c80892b34ba9
 * Java lines: 134
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: Block, Material, World, AxisAlignedBB, Entity, j, k, p
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockCactus(int i, int j)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k)
 * - public int getBlockTextureFromSide(int i)
 * - public boolean renderAsNormalBlock()
 * - public boolean isOpaqueCube()
 * - public int getRenderType()
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public boolean canBlockStay(World world, int i, int j, int k)
 * - public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
 *
 * Priority 11 directly ports Java age-15 growth, three-block height limit and
 * support/horizontal-neighbor survival rules.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_BlockCactus_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int height;
    int metadata;
    (void)random; (void)userData;
    if (!world || !CloneMCJ_World_IsAirBlock(world, x, y + 1, z)) return;
    height = 1;
    while (y - height >= 0 && CloneMCJ_World_GetBlockId(world, x, y - height, z) == blockID)
        ++height;
    if (height >= 3) return;
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (metadata == 15) {
        CloneMCJ_World_SetBlockNotify(world, x, y + 1, z, blockID);
        CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, 0);
    } else CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, metadata + 1);
}

static void CloneMCJ_BlockCactus_Neighbor(CloneMCJ_World *world, int x, int y,
    int z, int neighborID)
{
    (void)neighborID;
    if (!CloneMCJ_World_CanCactusStay(world, x, y, z)&&
        CloneMCJ_Block_TryDropAsItem(world,x,y,z))
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
}

void CloneMCJ_BlockCactus_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(81);
    if (block) { block->tickRandomly = 1; block->neighborChanged = CloneMCJ_BlockCactus_Neighbor; }
    CloneMCJ_World_RegisterBlockTick(world, 81, 1, CloneMCJ_BlockCactus_UpdateTick, 0);
}

void CloneMCJ_BlockCactus_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockCactus_JavaName(void)
{
    return "net.minecraft.src.BlockCactus";
}

const char *CloneMCJ_BlockCactus_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockCactus_JavaSourceHash32(void)
{
    return 0x026146EEUL;
}
