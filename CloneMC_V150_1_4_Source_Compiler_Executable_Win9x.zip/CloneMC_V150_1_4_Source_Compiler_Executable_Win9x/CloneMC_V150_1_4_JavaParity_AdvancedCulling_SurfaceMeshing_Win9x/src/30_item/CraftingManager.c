/*
 * Direct Open Watcom C89 port of CraftingManager.java.
 * The registry is fixed-size and allocation-free for Windows 98/2000 safety.
 */
#include "clonemc_java_port_30_item.h"
#include <string.h>
#include <stdlib.h>

static CloneMCJ_CraftingManagerNative g_cloneMCCraftingManager;

static const short g_cloneMCMainRecipeData[][25] = {
    {1, 339, 0, 3, 3, 1, 3, 338, 0, 338, 0, 338, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 340, 0, 1, 1, 3, 3, 339, 0, 339, 0, 339, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 85, 0, 2, 3, 2, 6, 280, 0, 280, 0, 280, 0, 280, 0, 280, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 84, 0, 1, 3, 3, 9, 5, -1, 5, -1, 5, -1, 5, -1, 264, 0, 5, -1, 5, -1, 5, -1, 5, -1},
    {1, 25, 0, 1, 3, 3, 9, 5, -1, 5, -1, 5, -1, 5, -1, 331, 0, 5, -1, 5, -1, 5, -1, 5, -1},
    {1, 47, 0, 1, 3, 3, 9, 5, -1, 5, -1, 5, -1, 340, 0, 340, 0, 340, 0, 5, -1, 5, -1, 5, -1},
    {1, 80, 0, 1, 2, 2, 4, 332, 0, 332, 0, 332, 0, 332, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 82, 0, 1, 2, 2, 4, 337, 0, 337, 0, 337, 0, 337, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 45, 0, 1, 2, 2, 4, 336, 0, 336, 0, 336, 0, 336, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 89, 0, 1, 2, 2, 4, 348, 0, 348, 0, 348, 0, 348, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 35, 0, 1, 2, 2, 4, 287, 0, 287, 0, 287, 0, 287, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 46, 0, 1, 3, 3, 9, 289, 0, 12, -1, 289, 0, 12, -1, 289, 0, 12, -1, 289, 0, 12, -1, 289, 0},
    {1, 44, 3, 3, 3, 1, 3, 4, -1, 4, -1, 4, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 44, 0, 3, 3, 1, 3, 1, -1, 1, -1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 44, 1, 3, 3, 1, 3, 24, -1, 24, -1, 24, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 44, 2, 3, 3, 1, 3, 5, -1, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 65, 0, 2, 3, 3, 9, 280, 0, 0, 0, 280, 0, 280, 0, 280, 0, 280, 0, 280, 0, 0, 0, 280, 0},
    {1, 324, 0, 1, 2, 3, 6, 5, -1, 5, -1, 5, -1, 5, -1, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0},
    {1, 96, 0, 2, 3, 2, 6, 5, -1, 5, -1, 5, -1, 5, -1, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0},
    {1, 330, 0, 1, 2, 3, 6, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 0, 0, 0, 0, 0, 0},
    {1, 323, 0, 1, 3, 3, 9, 5, -1, 5, -1, 5, -1, 5, -1, 5, -1, 5, -1, 0, 0, 280, 0, 0, 0},
    {1, 354, 0, 1, 3, 3, 9, 335, 0, 335, 0, 335, 0, 353, 0, 344, 0, 353, 0, 296, 0, 296, 0, 296, 0},
    {1, 353, 0, 1, 1, 1, 1, 338, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 5, 0, 4, 1, 1, 1, 17, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 280, 0, 4, 1, 2, 2, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 50, 0, 4, 1, 2, 2, 263, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 50, 0, 4, 1, 2, 2, 263, 1, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 281, 0, 4, 3, 2, 6, 5, -1, 0, 0, 5, -1, 0, 0, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 66, 0, 16, 3, 3, 9, 265, 0, 0, 0, 265, 0, 265, 0, 280, 0, 265, 0, 265, 0, 0, 0, 265, 0},
    {1, 27, 0, 6, 3, 3, 9, 266, 0, 0, 0, 266, 0, 266, 0, 280, 0, 266, 0, 266, 0, 331, 0, 266, 0},
    {1, 28, 0, 6, 3, 3, 9, 265, 0, 0, 0, 265, 0, 265, 0, 70, -1, 265, 0, 265, 0, 331, 0, 265, 0},
    {1, 328, 0, 1, 3, 2, 6, 265, 0, 0, 0, 265, 0, 265, 0, 265, 0, 265, 0, 0, 0, 0, 0, 0, 0},
    {1, 91, 0, 1, 1, 2, 2, 86, -1, 50, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 342, 0, 1, 1, 2, 2, 54, -1, 328, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 343, 0, 1, 1, 2, 2, 61, -1, 328, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 333, 0, 1, 3, 2, 6, 5, -1, 0, 0, 5, -1, 5, -1, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0},
    {1, 325, 0, 1, 3, 2, 6, 265, 0, 0, 0, 265, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 259, 0, 1, 2, 2, 4, 265, 0, 0, 0, 0, 0, 318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 297, 0, 1, 3, 1, 3, 296, 0, 296, 0, 296, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 53, 0, 4, 3, 3, 9, 5, -1, 0, 0, 0, 0, 5, -1, 5, -1, 0, 0, 5, -1, 5, -1, 5, -1},
    {1, 346, 0, 1, 3, 3, 9, 0, 0, 0, 0, 280, 0, 0, 0, 280, 0, 287, 0, 280, 0, 0, 0, 287, 0},
    {1, 67, 0, 4, 3, 3, 9, 4, -1, 0, 0, 0, 0, 4, -1, 4, -1, 0, 0, 4, -1, 4, -1, 4, -1},
    {1, 321, 0, 1, 3, 3, 9, 280, 0, 280, 0, 280, 0, 280, 0, 35, -1, 280, 0, 280, 0, 280, 0, 280, 0},
    {1, 322, 0, 1, 3, 3, 9, 41, -1, 41, -1, 41, -1, 41, -1, 260, 0, 41, -1, 41, -1, 41, -1, 41, -1},
    {1, 69, 0, 1, 1, 2, 2, 280, 0, 4, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 76, 0, 1, 1, 2, 2, 331, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 356, 0, 1, 3, 2, 6, 76, -1, 331, 0, 76, -1, 1, -1, 1, -1, 1, -1, 0, 0, 0, 0, 0, 0},
    {1, 347, 0, 1, 3, 3, 9, 0, 0, 266, 0, 0, 0, 266, 0, 331, 0, 266, 0, 0, 0, 266, 0, 0, 0},
    {1, 345, 0, 1, 3, 3, 9, 0, 0, 265, 0, 0, 0, 265, 0, 331, 0, 265, 0, 0, 0, 265, 0, 0, 0},
    {1, 358, 0, 1, 3, 3, 9, 339, 0, 339, 0, 339, 0, 339, 0, 345, 0, 339, 0, 339, 0, 339, 0, 339, 0},
    {1, 77, 0, 1, 1, 2, 2, 1, -1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 70, 0, 1, 2, 1, 2, 1, -1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 72, 0, 1, 2, 1, 2, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 23, 0, 1, 3, 3, 9, 4, -1, 4, -1, 4, -1, 4, -1, 261, 0, 4, -1, 4, -1, 331, 0, 4, -1},
    {1, 33, 0, 1, 3, 3, 9, 5, -1, 5, -1, 5, -1, 4, -1, 265, 0, 4, -1, 4, -1, 331, 0, 4, -1},
    {1, 29, 0, 1, 1, 2, 2, 341, 0, 33, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 355, 0, 1, 3, 2, 6, 35, -1, 35, -1, 35, -1, 5, -1, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0}
};

static int CloneMCJ_CraftingManager_RecipeCompare(const void *leftValue,
    const void *rightValue)
{
    const CloneMCJ_Recipe *left;
    const CloneMCJ_Recipe *right;
    int leftSize;
    int rightSize;
    left = (const CloneMCJ_Recipe *)leftValue;
    right = (const CloneMCJ_Recipe *)rightValue;
    if (left->shaped && !right->shaped) return -1;
    if (!left->shaped && right->shaped) return 1;
    leftSize = left->shaped ? left->width * left->height : left->ingredientCount;
    rightSize = right->shaped ? right->width * right->height : right->ingredientCount;
    if (rightSize != leftSize) return rightSize - leftSize;
    if (left->output.itemID != right->output.itemID)
        return left->output.itemID - right->output.itemID;
    return left->output.itemDamage - right->output.itemDamage;
}

static void CloneMCJ_CraftingManager_AddEncoded(const short data[25])
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int i;
    CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
    for (i = 0; i < CLONEMC_J_MAX_RECIPE_CELLS; ++i) {
        ingredients[i].itemID = data[7 + i * 2];
        ingredients[i].itemDamage = data[8 + i * 2];
    }
    if (data[0])
        CloneMCJ_CraftingManager_AddShapedNative(&output, data[4], data[5],
            ingredients);
    else
        CloneMCJ_CraftingManager_AddShapelessNative(&output, data[6], ingredients);
}

CloneMCJ_CraftingManagerNative *CloneMCJ_CraftingManager_GetInstanceNative(void)
{
    CloneMCJ_CraftingManager_InitializeNative();
    return &g_cloneMCCraftingManager;
}

int CloneMCJ_CraftingManager_AddShapedNative(const CloneMCJ_ItemStack *output,
    int width, int height, const CloneMCJ_RecipeIngredient *ingredients)
{
    CloneMCJ_Recipe *recipe;
    int count;
    int i;
    if (!output || !ingredients || width < 1 || width > 3 ||
        height < 1 || height > 3) return 0;
    count = width * height;
    if (g_cloneMCCraftingManager.recipeCount >= CLONEMC_J_MAX_RECIPES) return 0;
    recipe = &g_cloneMCCraftingManager.recipes[
        g_cloneMCCraftingManager.recipeCount++];
    memset(recipe, 0, sizeof(*recipe));
    recipe->output = *output;
    recipe->shaped = 1;
    recipe->width = (unsigned char)width;
    recipe->height = (unsigned char)height;
    recipe->ingredientCount = (unsigned char)count;
    for (i = 0; i < count; ++i) recipe->ingredients[i] = ingredients[i];
    return 1;
}

int CloneMCJ_CraftingManager_AddShapelessNative(const CloneMCJ_ItemStack *output,
    int count, const CloneMCJ_RecipeIngredient *ingredients)
{
    CloneMCJ_Recipe *recipe;
    int i;
    if (!output || !ingredients || count < 1 ||
        count > CLONEMC_J_MAX_RECIPE_CELLS) return 0;
    if (g_cloneMCCraftingManager.recipeCount >= CLONEMC_J_MAX_RECIPES) return 0;
    recipe = &g_cloneMCCraftingManager.recipes[
        g_cloneMCCraftingManager.recipeCount++];
    memset(recipe, 0, sizeof(*recipe));
    recipe->output = *output;
    recipe->shaped = 0;
    recipe->ingredientCount = (unsigned char)count;
    for (i = 0; i < count; ++i) recipe->ingredients[i] = ingredients[i];
    return 1;
}

void CloneMCJ_CraftingManager_InitializeNative(void)
{
    int i;
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    if (g_cloneMCCraftingManager.initialized) return;
    memset(&g_cloneMCCraftingManager, 0, sizeof(g_cloneMCCraftingManager));
    /* Preserve the Java constructor's registration order. */
    CloneMCJ_RecipesTools_AddNative();
    CloneMCJ_RecipesWeapons_AddNative();
    CloneMCJ_RecipesIngots_AddNative();
    CloneMCJ_RecipesFood_AddNative();
    CloneMCJ_RecipesCrafting_AddNative();
    CloneMCJ_RecipesArmor_AddNative();
    CloneMCJ_RecipesDyes_AddNative();
    for (i = 0; i < (int)(sizeof(g_cloneMCMainRecipeData) /
        sizeof(g_cloneMCMainRecipeData[0])); ++i)
        CloneMCJ_CraftingManager_AddEncoded(g_cloneMCMainRecipeData[i]);
    /* Release-era opt-in recipes.  Empty shaped cells use ID zero, matching
     * the converted Java recipe table above. */
    for(i=0;i<CLONEMC_J_MAX_RECIPE_CELLS;++i){
        ingredients[i].itemID=0;ingredients[i].itemDamage=0;
    }
    ingredients[1].itemID=340;
    ingredients[3].itemID=264;ingredients[4].itemID=49;
    ingredients[5].itemID=264;
    ingredients[6].itemID=49;ingredients[7].itemID=49;
    ingredients[8].itemID=49;
    CloneMCJ_ItemStack_Initialize(&output,116,1,0);
    CloneMCJ_CraftingManager_AddShapedNative(&output,3,3,ingredients);

    for(i=0;i<CLONEMC_J_MAX_RECIPE_CELLS;++i){
        ingredients[i].itemID=0;ingredients[i].itemDamage=0;
    }
    ingredients[1].itemID=369;
    ingredients[3].itemID=4;ingredients[4].itemID=4;
    ingredients[5].itemID=4;
    CloneMCJ_ItemStack_Initialize(&output,117,1,0);
    CloneMCJ_CraftingManager_AddShapedNative(&output,3,2,ingredients);

    for(i=0;i<CLONEMC_J_MAX_RECIPE_CELLS;++i){
        ingredients[i].itemID=0;ingredients[i].itemDamage=0;
    }
    ingredients[0].itemID=20;ingredients[2].itemID=20;
    ingredients[4].itemID=20;
    CloneMCJ_ItemStack_Initialize(&output,374,3,0);
    CloneMCJ_CraftingManager_AddShapedNative(&output,3,2,ingredients);

    ingredients[0].itemID=369;ingredients[0].itemDamage=0;
    CloneMCJ_ItemStack_Initialize(&output,377,2,0);
    CloneMCJ_CraftingManager_AddShapelessNative(&output,1,ingredients);
    ingredients[0].itemID=368;ingredients[0].itemDamage=0;
    ingredients[1].itemID=377;ingredients[1].itemDamage=0;
    CloneMCJ_ItemStack_Initialize(&output,381,1,0);
    CloneMCJ_CraftingManager_AddShapelessNative(&output,2,ingredients);
    ingredients[0].itemID=341;ingredients[1].itemID=377;
    CloneMCJ_ItemStack_Initialize(&output,378,1,0);
    CloneMCJ_CraftingManager_AddShapelessNative(&output,2,ingredients);
    ingredients[0].itemID=375;ingredients[1].itemID=353;
    ingredients[2].itemID=39;
    CloneMCJ_ItemStack_Initialize(&output,376,1,0);
    CloneMCJ_CraftingManager_AddShapelessNative(&output,3,ingredients);

    /* One gold ingot is reversible to nine nuggets.  The 1.0-era glistering
     * melon recipe was shapeless and used one nugget; eight nuggets was a
     * later 13w23a balance change and is intentionally not applied here. */
    ingredients[0].itemID=266;ingredients[0].itemDamage=0;
    CloneMCJ_ItemStack_Initialize(&output,371,9,0);
    CloneMCJ_CraftingManager_AddShapelessNative(&output,1,ingredients);
    for(i=0;i<9;++i){
        ingredients[i].itemID=371;ingredients[i].itemDamage=0;
    }
    CloneMCJ_ItemStack_Initialize(&output,266,1,0);
    CloneMCJ_CraftingManager_AddShapedNative(&output,3,3,ingredients);
    ingredients[0].itemID=360;ingredients[0].itemDamage=0;
    ingredients[1].itemID=371;ingredients[1].itemDamage=0;
    CloneMCJ_ItemStack_Initialize(&output,382,1,0);
    CloneMCJ_CraftingManager_AddShapelessNative(&output,2,ingredients);
    qsort(g_cloneMCCraftingManager.recipes,
        (size_t)g_cloneMCCraftingManager.recipeCount,
        sizeof(g_cloneMCCraftingManager.recipes[0]),
        CloneMCJ_CraftingManager_RecipeCompare);
    g_cloneMCCraftingManager.initialized = 1;
}

const CloneMCJ_Recipe *CloneMCJ_CraftingManager_FindMatchingRecipeNative(
    const CloneMCJ_InventoryCrafting *inventory, CloneMCJ_ItemStack *result)
{
    int i;
    const CloneMCJ_Recipe *recipe;
    CloneMCJ_CraftingManager_InitializeNative();
    if (result) CloneMCJ_ItemStack_Clear(result);
    if (!inventory) return (const CloneMCJ_Recipe *)0;
    for (i = 0; i < g_cloneMCCraftingManager.recipeCount; ++i) {
        recipe = &g_cloneMCCraftingManager.recipes[i];
        if ((recipe->shaped &&
             CloneMCJ_ShapedRecipes_MatchesNative(recipe, inventory)) ||
            (!recipe->shaped &&
             CloneMCJ_ShapelessRecipes_MatchesNative(recipe, inventory))) {
            if (result) *result = recipe->output;
            return recipe;
        }
    }
    return (const CloneMCJ_Recipe *)0;
}

static int CloneMCJ_CraftingManager_ContainerItemFor(int itemID)
{
    if (itemID == 326 || itemID == 327 || itemID == 335) return 325;
    return 0;
}

int CloneMCJ_CraftingManager_ConsumeRecipeNative(
    CloneMCJ_InventoryCrafting *inventory, const CloneMCJ_Recipe *recipe,
    CloneMCJ_ItemStack *leftovers, int *leftoverCount)
{
    int i;
    int size;
    int containerItem;
    int count;
    CloneMCJ_ItemStack *stack;
    CloneMCJ_ItemStack remainder;
    if (!inventory || !recipe) return 0;
    if ((recipe->shaped &&
         !CloneMCJ_ShapedRecipes_MatchesNative(recipe, inventory)) ||
        (!recipe->shaped &&
         !CloneMCJ_ShapelessRecipes_MatchesNative(recipe, inventory))) return 0;
    count = leftoverCount ? *leftoverCount : 0;
    if (count < 0) count = 0;
    size = CloneMCJ_InventoryCrafting_GetSize(inventory);
    for (i = 0; i < size; ++i) {
        stack = CloneMCJ_InventoryCrafting_GetSlot(inventory, i);
        if (!stack || CloneMCJ_ItemStack_IsEmpty(stack)) continue;
        containerItem = CloneMCJ_CraftingManager_ContainerItemFor(stack->itemID);
        --stack->stackSize;
        if (stack->stackSize <= 0) CloneMCJ_ItemStack_Clear(stack);
        if (containerItem > 0) {
            CloneMCJ_ItemStack_Initialize(&remainder, containerItem, 1, 0);
            if (CloneMCJ_ItemStack_IsEmpty(stack)) *stack = remainder;
            else if (leftovers && count < CLONEMC_J_MAX_RECIPE_CELLS)
                leftovers[count++] = remainder;
        }
    }
    ++inventory->changeSerial;
    if (leftoverCount) *leftoverCount = count;
    return 1;
}

int CloneMCJ_CraftingManager_GetRecipeCountNative(void)
{
    CloneMCJ_CraftingManager_InitializeNative();
    return g_cloneMCCraftingManager.recipeCount;
}

void CloneMCJ_CraftingManager_Register(void)
{
    CloneMCJ_CraftingManager_InitializeNative();
}
const char *CloneMCJ_CraftingManager_JavaName(void)
{ return "net.minecraft.src.CraftingManager"; }
const char *CloneMCJ_CraftingManager_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_CraftingManager_JavaSourceHash32(void)
{ return 0x013CD5B9UL; }
