/*
 * CloneMC Java port scaffold: ItemRecord
 *
 * Java source: ItemRecord.java
 * Java type: class ItemRecord
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: eacbdbb1b406d4d750a3f0a08b45f5b95ae60b8e991df0e5c63968bef79027a2
 * Java lines: 44
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, World, Block, BlockJukeBox, ItemStack, EntityPlayer, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final String recordName
 *
 * Java method/constructor inventory:
 * - protected ItemRecord(int i, String s)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

const char *CloneMCJ_ItemRecord_NameForIdNative(int itemID)
{
    switch(itemID){
    case 2256:return "13";case 2257:return "cat";
    case 2258:return "blocks";case 2259:return "chirp";
    case 2260:return "far";case 2261:return "mall";
    case 2262:return "mellohi";case 2263:return "stal";
    case 2264:return "strad";case 2265:return "ward";
    case 2266:return "11";default:return (const char *)0;
    }
}

int CloneMCJ_ItemRecord_UseNative(CloneMCJ_World *world,CloneMCJ_ItemStack *stack,
    int x,int y,int z)
{
    if(!world||!stack||CloneMCJ_ItemStack_IsEmpty(stack)||
       !CloneMCJ_ItemRecord_NameForIdNative(stack->itemID))return 0;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=84||
       CloneMCJ_World_GetBlockMetadata(world,x,y,z)!=0)return 0;
    if(world->multiplayerWorld)return 1;
    if(!CloneMCJ_BlockJukeBox_InsertNative(world,x,y,z,stack->itemID))return 0;
    --stack->stackSize;
    if(stack->stackSize<=0)CloneMCJ_ItemStack_Clear(stack);
    return 1;
}

void CloneMCJ_ItemRecord_Register(void)
{
    /* Item registry owns icons; native use behavior is exposed above. */
}

const char *CloneMCJ_ItemRecord_JavaName(void)
{
    return "net.minecraft.src.ItemRecord";
}

const char *CloneMCJ_ItemRecord_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemRecord_JavaSourceHash32(void)
{
    return 0xEACBDBB1UL;
}
