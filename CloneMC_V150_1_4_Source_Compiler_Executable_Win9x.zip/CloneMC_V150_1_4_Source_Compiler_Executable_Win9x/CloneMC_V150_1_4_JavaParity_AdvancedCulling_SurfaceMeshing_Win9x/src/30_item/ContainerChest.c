/*
 * Direct C89 port of ContainerChest.java, including deterministic double-chest
 * left/right inventory ordering supplied by the caller.
 */
#include "clonemc_java_port_30_item.h"

static void CloneMCJ_ContainerChest_AddPlayerSlots(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, int playerTop)
{
    int row;
    int column;
    int index;
    container->playerSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 9; ++column) {
            index = column + (row + 1) * 9;
            CloneMCJ_Container_AddTypedSlot(container,
                &inventory->mainInventory[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 8 + column * 18, playerTop + row * 18);
        }
    container->hotbarSlotStart = container->slotCount;
    for (column = 0; column < 9; ++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column], 64, CLONEMC_J_SLOT_NORMAL,
            -1, column, 8 + column * 18, playerTop + 58);
    container->hotbarSlotEnd = container->slotCount - 1;
    container->playerSlotEnd = container->hotbarSlotEnd;
}

void CloneMCJ_ContainerChest_InitializeDoubleNative(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_TileEntity *first,
    CloneMCJ_TileEntity *second)
{
    int i;
    int row;
    int rows;
    int tileCount;
    if (!container || !inventory || !first) return;
    CloneMCJ_Container_Initialize(container);
    container->type = CLONEMC_J_CONTAINER_CHEST;
    container->playerInventory = inventory;
    container->tileEntity = first;
    container->secondTileEntity = second;
    tileCount = first->itemCount;
    if (tileCount > CLONEMC_J_CHEST_INVENTORY_SIZE)
        tileCount = CLONEMC_J_CHEST_INVENTORY_SIZE;
    if (second) {
        i = second->itemCount;
        if (i > CLONEMC_J_CHEST_INVENTORY_SIZE)
            i = CLONEMC_J_CHEST_INVENTORY_SIZE;
        tileCount += i;
    }
    rows = (tileCount + 8) / 9;
    container->tileSlotStart = container->slotCount;
    for (i = 0; i < tileCount; ++i) {
        CloneMCJ_ItemStack *stack;
        if (i < first->itemCount) stack = &first->items[i];
        else stack = &second->items[i - first->itemCount];
        row = i / 9;
        CloneMCJ_Container_AddTypedSlot(container, stack, 64,
            CLONEMC_J_SLOT_NORMAL, -1, i, 8 + (i % 9) * 18,
            18 + row * 18);
    }
    container->tileSlotEnd = container->slotCount - 1;
    /*
     * ContainerChest.java:
     *   i = (inventoryRows - 4) * 18;
     *   player rows: 103 + row * 18 + i
     *   hotbar:      161 + i
     *
     * Reducing the first expression gives 31 + inventoryRows * 18.
     * The former 32 + rows * 18 value put every player slot one pixel below
     * the pixels drawn by GuiChest.  That was especially visible in a
     * six-row double chest: the highlight/click rectangle appeared to straddle
     * the slot border and clicks at the topmost slot pixel could miss.
     */
    CloneMCJ_ContainerChest_AddPlayerSlots(container, inventory,
        31 + rows * 18);
}

void CloneMCJ_ContainerChest_InitializeNative(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_TileEntity *tile)
{
    CloneMCJ_ContainerChest_InitializeDoubleNative(container, inventory,
        tile, (CloneMCJ_TileEntity *)0);
}

void CloneMCJ_ContainerChest_Register(void) { }
const char *CloneMCJ_ContainerChest_JavaName(void)
{ return "net.minecraft.src.ContainerChest"; }
const char *CloneMCJ_ContainerChest_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_ContainerChest_JavaSourceHash32(void)
{ return 0xAC5FDC2DUL; }
