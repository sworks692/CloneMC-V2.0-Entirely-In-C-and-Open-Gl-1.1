/*
 * Direct bounded C89 conversion of Beta BlockRedstoneWire.java.
 * Metadata 0..15 stores strength.  Propagation is iterative rather than
 * recursive, but preserves Java's cardinal/up-step/down-step strength rules
 * and temporarily disables wire power while looking for external sources.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

#define CLONEMC_J_REDSTONE_QUEUE 8192
static int g_cloneMCRedstoneQueueX[CLONEMC_J_REDSTONE_QUEUE];
static int g_cloneMCRedstoneQueueY[CLONEMC_J_REDSTONE_QUEUE];
static int g_cloneMCRedstoneQueueZ[CLONEMC_J_REDSTONE_QUEUE];
static int g_cloneMCRedstoneUpdating;
static int g_cloneMCRedstonePropagating;

int CloneMCJ_BlockRedstoneWire_IsUpdatingNative(void)
{
    return g_cloneMCRedstoneUpdating;
}

static int CloneMCJ_WireNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

int CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    int id;
    if(!world)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id==55)return 1;
    if(id==0)return 0;
    (void)side;
    /* BlockRedstoneWire.isPowerProviderOrWire returns true as soon as
     * canProvidePower() succeeds.  Repeaters therefore connect as ordinary
     * power providers; the later directional repeater branch in the decompiled
     * Java is unreachable for these blocks. */
    if(id==69||id==70||id==72||id==75||id==76||id==77||id==93||id==94)return 1;
    return 0;
}

int CloneMCJ_BlockRedstoneWire_IsPoweringToNative(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    int power;
    int west,east,north,south;
    if(!world||g_cloneMCRedstoneUpdating)return 0;
    power=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=55||power==0)return 0;
    if(side==1)return 1;
    west=CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x-1,y,z,1)||
        (!CloneMCJ_WireNormalCube(world,x-1,y,z)&&
         CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x-1,y-1,z,-1));
    east=CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x+1,y,z,3)||
        (!CloneMCJ_WireNormalCube(world,x+1,y,z)&&
         CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x+1,y-1,z,-1));
    north=CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x,y,z-1,2)||
        (!CloneMCJ_WireNormalCube(world,x,y,z-1)&&
         CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x,y-1,z-1,-1));
    south=CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x,y,z+1,0)||
        (!CloneMCJ_WireNormalCube(world,x,y,z+1)&&
         CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x,y-1,z+1,-1));
    if(!CloneMCJ_WireNormalCube(world,x,y+1,z)){
        if(CloneMCJ_WireNormalCube(world,x-1,y,z)&&
           CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x-1,y+1,z,-1))west=1;
        if(CloneMCJ_WireNormalCube(world,x+1,y,z)&&
           CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x+1,y+1,z,-1))east=1;
        if(CloneMCJ_WireNormalCube(world,x,y,z-1)&&
           CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x,y+1,z-1,-1))north=1;
        if(CloneMCJ_WireNormalCube(world,x,y,z+1)&&
           CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(world,x,y+1,z+1,-1))south=1;
    }
    if(!north&&!east&&!west&&!south&&side>=2&&side<=5)return 1;
    if(side==2&&north&&!west&&!east)return 1;
    if(side==3&&south&&!west&&!east)return 1;
    if(side==4&&west&&!north&&!south)return 1;
    return side==5&&east&&!north&&!south;
}

static int CloneMCJ_WireMaxAt(CloneMCJ_World *world,int x,int y,int z,int value)
{
    int candidate;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=55)return value;
    candidate=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    return candidate>value?candidate:value;
}

static void CloneMCJ_WireQueue(int *head,int *tail,int x,int y,int z)
{
    int i,pending;
    if(!head||!tail||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return;
    /* Only suppress cells which are still pending.  A processed cell must be
     * eligible for another relaxation after a neighbor changes; suppressing
     * against the complete historical array left long wires one pass behind
     * and made lamps/torches visibly alternate across later notifications. */
    if(*tail>=CLONEMC_J_REDSTONE_QUEUE&&*head>0){
        pending=*tail-*head;
        for(i=0;i<pending;++i){
            g_cloneMCRedstoneQueueX[i]=g_cloneMCRedstoneQueueX[*head+i];
            g_cloneMCRedstoneQueueY[i]=g_cloneMCRedstoneQueueY[*head+i];
            g_cloneMCRedstoneQueueZ[i]=g_cloneMCRedstoneQueueZ[*head+i];
        }
        *head=0;*tail=pending;
    }
    if(*tail>=CLONEMC_J_REDSTONE_QUEUE)return;
    for(i=*head;i<*tail;++i)
        if(g_cloneMCRedstoneQueueX[i]==x&&g_cloneMCRedstoneQueueY[i]==y&&
           g_cloneMCRedstoneQueueZ[i]==z)return;
    g_cloneMCRedstoneQueueX[*tail]=x;
    g_cloneMCRedstoneQueueY[*tail]=y;
    g_cloneMCRedstoneQueueZ[*tail]=z;
    ++*tail;
}

static void CloneMCJ_WireQueueConnected(CloneMCJ_World *world,int *head,int *tail,
    int x,int y,int z)
{
    static const signed char dx[4]={-1,1,0,0};
    static const signed char dz[4]={0,0,-1,1};
    int i,nx,nz,ny;
    CloneMCJ_WireQueue(head,tail,x,y,z);
    for(i=0;i<4;++i){
        nx=x+dx[i];nz=z+dz[i];ny=y;
        CloneMCJ_WireQueue(head,tail,nx,ny,nz);
        if(CloneMCJ_WireNormalCube(world,nx,y,nz)&&
           !CloneMCJ_WireNormalCube(world,x,y+1,z))
            CloneMCJ_WireQueue(head,tail,nx,y+1,nz);
        else if(!CloneMCJ_WireNormalCube(world,nx,y,nz))
            CloneMCJ_WireQueue(head,tail,nx,y-1,nz);
    }
}

static int CloneMCJ_WireDesiredStrength(CloneMCJ_World *world,int x,int y,int z)
{
    static const signed char dx[4]={-1,1,0,0};
    static const signed char dz[4]={0,0,-1,1};
    int i,nx,nz,maxPower,power;
    g_cloneMCRedstoneUpdating=1;
    power=CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y,z)?15:0;
    g_cloneMCRedstoneUpdating=0;
    if(power==15)return 15;
    maxPower=0;
    for(i=0;i<4;++i){
        nx=x+dx[i];nz=z+dz[i];
        maxPower=CloneMCJ_WireMaxAt(world,nx,y,nz,maxPower);
        if(CloneMCJ_WireNormalCube(world,nx,y,nz)&&
           !CloneMCJ_WireNormalCube(world,x,y+1,z))
            maxPower=CloneMCJ_WireMaxAt(world,nx,y+1,nz,maxPower);
        else if(!CloneMCJ_WireNormalCube(world,nx,y,nz))
            maxPower=CloneMCJ_WireMaxAt(world,nx,y-1,nz,maxPower);
    }
    return maxPower>0?maxPower-1:0;
}

static void CloneMCJ_BlockRedstoneWire_Propagate(CloneMCJ_World *world,
    int x,int y,int z)
{
    int head,tail,wx,wy,wz,oldPower,newPower;
    if(!world||world->multiplayerWorld||g_cloneMCRedstoneUpdating||
       g_cloneMCRedstonePropagating)return;
    g_cloneMCRedstonePropagating=1;
    head=0;tail=0;
    CloneMCJ_WireQueueConnected(world,&head,&tail,x,y,z);
    while(head<tail){
        wx=g_cloneMCRedstoneQueueX[head];
        wy=g_cloneMCRedstoneQueueY[head];
        wz=g_cloneMCRedstoneQueueZ[head];
        ++head;
        if(CloneMCJ_World_GetBlockId(world,wx,wy,wz)!=55)continue;
        if(!CloneMCJ_WireNormalCube(world,wx,wy-1,wz)){
            CloneMCJ_World_SetBlockNotify(world,wx,wy,wz,0);
            continue;
        }
        oldPower=CloneMCJ_World_GetBlockMetadata(world,wx,wy,wz);
        newPower=CloneMCJ_WireDesiredStrength(world,wx,wy,wz);
        if(newPower!=oldPower){
            world->editingBlocks=1;
            CloneMCJ_World_SetBlockMetadata(world,wx,wy,wz,newPower);
            world->editingBlocks=0;
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,wx,wy,wz,55);
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,wx,wy-1,wz,55);
            CloneMCJ_WireQueueConnected(world,&head,&tail,wx,wy,wz);
        }
    }
    g_cloneMCRedstonePropagating=0;
}

static void CloneMCJ_WireNotifyAt(CloneMCJ_World *world,int x,int y,int z)
{
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=55)return;
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z,55);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x-1,y,z,55);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x+1,y,z,55);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z-1,55);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z+1,55);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,55);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y+1,z,55);
}

static void CloneMCJ_WireNotifySurroundings(CloneMCJ_World *world,int x,int y,int z)
{
    static const signed char dx[4]={-1,1,0,0};
    static const signed char dz[4]={0,0,-1,1};
    int i,nx,nz;
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y+1,z,55);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,55);
    for(i=0;i<4;++i){
        nx=x+dx[i];nz=z+dz[i];
        CloneMCJ_WireNotifyAt(world,nx,y,nz);
        if(CloneMCJ_WireNormalCube(world,nx,y,nz))CloneMCJ_WireNotifyAt(world,nx,y+1,nz);
        else CloneMCJ_WireNotifyAt(world,nx,y-1,nz);
    }
}

static void CloneMCJ_BlockRedstoneWire_Added(CloneMCJ_World *world,int x,int y,int z)
{
    if(!world||world->multiplayerWorld)return;
    CloneMCJ_BlockRedstoneWire_Propagate(world,x,y,z);
    CloneMCJ_WireNotifySurroundings(world,x,y,z);
}

static void CloneMCJ_BlockRedstoneWire_Removed(CloneMCJ_World *world,int x,int y,int z)
{
    if(!world||world->multiplayerWorld)return;
    CloneMCJ_WireNotifySurroundings(world,x,y,z);
    CloneMCJ_BlockRedstoneWire_Propagate(world,x,y,z);
}

static void CloneMCJ_BlockRedstoneWire_Neighbor(CloneMCJ_World *world,
    int x,int y,int z,int neighborID)
{
    (void)neighborID;
    if(!world||world->multiplayerWorld)return;
    if(!CloneMCJ_WireNormalCube(world,x,y-1,z)){
        if(CloneMCJ_Block_TryDropAsItem(world,x,y,z))
            CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
        return;
    }
    CloneMCJ_BlockRedstoneWire_Propagate(world,x,y,z);
}

void CloneMCJ_BlockRedstoneWire_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(55);
    if(!block)return;
    block->solid=0;block->opaque=0;block->collidable=0;block->replaceable=0;
    block->lightOpacity=0;
    block->minX=0.0;block->minY=0.0;block->minZ=0.0;
    block->maxX=1.0;block->maxY=0.0625;block->maxZ=1.0;
    block->onBlockAdded=CloneMCJ_BlockRedstoneWire_Added;
    block->onBlockRemoved=CloneMCJ_BlockRedstoneWire_Removed;
    block->neighborChanged=CloneMCJ_BlockRedstoneWire_Neighbor;
}

void CloneMCJ_BlockRedstoneWire_Register(void){}
const char *CloneMCJ_BlockRedstoneWire_JavaName(void){return "net.minecraft.src.BlockRedstoneWire";}
const char *CloneMCJ_BlockRedstoneWire_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockRedstoneWire_JavaSourceHash32(void){return 0x971D26CCUL;}
