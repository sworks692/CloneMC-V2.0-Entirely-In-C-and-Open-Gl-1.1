/* Direct C89 conversion of Beta BlockLever.java. */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_LeverNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

int CloneMCJ_BlockLever_CanPlaceOnSideNative(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    if(!world)return 0;
    if(side==1)return CloneMCJ_LeverNormalCube(world,x,y-1,z);
    if(side==2)return CloneMCJ_LeverNormalCube(world,x,y,z+1);
    if(side==3)return CloneMCJ_LeverNormalCube(world,x,y,z-1);
    if(side==4)return CloneMCJ_LeverNormalCube(world,x+1,y,z);
    if(side==5)return CloneMCJ_LeverNormalCube(world,x-1,y,z);
    return 0;
}

int CloneMCJ_BlockLever_CanPlaceAtNative(CloneMCJ_World *world,int x,int y,int z)
{
    return CloneMCJ_LeverNormalCube(world,x-1,y,z)||
        CloneMCJ_LeverNormalCube(world,x+1,y,z)||
        CloneMCJ_LeverNormalCube(world,x,y-1,z)||
        CloneMCJ_LeverNormalCube(world,x,y,z-1)||
        CloneMCJ_LeverNormalCube(world,x,y,z+1);
}

static int CloneMCJ_LeverHasSupport(CloneMCJ_World *world,int x,int y,int z,int orientation)
{
    if(orientation==1)return CloneMCJ_LeverNormalCube(world,x-1,y,z);
    if(orientation==2)return CloneMCJ_LeverNormalCube(world,x+1,y,z);
    if(orientation==3)return CloneMCJ_LeverNormalCube(world,x,y,z-1);
    if(orientation==4)return CloneMCJ_LeverNormalCube(world,x,y,z+1);
    if(orientation==5||orientation==6)return CloneMCJ_LeverNormalCube(world,x,y-1,z);
    return 0;
}

static void CloneMCJ_LeverNotifyAttached(CloneMCJ_World *world,
    int x,int y,int z,int metadata)
{
    int orientation;
    if(!world)return;
    orientation=metadata&7;
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z,69);
    if(orientation==1)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x-1,y,z,69);
    else if(orientation==2)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x+1,y,z,69);
    else if(orientation==3)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z-1,69);
    else if(orientation==4)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z+1,69);
    else CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,69);
}

static void CloneMCJ_LeverNeighbor(CloneMCJ_World *world,int x,int y,int z,int neighborID)
{
    int metadata;
    (void)neighborID;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=69)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(!CloneMCJ_BlockLever_CanPlaceAtNative(world,x,y,z)||
       !CloneMCJ_LeverHasSupport(world,x,y,z,metadata&7)){
        if(metadata&8)CloneMCJ_LeverNotifyAttached(world,x,y,z,metadata);
        if(CloneMCJ_Block_TryDropAsItem(world,x,y,z))
            CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
    }
}

static void CloneMCJ_LeverRemoved(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata;
    if(!world)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(metadata&8)CloneMCJ_LeverNotifyAttached(world,x,y,z,metadata);
}

void CloneMCJ_BlockLever_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(69);
    if(!block)return;
    block->solid=0;block->opaque=0;block->collidable=0;
    block->minX=0.25;block->minY=0.0;block->minZ=0.25;
    block->maxX=0.75;block->maxY=0.6;block->maxZ=0.75;
    block->neighborChanged=CloneMCJ_LeverNeighbor;
    block->onBlockRemoved=CloneMCJ_LeverRemoved;
}

int CloneMCJ_BlockLever_OnPlacedNative(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    int metadata,orientation;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=69)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    orientation=-1;
    if(side==1&&CloneMCJ_LeverNormalCube(world,x,y-1,z))
        orientation=5+CloneMCJavaRandom_NextIntBound(&world->rand,2);
    if(side==2&&CloneMCJ_LeverNormalCube(world,x,y,z+1))orientation=4;
    if(side==3&&CloneMCJ_LeverNormalCube(world,x,y,z-1))orientation=3;
    if(side==4&&CloneMCJ_LeverNormalCube(world,x+1,y,z))orientation=2;
    if(side==5&&CloneMCJ_LeverNormalCube(world,x-1,y,z))orientation=1;
    if(orientation<0){CloneMCJ_World_SetBlockNotify(world,x,y,z,0);return 0;}
    return CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,
        orientation+(metadata&8));
}

int CloneMCJ_BlockLever_ActivateNative(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata,newMetadata;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=69)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    newMetadata=(metadata&7)+8-(metadata&8);
    if(!CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,newMetadata))return 0;
    CloneMCJ_LeverNotifyAttached(world,x,y,z,newMetadata);
    return 1;
}

void CloneMCJ_BlockLever_Register(void){}
const char *CloneMCJ_BlockLever_JavaName(void){return "net.minecraft.src.BlockLever";}
const char *CloneMCJ_BlockLever_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockLever_JavaSourceHash32(void){return 0x4A9DCCB0UL;}
