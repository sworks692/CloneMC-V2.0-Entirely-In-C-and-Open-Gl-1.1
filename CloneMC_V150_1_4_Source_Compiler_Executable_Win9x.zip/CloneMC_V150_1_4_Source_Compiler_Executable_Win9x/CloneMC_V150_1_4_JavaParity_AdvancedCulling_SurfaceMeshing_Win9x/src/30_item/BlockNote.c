/*
 * CloneMC Java port scaffold: BlockNote
 *
 * Java source: BlockNote.java
 * Java type: class BlockNote
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockContainer
 * Implements: (none declared)
 * Source SHA-256: 1c6868260e91ff3d2f374ed03f46b6557c9deb8a15b206e3b47b8b5262a05196
 * Java lines: 98
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: BlockContainer, Material, Block, World, TileEntityNote, EntityPlayer, TileEntity, j, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockNote(int i)
 * - public int getBlockTextureFromSide(int i)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - public void onBlockClicked(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - protected TileEntity getBlockEntity()
 * - public void playBlock(World world, int i, int j, int k, int l, int i1)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static CloneMCJ_TileEntity *CloneMCJ_BlockNote_GetTile(CloneMCJ_World *world,
    int x,int y,int z)
{
    CloneMCJ_Chunk *chunk;
    chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,
        CloneMCJ_World_GlobalToChunk(x),CloneMCJ_World_GlobalToChunk(z));
    return chunk?(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(
        chunk,x&15,y,z&15):(CloneMCJ_TileEntity *)0;
}

static int CloneMCJ_BlockNote_NeighborCanPower(int id)
{
    return id==55||id==69||id==70||id==72||id==76||id==77||id==94;
}

static void CloneMCJ_BlockNote_Neighbor(CloneMCJ_World *world,int x,int y,int z,
    int neighborID)
{
    CloneMCJ_TileEntity *tile;
    int powered;
    if(!world||world->multiplayerWorld||!CloneMCJ_BlockNote_NeighborCanPower(neighborID))return;
    tile=CloneMCJ_BlockNote_GetTile(world,x,y,z);
    if(!tile||tile->type!=CLONEMC_J_TILE_NOTE)return;
    powered=CloneMCJ_World_IsBlockGettingPowered(world,x,y,z);
    if((tile->previousRedstoneState?1:0)==powered)return;
    if(powered)CloneMCJ_TileEntityNote_TriggerNative(tile);
    tile->previousRedstoneState=(unsigned char)(powered?1:0);
}

int CloneMCJ_BlockNote_ActivateNative(CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_TileEntity *tile;
    if(!world)return 0;
    if(world->multiplayerWorld)return 1;
    tile=CloneMCJ_BlockNote_GetTile(world,x,y,z);
    if(!tile||tile->type!=CLONEMC_J_TILE_NOTE)return 0;
    CloneMCJ_TileEntityNote_ChangePitchNative(tile);
    return CloneMCJ_TileEntityNote_TriggerNative(tile);
}

int CloneMCJ_BlockNote_ClickNative(CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_TileEntity *tile;
    if(!world||world->multiplayerWorld)return 0;
    tile=CloneMCJ_BlockNote_GetTile(world,x,y,z);
    return tile?CloneMCJ_TileEntityNote_TriggerNative(tile):0;
}

void CloneMCJ_BlockNote_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(25);
    if(block)block->neighborChanged=CloneMCJ_BlockNote_Neighbor;
}

void CloneMCJ_BlockNote_Register(void)
{
    /* Registry behavior is installed by BlockSimulation_RegisterWorld. */
}

const char *CloneMCJ_BlockNote_JavaName(void)
{
    return "net.minecraft.src.BlockNote";
}

const char *CloneMCJ_BlockNote_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockNote_JavaSourceHash32(void)
{
    return 0x1C686826UL;
}
