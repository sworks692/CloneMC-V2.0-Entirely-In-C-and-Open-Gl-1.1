/* Direct C89 conversion of Beta BlockTrapDoor.java lifecycle and power behavior. */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_TrapDoorNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}
static int CloneMCJ_TrapDoorPowerProvider(int id)
{
    return id==55||id==69||id==70||id==72||id==75||id==76||id==77||id==93||id==94;
}
static int CloneMCJ_TrapDoorSupported(CloneMCJ_World *world,int x,int y,int z,int metadata)
{
    switch(metadata&3){
    case 0:return CloneMCJ_TrapDoorNormalCube(world,x,y,z+1);
    case 1:return CloneMCJ_TrapDoorNormalCube(world,x,y,z-1);
    case 2:return CloneMCJ_TrapDoorNormalCube(world,x+1,y,z);
    default:return CloneMCJ_TrapDoorNormalCube(world,x-1,y,z);
    }
}
static void CloneMCJ_TrapDoorNeighbor(CloneMCJ_World *world,int x,int y,int z,int neighborID)
{
    int metadata,powered;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=96)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(!CloneMCJ_TrapDoorSupported(world,x,y,z,metadata)){
        if(CloneMCJ_Block_TryDropAsItem(world,x,y,z))
            CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
        return;
    }
    if(CloneMCJ_TrapDoorPowerProvider(neighborID)){
        powered=CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y,z);
        if(((metadata&4)!=0)!=(powered!=0))
            CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,metadata^4);
    }
}
void CloneMCJ_BlockTrapDoor_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;(void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(96);
    if(block)block->neighborChanged=CloneMCJ_TrapDoorNeighbor;
}
int CloneMCJ_BlockTrapDoor_ActivateNative(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=96)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    return CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,metadata^4);
}
void CloneMCJ_BlockTrapDoor_Register(void){}
const char *CloneMCJ_BlockTrapDoor_JavaName(void){return "net.minecraft.src.BlockTrapDoor";}
const char *CloneMCJ_BlockTrapDoor_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockTrapDoor_JavaSourceHash32(void){return 0x9E77E16AUL;}
