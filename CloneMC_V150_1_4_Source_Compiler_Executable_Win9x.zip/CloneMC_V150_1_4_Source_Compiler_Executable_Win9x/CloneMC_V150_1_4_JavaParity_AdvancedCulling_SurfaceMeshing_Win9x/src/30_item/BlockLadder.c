/*
 * CloneMC Java port scaffold: BlockLadder
 *
 * Java source: BlockLadder.java
 * Java type: class BlockLadder
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 4606b96e75794b3a50524ad98bba68a364fcd70a1012126b98f7bfa11c8c9f93
 * Java lines: 153
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: Block, Material, World, AxisAlignedBB, j, f, i, return
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockLadder(int i, int j)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public int getRenderType()
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onBlockPlaced(World world, int i, int j, int k, int l)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public int quantityDropped(Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockLadder_NormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

int CloneMCJ_BlockLadder_CanPlaceOnSideNative(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    if(side==2)return CloneMCJ_BlockLadder_NormalCube(world,x,y,z+1);
    if(side==3)return CloneMCJ_BlockLadder_NormalCube(world,x,y,z-1);
    if(side==4)return CloneMCJ_BlockLadder_NormalCube(world,x+1,y,z);
    if(side==5)return CloneMCJ_BlockLadder_NormalCube(world,x-1,y,z);
    return 0;
}

static int CloneMCJ_BlockLadder_CanStay(CloneMCJ_World *world,int x,int y,int z,
    int metadata)
{
    return CloneMCJ_BlockLadder_CanPlaceOnSideNative(world,x,y,z,metadata);
}

static void CloneMCJ_BlockLadder_Neighbor(CloneMCJ_World *world,int x,int y,int z,
    int neighborID)
{
    int metadata;
    (void)neighborID;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=65)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(!CloneMCJ_BlockLadder_CanStay(world,x,y,z,metadata)&&
       CloneMCJ_Block_TryDropAsItem(world,x,y,z))
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
}

void CloneMCJ_BlockLadder_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(65);
    if(block)block->neighborChanged=CloneMCJ_BlockLadder_Neighbor;
}

void CloneMCJ_BlockLadder_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockLadder_JavaName(void)
{
    return "net.minecraft.src.BlockLadder";
}

const char *CloneMCJ_BlockLadder_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockLadder_JavaSourceHash32(void)
{
    return 0x4606B96EUL;
}
