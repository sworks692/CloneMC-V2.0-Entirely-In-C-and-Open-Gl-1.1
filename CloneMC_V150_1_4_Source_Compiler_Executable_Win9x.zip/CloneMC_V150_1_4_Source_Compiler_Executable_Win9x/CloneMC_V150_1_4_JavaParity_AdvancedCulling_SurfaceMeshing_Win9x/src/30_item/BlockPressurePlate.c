/*
 * CloneMC Java port scaffold: BlockPressurePlate
 *
 * Java source: BlockPressurePlate.java
 * Java type: class BlockPressurePlate
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: b1ee8c8c5c9b3cacbec195fa271bd1f1530dcfe6ed658801ea6880920d896738
 * Java lines: 206
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 18
 * Referenced Java classes: Block, World, EnumMobType, AxisAlignedBB, EntityLiving, EntityPlayer, IBlockAccess, Material, Entity, j, f, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private EnumMobType triggerMobType
 *
 * Java method/constructor inventory:
 * - protected BlockPressurePlate(int i, int j, EnumMobType enummobtype, Material material)
 * - public int tickRate()
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
 * - private void setStateIfMobInteractsWithPlate(World world, int i, int j, int k)
 * - public void onBlockRemoval(World world, int i, int j, int k)
 * - public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int i, int j, int k)
 * - public boolean isPoweringTo(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public boolean isIndirectlyPoweringTo(World world, int i, int j, int k, int l)
 * - public boolean canProvidePower()
 * - public void setBlockBoundsForItemRender()
 * - public int getMobilityFlag()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_PlateIntersects(const CloneMCJ_Entity *e,int x,int y,int z)
{CloneMCAxisAlignedBB box;if(!e||e->isDead)return 0;box=CloneMCAABB_Create(x+0.125,y,z+0.125,x+0.875,y+0.25,z+0.875);return CloneMCAABB_Intersects(&e->boundingBox,&box);}
static int CloneMCJ_PlateOccupied(CloneMCJ_World *w,int id,int x,int y,int z)
{CloneMCJ_GameplayState *g;int i;g=(CloneMCJ_GameplayState *)w->gameplayUserData;if(!g)return 0;if(CloneMCJ_PlateIntersects(&g->player.entity,x,y,z))return 1;for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(g->mobs[i].active&&CloneMCJ_PlateIntersects(&g->mobs[i].entity,x,y,z))return 1;if(id==72){for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(g->droppedItems[i].active&&CloneMCJ_PlateIntersects(&g->droppedItems[i].entity,x,y,z))return 1;for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(g->vehicles[i].active&&CloneMCJ_PlateIntersects(&g->vehicles[i].entity,x,y,z))return 1;for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(g->projectiles[i].active&&CloneMCJ_PlateIntersects(&g->projectiles[i].entity,x,y,z))return 1;}return 0;}
static int CloneMCJ_PlateNormalCube(CloneMCJ_World *w,int x,int y,int z)
{const CloneMCJ_BlockDefinition *b;int id;if(!w||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;id=CloneMCJ_World_GetLoadedBlockId(w,x,y,z);b=CloneMCJ_BlockRegistry_Get(id);return b&&b->opaque&&b->collidable;}
static void CloneMCJ_PlateUpdate(CloneMCJ_World *w,int x,int y,int z,int id)
{int old,on;if(!w||w->multiplayerWorld||CloneMCJ_World_GetLoadedBlockId(w,x,y,z)!=id)return;if(!CloneMCJ_PlateNormalCube(w,x,y-1,z)){if(CloneMCJ_Block_TryDropAsItem(w,x,y,z))CloneMCJ_World_SetBlockNotify(w,x,y,z,0);return;}old=CloneMCJ_World_GetLoadedBlockMetadata(w,x,y,z)>0;on=CloneMCJ_PlateOccupied(w,id,x,y,z);if(old!=on){CloneMCJ_World_SetBlockMetadataNotify(w,x,y,z,on?1:0);CloneMCJ_World_NotifyBlocksOfNeighborChange(w,x,y,z,id);CloneMCJ_World_NotifyBlocksOfNeighborChange(w,x,y-1,z,id);}if(on)CloneMCJ_World_ScheduleBlockUpdate(w,x,y,z,id,20);}
void CloneMCJ_BlockPressurePlate_EntityCollisionNative(CloneMCJ_World*w,int x,int y,int z)
{int id;if(!w||w->multiplayerWorld)return;id=CloneMCJ_World_GetLoadedBlockId(w,x,y,z);if((id==70||id==72)&&CloneMCJ_World_GetLoadedBlockMetadata(w,x,y,z)==0)CloneMCJ_PlateUpdate(w,x,y,z,id);}
static void CloneMCJ_PlateTick(CloneMCJ_World*w,int x,int y,int z,int id,CloneMCJavaRandom*r,void*u){(void)r;(void)u;CloneMCJ_PlateUpdate(w,x,y,z,id);}
static void CloneMCJ_PlateNeighbor(CloneMCJ_World*w,int x,int y,int z,int n){int id;(void)n;id=CloneMCJ_World_GetLoadedBlockId(w,x,y,z);if(id==70||id==72)CloneMCJ_PlateUpdate(w,x,y,z,id);}
static void CloneMCJ_PlateRemoved(CloneMCJ_World*w,int x,int y,int z)
{int metadata,id;if(!w)return;metadata=CloneMCJ_World_GetLoadedBlockMetadata(w,x,y,z);id=w->blockRemovalActive?w->removalOldBlockID:70;if(metadata>0){CloneMCJ_World_NotifyBlocksOfNeighborChange(w,x,y,z,id);CloneMCJ_World_NotifyBlocksOfNeighborChange(w,x,y-1,z,id);}}
void CloneMCJ_BlockPressurePlate_RegisterRuntime(CloneMCJ_World*w)
{
    int id;CloneMCJ_BlockDefinition*b;
    for(id=70;id<=72;id+=2){
        b=CloneMCJ_BlockRegistry_GetMutable(id);
        if(b){
            b->solid=0;b->opaque=0;b->collidable=0;
            b->minX=0.0625;b->minY=0.0;b->minZ=0.0625;
            b->maxX=0.9375;b->maxY=0.0625;b->maxZ=0.9375;
            b->neighborChanged=CloneMCJ_PlateNeighbor;
            b->onBlockRemoved=CloneMCJ_PlateRemoved;
        }
        CloneMCJ_World_RegisterBlockTick(w,id,1,CloneMCJ_PlateTick,0);
    }
}

void CloneMCJ_BlockPressurePlate_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockPressurePlate_JavaName(void)
{
    return "net.minecraft.src.BlockPressurePlate";
}

const char *CloneMCJ_BlockPressurePlate_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockPressurePlate_JavaSourceHash32(void)
{
    return 0xB1EE8C8CUL;
}
