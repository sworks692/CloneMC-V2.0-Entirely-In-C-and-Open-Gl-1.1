/*
 * Direct Open Watcom C89 port of Minecraft 1.2.3 BlockRedstoneLight.java.
 *
 * Block 123 is the idle lamp and block 124 is the lit lamp. Java performs
 * the transition immediately from both onBlockAdded and
 * onNeighborBlockChange. SetBlockNotify preserves that contract and routes
 * the emission change through CloneMC's bounded lighting queue.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_BlockRedstoneLight_Update(CloneMCJ_World *world,
    int x,int y,int z)
{
    int blockID;
    int powered;
    if(!world||world->multiplayerWorld)return;
    blockID=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(blockID!=123&&blockID!=124)return;
    powered=CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y,z);
    if(blockID==124&&!powered)
        CloneMCJ_World_SetBlockNotify(world,x,y,z,123);
    else if(blockID==123&&powered)
        CloneMCJ_World_SetBlockNotify(world,x,y,z,124);
}

static void CloneMCJ_BlockRedstoneLight_Added(CloneMCJ_World *world,
    int x,int y,int z)
{
    CloneMCJ_BlockRedstoneLight_Update(world,x,y,z);
}

static void CloneMCJ_BlockRedstoneLight_Neighbor(CloneMCJ_World *world,
    int x,int y,int z,int neighborID)
{
    (void)neighborID;
    CloneMCJ_BlockRedstoneLight_Update(world,x,y,z);
}

void CloneMCJ_BlockRedstoneLight_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    int id;
    (void)world;
    for(id=123;id<=124;++id){
        block=CloneMCJ_BlockRegistry_GetMutable(id);
        if(block){
            block->onBlockAdded=CloneMCJ_BlockRedstoneLight_Added;
            block->neighborChanged=CloneMCJ_BlockRedstoneLight_Neighbor;
        }
    }
}

