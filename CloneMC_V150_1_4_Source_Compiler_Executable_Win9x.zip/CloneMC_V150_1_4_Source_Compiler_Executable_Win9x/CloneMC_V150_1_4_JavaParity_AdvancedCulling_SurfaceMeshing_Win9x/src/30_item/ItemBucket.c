/* Direct C89 conversion of Beta ItemBucket.java. */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <math.h>

#define CLONEMC_BUCKET_PI 3.14159265358979323846

typedef struct CloneMCJ_BucketHitTag {int hit,x,y,z,side;} CloneMCJ_BucketHit;

static int CloneMCJ_ItemBucket_IsRayTarget(CloneMCJ_World *world,int x,int y,int z,int liquids)
{
    const CloneMCJ_BlockDefinition *block;int id;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id==0)return 0;
    if(id==8||id==9||id==10||id==11)return liquids;
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->collidable;
}

static CloneMCJ_BucketHit CloneMCJ_ItemBucket_RayTrace(CloneMCJ_World *world,
    CloneMCJ_EntityPlayer *player,int liquids)
{
    CloneMCJ_BucketHit result;
    double x,y,z,endX,endY,endZ,dx,dy,dz,tX,tY,tZ,stepX,stepY,stepZ;
    double boundaryX,boundaryY,boundaryZ;
    float yaw,pitch,cosPitch;
    int bx,by,bz,endBx,endBy,endBz,side,steps;
    result.hit=0;result.x=result.y=result.z=result.side=0;
    if(!world||!player)return result;
    x=player->entity.posX;
    y=player->entity.posY+1.62-(double)player->entity.yOffset;
    z=player->entity.posZ;
    yaw=(float)(-player->entity.rotationYaw*CLONEMC_BUCKET_PI/180.0-CLONEMC_BUCKET_PI);
    pitch=(float)(-player->entity.rotationPitch*CLONEMC_BUCKET_PI/180.0);
    cosPitch=(float)cos((double)pitch);
    /* ItemBucket.onItemRightClick uses the same view vector as
     * EntityPlayer.rayTrace: horizontal components are multiplied by
     * -cos(pitch).  The previous port omitted this minus sign, so the bucket
     * traced behind the player and appeared to do nothing. */
    dx=(double)(-sin((double)yaw)*cosPitch)*5.0;
    dy=(double)sin((double)pitch)*5.0;
    dz=(double)(-cos((double)yaw)*cosPitch)*5.0;
    endX=x+dx;endY=y+dy;endZ=z+dz;
    bx=CloneMCJava_FloorDouble(x);by=CloneMCJava_FloorDouble(y);bz=CloneMCJava_FloorDouble(z);
    endBx=CloneMCJava_FloorDouble(endX);endBy=CloneMCJava_FloorDouble(endY);endBz=CloneMCJava_FloorDouble(endZ);
    side=-1;
    for(steps=0;steps<200;++steps){
        if(CloneMCJ_ItemBucket_IsRayTarget(world,bx,by,bz,liquids)){
            result.hit=1;result.x=bx;result.y=by;result.z=bz;result.side=side<0?1:side;return result;
        }
        if(bx==endBx&&by==endBy&&bz==endBz)break;
        tX=tY=tZ=1.0e30;
        stepX=stepY=stepZ=0.0;
        if(endBx>bx){boundaryX=(double)(bx+1);tX=(boundaryX-x)/(endX-x);stepX=1.0;}
        else if(endBx<bx){boundaryX=(double)bx;tX=(boundaryX-x)/(endX-x);stepX=-1.0;}
        if(endBy>by){boundaryY=(double)(by+1);tY=(boundaryY-y)/(endY-y);stepY=1.0;}
        else if(endBy<by){boundaryY=(double)by;tY=(boundaryY-y)/(endY-y);stepY=-1.0;}
        if(endBz>bz){boundaryZ=(double)(bz+1);tZ=(boundaryZ-z)/(endZ-z);stepZ=1.0;}
        else if(endBz<bz){boundaryZ=(double)bz;tZ=(boundaryZ-z)/(endZ-z);stepZ=-1.0;}
        if(tX<tY&&tX<tZ){x+= (endX-x)*tX;y+=(endY-y)*tX;z+=(endZ-z)*tX;
            bx+=(int)stepX;side=stepX>0.0?4:5;}
        else if(tY<tZ){x+=(endX-x)*tY;y+=(endY-y)*tY;z+=(endZ-z)*tY;
            by+=(int)stepY;side=stepY>0.0?0:1;}
        else{x+=(endX-x)*tZ;y+=(endY-y)*tZ;z+=(endZ-z)*tZ;
            bz+=(int)stepZ;side=stepZ>0.0?2:3;}
        /* Nudge into the entered voxel so exact boundary coordinates cannot
         * select the same cell forever on old x87 math libraries. */
        x+=dx*1.0e-9;y+=dy*1.0e-9;z+=dz*1.0e-9;
    }
    return result;
}

static void CloneMCJ_ItemBucket_Offset(int side,int *x,int *y,int *z)
{
    if(side==0)--*y;else if(side==1)++*y;else if(side==2)--*z;
    else if(side==3)++*z;else if(side==4)--*x;else if(side==5)++*x;
}

int CloneMCJ_ItemBucket_UseNative(CloneMCJ_World *world,
    CloneMCJ_EntityPlayer *player,CloneMCJ_ItemStack *stack)
{
    CloneMCJ_BucketHit hit;
    const CloneMCJ_BlockDefinition *target;
    int id,blockID,metadata,x,y,z,placeID;
    if(!world||!player||CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    id=stack->itemID;
    if(id!=325&&id!=326&&id!=327)return 0;
    hit=CloneMCJ_ItemBucket_RayTrace(world,player,id==325);
    if(!hit.hit)return 0;
    blockID=CloneMCJ_World_GetBlockId(world,hit.x,hit.y,hit.z);
    metadata=CloneMCJ_World_GetBlockMetadata(world,hit.x,hit.y,hit.z);
    if(id==325){
        if(metadata!=0)return 0;
        if(blockID==8||blockID==9){
            if(!CloneMCJ_World_SetBlockNotify(world,hit.x,hit.y,hit.z,0))return 0;
            CloneMCJ_World_MarkMeshSectionUrgent(world,hit.x,hit.y,hit.z);
            stack->itemID=326;stack->stackSize=1;stack->itemDamage=0;return 1;
        }
        if(blockID==10||blockID==11){
            if(!CloneMCJ_World_SetBlockNotify(world,hit.x,hit.y,hit.z,0))return 0;
            CloneMCJ_World_MarkMeshSectionUrgent(world,hit.x,hit.y,hit.z);
            stack->itemID=327;stack->stackSize=1;stack->itemDamage=0;return 1;
        }
        return 0;
    }
    x=hit.x;y=hit.y;z=hit.z;CloneMCJ_ItemBucket_Offset(hit.side,&x,&y,&z);
    blockID=CloneMCJ_World_GetBlockId(world,x,y,z);
    target=CloneMCJ_BlockRegistry_Get(blockID);
    if(blockID!=0&&target&&target->solid)return 0;
    placeID=id==326?8:10;
    if(id==326&&world->worldProvider.isHellWorld){
        stack->itemID=325;stack->stackSize=1;stack->itemDamage=0;return 1;
    }
    if(!CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,placeID,0))return 0;
    CloneMCJ_World_MarkMeshSectionUrgent(world,x,y,z);
    stack->itemID=325;stack->stackSize=1;stack->itemDamage=0;return 1;
}

void CloneMCJ_ItemBucket_Register(void){}
const char *CloneMCJ_ItemBucket_JavaName(void){return "net.minecraft.src.ItemBucket";}
const char *CloneMCJ_ItemBucket_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_ItemBucket_JavaSourceHash32(void){return 0x8BE6E1FAUL;}
