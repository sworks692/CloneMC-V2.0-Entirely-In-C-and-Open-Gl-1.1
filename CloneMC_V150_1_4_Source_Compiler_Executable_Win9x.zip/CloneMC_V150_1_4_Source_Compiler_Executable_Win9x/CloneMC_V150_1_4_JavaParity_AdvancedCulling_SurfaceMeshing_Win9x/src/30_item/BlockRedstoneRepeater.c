/* Direct C89 conversion of Beta BlockRedstoneRepeater.java. */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static const unsigned char g_repeaterDelay[4]={1,2,3,4};

static int CloneMCJ_RepeaterNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

static int CloneMCJ_RepeaterCanStay(CloneMCJ_World *world,int x,int y,int z)
{
    return CloneMCJ_RepeaterNormalCube(world,x,y-1,z);
}

static int CloneMCJ_RepeaterInput(CloneMCJ_World *world,int x,int y,int z,int metadata)
{
    int direction,nx,nz,side,id;
    direction=metadata&3;nx=x;nz=z;side=0;
    if(direction==0){++nz;side=3;}
    else if(direction==2){--nz;side=2;}
    else if(direction==3){++nx;side=5;}
    else{--nx;side=4;}
    id=CloneMCJ_World_GetBlockId(world,nx,y,nz);
    if(id==55&&CloneMCJ_World_GetBlockMetadata(world,nx,y,nz)>0)return 1;
    return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,nx,y,nz,side);
}

static void CloneMCJ_RepeaterNotifyAll(CloneMCJ_World *world,int x,int y,int z,int id)
{
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x+1,y,z,id);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x-1,y,z,id);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z+1,id);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z-1,id);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,id);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y+1,z,id);
}

static void CloneMCJ_RepeaterTick(CloneMCJ_World *world,int x,int y,int z,
    int blockID,CloneMCJavaRandom *random,void *userData)
{
    int metadata,input;
    (void)random;(void)userData;
    if(!world||world->multiplayerWorld)return;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=blockID)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    input=CloneMCJ_RepeaterInput(world,x,y,z,metadata);
    if(blockID==94&&!input){
        CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,93,metadata);
        CloneMCJ_RepeaterNotifyAll(world,x,y,z,93);
    }else if(blockID==93){
        /* BlockRedstoneRepeater.updateTick always changes an idle repeater to
         * active when its scheduled tick arrives. If the input vanished while
         * waiting, Java schedules the active block to switch off after the same
         * selected delay, producing the authentic minimum pulse. */
        CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,94,metadata);
        CloneMCJ_RepeaterNotifyAll(world,x,y,z,94);
        if(!input){
            int delayIndex;
            delayIndex=(metadata&12)>>2;
            CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,94,
                g_repeaterDelay[delayIndex]*2);
        }
    }
}

static void CloneMCJ_RepeaterNeighbor(CloneMCJ_World *world,int x,int y,int z,int neighborID)
{
    int id,metadata,input,delay;
    (void)neighborID;
    if(!world)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id!=93&&id!=94)return;
    if(!CloneMCJ_RepeaterCanStay(world,x,y,z)){
        if(CloneMCJ_Block_TryDropAsItem(world,x,y,z))
            CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
        return;
    }
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    input=CloneMCJ_RepeaterInput(world,x,y,z,metadata);
    delay=g_repeaterDelay[(metadata>>2)&3]*2;
    if((id==94&&!input)||(id==93&&input))
        CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,id,delay);
}

static void CloneMCJ_RepeaterAdded(CloneMCJ_World *world,int x,int y,int z)
{
    int id;
    if(!world)return;
    /* BlockRedstoneRepeater.onBlockAdded only notifies the six neighbors.
     * The one-tick initial power check belongs to onBlockPlacedBy, not here:
     * active/idle state changes also invoke onBlockAdded and must not enqueue
     * a stale one-tick update for the replacement block. */
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    CloneMCJ_RepeaterNotifyAll(world,x,y,z,id);
}

void CloneMCJ_BlockRedstoneRepeater_OnPlacedByNative(CloneMCJ_World *world,
    int x,int y,int z)
{
    int id,metadata;
    if(!world)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id!=93&&id!=94)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(CloneMCJ_RepeaterInput(world,x,y,z,metadata))
        CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,id,1);
}

static void CloneMCJ_RepeaterRemoved(CloneMCJ_World *world,int x,int y,int z)
{
    if(world)CloneMCJ_RepeaterNotifyAll(world,x,y,z,93);
}

int CloneMCJ_BlockRedstoneRepeater_ActivateNative(CloneMCJ_World *world,
    int x,int y,int z)
{
    int id,metadata,delay;
    if(!world)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id!=93&&id!=94)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    delay=((((metadata&12)>>2)+1)<<2)&12;
    return CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,delay|(metadata&3));
}

void CloneMCJ_BlockRedstoneRepeater_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    int id;
    for(id=93;id<=94;++id){
        block=CloneMCJ_BlockRegistry_GetMutable(id);
        if(block){
            block->solid=0;block->opaque=0;block->collidable=0;
            block->minX=0.0;block->minY=0.0;block->minZ=0.0;
            block->maxX=1.0;block->maxY=0.125;block->maxZ=1.0;
            block->neighborChanged=CloneMCJ_RepeaterNeighbor;
            block->onBlockAdded=CloneMCJ_RepeaterAdded;
            block->onBlockRemoved=CloneMCJ_RepeaterRemoved;
        }
        CloneMCJ_World_RegisterBlockTick(world,id,0,CloneMCJ_RepeaterTick,0);
    }
}

void CloneMCJ_BlockRedstoneRepeater_Register(void){}
const char *CloneMCJ_BlockRedstoneRepeater_JavaName(void){return "net.minecraft.src.BlockRedstoneRepeater";}
const char *CloneMCJ_BlockRedstoneRepeater_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockRedstoneRepeater_JavaSourceHash32(void){return 0xAE7E3CE5UL;}
