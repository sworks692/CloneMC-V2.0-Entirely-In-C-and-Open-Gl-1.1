/* Direct bounded C89 port of Minecraft 1.2.3 TileEntityDispenser.java. */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_TileEntityDispenser_MarkDirty(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_Chunk *chunk;
    if(!tile||!tile->worldObj)return;
    chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(tile->worldObj,
        tile->xCoord>>4,tile->zCoord>>4);
    if(chunk)CloneMCJ_Chunk_SetModified(chunk);
}

int CloneMCJ_TileEntityDispenser_GetRandomStack(CloneMCJ_TileEntity *tile,
    CloneMCJ_ItemStack *out)
{
    int selected,occupied,slot;
    if(!tile||!out||tile->type!=CLONEMC_J_TILE_DISPENSER)return 0;
    CloneMCJ_ItemStack_Clear(out);
    selected=-1;occupied=1;
    /* Java reservoir sampling: every occupied slot has equal probability,
     * without an allocation or a temporary list. */
    for(slot=0;slot<9;++slot)
        if(!CloneMCJ_ItemStack_IsEmpty(&tile->items[slot])&&
           CloneMCJavaRandom_NextIntBound(&tile->dispenserRandom,occupied++)==0)
            selected=slot;
    if(selected<0)return 0;
    *out=CloneMCJ_ItemStack_Split(&tile->items[selected],1);
    CloneMCJ_TileEntityDispenser_MarkDirty(tile);
    return !CloneMCJ_ItemStack_IsEmpty(out);
}

void CloneMCJ_TileEntityDispenser_Register(void)
{
    /* Runtime behavior is installed per world by BlockDispenser. */
}

const char *CloneMCJ_TileEntityDispenser_JavaName(void)
{
    return "net.minecraft.src.TileEntityDispenser";
}

const char *CloneMCJ_TileEntityDispenser_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_TileEntityDispenser_JavaSourceHash32(void)
{
    return 0x714E75E8UL;
}
