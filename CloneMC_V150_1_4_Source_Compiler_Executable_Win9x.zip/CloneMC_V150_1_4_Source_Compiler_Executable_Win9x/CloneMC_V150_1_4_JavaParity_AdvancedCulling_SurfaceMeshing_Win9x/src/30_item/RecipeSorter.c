/*
 * RecipeSorter.java ordering is implemented in CraftingManager.c. This file
 * contains deterministic Priority 13 compatibility tests exercised at startup.
 */
#include "clonemc_java_port_30_item.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <stdio.h>
#include <string.h>

static int CloneMCJ_Priority13_Fail(char *error, int errorSize,
    const char *message)
{
    if (error && errorSize > 0) {
        strncpy(error, message, (size_t)errorSize - 1U);
        error[errorSize - 1] = '\0';
    }
    return 0;
}

int CloneMCJ_Priority13_RunSelfTests(char *error, int errorSize)
{
    CloneMCJ_InventoryPlayer player;
    CloneMCJ_InventoryCrafting matrix;
    CloneMCJ_InventoryCraftResult result;
    CloneMCJ_Container container;
    CloneMCJ_ItemStack stack;
    CloneMCJ_ItemStack output;
    CloneMCJ_ItemStack *slot;
    CloneMCJ_TileEntity *furnace;
    CloneMCJ_TileEntity *loadedTile;
    CloneMCJ_TileEntity *chestFirst;
    CloneMCJ_TileEntity *chestSecond;
    CloneMCJ_NBTTagCompound *compound;
    const CloneMCJ_Recipe *recipe;
    short transaction;
    int size;

    if (error && errorSize > 0) error[0] = '\0';
    CloneMCJ_ItemRegistry_Initialize();
    CloneMCJ_CraftingManager_InitializeNative();
    if (CloneMCJ_CraftingManager_GetRecipeCountNative() != 151)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: expected 151 Beta recipes");

    CloneMCJ_InventoryCrafting_Initialize(&matrix, 2, 2);
    CloneMCJ_ItemStack_Initialize(&stack, 17, 1, 0);
    CloneMCJ_InventoryCrafting_SetSlot(&matrix, 0, &stack);
    recipe = CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix, &output);
    if (!recipe || output.itemID != 5 || output.stackSize != 4)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: log-to-planks recipe mismatch");

    CloneMCJ_InventoryCrafting_Initialize(&matrix, 3, 3);
    CloneMCJ_ItemStack_Initialize(&stack, 5, 1, 0);
    CloneMCJ_InventoryCrafting_SetSlot(&matrix, 2, &stack);
    CloneMCJ_InventoryCrafting_SetSlot(&matrix, 5, &stack);
    recipe = CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix, &output);
    if (!recipe || output.itemID != 280 || output.stackSize != 4)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: shaped offset recipe mismatch");

    /* Exact CraftingManager.java redstone component recipes. */
    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[0],280,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[3],4,1,0);
    recipe=CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix,&output);
    if(!recipe||output.itemID!=69||output.stackSize!=1)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: Java lever recipe mismatch");

    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[3],76,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[4],331,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[5],76,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[6],1,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[7],1,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[8],1,1,0);
    recipe=CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix,&output);
    if(!recipe||output.itemID!=356||output.stackSize!=1)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: Java redstone repeater recipe mismatch");

    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[0],1,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[3],1,1,0);
    recipe=CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix,&output);
    if(!recipe||output.itemID!=77||output.stackSize!=1)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: Java stone button recipe mismatch");

    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[0],1,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[1],1,1,0);
    recipe=CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix,&output);
    if(!recipe||output.itemID!=70||output.stackSize!=1)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: Java stone pressure-plate recipe mismatch");

    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[0],5,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[1],5,1,0);
    recipe=CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix,&output);
    if(!recipe||output.itemID!=72||output.stackSize!=1)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: Java wooden pressure-plate recipe mismatch");

    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[0],5,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[1],5,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[2],5,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[3],4,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[4],265,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[5],4,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[6],4,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[7],331,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[8],4,1,0);
    recipe=CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix,&output);
    if(!recipe||output.itemID!=33||output.stackSize!=1)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: Java piston recipe mismatch");

    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[0],341,1,0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[3],33,1,0);
    recipe=CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix,&output);
    if(!recipe||output.itemID!=29||output.stackSize!=1)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: Java sticky-piston recipe mismatch");

    CloneMCJ_InventoryCrafting_Clear(&matrix);
    CloneMCJ_ItemStack_Initialize(&stack, 351, 1, 1);
    CloneMCJ_InventoryCrafting_SetSlot(&matrix, 0, &stack);
    CloneMCJ_ItemStack_Initialize(&stack, 351, 1, 15);
    CloneMCJ_InventoryCrafting_SetSlot(&matrix, 8, &stack);
    recipe = CloneMCJ_CraftingManager_FindMatchingRecipeNative(&matrix, &output);
    if (!recipe || output.itemID != 351 || output.itemDamage != 9 ||
        output.stackSize != 2)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: shapeless dye recipe mismatch");

    CloneMCJ_InventoryPlayer_Initialize(&player);
    CloneMCJ_ContainerPlayer_InitializeNative(&container, &player, &matrix,
        &result);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[0], 5, 1, 0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[1], 5, 1, 0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[2], 5, 1, 0);
    CloneMCJ_ItemStack_Initialize(&matrix.stackList[3], 5, 1, 0);
    CloneMCJ_Container_UpdateCraftResult(&container);
    if (result.result.itemID != 58)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: player crafting result did not refresh");
    if (!CloneMCJ_Container_Click(&container, &player,
        container.resultSlot, 0) ||
        player.carriedStack.itemID != 58 ||
        player.carriedStack.stackSize != 1)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: result-slot pickup failed");
    if (!CloneMCJ_ItemStack_IsEmpty(&matrix.stackList[0]) ||
        !CloneMCJ_ItemStack_IsEmpty(&result.result))
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: ingredients were not consumed");

    CloneMCJ_ItemStack_Clear(&player.carriedStack);
    CloneMCJ_ItemStack_Initialize(&player.carriedStack, 1, 1, 0);
    if (CloneMCJ_Container_Click(&container, &player, 5, 0))
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: armor slot accepted stone");
    CloneMCJ_ItemStack_Initialize(&player.carriedStack, 298, 1, 0);
    if (!CloneMCJ_Container_Click(&container, &player, 5, 0) ||
        player.armorInventory[3].itemID != 298)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: armor slot rejected helmet");

    CloneMCJ_ItemStack_Clear(&player.armorInventory[3]);
    CloneMCJ_ItemStack_Initialize(&player.mainInventory[9], 306, 1, 0);
    if (!CloneMCJ_Container_QuickMove(&container, &player,
        container.playerSlotStart) || player.armorInventory[3].itemID != 306 ||
        !CloneMCJ_ItemStack_IsEmpty(&player.mainInventory[9]))
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: shift-click armor auto-equip failed");

    CloneMCJ_ItemStack_Clear(&player.armorInventory[3]);
    CloneMCJ_ItemStack_Initialize(&player.mainInventory[0],298,1,0);
    if(!CloneMCJ_ItemArmor_EquipRightClickNative(&player,
        &player.mainInventory[0])||
        player.armorInventory[3].itemID!=298||
        !CloneMCJ_ItemStack_IsEmpty(&player.mainInventory[0]))
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: right-click helmet equip failed");
    CloneMCJ_ItemStack_Initialize(&player.mainInventory[0],299,1,0);
    if(!CloneMCJ_ItemArmor_EquipRightClickNative(&player,
        &player.mainInventory[0])||
        player.armorInventory[2].itemID!=299)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: right-click chestplate equip failed");
    CloneMCJ_ItemStack_Initialize(&player.mainInventory[0],300,1,0);
    if(!CloneMCJ_ItemArmor_EquipRightClickNative(&player,
        &player.mainInventory[0])||
        player.armorInventory[1].itemID!=300)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: right-click leggings equip failed");
    CloneMCJ_ItemStack_Initialize(&player.mainInventory[0],301,1,0);
    if(!CloneMCJ_ItemArmor_EquipRightClickNative(&player,
        &player.mainInventory[0])||
        player.armorInventory[0].itemID!=301)
        return CloneMCJ_Priority13_Fail(error,errorSize,
            "Priority13: right-click boots equip failed");

    CloneMCJ_ItemStack_Initialize(&player.mainInventory[9], 4, 8, 0);
    transaction = CloneMCJ_Container_BeginTransaction(&container, &player);
    slot = container.slots[container.playerSlotStart];
    size = slot ? slot->stackSize : -1;
    if (!CloneMCJ_Container_Click(&container, &player,
        container.playerSlotStart, 0))
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: transaction click failed");
    if (!CloneMCJ_Container_ResolveTransaction(&container, &player,
        transaction, 0) || !slot || slot->stackSize != size)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: rejected transaction did not roll back");

    furnace = CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_FURNACE,
        (struct CloneMCJ_WorldTag *)0, 0, 0, 0);
    if (!furnace)
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: furnace allocation failed");
    CloneMCJ_ItemStack_Initialize(&furnace->items[0], 56, 1, 0);
    CloneMCJ_ItemStack_Initialize(&furnace->items[1], 263, 1, 0);
    if (!CloneMCJ_FurnaceRecipes_CanSmeltNative(furnace, &output) ||
        output.itemID != 264 ||
        !CloneMCJ_FurnaceRecipes_SmeltOneNative(furnace) ||
        furnace->items[2].itemID != 264) {
        CloneMCJ_TileEntity_Destroy(furnace);
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: furnace recipe execution failed");
    }
    furnace->furnaceBurnTime = 77;
    furnace->currentItemBurnTime = 1600;
    furnace->furnaceCookTime = 91;
    compound = CloneMCJ_NBTTagCompound_Create();
    if (!compound || !CloneMCJ_TileEntity_WriteNBT(furnace, compound)) {
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);
        CloneMCJ_TileEntity_Destroy(furnace);
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: furnace NBT write failed");
    }
    loadedTile = CloneMCJ_TileEntity_ReadNBT(compound,
        (struct CloneMCJ_WorldTag *)0);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);
    if (!loadedTile || loadedTile->type != CLONEMC_J_TILE_FURNACE ||
        loadedTile->items[2].itemID != 264 ||
        loadedTile->furnaceBurnTime != 77 ||
        loadedTile->furnaceCookTime != 91) {
        CloneMCJ_TileEntity_Destroy(loadedTile);
        CloneMCJ_TileEntity_Destroy(furnace);
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: furnace NBT round-trip failed");
    }
    CloneMCJ_TileEntity_Destroy(loadedTile);
    CloneMCJ_TileEntity_Destroy(furnace);

    chestFirst = CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_CHEST,
        (struct CloneMCJ_WorldTag *)0, 10, 64, 10);
    chestSecond = CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_CHEST,
        (struct CloneMCJ_WorldTag *)0, 11, 64, 10);
    if (!chestFirst || !chestSecond) {
        CloneMCJ_TileEntity_Destroy(chestFirst);
        CloneMCJ_TileEntity_Destroy(chestSecond);
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: chest allocation failed");
    }
    CloneMCJ_ItemStack_Initialize(&chestFirst->items[0], 264, 3, 0);
    CloneMCJ_ItemStack_Initialize(&chestSecond->items[26], 351, 7, 4);
    CloneMCJ_ContainerChest_InitializeDoubleNative(&container, &player,
        chestFirst, chestSecond);
    if (container.tileSlotStart != 0 || container.tileSlotEnd != 53 ||
        container.slotCount != 90 || container.slots[0] != &chestFirst->items[0] ||
        container.slots[53] != &chestSecond->items[26] ||
        container.playerSlotStart != 54 || container.hotbarSlotStart != 81 ||
        container.slotX[54] != 8 || container.slotY[54] != 139 ||
        container.slotX[80] != 152 || container.slotY[80] != 175 ||
        container.slotX[81] != 8 || container.slotY[81] != 197 ||
        container.slotX[89] != 152 || container.slotY[89] != 197) {
        CloneMCJ_TileEntity_Destroy(chestFirst);
        CloneMCJ_TileEntity_Destroy(chestSecond);
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: double chest ordering/layout failed");
    }
    compound = CloneMCJ_NBTTagCompound_Create();
    if (!compound || !CloneMCJ_TileEntity_WriteNBT(chestSecond, compound)) {
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);
        CloneMCJ_TileEntity_Destroy(chestFirst);
        CloneMCJ_TileEntity_Destroy(chestSecond);
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: chest NBT write failed");
    }
    loadedTile = CloneMCJ_TileEntity_ReadNBT(compound,
        (struct CloneMCJ_WorldTag *)0);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);
    if (!loadedTile || loadedTile->type != CLONEMC_J_TILE_CHEST ||
        loadedTile->items[26].itemID != 351 ||
        loadedTile->items[26].stackSize != 7 ||
        loadedTile->items[26].itemDamage != 4) {
        CloneMCJ_TileEntity_Destroy(loadedTile);
        CloneMCJ_TileEntity_Destroy(chestFirst);
        CloneMCJ_TileEntity_Destroy(chestSecond);
        return CloneMCJ_Priority13_Fail(error, errorSize,
            "Priority13: chest NBT round-trip failed");
    }
    CloneMCJ_TileEntity_Destroy(loadedTile);
    CloneMCJ_TileEntity_Destroy(chestFirst);
    CloneMCJ_TileEntity_Destroy(chestSecond);

    if (error && errorSize > 0) {
        const char *successMessage;
        successMessage =
            "Priority13 OK: 151 recipes, redstone recipes, right-click armor, containers, rollback, NBT";
        strncpy(error, successMessage, (size_t)errorSize - 1U);
        error[errorSize - 1] = '\0';
    }
    return 1;
}

void CloneMCJ_RecipeSorter_Register(void) { }
const char *CloneMCJ_RecipeSorter_JavaName(void)
{ return "net.minecraft.src.RecipeSorter"; }
const char *CloneMCJ_RecipeSorter_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipeSorter_JavaSourceHash32(void)
{ return 0x345686F5UL; }
