/*
 * CloneMC Java port scaffold: ItemHoe
 *
 * Java source: ItemHoe.java
 * Java type: class ItemHoe
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 4197ee612921e4f69c06526004f3ecdba71079bb260b9298473a6ec95ecce3c8
 * Java lines: 50
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Item, EnumToolMaterial, World, Block, BlockGrass, StepSound, ItemStack, EntityPlayer, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemHoe(int i, EnumToolMaterial enumtoolmaterial)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 * - public boolean isFull3D()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"

int CloneMCJ_ItemHoe_UseNative(CloneMCJ_World *world,CloneMCJ_ItemStack *stack,
    CloneMCJ_EntityPlayer *player,int x,int y,int z,int side)
{
    int blockID;
    int aboveID;
    if(!world||!stack||!player||CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    if(stack->itemID<290||stack->itemID>294)return 0;
    blockID=CloneMCJ_World_GetBlockId(world,x,y,z);
    aboveID=CloneMCJ_World_GetBlockId(world,x,y+1,z);
    /* ItemHoe.java intentionally evaluates && before ||:
     * (side != 0 && above == air && block == grass) || block == dirt. */
    if(!((side!=0&&aboveID==0&&blockID==2)||blockID==3))return 0;
    if(!CloneMCJ_World_SetBlockNotify(world,x,y,z,60))return 0;
    CloneMCJ_World_MarkMeshSectionUrgent(world,x,y,z);
    CloneMCJ_ItemStack_Damage(stack,1);
    player->lastActivatedBlockID=60;
    player->lastActivatedMetadata=0;
    player->lastActivatedX=x;player->lastActivatedY=y;player->lastActivatedZ=z;
    ++player->blocksActivated;
    player->inventory.inventoryChanged=1;
    return 1;
}

void CloneMCJ_ItemHoe_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemHoe_JavaName(void)
{
    return "net.minecraft.src.ItemHoe";
}

const char *CloneMCJ_ItemHoe_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemHoe_JavaSourceHash32(void)
{
    return 0x4197EE61UL;
}
