/*
 * CloneMC Java port scaffold: BlockTorch
 *
 * Java source: BlockTorch.java
 * Java type: class BlockTorch
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 600f86f1217514f38a51c13a3852f3d9ec6fcb2d67a60d67acc5bed319e514ae
 * Java lines: 236
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 14
 * Referenced Java classes: Block, Material, World, AxisAlignedBB, Vec3D, MovingObjectPosition, j, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockTorch(int i, int j)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public int getRenderType()
 * - private boolean func_31032_h(World world, int i, int j, int k)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onBlockPlaced(World world, int i, int j, int k, int l)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - private boolean dropTorchIfCantStay(World world, int i, int j, int k)
 * - public MovingObjectPosition collisionRayTrace(World world, int i, int j, int k, Vec3D vec3d, Vec3D vec3d1)
 * - public void randomDisplayTick(World world, int i, int j, int k, Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockTorch_NormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

int CloneMCJ_BlockTorch_CanPlaceOnSideNative(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    if(side==1)return CloneMCJ_BlockTorch_NormalCube(world,x,y-1,z)||
        CloneMCJ_World_GetBlockId(world,x,y-1,z)==85;
    if(side==2)return CloneMCJ_BlockTorch_NormalCube(world,x,y,z+1);
    if(side==3)return CloneMCJ_BlockTorch_NormalCube(world,x,y,z-1);
    if(side==4)return CloneMCJ_BlockTorch_NormalCube(world,x+1,y,z);
    if(side==5)return CloneMCJ_BlockTorch_NormalCube(world,x-1,y,z);
    return 0;
}

int CloneMCJ_BlockTorch_CanPlaceAtNative(CloneMCJ_World *world,int x,int y,int z)
{
    return CloneMCJ_BlockTorch_CanPlaceOnSideNative(world,x,y,z,1)||
        CloneMCJ_BlockTorch_CanPlaceOnSideNative(world,x,y,z,2)||
        CloneMCJ_BlockTorch_CanPlaceOnSideNative(world,x,y,z,3)||
        CloneMCJ_BlockTorch_CanPlaceOnSideNative(world,x,y,z,4)||
        CloneMCJ_BlockTorch_CanPlaceOnSideNative(world,x,y,z,5);
}

int CloneMCJ_BlockTorch_CanStayNative(CloneMCJ_World *world,int x,int y,int z,
    int metadata)
{
    if(metadata==1)return CloneMCJ_BlockTorch_NormalCube(world,x-1,y,z);
    if(metadata==2)return CloneMCJ_BlockTorch_NormalCube(world,x+1,y,z);
    if(metadata==3)return CloneMCJ_BlockTorch_NormalCube(world,x,y,z-1);
    if(metadata==4)return CloneMCJ_BlockTorch_NormalCube(world,x,y,z+1);
    if(metadata==5)return CloneMCJ_BlockTorch_NormalCube(world,x,y-1,z)||
        CloneMCJ_World_GetBlockId(world,x,y-1,z)==85;
    return 0;
}

static void CloneMCJ_BlockTorch_Added(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=50)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(metadata==0){
        if(CloneMCJ_BlockTorch_NormalCube(world,x-1,y,z))metadata=1;
        else if(CloneMCJ_BlockTorch_NormalCube(world,x+1,y,z))metadata=2;
        else if(CloneMCJ_BlockTorch_NormalCube(world,x,y,z-1))metadata=3;
        else if(CloneMCJ_BlockTorch_NormalCube(world,x,y,z+1))metadata=4;
        else if(CloneMCJ_BlockTorch_CanPlaceOnSideNative(world,x,y,z,1))metadata=5;
        if(metadata)CloneMCJ_World_SetBlockMetadata(world,x,y,z,metadata);
    }
    if(!CloneMCJ_BlockTorch_CanStayNative(world,x,y,z,metadata)&&
       CloneMCJ_Block_TryDropAsItem(world,x,y,z))
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
}

static void CloneMCJ_BlockTorch_Neighbor(CloneMCJ_World *world,int x,int y,int z,
    int neighborID)
{
    int metadata;
    (void)neighborID;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=50)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(!CloneMCJ_BlockTorch_CanStayNative(world,x,y,z,metadata)&&
       CloneMCJ_Block_TryDropAsItem(world,x,y,z))
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
}

void CloneMCJ_BlockTorch_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(50);
    if(!block)return;
    block->onBlockAdded=CloneMCJ_BlockTorch_Added;
    block->neighborChanged=CloneMCJ_BlockTorch_Neighbor;
}

void CloneMCJ_BlockTorch_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockTorch_JavaName(void)
{
    return "net.minecraft.src.BlockTorch";
}

const char *CloneMCJ_BlockTorch_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockTorch_JavaSourceHash32(void)
{
    return 0x600F86F1UL;
}
