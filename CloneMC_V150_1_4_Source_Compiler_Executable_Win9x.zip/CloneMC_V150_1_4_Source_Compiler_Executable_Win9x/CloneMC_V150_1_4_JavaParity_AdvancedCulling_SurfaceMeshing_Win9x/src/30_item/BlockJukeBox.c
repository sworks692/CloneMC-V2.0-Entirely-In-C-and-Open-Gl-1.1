/*
 * CloneMC Java port scaffold: BlockJukeBox
 *
 * Java source: BlockJukeBox.java
 * Java type: class BlockJukeBox
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockContainer
 * Implements: (none declared)
 * Source SHA-256: 33c736ba3d08c3ff56727135146cb4efbc593b5a9bd53cdeb8b22541e6bc6c0b
 * Java lines: 106
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: BlockContainer, Material, World, TileEntityRecordPlayer, EntityItem, ItemStack, EntityPlayer, TileEntity, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockJukeBox(int i, int j)
 * - public int getBlockTextureFromSide(int i)
 * - public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - public void ejectRecord(World world, int i, int j, int k, int l)
 * - public void func_28038_b_(World world, int i, int j, int k)
 * - public void onBlockRemoval(World world, int i, int j, int k)
 * - public void dropBlockAsItemWithChance(World world, int i, int j, int k, int l, float f)
 * - protected TileEntity getBlockEntity()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"

static CloneMCJ_TileEntity *CloneMCJ_BlockJukeBox_GetTile(CloneMCJ_World *world,
    int x,int y,int z)
{
    CloneMCJ_Chunk *chunk;
    chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,
        CloneMCJ_World_GlobalToChunk(x),CloneMCJ_World_GlobalToChunk(z));
    return chunk?(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(
        chunk,x&15,y,z&15):(CloneMCJ_TileEntity *)0;
}

int CloneMCJ_BlockJukeBox_InsertNative(CloneMCJ_World *world,
    int x,int y,int z,int recordID)
{
    CloneMCJ_TileEntity *tile;
    CloneMCJ_GameplayState *gameplay;
    const char *name;
    if(!world||world->multiplayerWorld||CloneMCJ_World_GetBlockId(world,x,y,z)!=84||
       CloneMCJ_World_GetBlockMetadata(world,x,y,z)!=0)return 0;
    name=CloneMCJ_ItemRecord_NameForIdNative(recordID);
    tile=CloneMCJ_BlockJukeBox_GetTile(world,x,y,z);
    if(!name||!tile||tile->type!=CLONEMC_J_TILE_RECORD_PLAYER)return 0;
    tile->record=recordID;
    CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,1);
    gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(gameplay)CloneMCJ_Gameplay_QueueAudioEvent(gameplay,name,
        (float)x+0.5F,(float)y+0.5F,(float)z+0.5F,4.0F,1.0F,1);
    return 1;
}

int CloneMCJ_BlockJukeBox_EjectNative(CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_TileEntity *tile;
    CloneMCJ_GameplayState *gameplay;
    CloneMCJ_ItemStack stack;
    double dx,dy,dz;
    int recordID;
    if(!world||world->multiplayerWorld)return 0;
    tile=CloneMCJ_BlockJukeBox_GetTile(world,x,y,z);
    if(!tile||tile->type!=CLONEMC_J_TILE_RECORD_PLAYER||tile->record<=0)return 0;
    recordID=tile->record;tile->record=0;
    gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(gameplay){
        CloneMCJ_Gameplay_QueueAudioEvent(gameplay,(const char *)0,
            (float)x+0.5F,(float)y+0.5F,(float)z+0.5F,0.0F,1.0F,1);
        dx=(double)x+(double)(CloneMCJavaRandom_NextFloat(&world->rand)*0.7F)+0.15;
        dy=(double)y+(double)(CloneMCJavaRandom_NextFloat(&world->rand)*0.7F)+0.66;
        dz=(double)z+(double)(CloneMCJavaRandom_NextFloat(&world->rand)*0.7F)+0.15;
        CloneMCJ_ItemStack_Initialize(&stack,recordID,1,0);
        CloneMCJ_Gameplay_SpawnDrop(gameplay,dx,dy,dz,&stack,10,0);
    }
    if(CloneMCJ_World_GetBlockId(world,x,y,z)==84)
        CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,0);
    return 1;
}

int CloneMCJ_BlockJukeBox_ActivateNative(CloneMCJ_World *world,int x,int y,int z)
{
    if(!world)return 0;
    if(CloneMCJ_World_GetBlockMetadata(world,x,y,z)==0)return 0;
    if(world->multiplayerWorld)return 1;
    return CloneMCJ_BlockJukeBox_EjectNative(world,x,y,z);
}

static void CloneMCJ_BlockJukeBox_Removed(CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_BlockJukeBox_EjectNative(world,x,y,z);
}

void CloneMCJ_BlockJukeBox_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(84);
    if(block)block->onBlockRemoved=CloneMCJ_BlockJukeBox_Removed;
}

void CloneMCJ_BlockJukeBox_Register(void)
{
    /* Registry behavior is installed by BlockSimulation_RegisterWorld. */
}

const char *CloneMCJ_BlockJukeBox_JavaName(void)
{
    return "net.minecraft.src.BlockJukeBox";
}

const char *CloneMCJ_BlockJukeBox_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockJukeBox_JavaSourceHash32(void)
{
    return 0x33C736BAUL;
}
