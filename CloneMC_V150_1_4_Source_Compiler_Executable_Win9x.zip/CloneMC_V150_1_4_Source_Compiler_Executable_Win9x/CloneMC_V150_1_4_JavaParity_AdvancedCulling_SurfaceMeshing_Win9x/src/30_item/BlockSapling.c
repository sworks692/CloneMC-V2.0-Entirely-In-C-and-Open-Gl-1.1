/*
 * CloneMC Java port scaffold: BlockSapling
 *
 * Java source: BlockSapling.java
 * Java type: class BlockSapling
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockFlower
 * Implements: (none declared)
 * Source SHA-256: cbc031cf2ff99107d17e50a748a8b9744cd6cd237ba99e93dc04903a1379bbc3
 * Java lines: 90
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: BlockFlower, World, WorldGenTaiga2, WorldGenForest, WorldGenTrees, WorldGenBigTree, WorldGenerator, i, j, k, random, world.
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockSapling(int i, int j)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public void growTree(World world, int i, int j, int k, Random random)
 * - protected int damageDropped(int i)
 *
 * Priority 11 directly implements Java sapling staging and selection of the
 * existing taiga, forest, normal and big-tree generators below.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

int CloneMCJ_BlockSapling_GrowTree(CloneMCJ_World *world, int x, int y, int z,
    CloneMCJavaRandom *random)
{
    int type;
    int generated;
    if (!world || !random || CloneMCJ_World_GetBlockId(world, x, y, z) != 6) return 0;
    type = CloneMCJ_World_GetBlockMetadata(world, x, y, z) & 3;
    CloneMCJ_World_SetBlock(world, x, y, z, 0);
    if (type == 1) generated = CloneMCJ_WorldGenTaiga2_Generate(world, random, x, y, z);
    else if (type == 2) generated = CloneMCJ_WorldGenForest_Generate(world, random, x, y, z);
    else if (CloneMCJavaRandom_NextIntBound(random, 10) == 0)
        generated = CloneMCJ_WorldGenBigTree_Generate(world, random, x, y, z);
    else generated = CloneMCJ_WorldGenTrees_Generate(world, random, x, y, z);
    if (!generated) CloneMCJ_World_SetBlockWithMetadata(world, x, y, z, 6, type);
    else CloneMCJ_World_NotifyBlocksOfNeighborChange(world, x, y, z,
        CloneMCJ_World_GetBlockId(world, x, y, z));
    return generated;
}

static void CloneMCJ_BlockSapling_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int metadata;
    int below;
    (void)blockID; (void)userData;
    if (!world || !random || world->multiplayerWorld) return;
    below = CloneMCJ_World_GetBlockId(world, x, y - 1, z);
    if (below != 2 && below != 3 && below != 60) {
        if(CloneMCJ_Block_TryDropAsItem(world,x,y,z))
            CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
        return;
    }
    if (CloneMCJ_World_GetBlockLightValue(world, x, y + 1, z) >= 9 &&
        CloneMCJavaRandom_NextIntBound(random, 30) == 0) {
        metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
        if ((metadata & 8) == 0)
            CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, metadata | 8);
        else CloneMCJ_BlockSapling_GrowTree(world, x, y, z, random);
    }
}

void CloneMCJ_BlockSapling_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(6);
    if (block) block->tickRandomly = 1;
    CloneMCJ_World_RegisterBlockTick(world, 6, 1, CloneMCJ_BlockSapling_UpdateTick, 0);
}

void CloneMCJ_BlockSapling_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockSapling_JavaName(void)
{
    return "net.minecraft.src.BlockSapling";
}

const char *CloneMCJ_BlockSapling_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockSapling_JavaSourceHash32(void)
{
    return 0xCBC031CFUL;
}
