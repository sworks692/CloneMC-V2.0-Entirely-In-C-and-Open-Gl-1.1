/*
 * CloneMC Java port scaffold: TileEntityNote
 *
 * Java source: TileEntityNote.java
 * Java type: class TileEntityNote
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: TileEntity
 * Implements: (none declared)
 * Source SHA-256: ed688ff2eee7cca0fa57d2a41e2fda0e00079bfd34d6e8c693394aa8611aebb3
 * Java lines: 76
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: TileEntity, NBTTagCompound, World, Material, j, k, byte0
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public byte note
 * - public boolean previousRedstoneState
 *
 * Java method/constructor inventory:
 * - public TileEntityNote()
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - public void changePitch()
 * - public void triggerNote(World world, int i, int j, int k)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include <math.h>

void CloneMCJ_TileEntityNote_ChangePitchNative(CloneMCJ_TileEntity *tile)
{
    if(!tile||tile->type!=CLONEMC_J_TILE_NOTE)return;
    tile->note=(unsigned char)((tile->note+1U)%25U);
}

int CloneMCJ_TileEntityNote_TriggerNative(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_GameplayState *gameplay;
    const CloneMCJ_BlockDefinition *below;
    const char *sound;
    float pitch;
    int instrument,belowID;
    if(!tile||tile->type!=CLONEMC_J_TILE_NOTE||!tile->worldObj)return 0;
    if(CloneMCJ_World_GetBlockId(tile->worldObj,tile->xCoord,
        tile->yCoord+1,tile->zCoord)!=0)return 0;
    belowID=CloneMCJ_World_GetBlockId(tile->worldObj,tile->xCoord,
        tile->yCoord-1,tile->zCoord);
    below=CloneMCJ_BlockRegistry_Get(belowID);
    instrument=0;
    if(below){
        if(below->material==CLONEMC_J_MATERIAL_ROCK)instrument=1;
        else if(below->material==CLONEMC_J_MATERIAL_SAND)instrument=2;
        else if(below->material==CLONEMC_J_MATERIAL_GLASS)instrument=3;
        else if(below->material==CLONEMC_J_MATERIAL_WOOD)instrument=4;
    }
    sound=instrument==1?"note.bd":instrument==2?"note.snare":
        instrument==3?"note.hat":instrument==4?"note.bassattack":"note.harp";
    pitch=(float)pow(2.0,((double)(int)tile->note-12.0)/12.0);
    gameplay=(CloneMCJ_GameplayState *)tile->worldObj->gameplayUserData;
    if(gameplay)CloneMCJ_Gameplay_QueueAudioEvent(gameplay,sound,
        (float)tile->xCoord+0.5F,(float)tile->yCoord+0.5F,
        (float)tile->zCoord+0.5F,3.0F,pitch,0);
    return 1;
}

void CloneMCJ_TileEntityNote_Register(void)
{
    /* Runtime behavior is exposed through the native helpers above. */
}

const char *CloneMCJ_TileEntityNote_JavaName(void)
{
    return "net.minecraft.src.TileEntityNote";
}

const char *CloneMCJ_TileEntityNote_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_TileEntityNote_JavaSourceHash32(void)
{
    return 0xED688FF2UL;
}
