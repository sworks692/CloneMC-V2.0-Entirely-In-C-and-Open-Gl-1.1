/* Direct C89 conversion of Beta BlockDoor.java lifecycle and power behavior. */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockDoor_IsNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

static int CloneMCJ_BlockDoor_CanProvidePower(int id)
{
    return id==55||id==69||id==70||id==72||id==75||id==76||id==77||
        id==93||id==94;
}

static void CloneMCJ_BlockDoor_SetPowered(CloneMCJ_World *world,int x,int y,int z,int powered)
{
    int id,metadata,lowerY,upper,opened,newMetadata;
    if(!world)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id!=64&&id!=71)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    lowerY=(metadata&8)?y-1:y;
    if(CloneMCJ_World_GetBlockId(world,x,lowerY,z)!=id)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,lowerY,z);
    opened=(metadata&4)!=0;
    if(opened==(powered!=0))return;
    newMetadata=metadata^4;
    if(CloneMCJ_World_GetBlockId(world,x,lowerY+1,z)==id){
        upper=CloneMCJ_World_GetBlockMetadata(world,x,lowerY+1,z);
        CloneMCJ_World_SetBlockMetadataNotify(world,x,lowerY+1,z,
            (upper&3)|(newMetadata&4)|8);
    }
    CloneMCJ_World_SetBlockMetadataNotify(world,x,lowerY,z,newMetadata&7);
}

static void CloneMCJ_BlockDoor_Neighbor(CloneMCJ_World *world,int x,int y,int z,int neighborID)
{
    int id,metadata,lowerY;
    if(!world)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id!=64&&id!=71)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(metadata&8){
        if(CloneMCJ_World_GetBlockId(world,x,y-1,z)!=id)
            CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
        else if(CloneMCJ_BlockDoor_CanProvidePower(neighborID))
            CloneMCJ_BlockDoor_Neighbor(world,x,y-1,z,neighborID);
        return;
    }
    lowerY=y;
    if(CloneMCJ_World_GetBlockId(world,x,lowerY+1,z)!=id){
        if(CloneMCJ_Block_TryDropAsItem(world,x,lowerY,z))
            CloneMCJ_World_SetBlockNotify(world,x,lowerY,z,0);
        return;
    }
    if(!CloneMCJ_BlockDoor_IsNormalCube(world,x,lowerY-1,z)){
        if(!CloneMCJ_Block_TryDropAsItem(world,x,lowerY,z))return;
        CloneMCJ_World_SetBlockNotify(world,x,lowerY,z,0);
        if(CloneMCJ_World_GetBlockId(world,x,lowerY+1,z)==id)
            CloneMCJ_World_SetBlockNotify(world,x,lowerY+1,z,0);
        return;
    }
    if(CloneMCJ_BlockDoor_CanProvidePower(neighborID))
        CloneMCJ_BlockDoor_SetPowered(world,x,lowerY,z,
            CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,lowerY,z)||
            CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,lowerY+1,z));
}

void CloneMCJ_BlockDoor_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *wood,*iron;
    (void)world;
    wood=CloneMCJ_BlockRegistry_GetMutable(64);
    iron=CloneMCJ_BlockRegistry_GetMutable(71);
    if(wood)wood->neighborChanged=CloneMCJ_BlockDoor_Neighbor;
    if(iron)iron->neighborChanged=CloneMCJ_BlockDoor_Neighbor;
}

int CloneMCJ_BlockDoor_ActivateNative(CloneMCJ_World *world,int x,int y,int z)
{
    int id,metadata,lowerY,upper;
    if(!world)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id!=64&&id!=71)return 0;
    if(id==71)return 1; /* iron doors are use-locked and only respond to power */
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    lowerY=(metadata&8)?y-1:y;
    if(CloneMCJ_World_GetBlockId(world,x,lowerY,z)!=id)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,lowerY,z)^4;
    if(CloneMCJ_World_GetBlockId(world,x,lowerY+1,z)==id){
        upper=CloneMCJ_World_GetBlockMetadata(world,x,lowerY+1,z);
        CloneMCJ_World_SetBlockMetadataNotify(world,x,lowerY+1,z,
            (upper&3)|(metadata&4)|8);
    }
    return CloneMCJ_World_SetBlockMetadataNotify(world,x,lowerY,z,metadata&7);
}

void CloneMCJ_BlockDoor_Register(void){}
const char *CloneMCJ_BlockDoor_JavaName(void){return "net.minecraft.src.BlockDoor";}
const char *CloneMCJ_BlockDoor_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockDoor_JavaSourceHash32(void){return 0x7AEACBA4UL;}
