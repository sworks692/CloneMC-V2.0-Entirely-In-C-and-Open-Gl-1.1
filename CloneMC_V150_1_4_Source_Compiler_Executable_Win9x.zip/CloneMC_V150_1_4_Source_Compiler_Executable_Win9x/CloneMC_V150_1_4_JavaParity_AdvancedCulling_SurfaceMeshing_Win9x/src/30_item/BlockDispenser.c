/*
 * Direct bounded C89 port of Minecraft 1.2.3 BlockDispenser.java.
 *
 * The Java implementation schedules a four-tick response to redstone, chooses
 * one occupied slot with reservoir sampling, and emits one item.  CloneMC uses
 * the existing fixed-capacity entity pools: a full pool makes the operation
 * fail safely and the extracted stack is restored instead of being lost.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include <math.h>

static int CloneMCJ_BlockDispenser_IsOpaque(CloneMCJ_World *world,
    int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque;
}

static void CloneMCJ_BlockDispenser_SetDefaultDirection(CloneMCJ_World *world,
    int x,int y,int z)
{
    int north,south,west,east,facing;
    if(!world||world->multiplayerWorld)return;
    north=CloneMCJ_BlockDispenser_IsOpaque(world,x,y,z-1);
    south=CloneMCJ_BlockDispenser_IsOpaque(world,x,y,z+1);
    west=CloneMCJ_BlockDispenser_IsOpaque(world,x-1,y,z);
    east=CloneMCJ_BlockDispenser_IsOpaque(world,x+1,y,z);
    facing=3;
    if(north&&!south)facing=3;
    if(south&&!north)facing=2;
    if(west&&!east)facing=5;
    if(east&&!west)facing=4;
    CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,facing);
}

static CloneMCJ_TileEntity *CloneMCJ_BlockDispenser_GetTile(
    CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_Chunk *chunk;
    CloneMCJ_TileEntity *tile;
    if(!world)return (CloneMCJ_TileEntity *)0;
    chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,x>>4,z>>4);
    tile=chunk?(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(
        chunk,x&15,y,z&15):(CloneMCJ_TileEntity *)0;
    return tile&&tile->type==CLONEMC_J_TILE_DISPENSER?tile:
        (CloneMCJ_TileEntity *)0;
}

static int CloneMCJ_BlockDispenser_Projectile(CloneMCJ_GameplayState *state,
    CloneMCJ_ProjectileType type,double x,double y,double z,
    int dx,int dz,float speed,float inaccuracy,int belongs,int payload)
{
    CloneMCJ_Projectile *projectile;
    double vx,vy,vz,length;
    int slot;
    if(!state||!state->world)return 0;
    for(slot=0;slot<CLONEMC_J_MAX_PROJECTILES;++slot)
        if(!state->projectiles[slot].active)break;
    if(slot>=CLONEMC_J_MAX_PROJECTILES)return 0;
    projectile=&state->projectiles[slot];
    CloneMCJ_Projectile_Initialize(projectile,type,state->world,
        (const CloneMCJ_Entity *)0,speed,inaccuracy);
    CloneMCJ_Entity_SetPosition(&projectile->entity,x,y,z);
    if(type==CLONEMC_J_PROJECTILE_SMALL_FIREBALL){
        vx=(double)dx+CloneMCJavaRandom_NextGaussian(
            &projectile->entity.rand)*0.05;
        vy=CloneMCJavaRandom_NextGaussian(&projectile->entity.rand)*0.05;
        vz=(double)dz+CloneMCJavaRandom_NextGaussian(
            &projectile->entity.rand)*0.05;
        length=sqrt(vx*vx+vy*vy+vz*vz);
        if(length<0.000001)length=1.0;
        projectile->accelerationX=vx/length*0.1;
        projectile->accelerationY=vy/length*0.1;
        projectile->accelerationZ=vz/length*0.1;
        projectile->entity.motionX=projectile->entity.motionY=
            projectile->entity.motionZ=0.0;
    }else CloneMCJ_Projectile_SetHeading(projectile,
        (double)dx,0.1,(double)dz,speed,inaccuracy);
    projectile->belongsToPlayer=(unsigned char)(belongs?1:0);
    projectile->payloadDamage=payload;
    if(state->nextEntityId<=projectile->entity.entityId)
        state->nextEntityId=projectile->entity.entityId+1;
    if(slot>=state->projectileCount)state->projectileCount=slot+1;
    return 1;
}

static int CloneMCJ_BlockDispenser_SpawnEgg(CloneMCJ_GameplayState *state,
    int numericID,double x,double y,double z,CloneMCJavaRandom *random)
{
    const char *name;
    CloneMCJ_MobType type;
    int slot;
    if(!state||!random)return 0;
    name=CloneMCJ_EntityList_NameForNumericID(numericID);
    if(!name||!CloneMCJ_EntityList_MobTypeForName(name,&type)||
       type==CLONEMC_J_MOB_ENDER_DRAGON||
       type==CLONEMC_J_MOB_ENDER_CRYSTAL)return 0;
    for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)
        if(!state->mobs[slot].active)break;
    if(slot>=CLONEMC_J_MAX_MOBS)return 0;
    CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],type,state->world,
        x,y,z);
    state->mobs[slot].entity.rotationYaw=
        CloneMCJavaRandom_NextFloat(random)*360.0F;
    state->mobs[slot].persistenceRequired=1;
    if(state->nextEntityId<=state->mobs[slot].entity.entityId)
        state->nextEntityId=state->mobs[slot].entity.entityId+1;
    if(slot>=state->mobCount)state->mobCount=slot+1;
    return 1;
}

static int CloneMCJ_BlockDispenser_Drop(CloneMCJ_GameplayState *state,
    double x,double y,double z,int dx,int dz,const CloneMCJ_ItemStack *stack,
    CloneMCJavaRandom *random)
{
    CloneMCJ_EntityItem *drop;
    double speed;
    if(!state||!stack||!random)return 0;
    drop=CloneMCJ_Gameplay_SpawnDropEntity(state,x,y-0.3,z,stack,10,0);
    if(!drop)return 0;
    speed=CloneMCJavaRandom_NextDouble(random)*0.1+0.2;
    drop->entity.motionX=(double)dx*speed+
        CloneMCJavaRandom_NextGaussian(random)*0.045;
    drop->entity.motionY=0.2+CloneMCJavaRandom_NextGaussian(random)*0.045;
    drop->entity.motionZ=(double)dz*speed+
        CloneMCJavaRandom_NextGaussian(random)*0.045;
    return 1;
}

static void CloneMCJ_BlockDispenser_Restore(CloneMCJ_TileEntity *tile,
    const CloneMCJ_ItemStack *stack)
{
    int slot;
    if(!tile||!stack)return;
    for(slot=0;slot<9;++slot)
        if(!CloneMCJ_ItemStack_IsEmpty(&tile->items[slot])&&
           tile->items[slot].itemID==stack->itemID&&
           tile->items[slot].itemDamage==stack->itemDamage&&
           tile->items[slot].stackSize<64){
            ++tile->items[slot].stackSize;return;
        }
    for(slot=0;slot<9;++slot)
        if(CloneMCJ_ItemStack_IsEmpty(&tile->items[slot])){
            tile->items[slot]=*stack;return;
        }
}

static void CloneMCJ_BlockDispenser_Dispense(CloneMCJ_World *world,
    int x,int y,int z,CloneMCJavaRandom *random)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_TileEntity *tile;
    CloneMCJ_ItemStack stack;
    double emitX,emitY,emitZ;
    int facing,dx,dz,spawned;
    if(!world||world->multiplayerWorld)return;
    tile=CloneMCJ_BlockDispenser_GetTile(world,x,y,z);
    if(!tile||!CloneMCJ_TileEntityDispenser_GetRandomStack(tile,&stack))return;
    state=(CloneMCJ_GameplayState *)world->gameplayUserData;
    facing=CloneMCJ_World_GetBlockMetadata(world,x,y,z)&7;
    dx=facing==5?1:(facing==4?-1:0);
    dz=facing==3?1:(facing==2?-1:0);
    emitX=(double)x+(double)dx*0.6+0.5;
    emitY=(double)y+0.5;
    emitZ=(double)z+(double)dz*0.6+0.5;
    spawned=0;
    if(state&&stack.itemID==262)
        spawned=CloneMCJ_BlockDispenser_Projectile(state,
            CLONEMC_J_PROJECTILE_ARROW,emitX,emitY,emitZ,
            dx,dz,1.1F,6.0F,1,0);
    else if(state&&(stack.itemID==344||stack.itemID==332))
        spawned=CloneMCJ_BlockDispenser_Projectile(state,
            stack.itemID==344?CLONEMC_J_PROJECTILE_EGG:
            CLONEMC_J_PROJECTILE_SNOWBALL,emitX,emitY,emitZ,
            dx,dz,1.1F,6.0F,0,0);
    else if(state&&stack.itemID==373&&
            (stack.itemDamage&CLONEMC_J_POTION_SPLASH))
        spawned=CloneMCJ_BlockDispenser_Projectile(state,
            CLONEMC_J_PROJECTILE_POTION,emitX,emitY,emitZ,
            dx,dz,1.375F,3.0F,0,stack.itemDamage);
    else if(state&&stack.itemID==384)
        spawned=CloneMCJ_BlockDispenser_Projectile(state,
            CLONEMC_J_PROJECTILE_XP_BOTTLE,emitX,emitY,emitZ,
            dx,dz,1.375F,3.0F,0,0);
    else if(state&&stack.itemID==383)
        spawned=CloneMCJ_BlockDispenser_SpawnEgg(state,stack.itemDamage,
            emitX+(double)dx*0.3,emitY-0.3,emitZ+(double)dz*0.3,random);
    else if(state&&stack.itemID==385)
        spawned=CloneMCJ_BlockDispenser_Projectile(state,
            CLONEMC_J_PROJECTILE_SMALL_FIREBALL,
            emitX+(double)dx*0.3,emitY,emitZ+(double)dz*0.3,
            dx,dz,1.0F,0.5F,0,0);
    else if(state)
        spawned=CloneMCJ_BlockDispenser_Drop(state,emitX,emitY,emitZ,
            dx,dz,&stack,random);
    if(!spawned)CloneMCJ_BlockDispenser_Restore(tile,&stack);
}

static void CloneMCJ_BlockDispenser_Tick(CloneMCJ_World *world,
    int x,int y,int z,int blockID,CloneMCJavaRandom *random,void *userData)
{
    (void)userData;
    if(!world||blockID!=23||world->multiplayerWorld)return;
    if(CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y,z)||
       CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y+1,z))
        CloneMCJ_BlockDispenser_Dispense(world,x,y,z,random);
}

static void CloneMCJ_BlockDispenser_Neighbor(CloneMCJ_World *world,
    int x,int y,int z,int neighborID)
{
    (void)neighborID;
    if(!world||world->multiplayerWorld)return;
    if(CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y,z)||
       CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y+1,z))
        CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,23,4);
}

static void CloneMCJ_BlockDispenser_Added(CloneMCJ_World *world,
    int x,int y,int z)
{
    CloneMCJ_BlockDispenser_SetDefaultDirection(world,x,y,z);
}

void CloneMCJ_BlockDispenser_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block=CloneMCJ_BlockRegistry_GetMutable(23);
    if(block){
        block->neighborChanged=CloneMCJ_BlockDispenser_Neighbor;
        block->onBlockAdded=CloneMCJ_BlockDispenser_Added;
    }
    CloneMCJ_World_RegisterBlockTick(world,23,0,
        CloneMCJ_BlockDispenser_Tick,(void *)0);
}

void CloneMCJ_BlockDispenser_Register(void){}
const char *CloneMCJ_BlockDispenser_JavaName(void)
{return "net.minecraft.src.BlockDispenser";}
const char *CloneMCJ_BlockDispenser_AssignedFolder(void)
{return "src/30_item";}
unsigned long CloneMCJ_BlockDispenser_JavaSourceHash32(void)
{return 0x2CA98AA5UL;}
