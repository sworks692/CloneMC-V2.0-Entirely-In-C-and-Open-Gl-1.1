/*
 * CloneMC Java port scaffold: InventoryPlayer
 *
 * Java source: InventoryPlayer.java
 * Java type: class InventoryPlayer
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: IInventory
 * Source SHA-256: eb3370424ef695cfb953ccf40e8b2f2e1238d6a07bc1407752d1191704ae860c
 * Java lines: 473
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 31
 * Referenced Java classes: IInventory, ItemStack, EntityPlayer, NBTTagCompound, NBTTagList, Block, Material, ItemArmor, Entity
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public ItemStack mainInventory[]
 * - public ItemStack armorInventory[]
 * - public int currentItem
 * - public EntityPlayer player
 * - private ItemStack itemStack
 * - public boolean inventoryChanged
 *
 * Java method/constructor inventory:
 * - public InventoryPlayer(EntityPlayer entityplayer)
 * - public ItemStack getCurrentItem()
 * - private int getInventorySlotContainItem(int i)
 * - private int storeItemStack(ItemStack itemstack)
 * - private int getFirstEmptyStack()
 * - public void setCurrentItem(int i, boolean flag)
 * - public void changeCurrentItem(int i)
 * - private int storePartialItemStack(ItemStack itemstack)
 * - public void decrementAnimations()
 * - public boolean consumeInventoryItem(int i)
 * - public boolean addItemStackToInventory(ItemStack itemstack)
 * - public ItemStack decrStackSize(int i, int j)
 * - public void setInventorySlotContents(int i, ItemStack itemstack)
 * - public float getStrVsBlock(Block block)
 * - public NBTTagList writeToNBT(NBTTagList nbttaglist)
 * - public void readFromNBT(NBTTagList nbttaglist)
 * - public int getSizeInventory()
 * - public ItemStack getStackInSlot(int i)
 * - public String getInvName()
 * - public int getInventoryStackLimit()
 * - public int getDamageVsEntity(Entity entity)
 * - public boolean canHarvestBlock(Block block)
 * - public ItemStack armorItemInSlot(int i)
 * - public int getTotalArmorValue()
 * - public void damageArmor(int i)
 * - public void dropAllItems()
 * - public void onInventoryChanged()
 * - public void setItemStack(ItemStack itemstack)
 * - public ItemStack getItemStack()
 * - public boolean canInteractWith(EntityPlayer entityplayer)
 * - public boolean func_28018_c(ItemStack itemstack)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_30_item.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <string.h>

static CloneMCJ_ItemStack *CloneMCJ_InventoryPlayer_GetSlot(CloneMCJ_InventoryPlayer *inventory, int slot)
{
    if (!inventory) return (CloneMCJ_ItemStack *)0;
    if (slot >= 0 && slot < CLONEMC_J_MAIN_INVENTORY_SIZE) return &inventory->mainInventory[slot];
    slot -= CLONEMC_J_MAIN_INVENTORY_SIZE;
    if (slot >= 0 && slot < CLONEMC_J_ARMOR_INVENTORY_SIZE) return &inventory->armorInventory[slot];
    return (CloneMCJ_ItemStack *)0;
}

void CloneMCJ_InventoryPlayer_Initialize(CloneMCJ_InventoryPlayer *inventory)
{
    int i;
    if (!inventory) return;
    memset(inventory, 0, sizeof(*inventory));
    for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE; ++i) CloneMCJ_ItemStack_Clear(&inventory->mainInventory[i]);
    for (i = 0; i < CLONEMC_J_ARMOR_INVENTORY_SIZE; ++i) CloneMCJ_ItemStack_Clear(&inventory->armorInventory[i]);
    CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
}

static int CloneMCJ_InventoryPlayer_ArmorInfo(int itemID,int *reduction,int *maximum)
{
    static const int reduce[4]={3,8,6,3};
    static const int durability[4]={11,16,15,13};
    int group,type,level;
    if(itemID<298||itemID>317)return 0;
    group=(itemID-298)/4;type=(itemID-298)&3;
    if(group==0)level=0;else if(group==1)level=1;else if(group==2)level=2;
    else if(group==3)level=3;else level=1;
    if(reduction)*reduction=reduce[type];
    if(maximum)*maximum=(durability[type]*3)<<level;
    return 1;
}

int CloneMCJ_InventoryPlayer_GetTotalArmorValue(const CloneMCJ_InventoryPlayer *inventory)
{
    int i,totalProtection,totalRemaining,totalDurability,reduction,maximum,remaining;
    if(!inventory)return 0;
    totalProtection=0;totalRemaining=0;totalDurability=0;
    for(i=0;i<CLONEMC_J_ARMOR_INVENTORY_SIZE;++i){
        if(CloneMCJ_ItemStack_IsEmpty(&inventory->armorInventory[i])||
            !CloneMCJ_InventoryPlayer_ArmorInfo(inventory->armorInventory[i].itemID,&reduction,&maximum))continue;
        remaining=maximum-inventory->armorInventory[i].itemDamage;if(remaining<0)remaining=0;
        totalProtection+=reduction;totalRemaining+=remaining;totalDurability+=maximum;
    }
    if(totalDurability==0)return 0;
    return ((totalProtection-1)*totalRemaining)/totalDurability+1;
}

void CloneMCJ_InventoryPlayer_DamageArmor(CloneMCJ_InventoryPlayer *inventory,int damage)
{
    int i,maximum;
    if(!inventory||damage<=0)return;
    for(i=0;i<CLONEMC_J_ARMOR_INVENTORY_SIZE;++i){
        if(CloneMCJ_ItemStack_IsEmpty(&inventory->armorInventory[i])||
            !CloneMCJ_InventoryPlayer_ArmorInfo(inventory->armorInventory[i].itemID,(int *)0,&maximum))continue;
        inventory->armorInventory[i].itemDamage+=damage;
        if(inventory->armorInventory[i].itemDamage>maximum)CloneMCJ_ItemStack_Clear(&inventory->armorInventory[i]);
    }
    inventory->inventoryChanged=1;
}

CloneMCJ_ItemStack *CloneMCJ_InventoryPlayer_GetCurrent(CloneMCJ_InventoryPlayer *inventory)
{
    if (!inventory || inventory->currentItem < 0 || inventory->currentItem >= 9) return (CloneMCJ_ItemStack *)0;
    return &inventory->mainInventory[inventory->currentItem];
}

CloneMCJ_ItemStack CloneMCJ_InventoryPlayer_DecrStackSize(CloneMCJ_InventoryPlayer *inventory, int slot, int amount)
{
    CloneMCJ_ItemStack empty;
    CloneMCJ_ItemStack *stack;
    CloneMCJ_ItemStack_Clear(&empty);
    stack = CloneMCJ_InventoryPlayer_GetSlot(inventory, slot);
    if (!stack || amount <= 0) return empty;
    inventory->inventoryChanged = 1;
    return CloneMCJ_ItemStack_Split(stack, amount);
}

int CloneMCJ_InventoryPlayer_AddItemStack(CloneMCJ_InventoryPlayer *inventory, CloneMCJ_ItemStack *incoming)
{
    const CloneMCJ_ItemDefinition *item;
    int i;
    int moved;
    if (!inventory || CloneMCJ_ItemStack_IsEmpty(incoming)) return 0;
    item = CloneMCJ_ItemRegistry_Get(incoming->itemID);
    moved = 0;
    if (item && item->maxStackSize == 1) {
        for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE; ++i) {
            if (CloneMCJ_ItemStack_IsEmpty(&inventory->mainInventory[i])) {
                inventory->mainInventory[i] = *incoming;
                CloneMCJ_ItemStack_Clear(incoming);
                inventory->inventoryChanged = 1;
                return 1;
            }
        }
        return 0;
    }
    for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE && incoming->stackSize > 0; ++i) {
        CloneMCJ_ItemStack *slot;
        int room;
        int transfer;
        slot = &inventory->mainInventory[i];
        if (!CloneMCJ_ItemStack_IsStackableWith(slot, incoming)) continue;
        room = CloneMCJ_ItemStack_GetMaxStackSize(slot) - slot->stackSize;
        transfer = room < incoming->stackSize ? room : incoming->stackSize;
        if (transfer > 0) {
            slot->stackSize += transfer;
            slot->animationsToGo = 5;
            incoming->stackSize -= transfer;
            moved += transfer;
        }
    }
    for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE && incoming->stackSize > 0; ++i) {
        int transfer;
        int maximum;
        if (!CloneMCJ_ItemStack_IsEmpty(&inventory->mainInventory[i])) continue;
        maximum = CloneMCJ_ItemStack_GetMaxStackSize(incoming);
        transfer = incoming->stackSize < maximum ? incoming->stackSize : maximum;
        inventory->mainInventory[i] = *incoming;
        inventory->mainInventory[i].stackSize = transfer;
        inventory->mainInventory[i].animationsToGo = 5;
        incoming->stackSize -= transfer;
        moved += transfer;
    }
    if (incoming->stackSize <= 0) CloneMCJ_ItemStack_Clear(incoming);
    if (moved > 0) inventory->inventoryChanged = 1;
    return moved > 0;
}

int CloneMCJ_InventoryPlayer_ConsumeItem(CloneMCJ_InventoryPlayer *inventory, int itemID)
{
    int i;
    if (!inventory) return 0;
    for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE; ++i) {
        if (inventory->mainInventory[i].itemID == itemID && inventory->mainInventory[i].stackSize > 0) {
            --inventory->mainInventory[i].stackSize;
            if (inventory->mainInventory[i].stackSize <= 0) CloneMCJ_ItemStack_Clear(&inventory->mainInventory[i]);
            inventory->inventoryChanged = 1;
            return 1;
        }
    }
    return 0;
}

void CloneMCJ_InventoryPlayer_ChangeCurrentItem(CloneMCJ_InventoryPlayer *inventory, int wheelDelta)
{
    if (!inventory || wheelDelta == 0) return;
    if (wheelDelta > 0) wheelDelta = 1; else wheelDelta = -1;
    inventory->currentItem -= wheelDelta;
    while (inventory->currentItem < 0) inventory->currentItem += 9;
    while (inventory->currentItem >= 9) inventory->currentItem -= 9;
}

int CloneMCJ_InventoryPlayer_ClickSlot(CloneMCJ_InventoryPlayer *inventory, int slotNumber, int mouseButton)
{
    CloneMCJ_ItemStack *slot;
    CloneMCJ_ItemStack temporary;
    int amount;
    int room;
    if (!inventory) return 0;
    slot = CloneMCJ_InventoryPlayer_GetSlot(inventory, slotNumber);
    if (!slot) return 0;
    if (mouseButton == 0) {
        if (CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)) {
            inventory->carriedStack = *slot;
            CloneMCJ_ItemStack_Clear(slot);
        } else if (CloneMCJ_ItemStack_IsEmpty(slot)) {
            *slot = inventory->carriedStack;
            CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
        } else if (CloneMCJ_ItemStack_IsStackableWith(slot, &inventory->carriedStack)) {
            room = CloneMCJ_ItemStack_GetMaxStackSize(slot) - slot->stackSize;
            amount = room < inventory->carriedStack.stackSize ? room : inventory->carriedStack.stackSize;
            slot->stackSize += amount;
            inventory->carriedStack.stackSize -= amount;
            if (inventory->carriedStack.stackSize <= 0) CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
        } else {
            temporary = *slot;
            *slot = inventory->carriedStack;
            inventory->carriedStack = temporary;
        }
    } else {
        if (CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)) {
            amount = (slot->stackSize + 1) / 2;
            inventory->carriedStack = CloneMCJ_ItemStack_Split(slot, amount);
        } else if (CloneMCJ_ItemStack_IsEmpty(slot)) {
            *slot = CloneMCJ_ItemStack_Split(&inventory->carriedStack, 1);
        } else if (CloneMCJ_ItemStack_IsStackableWith(slot, &inventory->carriedStack) &&
                   slot->stackSize < CloneMCJ_ItemStack_GetMaxStackSize(slot)) {
            ++slot->stackSize;
            --inventory->carriedStack.stackSize;
            if (inventory->carriedStack.stackSize <= 0) CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
        }
    }
    inventory->inventoryChanged = 1;
    return 1;
}

static int CloneMCJ_InventoryPlayer_ToolEffective(unsigned char toolClass,
    int blockID,int metadata)
{
    static const unsigned char shovelBlocks[]={2,3,12,13,78,80,82,60};
    /* ItemAxe.java 1.2.3 adds both pumpkin states to the legacy wood list.
     * This affects break speed only; Material.pumpkin remains hand-harvestable. */
    static const unsigned char axeBlocks[]={5,47,17,53,54,86,91};
    static const unsigned char pickaxeBlocks[]={4,67,1,24,48,15,42,16,41,14,56,57,79,87,21,22};
    const unsigned char *blocks;int count,index;
    /* Later stair/slab mining keeps the Beta block IDs but applies the
     * material-specific tools used by the split modern slab families.  The
     * old BlockStep ID stores wood as subtype 2. */
    if(blockID==43||blockID==44){
        if((metadata&3)==2)return toolClass==CLONEMC_J_TOOL_AXE;
        return toolClass==CLONEMC_J_TOOL_PICKAXE;
    }
    blocks=0;count=0;
    if(toolClass==CLONEMC_J_TOOL_SHOVEL){blocks=shovelBlocks;count=(int)sizeof(shovelBlocks);}
    else if(toolClass==CLONEMC_J_TOOL_AXE){blocks=axeBlocks;count=(int)sizeof(axeBlocks);}
    else if(toolClass==CLONEMC_J_TOOL_PICKAXE){blocks=pickaxeBlocks;count=(int)sizeof(pickaxeBlocks);}
    for(index=0;index<count;++index)if((int)blocks[index]==blockID)return 1;
    return 0;
}

float CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
    const CloneMCJ_InventoryPlayer *inventory,int blockID,int metadata)
{
    const CloneMCJ_ItemDefinition *item;
    const CloneMCJ_ItemStack *stack;
    if(!inventory||inventory->currentItem<0||inventory->currentItem>=9)return 1.0F;
    stack=&inventory->mainInventory[inventory->currentItem];
    if(CloneMCJ_ItemStack_IsEmpty(stack))return 1.0F;
    item=CloneMCJ_ItemRegistry_Get(stack->itemID);
    if(!item)return 1.0F;
    if(CloneMCJ_InventoryPlayer_ToolEffective(item->toolClass,blockID,metadata)){
        float strength;
        int efficiencyLevel;
        strength=item->efficiency>1.0F?item->efficiency:1.0F;
        efficiencyLevel=CloneMCJ_Progression_EnchantLevel(stack,
            CLONEMC_J_ENCHANT_EFFICIENCY);
        if(efficiencyLevel>0)strength+=(float)(efficiencyLevel*
            efficiencyLevel+1);
        return strength;
    }
    if(item->toolClass==CLONEMC_J_TOOL_SHEARS&&(blockID==18||blockID==30))return 15.0F;
    if(item->toolClass==CLONEMC_J_TOOL_SWORD&&blockID==30)return 15.0F;
    return 1.0F;
}

float CloneMCJ_InventoryPlayer_GetStrengthVsBlock(
    const CloneMCJ_InventoryPlayer *inventory,int blockID)
{
    return CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(inventory,
        blockID,0);
}

int CloneMCJ_InventoryPlayer_CanHarvestMetadata(
    const CloneMCJ_InventoryPlayer *inventory,int blockID,int metadata)
{
    const CloneMCJ_BlockDefinition *block;const CloneMCJ_ItemDefinition *item;
    const CloneMCJ_ItemStack *stack;int level;
    block=CloneMCJ_BlockRegistry_Get(blockID);
    if(!block)return 0;
    /* Wood slabs are harvestable by hand just like planks and wood stairs;
     * an axe affects only break speed.  Stone, sandstone, and cobblestone
     * slab variants retain their pickaxe requirement. */
    if((blockID==43||blockID==44)&&(metadata&3)==2)return 1;
    /* Material.java marks only rock, iron, snow and builtSnow as requiring a
     * tool.  Other materials remain harvestable even when a tool is faster. */
    if(block->material!=CLONEMC_J_MATERIAL_ROCK&&
       block->material!=CLONEMC_J_MATERIAL_METAL&&blockID!=78&&blockID!=80)return 1;
    if(!inventory||inventory->currentItem<0||inventory->currentItem>=9)return 0;
    stack=&inventory->mainInventory[inventory->currentItem];
    if(CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    item=CloneMCJ_ItemRegistry_Get(stack->itemID);if(!item)return 0;
    if(blockID==78||blockID==80)return item->toolClass==CLONEMC_J_TOOL_SHOVEL;
    if(item->toolClass!=CLONEMC_J_TOOL_PICKAXE)return 0;
    level=(int)item->harvestLevel;
    if(blockID==49)return level==3;
    if(blockID==56||blockID==57||blockID==14||blockID==41)return level>=2;
    if(blockID==15||blockID==42||blockID==21||blockID==22)return level>=1;
    if(blockID==73||blockID==74)return level>=2;
    return 1;
}

int CloneMCJ_InventoryPlayer_CanHarvest(
    const CloneMCJ_InventoryPlayer *inventory,int blockID)
{
    return CloneMCJ_InventoryPlayer_CanHarvestMetadata(inventory,blockID,0);
}

int CloneMCJ_InventoryPlayer_WriteNBT(const CloneMCJ_InventoryPlayer *inventory, CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagList *list;
    int i;
    if (!inventory || !compound) return 0;
    list = CloneMCJ_NBTTagList_Create();
    if (!list) return 0;
    for (i = 0; i < CLONEMC_J_MAIN_INVENTORY_SIZE + CLONEMC_J_ARMOR_INVENTORY_SIZE; ++i) {
        const CloneMCJ_ItemStack *stack;
        CloneMCJ_NBTTagCompound *entry;
        int savedSlot;
        stack = i < CLONEMC_J_MAIN_INVENTORY_SIZE ? &inventory->mainInventory[i] : &inventory->armorInventory[i - CLONEMC_J_MAIN_INVENTORY_SIZE];
        if (CloneMCJ_ItemStack_IsEmpty(stack)) continue;
        entry = CloneMCJ_NBTTagCompound_Create();
        if (!entry) continue;
        savedSlot = i < CLONEMC_J_MAIN_INVENTORY_SIZE ? i : 100 + i - CLONEMC_J_MAIN_INVENTORY_SIZE;
        CloneMCJ_NBTTagCompound_SetByte(entry, "Slot", (CloneMCJByte)savedSlot);
        CloneMCJ_ItemStack_WriteNBT(stack, entry);
        CloneMCJ_NBTTagList_Append(list, (CloneMCJ_NBTBase *)entry);
    }
    CloneMCJ_NBTTagCompound_SetTag(compound, "Inventory", (CloneMCJ_NBTBase *)list);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "SelectedItemSlot", inventory->currentItem);
    return 1;
}

int CloneMCJ_InventoryPlayer_ReadNBT(CloneMCJ_InventoryPlayer *inventory, const CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagList *list;
    CloneMCJInt count;
    CloneMCJInt i;
    if (!inventory || !compound) return 0;
    CloneMCJ_InventoryPlayer_Initialize(inventory);
    list = CloneMCJ_NBTTagCompound_GetTagList(compound, "Inventory");
    count = CloneMCJ_NBTTagList_Count(list);
    for (i = 0; i < count; ++i) {
        CloneMCJ_NBTTagCompound *entry;
        int slot;
        entry = (CloneMCJ_NBTTagCompound *)CloneMCJ_NBTTagList_Get(list, i);
        if (!entry) continue;
        slot = (int)(unsigned char)CloneMCJ_NBTTagCompound_GetByte(entry, "Slot");
        if (slot >= 0 && slot < CLONEMC_J_MAIN_INVENTORY_SIZE) CloneMCJ_ItemStack_ReadNBT(&inventory->mainInventory[slot], entry);
        else if (slot >= 100 && slot < 100 + CLONEMC_J_ARMOR_INVENTORY_SIZE) CloneMCJ_ItemStack_ReadNBT(&inventory->armorInventory[slot - 100], entry);
    }
    inventory->currentItem = CloneMCJ_NBTTagCompound_HasKey(compound, "SelectedItemSlot") ? CloneMCJ_NBTTagCompound_GetInteger(compound, "SelectedItemSlot") : 0;
    if (inventory->currentItem < 0 || inventory->currentItem >= 9) inventory->currentItem = 0;
    return 1;
}

void CloneMCJ_InventoryPlayer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_InventoryPlayer_JavaName(void)
{
    return "net.minecraft.src.InventoryPlayer";
}

const char *CloneMCJ_InventoryPlayer_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_InventoryPlayer_JavaSourceHash32(void)
{
    return 0xEB337042UL;
}
