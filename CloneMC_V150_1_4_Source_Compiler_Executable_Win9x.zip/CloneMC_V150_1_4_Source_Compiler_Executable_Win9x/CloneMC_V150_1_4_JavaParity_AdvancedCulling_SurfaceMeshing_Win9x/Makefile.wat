# CloneMC V150.1.4 complete Open Watcom V2 build
VERSION = V150_1_4
EXE = CloneMC_V150_1_4_JavaParity_AdvancedCulling_SurfaceMeshing_Win9x.exe
OBJ = project2finalalpharecreation.obj
SRC = project2finalalpharecreation.c
LNK = clonemc_v150_1_4_advanced_culling_meshing_win9x.lnk

all: $(EXE)

$(OBJ): .SYMBOLIC
	wcc386 -q -otexan -bt=nt -dWINVER=0x0400 -d_WIN32_WINNT=0x0400 -dCLONEMC_BUILD_OPEN_WATCOM_V2=1 -dCLONEMC_REFERENCE_DEFAULT=0 -fo=$(OBJ) $(SRC)

$(EXE): $(OBJ) $(LNK)
	wlink @$(LNK)

clean: .SYMBOLIC
	-del $(OBJ)
	-del $(EXE)
	-del CloneMC_V150_1_4_JavaParity_AdvancedCulling_SurfaceMeshing_Win9x.map
