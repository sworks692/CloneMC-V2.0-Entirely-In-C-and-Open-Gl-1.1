#ifndef CLONEMC_VERSION_H
#define CLONEMC_VERSION_H

/*
 * Single authoritative identity for cumulative V150 dual-stage Java-shaped
 * section rendering, interleaved display-list compilation, coarse column
 * and dynamic-object culling, verified display-list transactions, partial-
 * block lighting, lossless support updates, projected shadows and parity.
 * Keep this header C89 and preprocessor-only
 * for Open Watcom V2.0 and the Win32 resource/link path.
 */
#define CLONEMC_VERSION_MAJOR 150
#define CLONEMC_VERSION_MINOR 1
#define CLONEMC_VERSION_PATCH 4
#define CLONEMC_VERSION_TEXT "V150.1.4.0"
#define CLONEMC_VERSION_CHANNEL "Java Parity Advanced Frustum, Surface Meshing and Visual Fidelity"
#define CLONEMC_VERSION_DISPLAY "CloneMC V150.1.4.0 Java Parity Advanced Frustum, Surface Meshing and Visual Fidelity"
#define CLONEMC_REFERENCE_JAVA_MODULES 974UL
#define CLONEMC_LEGACY_REFERENCE_JAVA_MODULES 675UL
#define CLONEMC_NATIVE_TEST_MODULES 2UL
#define CLONEMC_TOTAL_C_MODULES 697UL
#define CLONEMC_REFERENCE_ARCHIVE_SHA256 \
    "6fbebcf97d2bbc1f28cdce3a3abe7b6d9267cdfd998c3979ac7a7f712c5a87d2"
#define CLONEMC_REFERENCE_MANIFEST_SHA256 \
    "d470637e4cab2eb05cf1aa475d3cccf7e78c1e838daf79fd678bd201e69d04ac"
#define CLONEMC_PARITY_MANIFEST_SHA256 \
    "6d2aa968f15a6eaeb0d05c312f13f4ab9900b82b559aebd580166a38336f1510"
#define CLONEMC_SOURCE_ARCHIVE_SHA256 \
    "generated-in-CloneMC_V150_SHA256SUMS.txt"
#define CLONEMC_JAVA123_REFERENCE_ARCHIVE_SHA256 \
    "9aa41912be0c63b735a804703b7ea63c8138032bf92b65c974380842563e4951"
#define CLONEMC_POST_BETA_ASSET_ARCHIVE_SHA256 \
    "dd233df240077e5f263780dc1a4b02702d102a098b6f52fab0a644d4e89967a0"
#define CLONEMC_LICENSE_SHA256 \
    "d90ce01c204f5cbc173088e8ef27ebe348a49124005d7043bf4d1b50d18fca4d"
#define CLONEMC_CANONICAL_TERRAIN_RGBA_SHA256 \
    "3c5684d3e6cc0a500b2929480148b430e43b3760e4c76c1950bdc1630a256b9f"
#define CLONEMC_BUILD_PROFILE "win32-x86-c89-opengl11-win98-winsock2-v150p1p4-frustum-meshing"

#endif
