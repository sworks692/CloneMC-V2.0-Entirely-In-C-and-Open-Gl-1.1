# V150.1.4 Renderer Performance Engineering

## Objectives

1. Reduce CPU work before OpenGL submission.
2. Preserve the Java-visible result exactly where possible.
3. Preserve OpenGL 1.1 and Win9x compatibility.
4. Avoid optimizations that trade correctness for benchmark numbers.
5. Expose enough counters that future regressions can be diagnosed.

## Frustum hierarchy

The previous renderer could repeatedly test a parent chunk-column and then each 16-block vertical section against the same six planes. V150.1.4 classifies the parent once and passes only unresolved planes to children.

The key invariant is that the reject decision remains the same as the Java eight-corner box/plane test. Hierarchy only removes redundant plane work.

### Synthetic result

- columns tested: 693
- old-style plane evaluations: 19,294
- hierarchical evaluations: 3,667
- evaluations avoided: 15,627 (81.0%)
- drawable section masks: exact match

## Empty-section pruning

Built sections known to contain no renderable geometry are removed before child frustum evaluation. Parent Y bounds are calculated from the candidate sections that remain. In the synthetic fixture 2,644 empty-section child tests were avoided.

## Enclosed-voxel surface compaction

The mesher skips only a standard full opaque cube that has six standard full opaque neighbors. This means it would have produced no Java-visible face anyway.

The check occurs before metadata, lighting, ambient-occlusion, texture-UV, and tessellator work. Four cardinal neighbor chunks are cached once per build slice and the opaque classification table is cached by block ID.

### Synthetic cave fixture

- non-air blocks: 3,744
- previous RenderBlocks calls: 3,744
- V150.1.4 calls: 1,526
- calls avoided: 2,218 (59.2%)

The final display-list geometry remains governed by the same RenderBlocks face/light/UV code for every block that can contribute a visible surface.

## Fast leaves

Java fast leaves are opaque and suppress adjoining leaf/leaf faces. On a solid 12^3 leaf fixture:

- leaves: 1,728
- prior internal-face quads: 10,368
- Java-fast quads: 864
- quads eliminated: 9,504 (91.7%)

Real foliage is less dense than this stress fixture, so actual reduction will vary.

## Glass/translucency

Glass is moved out of the blended pass because target Java `BlockGlass` reports pass 0. Water, ice and portal remain in the translucent pass. Removing the extra 190/255 vertex-alpha multiplication also avoids unnecessarily dimming texture alpha.

## Why display lists remain

The engine's terrain is static between chunk rebuilds, which is a workload well suited to retained/replayable geometry on period OpenGL implementations. V150.1.4 therefore improves what enters the existing display lists rather than replacing that path with later OpenGL buffer/shader APIs. Driver implementation quality still matters; real hardware benchmarking remains necessary.

## What the benchmark does not claim

The bundled benchmark does **not** measure:

- GPU execution time;
- OpenGL driver display-list compilation/replay cost;
- world generation;
- entity AI;
- networking;
- sound;
- real FPS.

It isolates renderer algorithm work so visibility correctness and CPU-side work reduction can be checked deterministically.
