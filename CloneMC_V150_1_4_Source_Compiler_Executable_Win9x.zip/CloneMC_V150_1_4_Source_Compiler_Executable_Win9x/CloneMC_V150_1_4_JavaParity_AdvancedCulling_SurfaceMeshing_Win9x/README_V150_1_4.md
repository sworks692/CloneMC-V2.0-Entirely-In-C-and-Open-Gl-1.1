# CloneMC V150.1.4.0
## Java Parity Advanced Frustum, Surface Meshing and Visual Fidelity

This release continues the V150.1.3 Preview codebase and focuses on renderer correctness, Java visual parity, Win9x-safe CPU-side culling, and developer diagnostics. It deliberately stays within the existing fixed-function OpenGL 1.1 / Open Watcom C89 design instead of introducing shader, VBO, FBO, occlusion-query, or later Windows dependencies.

### Main renderer changes

- Hierarchical six-plane frustum classification for chunk columns and 16-block vertical sections.
- Exact parent-to-child frustum-plane mask inheritance: planes that wholly contain a parent are not retested for child sections.
- Empty/built-air sections are removed before child frustum work.
- Coarse parent Y bounds are tightened to the actual candidate-section range rather than blindly testing Y=0..128.
- Fully-contained parent boxes accept all candidate children without additional plane tests.
- Lossless enclosed-opaque-block rejection before metadata, lighting, ambient occlusion, UV calculation, and tessellation.
- Cached north/south/east/west neighbor-chunk pointers and a per-build opaque-material table keep the new meshing test inexpensive.
- Java fast-leaf behavior restored: fast leaves are opaque and suppress faces between adjacent leaves; fancy leaves remain alpha-tested/cutout.
- Java glass render-pass behavior restored: glass is no longer treated as a blended translucent terrain pass.
- Removed the extra native 190/255 vertex-alpha multiplier from water/ice/portal geometry; Java supplies opaque vertex color and relies on atlas texture alpha plus blending.
- F3 advanced diagnostics now expose plane tests, saved plane tests, fully-inside parents, empty-section skips, enclosed-block mesh culls, and batching activity.

- Frustum visibility masks: exact match on 693 test columns.
- Plane evaluations: 19,294 -> 3,667, a synthetic 81.0% reduction.
- Cave-like 16^3 section: 3,744 -> 1,526 RenderBlocks calls, 59.2% avoided by enclosed-voxel rejection.
- Solid 12^3 fast-leaf canopy: 10,368 -> 864 emitted leaf faces, 91.7% internal faces removed.

These numbers demonstrate algorithmic work reduction only. Real frame-rate improvement depends on CPU, OpenGL ICD/driver, view distance, scene composition, display-list implementation, and rebuild frequency.
```
