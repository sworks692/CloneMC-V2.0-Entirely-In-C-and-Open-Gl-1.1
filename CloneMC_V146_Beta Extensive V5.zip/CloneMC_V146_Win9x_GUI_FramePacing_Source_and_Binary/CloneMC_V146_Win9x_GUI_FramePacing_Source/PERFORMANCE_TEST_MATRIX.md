# CloneMC V132.5 — Windows 98/2000/XP Performance and Visual-Safety Test Matrix

## V132.5 visual-safety supplement

Run every visual-safety comparison with the same world, position, camera
direction, window size, render distance, graphics setting, and FPS policy.
Visual Safety is intentionally independent of frame pacing: `Max FPS`,
`Balanced`, and `Power saver` retain their existing targets.

| Scenario | Visual Safety ON | Visual Safety OFF | Required result |
|---|---|---|---|
| Normal walking | No view bob | Java-style bob if View Bobbing is ON | Player speed, collision, and tick rate remain identical |
| Survival sprint | Stable base FOV | Java-style sprint FOV expansion | Sprint acceleration, speed, hunger, and packets remain identical |
| Taking damage/death | No automatic camera shake/roll | Java-style hurt shake/death roll | Damage, health, death, respawn, and sound remain identical |
| Standing in a portal | Static low-alpha purple cue | Animated full-screen portal texture | Portal timer and dimension transfer remain identical |
| Lightning storm | No full-screen sky brightening | Java-style lightning sky brightening | Lightning world state, fire/damage, weather, and sound remain identical |
| Ignited creeper | Smooth scale, no alternating white flash | Java-style wobble and blink | Fuse length, explosion, damage, and AI remain identical |
| Anaglyph selected | Anaglyph is forced OFF | Two-eye color-mask rendering works | No simulation, save, or networking difference |

For each row:

1. Capture average FPS plus shutdown p50, p95, p99, and maximum frame time.
2. Confirm Visual Safety ON does not introduce periodic stalls or cap `Max FPS`.
3. Confirm the setting persists through a clean exit and restart.
4. Toggle it through Options > Video Settings and exercise every GUI button in
   the Win95/98-compatible frontend before and after a world session.
5. Repeat in a window on a CRT test machine; configure CRT refresh in Windows
   or the display driver because CloneMC does not force a monitor refresh mode.

## V132.4 OpenGL 1.1 throughput supplement

Use this supplement before the original long-session scenarios below.

### A/B comparison

Compare the cumulative V132.3 and V132.4 executables with copied world data.
Use the same camera coordinates/yaw/pitch, resolution, pixel format, driver,
render distance, graphics mode, AO, weather, entity count, and FPS option.

Run each case for 60 seconds of warm-up and five minutes of measurement:

| Case | Required configuration |
| --- | --- |
| SW-idle | Software/GDI Generic OpenGL 1.1, 640×480, 16-bit, basic, AO off, Max FPS, stationary |
| SW-turn | Same, constant slow 360-degree turns |
| SW-travel | Same, fixed route across at least eight chunk boundaries |
| ICD-idle | Period vendor OpenGL 1.1 ICD, same scene/settings |
| ICD-travel | Period vendor ICD, same traversal |
| GUI | `-win98safe`, every main/options/world button, return to title |
| MP | Connect, receive chunks, move, disconnect, reconnect |

Record FPS and shutdown p50/p95/p99/max frame time. For V132.4 also record
`batchBuilds`, `batchCalls`, `batchedChunks`, `batchFallbacks`,
`residentSyncs`, and `slotScans`.

### V132.4 pass conditions

- Max FPS is not silently forced back to 40 FPS in `win98-safe`.
- TPS remains 20 and gameplay speed does not track presentation FPS.
- In a warmed stationary scene, `batchBuilds` stops or grows only when a
  visible child mesh/order/anchor changes.
- `batchedChunks` is greater than `batchCalls` when several chunks are visible.
- `batchFallbacks` remains zero on a functioning display-list implementation.
- `slotScans == residentSyncs × 128`.
- No terrain disappears at yaw 0/90/180/270 or while pitching up/down.
- Translucent terrain remains back-to-front; opaque/cutout remain front-to-back.
- Chunk edges, AO, light, fences, rails, stairs, slabs, and connected geometry
  match V132.3.
- Every legacy frontend option remains responsive and crash-free.
- Single-player save/reload and multiplayer chunk add/remove remain correct.

Hundreds of FPS are a measurement target for favorable simple scenes, not a
release guarantee. Report `SwapBuffers` blocking, emulation/virtualization,
driver identity, and scene complexity with every result.

## Original Priority 2 matrix

## Purpose

This matrix turns "high FPS and stability" into repeatable evidence. It tests
the exact risks addressed by V129:

- frame pacing and long-frame spikes;
- 20 TPS simulation stability;
- chunk/mesh/particle/network/region ceilings;
- TCP fragmentation and burst behavior;
- save integrity under memory pressure;
- minimize/restore and display-driver recovery;
- long-session heap and handle stability.

Use the same world seed, route, resolution, driver, settings, and scenario for
V128 and V129. Average FPS alone is insufficient; record p50, p95, p99, and
maximum frame time plus TPS and high-water marks.

## 1. Hardware/OS matrix

| ID | OS | Suggested hardware | Memory | Graphics path | Profile |
|---|---|---|---:|---|---|
| W98-L | Windows 98 SE | Pentium II-class, period PCI/AGP GPU | 64 MiB | Vendor OpenGL 1.1 ICD | `win98safe` |
| W98-H | Windows 98 SE | Pentium III-class, period AGP GPU | 128 MiB | Vendor OpenGL 1.1 ICD | `win98high` |
| W98-SW | Windows 98 SE | Same as W98-L/H | 64–128 MiB | Microsoft/software OpenGL baseline | `win98safe` |
| W2K-L | Windows 2000 SP4 | Pentium III-class | 128 MiB | Vendor OpenGL 1.1 ICD | `win98high` |
| W2K-N | Windows 2000 SP4 | Pentium III/Athlon | 256 MiB | Vendor OpenGL 1.1 ICD | `xp` |
| XP-N | Windows XP SP3 | Pentium 4/Athlon XP | 512 MiB | Vendor OpenGL 1.1+ ICD using only 1.1 calls | `xp` |
| XP-H | Windows XP SP3 | Later x86 single/dual core | 1 GiB | Vendor ICD | `modern` and `xp` comparison |

If the exact hardware is unavailable, record the actual CPU, clock, memory,
GPU, driver version/date, sound device, and whether the test is physical,
virtualized, or emulated. Never mix physical and virtual results in one
performance comparison.

## 2. Pre-test controls

For every result:

1. Reboot the target.
2. Disable unrelated resident software and scheduled scans.
3. Confirm virtual memory/pagefile settings and free disk space.
4. Record desktop color depth and resolution.
5. Record GPU and sound-driver versions.
6. Copy V128 and V129 to separate clean directories.
7. Verify the V129 executable SHA-256:
   `7e2844d5cb9b8950fa6c89497e852b735a0120a0a5b38fe983e048534c10f446`.
8. Use a copy of the test world for each run.
9. Delete only generated logs/options between controlled runs; do not reuse a
   world changed by another test.
10. Warm the driver once by launching to the title screen, then exit.

## 3. Startup self-tests

Run:

```text
CloneMC_V129_Priority2_Win98_Performance.exe -selftest -profile=win98safe
CloneMC_V129_Priority2_Win98_Performance.exe -selftest -profile=win98high
CloneMC_V129_Priority2_Win98_Performance.exe -selftest -profile=xp
```

On a 64 MiB target, the first command is mandatory; the others may be run only
if the OS has enough free memory.

Pass conditions:

- process returns success;
- no compatibility/self-test failure dialog;
- no invalid-page fault or protection fault;
- log states that explicit startup self-tests passed;
- OpenGL 1.1 capability check passes;
- selected profile and exact ceilings match the command.

## 4. Standardized world route

Create one reference world and copy it for each run. The route should contain:

1. spawn/base with chests, furnaces, signs, torches, water, and lava;
2. a straight path crossing at least eight chunk boundaries;
3. a hill or tower that exposes many chunk sections;
4. a cave with low visibility and many surfaces;
5. an open area for explosions and particles;
6. weather-capable outdoor space;
7. a mine with continuous block-damage overlay use;
8. enough travel to generate previously unseen terrain.

Write down the seed, player coordinates for every checkpoint, direction faced,
weather/time command or world state, and the number/type of explosions.

## 5. Scenario A — quiet baseline

Duration: 5 minutes after a 60-second warm-up.

Actions:

- stand at the base facing the same direction;
- do not open menus;
- do not generate new terrain;
- use the same framerate cap and profile.

Record:

- FPS once per second or from video/OCR tooling;
- live TPS and p95 from the title;
- shutdown p50/p95/p99/max;
- mesh/chunk/network high-water values;
- issued/suppressed texture binds;
- process working set if the OS tool can report it.

Pass:

- 20 TPS while unpaused;
- no steadily rising memory after warm-up;
- no GL errors;
- p95 is stable rather than increasing over time.

## 6. Scenario B — terrain traversal and mesh pressure

Duration: 10 minutes.

Actions:

- follow the exact eight-chunk route out and back;
- turn 180 degrees at every marked checkpoint;
- climb the tower/hill and rotate once;
- enter and leave the cave;
- on the last outbound leg, continue into new terrain.

Record:

- FPS/TPS/p95 at each checkpoint;
- largest visible stall;
- p50/p95/p99/max at shutdown;
- mesh and chunk high-water bytes;
- chunks generated and meshes rebuilt;
- disk activity or paging indication.

Pass:

- 20 TPS except bounded catch-up immediately after unavoidable disk stalls;
- no chunk corruption or permanent holes;
- safe-profile mesh high-water ≤ 20 MiB;
- safe-profile chunk high-water ≤ 8 MiB;
- no unbounded increase on repeated out-and-back travel;
- V129 p95/p99 is no worse than V128 outside measurement noise.

## 7. Scenario C — mining and overlay churn

Duration: 5 minutes.

Actions:

- hold mining on valid blocks continuously;
- alternate between successful breaks and aborting halfway;
- move the crosshair across adjacent faces while damage overlay is visible;
- place blocks between breaks.

This specifically exercises the reusable overlay mesh.

Pass:

- no heap/protection fault;
- no disappearing or stale block-damage overlay;
- no monotonic memory increase;
- frame-time spikes are lower or equal to V128 on the same path.

## 8. Scenario D — particles, weather, and explosions

Duration: 5 minutes.

Actions:

- enter rain or snow;
- trigger the same controlled explosion sequence;
- break particle-producing blocks;
- generate smoke/flame effects if available;
- view the event from the same location/direction.

Record:

- FPS and p95 during the maximum effect density;
- particle visual continuity;
- particle high-water/recycle values if using an instrumented log build;
- texture bind issued/suppressed counts.

Pass:

- `win98-safe` never has more than 192 active particles;
- particles remain layer-correct (terrain particles use terrain atlas);
- oldest effects may be recycled, but there is no array overrun or allocation
  growth;
- no GL error increase;
- simulation remains at 20 TPS.

## 9. Scenario E — save, quit, and recovery

Repeat 10 times:

1. modify blocks in at least three chunks;
2. change inventory/container state;
3. save and quit;
4. reopen;
5. verify the exact blocks and inventory/container contents.

On iterations 3 and 7, travel enough to force region cache churn before save.
On iteration 5, begin save after a particle/explosion event. Do not power off
the system while writing.

Pass:

- every save completes or reports a failure while keeping the world open;
- no success is reported for a failed verification;
- all successful saves reopen;
- non-forced background saving remains bounded to two chunks per pass;
- safe profile keeps no more than eight region files active;
- no zero-length or malformed region file.

## 10. Scenario F — minimize, restore, resize, and focus

Repeat 20 cycles:

1. run the world for 10 seconds;
2. Alt-Tab or minimize for 10 seconds;
3. restore;
4. resize between 640×480 and a second supported size;
5. resume movement.

Pass:

- no lost OpenGL context or black permanent frame;
- input is not stuck;
- no huge simulation jump after restore;
- timer resolution is released while inactive and reacquired on resume as
  inferred from the log/debug instrumentation;
- TPS returns to 20;
- save/quit still works after the final cycle.

## 11. Scenario G — multiplayer stream pressure

Use a controlled compatible server or packet test proxy.

Cases:

- one packet split across many TCP receives;
- many valid packets coalesced in one receive;
- receive window positioned near its physical end before another packet;
- enough valid traffic to force at least one compaction;
- packet burst approaching, but not exceeding, the selected read ceiling;
- valid traffic after compaction;
- peer orderly close;
- malformed packet in a separate negative test.

Pass:

- valid packets are processed in original byte-stream order;
- no more than 101 queued packets dispatch in one simulation tick;
- fragmented packet is processed once and only when complete;
- coalesced packets are all retained;
- `WSAEWOULDBLOCK` does not disconnect;
- orderly close reports termination cleanly;
- valid burst does not increment malformed count;
- safe-profile network high-water ≤ 512 KiB;
- the negative malformed test terminates without overwrite/crash.

Do not run malformed traffic against a public server.

## 12. Scenario H — 30-minute mixed endurance

Timeline:

| Minute | Action |
|---:|---|
| 0–5 | Quiet base, GUI/inventory/container use |
| 5–10 | Existing terrain route |
| 10–15 | New terrain generation |
| 15–20 | Mining, placement, particles, explosion |
| 20–23 | Weather and rapid camera turns |
| 23–25 | Minimize/restore/resize cycles |
| 25–28 | Region-crossing travel and background saves |
| 28–30 | Return, save and quit, then reopen |

Pass:

- no crash, hang, invalid-page fault, or resource-exhaustion dialog;
- final save reopens correctly;
- 20 TPS during unpaused steady gameplay;
- high-water values stop growing once the route repeats;
- zero malformed packets on valid traffic;
- zero new GL errors;
- no handle/resource trend that would exhaust the system in a longer run.

## 13. Measurement worksheet

Use one row per build/profile/scenario.

| Field | Value |
|---|---|
| Run ID | |
| Date/time | |
| Physical/VM/emulator | |
| OS/service pack | |
| CPU/clock | |
| RAM/pagefile | |
| GPU/driver | |
| Audio/driver | |
| Build SHA-256 | |
| Profile | |
| Resolution/color/depth | |
| Frame cap | |
| Scenario | |
| Duration | |
| FPS average/median if externally captured | |
| Frame p50 | |
| Frame p95 | |
| Frame p99 | |
| Frame maximum | |
| TPS minimum/typical | |
| Mesh high-water | |
| Chunk high-water | |
| Network high-water | |
| Texture binds/skipped binds | |
| Receive compactions | |
| Malformed packets | |
| GL errors | |
| Save failures | |
| Crash/hang/fault | |
| Notes | |

## 14. Frame-time interpretation

| Frame rate | Frame budget |
|---:|---:|
| 20 FPS | 50.0 ms |
| 30 FPS | 33.3 ms |
| 40 FPS | 25.0 ms |
| 60 FPS | 16.7 ms |

Suggested acceptance after terrain warm-up:

- 40 FPS cap: p95 near or below 25 ms;
- 30 FPS cap: p95 near or below 33.3 ms;
- p99 and maximum should improve versus V128 on the same hardware/route;
- no performance target overrides correctness, 20 TPS, save integrity, or
  profile ceilings.

The histogram's last bucket contains all frames at or above approximately
126 ms, while the separate maximum value preserves the worst observed frame.

## 15. Regression triage

If p95 improves but p99/max does not:

- correlate the stall with new terrain generation, save, texture upload, or
  region open;
- compare mesh/chunk high-water and rebuild count;
- repeat from a fresh world copy.

If average FPS improves but TPS falls:

- reject the result;
- inspect tick catch-up count and timer fallback;
- confirm the test was not paused or inactive.

If memory grows:

- identify whether chunk, mesh, network, region handle, particle, or process
  working set grows;
- repeat the same route rather than generating new terrain;
- confirm high-water ceilings in the shutdown log.

If only software OpenGL is slow:

- preserve it as a compatibility/stability baseline;
- use the vendor OpenGL 1.1 ICD for performance qualification;
- do not add an extension or shader requirement.

If Windows 98 faults but Windows XP passes:

- capture the exact fault module/address, last startup phase, profile log,
  display/audio driver, and action;
- rerun with `-profile=win98safe -safeaudio`;
- do not raise memory limits until ownership corruption is excluded.
