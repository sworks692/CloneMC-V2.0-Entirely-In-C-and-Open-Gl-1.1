/*
 * Shared public declarations for Java modules assigned to src/30_item.
 * 170 class-specific C implementations use this one subsystem header.
 * Detailed Java field/method inventories remain beside the implementation in
 * each same-named class C file, avoiding hundreds of tiny public headers.
 */
#ifndef CLONEMC_JAVA_PORT_30_ITEM_H
#define CLONEMC_JAVA_PORT_30_ITEM_H

#include "../00_core/clonemc_java_port_00_core.h"

#ifdef __cplusplus
extern "C" {
#endif

struct CloneMCJ_ItemStackTag;

struct CloneMCJ_WorldTag;
struct CloneMCJ_ItemStackTag;
struct CloneMCJ_EntityPlayerTag;
struct CloneMCJ_InventoryPlayerTag;
struct CloneMCJ_TileEntityTag;

/* Fixed-capacity release-era progression registration. */
void CloneMCJ_Progression_RegisterWorldTicks(struct CloneMCJ_WorldTag *);

/* Block.java: class, 875 Java lines. */
void CloneMCJ_Block_Register(void);
const char *CloneMCJ_Block_JavaName(void);
const char *CloneMCJ_Block_AssignedFolder(void);
unsigned long CloneMCJ_Block_JavaSourceHash32(void);

/* BlockBed.java: class, 282 Java lines. */
void CloneMCJ_BlockBed_Register(void);
const char *CloneMCJ_BlockBed_JavaName(void);
const char *CloneMCJ_BlockBed_AssignedFolder(void);
unsigned long CloneMCJ_BlockBed_JavaSourceHash32(void);
void CloneMCJ_BlockBed_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockBed_GetDirection(int);
int CloneMCJ_BlockBed_IsFoot(int);
int CloneMCJ_BlockBed_IsOccupied(int);
void CloneMCJ_BlockBed_SetOccupied(struct CloneMCJ_WorldTag *, int, int, int, int);

/* BlockBookshelf.java: class, 36 Java lines. */
void CloneMCJ_BlockBookshelf_Register(void);
const char *CloneMCJ_BlockBookshelf_JavaName(void);
const char *CloneMCJ_BlockBookshelf_AssignedFolder(void);
unsigned long CloneMCJ_BlockBookshelf_JavaSourceHash32(void);

/* BlockBreakable.java: class, 39 Java lines. */
void CloneMCJ_BlockBreakable_Register(void);
const char *CloneMCJ_BlockBreakable_JavaName(void);
const char *CloneMCJ_BlockBreakable_AssignedFolder(void);
unsigned long CloneMCJ_BlockBreakable_JavaSourceHash32(void);

/* BlockButton.java: class, 347 Java lines. */
void CloneMCJ_BlockButton_Register(void);
const char *CloneMCJ_BlockButton_JavaName(void);
const char *CloneMCJ_BlockButton_AssignedFolder(void);
unsigned long CloneMCJ_BlockButton_JavaSourceHash32(void);

/* BlockDispenser.java / TileEntityDispenser.java: direct 1.2.3 runtime. */
void CloneMCJ_BlockDispenser_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_TileEntityDispenser_GetRandomStack(
    struct CloneMCJ_TileEntityTag *, struct CloneMCJ_ItemStackTag *);

/* BlockCactus.java: class, 134 Java lines. */
void CloneMCJ_BlockCactus_Register(void);
const char *CloneMCJ_BlockCactus_JavaName(void);
const char *CloneMCJ_BlockCactus_AssignedFolder(void);
unsigned long CloneMCJ_BlockCactus_JavaSourceHash32(void);

/* BlockCake.java: class, 163 Java lines. */
void CloneMCJ_BlockCake_Register(void);
const char *CloneMCJ_BlockCake_JavaName(void);
const char *CloneMCJ_BlockCake_AssignedFolder(void);
unsigned long CloneMCJ_BlockCake_JavaSourceHash32(void);

/* BlockChest.java: class, 286 Java lines. */
void CloneMCJ_BlockChest_Register(void);
const char *CloneMCJ_BlockChest_JavaName(void);
const char *CloneMCJ_BlockChest_AssignedFolder(void);
unsigned long CloneMCJ_BlockChest_JavaSourceHash32(void);

/* BlockClay.java: class, 30 Java lines. */
void CloneMCJ_BlockClay_Register(void);
const char *CloneMCJ_BlockClay_JavaName(void);
const char *CloneMCJ_BlockClay_AssignedFolder(void);
unsigned long CloneMCJ_BlockClay_JavaSourceHash32(void);

/* BlockCloth.java: class, 46 Java lines. */
void CloneMCJ_BlockCloth_Register(void);
const char *CloneMCJ_BlockCloth_JavaName(void);
const char *CloneMCJ_BlockCloth_AssignedFolder(void);
unsigned long CloneMCJ_BlockCloth_JavaSourceHash32(void);
int CloneMCJ_BlockCloth_TextureNative(int);
int CloneMCJ_BlockCloth_DamageDroppedNative(int);
int CloneMCJ_BlockCloth_DyeToBlockMetadataNative(int);
int CloneMCJ_BlockCloth_BlockMetadataToDyeNative(int);

/* BlockContainer.java: class, 40 Java lines. */
void CloneMCJ_BlockContainer_Register(void);
const char *CloneMCJ_BlockContainer_JavaName(void);
const char *CloneMCJ_BlockContainer_AssignedFolder(void);
unsigned long CloneMCJ_BlockContainer_JavaSourceHash32(void);

/* BlockCrops.java: class, 150 Java lines. */
void CloneMCJ_BlockCrops_Register(void);
const char *CloneMCJ_BlockCrops_JavaName(void);
const char *CloneMCJ_BlockCrops_AssignedFolder(void);
unsigned long CloneMCJ_BlockCrops_JavaSourceHash32(void);

/* BlockDeadBush.java: class, 37 Java lines. */
void CloneMCJ_BlockDeadBush_Register(void);
const char *CloneMCJ_BlockDeadBush_JavaName(void);
const char *CloneMCJ_BlockDeadBush_AssignedFolder(void);
unsigned long CloneMCJ_BlockDeadBush_JavaSourceHash32(void);

/* BlockDetectorRail.java: class, 113 Java lines. */
void CloneMCJ_BlockDetectorRail_Register(void);
const char *CloneMCJ_BlockDetectorRail_JavaName(void);
const char *CloneMCJ_BlockDetectorRail_AssignedFolder(void);
unsigned long CloneMCJ_BlockDetectorRail_JavaSourceHash32(void);

/* BlockDirt.java: class, 19 Java lines. */
void CloneMCJ_BlockDirt_Register(void);
const char *CloneMCJ_BlockDirt_JavaName(void);
const char *CloneMCJ_BlockDirt_AssignedFolder(void);
unsigned long CloneMCJ_BlockDirt_JavaSourceHash32(void);

/* BlockDispenser.java: class, 278 Java lines. */
void CloneMCJ_BlockDispenser_Register(void);
const char *CloneMCJ_BlockDispenser_JavaName(void);
const char *CloneMCJ_BlockDispenser_AssignedFolder(void);
unsigned long CloneMCJ_BlockDispenser_JavaSourceHash32(void);

/* BlockDoor.java: class, 258 Java lines. */
void CloneMCJ_BlockDoor_Register(void);
const char *CloneMCJ_BlockDoor_JavaName(void);
const char *CloneMCJ_BlockDoor_AssignedFolder(void);
unsigned long CloneMCJ_BlockDoor_JavaSourceHash32(void);

/* BlockFarmland.java: class, 139 Java lines. */
void CloneMCJ_BlockFarmland_Register(void);
const char *CloneMCJ_BlockFarmland_JavaName(void);
const char *CloneMCJ_BlockFarmland_AssignedFolder(void);
unsigned long CloneMCJ_BlockFarmland_JavaSourceHash32(void);

/* BlockFence.java: class, 54 Java lines. */
void CloneMCJ_BlockFence_Register(void);
const char *CloneMCJ_BlockFence_JavaName(void);
const char *CloneMCJ_BlockFence_AssignedFolder(void);
unsigned long CloneMCJ_BlockFence_JavaSourceHash32(void);

/* BlockFire.java: class, 352 Java lines. */
void CloneMCJ_BlockFire_Register(void);
const char *CloneMCJ_BlockFire_JavaName(void);
const char *CloneMCJ_BlockFire_AssignedFolder(void);
unsigned long CloneMCJ_BlockFire_JavaSourceHash32(void);

/* BlockFlower.java: class, 80 Java lines. */
void CloneMCJ_BlockFlower_Register(void);
const char *CloneMCJ_BlockFlower_JavaName(void);
const char *CloneMCJ_BlockFlower_AssignedFolder(void);
unsigned long CloneMCJ_BlockFlower_JavaSourceHash32(void);

/* BlockFlowing.java: class, 328 Java lines. */
void CloneMCJ_BlockFlowing_Register(void);
const char *CloneMCJ_BlockFlowing_JavaName(void);
const char *CloneMCJ_BlockFlowing_AssignedFolder(void);
unsigned long CloneMCJ_BlockFlowing_JavaSourceHash32(void);

/* BlockFluid.java: class, 380 Java lines. */
void CloneMCJ_BlockFluid_Register(void);
const char *CloneMCJ_BlockFluid_JavaName(void);
const char *CloneMCJ_BlockFluid_AssignedFolder(void);
unsigned long CloneMCJ_BlockFluid_JavaSourceHash32(void);

/* BlockFurnace.java: class, 247 Java lines. */
void CloneMCJ_BlockFurnace_Register(void);
const char *CloneMCJ_BlockFurnace_JavaName(void);
const char *CloneMCJ_BlockFurnace_AssignedFolder(void);
unsigned long CloneMCJ_BlockFurnace_JavaSourceHash32(void);

/* BlockGlass.java: class, 30 Java lines. */
void CloneMCJ_BlockGlass_Register(void);
const char *CloneMCJ_BlockGlass_JavaName(void);
const char *CloneMCJ_BlockGlass_AssignedFolder(void);
unsigned long CloneMCJ_BlockGlass_JavaSourceHash32(void);

/* BlockGlowStone.java: class, 30 Java lines. */
void CloneMCJ_BlockGlowStone_Register(void);
const char *CloneMCJ_BlockGlowStone_JavaName(void);
const char *CloneMCJ_BlockGlowStone_AssignedFolder(void);
unsigned long CloneMCJ_BlockGlowStone_JavaSourceHash32(void);

/* BlockGrass.java: class, 77 Java lines. */
void CloneMCJ_BlockGrass_Register(void);
const char *CloneMCJ_BlockGrass_JavaName(void);
const char *CloneMCJ_BlockGrass_AssignedFolder(void);
unsigned long CloneMCJ_BlockGrass_JavaSourceHash32(void);

/* BlockGravel.java: class, 31 Java lines. */
void CloneMCJ_BlockGravel_Register(void);
const char *CloneMCJ_BlockGravel_JavaName(void);
const char *CloneMCJ_BlockGravel_AssignedFolder(void);
unsigned long CloneMCJ_BlockGravel_JavaSourceHash32(void);

/* BlockIce.java: class, 62 Java lines. */
void CloneMCJ_BlockIce_Register(void);
const char *CloneMCJ_BlockIce_JavaName(void);
const char *CloneMCJ_BlockIce_AssignedFolder(void);
unsigned long CloneMCJ_BlockIce_JavaSourceHash32(void);

/* BlockJukeBox.java: class, 106 Java lines. */
void CloneMCJ_BlockJukeBox_Register(void);
const char *CloneMCJ_BlockJukeBox_JavaName(void);
const char *CloneMCJ_BlockJukeBox_AssignedFolder(void);
unsigned long CloneMCJ_BlockJukeBox_JavaSourceHash32(void);

/* BlockLadder.java: class, 153 Java lines. */
void CloneMCJ_BlockLadder_Register(void);
const char *CloneMCJ_BlockLadder_JavaName(void);
const char *CloneMCJ_BlockLadder_AssignedFolder(void);
unsigned long CloneMCJ_BlockLadder_JavaSourceHash32(void);

/* BlockLeaves.java: class, 250 Java lines. */
void CloneMCJ_BlockLeaves_Register(void);
const char *CloneMCJ_BlockLeaves_JavaName(void);
const char *CloneMCJ_BlockLeaves_AssignedFolder(void);
unsigned long CloneMCJ_BlockLeaves_JavaSourceHash32(void);

/* BlockLeavesBase.java: class, 39 Java lines. */
void CloneMCJ_BlockLeavesBase_Register(void);
const char *CloneMCJ_BlockLeavesBase_JavaName(void);
const char *CloneMCJ_BlockLeavesBase_AssignedFolder(void);
unsigned long CloneMCJ_BlockLeavesBase_JavaSourceHash32(void);

/* BlockLever.java: class, 309 Java lines. */
void CloneMCJ_BlockLever_Register(void);
const char *CloneMCJ_BlockLever_JavaName(void);
const char *CloneMCJ_BlockLever_AssignedFolder(void);
unsigned long CloneMCJ_BlockLever_JavaSourceHash32(void);

/* BlockLockedChest.java: class, 84 Java lines. */
void CloneMCJ_BlockLockedChest_Register(void);
const char *CloneMCJ_BlockLockedChest_JavaName(void);
const char *CloneMCJ_BlockLockedChest_AssignedFolder(void);
unsigned long CloneMCJ_BlockLockedChest_JavaSourceHash32(void);

/* BlockLog.java: class, 90 Java lines. */
void CloneMCJ_BlockLog_Register(void);
const char *CloneMCJ_BlockLog_JavaName(void);
const char *CloneMCJ_BlockLog_AssignedFolder(void);
unsigned long CloneMCJ_BlockLog_JavaSourceHash32(void);

/* BlockMobSpawner.java: class, 40 Java lines. */
void CloneMCJ_BlockMobSpawner_Register(void);
const char *CloneMCJ_BlockMobSpawner_JavaName(void);
const char *CloneMCJ_BlockMobSpawner_AssignedFolder(void);
unsigned long CloneMCJ_BlockMobSpawner_JavaSourceHash32(void);

/* BlockMushroom.java: class, 58 Java lines. */
void CloneMCJ_BlockMushroom_Register(void);
const char *CloneMCJ_BlockMushroom_JavaName(void);
const char *CloneMCJ_BlockMushroom_AssignedFolder(void);
unsigned long CloneMCJ_BlockMushroom_JavaSourceHash32(void);

/* BlockNetherrack.java: class, 19 Java lines. */
void CloneMCJ_BlockNetherrack_Register(void);
const char *CloneMCJ_BlockNetherrack_JavaName(void);
const char *CloneMCJ_BlockNetherrack_AssignedFolder(void);
unsigned long CloneMCJ_BlockNetherrack_JavaSourceHash32(void);

/* BlockNote.java: class, 98 Java lines. */
void CloneMCJ_BlockNote_Register(void);
const char *CloneMCJ_BlockNote_JavaName(void);
const char *CloneMCJ_BlockNote_AssignedFolder(void);
unsigned long CloneMCJ_BlockNote_JavaSourceHash32(void);

/* BlockObsidian.java: class, 30 Java lines. */
void CloneMCJ_BlockObsidian_Register(void);
const char *CloneMCJ_BlockObsidian_JavaName(void);
const char *CloneMCJ_BlockObsidian_AssignedFolder(void);
unsigned long CloneMCJ_BlockObsidian_JavaSourceHash32(void);

/* BlockOre.java: class, 55 Java lines. */
void CloneMCJ_BlockOre_Register(void);
const char *CloneMCJ_BlockOre_JavaName(void);
const char *CloneMCJ_BlockOre_AssignedFolder(void);
unsigned long CloneMCJ_BlockOre_JavaSourceHash32(void);

/* BlockOreStorage.java: class, 25 Java lines. */
void CloneMCJ_BlockOreStorage_Register(void);
const char *CloneMCJ_BlockOreStorage_JavaName(void);
const char *CloneMCJ_BlockOreStorage_AssignedFolder(void);
unsigned long CloneMCJ_BlockOreStorage_JavaSourceHash32(void);

/* BlockPistonBase.java: class, 469 Java lines. */
void CloneMCJ_BlockPistonBase_Register(void);
const char *CloneMCJ_BlockPistonBase_JavaName(void);
const char *CloneMCJ_BlockPistonBase_AssignedFolder(void);
unsigned long CloneMCJ_BlockPistonBase_JavaSourceHash32(void);

/* BlockPistonExtension.java: class, 206 Java lines. */
void CloneMCJ_BlockPistonExtension_Register(void);
const char *CloneMCJ_BlockPistonExtension_JavaName(void);
const char *CloneMCJ_BlockPistonExtension_AssignedFolder(void);
unsigned long CloneMCJ_BlockPistonExtension_JavaSourceHash32(void);

/* BlockPistonMoving.java: class, 191 Java lines. */
void CloneMCJ_BlockPistonMoving_Register(void);
const char *CloneMCJ_BlockPistonMoving_JavaName(void);
const char *CloneMCJ_BlockPistonMoving_AssignedFolder(void);
unsigned long CloneMCJ_BlockPistonMoving_JavaSourceHash32(void);

/* BlockPortal.java: class, 229 Java lines. */
void CloneMCJ_BlockPortal_Register(void);
const char *CloneMCJ_BlockPortal_JavaName(void);
const char *CloneMCJ_BlockPortal_AssignedFolder(void);
unsigned long CloneMCJ_BlockPortal_JavaSourceHash32(void);
int CloneMCJ_BlockPortal_TryCreate(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockPortal_IsValid(struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_BlockPortal_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockSign_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockSign_CanStayNative(struct CloneMCJ_WorldTag *,int,int,int,int,int);
void CloneMCJ_BlockCake_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockCake_CanStayNative(struct CloneMCJ_WorldTag *,int,int,int);
int CloneMCJ_BlockCake_ActivateNative(struct CloneMCJ_WorldTag *,int,int,int,
    struct CloneMCJ_EntityPlayerTag *);
int CloneMCJ_ItemFlintAndSteel_UseNative(struct CloneMCJ_WorldTag *,
    struct CloneMCJ_ItemStackTag *,struct CloneMCJ_EntityPlayerTag *,
    int,int,int,int);

/* BlockPressurePlate.java: class, 206 Java lines. */
void CloneMCJ_BlockPressurePlate_Register(void);
const char *CloneMCJ_BlockPressurePlate_JavaName(void);
const char *CloneMCJ_BlockPressurePlate_AssignedFolder(void);
unsigned long CloneMCJ_BlockPressurePlate_JavaSourceHash32(void);

/* BlockPumpkin.java: class, 97 Java lines. */
void CloneMCJ_BlockPumpkin_Register(void);
const char *CloneMCJ_BlockPumpkin_JavaName(void);
const char *CloneMCJ_BlockPumpkin_AssignedFolder(void);
unsigned long CloneMCJ_BlockPumpkin_JavaSourceHash32(void);

/* BlockRail.java: class, 321 Java lines. */
void CloneMCJ_BlockRail_Register(void);
const char *CloneMCJ_BlockRail_JavaName(void);
const char *CloneMCJ_BlockRail_AssignedFolder(void);
unsigned long CloneMCJ_BlockRail_JavaSourceHash32(void);

/* BlockRedstoneOre.java: class, 127 Java lines. */
void CloneMCJ_BlockRedstoneOre_Register(void);
const char *CloneMCJ_BlockRedstoneOre_JavaName(void);
const char *CloneMCJ_BlockRedstoneOre_AssignedFolder(void);
unsigned long CloneMCJ_BlockRedstoneOre_JavaSourceHash32(void);

/* BlockRedstoneRepeater.java: class, 278 Java lines. */
void CloneMCJ_BlockRedstoneRepeater_Register(void);
const char *CloneMCJ_BlockRedstoneRepeater_JavaName(void);
const char *CloneMCJ_BlockRedstoneRepeater_AssignedFolder(void);
unsigned long CloneMCJ_BlockRedstoneRepeater_JavaSourceHash32(void);

/* BlockRedstoneTorch.java: class, 230 Java lines. */
void CloneMCJ_BlockRedstoneTorch_Register(void);
const char *CloneMCJ_BlockRedstoneTorch_JavaName(void);
const char *CloneMCJ_BlockRedstoneTorch_AssignedFolder(void);
unsigned long CloneMCJ_BlockRedstoneTorch_JavaSourceHash32(void);

/* BlockRedstoneWire.java: class, 471 Java lines. */
void CloneMCJ_BlockRedstoneWire_Register(void);
const char *CloneMCJ_BlockRedstoneWire_JavaName(void);
const char *CloneMCJ_BlockRedstoneWire_AssignedFolder(void);
unsigned long CloneMCJ_BlockRedstoneWire_JavaSourceHash32(void);

/* BlockReed.java: class, 116 Java lines. */
void CloneMCJ_BlockReed_Register(void);
const char *CloneMCJ_BlockReed_JavaName(void);
const char *CloneMCJ_BlockReed_AssignedFolder(void);
unsigned long CloneMCJ_BlockReed_JavaSourceHash32(void);

/* BlockSand.java: class, 87 Java lines. */
void CloneMCJ_BlockSand_Register(void);
void CloneMCJ_BlockSand_RegisterRuntime(struct CloneMCJ_WorldTag *);
const char *CloneMCJ_BlockSand_JavaName(void);
const char *CloneMCJ_BlockSand_AssignedFolder(void);
unsigned long CloneMCJ_BlockSand_JavaSourceHash32(void);

/* BlockSandStone.java: class, 34 Java lines. */
void CloneMCJ_BlockSandStone_Register(void);
const char *CloneMCJ_BlockSandStone_JavaName(void);
const char *CloneMCJ_BlockSandStone_AssignedFolder(void);
unsigned long CloneMCJ_BlockSandStone_JavaSourceHash32(void);

/* BlockSapling.java: class, 90 Java lines. */
void CloneMCJ_BlockSapling_Register(void);
const char *CloneMCJ_BlockSapling_JavaName(void);
const char *CloneMCJ_BlockSapling_AssignedFolder(void);
unsigned long CloneMCJ_BlockSapling_JavaSourceHash32(void);

/* BlockSign.java: class, 142 Java lines. */
void CloneMCJ_BlockSign_Register(void);
const char *CloneMCJ_BlockSign_JavaName(void);
const char *CloneMCJ_BlockSign_AssignedFolder(void);
unsigned long CloneMCJ_BlockSign_JavaSourceHash32(void);

/* BlockSnow.java: class, 127 Java lines. */
void CloneMCJ_BlockSnow_Register(void);
const char *CloneMCJ_BlockSnow_JavaName(void);
const char *CloneMCJ_BlockSnow_AssignedFolder(void);
unsigned long CloneMCJ_BlockSnow_JavaSourceHash32(void);

/* BlockSnowBlock.java: class, 41 Java lines. */
void CloneMCJ_BlockSnowBlock_Register(void);
const char *CloneMCJ_BlockSnowBlock_JavaName(void);
const char *CloneMCJ_BlockSnowBlock_AssignedFolder(void);
unsigned long CloneMCJ_BlockSnowBlock_JavaSourceHash32(void);

/* BlockSoulSand.java: class, 32 Java lines. */
void CloneMCJ_BlockSoulSand_Register(void);
const char *CloneMCJ_BlockSoulSand_JavaName(void);
const char *CloneMCJ_BlockSoulSand_AssignedFolder(void);
unsigned long CloneMCJ_BlockSoulSand_JavaSourceHash32(void);

/* BlockSponge.java: class, 56 Java lines. */
void CloneMCJ_BlockSponge_Register(void);
const char *CloneMCJ_BlockSponge_JavaName(void);
const char *CloneMCJ_BlockSponge_AssignedFolder(void);
unsigned long CloneMCJ_BlockSponge_JavaSourceHash32(void);

/* BlockStairs.java: class, 236 Java lines. */
void CloneMCJ_BlockStairs_Register(void);
const char *CloneMCJ_BlockStairs_JavaName(void);
const char *CloneMCJ_BlockStairs_AssignedFolder(void);
unsigned long CloneMCJ_BlockStairs_JavaSourceHash32(void);

/* BlockStationary.java: class, 79 Java lines. */
void CloneMCJ_BlockStationary_Register(void);
const char *CloneMCJ_BlockStationary_JavaName(void);
const char *CloneMCJ_BlockStationary_AssignedFolder(void);
unsigned long CloneMCJ_BlockStationary_JavaSourceHash32(void);

/* BlockStep.java: class, 126 Java lines. */
void CloneMCJ_BlockStep_Register(void);
const char *CloneMCJ_BlockStep_JavaName(void);
const char *CloneMCJ_BlockStep_AssignedFolder(void);
unsigned long CloneMCJ_BlockStep_JavaSourceHash32(void);

/* BlockStone.java: class, 25 Java lines. */
void CloneMCJ_BlockStone_Register(void);
const char *CloneMCJ_BlockStone_JavaName(void);
const char *CloneMCJ_BlockStone_AssignedFolder(void);
unsigned long CloneMCJ_BlockStone_JavaSourceHash32(void);

/* BlockTallGrass.java: class, 73 Java lines. */
void CloneMCJ_BlockTallGrass_Register(void);
const char *CloneMCJ_BlockTallGrass_JavaName(void);
const char *CloneMCJ_BlockTallGrass_AssignedFolder(void);
unsigned long CloneMCJ_BlockTallGrass_JavaSourceHash32(void);

/* BlockTNT.java: class, 98 Java lines. */
void CloneMCJ_BlockTNT_Register(void);
const char *CloneMCJ_BlockTNT_JavaName(void);
const char *CloneMCJ_BlockTNT_AssignedFolder(void);
unsigned long CloneMCJ_BlockTNT_JavaSourceHash32(void);

/* BlockTorch.java: class, 236 Java lines. */
void CloneMCJ_BlockTorch_Register(void);
const char *CloneMCJ_BlockTorch_JavaName(void);
const char *CloneMCJ_BlockTorch_AssignedFolder(void);
unsigned long CloneMCJ_BlockTorch_JavaSourceHash32(void);

/* BlockTrapDoor.java: class, 224 Java lines. */
void CloneMCJ_BlockTrapDoor_Register(void);
const char *CloneMCJ_BlockTrapDoor_JavaName(void);
const char *CloneMCJ_BlockTrapDoor_AssignedFolder(void);
unsigned long CloneMCJ_BlockTrapDoor_JavaSourceHash32(void);

/* BlockWeb.java: class, 51 Java lines. */
void CloneMCJ_BlockWeb_Register(void);
const char *CloneMCJ_BlockWeb_JavaName(void);
const char *CloneMCJ_BlockWeb_AssignedFolder(void);
unsigned long CloneMCJ_BlockWeb_JavaSourceHash32(void);

/* BlockWorkbench.java: class, 51 Java lines. */
void CloneMCJ_BlockWorkbench_Register(void);
const char *CloneMCJ_BlockWorkbench_JavaName(void);
const char *CloneMCJ_BlockWorkbench_AssignedFolder(void);
unsigned long CloneMCJ_BlockWorkbench_JavaSourceHash32(void);

/* Container.java: class, 331 Java lines. */
void CloneMCJ_Container_Register(void);
const char *CloneMCJ_Container_JavaName(void);
const char *CloneMCJ_Container_AssignedFolder(void);
unsigned long CloneMCJ_Container_JavaSourceHash32(void);

/* ContainerChest.java: class, 80 Java lines. */
void CloneMCJ_ContainerChest_Register(void);
const char *CloneMCJ_ContainerChest_JavaName(void);
const char *CloneMCJ_ContainerChest_AssignedFolder(void);
unsigned long CloneMCJ_ContainerChest_JavaSourceHash32(void);

/* ContainerDispenser.java: class, 50 Java lines. */
void CloneMCJ_ContainerDispenser_Register(void);
const char *CloneMCJ_ContainerDispenser_JavaName(void);
const char *CloneMCJ_ContainerDispenser_AssignedFolder(void);
unsigned long CloneMCJ_ContainerDispenser_JavaSourceHash32(void);

/* ContainerFurnace.java: class, 133 Java lines. */
void CloneMCJ_ContainerFurnace_Register(void);
const char *CloneMCJ_ContainerFurnace_JavaName(void);
const char *CloneMCJ_ContainerFurnace_AssignedFolder(void);
unsigned long CloneMCJ_ContainerFurnace_JavaSourceHash32(void);

/* ContainerPlayer.java: class, 131 Java lines. */
void CloneMCJ_ContainerPlayer_Register(void);
const char *CloneMCJ_ContainerPlayer_JavaName(void);
const char *CloneMCJ_ContainerPlayer_AssignedFolder(void);
unsigned long CloneMCJ_ContainerPlayer_JavaSourceHash32(void);

/* ContainerWorkbench.java: class, 132 Java lines. */
void CloneMCJ_ContainerWorkbench_Register(void);
const char *CloneMCJ_ContainerWorkbench_JavaName(void);
const char *CloneMCJ_ContainerWorkbench_AssignedFolder(void);
unsigned long CloneMCJ_ContainerWorkbench_JavaSourceHash32(void);

/* CraftingManager.java: class, 327 Java lines. */
void CloneMCJ_CraftingManager_Register(void);
const char *CloneMCJ_CraftingManager_JavaName(void);
const char *CloneMCJ_CraftingManager_AssignedFolder(void);
unsigned long CloneMCJ_CraftingManager_JavaSourceHash32(void);

/* EnumToolMaterial.java: enum, 81 Java lines. */
void CloneMCJ_EnumToolMaterial_Register(void);
const char *CloneMCJ_EnumToolMaterial_JavaName(void);
const char *CloneMCJ_EnumToolMaterial_AssignedFolder(void);
unsigned long CloneMCJ_EnumToolMaterial_JavaSourceHash32(void);

/* FurnaceRecipes.java: class, 55 Java lines. */
void CloneMCJ_FurnaceRecipes_Register(void);
const char *CloneMCJ_FurnaceRecipes_JavaName(void);
const char *CloneMCJ_FurnaceRecipes_AssignedFolder(void);
unsigned long CloneMCJ_FurnaceRecipes_JavaSourceHash32(void);

/* ICrafting.java: interface, 18 Java lines. */
void CloneMCJ_ICrafting_Register(void);
const char *CloneMCJ_ICrafting_JavaName(void);
const char *CloneMCJ_ICrafting_AssignedFolder(void);
unsigned long CloneMCJ_ICrafting_JavaSourceHash32(void);

/* IInvBasic.java: interface, 16 Java lines. */
void CloneMCJ_IInvBasic_Register(void);
const char *CloneMCJ_IInvBasic_JavaName(void);
const char *CloneMCJ_IInvBasic_AssignedFolder(void);
unsigned long CloneMCJ_IInvBasic_JavaSourceHash32(void);

/* IInventory.java: interface, 30 Java lines. */
void CloneMCJ_IInventory_Register(void);
const char *CloneMCJ_IInventory_JavaName(void);
const char *CloneMCJ_IInventory_AssignedFolder(void);
unsigned long CloneMCJ_IInventory_JavaSourceHash32(void);

/* InventoryBasic.java: class, 99 Java lines. */
void CloneMCJ_InventoryBasic_Register(void);
const char *CloneMCJ_InventoryBasic_JavaName(void);
const char *CloneMCJ_InventoryBasic_AssignedFolder(void);
unsigned long CloneMCJ_InventoryBasic_JavaSourceHash32(void);

/* InventoryCrafting.java: class, 104 Java lines. */
void CloneMCJ_InventoryCrafting_Register(void);
const char *CloneMCJ_InventoryCrafting_JavaName(void);
const char *CloneMCJ_InventoryCrafting_AssignedFolder(void);
unsigned long CloneMCJ_InventoryCrafting_JavaSourceHash32(void);

/* InventoryCraftResult.java: class, 69 Java lines. */
void CloneMCJ_InventoryCraftResult_Register(void);
const char *CloneMCJ_InventoryCraftResult_JavaName(void);
const char *CloneMCJ_InventoryCraftResult_AssignedFolder(void);
unsigned long CloneMCJ_InventoryCraftResult_JavaSourceHash32(void);

/* InventoryLargeChest.java: class, 85 Java lines. */
void CloneMCJ_InventoryLargeChest_Register(void);
const char *CloneMCJ_InventoryLargeChest_JavaName(void);
const char *CloneMCJ_InventoryLargeChest_AssignedFolder(void);
unsigned long CloneMCJ_InventoryLargeChest_JavaSourceHash32(void);

/* InventoryPlayer.java: class, 473 Java lines. */
void CloneMCJ_InventoryPlayer_Register(void);
const char *CloneMCJ_InventoryPlayer_JavaName(void);
const char *CloneMCJ_InventoryPlayer_AssignedFolder(void);
unsigned long CloneMCJ_InventoryPlayer_JavaSourceHash32(void);

/* IRecipe.java: interface, 22 Java lines. */
void CloneMCJ_IRecipe_Register(void);
const char *CloneMCJ_IRecipe_JavaName(void);
const char *CloneMCJ_IRecipe_AssignedFolder(void);
unsigned long CloneMCJ_IRecipe_JavaSourceHash32(void);

/* Item.java: class, 373 Java lines. */
void CloneMCJ_Item_Register(void);
const char *CloneMCJ_Item_JavaName(void);
const char *CloneMCJ_Item_AssignedFolder(void);
unsigned long CloneMCJ_Item_JavaSourceHash32(void);

/* ItemArmor.java: class, 37 Java lines. */
void CloneMCJ_ItemArmor_Register(void);
const char *CloneMCJ_ItemArmor_JavaName(void);
const char *CloneMCJ_ItemArmor_AssignedFolder(void);
unsigned long CloneMCJ_ItemArmor_JavaSourceHash32(void);
int CloneMCJ_ItemArmor_IsArmorNative(int, int *);
int CloneMCJ_ItemArmor_EquipRightClickNative(struct CloneMCJ_InventoryPlayerTag *, struct CloneMCJ_ItemStackTag *);

/* ItemAxe.java: class, 28 Java lines. */
void CloneMCJ_ItemAxe_Register(void);
const char *CloneMCJ_ItemAxe_JavaName(void);
const char *CloneMCJ_ItemAxe_AssignedFolder(void);
unsigned long CloneMCJ_ItemAxe_JavaSourceHash32(void);

/* ItemBed.java: class, 59 Java lines. */
void CloneMCJ_ItemBed_Register(void);
const char *CloneMCJ_ItemBed_JavaName(void);
const char *CloneMCJ_ItemBed_AssignedFolder(void);
unsigned long CloneMCJ_ItemBed_JavaSourceHash32(void);

/* ItemBlock.java: class, 91 Java lines. */
void CloneMCJ_ItemBlock_Register(void);
const char *CloneMCJ_ItemBlock_JavaName(void);
const char *CloneMCJ_ItemBlock_AssignedFolder(void);
unsigned long CloneMCJ_ItemBlock_JavaSourceHash32(void);

/* ItemBoat.java: class, 63 Java lines. */
void CloneMCJ_ItemBoat_Register(void);
const char *CloneMCJ_ItemBoat_JavaName(void);
const char *CloneMCJ_ItemBoat_AssignedFolder(void);
unsigned long CloneMCJ_ItemBoat_JavaSourceHash32(void);

/* ItemBow.java: class, 35 Java lines. */
void CloneMCJ_ItemBow_Register(void);
const char *CloneMCJ_ItemBow_JavaName(void);
const char *CloneMCJ_ItemBow_AssignedFolder(void);
unsigned long CloneMCJ_ItemBow_JavaSourceHash32(void);

/* ItemBucket.java: class, 125 Java lines. */
void CloneMCJ_ItemBucket_Register(void);
const char *CloneMCJ_ItemBucket_JavaName(void);
const char *CloneMCJ_ItemBucket_AssignedFolder(void);
unsigned long CloneMCJ_ItemBucket_JavaSourceHash32(void);
int CloneMCJ_ItemBucket_UseNative(struct CloneMCJ_WorldTag *,
    struct CloneMCJ_EntityPlayerTag *, struct CloneMCJ_ItemStackTag *);

/* ItemCloth.java: class, 37 Java lines. */
void CloneMCJ_ItemCloth_Register(void);
const char *CloneMCJ_ItemCloth_JavaName(void);
const char *CloneMCJ_ItemCloth_AssignedFolder(void);
unsigned long CloneMCJ_ItemCloth_JavaSourceHash32(void);

/* ItemCoal.java: class, 32 Java lines. */
void CloneMCJ_ItemCoal_Register(void);
const char *CloneMCJ_ItemCoal_JavaName(void);
const char *CloneMCJ_ItemCoal_AssignedFolder(void);
unsigned long CloneMCJ_ItemCoal_JavaSourceHash32(void);

/* ItemCookie.java: class, 20 Java lines. */
void CloneMCJ_ItemCookie_Register(void);
const char *CloneMCJ_ItemCookie_JavaName(void);
const char *CloneMCJ_ItemCookie_AssignedFolder(void);
unsigned long CloneMCJ_ItemCookie_JavaSourceHash32(void);

/* ItemDoor.java: class, 90 Java lines. */
void CloneMCJ_ItemDoor_Register(void);
const char *CloneMCJ_ItemDoor_JavaName(void);
const char *CloneMCJ_ItemDoor_AssignedFolder(void);
unsigned long CloneMCJ_ItemDoor_JavaSourceHash32(void);

/* ItemDye.java: class, 130 Java lines. */
void CloneMCJ_ItemDye_Register(void);
const char *CloneMCJ_ItemDye_JavaName(void);
const char *CloneMCJ_ItemDye_AssignedFolder(void);
unsigned long CloneMCJ_ItemDye_JavaSourceHash32(void);

/* ItemEgg.java: class, 33 Java lines. */
void CloneMCJ_ItemEgg_Register(void);
const char *CloneMCJ_ItemEgg_JavaName(void);
const char *CloneMCJ_ItemEgg_AssignedFolder(void);
unsigned long CloneMCJ_ItemEgg_JavaSourceHash32(void);

/* ItemFishingRod.java: class, 52 Java lines. */
void CloneMCJ_ItemFishingRod_Register(void);
const char *CloneMCJ_ItemFishingRod_JavaName(void);
const char *CloneMCJ_ItemFishingRod_AssignedFolder(void);
unsigned long CloneMCJ_ItemFishingRod_JavaSourceHash32(void);

/* ItemFlintAndSteel.java: class, 59 Java lines. */
void CloneMCJ_ItemFlintAndSteel_Register(void);
const char *CloneMCJ_ItemFlintAndSteel_JavaName(void);
const char *CloneMCJ_ItemFlintAndSteel_AssignedFolder(void);
unsigned long CloneMCJ_ItemFlintAndSteel_JavaSourceHash32(void);

/* ItemFood.java: class, 42 Java lines. */
void CloneMCJ_ItemFood_Register(void);
const char *CloneMCJ_ItemFood_JavaName(void);
const char *CloneMCJ_ItemFood_AssignedFolder(void);
unsigned long CloneMCJ_ItemFood_JavaSourceHash32(void);

/* ItemHoe.java: class, 50 Java lines. */
void CloneMCJ_ItemHoe_Register(void);
int CloneMCJ_ItemHoe_UseNative(struct CloneMCJ_WorldTag *, struct CloneMCJ_ItemStackTag *,
    struct CloneMCJ_EntityPlayerTag *, int, int, int, int);
const char *CloneMCJ_ItemHoe_JavaName(void);
const char *CloneMCJ_ItemHoe_AssignedFolder(void);
unsigned long CloneMCJ_ItemHoe_JavaSourceHash32(void);

/* ItemLeaves.java: class, 46 Java lines. */
void CloneMCJ_ItemLeaves_Register(void);
const char *CloneMCJ_ItemLeaves_JavaName(void);
const char *CloneMCJ_ItemLeaves_AssignedFolder(void);
unsigned long CloneMCJ_ItemLeaves_JavaSourceHash32(void);

/* ItemLog.java: class, 31 Java lines. */
void CloneMCJ_ItemLog_Register(void);
const char *CloneMCJ_ItemLog_JavaName(void);
const char *CloneMCJ_ItemLog_AssignedFolder(void);
unsigned long CloneMCJ_ItemLog_JavaSourceHash32(void);

/* ItemMap.java: class, 268 Java lines. */
void CloneMCJ_ItemMap_Register(void);
const char *CloneMCJ_ItemMap_JavaName(void);
const char *CloneMCJ_ItemMap_AssignedFolder(void);
unsigned long CloneMCJ_ItemMap_JavaSourceHash32(void);

/* ItemMapBase.java: class, 19 Java lines. */
void CloneMCJ_ItemMapBase_Register(void);
const char *CloneMCJ_ItemMapBase_JavaName(void);
const char *CloneMCJ_ItemMapBase_AssignedFolder(void);
unsigned long CloneMCJ_ItemMapBase_JavaSourceHash32(void);

/* ItemMinecart.java: class, 41 Java lines. */
void CloneMCJ_ItemMinecart_Register(void);
const char *CloneMCJ_ItemMinecart_JavaName(void);
const char *CloneMCJ_ItemMinecart_AssignedFolder(void);
unsigned long CloneMCJ_ItemMinecart_JavaSourceHash32(void);

/* ItemPainting.java: class, 55 Java lines. */
void CloneMCJ_ItemPainting_Register(void);
const char *CloneMCJ_ItemPainting_JavaName(void);
const char *CloneMCJ_ItemPainting_AssignedFolder(void);
unsigned long CloneMCJ_ItemPainting_JavaSourceHash32(void);

/* ItemPickaxe.java: class, 62 Java lines. */
void CloneMCJ_ItemPickaxe_Register(void);
const char *CloneMCJ_ItemPickaxe_JavaName(void);
const char *CloneMCJ_ItemPickaxe_AssignedFolder(void);
unsigned long CloneMCJ_ItemPickaxe_JavaSourceHash32(void);

/* ItemPiston.java: class, 24 Java lines. */
void CloneMCJ_ItemPiston_Register(void);
const char *CloneMCJ_ItemPiston_JavaName(void);
const char *CloneMCJ_ItemPiston_AssignedFolder(void);
unsigned long CloneMCJ_ItemPiston_JavaSourceHash32(void);

/* ItemRecord.java: class, 44 Java lines. */
void CloneMCJ_ItemRecord_Register(void);
const char *CloneMCJ_ItemRecord_JavaName(void);
const char *CloneMCJ_ItemRecord_AssignedFolder(void);
unsigned long CloneMCJ_ItemRecord_JavaSourceHash32(void);

/* ItemRedstone.java: class, 61 Java lines. */
void CloneMCJ_ItemRedstone_Register(void);
const char *CloneMCJ_ItemRedstone_JavaName(void);
const char *CloneMCJ_ItemRedstone_AssignedFolder(void);
unsigned long CloneMCJ_ItemRedstone_JavaSourceHash32(void);
int CloneMCJ_ItemRedstone_UseNative(struct CloneMCJ_WorldTag *, struct CloneMCJ_ItemStackTag *, struct CloneMCJ_EntityPlayerTag *, int, int, int, int);

/* ItemReed.java: class, 73 Java lines. */
void CloneMCJ_ItemReed_Register(void);
const char *CloneMCJ_ItemReed_JavaName(void);
const char *CloneMCJ_ItemReed_AssignedFolder(void);
unsigned long CloneMCJ_ItemReed_JavaSourceHash32(void);

/* ItemSaddle.java: class, 39 Java lines. */
void CloneMCJ_ItemSaddle_Register(void);
const char *CloneMCJ_ItemSaddle_JavaName(void);
const char *CloneMCJ_ItemSaddle_AssignedFolder(void);
unsigned long CloneMCJ_ItemSaddle_JavaSourceHash32(void);

/* ItemSapling.java: class, 31 Java lines. */
void CloneMCJ_ItemSapling_Register(void);
const char *CloneMCJ_ItemSapling_JavaName(void);
const char *CloneMCJ_ItemSapling_AssignedFolder(void);
unsigned long CloneMCJ_ItemSapling_JavaSourceHash32(void);

/* ItemSeeds.java: class, 41 Java lines. */
void CloneMCJ_ItemSeeds_Register(void);
int CloneMCJ_ItemSeeds_UseNative(struct CloneMCJ_WorldTag *, struct CloneMCJ_ItemStackTag *, int, int, int, int);
const char *CloneMCJ_ItemSeeds_JavaName(void);
const char *CloneMCJ_ItemSeeds_AssignedFolder(void);
unsigned long CloneMCJ_ItemSeeds_JavaSourceHash32(void);

/* ItemShears.java: class, 51 Java lines. */
void CloneMCJ_ItemShears_Register(void);
const char *CloneMCJ_ItemShears_JavaName(void);
const char *CloneMCJ_ItemShears_AssignedFolder(void);
unsigned long CloneMCJ_ItemShears_JavaSourceHash32(void);

/* ItemSign.java: class, 71 Java lines. */
void CloneMCJ_ItemSign_Register(void);
const char *CloneMCJ_ItemSign_JavaName(void);
const char *CloneMCJ_ItemSign_AssignedFolder(void);
unsigned long CloneMCJ_ItemSign_JavaSourceHash32(void);

/* ItemSlab.java: class, 36 Java lines. */
void CloneMCJ_ItemSlab_Register(void);
const char *CloneMCJ_ItemSlab_JavaName(void);
const char *CloneMCJ_ItemSlab_AssignedFolder(void);
unsigned long CloneMCJ_ItemSlab_JavaSourceHash32(void);

/* ItemSnowball.java: class, 33 Java lines. */
void CloneMCJ_ItemSnowball_Register(void);
const char *CloneMCJ_ItemSnowball_JavaName(void);
const char *CloneMCJ_ItemSnowball_AssignedFolder(void);
unsigned long CloneMCJ_ItemSnowball_JavaSourceHash32(void);

/* ItemSoup.java: class, 26 Java lines. */
void CloneMCJ_ItemSoup_Register(void);
const char *CloneMCJ_ItemSoup_JavaName(void);
const char *CloneMCJ_ItemSoup_AssignedFolder(void);
unsigned long CloneMCJ_ItemSoup_JavaSourceHash32(void);

/* ItemSpade.java: class, 37 Java lines. */
void CloneMCJ_ItemSpade_Register(void);
const char *CloneMCJ_ItemSpade_JavaName(void);
const char *CloneMCJ_ItemSpade_AssignedFolder(void);
unsigned long CloneMCJ_ItemSpade_JavaSourceHash32(void);

/* ItemStack.java: class, 292 Java lines. */
void CloneMCJ_ItemStack_Register(void);
const char *CloneMCJ_ItemStack_JavaName(void);
const char *CloneMCJ_ItemStack_AssignedFolder(void);
unsigned long CloneMCJ_ItemStack_JavaSourceHash32(void);

/* ItemSword.java: class, 57 Java lines. */
void CloneMCJ_ItemSword_Register(void);
const char *CloneMCJ_ItemSword_JavaName(void);
const char *CloneMCJ_ItemSword_AssignedFolder(void);
unsigned long CloneMCJ_ItemSword_JavaSourceHash32(void);

/* ItemTool.java: class, 67 Java lines. */
void CloneMCJ_ItemTool_Register(void);
const char *CloneMCJ_ItemTool_JavaName(void);
const char *CloneMCJ_ItemTool_AssignedFolder(void);
unsigned long CloneMCJ_ItemTool_JavaSourceHash32(void);

/* MapColor.java: class, 37 Java lines. */
void CloneMCJ_MapColor_Register(void);
const char *CloneMCJ_MapColor_JavaName(void);
const char *CloneMCJ_MapColor_AssignedFolder(void);
unsigned long CloneMCJ_MapColor_JavaSourceHash32(void);
unsigned long CloneMCJ_MapColor_GetValue(int);

/* MapCoord.java: class, 30 Java lines. */
void CloneMCJ_MapCoord_Register(void);
const char *CloneMCJ_MapCoord_JavaName(void);
const char *CloneMCJ_MapCoord_AssignedFolder(void);
unsigned long CloneMCJ_MapCoord_JavaSourceHash32(void);

/* MapData.java: class, 181 Java lines. */
void CloneMCJ_MapData_Register(void);
const char *CloneMCJ_MapData_JavaName(void);
const char *CloneMCJ_MapData_AssignedFolder(void);
unsigned long CloneMCJ_MapData_JavaSourceHash32(void);


#ifndef CLONEMC_J_NBT_TAG_COMPOUND_TYPEDEF
#define CLONEMC_J_NBT_TAG_COMPOUND_TYPEDEF
typedef struct CloneMCJ_NBTBaseTag CloneMCJ_NBTTagCompound;
#endif
#ifndef CLONEMC_J_MAP_DATA_BASE_TYPEDEF
#define CLONEMC_J_MAP_DATA_BASE_TYPEDEF
typedef struct CloneMCJ_MapDataBaseTag CloneMCJ_MapDataBase;
#endif
struct CloneMCJ_MapDataBaseTag {
    char name[256];
    unsigned char dirty;
    void (*readFromNBT)(struct CloneMCJ_MapDataBaseTag *, const CloneMCJ_NBTTagCompound *);
    void (*writeToNBT)(const struct CloneMCJ_MapDataBaseTag *, CloneMCJ_NBTTagCompound *);
    void (*destroy)(struct CloneMCJ_MapDataBaseTag *);
};
void CloneMCJ_MapDataBase_Initialize(CloneMCJ_MapDataBase *data, const char *name,
    void (*readFromNBT)(CloneMCJ_MapDataBase *, const CloneMCJ_NBTTagCompound *),
    void (*writeToNBT)(const CloneMCJ_MapDataBase *, CloneMCJ_NBTTagCompound *),
    void (*destroy)(CloneMCJ_MapDataBase *));
void CloneMCJ_MapDataBase_MarkDirty(CloneMCJ_MapDataBase *data);
void CloneMCJ_MapDataBase_SetDirty(CloneMCJ_MapDataBase *data, int dirty);
int CloneMCJ_MapDataBase_IsDirty(const CloneMCJ_MapDataBase *data);

#define CLONEMC_J_MAP_SIZE 128
#define CLONEMC_J_MAP_PIXELS 16384
#define CLONEMC_J_MAP_MAX_TRACKED_PLAYERS 16
#define CLONEMC_J_MAP_MAX_DECORATIONS 32

typedef struct CloneMCJ_MapCoordTag {
    CloneMCJByte type;
    CloneMCJByte x;
    CloneMCJByte z;
    CloneMCJByte rotation;
} CloneMCJ_MapCoord;

typedef struct CloneMCJ_MapInfoTag {
    struct CloneMCJ_EntityPlayerTag *player;
    int minDirty[CLONEMC_J_MAP_SIZE];
    int maxDirty[CLONEMC_J_MAP_SIZE];
    int packetColumn;
    int iconTick;
} CloneMCJ_MapInfo;

typedef struct CloneMCJ_MapDataTag {
    CloneMCJ_MapDataBase base;
    int xCenter;
    int zCenter;
    CloneMCJByte dimension;
    CloneMCJByte scale;
    unsigned char colors[CLONEMC_J_MAP_PIXELS];
    int updateCounter;
    CloneMCJ_MapInfo observers[CLONEMC_J_MAP_MAX_TRACKED_PLAYERS];
    int observerCount;
    CloneMCJ_MapCoord decorations[CLONEMC_J_MAP_MAX_DECORATIONS];
    int decorationCount;
} CloneMCJ_MapData;

struct CloneMCJ_MapStorageTag;
void CloneMCJ_MapCoord_Initialize(CloneMCJ_MapCoord *, CloneMCJByte,
    CloneMCJByte, CloneMCJByte, CloneMCJByte);
void CloneMCJ_MapInfo_Initialize(CloneMCJ_MapInfo *,
    struct CloneMCJ_EntityPlayerTag *);
CloneMCJ_MapData *CloneMCJ_MapData_Create(const char *);
CloneMCJ_MapDataBase *CloneMCJ_MapData_Factory(const char *, void *);
void CloneMCJ_MapData_UpdatePlayer(CloneMCJ_MapData *,
    struct CloneMCJ_EntityPlayerTag *,
    const struct CloneMCJ_ItemStackTag *);
void CloneMCJ_MapData_MarkDirtyColumn(CloneMCJ_MapData *, int, int, int);
int CloneMCJ_MapData_ApplyPacket(CloneMCJ_MapData *,
    const unsigned char *, int);
CloneMCJ_MapData *CloneMCJ_ItemMap_GetOrCreate(
    struct CloneMCJ_MapStorageTag *, struct CloneMCJ_ItemStackTag *,
    struct CloneMCJ_WorldTag *, int);
CloneMCJ_MapData *CloneMCJ_ItemMap_GetById(
    struct CloneMCJ_MapStorageTag *, int, int);
void CloneMCJ_ItemMap_UpdateTerrain(CloneMCJ_MapData *,
    struct CloneMCJ_WorldTag *, const struct CloneMCJ_EntityPlayerTag *);
void CloneMCJ_ItemMap_TickInventory(struct CloneMCJ_MapStorageTag *,
    struct CloneMCJ_WorldTag *, struct CloneMCJ_EntityPlayerTag *);
int CloneMCJ_MapPipeline_RunSelfTests(char *, unsigned int);

/* MapDataBase.java: class, 41 Java lines. */
void CloneMCJ_MapDataBase_Register(void);
const char *CloneMCJ_MapDataBase_JavaName(void);
const char *CloneMCJ_MapDataBase_AssignedFolder(void);
unsigned long CloneMCJ_MapDataBase_JavaSourceHash32(void);

/* MapInfo.java: class, 38 Java lines. */
void CloneMCJ_MapInfo_Register(void);
const char *CloneMCJ_MapInfo_JavaName(void);
const char *CloneMCJ_MapInfo_AssignedFolder(void);
unsigned long CloneMCJ_MapInfo_JavaSourceHash32(void);

/* Material.java: class, 175 Java lines. */
void CloneMCJ_Material_Register(void);
const char *CloneMCJ_Material_JavaName(void);
const char *CloneMCJ_Material_AssignedFolder(void);
unsigned long CloneMCJ_Material_JavaSourceHash32(void);

/* MaterialLiquid.java: class, 36 Java lines. */
void CloneMCJ_MaterialLiquid_Register(void);
const char *CloneMCJ_MaterialLiquid_JavaName(void);
const char *CloneMCJ_MaterialLiquid_AssignedFolder(void);
unsigned long CloneMCJ_MaterialLiquid_JavaSourceHash32(void);

/* MaterialLogic.java: class, 34 Java lines. */
void CloneMCJ_MaterialLogic_Register(void);
const char *CloneMCJ_MaterialLogic_JavaName(void);
const char *CloneMCJ_MaterialLogic_AssignedFolder(void);
unsigned long CloneMCJ_MaterialLogic_JavaSourceHash32(void);

/* MaterialPortal.java: class, 34 Java lines. */
void CloneMCJ_MaterialPortal_Register(void);
const char *CloneMCJ_MaterialPortal_JavaName(void);
const char *CloneMCJ_MaterialPortal_AssignedFolder(void);
unsigned long CloneMCJ_MaterialPortal_JavaSourceHash32(void);

/* MaterialTransparent.java: class, 35 Java lines. */
void CloneMCJ_MaterialTransparent_Register(void);
const char *CloneMCJ_MaterialTransparent_JavaName(void);
const char *CloneMCJ_MaterialTransparent_AssignedFolder(void);
unsigned long CloneMCJ_MaterialTransparent_JavaSourceHash32(void);

/* RailLogic.java: class, 441 Java lines. */
void CloneMCJ_RailLogic_Register(void);
const char *CloneMCJ_RailLogic_JavaName(void);
const char *CloneMCJ_RailLogic_AssignedFolder(void);
unsigned long CloneMCJ_RailLogic_JavaSourceHash32(void);

/* RecipesArmor.java: class, 61 Java lines. */
void CloneMCJ_RecipesArmor_Register(void);
const char *CloneMCJ_RecipesArmor_JavaName(void);
const char *CloneMCJ_RecipesArmor_AssignedFolder(void);
unsigned long CloneMCJ_RecipesArmor_JavaSourceHash32(void);

/* RecipesCrafting.java: class, 34 Java lines. */
void CloneMCJ_RecipesCrafting_Register(void);
const char *CloneMCJ_RecipesCrafting_JavaName(void);
const char *CloneMCJ_RecipesCrafting_AssignedFolder(void);
unsigned long CloneMCJ_RecipesCrafting_JavaSourceHash32(void);

/* RecipesDyes.java: class, 75 Java lines. */
void CloneMCJ_RecipesDyes_Register(void);
const char *CloneMCJ_RecipesDyes_JavaName(void);
const char *CloneMCJ_RecipesDyes_AssignedFolder(void);
unsigned long CloneMCJ_RecipesDyes_JavaSourceHash32(void);

/* RecipesFood.java: class, 31 Java lines. */
void CloneMCJ_RecipesFood_Register(void);
const char *CloneMCJ_RecipesFood_JavaName(void);
const char *CloneMCJ_RecipesFood_AssignedFolder(void);
unsigned long CloneMCJ_RecipesFood_JavaSourceHash32(void);

/* RecipesIngots.java: class, 47 Java lines. */
void CloneMCJ_RecipesIngots_Register(void);
const char *CloneMCJ_RecipesIngots_JavaName(void);
const char *CloneMCJ_RecipesIngots_AssignedFolder(void);
unsigned long CloneMCJ_RecipesIngots_JavaSourceHash32(void);

/* RecipeSorter.java: class, 46 Java lines. */
void CloneMCJ_RecipeSorter_Register(void);
const char *CloneMCJ_RecipeSorter_JavaName(void);
const char *CloneMCJ_RecipeSorter_AssignedFolder(void);
unsigned long CloneMCJ_RecipeSorter_JavaSourceHash32(void);

/* RecipesTools.java: class, 64 Java lines. */
void CloneMCJ_RecipesTools_Register(void);
const char *CloneMCJ_RecipesTools_JavaName(void);
const char *CloneMCJ_RecipesTools_AssignedFolder(void);
unsigned long CloneMCJ_RecipesTools_JavaSourceHash32(void);

/* RecipesWeapons.java: class, 55 Java lines. */
void CloneMCJ_RecipesWeapons_Register(void);
const char *CloneMCJ_RecipesWeapons_JavaName(void);
const char *CloneMCJ_RecipesWeapons_AssignedFolder(void);
unsigned long CloneMCJ_RecipesWeapons_JavaSourceHash32(void);

/* RedstoneUpdateInfo.java: class, 24 Java lines. */
void CloneMCJ_RedstoneUpdateInfo_Register(void);
const char *CloneMCJ_RedstoneUpdateInfo_JavaName(void);
const char *CloneMCJ_RedstoneUpdateInfo_AssignedFolder(void);
unsigned long CloneMCJ_RedstoneUpdateInfo_JavaSourceHash32(void);

/* ShapedRecipes.java: class, 109 Java lines. */
void CloneMCJ_ShapedRecipes_Register(void);
const char *CloneMCJ_ShapedRecipes_JavaName(void);
const char *CloneMCJ_ShapedRecipes_AssignedFolder(void);
unsigned long CloneMCJ_ShapedRecipes_JavaSourceHash32(void);

/* ShapelessRecipes.java: class, 85 Java lines. */
void CloneMCJ_ShapelessRecipes_Register(void);
const char *CloneMCJ_ShapelessRecipes_JavaName(void);
const char *CloneMCJ_ShapelessRecipes_AssignedFolder(void);
unsigned long CloneMCJ_ShapelessRecipes_JavaSourceHash32(void);

/* Slot.java: class, 74 Java lines. */
void CloneMCJ_Slot_Register(void);
const char *CloneMCJ_Slot_JavaName(void);
const char *CloneMCJ_Slot_AssignedFolder(void);
unsigned long CloneMCJ_Slot_JavaSourceHash32(void);

/* SlotArmor.java: class, 45 Java lines. */
void CloneMCJ_SlotArmor_Register(void);
const char *CloneMCJ_SlotArmor_JavaName(void);
const char *CloneMCJ_SlotArmor_AssignedFolder(void);
unsigned long CloneMCJ_SlotArmor_JavaSourceHash32(void);

/* SlotCrafting.java: class, 81 Java lines. */
void CloneMCJ_SlotCrafting_Register(void);
const char *CloneMCJ_SlotCrafting_JavaName(void);
const char *CloneMCJ_SlotCrafting_AssignedFolder(void);
unsigned long CloneMCJ_SlotCrafting_JavaSourceHash32(void);

/* SlotFurnace.java: class, 42 Java lines. */
void CloneMCJ_SlotFurnace_Register(void);
const char *CloneMCJ_SlotFurnace_JavaName(void);
const char *CloneMCJ_SlotFurnace_AssignedFolder(void);
unsigned long CloneMCJ_SlotFurnace_JavaSourceHash32(void);

/* StepSound.java: class, 42 Java lines. */
void CloneMCJ_StepSound_Register(void);
const char *CloneMCJ_StepSound_JavaName(void);
const char *CloneMCJ_StepSound_AssignedFolder(void);
unsigned long CloneMCJ_StepSound_JavaSourceHash32(void);

/* StepSoundSand.java: class, 24 Java lines. */
void CloneMCJ_StepSoundSand_Register(void);
const char *CloneMCJ_StepSoundSand_JavaName(void);
const char *CloneMCJ_StepSoundSand_AssignedFolder(void);
unsigned long CloneMCJ_StepSoundSand_JavaSourceHash32(void);

/* StepSoundStone.java: class, 24 Java lines. */
void CloneMCJ_StepSoundStone_Register(void);
const char *CloneMCJ_StepSoundStone_JavaName(void);
const char *CloneMCJ_StepSoundStone_AssignedFolder(void);
unsigned long CloneMCJ_StepSoundStone_JavaSourceHash32(void);

/* TileEntity.java: class, 161 Java lines. */
void CloneMCJ_TileEntity_Register(void);
const char *CloneMCJ_TileEntity_JavaName(void);
const char *CloneMCJ_TileEntity_AssignedFolder(void);
unsigned long CloneMCJ_TileEntity_JavaSourceHash32(void);

/* TileEntityChest.java: class, 121 Java lines. */
void CloneMCJ_TileEntityChest_Register(void);
const char *CloneMCJ_TileEntityChest_JavaName(void);
const char *CloneMCJ_TileEntityChest_AssignedFolder(void);
unsigned long CloneMCJ_TileEntityChest_JavaSourceHash32(void);

/* TileEntityDispenser.java: class, 145 Java lines. */
void CloneMCJ_TileEntityDispenser_Register(void);
const char *CloneMCJ_TileEntityDispenser_JavaName(void);
const char *CloneMCJ_TileEntityDispenser_AssignedFolder(void);
unsigned long CloneMCJ_TileEntityDispenser_JavaSourceHash32(void);

/* TileEntityFurnace.java: class, 274 Java lines. */
void CloneMCJ_TileEntityFurnace_Register(void);
const char *CloneMCJ_TileEntityFurnace_JavaName(void);
const char *CloneMCJ_TileEntityFurnace_AssignedFolder(void);
unsigned long CloneMCJ_TileEntityFurnace_JavaSourceHash32(void);

/* TileEntityMobSpawner.java: class, 137 Java lines. */
void CloneMCJ_TileEntityMobSpawner_Register(void);
const char *CloneMCJ_TileEntityMobSpawner_JavaName(void);
const char *CloneMCJ_TileEntityMobSpawner_AssignedFolder(void);
unsigned long CloneMCJ_TileEntityMobSpawner_JavaSourceHash32(void);

/* TileEntityNote.java: class, 76 Java lines. */
void CloneMCJ_TileEntityNote_Register(void);
const char *CloneMCJ_TileEntityNote_JavaName(void);
const char *CloneMCJ_TileEntityNote_AssignedFolder(void);
unsigned long CloneMCJ_TileEntityNote_JavaSourceHash32(void);

/* TileEntityPiston.java: class, 192 Java lines. */
void CloneMCJ_TileEntityPiston_Register(void);
struct CloneMCJ_TileEntityTag *CloneMCJ_TileEntityPiston_Create(struct CloneMCJ_WorldTag *,int,int,int,int,int,int,int,int);
float CloneMCJ_TileEntityPiston_GetProgress(const struct CloneMCJ_TileEntityTag *,float);
float CloneMCJ_TileEntityPiston_OffsetX(const struct CloneMCJ_TileEntityTag *,float);
float CloneMCJ_TileEntityPiston_OffsetY(const struct CloneMCJ_TileEntityTag *,float);
float CloneMCJ_TileEntityPiston_OffsetZ(const struct CloneMCJ_TileEntityTag *,float);
const char *CloneMCJ_TileEntityPiston_JavaName(void);
const char *CloneMCJ_TileEntityPiston_AssignedFolder(void);
unsigned long CloneMCJ_TileEntityPiston_JavaSourceHash32(void);

/* TileEntityRecordPlayer.java: class, 35 Java lines. */
void CloneMCJ_TileEntityRecordPlayer_Register(void);
const char *CloneMCJ_TileEntityRecordPlayer_JavaName(void);
const char *CloneMCJ_TileEntityRecordPlayer_AssignedFolder(void);
unsigned long CloneMCJ_TileEntityRecordPlayer_JavaSourceHash32(void);

/* TileEntitySign.java: class, 50 Java lines. */
void CloneMCJ_TileEntitySign_Register(void);
const char *CloneMCJ_TileEntitySign_JavaName(void);
const char *CloneMCJ_TileEntitySign_AssignedFolder(void);
unsigned long CloneMCJ_TileEntitySign_JavaSourceHash32(void);

/* Priority 7: direct ItemStack/Inventory/Block/TileEntity gameplay kernel. */
#define CLONEMC_J_ITEM_REGISTRY_SIZE 2304
#define CLONEMC_J_BLOCK_REGISTRY_SIZE 256
#define CLONEMC_J_MAIN_INVENTORY_SIZE 36
#define CLONEMC_J_ARMOR_INVENTORY_SIZE 4
#define CLONEMC_J_CHEST_INVENTORY_SIZE 27
#define CLONEMC_J_FURNACE_INVENTORY_SIZE 3

typedef enum CloneMCJ_MaterialKindTag {
    CLONEMC_J_MATERIAL_AIR = 0,
    CLONEMC_J_MATERIAL_ROCK,
    CLONEMC_J_MATERIAL_EARTH,
    CLONEMC_J_MATERIAL_WOOD,
    CLONEMC_J_MATERIAL_PLANT,
    CLONEMC_J_MATERIAL_WATER,
    CLONEMC_J_MATERIAL_LAVA,
    CLONEMC_J_MATERIAL_GLASS,
    CLONEMC_J_MATERIAL_CIRCUITS,
    CLONEMC_J_MATERIAL_CLOTH,
    CLONEMC_J_MATERIAL_ICE,
    CLONEMC_J_MATERIAL_SAND,
    CLONEMC_J_MATERIAL_METAL
} CloneMCJ_MaterialKind;

typedef enum CloneMCJ_ToolClassTag {
    CLONEMC_J_TOOL_NONE = 0,
    CLONEMC_J_TOOL_PICKAXE,
    CLONEMC_J_TOOL_AXE,
    CLONEMC_J_TOOL_SHOVEL,
    CLONEMC_J_TOOL_SWORD,
    CLONEMC_J_TOOL_HOE,
    CLONEMC_J_TOOL_SHEARS
} CloneMCJ_ToolClass;

#define CLONEMC_J_MAX_ITEM_ENCHANTMENTS 32

typedef struct CloneMCJ_ItemStackTag {
    int itemID;
    int stackSize;
    int itemDamage;
    int animationsToGo;
    unsigned char enchantmentCount;
    unsigned char enchantmentId[CLONEMC_J_MAX_ITEM_ENCHANTMENTS];
    unsigned char enchantmentLevel[CLONEMC_J_MAX_ITEM_ENCHANTMENTS];
} CloneMCJ_ItemStack;

struct CloneMCJ_WorldTag;
struct CloneMCJ_EntityPlayerTag;
struct CloneMCJ_InventoryPlayerTag;
struct CloneMCJ_TileEntityTag;
struct CloneMCJ_MobTag;
struct CloneMCJ_BlockDefinitionTag;

typedef void (*CloneMCJ_BlockNeighborProc)(struct CloneMCJ_WorldTag *, int, int, int, int);
typedef void (*CloneMCJ_BlockLifecycleProc)(struct CloneMCJ_WorldTag *, int, int, int);
typedef int (*CloneMCJ_BlockActivateProc)(struct CloneMCJ_WorldTag *, int, int, int,
    struct CloneMCJ_EntityPlayerTag *);

typedef struct CloneMCJ_BlockDefinitionTag {
    int blockID;
    const char *name;
    CloneMCJ_MaterialKind material;
    float hardness;
    float resistance;
    float slipperiness;
    unsigned char lightOpacity;
    unsigned char lightEmission;
    unsigned char solid, opaque, collidable, replaceable;
    unsigned char tickRandomly, hasTileEntity, registered;
    unsigned char requiredTool, requiredHarvestLevel;
    int droppedItemID;
    int droppedCount;
    double minX, minY, minZ, maxX, maxY, maxZ;
    CloneMCJ_BlockNeighborProc neighborChanged;
    CloneMCJ_BlockLifecycleProc onBlockAdded;
    CloneMCJ_BlockLifecycleProc onBlockRemoved;
    CloneMCJ_BlockActivateProc activate;
} CloneMCJ_BlockDefinition;

typedef struct CloneMCJ_ItemDefinitionTag {
    int itemID;
    const char *name;
    int maxStackSize;
    int maxDamage;
    int damageVsEntity;
    int iconIndex;
    float efficiency;
    unsigned char hasSubtypes;
    unsigned char registered;
    unsigned char toolClass;
    unsigned char harvestLevel;
    unsigned char wolfsFavoriteMeat;
    int healAmount;
    int placeBlockID;
} CloneMCJ_ItemDefinition;

typedef struct CloneMCJ_InventoryPlayerTag {
    CloneMCJ_ItemStack mainInventory[CLONEMC_J_MAIN_INVENTORY_SIZE];
    CloneMCJ_ItemStack armorInventory[CLONEMC_J_ARMOR_INVENTORY_SIZE];
    CloneMCJ_ItemStack carriedStack;
    int currentItem;
    unsigned char inventoryChanged;
} CloneMCJ_InventoryPlayer;

typedef enum CloneMCJ_TileEntityTypeTag {
    CLONEMC_J_TILE_NONE = 0,
    CLONEMC_J_TILE_CHEST,
    CLONEMC_J_TILE_FURNACE,
    CLONEMC_J_TILE_DISPENSER,
    CLONEMC_J_TILE_SIGN,
    CLONEMC_J_TILE_MOB_SPAWNER,
    CLONEMC_J_TILE_PISTON,
    CLONEMC_J_TILE_BREWING_STAND,
    CLONEMC_J_TILE_ENCHANTMENT_TABLE
} CloneMCJ_TileEntityType;

typedef struct CloneMCJ_TileEntityTag {
    CloneMCJ_TileEntityType type;
    struct CloneMCJ_WorldTag *worldObj;
    int xCoord, yCoord, zCoord;
    unsigned char invalid;
    CloneMCJ_ItemStack items[CLONEMC_J_CHEST_INVENTORY_SIZE];
    int itemCount;
    int furnaceBurnTime, currentItemBurnTime, furnaceCookTime;
    int brewingTime, brewingIngredientId;
    int enchantTickCount;
    float enchantPageFlip, enchantPageFlipPrev;
    float enchantPageTarget, enchantPageVelocity;
    float enchantBookSpread, enchantBookSpreadPrev;
    float enchantBookRotation, enchantBookRotationPrev;
    float enchantBookRotationTarget;
    char signText[4][64];
    int signLineBeingEdited;
    char mobID[32];
    int spawnDelay;
    double spawnerYaw, previousSpawnerYaw;
    int numUsingPlayers;
    float lidAngle, previousLidAngle;
    int pistonStoredBlockID, pistonStoredMetadata, pistonFacing;
    unsigned char pistonExtending, pistonRenderHead;
    float pistonProgress, pistonPreviousProgress;
    /* TileEntityDispenser owns its selection RNG in Java.  Keeping it on the
     * tile preserves reservoir-sampling call order without consuming the
     * world's terrain/entity random stream. */
    CloneMCJavaRandom dispenserRandom;
} CloneMCJ_TileEntity;

/* Priority 13: bounded Beta-style crafting and container runtime. */
#define CLONEMC_J_MAX_RECIPE_CELLS 9
#define CLONEMC_J_MAX_RECIPES 192
#define CLONEMC_J_MAX_CONTAINER_SLOTS 96
#define CLONEMC_J_MAX_PENDING_TRANSACTIONS 16
#define CLONEMC_J_ITEM_DAMAGE_WILDCARD (-1)

typedef struct CloneMCJ_RecipeIngredientTag {
    short itemID;
    short itemDamage;
} CloneMCJ_RecipeIngredient;

typedef struct CloneMCJ_RecipeTag {
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    unsigned char shaped;
    unsigned char width;
    unsigned char height;
    unsigned char ingredientCount;
} CloneMCJ_Recipe;

typedef struct CloneMCJ_CraftingManagerNativeTag {
    CloneMCJ_Recipe recipes[CLONEMC_J_MAX_RECIPES];
    int recipeCount;
    unsigned char initialized;
} CloneMCJ_CraftingManagerNative;

typedef struct CloneMCJ_InventoryCraftingTag {
    CloneMCJ_ItemStack stackList[CLONEMC_J_MAX_RECIPE_CELLS];
    int width;
    int height;
    unsigned long changeSerial;
} CloneMCJ_InventoryCrafting;

typedef struct CloneMCJ_InventoryCraftResultTag {
    CloneMCJ_ItemStack result;
    unsigned long changeSerial;
} CloneMCJ_InventoryCraftResult;

typedef enum CloneMCJ_SlotKindTag {
    CLONEMC_J_SLOT_NORMAL = 0,
    CLONEMC_J_SLOT_CRAFT_RESULT,
    CLONEMC_J_SLOT_ARMOR,
    CLONEMC_J_SLOT_FURNACE_INPUT,
    CLONEMC_J_SLOT_FURNACE_FUEL,
    CLONEMC_J_SLOT_FURNACE_OUTPUT,
    CLONEMC_J_SLOT_ENCHANT_INPUT,
    CLONEMC_J_SLOT_BREWING_BOTTLE,
    CLONEMC_J_SLOT_BREWING_INGREDIENT,
    CLONEMC_J_SLOT_MERCHANT_OUTPUT
} CloneMCJ_SlotKind;

typedef enum CloneMCJ_ContainerTypeTag {
    CLONEMC_J_CONTAINER_GENERIC = 0,
    CLONEMC_J_CONTAINER_PLAYER,
    CLONEMC_J_CONTAINER_WORKBENCH,
    CLONEMC_J_CONTAINER_CHEST,
    CLONEMC_J_CONTAINER_FURNACE,
    CLONEMC_J_CONTAINER_DISPENSER,
    CLONEMC_J_CONTAINER_ENCHANTMENT,
    CLONEMC_J_CONTAINER_BREWING,
    CLONEMC_J_CONTAINER_MERCHANT
} CloneMCJ_ContainerType;

typedef struct CloneMCJ_ContainerTransactionTag {
    CloneMCJ_ItemStack slotSnapshot[CLONEMC_J_MAX_CONTAINER_SLOTS];
    CloneMCJ_ItemStack carriedSnapshot;
    short transactionId;
    unsigned char active;
} CloneMCJ_ContainerTransaction;

typedef struct CloneMCJ_ContainerTag {
    /* The first fields intentionally preserve the predecessor public layout. */
    CloneMCJ_ItemStack *slots[CLONEMC_J_MAX_CONTAINER_SLOTS];
    unsigned char slotLimit[CLONEMC_J_MAX_CONTAINER_SLOTS];
    unsigned char slotCount;
    int windowId;
    short transactionId;

    unsigned char type;
    unsigned char slotKind[CLONEMC_J_MAX_CONTAINER_SLOTS];
    signed char slotArmorType[CLONEMC_J_MAX_CONTAINER_SLOTS];
    short slotX[CLONEMC_J_MAX_CONTAINER_SLOTS];
    short slotY[CLONEMC_J_MAX_CONTAINER_SLOTS];
    short slotInventoryIndex[CLONEMC_J_MAX_CONTAINER_SLOTS];

    CloneMCJ_InventoryPlayer *playerInventory;
    CloneMCJ_TileEntity *tileEntity;
    CloneMCJ_TileEntity *secondTileEntity;
    CloneMCJ_InventoryCrafting *craftMatrix;
    CloneMCJ_InventoryCraftResult *craftResult;

    int resultSlot;
    int tileSlotStart;
    int tileSlotEnd;
    int playerSlotStart;
    int playerSlotEnd;
    int hotbarSlotStart;
    int hotbarSlotEnd;
    int workbenchX;
    int workbenchY;
    int workbenchZ;
    unsigned long mutationSerial;
    unsigned long craftedSerial, smeltedSerial;
    int lastCraftedItemID, lastCraftedCount;
    int lastSmeltedItemID, lastSmeltedCount;
    CloneMCJ_ItemStack lastDroppedStack;

    CloneMCJ_ContainerTransaction pending[CLONEMC_J_MAX_PENDING_TRANSACTIONS];
} CloneMCJ_Container;

void CloneMCJ_BlockRegistry_Initialize(void);
const CloneMCJ_BlockDefinition *CloneMCJ_BlockRegistry_Get(int);
CloneMCJ_BlockDefinition *CloneMCJ_BlockRegistry_GetMutable(int);
int CloneMCJ_Block_GetCollisionBoxes(struct CloneMCJ_WorldTag *, int, int, int,
    CloneMCAxisAlignedBB *, int);
int CloneMCJ_Block_GetSelectionBox(struct CloneMCJ_WorldTag *, int, int, int,
    CloneMCAxisAlignedBB *);
int CloneMCJ_Block_CanPlaceAt(struct CloneMCJ_WorldTag *, int, int, int, int,
    const CloneMCAxisAlignedBB *);
int CloneMCJ_Block_GetDroppedStack(int, int, CloneMCJavaRandom *, CloneMCJ_ItemStack *);
int CloneMCJ_Block_GetAdditionalDroppedStack(int, int, CloneMCJavaRandom *,
    CloneMCJ_ItemStack *);
int CloneMCJ_Block_Activate(struct CloneMCJ_WorldTag *, int, int, int,
    struct CloneMCJ_EntityPlayerTag *);
int CloneMCJ_BlockDoor_ActivateNative(struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_BlockDoor_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockTrapDoor_ActivateNative(struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_BlockTrapDoor_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockLever_ActivateNative(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockLever_CanPlaceOnSideNative(struct CloneMCJ_WorldTag *, int, int, int, int);
int CloneMCJ_BlockLever_CanPlaceAtNative(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockLever_OnPlacedNative(struct CloneMCJ_WorldTag *, int, int, int, int);
void CloneMCJ_BlockLever_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockButton_CanPlaceOnSideNative(struct CloneMCJ_WorldTag *, int, int, int, int);
int CloneMCJ_BlockButton_CanPlaceAtNative(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockButton_ActivateNative(struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_BlockButton_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockSimulation_RegisterWorld(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockFluid_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockSponge_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockSponge_AbsorbNative(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockSponge_IsWaterProtectedNative(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockFluid_GetFlowDecay(struct CloneMCJ_WorldTag *, int, int, int, int);
int CloneMCJ_BlockFluid_GetEffectiveFlowDecay(struct CloneMCJ_WorldTag *, int, int, int, int);
int CloneMCJ_BlockFluid_TickRate(int);
int CloneMCJ_BlockFluid_CheckForHarden(struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_BlockFlowing_UpdateTick(struct CloneMCJ_WorldTag *, int, int, int,
    int, CloneMCJavaRandom *, void *);
void CloneMCJ_BlockFire_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockCrops_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockSapling_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockLeaves_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockRedstoneWire_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockRedstoneWire_IsUpdatingNative(void);
int CloneMCJ_BlockRedstoneWire_IsPoweringToNative(struct CloneMCJ_WorldTag *, int, int, int, int);
int CloneMCJ_BlockRedstoneWire_IsPowerProviderOrWireNative(struct CloneMCJ_WorldTag *, int, int, int, int);
void CloneMCJ_BlockRedstoneTorch_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockFarmland_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockGrass_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockCactus_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockReed_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockIce_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockSnow_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockCrops_Fertilize(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockSapling_GrowTree(struct CloneMCJ_WorldTag *, int, int, int,
    CloneMCJavaRandom *);
int CloneMCJ_ItemDye_UseNative(struct CloneMCJ_WorldTag *, CloneMCJ_ItemStack *,
    int, int, int, int);

void CloneMCJ_ItemRegistry_Initialize(void);
const CloneMCJ_ItemDefinition *CloneMCJ_ItemRegistry_Get(int);
int CloneMCJ_ItemRegistry_IsRegistered(int);
int CloneMCJ_ItemRegistry_Validate(char *,unsigned int);
int CloneMCJ_ItemRegistry_GetIconIndex(int itemID,int damage);
int CloneMCJ_ItemRegistry_GetRenderPasses(int itemID);
int CloneMCJ_ItemRegistry_GetIconForPass(int itemID,int damage,int pass);
int CloneMCJ_ItemRegistry_GetColorForPass(int itemID,int damage,int pass);
int CloneMCJ_ItemRegistry_IsFull3D(int itemID);
int CloneMCJ_ItemRegistry_ShouldRotateAround(int itemID);
void CloneMCJ_ItemStack_Clear(CloneMCJ_ItemStack *);
void CloneMCJ_ItemStack_Initialize(CloneMCJ_ItemStack *, int, int, int);
int CloneMCJ_ItemStack_IsEmpty(const CloneMCJ_ItemStack *);
int CloneMCJ_ItemStack_GetMaxStackSize(const CloneMCJ_ItemStack *);
int CloneMCJ_ItemStack_IsStackableWith(const CloneMCJ_ItemStack *, const CloneMCJ_ItemStack *);
CloneMCJ_ItemStack CloneMCJ_ItemStack_Split(CloneMCJ_ItemStack *, int);
void CloneMCJ_ItemStack_Damage(CloneMCJ_ItemStack *, int);
int CloneMCJ_ItemStack_WriteNBT(const CloneMCJ_ItemStack *, CloneMCJ_NBTTagCompound *);
int CloneMCJ_ItemStack_ReadNBT(CloneMCJ_ItemStack *, const CloneMCJ_NBTTagCompound *);
const char *CloneMCJ_ItemStack_GetNameKey(const CloneMCJ_ItemStack *);
int CloneMCJ_ItemFood_Use(CloneMCJ_ItemStack *, struct CloneMCJ_EntityPlayerTag *);
int CloneMCJ_ItemSoup_Use(CloneMCJ_ItemStack *, struct CloneMCJ_EntityPlayerTag *);
int CloneMCJ_ItemSaddle_UseOnMob(CloneMCJ_ItemStack *, struct CloneMCJ_MobTag *);

void CloneMCJ_InventoryPlayer_Initialize(CloneMCJ_InventoryPlayer *);
CloneMCJ_ItemStack *CloneMCJ_InventoryPlayer_GetCurrent(CloneMCJ_InventoryPlayer *);
CloneMCJ_ItemStack CloneMCJ_InventoryPlayer_DecrStackSize(CloneMCJ_InventoryPlayer *, int, int);
int CloneMCJ_InventoryPlayer_AddItemStack(CloneMCJ_InventoryPlayer *, CloneMCJ_ItemStack *);
int CloneMCJ_InventoryPlayer_GetTotalArmorValue(const CloneMCJ_InventoryPlayer *);
void CloneMCJ_InventoryPlayer_DamageArmor(CloneMCJ_InventoryPlayer *, int);
int CloneMCJ_InventoryPlayer_ConsumeItem(CloneMCJ_InventoryPlayer *, int);
void CloneMCJ_InventoryPlayer_ChangeCurrentItem(CloneMCJ_InventoryPlayer *, int);
int CloneMCJ_InventoryPlayer_ClickSlot(CloneMCJ_InventoryPlayer *, int, int);
float CloneMCJ_InventoryPlayer_GetStrengthVsBlock(const CloneMCJ_InventoryPlayer *, int);
int CloneMCJ_InventoryPlayer_CanHarvest(const CloneMCJ_InventoryPlayer *, int);
float CloneMCJ_InventoryPlayer_GetStrengthVsBlockMetadata(
    const CloneMCJ_InventoryPlayer *, int, int);
int CloneMCJ_InventoryPlayer_CanHarvestMetadata(
    const CloneMCJ_InventoryPlayer *, int, int);
int CloneMCJ_InventoryPlayer_WriteNBT(const CloneMCJ_InventoryPlayer *, CloneMCJ_NBTTagCompound *);
int CloneMCJ_InventoryPlayer_ReadNBT(CloneMCJ_InventoryPlayer *, const CloneMCJ_NBTTagCompound *);

CloneMCJ_TileEntity *CloneMCJ_TileEntity_Create(CloneMCJ_TileEntityType, struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_TileEntity_Destroy(CloneMCJ_TileEntity *);
void CloneMCJ_TileEntity_Update(CloneMCJ_TileEntity *);
int CloneMCJ_TileEntity_WriteNBT(const CloneMCJ_TileEntity *, CloneMCJ_NBTTagCompound *);
CloneMCJ_TileEntity *CloneMCJ_TileEntity_ReadNBT(const CloneMCJ_NBTTagCompound *, struct CloneMCJ_WorldTag *);
int CloneMCJ_TileEntity_DecrStack(CloneMCJ_TileEntity *, int, int, CloneMCJ_ItemStack *);
int CloneMCJ_TileEntity_SetStack(CloneMCJ_TileEntity *, int, const CloneMCJ_ItemStack *);

void CloneMCJ_InventoryCrafting_Initialize(CloneMCJ_InventoryCrafting *, int, int);
int CloneMCJ_InventoryCrafting_GetSize(const CloneMCJ_InventoryCrafting *);
CloneMCJ_ItemStack *CloneMCJ_InventoryCrafting_GetSlot(CloneMCJ_InventoryCrafting *, int);
const CloneMCJ_ItemStack *CloneMCJ_InventoryCrafting_GetSlotConst(
    const CloneMCJ_InventoryCrafting *, int);
int CloneMCJ_InventoryCrafting_SetSlot(CloneMCJ_InventoryCrafting *, int,
    const CloneMCJ_ItemStack *);
CloneMCJ_ItemStack CloneMCJ_InventoryCrafting_DecrStack(CloneMCJ_InventoryCrafting *,
    int, int);
void CloneMCJ_InventoryCrafting_Clear(CloneMCJ_InventoryCrafting *);

void CloneMCJ_InventoryCraftResult_Initialize(CloneMCJ_InventoryCraftResult *);
void CloneMCJ_InventoryCraftResult_Set(CloneMCJ_InventoryCraftResult *,
    const CloneMCJ_ItemStack *);
CloneMCJ_ItemStack *CloneMCJ_InventoryCraftResult_Get(CloneMCJ_InventoryCraftResult *);

CloneMCJ_CraftingManagerNative *CloneMCJ_CraftingManager_GetInstanceNative(void);
void CloneMCJ_CraftingManager_InitializeNative(void);
int CloneMCJ_CraftingManager_AddShapedNative(const CloneMCJ_ItemStack *, int, int,
    const CloneMCJ_RecipeIngredient *);
int CloneMCJ_CraftingManager_AddShapelessNative(const CloneMCJ_ItemStack *, int,
    const CloneMCJ_RecipeIngredient *);
const CloneMCJ_Recipe *CloneMCJ_CraftingManager_FindMatchingRecipeNative(
    const CloneMCJ_InventoryCrafting *, CloneMCJ_ItemStack *);
int CloneMCJ_CraftingManager_ConsumeRecipeNative(CloneMCJ_InventoryCrafting *,
    const CloneMCJ_Recipe *, CloneMCJ_ItemStack *, int *);
int CloneMCJ_CraftingManager_GetRecipeCountNative(void);
int CloneMCJ_ShapedRecipes_MatchesNative(const CloneMCJ_Recipe *,
    const CloneMCJ_InventoryCrafting *);
int CloneMCJ_ShapelessRecipes_MatchesNative(const CloneMCJ_Recipe *,
    const CloneMCJ_InventoryCrafting *);

void CloneMCJ_RecipesTools_AddNative(void);
void CloneMCJ_RecipesWeapons_AddNative(void);
void CloneMCJ_RecipesIngots_AddNative(void);
void CloneMCJ_RecipesFood_AddNative(void);
void CloneMCJ_RecipesCrafting_AddNative(void);
void CloneMCJ_RecipesArmor_AddNative(void);
void CloneMCJ_RecipesDyes_AddNative(void);

int CloneMCJ_FurnaceRecipes_GetResultNative(const CloneMCJ_ItemStack *,
    CloneMCJ_ItemStack *);
int CloneMCJ_FurnaceRecipes_GetFuelTimeNative(const CloneMCJ_ItemStack *);
int CloneMCJ_FurnaceRecipes_CanSmeltNative(const CloneMCJ_TileEntity *,
    CloneMCJ_ItemStack *);
int CloneMCJ_FurnaceRecipes_SmeltOneNative(CloneMCJ_TileEntity *);

void CloneMCJ_Container_Initialize(CloneMCJ_Container *);
int CloneMCJ_Container_AddSlot(CloneMCJ_Container *, CloneMCJ_ItemStack *, int);
int CloneMCJ_Container_AddTypedSlot(CloneMCJ_Container *, CloneMCJ_ItemStack *, int,
    CloneMCJ_SlotKind, int, int, int, int);
int CloneMCJ_Container_Click(CloneMCJ_Container *, CloneMCJ_InventoryPlayer *, int, int);
int CloneMCJ_Container_ClickEx(CloneMCJ_Container *, CloneMCJ_InventoryPlayer *, int,
    int, int);
int CloneMCJ_Container_QuickMove(CloneMCJ_Container *, CloneMCJ_InventoryPlayer *, int);
int CloneMCJ_Container_GetSlotAt(const CloneMCJ_Container *, int, int);
int CloneMCJ_Container_UpdateCraftResult(CloneMCJ_Container *);
int CloneMCJ_Container_Close(CloneMCJ_Container *, CloneMCJ_InventoryPlayer *,
    CloneMCJ_ItemStack *, int);
short CloneMCJ_Container_BeginTransaction(CloneMCJ_Container *,
    const CloneMCJ_InventoryPlayer *);
int CloneMCJ_Container_BeginTransactionWithId(CloneMCJ_Container *,
    const CloneMCJ_InventoryPlayer *, short);
int CloneMCJ_Container_ResolveTransaction(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, short, int);
int CloneMCJ_Container_SetServerSlot(CloneMCJ_Container *, CloneMCJ_InventoryPlayer *,
    int, const CloneMCJ_ItemStack *);
int CloneMCJ_Container_TakeDroppedStack(CloneMCJ_Container *, CloneMCJ_ItemStack *);

void CloneMCJ_ContainerPlayer_InitializeNative(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, CloneMCJ_InventoryCrafting *,
    CloneMCJ_InventoryCraftResult *);
void CloneMCJ_ContainerWorkbench_InitializeNative(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, CloneMCJ_InventoryCrafting *,
    CloneMCJ_InventoryCraftResult *, int, int, int);
void CloneMCJ_ContainerChest_InitializeNative(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, CloneMCJ_TileEntity *);
void CloneMCJ_ContainerChest_InitializeDoubleNative(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, CloneMCJ_TileEntity *, CloneMCJ_TileEntity *);
void CloneMCJ_ContainerFurnace_InitializeNative(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, CloneMCJ_TileEntity *);
void CloneMCJ_ContainerDispenser_InitializeNative(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, CloneMCJ_TileEntity *);
int CloneMCJ_Priority13_RunSelfTests(char *, int);

#ifdef __cplusplus
}
#endif


void CloneMCJ_BlockPressurePlate_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockPressurePlate_EntityCollisionNative(struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_BlockRedstoneRepeater_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockRail_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockRail_IsRailAtNative(struct CloneMCJ_WorldTag *, int, int, int);
void CloneMCJ_BlockDetectorRail_MinecartCollisionNative(struct CloneMCJ_WorldTag *, int, int, int);
int CloneMCJ_BlockRail_RunV127SelfTests(char *, unsigned int);
void CloneMCJ_BlockPistonBase_RegisterRuntime(struct CloneMCJ_WorldTag *);
void CloneMCJ_BlockPistonMoving_RegisterRuntime(struct CloneMCJ_WorldTag *);
int CloneMCJ_BlockRedstoneRepeater_ActivateNative(struct CloneMCJ_WorldTag *,int,int,int);
void CloneMCJ_BlockRedstoneRepeater_OnPlacedByNative(struct CloneMCJ_WorldTag *,int,int,int);
int CloneMCJ_BlockRedstoneWire_IsUpdatingNative(void);
#endif /* CLONEMC_JAVA_PORT_30_ITEM_H */
