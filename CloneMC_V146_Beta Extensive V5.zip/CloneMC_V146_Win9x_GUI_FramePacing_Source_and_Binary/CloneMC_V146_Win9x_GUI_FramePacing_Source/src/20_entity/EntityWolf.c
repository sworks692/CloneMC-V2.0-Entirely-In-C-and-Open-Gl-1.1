/*
 * CloneMC Java port scaffold: EntityWolf
 *
 * Java source: EntityWolf.java
 * Java type: class EntityWolf
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityAnimal
 * Implements: (none declared)
 * Source SHA-256: 16f8f37a9b65e7800e725bc4e9d8730bae3781940f4f0ff3511b73e1d3947816
 * Java lines: 611
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 38
 * Referenced Java classes: EntityAnimal, DataWatcher, NBTTagCompound, World, EntityPlayer, EntitySheep, AxisAlignedBB, Entity, InventoryPlayer, ItemStack, Item, ItemFood, MathHelper, EntityArrow, EntityLiving
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private boolean looksWithInterest
 * - private float field_25048_b
 * - private float field_25054_c
 * - private boolean isWolfShaking
 * - private boolean field_25052_g
 * - private float timeWolfIsShaking
 * - private float prevTimeWolfIsShaking
 *
 * Java method/constructor inventory:
 * - public EntityWolf(World world)
 * - protected void entityInit()
 * - protected boolean canTriggerWalking()
 * - public String getEntityTexture()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected boolean canDespawn()
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected float getSoundVolume()
 * - protected int getDropItemId()
 * - protected void updatePlayerActionState()
 * - public void onLivingUpdate()
 * - public void onUpdate()
 * - public boolean getWolfShaking()
 * - public float getShadingWhileShaking(float f)
 * - public float getShakeAngle(float f, float f1)
 * - public float getInterestedAngle(float f)
 * - public float getEyeHeight()
 * - protected int func_25026_x()
 * - private void getPathOrWalkableBlock(Entity entity, float f)
 * - protected boolean isMovementCeased()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - protected Entity findPlayerToAttack()
 * - protected void attackEntity(Entity entity, float f)
 * - public boolean interact(EntityPlayer entityplayer)
 * - public void handleHealthUpdate(byte byte0)
 * - public float setTailRotation()
 * - public int getMaxSpawnedInChunk()
 * - public String getWolfOwner()
 * - public void setWolfOwner(String s)
 * - public boolean isWolfSitting()
 * - public void setWolfSitting(boolean flag)
 * - public boolean isWolfAngry()
 * - public void setWolfAngry(boolean flag)
 * - public boolean isWolfTamed()
 * - public void setWolfTamed(boolean flag)
 *
 * Direct conversion: taming, feeding, owner sit/stand control, interest easing,
 * wet-shake animation values and texture-state selection are native runtime
 * behavior translated from the uploaded Java class.
 */
#include "clonemc_java_port_20_entity.h"
#include <ctype.h>
#include <math.h>
#include <string.h>

static int CloneMCJ_EntityWolf_NameEquals(const char *left,const char *right)
{
    unsigned char a,b;
    if(!left||!right)return 0;
    do{
        a=(unsigned char)*left++;b=(unsigned char)*right++;
        if(tolower((int)a)!=tolower((int)b))return 0;
    }while(a&&b);
    return a==b;
}

int CloneMCJ_EntityWolf_GetTextureState(const CloneMCJ_Mob *wolf)
{
    if(!wolf||wolf->type!=CLONEMC_J_MOB_WOLF)return 0;
    if(wolf->tamed)return 2;
    return wolf->angry?1:0;
}

float CloneMCJ_EntityWolf_GetInterestedAngle(const CloneMCJ_Mob *wolf,float partial)
{
    if(!wolf)return 0.0F;
    return (wolf->prevInterestedAngle+
        (wolf->interestedAngle-wolf->prevInterestedAngle)*partial)*0.15F*3.141593F;
}

float CloneMCJ_EntityWolf_GetShakeAngle(const CloneMCJ_Mob *wolf,float partial,float offset)
{
    float value;
    if(!wolf)return 0.0F;
    value=(wolf->prevShakeTime+(wolf->shakeTime-wolf->prevShakeTime)*partial+offset)/1.8F;
    if(value<0.0F)value=0.0F;else if(value>1.0F)value=1.0F;
    return (float)sin((double)(value*3.141593F))*
        (float)sin((double)(value*3.141593F*11.0F))*0.15F*3.141593F;
}

float CloneMCJ_EntityWolf_GetShadingWhileShaking(const CloneMCJ_Mob *wolf,float partial)
{
    float time;
    if(!wolf)return 1.0F;
    time=wolf->prevShakeTime+(wolf->shakeTime-wolf->prevShakeTime)*partial;
    return 0.75F+(time/2.0F)*0.25F;
}

float CloneMCJ_EntityWolf_GetTailRotation(const CloneMCJ_Mob *wolf)
{
    if(!wolf)return 1.570796F;
    if(wolf->angry)return 1.53938F;
    if(wolf->tamed)return (0.55F-(20-wolf->health)*0.02F)*3.141593F;
    return 0.6283185F;
}

void CloneMCJ_EntityWolf_Tick(CloneMCJ_Mob *wolf,CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_ItemStack *held;
    const CloneMCJ_ItemDefinition *item;
    int interested;
    if(!wolf||wolf->type!=CLONEMC_J_MOB_WOLF)return;
    held=player?CloneMCJ_InventoryPlayer_GetCurrent(&player->inventory):0;
    item=held&&!CloneMCJ_ItemStack_IsEmpty(held)?CloneMCJ_ItemRegistry_Get(held->itemID):0;
    interested=held&&!CloneMCJ_ItemStack_IsEmpty(held)&&
        ((!wolf->tamed&&held->itemID==352)||
         (wolf->tamed&&item&&item->wolfsFavoriteMeat));
    wolf->looksWithInterest=(unsigned char)(interested?1:0);
    wolf->prevInterestedAngle=wolf->interestedAngle;
    wolf->interestedAngle+=((interested?1.0F:0.0F)-wolf->interestedAngle)*0.4F;
    if(wolf->entity.inWater){
        wolf->wolfShaking=1;wolf->wolfShakeStarted=0;
        wolf->shakeTime=0.0F;wolf->prevShakeTime=0.0F;
        wolf->sitting=0;
    }else if(wolf->wolfShaking&&!wolf->wolfShakeStarted&&wolf->entity.onGround){
        wolf->wolfShakeStarted=1;wolf->shakeTime=0.0F;wolf->prevShakeTime=0.0F;
    }
    if(wolf->wolfShakeStarted){
        wolf->prevShakeTime=wolf->shakeTime;wolf->shakeTime+=0.05F;
        if(wolf->prevShakeTime>=2.0F){
            wolf->wolfShaking=0;wolf->wolfShakeStarted=0;
            wolf->prevShakeTime=0.0F;wolf->shakeTime=0.0F;
        }
    }
}

int CloneMCJ_EntityWolf_Interact(CloneMCJ_Mob *wolf,CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_ItemStack *held;
    const CloneMCJ_ItemDefinition *item;
    if(!wolf||wolf->type!=CLONEMC_J_MOB_WOLF||!player)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&player->inventory);
    item=held&&!CloneMCJ_ItemStack_IsEmpty(held)?CloneMCJ_ItemRegistry_Get(held->itemID):0;
    if(!wolf->tamed){
        if(!held||CloneMCJ_ItemStack_IsEmpty(held)||held->itemID!=352||wolf->angry)return 0;
        --held->stackSize;if(held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        player->inventory.inventoryChanged=1;
        if(CloneMCJavaRandom_NextIntBound(&wolf->entity.rand,3)==0){
            wolf->tamed=1;wolf->angry=0;wolf->sitting=1;wolf->maxHealth=20;wolf->health=20;
            strncpy(wolf->owner,player->username,sizeof(wolf->owner)-1);
            wolf->owner[sizeof(wolf->owner)-1]='\0';
        }
        return 1;
    }
    if(item&&item->wolfsFavoriteMeat&&wolf->health<wolf->maxHealth){
        --held->stackSize;if(held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        wolf->health+=3;if(wolf->health>wolf->maxHealth)wolf->health=wolf->maxHealth;
        player->inventory.inventoryChanged=1;
        return 1;
    }
    if(item&&item->wolfsFavoriteMeat)return 0;
    if(CloneMCJ_EntityWolf_NameEquals(wolf->owner,player->username)){
        wolf->sitting=(unsigned char)!wolf->sitting;wolf->jumping=0;
        return 1;
    }
    return 0;
}

void CloneMCJ_EntityWolf_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityWolf_JavaName(void)
{
    return "net.minecraft.src.EntityWolf";
}

const char *CloneMCJ_EntityWolf_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityWolf_JavaSourceHash32(void)
{
    return 0x16F8F37AUL;
}
