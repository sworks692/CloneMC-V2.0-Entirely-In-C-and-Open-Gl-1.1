/*
 * CloneMC Java port scaffold: EntityPlayer
 *
 * Java source: EntityPlayer.java
 * Java type: class EntityPlayer
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityLiving
 * Implements: (none declared)
 * Source SHA-256: 5e0448b67bcf5c3e763820f284956ca7c1ea4865bb115c9abe544f21b6e98a25
 * Java lines: 972
 * Discovered declared fields: 32
 * Discovered declared methods/constructors: 67
 * Referenced Java classes: EntityLiving, InventoryPlayer, ContainerPlayer, World, ChunkCoordinates, DataWatcher, Container, StatList, MathHelper, AxisAlignedBB, Entity, ItemStack, Item, EntityItem, Material, NBTTagCompound, NBTTagList, EntityMob, EntityArrow, EntityCreeper, EntityGhast, EntityWolf, EnumStatus, WorldProvider, BlockBed, Block, IChunkProvider, EntityMinecart, AchievementList, EntityBoat, EntityPig, EntityFish, IInventory, TileEntityFurnace, TileEntityDispenser, TileEntitySign, StatBase
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public InventoryPlayer inventory
 * - public Container inventorySlots
 * - public Container craftingInventory
 * - public byte field_9371_f
 * - public int score
 * - public float field_775_e
 * - public float field_774_f
 * - public boolean isSwinging
 * - public int swingProgressInt
 * - public String username
 * - public int dimension
 * - public String playerCloakUrl
 * - public double field_20066_r
 * - public double field_20065_s
 * - public double field_20064_t
 * - public double field_20063_u
 * - public double field_20062_v
 * - public double field_20061_w
 * - protected boolean sleeping
 * - public ChunkCoordinates bedChunkCoordinates
 * - private int sleepTimer
 * - public float field_22063_x
 * - public float field_22062_y
 * - public float field_22061_z
 * - private ChunkCoordinates playerSpawnCoordinate
 * - private ChunkCoordinates startMinecartRidingCoordinate
 * - public int timeUntilPortal
 * - protected boolean inPortal
 * - public float timeInPortal
 * - public float prevTimeInPortal
 * - private int damageRemainder
 * - public EntityFish fishEntity
 *
 * Java method/constructor inventory:
 * - public EntityPlayer(World world)
 * - protected void entityInit()
 * - public void onUpdate()
 * - protected boolean isMovementBlocked()
 * - protected void closeScreen()
 * - public void updateCloak()
 * - public void updateRidden()
 * - public void preparePlayerToSpawn()
 * - protected void updatePlayerActionState()
 * - public void onLivingUpdate()
 * - private void collideWithPlayer(Entity entity)
 * - public int getScore()
 * - public void onDeath(Entity entity)
 * - public void addToPlayerScore(Entity entity, int i)
 * - public void dropCurrentItem()
 * - public void dropPlayerItem(ItemStack itemstack)
 * - public void dropPlayerItemWithRandomChoice(ItemStack itemstack, boolean flag)
 * - protected void joinEntityItemWithWorld(EntityItem entityitem)
 * - public float getCurrentPlayerStrVsBlock(Block block)
 * - public boolean canHarvestBlock(Block block)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void displayGUIChest(IInventory iinventory)
 * - public void displayWorkbenchGUI(int i, int j, int k)
 * - public void onItemPickup(Entity entity, int i)
 * - public float getEyeHeight()
 * - protected void resetHeight()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - protected boolean func_27025_G()
 * - protected void alertWolves(EntityLiving entityliving, boolean flag)
 * - protected void damageEntity(int i)
 * - public void displayGUIFurnace(TileEntityFurnace tileentityfurnace)
 * - public void displayGUIDispenser(TileEntityDispenser tileentitydispenser)
 * - public void displayGUIEditSign(TileEntitySign tileentitysign)
 * - public void useCurrentItemOnEntity(Entity entity)
 * - public ItemStack getCurrentEquippedItem()
 * - public void destroyCurrentEquippedItem()
 * - public double getYOffset()
 * - public void swingItem()
 * - public void attackTargetEntityWithCurrentItem(Entity entity)
 * - public void respawnPlayer()
 * - public abstract void func_6420_o()
 * - public void onItemStackChanged(ItemStack itemstack)
 * - public void setEntityDead()
 * - public boolean isEntityInsideOpaqueBlock()
 * - public EnumStatus sleepInBedAt(int i, int j, int k)
 * - private void func_22052_e(int i)
 * - public void wakeUpPlayer(boolean flag, boolean flag1, boolean flag2)
 * - private boolean isInBed()
 * - public static ChunkCoordinates func_25060_a(World world, ChunkCoordinates chunkcoordinates)
 * - public float getBedOrientationInDegrees()
 * - public boolean isPlayerSleeping()
 * - public boolean isPlayerFullyAsleep()
 * - public int func_22060_M()
 * - public void addChatMessage(String s)
 * - public ChunkCoordinates getPlayerSpawnCoordinate()
 * - public void setPlayerSpawnCoordinate(ChunkCoordinates chunkcoordinates)
 * - public void triggerAchievement(StatBase statbase)
 * - public void addStat(StatBase statbase, int i)
 * - protected void jump()
 * - public void moveEntityWithHeading(float f, float f1)
 * - private void addMovementStat(double d, double d1, double d2)
 * - private void addMountedMovementStat(double d, double d1, double d2)
 * - protected void fall(float f)
 * - public void onKillEntity(EntityLiving entityliving)
 * - public int getItemIcon(ItemStack itemstack)
 * - public void setInPortal()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

void CloneMCJ_EntityPlayer_Initialize(CloneMCJ_EntityPlayer *player, CloneMCJ_World *world, const char *username)
{
    int spawnX, spawnY, spawnZ;
    if (!player) return;
    memset(player, 0, sizeof(*player));
    CloneMCJ_Entity_Initialize(&player->entity, world);
    CloneMCJ_Entity_SetSize(&player->entity, 0.6F, 1.8F);
    player->entity.stepHeight = 0.5F;
    player->health = 20;
    player->dimension = world ? world->worldInfo.dimension : 0;
    player->gameMode=world?world->worldInfo.gameType:CLONEMC_J_GAMEMODE_SURVIVAL;
    player->allowFlying=(unsigned char)(player->gameMode!=CLONEMC_J_GAMEMODE_SURVIVAL);
    player->flying=(unsigned char)(player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR);
    player->invulnerable=player->allowFlying;
    player->sprintFovModifier=player->prevSprintFovModifier=1.0F;
    player->timeUntilPortal = 20;
    player->timeInPortal = player->prevTimeInPortal = 0.0F;
    player->inPortal = 0;
    player->sleeping = 0;
    CloneMCJ_InventoryPlayer_Initialize(&player->inventory);
    if (username) {
        strncpy(player->username, username, sizeof(player->username) - 1U);
        player->username[sizeof(player->username) - 1U] = '\0';
    } else strcpy(player->username, "Player");
    spawnX = world ? world->worldInfo.spawnX : 0;
    spawnZ = world ? world->worldInfo.spawnZ : 0;
    spawnY = world ? world->worldInfo.spawnY : 0;
    if (world && spawnY <= 0) spawnY = CloneMCJ_World_FindTopSolidBlock(world, spawnX, spawnZ) + 1;
    if (spawnY <= 0) spawnY = 65;
    player->spawnX=spawnX;player->spawnY=spawnY;player->spawnZ=spawnZ;
    player->bedX=spawnX;player->bedY=spawnY;player->bedZ=spawnZ;
    CloneMCJ_Entity_SetPosition(&player->entity, spawnX + 0.5, (double)spawnY, spawnZ + 0.5);
    player->cloakPrevX=player->cloakX=player->entity.posX;
    player->cloakPrevY=player->cloakY=player->entity.posY;
    player->cloakPrevZ=player->cloakZ=player->entity.posZ;
}

void CloneMCJ_EntityPlayer_SwingItem(CloneMCJ_EntityPlayer *player)
{
    if(!player)return;
    player->swingProgressInt=-1;
    player->isSwinging=1;
}

void CloneMCJ_EntityPlayer_SetInPortal(CloneMCJ_EntityPlayer *player)
{
    if(!player)return;
    if(player->timeUntilPortal>0)player->timeUntilPortal=10;
    else player->inPortal=1;
}

static int CloneMCJ_EntityPlayer_OverlapsPortal(CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_Entity *entity;CloneMCJ_World *world;int minX,maxX,minY,maxY,minZ,maxZ,x,y,z;
    if(!player||!player->entity.worldObj)return 0;entity=&player->entity;world=entity->worldObj;
    minX=CloneMCJava_FloorDouble(entity->boundingBox.minX+0.001);
    maxX=CloneMCJava_FloorDouble(entity->boundingBox.maxX-0.001);
    minY=CloneMCJava_FloorDouble(entity->boundingBox.minY+0.001);
    maxY=CloneMCJava_FloorDouble(entity->boundingBox.maxY-0.001);
    minZ=CloneMCJava_FloorDouble(entity->boundingBox.minZ+0.001);
    maxZ=CloneMCJava_FloorDouble(entity->boundingBox.maxZ-0.001);
    for(x=minX;x<=maxX;++x)for(y=minY;y<=maxY;++y)for(z=minZ;z<=maxZ;++z)
        if(CloneMCJ_World_GetBlockId(world,x,y,z)==CLONEMC_J_BLOCK_PORTAL)return 1;
    return 0;
}

void CloneMCJ_EntityPlayer_SetInput(CloneMCJ_EntityPlayer *player, float strafe, float forward, int jump, int sneak)
{
    if (!player) return;
    player->movementInput.moveStrafe = strafe;
    player->movementInput.moveForward = forward;
    player->movementInput.jump = (unsigned char)(jump != 0);
    player->movementInput.sneak = (unsigned char)(sneak != 0);
    player->entity.sneaking = player->movementInput.sneak;
}

int CloneMCJ_EntityPlayer_CanSprint(const CloneMCJ_EntityPlayer *player)
{
    const CloneMCJ_Entity *entity;
    if(!player)return 0;
    entity=&player->entity;
    return player->gameMode==CLONEMC_J_GAMEMODE_SURVIVAL&&
        !player->allowFlying&&!player->flying&&!player->sleeping&&
        player->ridingEntityId==0&&player->health>0&&!entity->isDead&&
        entity->worldObj&&!entity->worldObj->multiplayerWorld&&
        !player->movementInput.sneak&&!entity->inWater&&!entity->inLava&&
        !entity->inWeb;
}

void CloneMCJ_EntityPlayer_SetSprinting(CloneMCJ_EntityPlayer *player,
    int sprinting)
{
    if(!player)return;
    player->sprinting=(unsigned char)(sprinting&&
        CloneMCJ_EntityPlayer_CanSprint(player));
}

int CloneMCJ_EntityPlayer_IsSprinting(const CloneMCJ_EntityPlayer *player)
{
    return player&&player->sprinting;
}

static void CloneMCJ_EntityPlayer_UpdateSprintFov(CloneMCJ_EntityPlayer *player)
{
    float target;
    if(!player)return;
    player->prevSprintFovModifier=player->sprintFovModifier;
    target=player->sprinting?CLONEMC_J_SPRINT_FOV_MULTIPLIER:1.0F;
    player->sprintFovModifier+=(target-player->sprintFovModifier)*0.5F;
    if(player->sprintFovModifier<0.1F)player->sprintFovModifier=0.1F;
    if(player->sprintFovModifier>1.5F)player->sprintFovModifier=1.5F;
}

static void CloneMCJ_EntityPlayer_UpdateEnvironment(CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_Entity *entity;
    CloneMCJ_World *world;
    const CloneMCJ_BlockDefinition *eyeBlock;
    int x,y,z,bodyID;
    int fireResistant;
    if(!player||player->health<=0)return;
    entity=&player->entity;world=entity->worldObj;if(!world)return;
    if(world->multiplayerWorld){entity->fire=0;entity->air=300;return;}
    entity->inWater=(unsigned char)CloneMCJ_Entity_IsInsideMaterial(entity,CLONEMC_J_MATERIAL_WATER);
    entity->inLava=(unsigned char)CloneMCJ_Entity_IsInsideMaterial(entity,CLONEMC_J_MATERIAL_LAVA);
    x=CloneMCJava_FloorDouble(entity->posX);
    y=CloneMCJava_FloorDouble(entity->posY+(double)entity->height*0.85);
    z=CloneMCJava_FloorDouble(entity->posZ);
    eyeBlock=CloneMCJ_BlockRegistry_Get(CloneMCJ_World_GetBlockId(world,x,y,z));
    if(eyeBlock&&eyeBlock->solid)CloneMCJ_EntityPlayer_AttackFrom(player,(const CloneMCJ_Entity *)0,1);
    if(entity->inWater){entity->fallDistance=0.0F;entity->fire=0;}
    if(eyeBlock&&eyeBlock->material==CLONEMC_J_MATERIAL_WATER){
        --entity->air;if(entity->air<=-20){entity->air=0;
            CloneMCJ_EntityPlayer_AttackFrom(player,(const CloneMCJ_Entity *)0,2);}
    }else entity->air=300;
    fireResistant=CloneMCJ_Progression_HasEffect(player,
        CLONEMC_J_EFFECT_FIRE_RESISTANCE,(int *)0);
    if(fireResistant)entity->fire=0;
    if(entity->fire>0){
        if((entity->fire%20)==0)
            CloneMCJ_Progression_AttackPlayerProtected(player,
                (const CloneMCJ_Entity *)0,1,
                CLONEMC_J_ENCHANT_FIRE_PROTECTION);
        --entity->fire;}
    if(entity->inLava&&!fireResistant){
        CloneMCJ_Progression_AttackPlayerProtected(player,
            (const CloneMCJ_Entity *)0,4,
            CLONEMC_J_ENCHANT_FIRE_PROTECTION);
        entity->fire=600;
    }
    bodyID=CloneMCJ_World_GetBlockId(world,CloneMCJava_FloorDouble(entity->posX),
        CloneMCJava_FloorDouble(entity->boundingBox.minY+0.1),CloneMCJava_FloorDouble(entity->posZ));
    if(bodyID==51&&!fireResistant){
        CloneMCJ_Progression_AttackPlayerProtected(player,
            (const CloneMCJ_Entity *)0,1,
            CLONEMC_J_ENCHANT_FIRE_PROTECTION);
        if(entity->fire<300)entity->fire=300;}
    if(entity->posY<-64.0)player->health=0;
}

void CloneMCJ_EntityPlayer_Tick(CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_Entity *entity;
    float acceleration,landingDistance;
    float slipperiness;
    int belowID;
    const CloneMCJ_BlockDefinition *below;
    if (!player || !player->entity.worldObj || player->entity.isDead) return;
    entity = &player->entity;
    player->prevSwingProgress=player->swingProgress;
    if(player->isSwinging){
        ++player->swingProgressInt;
        if(player->swingProgressInt>=8){
            player->swingProgressInt=0;
            player->isSwinging=0;
        }
    }else player->swingProgressInt=0;
    player->swingProgress=(float)player->swingProgressInt/8.0F;
    entity->prevPosX = entity->posX;
    entity->prevPosY = entity->posY;
    entity->prevPosZ = entity->posZ;
    entity->prevRotationYaw = entity->rotationYaw;
    entity->prevRotationPitch = entity->rotationPitch;
    /* EntityPlayer.onUpdate updates the cloak chase point after the previous
     * transform has been captured.  Teleports larger than ten blocks reset the
     * chase point; ordinary movement eases toward the player by one quarter. */
    player->cloakPrevX=player->cloakX;
    player->cloakPrevY=player->cloakY;
    player->cloakPrevZ=player->cloakZ;
    {
        double cloakDX,cloakDY,cloakDZ;
        cloakDX=entity->posX-player->cloakX;
        cloakDY=entity->posY-player->cloakY;
        cloakDZ=entity->posZ-player->cloakZ;
        if(cloakDX>10.0||cloakDX<-10.0)
            player->cloakPrevX=player->cloakX=entity->posX;
        if(cloakDY>10.0||cloakDY<-10.0)
            player->cloakPrevY=player->cloakY=entity->posY;
        if(cloakDZ>10.0||cloakDZ<-10.0)
            player->cloakPrevZ=player->cloakZ=entity->posZ;
        player->cloakX+=cloakDX*0.25;
        player->cloakY+=cloakDY*0.25;
        player->cloakZ+=cloakDZ*0.25;
    }
    ++entity->ticksExisted;
    CloneMCJ_Progression_TickPlayerEffects(player);
    if(player->hurtTime>0)--player->hurtTime;
    if(player->hurtResistantTime>0)--player->hurtResistantTime;
    player->prevTimeInPortal=player->timeInPortal;
    player->inPortal=0;
    if(!player->invulnerable)CloneMCJ_EntityPlayer_UpdateEnvironment(player);
    else{entity->fire=0;entity->air=300;entity->fallDistance=0.0F;}
    /* BlockPortal.onEntityCollidedWithBlock is independent of damage
     * vulnerability in the Java client.  Creative players are invulnerable,
     * so keeping this collision test inside UpdateEnvironment made them skip
     * portal entry completely.  Detect portal overlap for every local player;
     * multiplayer remains server authoritative. */
    if(!entity->worldObj->multiplayerWorld&&
       CloneMCJ_EntityPlayer_OverlapsPortal(player))
        CloneMCJ_EntityPlayer_SetInPortal(player);
    if(player->inPortal){
        player->timeInPortal+=0.0125F;if(player->timeInPortal>1.0F)player->timeInPortal=1.0F;
    }else{
        player->timeInPortal-=0.05F;if(player->timeInPortal<0.0F)player->timeInPortal=0.0F;
    }
    if(player->timeUntilPortal>0)--player->timeUntilPortal;
    if(player->health<=0){player->sprinting=0;
        CloneMCJ_EntityPlayer_UpdateSprintFov(player);return;}
    if(player->flying){
        player->sprinting=0;
        CloneMCJ_EntityPlayer_UpdateSprintFov(player);
        entity->noClip=(unsigned char)(player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR);
        entity->motionY=player->movementInput.jump?0.35:(player->movementInput.sneak?-0.35:0.0);
        entity->motionX*=0.5;entity->motionZ*=0.5;
        CloneMCJ_Entity_MoveFlying(entity,player->movementInput.moveStrafe,
            player->movementInput.moveForward,0.12F);
        if(entity->noClip){entity->posX+=entity->motionX;entity->posY+=entity->motionY;
            entity->posZ+=entity->motionZ;CloneMCJ_Entity_SetPosition(entity,entity->posX,entity->posY,entity->posZ);}
        else CloneMCJ_Entity_Move(entity,entity->motionX,entity->motionY,entity->motionZ);
        entity->motionX*=0.7;entity->motionY*=0.7;entity->motionZ*=0.7;
        CloneMCJ_World_SetPlayerGlobalPosition(entity->worldObj,entity->posX,entity->posZ);return;
    }else entity->noClip=0;
    if(player->sleeping){player->sprinting=0;
        CloneMCJ_EntityPlayer_UpdateSprintFov(player);
        entity->motionX=entity->motionY=entity->motionZ=0.0;
        CloneMCJ_World_SetPlayerGlobalPosition(entity->worldObj,entity->posX,entity->posZ);return;}
    entity->inWeb = (unsigned char)CloneMCJ_Entity_IsInsideMaterial(entity, CLONEMC_J_MATERIAL_PLANT) &&
                    CloneMCJ_World_GetBlockId(entity->worldObj, CloneMCJava_FloorDouble(entity->posX),
                        CloneMCJava_FloorDouble(entity->posY + 0.4), CloneMCJava_FloorDouble(entity->posZ)) == 30;
    /* Modern LocalPlayer cancels sprint when forward intent is lost or a
     * horizontal collision blocks the player.  Perform this before sneak
     * scales the Java MovementInput values so the 0.8 threshold is evaluated
     * against the unmodified configured-forward action. */
    if(player->sprinting&&(!CloneMCJ_EntityPlayer_CanSprint(player)||
       player->movementInput.moveForward<0.8F||entity->collidedHorizontally))
        player->sprinting=0;
    if (player->movementInput.sneak) {
        player->movementInput.moveStrafe *= 0.3F;
        player->movementInput.moveForward *= 0.3F;
    }
    landingDistance=entity->fallDistance;
    if(entity->motionY<0.0)landingDistance-=(float)entity->motionY;
    if(entity->inWater||entity->inLava)landingDistance=0.0F;
    if (entity->inWater || entity->inLava) {
        acceleration = entity->inWater ? 0.02F : 0.02F;
        if (player->movementInput.jump) entity->motionY += 0.04;
        CloneMCJ_Entity_MoveFlying(entity, player->movementInput.moveStrafe, player->movementInput.moveForward, acceleration);
        CloneMCJ_Entity_Move(entity, entity->motionX, entity->motionY, entity->motionZ);
        entity->motionX *= entity->inWater ? 0.8 : 0.5;
        entity->motionY *= entity->inWater ? 0.8 : 0.5;
        entity->motionZ *= entity->inWater ? 0.8 : 0.5;
        entity->motionY -= entity->inWater ? 0.02 : 0.02;
    } else {
        if (player->movementInput.jump && entity->onGround) {
            entity->motionY = 0.42;
            if(player->sprinting){
                double yawRadians;
                yawRadians=(double)entity->rotationYaw*3.14159265358979323846/180.0;
                entity->motionX-=sin(yawRadians)*CLONEMC_J_SPRINT_JUMP_IMPULSE;
                entity->motionZ+=cos(yawRadians)*CLONEMC_J_SPRINT_JUMP_IMPULSE;
            }
        }
        belowID = CloneMCJ_World_GetBlockId(entity->worldObj, CloneMCJava_FloorDouble(entity->posX),
            CloneMCJava_FloorDouble(entity->boundingBox.minY) - 1, CloneMCJava_FloorDouble(entity->posZ));
        below = CloneMCJ_BlockRegistry_Get(belowID);
        slipperiness = entity->onGround && below ? below->slipperiness * 0.91F : 0.91F;
        acceleration = entity->onGround ? 0.1F * (0.16277136F / (slipperiness * slipperiness * slipperiness)) : 0.02F;
        if(entity->onGround&&player->sprinting)
            acceleration*=CLONEMC_J_SPRINT_SPEED_MULTIPLIER;
        {
            int speedAmplifier;
            if(CloneMCJ_Progression_HasEffect(player,CLONEMC_J_EFFECT_SPEED,
                &speedAmplifier))
                acceleration*=1.0F+0.2F*(float)(speedAmplifier+1);
        }
        CloneMCJ_Entity_MoveFlying(entity, player->movementInput.moveStrafe, player->movementInput.moveForward, acceleration);
        CloneMCJ_Entity_Move(entity, entity->motionX, entity->motionY, entity->motionZ);
        if(entity->collidedHorizontally)player->sprinting=0;
        entity->motionY -= 0.08;
        entity->motionY *= 0.98;
        entity->motionX *= slipperiness;
        entity->motionZ *= slipperiness;
        if (belowID == 88) { entity->motionX *= 0.4; entity->motionZ *= 0.4; }
    }
    if(entity->onGround&&landingDistance>3.0F)
        CloneMCJ_EntityPlayer_AttackFrom(player,(const CloneMCJ_Entity *)0,
            (int)ceil((double)landingDistance-3.0));
    if (CloneMCJ_World_GetBlockId(entity->worldObj, CloneMCJava_FloorDouble(entity->posX),
        CloneMCJava_FloorDouble(entity->posY), CloneMCJava_FloorDouble(entity->posZ)) == 65) {
        if (entity->motionX < -0.15) entity->motionX = -0.15;
        if (entity->motionX > 0.15) entity->motionX = 0.15;
        if (entity->motionZ < -0.15) entity->motionZ = -0.15;
        if (entity->motionZ > 0.15) entity->motionZ = 0.15;
        if (entity->motionY < -0.15) entity->motionY = -0.15;
        if (player->movementInput.jump) entity->motionY = 0.2;
    }
    CloneMCJ_EntityPlayer_UpdateSprintFov(player);
    CloneMCJ_World_SetPlayerGlobalPosition(entity->worldObj, entity->posX, entity->posZ);
}

int CloneMCJ_EntityPlayer_AttackFrom(CloneMCJ_EntityPlayer *player,
    const CloneMCJ_Entity *source,int damage)
{
    int armor,scaled;
    int enchantmentProtection;
    int i;
    double dx,dz,length;
    if(!player||player->health<=0||damage<=0||player->invulnerable)return 0;
    if(player->entity.worldObj&&player->entity.worldObj->multiplayerWorld)return 0;
    if(player->hurtResistantTime>10){
        if(damage<=player->lastDamage)return 0;
        damage-=player->lastDamage;
    }else{
        player->lastDamage=damage;player->hurtResistantTime=20;
        player->maxHurtTime=player->hurtTime=10;
    }
    armor=CloneMCJ_InventoryPlayer_GetTotalArmorValue(&player->inventory);
    enchantmentProtection=0;
    for(i=0;i<CLONEMC_J_ARMOR_INVENTORY_SIZE;++i)
        enchantmentProtection+=CloneMCJ_Progression_EnchantLevel(
            &player->inventory.armorInventory[i],CLONEMC_J_ENCHANT_PROTECTION);
    if(enchantmentProtection>20)enchantmentProtection=20;
    damage=damage*(25-enchantmentProtection)/25;
    if(damage<1)damage=1;
    scaled=damage*(25-armor)+player->damageRemainder;
    CloneMCJ_InventoryPlayer_DamageArmor(&player->inventory,damage);
    damage=scaled/25;player->damageRemainder=scaled%25;
    if(damage<=0)return 1;
    player->health-=damage;if(player->health<0)player->health=0;
    if(source){player->lastAttackerEntityId=source->entityId;
        dx=player->entity.posX-source->posX;dz=player->entity.posZ-source->posZ;
        length=sqrt(dx*dx+dz*dz);if(length<0.0001){dx=0.01;dz=0.01;length=0.0141421356;}
        player->entity.motionX+=dx/length*0.4;player->entity.motionZ+=dz/length*0.4;
        player->entity.motionY+=0.4;if(player->entity.motionY>0.4)player->entity.motionY=0.4;}
    return 1;
}

int CloneMCJ_EntityPlayer_WriteNBT(const CloneMCJ_EntityPlayer *player, CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagList *effects;
    CloneMCJ_NBTTagCompound *effect;
    int i;
    if (!player || !compound) return 0;
    CloneMCJ_Entity_WriteNBT(&player->entity, compound, "Player");
    CloneMCJ_NBTTagCompound_SetShort(compound, "Health", (CloneMCJShort)player->health);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "Score", player->score);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "Dimension", player->dimension);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"playerGameType",player->gameMode);
    CloneMCJ_NBTTagCompound_SetBoolean(compound,"flying",player->flying);
    CloneMCJ_NBTTagCompound_SetShort(compound, "HurtTime", (CloneMCJShort)player->hurtTime);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "RidingEntity", player->ridingEntityId);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"XpLevel",player->experienceLevel);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"XpTotal",player->experienceTotal);
    CloneMCJ_NBTTagCompound_SetFloat(compound,"XpP",player->experienceProgress);
    effects=CloneMCJ_NBTTagList_Create();
    if(effects){
        for(i=0;i<CLONEMC_J_MAX_ACTIVE_EFFECTS;++i)
            if(player->activeEffectDuration[i]>0){
                effect=CloneMCJ_NBTTagCompound_Create();
                if(!effect)continue;
                CloneMCJ_NBTTagCompound_SetByte(effect,"Id",
                    (CloneMCJByte)player->activeEffectId[i]);
                CloneMCJ_NBTTagCompound_SetByte(effect,"Amplifier",
                    (CloneMCJByte)player->activeEffectAmplifier[i]);
                CloneMCJ_NBTTagCompound_SetInteger(effect,"Duration",
                    player->activeEffectDuration[i]);
                CloneMCJ_NBTTagList_Append(effects,(CloneMCJ_NBTBase *)effect);
            }
        if(CloneMCJ_NBTTagList_Count(effects)>0)
            CloneMCJ_NBTTagCompound_SetTag(compound,"ActiveEffects",
                (CloneMCJ_NBTBase *)effects);
        else CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)effects);
    }
    if(player->hasBedSpawn){
        CloneMCJ_NBTTagCompound_SetInteger(compound,"SpawnX",player->spawnX);
        CloneMCJ_NBTTagCompound_SetInteger(compound,"SpawnY",player->spawnY);
        CloneMCJ_NBTTagCompound_SetInteger(compound,"SpawnZ",player->spawnZ);
    }
    CloneMCJ_InventoryPlayer_WriteNBT(&player->inventory, compound);
    return 1;
}

int CloneMCJ_EntityPlayer_ReadNBT(CloneMCJ_EntityPlayer *player, const CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagList *effects;
    CloneMCJ_NBTTagCompound *effect;
    int i,count;
    char key[32];
    if (!player || !compound) return 0;
    if (!CloneMCJ_Entity_ReadNBT(&player->entity, compound)) return 0;
    player->health = CloneMCJ_NBTTagCompound_HasKey(compound,"Health")?
        CloneMCJ_NBTTagCompound_GetShort(compound, "Health"):20;
    player->score = CloneMCJ_NBTTagCompound_GetInteger(compound, "Score");
    player->dimension = CloneMCJ_NBTTagCompound_GetInteger(compound, "Dimension");
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"playerGameType"))
        player->gameMode=CloneMCJ_NBTTagCompound_GetInteger(compound,"playerGameType");
    player->allowFlying=(unsigned char)(player->gameMode!=CLONEMC_J_GAMEMODE_SURVIVAL);
    player->flying=(unsigned char)(player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR);
    player->sprinting=0;
    player->sprintFovModifier=player->prevSprintFovModifier=1.0F;
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"flying")&&player->allowFlying)
        player->flying=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound,"flying");
    if(player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR)player->flying=1;
    player->invulnerable=player->allowFlying;
    player->hurtTime = CloneMCJ_NBTTagCompound_GetShort(compound, "HurtTime");
    player->ridingEntityId = CloneMCJ_NBTTagCompound_GetInteger(compound, "RidingEntity");
    player->experienceLevel=CloneMCJ_NBTTagCompound_GetInteger(compound,"XpLevel");
    player->experienceTotal=CloneMCJ_NBTTagCompound_GetInteger(compound,"XpTotal");
    player->experienceProgress=CloneMCJ_NBTTagCompound_GetFloat(compound,"XpP");
    if(player->experienceLevel<0)player->experienceLevel=0;
    if(player->experienceTotal<0)player->experienceTotal=0;
    if(player->experienceProgress<0.0F)player->experienceProgress=0.0F;
    if(player->experienceProgress>=1.0F)player->experienceProgress=0.9999F;
    for(i=0;i<CLONEMC_J_MAX_ACTIVE_EFFECTS;++i){
        player->activeEffectId[i]=0;
        player->activeEffectAmplifier[i]=0;
        player->activeEffectDuration[i]=0;
    }
    effects=CloneMCJ_NBTTagCompound_GetTagList(compound,"ActiveEffects");
    if(effects){
        count=CloneMCJ_NBTTagList_Count(effects);
        if(count>CLONEMC_J_MAX_ACTIVE_EFFECTS)
            count=CLONEMC_J_MAX_ACTIVE_EFFECTS;
        for(i=0;i<count;++i){
            effect=(CloneMCJ_NBTTagCompound *)CloneMCJ_NBTTagList_Get(effects,i);
            if(!effect||effect->type!=10)continue;
            player->activeEffectId[i]=(unsigned char)
                CloneMCJ_NBTTagCompound_GetByte(effect,"Id");
            player->activeEffectAmplifier[i]=(unsigned char)
                CloneMCJ_NBTTagCompound_GetByte(effect,"Amplifier");
            player->activeEffectDuration[i]=
                CloneMCJ_NBTTagCompound_GetInteger(effect,"Duration");
            if(player->activeEffectDuration[i]<0)
                player->activeEffectDuration[i]=0;
        }
    }else{
        /* V133-V137 compatibility for the earlier flat effect fields. */
        for(i=0;i<CLONEMC_J_MAX_ACTIVE_EFFECTS;++i){
            sprintf(key,"EffectId%d",i);
            player->activeEffectId[i]=(unsigned char)
                CloneMCJ_NBTTagCompound_GetByte(compound,key);
            sprintf(key,"EffectAmp%d",i);
            player->activeEffectAmplifier[i]=(unsigned char)
                CloneMCJ_NBTTagCompound_GetByte(compound,key);
            sprintf(key,"EffectTime%d",i);
            player->activeEffectDuration[i]=
                CloneMCJ_NBTTagCompound_GetInteger(compound,key);
            if(player->activeEffectDuration[i]<0)
                player->activeEffectDuration[i]=0;
        }
    }
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"SpawnX")&&
       CloneMCJ_NBTTagCompound_HasKey(compound,"SpawnY")&&
       CloneMCJ_NBTTagCompound_HasKey(compound,"SpawnZ")){
        player->spawnX=CloneMCJ_NBTTagCompound_GetInteger(compound,"SpawnX");
        player->spawnY=CloneMCJ_NBTTagCompound_GetInteger(compound,"SpawnY");
        player->spawnZ=CloneMCJ_NBTTagCompound_GetInteger(compound,"SpawnZ");
        player->hasBedSpawn=1;
    }
    CloneMCJ_InventoryPlayer_ReadNBT(&player->inventory, compound);
    return 1;
}


int CloneMCJ_EntityPlayer_FindSafeBedSpawn(CloneMCJ_World *world,int bedX,int bedY,int bedZ,
    int *resultX,int *resultY,int *resultZ)
{
    static const int direction[4][2]={{0,1},{-1,0},{0,-1},{1,0}};
    int metadata,dir,pass,x,z,minX,minZ,maxX,maxZ;
    if(!world)return 0;
    if(CloneMCJ_World_GetBlockId(world,bedX,bedY,bedZ)!=26)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,bedX,bedY,bedZ);dir=metadata&3;
    for(pass=0;pass<=1;++pass){
        minX=bedX-direction[dir][0]*pass-1;minZ=bedZ-direction[dir][1]*pass-1;
        maxX=minX+2;maxZ=minZ+2;
        for(x=minX;x<=maxX;++x)for(z=minZ;z<=maxZ;++z)
            if(CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,x,bedY-1,z))&&
               CloneMCJ_World_GetBlockId(world,x,bedY,z)==0&&
               CloneMCJ_World_GetBlockId(world,x,bedY+1,z)==0){
                if(resultX)*resultX=x;if(resultY)*resultY=bedY;if(resultZ)*resultZ=z;return 1;
            }
    }
    return 0;
}

int CloneMCJ_EntityPlayer_TrySleep(CloneMCJ_EntityPlayer *player,int x,int y,int z)
{
    CloneMCJ_World *world;double dx,dy,dz;int metadata,dir;
    static const int direction[4][2]={{0,1},{-1,0},{0,-1},{1,0}};
    if(!player||!player->entity.worldObj||player->sleeping)return 0;world=player->entity.worldObj;
    if(world->worldProvider.isHellWorld)return -2;
    if((world->worldTime%CLONEMC_J_WORLD_DAY_TICKS)<12541L)return -1;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=26)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);dir=metadata&3;
    if(!(metadata&8)){x+=direction[dir][0];z+=direction[dir][1];
        if(CloneMCJ_World_GetBlockId(world,x,y,z)!=26)return 0;metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);}
    dx=player->entity.posX-((double)x+0.5);dy=player->entity.posY-((double)y+0.5);
    dz=player->entity.posZ-((double)z+0.5);if(dx*dx+dy*dy+dz*dz>9.0)return 0;
    if(CloneMCJ_BlockBed_IsOccupied(metadata))return 0;
    player->sleeping=1;player->sleepTimer=0;player->bedX=x;player->bedY=y;player->bedZ=z;
    player->entity.motionX=player->entity.motionY=player->entity.motionZ=0.0;
    CloneMCJ_BlockBed_SetOccupied(world,x,y,z,1);
    CloneMCJ_Entity_SetPosition(&player->entity,(double)x+0.5,(double)y+0.6875,(double)z+0.5);
    return 1;
}

void CloneMCJ_EntityPlayer_Wake(CloneMCJ_EntityPlayer *player,int resetTimer,int setSpawn)
{
    int x,y,z;CloneMCJ_World *world;
    if(!player||!player->entity.worldObj)return;world=player->entity.worldObj;
    if(CloneMCJ_World_GetBlockId(world,player->bedX,player->bedY,player->bedZ)==26)
        CloneMCJ_BlockBed_SetOccupied(world,player->bedX,player->bedY,player->bedZ,0);
    if(CloneMCJ_EntityPlayer_FindSafeBedSpawn(world,player->bedX,player->bedY,player->bedZ,&x,&y,&z))
        CloneMCJ_Entity_SetPosition(&player->entity,(double)x+0.5,(double)y,(double)z+0.5);
    if(setSpawn){player->spawnX=player->bedX;player->spawnY=player->bedY;player->spawnZ=player->bedZ;player->hasBedSpawn=1;}
    player->sleeping=0;if(resetTimer)player->sleepTimer=0;else player->sleepTimer=100;
}

void CloneMCJ_EntityPlayer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityPlayer_JavaName(void)
{
    return "net.minecraft.src.EntityPlayer";
}

const char *CloneMCJ_EntityPlayer_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityPlayer_JavaSourceHash32(void)
{
    return 0x5E0448B6UL;
}
