/*
 * CloneMC Java port scaffold: EntityLiving
 *
 * Java source: EntityLiving.java
 * Java type: class EntityLiving
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 99104386aa00b884eba22b2248e060c123583824aa35fdc4f0116283743af70b
 * Java lines: 974
 * Discovered declared fields: 52
 * Discovered declared methods/constructors: 57
 * Referenced Java classes: Entity, Vec3D, World, Material, MathHelper, Block, StepSound, AxisAlignedBB, NBTTagCompound, ItemStack, MovingObjectPosition, posY
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int heartsHalvesLife
 * - public float field_9365_p
 * - public float field_9363_r
 * - public float renderYawOffset
 * - public float prevRenderYawOffset
 * - protected float field_9362_u
 * - protected float field_9361_v
 * - protected float field_9360_w
 * - protected float field_9359_x
 * - protected boolean field_9358_y
 * - protected String texture
 * - protected boolean field_9355_A
 * - protected float field_9353_B
 * - protected String field_9351_C
 * - protected float field_9349_D
 * - protected int scoreValue
 * - protected float field_9345_F
 * - public boolean isMultiplayerEntity
 * - public float prevSwingProgress
 * - public float swingProgress
 * - public int health
 * - public int prevHealth
 * - private int livingSoundTime
 * - public int hurtTime
 * - public int maxHurtTime
 * - public float attackedAtYaw
 * - public int deathTime
 * - public int attackTime
 * - public float cameraPitch
 * - public float field_9328_R
 * - protected boolean unused_flag
 * - public int field_9326_T
 * - public float field_9325_U
 * - public float field_705_Q
 * - public float field_704_R
 * - public float field_703_S
 * - protected int newPosRotationIncrements
 * - protected double newPosX
 * - protected double newPosY
 * - protected double newPosZ
 * - protected double newRotationYaw
 * - protected double newRotationPitch
 * - protected int field_9346_af
 * - protected int entityAge
 * - protected float moveStrafing
 * - protected float moveForward
 * - protected float randomYawVelocity
 * - protected boolean isJumping
 * - protected float defaultPitch
 * - protected float moveSpeed
 * - private Entity currentTarget
 * - protected int numTicksToChaseTarget
 *
 * Java method/constructor inventory:
 * - public EntityLiving(World world)
 * - protected void entityInit()
 * - public boolean canEntityBeSeen(Entity entity)
 * - public String getEntityTexture()
 * - public boolean canBeCollidedWith()
 * - public boolean canBePushed()
 * - public float getEyeHeight()
 * - public int getTalkInterval()
 * - public void playLivingSound()
 * - public void onEntityUpdate()
 * - public void spawnExplosionParticle()
 * - public void updateRidden()
 * - public void onUpdate()
 * - protected void setSize(float f, float f1)
 * - public void heal(int i)
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public void performHurtAnimation()
 * - protected void damageEntity(int i)
 * - protected float getSoundVolume()
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - public void knockBack(Entity entity, int i, double d, double d1)
 * - public void onDeath(Entity entity)
 * - protected void dropFewItems()
 * - protected int getDropItemId()
 * - protected void fall(float f)
 * - public void moveEntityWithHeading(float f, float f1)
 * - public boolean isOnLadder()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public boolean isEntityAlive()
 * - public boolean canBreatheUnderwater()
 * - public void onLivingUpdate()
 * - protected boolean isMovementBlocked()
 * - protected void jump()
 * - protected boolean canDespawn()
 * - protected void func_27021_X()
 * - protected void updatePlayerActionState()
 * - protected int func_25026_x()
 * - public void faceEntity(Entity entity, float f, float f1)
 * - public boolean hasCurrentTarget()
 * - public Entity getCurrentTarget()
 * - private float updateRotation(float f, float f1, float f2)
 * - public void onEntityDeath()
 * - public boolean getCanSpawnHere()
 * - protected void kill()
 * - public float getSwingProgress(float f)
 * - public Vec3D getPosition(float f)
 * - public Vec3D getLookVec()
 * - public Vec3D getLook(float f)
 * - public MovingObjectPosition rayTrace(double d, float f)
 * - public int getMaxSpawnedInChunk()
 * - public ItemStack getHeldItem()
 * - public void handleHealthUpdate(byte byte0)
 * - public boolean isPlayerSleeping()
 * - public int getItemIcon(ItemStack itemstack)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <math.h>
#include <string.h>

#define CLONEMC_J_PI 3.14159265358979323846
#define CLONEMC_J_DEG_TO_RAD 0.01745329251994329577

static double CloneMCJ_EntityLiving_DistanceSquared(const CloneMCJ_Entity *a,
    const CloneMCJ_Entity *b)
{
    double x,y,z;
    if(!a||!b)return 1.0e30;
    x=a->posX-b->posX;y=a->posY-b->posY;z=a->posZ-b->posZ;
    return x*x+y*y+z*z;
}

static float CloneMCJ_EntityLiving_WrapAngle(float value)
{
    while(value<-180.0F)value+=360.0F;
    while(value>=180.0F)value-=360.0F;
    return value;
}

static float CloneMCJ_EntityLiving_ApproachAngle(float current,float target,float maximum)
{
    float delta;
    delta=CloneMCJ_EntityLiving_WrapAngle(target-current);
    if(delta>maximum)delta=maximum;
    if(delta<-maximum)delta=-maximum;
    return current+delta;
}

static void CloneMCJ_EntityLiving_SetMobSize(CloneMCJ_Mob *mob,float width,float height)
{
    CloneMCJ_Entity_SetSize(&mob->entity,width,height);
}

int CloneMCJ_EntityLiving_GetMaxHealth(CloneMCJ_MobType type,int slimeSize)
{
    switch(type){
    case CLONEMC_J_MOB_SHEEP:return 8;
    case CLONEMC_J_MOB_CHICKEN:return 4;
    case CLONEMC_J_MOB_GIANT:return 200;
    case CLONEMC_J_MOB_WOLF:return 8;
    case CLONEMC_J_MOB_SLIME:
    case CLONEMC_J_MOB_MAGMA_CUBE:
        if(slimeSize<1)slimeSize=1;
        if(slimeSize>16)slimeSize=16;
        return slimeSize*slimeSize;
    case CLONEMC_J_MOB_ENDERMAN:return 40;
    case CLONEMC_J_MOB_BLAZE:return 20;
    case CLONEMC_J_MOB_ENDER_DRAGON:return 200;
    case CLONEMC_J_MOB_ENDER_CRYSTAL:return 5;
    case CLONEMC_J_MOB_VILLAGER:return 20;
    case CLONEMC_J_MOB_CAVE_SPIDER:return 12;
    case CLONEMC_J_MOB_SILVERFISH:return 8;
    case CLONEMC_J_MOB_MOOSHROOM:return 10;
    case CLONEMC_J_MOB_SNOWMAN:return 4;
    case CLONEMC_J_MOB_OCELOT:return 10;
    case CLONEMC_J_MOB_IRON_GOLEM:return 100;
    case CLONEMC_J_MOB_ZOMBIE:
    case CLONEMC_J_MOB_PIG_ZOMBIE:
    case CLONEMC_J_MOB_SKELETON:
    case CLONEMC_J_MOB_CREEPER:
    case CLONEMC_J_MOB_SPIDER:return 20;
    default:return 10;
    }
}

int CloneMCJ_EntityLiving_IsHostileType(CloneMCJ_MobType type)
{
    return type==CLONEMC_J_MOB_ZOMBIE||type==CLONEMC_J_MOB_GIANT||
        type==CLONEMC_J_MOB_GHAST||type==CLONEMC_J_MOB_PIG_ZOMBIE||
        type==CLONEMC_J_MOB_SKELETON||type==CLONEMC_J_MOB_CREEPER||
        type==CLONEMC_J_MOB_SPIDER||type==CLONEMC_J_MOB_SLIME||
        type==CLONEMC_J_MOB_BLAZE||type==CLONEMC_J_MOB_MAGMA_CUBE||
        type==CLONEMC_J_MOB_CAVE_SPIDER||
        type==CLONEMC_J_MOB_SILVERFISH||
        type==CLONEMC_J_MOB_ENDER_DRAGON;
}

int CloneMCJ_EntityLiving_IsHostileNow(const CloneMCJ_Mob *mob)
{
    CloneMCJ_World *world;
    int x,y,z,light;
    if(!mob||!mob->active||mob->health<=0)return 0;
    if(mob->type==CLONEMC_J_MOB_WOLF)return mob->angry&&!mob->tamed;
    if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE)return mob->angerLevel>0;
    if(mob->type==CLONEMC_J_MOB_ENDERMAN)return mob->angry;
    if(mob->type==CLONEMC_J_MOB_MAGMA_CUBE)return 1;
    if(mob->type==CLONEMC_J_MOB_SLIME)return mob->slimeSize>1;
    if(mob->type!=CLONEMC_J_MOB_SPIDER)return CloneMCJ_EntityLiving_IsHostileType(mob->type);
    world=mob->entity.worldObj;
    if(!world)return mob->hostile;
    x=CloneMCJava_FloorDouble(mob->entity.posX);
    y=CloneMCJava_FloorDouble(mob->entity.posY+0.5);
    z=CloneMCJava_FloorDouble(mob->entity.posZ);
    light=CloneMCJ_World_GetFullBlockLightValue(world,x,y,z);
    return light<8||mob->recentlyHit>0||mob->targetMemoryTicks>0;
}

int CloneMCJ_EntityLiving_CanSeeEntity(const CloneMCJ_Entity *viewer,
    const CloneMCJ_Entity *target)
{
    CloneMCJ_World *world;
    double x0,y0,z0,x1,y1,z1,dx,dy,dz,distance,step;
    int samples,index,bx,by,bz,id;
    const CloneMCJ_BlockDefinition *block;
    if(!viewer||!target)return 0;
    world=viewer->worldObj;if(!world||target->worldObj!=world)return 0;
    x0=viewer->posX;y0=viewer->posY+(double)viewer->height*0.85;z0=viewer->posZ;
    x1=target->posX;y1=target->posY+(double)target->height*0.85;z1=target->posZ;
    dx=x1-x0;dy=y1-y0;dz=z1-z0;distance=sqrt(dx*dx+dy*dy+dz*dz);
    if(distance<=0.25)return 1;
    samples=(int)(distance*4.0);if(samples<1)samples=1;if(samples>512)samples=512;
    step=1.0/(double)samples;
    for(index=1;index<samples;++index){
        bx=CloneMCJava_FloorDouble(x0+dx*(double)index*step);
        by=CloneMCJava_FloorDouble(y0+dy*(double)index*step);
        bz=CloneMCJava_FloorDouble(z0+dz*(double)index*step);
        id=CloneMCJ_World_GetBlockId(world,bx,by,bz);if(id<=0)continue;
        block=CloneMCJ_BlockRegistry_Get(id);
        if(block&&block->solid&&block->opaque)return 0;
    }
    return 1;
}

static int CloneMCJ_EntityLiving_CanOccupy(CloneMCJ_World *world,double x,double y,
    double z,float width,float height)
{
    int minX,maxX,minY,maxY,minZ,maxZ,bx,by,bz,id;
    const CloneMCJ_BlockDefinition *block;
    if(!world)return 0;
    minX=CloneMCJava_FloorDouble(x-(double)width*0.5);
    maxX=CloneMCJava_FloorDouble(x+(double)width*0.5);
    minY=CloneMCJava_FloorDouble(y);
    maxY=CloneMCJava_FloorDouble(y+(double)height-0.001);
    minZ=CloneMCJava_FloorDouble(z-(double)width*0.5);
    maxZ=CloneMCJava_FloorDouble(z+(double)width*0.5);
    for(bx=minX;bx<=maxX;++bx)for(by=minY;by<=maxY;++by)for(bz=minZ;bz<=maxZ;++bz){
        id=CloneMCJ_World_GetBlockId(world,bx,by,bz);if(id<=0)continue;
        block=CloneMCJ_BlockRegistry_Get(id);if(block&&block->solid)return 0;
    }
    return 1;
}

static int CloneMCJ_EntityLiving_HasSolidFloor(CloneMCJ_World *world,
    double x,double y,double z,float width)
{
    int minX,maxX,minZ,maxZ,bx,bz,id,by;
    const CloneMCJ_BlockDefinition *block;
    if(!world)return 0;
    minX=CloneMCJava_FloorDouble(x-(double)width*0.5);
    maxX=CloneMCJava_FloorDouble(x+(double)width*0.5);
    minZ=CloneMCJava_FloorDouble(z-(double)width*0.5);
    maxZ=CloneMCJava_FloorDouble(z+(double)width*0.5);
    by=CloneMCJava_FloorDouble(y)-1;
    for(bx=minX;bx<=maxX;++bx)for(bz=minZ;bz<=maxZ;++bz){
        id=CloneMCJ_World_GetBlockId(world,bx,by,bz);
        block=CloneMCJ_BlockRegistry_Get(id);
        if(!block||!block->solid)return 0;
    }
    return 1;
}

static void CloneMCJ_EntityLiving_UpdateEnvironment(CloneMCJ_Mob *mob)
{
    CloneMCJ_Entity *entity;
    CloneMCJ_World *world;
    const CloneMCJ_BlockDefinition *inside;
    int x,y,z,immuneToFire,breathesWater;
    if(!mob||!mob->active||mob->health<=0)return;
    entity=&mob->entity;world=entity->worldObj;if(!world)return;
    entity->inWater=(unsigned char)CloneMCJ_Entity_IsInsideMaterial(entity,CLONEMC_J_MATERIAL_WATER);
    entity->inLava=(unsigned char)CloneMCJ_Entity_IsInsideMaterial(entity,CLONEMC_J_MATERIAL_LAVA);
    mob->inWater=entity->inWater;
    immuneToFire=mob->type==CLONEMC_J_MOB_GHAST||
        mob->type==CLONEMC_J_MOB_PIG_ZOMBIE||
        mob->type==CLONEMC_J_MOB_BLAZE||
        mob->type==CLONEMC_J_MOB_MAGMA_CUBE||
        mob->type==CLONEMC_J_MOB_ENDER_DRAGON||
        mob->type==CLONEMC_J_MOB_ENDER_CRYSTAL;
    breathesWater=mob->type==CLONEMC_J_MOB_SQUID;
    x=CloneMCJava_FloorDouble(entity->posX);
    y=CloneMCJava_FloorDouble(entity->posY+(double)entity->height*0.85);
    z=CloneMCJava_FloorDouble(entity->posZ);
    inside=CloneMCJ_BlockRegistry_Get(CloneMCJ_World_GetBlockId(world,x,y,z));
    if(!entity->noClip&&inside&&inside->solid&&((entity->ticksExisted&3)==0))
        CloneMCJ_EntityLiving_AttackMobFrom(mob,(const CloneMCJ_Entity *)0,1);
    if(entity->inWater){entity->fallDistance=0.0F;entity->fire=0;}
    if(!entity->noClip&&inside&&inside->material==
       CLONEMC_J_MATERIAL_WATER&&!breathesWater){
        --entity->air;if(entity->air<=-20){entity->air=0;
            CloneMCJ_EntityLiving_AttackMobFrom(mob,(const CloneMCJ_Entity *)0,2);}
    }else entity->air=300;
    if(!immuneToFire&&entity->fire>0){
        if((entity->fire%20)==0)CloneMCJ_EntityLiving_AttackMobFrom(mob,(const CloneMCJ_Entity *)0,1);
        --entity->fire;
    }else if(immuneToFire)entity->fire=0;
    if(entity->inLava&&!immuneToFire){
        if((entity->ticksExisted%10)==0)CloneMCJ_EntityLiving_AttackMobFrom(mob,(const CloneMCJ_Entity *)0,4);
        entity->fire=600;
    }
    if(entity->posY<-64.0){mob->health=0;mob->deathTime=1;}
}

void CloneMCJ_EntityLiving_InitializeMob(CloneMCJ_Mob *mob,CloneMCJ_MobType type,
    CloneMCJ_World *world,double x,double y,double z)
{
    if(!mob)return;
    memset(mob,0,sizeof(*mob));CloneMCJ_Entity_Initialize(&mob->entity,world);
    mob->type=type;mob->active=1;mob->moveSpeed=0.7F;mob->attackStrength=2;
    mob->renderScale=1.0F;
    mob->fuseTime=30;mob->creeperState=-1;mob->slimeSize=1;
    mob->pathAvoidsWater=1;mob->pathAvoidsSun=0;
    CloneMCJ_EntityLiving_SetMobSize(mob,0.6F,1.8F);
    switch(type){
    case CLONEMC_J_MOB_PIG:mob->moveSpeed=0.7F;CloneMCJ_EntityLiving_SetMobSize(mob,0.9F,0.9F);break;
    case CLONEMC_J_MOB_SHEEP:mob->woolColor=CloneMCJ_EntitySheep_RandomFleeceColor(&mob->entity.rand);CloneMCJ_EntityLiving_SetMobSize(mob,0.9F,1.3F);break;
    case CLONEMC_J_MOB_COW:CloneMCJ_EntityLiving_SetMobSize(mob,0.9F,1.3F);break;
    case CLONEMC_J_MOB_CHICKEN:mob->specialTimer=6000+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,6000);CloneMCJ_EntityLiving_SetMobSize(mob,0.3F,0.4F);break;
    case CLONEMC_J_MOB_ZOMBIE:mob->attackStrength=5;mob->moveSpeed=0.5F;mob->hostile=1;mob->daylightBurns=1;mob->pathAvoidsSun=1;break;
    case CLONEMC_J_MOB_GIANT:mob->attackStrength=50;mob->moveSpeed=0.5F;mob->hostile=1;CloneMCJ_EntityLiving_SetMobSize(mob,3.6F,10.8F);break;
    case CLONEMC_J_MOB_GHAST:mob->attackStrength=6;mob->hostile=1;mob->moveSpeed=0.0F;mob->waypointX=x;mob->waypointY=y;mob->waypointZ=z;CloneMCJ_EntityLiving_SetMobSize(mob,4.0F,4.0F);break;
    case CLONEMC_J_MOB_PIG_ZOMBIE:mob->attackStrength=5;mob->moveSpeed=0.5F;break;
    case CLONEMC_J_MOB_SKELETON:mob->hostile=1;mob->daylightBurns=1;mob->pathAvoidsSun=1;break;
    case CLONEMC_J_MOB_CREEPER:mob->hostile=1;break;
    case CLONEMC_J_MOB_SPIDER:mob->moveSpeed=0.8F;mob->hostile=1;CloneMCJ_EntityLiving_SetMobSize(mob,1.4F,0.9F);break;
    case CLONEMC_J_MOB_SLIME:
        mob->slimeSize=1<<CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        mob->attackStrength=mob->slimeSize;mob->hostile=1;
        mob->slimeJumpDelay=10+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,20);
        CloneMCJ_EntityLiving_SetMobSize(mob,0.6F*(float)mob->slimeSize,0.6F*(float)mob->slimeSize);break;
    case CLONEMC_J_MOB_WOLF:mob->attackStrength=2;mob->moveSpeed=1.1F;CloneMCJ_EntityLiving_SetMobSize(mob,0.8F,0.8F);break;
    case CLONEMC_J_MOB_SQUID:
        mob->inWater=1;mob->pathAvoidsWater=0;
        mob->squidPhaseVelocity=(1.0F/(CloneMCJavaRandom_NextFloat(
            &mob->entity.rand)+1.0F))*0.2F;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.95F,0.95F);break;
    case CLONEMC_J_MOB_ENDERMAN:
        mob->attackStrength=7;mob->moveSpeed=0.3F;mob->hostile=0;
        mob->entity.stepHeight=1.0F;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.6F,2.9F);break;
    case CLONEMC_J_MOB_BLAZE:
        mob->attackStrength=6;mob->moveSpeed=0.5F;mob->hostile=1;
        mob->blazeHeightOffset=0.5F;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.6F,1.8F);break;
    case CLONEMC_J_MOB_MAGMA_CUBE:
        mob->slimeSize=1<<CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        mob->attackStrength=mob->slimeSize+2;mob->hostile=1;
        mob->slimeJumpDelay=10+CloneMCJavaRandom_NextIntBound(
            &mob->entity.rand,20);
        CloneMCJ_EntityLiving_SetMobSize(mob,0.6F*(float)mob->slimeSize,
            0.6F*(float)mob->slimeSize);break;
    case CLONEMC_J_MOB_ENDER_DRAGON:
        mob->attackStrength=10;mob->hostile=1;mob->persistenceRequired=1;
        mob->moveSpeed=1.0F;mob->waypointX=x;mob->waypointY=100.0;
        mob->waypointZ=z;mob->entity.noClip=1;
        CloneMCJ_EntityLiving_SetMobSize(mob,16.0F,8.0F);break;
    case CLONEMC_J_MOB_ENDER_CRYSTAL:
        mob->moveSpeed=0.0F;mob->persistenceRequired=1;
        mob->entity.noClip=1;
        CloneMCJ_EntityLiving_SetMobSize(mob,2.0F,2.0F);break;
    case CLONEMC_J_MOB_VILLAGER:
        mob->moveSpeed=0.5F;mob->persistenceRequired=1;
        mob->profession=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,5);
        CloneMCJ_EntityLiving_SetMobSize(mob,0.6F,1.8F);break;
    case CLONEMC_J_MOB_CAVE_SPIDER:
        mob->moveSpeed=0.8F;mob->attackStrength=2;mob->hostile=1;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.7F,0.5F);break;
    case CLONEMC_J_MOB_SILVERFISH:
        mob->moveSpeed=0.6F;mob->attackStrength=1;mob->hostile=1;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.3F,0.7F);break;
    case CLONEMC_J_MOB_MOOSHROOM:
        mob->moveSpeed=0.7F;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.9F,1.3F);break;
    case CLONEMC_J_MOB_SNOWMAN:
        mob->moveSpeed=0.5F;mob->persistenceRequired=1;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.4F,1.8F);break;
    case CLONEMC_J_MOB_OCELOT:
        mob->moveSpeed=0.23F;mob->attackStrength=3;
        CloneMCJ_EntityLiving_SetMobSize(mob,0.6F,0.8F);break;
    case CLONEMC_J_MOB_IRON_GOLEM:
        mob->moveSpeed=0.25F;mob->attackStrength=7;mob->persistenceRequired=1;
        CloneMCJ_EntityLiving_SetMobSize(mob,1.4F,2.9F);break;
    default:break;
    }
    mob->maxHealth=CloneMCJ_EntityLiving_GetMaxHealth(type,mob->slimeSize);
    mob->health=mob->maxHealth;mob->prevHealth=mob->health;
    mob->entity.rotationYaw=CloneMCJavaRandom_NextFloat(&mob->entity.rand)*360.0F;
    mob->entity.prevRotationYaw=mob->entity.rotationYaw;
    CloneMCJ_Entity_SetPosition(&mob->entity,x,y,z);
    mob->lastProgressX=x;mob->lastProgressY=y;mob->lastProgressZ=z;
    mob->lastTargetX=x;mob->lastTargetY=y;mob->lastTargetZ=z;
}

void CloneMCJ_EntityLiving_StartSwing(CloneMCJ_Mob *mob)
{
    if(!mob)return;
    mob->swingProgressInt=-1;
    mob->isSwinging=1;
}

int CloneMCJ_EntityLiving_AttackMob(CloneMCJ_Mob *mob,int damage)
{
    return CloneMCJ_EntityLiving_AttackMobFrom(mob,(const CloneMCJ_Entity *)0,damage);
}

void CloneMCJ_EntityLiving_AngerPigZombie(CloneMCJ_Mob *pigZombie)
{
    if(!pigZombie||pigZombie->type!=CLONEMC_J_MOB_PIG_ZOMBIE)return;
    pigZombie->angerLevel=400+CloneMCJavaRandom_NextIntBound(&pigZombie->entity.rand,400);
    pigZombie->angry=1;pigZombie->hostile=1;pigZombie->targetMemoryTicks=200;
}

int CloneMCJ_EntityLiving_AttackMobFrom(CloneMCJ_Mob *mob,
    const CloneMCJ_Entity *source,int damage)
{
    double dx,dz,length;
    int armor,reduced;
    if(!mob||!mob->active||damage<=0||mob->health<=0)return 0;
    if(mob->entity.worldObj&&mob->entity.worldObj->multiplayerWorld)return 0;
    /* EntityMagmaCube.getTotalArmorValue returns size*3.  Environmental
     * sources in this port pass a null attacker and correspond to Java's
     * unblockable drown/fall/void paths; direct and projectile attacks use
     * the normal EntityLiving 25-point armor carryover formula. */
    if(mob->type==CLONEMC_J_MOB_MAGMA_CUBE&&source){
        armor=mob->slimeSize*3;if(armor>20)armor=20;
        reduced=damage*(25-armor)+mob->magmaArmorCarryover;
        damage=reduced/25;mob->magmaArmorCarryover=reduced%25;
        if(damage<=0){mob->recentlyHit=60;return 1;}
    }
    mob->entityAge=0;
    if(mob->hurtResistantTime>10){if(damage<=mob->lastDamage)return 0;damage-=mob->lastDamage;}
    else{mob->lastDamage=damage;mob->hurtResistantTime=20;mob->maxHurtTime=mob->hurtTime=10;}
    mob->prevHealth=mob->health;mob->health-=damage;mob->recentlyHit=60;
    if(source){
        mob->lastAttackerEntityId=source->entityId;mob->targetEntityId=source->entityId;
        mob->targetMemoryTicks=100;mob->targetAcquired=1;mob->sitting=0;
        if(mob->type==CLONEMC_J_MOB_WOLF&&!mob->tamed){mob->angry=1;mob->hostile=1;}
        if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE)CloneMCJ_EntityLiving_AngerPigZombie(mob);
        dx=mob->entity.posX-source->posX;dz=mob->entity.posZ-source->posZ;length=sqrt(dx*dx+dz*dz);
        if(length<0.0001){dx=0.01;dz=0.01;length=0.0141421356;}
        mob->entity.motionX+=dx/length*0.4;mob->entity.motionZ+=dz/length*0.4;
        mob->entity.motionY+=0.4;if(mob->entity.motionY>0.4)mob->entity.motionY=0.4;
    }
    if(mob->health<=0){mob->health=0;mob->deathTime=1;mob->hasPath=0;mob->targetAcquired=0;}
    return 1;
}

static double CloneMCJ_EntityLiving_ExplosionExposure(const CloneMCJ_Entity *source,
    const CloneMCJ_Entity *target)
{
    int visible,total,ix,iy,iz;
    CloneMCJ_Entity sample;
    if(!source||!target)return 0.0;
    visible=0;total=0;sample=*target;
    for(ix=0;ix<2;++ix)for(iy=0;iy<3;++iy)for(iz=0;iz<2;++iz){
        sample.posX=target->boundingBox.minX+(target->boundingBox.maxX-target->boundingBox.minX)*(0.2+0.6*(double)ix);
        sample.posY=target->boundingBox.minY+(target->boundingBox.maxY-target->boundingBox.minY)*(0.1+0.4*(double)iy);
        sample.posZ=target->boundingBox.minZ+(target->boundingBox.maxZ-target->boundingBox.minZ)*(0.2+0.6*(double)iz);
        if(CloneMCJ_EntityLiving_CanSeeEntity(source,&sample))++visible;
        ++total;
    }
    return total?((double)visible/(double)total):0.0;
}

static void CloneMCJ_EntityLiving_CreeperExplosion(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player)
{
    float radius;(void)player;if(!mob||!mob->entity.worldObj)return;
    radius=mob->angry?6.0F:3.0F;
    CloneMCJ_Explosion_Execute(mob->entity.worldObj,&mob->entity,mob->entity.posX,
        mob->entity.posY+0.5,mob->entity.posZ,radius,0);
    mob->health=0;mob->deathTime=1;mob->active=0;mob->hasPath=0;mob->lootDropped=1;
}

float CloneMCJ_EntityLiving_GetCreeperFlash(const CloneMCJ_Mob *mob,float partial)
{
    float value;
    if(!mob||mob->type!=CLONEMC_J_MOB_CREEPER)return 0.0F;
    value=((float)mob->lastActiveTime+(float)(mob->timeSinceIgnited-mob->lastActiveTime)*partial)/28.0F;
    if(value<0.0F)value=0.0F;
    if(value>1.0F)value=1.0F;
    return value;
}

static int CloneMCJ_EntityLiving_TargetRange(const CloneMCJ_Mob *mob)
{
    if(!mob)return 0;
    if(mob->type==CLONEMC_J_MOB_GHAST)return 64;
    if(mob->type==CLONEMC_J_MOB_ENDERMAN)return 64;
    if(mob->type==CLONEMC_J_MOB_WOLF&&mob->tamed)return 32;
    return 16;
}

static void CloneMCJ_EntityLiving_UpdateTarget(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player,double distanceSquared)
{
    int range,hostile,visible;
    if(!mob||!player)return;
    range=CloneMCJ_EntityLiving_TargetRange(mob);
    hostile=CloneMCJ_EntityLiving_IsHostileNow(mob);
    if(mob->type==CLONEMC_J_MOB_WOLF&&mob->tamed){
        if(mob->sitting){mob->targetAcquired=0;mob->targetEntityId=0;mob->canSeeTarget=0;return;}
        if(mob->combatTarget&&mob->combatTarget->active&&mob->combatTarget->health>0){
            double targetDistance;
            targetDistance=CloneMCJ_EntityLiving_DistanceSquared(&mob->entity,
                &mob->combatTarget->entity);
            mob->targetAcquired=(unsigned char)(targetDistance<(double)(range*range));
            mob->targetEntityId=mob->combatTarget->entity.entityId;
            mob->canSeeTarget=(unsigned char)CloneMCJ_EntityLiving_CanSeeEntity(
                &mob->entity,&mob->combatTarget->entity);
        }else{
            mob->combatTarget=(CloneMCJ_Mob *)0;
            mob->targetAcquired=(unsigned char)(distanceSquared<(double)(range*range));
            mob->targetEntityId=player->entity.entityId;mob->canSeeTarget=1;
        }
        return;
    }
    if(!hostile){mob->targetAcquired=0;mob->targetEntityId=0;mob->targetMemoryTicks=0;return;}
    visible=distanceSquared<(double)(range*range)&&
        CloneMCJ_EntityLiving_CanSeeEntity(&mob->entity,&player->entity);
    mob->canSeeTarget=(unsigned char)visible;
    if(visible){
        mob->targetAcquired=1;mob->targetEntityId=player->entity.entityId;
        mob->targetMemoryTicks=60;mob->targetUnseenTicks=0;
    }else if(mob->targetAcquired){
        ++mob->targetUnseenTicks;if(mob->targetMemoryTicks>0)--mob->targetMemoryTicks;
        if(distanceSquared>(double)(range*range*4)||mob->targetMemoryTicks<=0){
            mob->targetAcquired=0;mob->targetEntityId=0;mob->hasPath=0;
        }
    }
    if(mob->type==CLONEMC_J_MOB_SPIDER&&mob->targetAcquired&&!mob->canSeeTarget&&
        CloneMCJavaRandom_NextIntBound(&mob->entity.rand,100)==0){
        mob->targetAcquired=0;mob->targetEntityId=0;mob->hasPath=0;
    }
}

static int CloneMCJ_EntityLiving_SelectWanderPoint(CloneMCJ_Mob *mob)
{
    CloneMCJ_World *world;
    int attempt,x,y,z,bestX,bestY,bestZ,id;
    float score,bestScore;
    const CloneMCJ_BlockDefinition *below;
    world=mob->entity.worldObj;if(!world)return 0;
    bestScore=-99999.0F;bestX=bestY=bestZ=0;
    for(attempt=0;attempt<10;++attempt){
        x=CloneMCJava_FloorDouble(mob->entity.posX)+(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,13)-6);
        y=CloneMCJava_FloorDouble(mob->entity.posY)+(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,7)-3);
        z=CloneMCJava_FloorDouble(mob->entity.posZ)+(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,13)-6);
        if(y<1||y>=CLONEMC_J_CHUNK_HEIGHT-2)continue;
        id=CloneMCJ_World_GetBlockId(world,x,y-1,z);below=CloneMCJ_BlockRegistry_Get(id);
        if(!below||!below->solid||!CloneMCJ_EntityLiving_CanOccupy(world,(double)x+0.5,(double)y,
            (double)z+0.5,mob->entity.width,mob->entity.height))continue;
        score=(float)CloneMCJavaRandom_NextIntBound(&mob->entity.rand,1000)/1000.0F;
        if(CloneMCJ_EntityLiving_IsHostileType(mob->type))
            score+=(15.0F-(float)CloneMCJ_World_GetFullBlockLightValue(world,x,y,z))*0.1F;
        if(mob->pathAvoidsSun&&CloneMCJ_World_CanExistingBlockSeeTheSky(world,x,y,z))score-=3.0F;
        if(score>bestScore){bestScore=score;bestX=x;bestY=y;bestZ=z;}
    }
    if(bestScore<=-99998.0F)return 0;
    mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePathEx(world,&mob->entity,
        (double)bestX+0.5,(double)bestY,(double)bestZ+0.5,10.0F,
        mob->pathAvoidsWater,mob->pathAvoidsSun,&mob->path);
    mob->pathAge=0;return mob->hasPath;
}

static void CloneMCJ_EntityLiving_UpdatePath(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player,double distanceSquared)
{
    CloneMCJ_World *world;
    double movedTarget;
    int needPath;
    world=mob->entity.worldObj;if(!world)return;
    if(mob->pathRecalcDelay>0)--mob->pathRecalcDelay;
    if(mob->hasPath&&++mob->pathAge>200){mob->hasPath=0;mob->pathAge=0;}
    if(mob->targetAcquired&&player){
        const CloneMCJ_Entity *pathTarget;
        pathTarget=(mob->combatTarget&&mob->combatTarget->active)?
            &mob->combatTarget->entity:&player->entity;
        movedTarget=(pathTarget->posX-mob->lastTargetX)*(pathTarget->posX-mob->lastTargetX)+
            (pathTarget->posY-mob->lastTargetY)*(pathTarget->posY-mob->lastTargetY)+
            (pathTarget->posZ-mob->lastTargetZ)*(pathTarget->posZ-mob->lastTargetZ);
        needPath=!mob->hasPath||movedTarget>4.0||mob->pathRecalcDelay<=0;
        if(needPath&&distanceSquared<1024.0){
            mob->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePathEx(world,&mob->entity,
                pathTarget->posX,pathTarget->boundingBox.minY,pathTarget->posZ,
                mob->type==CLONEMC_J_MOB_WOLF?32.0F:16.0F,
                mob->pathAvoidsWater,mob->pathAvoidsSun,&mob->path);
            if(mob->hasPath){mob->pathFailureCount=0;mob->pathAge=0;}
            else if(mob->pathFailureCount<1000)++mob->pathFailureCount;
            mob->pathRecalcDelay=10+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,20)+
                (mob->pathFailureCount>3?20:0);
            mob->lastTargetX=pathTarget->posX;mob->lastTargetY=pathTarget->posY;
            mob->lastTargetZ=pathTarget->posZ;
        }
    }else if(!mob->hasPath&&mob->pathRecalcDelay<=0&&
        CloneMCJavaRandom_NextIntBound(&mob->entity.rand,80)==0){
        CloneMCJ_EntityLiving_SelectWanderPoint(mob);
        mob->pathRecalcDelay=20+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,40);
    }
}

static int CloneMCJ_EntityLiving_FollowPath(CloneMCJ_Mob *mob,double *directionX,
    double *directionZ)
{
    CloneMCVec3D point;
    double dx,dz,reach;
    if(!mob||!mob->hasPath)return 0;
    while(CloneMCJ_PathEntity_GetPosition(&mob->path,&mob->entity,&point)){
        dx=point.xCoord-mob->entity.posX;dz=point.zCoord-mob->entity.posZ;
        reach=(double)mob->entity.width*2.0;
        if(dx*dx+dz*dz>=reach*reach)break;
        CloneMCJ_PathEntity_Increment(&mob->path);
    }
    if(!CloneMCJ_PathEntity_GetPosition(&mob->path,&mob->entity,&point)){
        mob->hasPath=0;return 0;
    }
    *directionX=point.xCoord-mob->entity.posX;*directionZ=point.zCoord-mob->entity.posZ;
    mob->jumping=(unsigned char)(point.yCoord>
        (double)CloneMCJava_FloorDouble(mob->entity.boundingBox.minY+0.5));
    return 1;
}

static void CloneMCJ_EntityLiving_UpdateStuckState(CloneMCJ_Mob *mob)
{
    double dx,dy,dz,moved;
    if(!mob)return;
    dx=mob->entity.posX-mob->lastProgressX;dy=mob->entity.posY-mob->lastProgressY;
    dz=mob->entity.posZ-mob->lastProgressZ;moved=dx*dx+dy*dy+dz*dz;
    if(mob->hasPath&&mob->moveForward>0.01F&&moved<0.0025)++mob->stuckTicks;
    else mob->stuckTicks=0;
    if(moved>0.25||mob->stuckTicks==0){
        mob->lastProgressX=mob->entity.posX;mob->lastProgressY=mob->entity.posY;
        mob->lastProgressZ=mob->entity.posZ;
    }
    if(mob->stuckTicks>40){
        mob->hasPath=0;mob->pathRecalcDelay=0;mob->stuckTicks=0;
        mob->randomYawVelocity=(CloneMCJavaRandom_NextFloat(&mob->entity.rand)-0.5F)*120.0F;
    }
}

static void CloneMCJ_EntityLiving_UpdateDaylight(CloneMCJ_Mob *mob)
{
    CloneMCJ_World *world;
    int x,y,z,light;
    float brightness;
    if(!mob||!mob->daylightBurns)return;
    world=mob->entity.worldObj;if(!world||world->skylightSubtracted>=4)return;
    x=CloneMCJava_FloorDouble(mob->entity.posX);
    y=CloneMCJava_FloorDouble(mob->entity.posY);
    z=CloneMCJava_FloorDouble(mob->entity.posZ);
    light=CloneMCJ_World_GetBlockLightValue(world,x,y,z);brightness=(float)light/15.0F;
    if(brightness>0.5F&&CloneMCJ_World_CanExistingBlockSeeTheSky(world,x,y,z)&&
        CloneMCJavaRandom_NextFloat(&mob->entity.rand)*30.0F<(brightness-0.4F)*2.0F)
        mob->entity.fire=300;
}

static void CloneMCJ_EntityLiving_UpdateGhast(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player,double distanceSquared)
{
    CloneMCJ_Entity *entity;
    double dx,dy,dz,distance;
    int canMove;
    entity=&mob->entity;mob->prevAttackCounter=mob->attackCounter;
    dx=mob->waypointX-entity->posX;dy=mob->waypointY-entity->posY;dz=mob->waypointZ-entity->posZ;
    distance=sqrt(dx*dx+dy*dy+dz*dz);
    if(distance<1.0||distance>60.0){
        mob->waypointX=entity->posX+(CloneMCJavaRandom_NextFloat(&entity->rand)*2.0F-1.0F)*16.0F;
        mob->waypointY=entity->posY+(CloneMCJavaRandom_NextFloat(&entity->rand)*2.0F-1.0F)*16.0F;
        mob->waypointZ=entity->posZ+(CloneMCJavaRandom_NextFloat(&entity->rand)*2.0F-1.0F)*16.0F;
        dx=mob->waypointX-entity->posX;dy=mob->waypointY-entity->posY;dz=mob->waypointZ-entity->posZ;
        distance=sqrt(dx*dx+dy*dy+dz*dz);
    }
    if(mob->courseChangeCooldown--<=0){
        mob->courseChangeCooldown=2+CloneMCJavaRandom_NextIntBound(&entity->rand,5);
        canMove=CloneMCJ_EntityLiving_CanOccupy(entity->worldObj,
            entity->posX+(distance>0.001?dx/distance*2.0:0.0),
            entity->posY+(distance>0.001?dy/distance*2.0:0.0),
            entity->posZ+(distance>0.001?dz/distance*2.0:0.0),entity->width,entity->height);
        if(canMove&&distance>0.001){entity->motionX+=dx/distance*0.1;
            entity->motionY+=dy/distance*0.1;entity->motionZ+=dz/distance*0.1;}
        else{mob->waypointX=entity->posX;mob->waypointY=entity->posY;mob->waypointZ=entity->posZ;}
    }
    if(player&&distanceSquared<4096.0&&CloneMCJ_EntityLiving_CanSeeEntity(entity,&player->entity)){
        dx=player->entity.posX-entity->posX;dz=player->entity.posZ-entity->posZ;
        entity->rotationYaw=(float)(-atan2(dx,dz)*180.0/CLONEMC_J_PI);
        if(mob->attackCounter<20)++mob->attackCounter;
        if(mob->attackCounter==20){mob->attackTime=40;mob->rangedAttackPending=1;mob->attackCounter=-40;}
    }else if(mob->attackCounter>0)--mob->attackCounter;
    else if(mob->attackCounter<0)++mob->attackCounter;
    CloneMCJ_Entity_Move(entity,entity->motionX,entity->motionY,entity->motionZ);
    entity->motionX*=0.91;entity->motionY*=0.91;entity->motionZ*=0.91;
    mob->renderYawOffset=entity->rotationYaw;
}

static void CloneMCJ_EntityLiving_UpdateSquid(CloneMCJ_Mob *mob)
{
    CloneMCJ_Entity *entity;
    float phaseFraction,horizontalSpeed,desiredYaw,desiredPitch,randomAngle;
    if(!mob)return;
    entity=&mob->entity;
    mob->prevSquidPitch=mob->squidPitch;
    mob->prevSquidBodyYaw=mob->squidBodyYaw;
    mob->prevSquidPhase=mob->squidPhase;
    mob->prevSquidTentacleAngle=mob->squidTentacleAngle;
    mob->squidPhase+=mob->squidPhaseVelocity;
    if(mob->squidPhase>6.283185F){
        mob->squidPhase-=6.283185F;
        if(CloneMCJavaRandom_NextIntBound(&entity->rand,10)==0)
            mob->squidPhaseVelocity=(1.0F/
                (CloneMCJavaRandom_NextFloat(&entity->rand)+1.0F))*0.2F;
    }
    if(CloneMCJavaRandom_NextIntBound(&entity->rand,50)==0||
       !entity->inWater||
       (mob->squidRandomMotionX==0.0F&&mob->squidRandomMotionY==0.0F&&
        mob->squidRandomMotionZ==0.0F)){
        randomAngle=CloneMCJavaRandom_NextFloat(&entity->rand)*6.283186F;
        mob->squidRandomMotionX=(float)cos((double)randomAngle)*0.2F;
        mob->squidRandomMotionY=-0.1F+
            CloneMCJavaRandom_NextFloat(&entity->rand)*0.2F;
        mob->squidRandomMotionZ=(float)sin((double)randomAngle)*0.2F;
    }
    if(entity->inWater){
        if(mob->squidPhase<3.141593F){
            phaseFraction=mob->squidPhase/3.141593F;
            mob->squidTentacleAngle=(float)sin((double)
                (phaseFraction*phaseFraction*3.141593F))*3.141593F*0.25F;
            if(phaseFraction>0.75F){
                mob->squidRandomMotionSpeed=1.0F;
                mob->squidTentacleSpeed=1.0F;
            }else mob->squidTentacleSpeed*=0.8F;
        }else{
            mob->squidTentacleAngle=0.0F;
            mob->squidRandomMotionSpeed*=0.9F;
            mob->squidTentacleSpeed*=0.99F;
        }
        entity->motionX=(double)mob->squidRandomMotionX*
            (double)mob->squidRandomMotionSpeed;
        entity->motionY=(double)mob->squidRandomMotionY*
            (double)mob->squidRandomMotionSpeed;
        entity->motionZ=(double)mob->squidRandomMotionZ*
            (double)mob->squidRandomMotionSpeed;
        horizontalSpeed=(float)sqrt(entity->motionX*entity->motionX+
            entity->motionZ*entity->motionZ);
        desiredYaw=(float)(-atan2(entity->motionX,entity->motionZ)*
            180.0/CLONEMC_J_PI);
        mob->renderYawOffset+=(desiredYaw-mob->renderYawOffset)*0.1F;
        entity->rotationYaw=mob->renderYawOffset;
        mob->squidBodyYaw+=3.141593F*mob->squidTentacleSpeed*1.5F;
        desiredPitch=(float)(-atan2((double)horizontalSpeed,entity->motionY)*
            180.0/CLONEMC_J_PI);
        mob->squidPitch+=(desiredPitch-mob->squidPitch)*0.1F;
    }else{
        mob->squidTentacleAngle=(float)fabs(sin((double)mob->squidPhase))*
            3.141593F*0.25F;
        entity->motionX=0.0;entity->motionY-=0.08;
        entity->motionY*=0.98000001907348633;entity->motionZ=0.0;
        mob->squidPitch+=(-90.0F-mob->squidPitch)*0.02F;
    }
    CloneMCJ_Entity_Move(entity,entity->motionX,entity->motionY,entity->motionZ);
    mob->limbSwingAmount=0.0F;
}

static int CloneMCJ_EntityLiving_PlayerStaresAtEnderman(
    const CloneMCJ_Mob *mob,const CloneMCJ_EntityPlayer *player)
{
    double yaw,pitch,lookX,lookY,lookZ,toX,toY,toZ,distance,dot;
    const CloneMCJ_ItemStack *helmet;
    if(!mob||!player)return 0;
    /* EntityEnderman.shouldAttackPlayer explicitly exempts a pumpkin worn in
     * the helmet slot.  Earlier native builds checked only the view vector,
     * which made the Java disguise mechanic impossible. */
    helmet=&player->inventory.armorInventory[3];
    if(!CloneMCJ_ItemStack_IsEmpty(helmet)&&helmet->itemID==86)return 0;
    toX=mob->entity.posX-player->entity.posX;
    toY=mob->entity.posY+(double)mob->entity.height*0.5-
        (player->entity.posY+1.62);
    toZ=mob->entity.posZ-player->entity.posZ;
    distance=sqrt(toX*toX+toY*toY+toZ*toZ);
    if(distance<0.001||distance>64.0)return 0;
    toX/=distance;toY/=distance;toZ/=distance;
    yaw=(double)player->entity.rotationYaw*CLONEMC_J_DEG_TO_RAD;
    pitch=(double)player->entity.rotationPitch*CLONEMC_J_DEG_TO_RAD;
    lookX=-sin(yaw)*cos(pitch);lookY=-sin(pitch);
    lookZ=cos(yaw)*cos(pitch);
    dot=lookX*toX+lookY*toY+lookZ*toZ;
    /* EntityEnderman.shouldAttackPlayer uses
     * dot > 1 - 0.025 / distance plus visibility. */
    return dot>1.0-0.025/distance&&CloneMCJ_EntityLiving_CanSeeEntity(
        &player->entity,&mob->entity);
}

static int CloneMCJ_EntityEnderman_CanCarryBlock(int blockID)
{
    /* Exact EntityEnderman.java static canCarryBlocks[] set for 1.2.3. */
    switch(blockID){
    case 2:case 3:case 12:case 13:case 37:case 38:case 39:case 40:
    case 46:case 81:case 82:case 86:case 103:case 110:return 1;
    default:return 0;
    }
}

static int CloneMCJ_EntityEnderman_AreaContainsLiquid(CloneMCJ_World *world,
    double x,double y,double z,float width,float height)
{
    int minX,maxX,minY,maxY,minZ,maxZ,bx,by,bz,id;
    const CloneMCJ_BlockDefinition *block;
    if(!world)return 1;
    minX=CloneMCJava_FloorDouble(x-(double)width*0.5);
    maxX=CloneMCJava_FloorDouble(x+(double)width*0.5);
    minY=CloneMCJava_FloorDouble(y);
    maxY=CloneMCJava_FloorDouble(y+(double)height-0.001);
    minZ=CloneMCJava_FloorDouble(z-(double)width*0.5);
    maxZ=CloneMCJava_FloorDouble(z+(double)width*0.5);
    for(bx=minX;bx<=maxX;++bx)for(by=minY;by<=maxY;++by)
        for(bz=minZ;bz<=maxZ;++bz){
            id=CloneMCJ_World_GetLoadedBlockId(world,bx,by,bz);
            block=CloneMCJ_BlockRegistry_Get(id);
            if(block&&(block->material==CLONEMC_J_MATERIAL_WATER||
                       block->material==CLONEMC_J_MATERIAL_LAVA))return 1;
        }
    return 0;
}

static int CloneMCJ_EntityEnderman_TeleportTo(CloneMCJ_Mob *mob,
    double x,double y,double z)
{
    CloneMCJ_Entity *entity;
    CloneMCJ_World *world;
    const CloneMCJ_BlockDefinition *floorBlock;
    double oldX,oldY,oldZ;
    int blockX,blockY,blockZ,floorID;
    if(!mob||mob->type!=CLONEMC_J_MOB_ENDERMAN)return 0;
    entity=&mob->entity;world=entity->worldObj;if(!world)return 0;
    blockX=CloneMCJava_FloorDouble(x);
    blockY=CloneMCJava_FloorDouble(y);
    blockZ=CloneMCJava_FloorDouble(z);
    if(blockY<1)blockY=1;
    if(blockY>=CLONEMC_J_CHUNK_HEIGHT)blockY=CLONEMC_J_CHUNK_HEIGHT-1;
    /* World.blockExists is a residency query in the Java method.  Admit a
     * destination only when it belongs to the active streaming horizon; do
     * not manufacture a remote island merely because a teleport rolled it. */
    if(!CloneMCJ_World_EnsureChunksExist(world,blockX-1,blockZ-1,
            blockX+1,blockZ+1,4,CLONEMC_J_CHUNK_REQUEST_ENTITY))return 0;
    while(blockY>0){
        floorID=CloneMCJ_World_GetLoadedBlockId(world,blockX,blockY-1,blockZ);
        floorBlock=CloneMCJ_BlockRegistry_Get(floorID);
        if(floorBlock&&floorBlock->solid)break;
        --blockY;
    }
    if(blockY<=0)return 0;
    oldX=entity->posX;oldY=entity->posY;oldZ=entity->posZ;
    x=(double)blockX+0.5;y=(double)blockY;z=(double)blockZ+0.5;
    if(!CloneMCJ_EntityLiving_CanOccupy(world,x,y,z,entity->width,
            entity->height)||
       CloneMCJ_EntityEnderman_AreaContainsLiquid(world,x,y,z,
            entity->width,entity->height))return 0;
    CloneMCJ_Entity_SetPosition(entity,x,y,z);
    entity->motionX=entity->motionY=entity->motionZ=0.0;
    /* EffectRenderer detects this discontinuity and emits the Java-style
     * portal trail without introducing a gameplay-to-render allocation. */
    mob->lastProgressX=oldX;mob->lastProgressY=oldY;mob->lastProgressZ=oldZ;
    mob->specialTimer=2;
    return 1;
}

int CloneMCJ_EntityEnderman_TeleportRandomly(CloneMCJ_Mob *mob)
{
    double x,y,z;
    if(!mob||mob->type!=CLONEMC_J_MOB_ENDERMAN)return 0;
    x=mob->entity.posX+(CloneMCJavaRandom_NextDouble(&mob->entity.rand)-0.5)*64.0;
    y=mob->entity.posY+(double)(CloneMCJavaRandom_NextIntBound(
        &mob->entity.rand,64)-32);
    z=mob->entity.posZ+(CloneMCJavaRandom_NextDouble(&mob->entity.rand)-0.5)*64.0;
    return CloneMCJ_EntityEnderman_TeleportTo(mob,x,y,z);
}

static int CloneMCJ_EntityEnderman_TeleportToPlayer(CloneMCJ_Mob *mob,
    const CloneMCJ_EntityPlayer *player)
{
    double vx,vy,vz,length,x,y,z;
    if(!mob||!player)return 0;
    vx=mob->entity.posX-player->entity.posX;
    vy=(mob->entity.boundingBox.minY+(double)mob->entity.height*0.5)-
        player->entity.posY+1.62;
    vz=mob->entity.posZ-player->entity.posZ;
    length=sqrt(vx*vx+vy*vy+vz*vz);if(length<0.001)return 0;
    vx/=length;vy/=length;vz/=length;
    x=mob->entity.posX+(CloneMCJavaRandom_NextDouble(&mob->entity.rand)-0.5)*8.0-
        vx*16.0;
    y=mob->entity.posY+(double)(CloneMCJavaRandom_NextIntBound(
        &mob->entity.rand,16)-8)-vy*16.0;
    z=mob->entity.posZ+(CloneMCJavaRandom_NextDouble(&mob->entity.rand)-0.5)*8.0-
        vz*16.0;
    return CloneMCJ_EntityEnderman_TeleportTo(mob,x,y,z);
}

static void CloneMCJ_EntityEnderman_UpdateCarriedBlock(CloneMCJ_Mob *mob)
{
    CloneMCJ_World *world;
    const CloneMCJ_BlockDefinition *floorBlock;
    int x,y,z,id,belowID,metadata;
    if(!mob||mob->type!=CLONEMC_J_MOB_ENDERMAN)return;
    world=mob->entity.worldObj;if(!world||world->multiplayerWorld)return;
    if(mob->carriedBlockId==0){
        if(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,20)!=0)return;
        x=CloneMCJava_FloorDouble((mob->entity.posX-2.0)+
            CloneMCJavaRandom_NextDouble(&mob->entity.rand)*4.0);
        y=CloneMCJava_FloorDouble(mob->entity.posY+
            CloneMCJavaRandom_NextDouble(&mob->entity.rand)*3.0);
        z=CloneMCJava_FloorDouble((mob->entity.posZ-2.0)+
            CloneMCJavaRandom_NextDouble(&mob->entity.rand)*4.0);
        id=CloneMCJ_World_GetLoadedBlockId(world,x,y,z);
        if(CloneMCJ_EntityEnderman_CanCarryBlock(id)){
            metadata=CloneMCJ_World_GetLoadedBlockMetadata(world,x,y,z);
            if(CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,0,0)){
                mob->carriedBlockId=id;mob->carriedBlockData=metadata;
            }
        }
    }else{
        if(CloneMCJavaRandom_NextIntBound(&mob->entity.rand,2000)!=0)return;
        x=CloneMCJava_FloorDouble((mob->entity.posX-1.0)+
            CloneMCJavaRandom_NextDouble(&mob->entity.rand)*2.0);
        y=CloneMCJava_FloorDouble(mob->entity.posY+
            CloneMCJavaRandom_NextDouble(&mob->entity.rand)*2.0);
        z=CloneMCJava_FloorDouble((mob->entity.posZ-1.0)+
            CloneMCJavaRandom_NextDouble(&mob->entity.rand)*2.0);
        id=CloneMCJ_World_GetLoadedBlockId(world,x,y,z);
        belowID=CloneMCJ_World_GetLoadedBlockId(world,x,y-1,z);
        floorBlock=CloneMCJ_BlockRegistry_Get(belowID);
        if(id==0&&floorBlock&&floorBlock->solid&&floorBlock->opaque&&
           CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,
                mob->carriedBlockId,mob->carriedBlockData)){
            mob->carriedBlockId=0;mob->carriedBlockData=0;
        }
    }
}

static void CloneMCJ_EntityLiving_UpdateDragon(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_Entity *entity;
    double dx,dy,dz,distance,horizontal,targetYaw,delta;
    if(!mob)return;
    entity=&mob->entity;
    dx=mob->waypointX-entity->posX;
    dy=mob->waypointY-entity->posY;
    dz=mob->waypointZ-entity->posZ;
    distance=dx*dx+dy*dy+dz*dz;
    if(distance<100.0||distance>22500.0||
       (entity->ticksExisted%200)==0){
        if(player&&CloneMCJavaRandom_NextIntBound(&entity->rand,2)==0){
            mob->waypointX=player->entity.posX;
            mob->waypointY=player->entity.posY+4.0;
            mob->waypointZ=player->entity.posZ;
        }else{
            mob->waypointX=(CloneMCJavaRandom_NextDouble(&entity->rand)*
                2.0-1.0)*60.0;
            mob->waypointY=70.0+
                CloneMCJavaRandom_NextDouble(&entity->rand)*50.0;
            mob->waypointZ=(CloneMCJavaRandom_NextDouble(&entity->rand)*
                2.0-1.0)*60.0;
        }
        dx=mob->waypointX-entity->posX;
        dy=mob->waypointY-entity->posY;
        dz=mob->waypointZ-entity->posZ;
    }
    horizontal=sqrt(dx*dx+dz*dz);if(horizontal<0.001)horizontal=0.001;
    dy/=horizontal;if(dy<-0.6)dy=-0.6;if(dy>0.6)dy=0.6;
    entity->motionY+=(dy*0.1);
    targetYaw=180.0-atan2(dx,dz)*180.0/CLONEMC_J_PI;
    delta=targetYaw-(double)entity->rotationYaw;
    while(delta<-180.0)delta+=360.0;while(delta>=180.0)delta-=360.0;
    if(delta>50.0)delta=50.0;if(delta<-50.0)delta=-50.0;
    mob->randomYawVelocity=mob->randomYawVelocity*0.8F+
        (float)(delta*0.7/(horizontal+1.0));
    entity->rotationYaw+=mob->randomYawVelocity*0.1F;
    entity->motionX+=-sin((double)entity->rotationYaw*
        CLONEMC_J_DEG_TO_RAD)*0.06;
    entity->motionZ+=cos((double)entity->rotationYaw*
        CLONEMC_J_DEG_TO_RAD)*0.06;
    CloneMCJ_Entity_Move(entity,entity->motionX,entity->motionY,
        entity->motionZ);
    entity->motionX*=0.91;entity->motionY*=0.91;entity->motionZ*=0.91;
    mob->renderYawOffset=entity->rotationYaw;
    if(player){
        dx=player->entity.posX-entity->posX;
        dy=player->entity.posY-entity->posY;
        dz=player->entity.posZ-entity->posZ;
        if(dx*dx+dy*dy+dz*dz<36.0&&mob->attackTime<=0){
            mob->attackTime=10;
            CloneMCJ_EntityPlayer_AttackFrom(player,entity,
                mob->attackStrength);
        }
    }
}

static void CloneMCJ_EntityLiving_HandleAttacks(CloneMCJ_Mob *mob,
    CloneMCJ_EntityPlayer *player,double dx,double dz,double distance,double distanceSquared)
{
    double verticalOverlap;
    int visible;
    if(!mob||!player||!mob->targetAcquired)return;
    visible=mob->canSeeTarget;verticalOverlap=player->entity.boundingBox.maxY-mob->entity.boundingBox.minY;
    if(mob->type==CLONEMC_J_MOB_WOLF&&mob->tamed){
        if(mob->combatTarget&&mob->combatTarget->active&&mob->combatTarget->health>0&&
            visible&&distance<2.0&&mob->attackTime<=0){
            mob->attackTime=20;CloneMCJ_EntityLiving_StartSwing(mob);
            CloneMCJ_EntityLiving_AttackMobFrom(mob->combatTarget,
                &mob->entity,mob->attackStrength);
        }
        return;
    }
    if(mob->type==CLONEMC_J_MOB_CREEPER){
        mob->lastActiveTime=mob->timeSinceIgnited;
        if(visible&&(distance<3.0||(mob->timeSinceIgnited>0&&distance<7.0))){
            mob->creeperState=1;if(mob->timeSinceIgnited<mob->fuseTime)++mob->timeSinceIgnited;
        }else{mob->creeperState=-1;if(mob->timeSinceIgnited>0)--mob->timeSinceIgnited;}
        if(mob->timeSinceIgnited>=mob->fuseTime)CloneMCJ_EntityLiving_CreeperExplosion(mob,player);
        return;
    }
    if(mob->type==CLONEMC_J_MOB_SKELETON){
        if(visible&&distance<10.0&&mob->attackTime<=0){
            mob->attackTime=30;mob->rangedAttackPending=1;
            CloneMCJ_EntityLiving_StartSwing(mob);
        }
        if(distance<6.0){mob->moveForward=0.0F;mob->moveStrafing=(float)(sin((double)mob->entity.ticksExisted*0.25)*0.5);}
        return;
    }
    if(mob->type==CLONEMC_J_MOB_BLAZE){
        /* EntityBlaze.attackEntity checks melee first.  The previous native
         * order started the 60-tick charge before testing melee range, which
         * made a nearby Blaze stand harmlessly in front of the player. */
        if(visible&&distance<2.0&&verticalOverlap>0.0&&mob->attackTime<=0){
            mob->attackTime=20;
            CloneMCJ_EntityPlayer_AttackFrom(player,&mob->entity,
                mob->attackStrength);
        }else if(visible&&distance<30.0&&mob->attackTime<=0){
            ++mob->attackCounter;
            if(mob->attackCounter==1){
                mob->attackTime=60;mob->blazeCharged=1;
            }else if(mob->attackCounter<=4){
                mob->attackTime=6;mob->rangedAttackPending=1;
            }else{
                mob->attackTime=100;mob->attackCounter=0;
                mob->blazeCharged=0;
            }
        }
        return;
    }
    if(mob->type==CLONEMC_J_MOB_SPIDER){
        if(visible&&distance>2.0&&distance<6.0&&mob->entity.onGround&&
            CloneMCJavaRandom_NextIntBound(&mob->entity.rand,10)==0){
            mob->entity.motionX=dx/(distance>0.001?distance:1.0)*0.4+mob->entity.motionX*0.2;
            mob->entity.motionZ=dz/(distance>0.001?distance:1.0)*0.4+mob->entity.motionZ*0.2;
            mob->entity.motionY=0.4;
        }
    }
    if(mob->type==CLONEMC_J_MOB_SLIME||
       mob->type==CLONEMC_J_MOB_MAGMA_CUBE){
        int canDamage;
        canDamage=mob->type==CLONEMC_J_MOB_MAGMA_CUBE||mob->slimeSize>1;
        if(canDamage&&visible&&distance<0.6*(double)mob->slimeSize&&
           mob->attackTime<=0){
            mob->attackTime=20;CloneMCJ_EntityLiving_StartSwing(mob);
            CloneMCJ_EntityPlayer_AttackFrom(player,&mob->entity,
                mob->type==CLONEMC_J_MOB_MAGMA_CUBE?
                mob->slimeSize+2:mob->slimeSize);
        }
        return;
    }
    if(visible&&distance<2.0&&verticalOverlap>0.0&&mob->attackTime<=0){
        mob->attackTime=20;CloneMCJ_EntityLiving_StartSwing(mob);
        CloneMCJ_EntityPlayer_AttackFrom(player,&mob->entity,mob->attackStrength);
    }
    (void)distanceSquared;
}

static void CloneMCJ_EntityLiving_ApplyMovement(CloneMCJ_Mob *mob)
{
    CloneMCJ_Entity *entity;
    CloneMCJ_World *world;
    const CloneMCJ_BlockDefinition *definition;
    int blockBelow,liquidMovement;
    double sinYaw,cosYaw;
    float landingDistance,groundFriction;
    entity=&mob->entity;world=entity->worldObj;
    /* EntityMagmaCube.handleLavaMovement() is explicitly false.  It is fire
     * immune but must use the ordinary land/gravity branch while intersecting
     * lava instead of acquiring the generic liquid buoyancy and drag. */
    liquidMovement=entity->inWater||
        (entity->inLava&&mob->type!=CLONEMC_J_MOB_MAGMA_CUBE);
    mob->wasOnGround=entity->onGround;
    {
        sinYaw=sin((double)entity->rotationYaw*CLONEMC_J_DEG_TO_RAD);
        cosYaw=cos((double)entity->rotationYaw*CLONEMC_J_DEG_TO_RAD);
        entity->motionX+=(-sinYaw*(double)mob->moveForward+cosYaw*(double)mob->moveStrafing)*0.08;
        entity->motionZ+=(cosYaw*(double)mob->moveForward+sinYaw*(double)mob->moveStrafing)*0.08;
    if(mob->type==CLONEMC_J_MOB_SLIME||
       mob->type==CLONEMC_J_MOB_MAGMA_CUBE){
            if(entity->onGround&&--mob->slimeJumpDelay<=0){
                mob->slimeJumpDelay=10+CloneMCJavaRandom_NextIntBound(&entity->rand,20);
                if(mob->type==CLONEMC_J_MOB_MAGMA_CUBE)
                    mob->slimeJumpDelay*=4;
                if(mob->targetAcquired)mob->slimeJumpDelay/=3;
                entity->motionY=mob->type==CLONEMC_J_MOB_MAGMA_CUBE?
                    0.42+(double)mob->slimeSize*0.1:0.42;
                mob->slimeSquishAmount=1.0F;
                /* EntitySlime assigns moveForward=size.  The native movement
                 * integrator applies its own 0.08 acceleration afterward. */
                mob->moveForward=(float)mob->slimeSize;
                mob->moveStrafing=1.0F-CloneMCJavaRandom_NextFloat(&entity->rand)*2.0F;
            }else if(entity->onGround){mob->moveForward=0.0F;mob->moveStrafing=0.0F;}
            mob->slimeSquishAmount*=mob->type==CLONEMC_J_MOB_MAGMA_CUBE?
                0.9F:0.6F;
        }else if(mob->jumping&&(entity->onGround||liquidMovement)){
            entity->motionY=liquidMovement?0.3:0.42;mob->jumping=0;
        }else if(!liquidMovement)entity->motionY-=0.08;
        else entity->motionY+=0.02;
        if(mob->type==CLONEMC_J_MOB_CHICKEN&&entity->motionY<0.0)entity->motionY*=0.6;
    }
    landingDistance=entity->fallDistance;if(entity->motionY<0.0)landingDistance-=(float)entity->motionY;
    if(liquidMovement)landingDistance=0.0F;
    CloneMCJ_Entity_Move(entity,entity->motionX,entity->motionY,entity->motionZ);
    if(entity->onGround&&!mob->wasOnGround&&
       (mob->type==CLONEMC_J_MOB_SLIME||
        mob->type==CLONEMC_J_MOB_MAGMA_CUBE))
        mob->slimeSquishAmount=-0.5F;
    if(entity->onGround&&landingDistance>3.0F&&
       mob->type!=CLONEMC_J_MOB_CHICKEN&&
       mob->type!=CLONEMC_J_MOB_MAGMA_CUBE&&
       mob->type!=CLONEMC_J_MOB_BLAZE)
        CloneMCJ_EntityLiving_AttackMobFrom(mob,(const CloneMCJ_Entity *)0,
            (int)ceil((double)landingDistance-3.0));
    if(mob->type==CLONEMC_J_MOB_SPIDER&&entity->collidedHorizontally)entity->motionY=0.2;
    if(entity->onGround&&entity->motionY<0.0)entity->motionY=0.0;
    entity->motionY*=liquidMovement?0.8:0.98;
    blockBelow=world?CloneMCJ_World_GetBlockId(world,CloneMCJava_FloorDouble(entity->posX),
        CloneMCJava_FloorDouble(entity->boundingBox.minY)-1,CloneMCJava_FloorDouble(entity->posZ)):0;
    definition=CloneMCJ_BlockRegistry_Get(blockBelow);
    groundFriction=entity->onGround&&definition?definition->slipperiness*0.91F:0.91F;
    entity->motionX*=groundFriction;entity->motionZ*=groundFriction;
    mob->limbSwingAmount=(float)sqrt((entity->posX-entity->prevPosX)*(entity->posX-entity->prevPosX)+
        (entity->posZ-entity->prevPosZ)*(entity->posZ-entity->prevPosZ))*4.0F;
    if(mob->limbSwingAmount>1.0F)mob->limbSwingAmount=1.0F;
    mob->limbSwing+=mob->limbSwingAmount;mob->renderYawOffset=entity->rotationYaw;
}

void CloneMCJ_EntityLiving_TickMob(CloneMCJ_Mob *mob,CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_Entity *entity;
    CloneMCJ_World *world;
    double dx,dz,distanceSquared,distance,pathDX,pathDZ;
    float desiredYaw;
    int followsOwner;
    if(!mob||!mob->active)return;
    entity=&mob->entity;world=entity->worldObj;
    /* EntityOcelot exposes sprinting through EntityLivingBase.  The native AI
     * does not yet own Java's MoveHelper speed field, so derive the transient
     * renderer flag from active pursuit after resetting it every tick. */
    mob->sprinting=0;

    /* Fixed 20 TPS order: previous state, timers, environment, death, target,
     * path/intent, attacks, motion/collision, animation and despawn. */
    entity->prevPosX=entity->posX;entity->prevPosY=entity->posY;entity->prevPosZ=entity->posZ;
    entity->prevRotationYaw=entity->rotationYaw;entity->prevRotationPitch=entity->rotationPitch;
    mob->prevRenderYawOffset=mob->renderYawOffset;mob->prevLimbSwing=mob->limbSwing;
    mob->prevLimbSwingAmount=mob->limbSwingAmount;mob->prevHealth=mob->health;
    mob->prevSlimeSquish=mob->slimeSquish;
    if(mob->type==CLONEMC_J_MOB_SLIME||
       mob->type==CLONEMC_J_MOB_MAGMA_CUBE)
        mob->slimeSquish+=(mob->slimeSquishAmount-mob->slimeSquish)*0.5F;
    ++entity->ticksExisted;++mob->entityAge;
    mob->prevSwingProgress=mob->swingProgress;
    if(mob->isSwinging){
        ++mob->swingProgressInt;
        if(mob->swingProgressInt>=8){
            mob->swingProgressInt=0;mob->isSwinging=0;
        }
    }else mob->swingProgressInt=0;
    mob->swingProgress=(float)mob->swingProgressInt/8.0F;
    if(mob->attackTime>0)--mob->attackTime;
    if(mob->hurtTime>0)--mob->hurtTime;
    if(mob->hurtResistantTime>0)--mob->hurtResistantTime;
    if(mob->recentlyHit>0)--mob->recentlyHit;
    if(mob->specialTimer>0)--mob->specialTimer;
    if(mob->targetTicks>0)--mob->targetTicks;
    mob->rangedAttackPending=0;
    CloneMCJ_EntityLiving_UpdateEnvironment(mob);
    if(world&&(mob->type==CLONEMC_J_MOB_SLIME||
       mob->type==CLONEMC_J_MOB_MAGMA_CUBE)){
        CloneMCJ_GameplayState *slimeState;
        slimeState=(CloneMCJ_GameplayState *)world->gameplayUserData;
        if(slimeState&&slimeState->difficulty==0){
            mob->active=0;return;
        }
    }
    if(mob->health<=0&&mob->type==CLONEMC_J_MOB_ENDER_DRAGON){
        CloneMCJ_GameplayState *dragonState;
        dragonState=world?(CloneMCJ_GameplayState *)world->gameplayUserData:
            (CloneMCJ_GameplayState *)0;
        if(dragonState)CloneMCJ_V136_TickDragonDeath(dragonState,mob);
        return;
    }
    if(mob->health<=0){if(mob->deathTime<=0)mob->deathTime=1;else ++mob->deathTime;
        mob->moveForward=mob->moveStrafing=0.0F;mob->hasPath=0;
        if(mob->deathTime>20)mob->active=0;
        return;}
    if(mob->type==CLONEMC_J_MOB_SQUID){
        CloneMCJ_EntityLiving_UpdateSquid(mob);return;
    }
    if(mob->type==CLONEMC_J_MOB_ENDER_CRYSTAL){
        ++mob->specialTimer;mob->renderYawOffset+=3.0F;return;
    }
    if(mob->type==CLONEMC_J_MOB_ENDER_DRAGON){
        CloneMCJ_V136_UpdateDragon(mob,player);return;
    }
    if(!player)return;
    if(mob->type==CLONEMC_J_MOB_VILLAGER)
        CloneMCJ_V136_TickVillager(mob,player);
    if(mob->type==CLONEMC_J_MOB_BLAZE){
        if(entity->inWater)
            CloneMCJ_EntityLiving_AttackMobFrom(mob,
                (const CloneMCJ_Entity *)0,1);
        --mob->blazeHeightOffsetUpdateTime;
        if(mob->blazeHeightOffsetUpdateTime<=0){
            mob->blazeHeightOffsetUpdateTime=100;
            mob->blazeHeightOffset=0.5F+(float)
                CloneMCJavaRandom_NextGaussian(&entity->rand)*3.0F;
        }
        if(player->entity.posY+1.62>entity->posY+
           (double)entity->height*0.85+(double)mob->blazeHeightOffset)
            entity->motionY+=(0.3-entity->motionY)*0.3;
        if(!entity->onGround&&entity->motionY<0.0)entity->motionY*=0.6;
    }
    if(mob->type==CLONEMC_J_MOB_ENDERMAN){
        int ex,ey,ez,light;
        float brightness;
        if(entity->inWater)
            CloneMCJ_EntityLiving_AttackMobFrom(mob,
                (const CloneMCJ_Entity *)0,1);
        CloneMCJ_EntityEnderman_UpdateCarriedBlock(mob);
        if(CloneMCJ_EntityLiving_PlayerStaresAtEnderman(mob,player)){
            if(mob->endermanGazeTicks++>=5){
                mob->endermanGazeTicks=0;mob->angry=1;mob->hostile=1;
                mob->targetMemoryTicks=300;mob->targetAcquired=1;
                mob->targetEntityId=player->entity.entityId;
            }
        }else mob->endermanGazeTicks=0;
        ex=CloneMCJava_FloorDouble(entity->posX);
        ey=CloneMCJava_FloorDouble(entity->posY);
        ez=CloneMCJava_FloorDouble(entity->posZ);
        light=CloneMCJ_World_GetFullBlockLightValue(world,ex,ey,ez);
        brightness=(float)light/15.0F;
        if(world->skylightSubtracted<4&&brightness>0.5F&&
           CloneMCJ_World_CanExistingBlockSeeTheSky(world,ex,ey,ez)&&
           CloneMCJavaRandom_NextFloat(&entity->rand)*30.0F<
                (brightness-0.4F)*2.0F){
            mob->targetAcquired=0;mob->hostile=0;mob->angry=0;
            (void)CloneMCJ_EntityEnderman_TeleportRandomly(mob);
        }
        if(entity->inWater){
            mob->targetAcquired=0;
            (void)CloneMCJ_EntityEnderman_TeleportRandomly(mob);
        }
    }
    if(mob->type==CLONEMC_J_MOB_WOLF)CloneMCJ_EntityWolf_Tick(mob,player);
    distanceSquared=CloneMCJ_EntityLiving_DistanceSquared(entity,&player->entity);
    if(!mob->persistenceRequired&&distanceSquared>16384.0){mob->active=0;return;}
    if(!mob->persistenceRequired&&mob->entityAge>600&&
        CloneMCJavaRandom_NextIntBound(&entity->rand,800)==0){
        if(distanceSquared>1024.0){mob->active=0;return;}mob->entityAge=0;
    }
    if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE){
        if(mob->angerLevel>0)--mob->angerLevel;
        mob->angry=(unsigned char)(mob->angerLevel>0);
        mob->hostile=mob->angry;mob->moveSpeed=mob->angry?0.95F:0.5F;
    }
    CloneMCJ_EntityLiving_UpdateTarget(mob,player,distanceSquared);
    if(mob->type==CLONEMC_J_MOB_ENDERMAN){
        mob->endermanAttacking=mob->targetAcquired;
        mob->moveSpeed=mob->targetAcquired?6.5F:0.3F;
        if(mob->targetAcquired){
            if(CloneMCJ_EntityLiving_PlayerStaresAtEnderman(mob,player)){
                mob->moveForward=mob->moveStrafing=0.0F;
                mob->moveSpeed=0.0F;
                if(distanceSquared<16.0)
                    (void)CloneMCJ_EntityEnderman_TeleportRandomly(mob);
                mob->endermanTeleportDelay=0;
            }else if(distanceSquared>256.0){
                ++mob->endermanTeleportDelay;
                if(mob->endermanTeleportDelay>=30&&
                   CloneMCJ_EntityEnderman_TeleportToPlayer(mob,player))
                    mob->endermanTeleportDelay=0;
            }else mob->endermanTeleportDelay=0;
        }else mob->endermanTeleportDelay=0;
    }
    if(mob->combatTarget&&mob->combatTarget->active&&mob->combatTarget->health>0)
        distanceSquared=CloneMCJ_EntityLiving_DistanceSquared(entity,
            &mob->combatTarget->entity);
    if(mob->type==CLONEMC_J_MOB_GHAST){
        CloneMCJ_EntityLiving_UpdateGhast(mob,player,distanceSquared);return;
    }
    CloneMCJ_EntityLiving_UpdatePath(mob,player,distanceSquared);
    if(mob->combatTarget&&mob->combatTarget->active&&mob->combatTarget->health>0){
        dx=mob->combatTarget->entity.posX-entity->posX;
        dz=mob->combatTarget->entity.posZ-entity->posZ;
        distanceSquared=CloneMCJ_EntityLiving_DistanceSquared(entity,
            &mob->combatTarget->entity);
    }else{dx=player->entity.posX-entity->posX;dz=player->entity.posZ-entity->posZ;}
    distance=sqrt(dx*dx+dz*dz);pathDX=dx;pathDZ=dz;
    if(CloneMCJ_EntityLiving_FollowPath(mob,&pathDX,&pathDZ)){
        desiredYaw=(float)(atan2(pathDZ,pathDX)*180.0/CLONEMC_J_PI)-90.0F;
        entity->rotationYaw=CloneMCJ_EntityLiving_ApproachAngle(entity->rotationYaw,desiredYaw,30.0F);
        mob->moveForward=mob->sitting?0.0F:mob->moveSpeed;mob->moveStrafing=0.0F;
    }else if(mob->targetAcquired){
        desiredYaw=(float)(atan2(dz,dx)*180.0/CLONEMC_J_PI)-90.0F;
        entity->rotationYaw=CloneMCJ_EntityLiving_ApproachAngle(entity->rotationYaw,desiredYaw,30.0F);
        mob->moveForward=distance>1.5?mob->moveSpeed:0.0F;mob->moveStrafing=0.0F;
    }else{
        if((entity->ticksExisted%80)==0)
            mob->randomYawVelocity=(CloneMCJavaRandom_NextFloat(&entity->rand)-0.5F)*80.0F;
        entity->rotationYaw+=mob->randomYawVelocity*0.05F;
        mob->moveForward=mob->sitting?0.0F:mob->moveSpeed*0.35F;mob->moveStrafing=0.0F;
    }
    if(mob->type==CLONEMC_J_MOB_OCELOT&&!mob->sitting&&
       mob->targetAcquired&&mob->moveForward>=0.4F)mob->sprinting=1;
    followsOwner=mob->type==CLONEMC_J_MOB_WOLF&&mob->tamed&&!mob->sitting&&!mob->combatTarget;
    if(followsOwner&&distanceSquared>144.0&&!mob->hasPath){
        int tx,tz,ox,oz,found;
        found=0;tx=CloneMCJava_FloorDouble(player->entity.posX)-2;
        tz=CloneMCJava_FloorDouble(player->entity.posZ)-2;
        for(ox=0;ox<5&&!found;++ox)for(oz=0;oz<5&&!found;++oz)
            if((ox<1||oz<1||ox>3||oz>3)&&
                CloneMCJ_EntityLiving_HasSolidFloor(world,(double)(tx+ox)+0.5,
                    player->entity.posY,(double)(tz+oz)+0.5,entity->width)&&
                CloneMCJ_EntityLiving_CanOccupy(world,(double)(tx+ox)+0.5,
                    player->entity.posY,(double)(tz+oz)+0.5,
                    entity->width,entity->height)){
                CloneMCJ_Entity_SetPosition(entity,(double)(tx+ox)+0.5,
                    player->entity.posY,(double)(tz+oz)+0.5);found=1;}
    }
    CloneMCJ_EntityLiving_HandleAttacks(mob,player,dx,dz,distance,distanceSquared);
    if(!mob->active)return;
    CloneMCJ_EntityLiving_UpdateDaylight(mob);
    CloneMCJ_EntityLiving_ApplyMovement(mob);
    CloneMCJ_EntityLiving_UpdateStuckState(mob);
}

void CloneMCJ_EntityLiving_Register(void)
{
    /* Priority 14 behavior is statically dispatched by the bounded mob type. */
}

const char *CloneMCJ_EntityLiving_JavaName(void)
{
    return "net.minecraft.src.EntityLiving";
}

const char *CloneMCJ_EntityLiving_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityLiving_JavaSourceHash32(void)
{
    return 0x99104386UL;
}
