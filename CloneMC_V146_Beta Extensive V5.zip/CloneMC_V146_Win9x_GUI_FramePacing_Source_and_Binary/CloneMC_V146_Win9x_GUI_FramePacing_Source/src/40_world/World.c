/*
 * CloneMC Java port scaffold: World
 *
 * Java source: World.java
 * Java type: class World
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IBlockAccess
 * Source SHA-256: 01a4b5bf674028b3d6c1b6f7d909f105c37b7c767231b4989c94971741b9c796
 * Java lines: 2940
 * Discovered declared fields: 43
 * Discovered declared methods/constructors: 149
 * Referenced Java classes: IBlockAccess, WorldProvider, WorldInfo, MapStorage, ISaveHandler, ChunkProvider, EntityPlayer, ChunkProviderLoadOrGenerate, MathHelper, IChunkProvider, IProgressUpdate, Chunk, Material, Block, IWorldAccess, EnumSkyBlock, Vec3D, Entity, AxisAlignedBB, WorldChunkManager, BiomeGenBase, NextTickListEntry, TileEntity, BlockFire, BlockFluid, Explosion, MetadataChunkBlock, SpawnerAnimals, ChunkCoordIntPair, EntityLightningBolt, ChunkCache, Pathfinder, ChunkCoordinates, MovingObjectPosition, PathEntity, MapDataBase, positionsToUpdat
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public boolean scheduledUpdatesAreImmediate
 * - private List lightingToUpdate
 * - public List loadedEntityList
 * - private List unloadedEntityList
 * - private TreeSet scheduledTickTreeSet
 * - private Set scheduledTickSet
 * - public List loadedTileEntityList
 * - private List field_30900_E
 * - public List playerEntities
 * - public List weatherEffects
 * - private long field_1019_F
 * - public int skylightSubtracted
 * - protected int field_9437_g
 * - protected final int field_9436_h = 0x3c6ef35f
 * - protected float prevRainingStrength
 * - protected float rainingStrength
 * - protected float prevThunderingStrength
 * - protected float thunderingStrength
 * - protected int field_27168_F
 * - public int field_27172_i
 * - public boolean editingBlocks
 * - private long lockTimestamp
 * - protected int autosavePeriod
 * - public int difficultySetting
 * - public Random rand
 * - public boolean isNewWorld
 * - public final WorldProvider worldProvider
 * - protected List worldAccesses
 * - protected IChunkProvider chunkProvider
 * - protected final ISaveHandler saveHandler
 * - protected WorldInfo worldInfo
 * - public boolean findingSpawnPoint
 * - private boolean allPlayersSleeping
 * - public MapStorage field_28108_z
 * - private ArrayList collidingBoundingBoxes
 * - private boolean field_31055_L
 * - private int lightingUpdatesCounter
 * - private boolean spawnHostileMobs
 * - private boolean spawnPeacefulMobs
 * - private Set positionsToUpdate
 * - private int soundCounter
 * - private List field_1012_M
 * - public boolean multiplayerWorld
 *
 * Java method/constructor inventory:
 * - public WorldChunkManager getWorldChunkManager()
 * - public World(ISaveHandler isavehandler, String s, WorldProvider worldprovider, long l)
 * - public World(World world, WorldProvider worldprovider)
 * - public World(ISaveHandler isavehandler, String s, long l)
 * - public World(ISaveHandler isavehandler, String s, long l, WorldProvider worldprovider)
 * - protected IChunkProvider getChunkProvider()
 * - protected void getInitialSpawnLocation()
 * - public void setSpawnLocation()
 * - public int getFirstUncoveredBlock(int i, int j)
 * - public void emptyMethod1()
 * - public void spawnPlayerWithLoadedChunks(EntityPlayer entityplayer)
 * - public void saveWorld(boolean flag, IProgressUpdate iprogressupdate)
 * - private void saveLevel()
 * - public boolean func_650_a(int i)
 * - public int getBlockId(int i, int j, int k)
 * - public boolean isAirBlock(int i, int j, int k)
 * - public boolean blockExists(int i, int j, int k)
 * - public boolean doChunksNearChunkExist(int i, int j, int k, int l)
 * - public boolean checkChunksExist(int i, int j, int k, int l, int i1, int j1)
 * - private boolean chunkExists(int i, int j)
 * - public Chunk getChunkFromBlockCoords(int i, int j)
 * - public Chunk getChunkFromChunkCoords(int i, int j)
 * - public boolean setBlockAndMetadata(int i, int j, int k, int l, int i1)
 * - public boolean setBlock(int i, int j, int k, int l)
 * - public Material getBlockMaterial(int i, int j, int k)
 * - public int getBlockMetadata(int i, int j, int k)
 * - public void setBlockMetadataWithNotify(int i, int j, int k, int l)
 * - public boolean setBlockMetadata(int i, int j, int k, int l)
 * - public boolean setBlockWithNotify(int i, int j, int k, int l)
 * - public boolean setBlockAndMetadataWithNotify(int i, int j, int k, int l, int i1)
 * - public void markBlockNeedsUpdate(int i, int j, int k)
 * - protected void notifyBlockChange(int i, int j, int k, int l)
 * - public void markBlocksDirtyVertical(int i, int j, int k, int l)
 * - public void markBlockAsNeedsUpdate(int i, int j, int k)
 * - public void markBlocksDirty(int i, int j, int k, int l, int i1, int j1)
 * - public void notifyBlocksOfNeighborChange(int i, int j, int k, int l)
 * - private void notifyBlockOfNeighborChange(int i, int j, int k, int l)
 * - public boolean canBlockSeeTheSky(int i, int j, int k)
 * - public int getFullBlockLightValue(int i, int j, int k)
 * - public int getBlockLightValue(int i, int j, int k)
 * - public int getBlockLightValue_do(int i, int j, int k, boolean flag)
 * - public boolean canExistingBlockSeeTheSky(int i, int j, int k)
 * - public int getHeightValue(int i, int j)
 * - public void neighborLightPropagationChanged(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
 * - public int getSavedLightValue(EnumSkyBlock enumskyblock, int i, int j, int k)
 * - public void setLightValue(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
 * - public float getBrightness(int i, int j, int k, int l)
 * - public float getLightBrightness(int i, int j, int k)
 * - public boolean isDaytime()
 * - public MovingObjectPosition rayTraceBlocks(Vec3D vec3d, Vec3D vec3d1)
 * - public MovingObjectPosition rayTraceBlocks_do(Vec3D vec3d, Vec3D vec3d1, boolean flag)
 * - public MovingObjectPosition func_28105_a(Vec3D vec3d, Vec3D vec3d1, boolean flag, boolean flag1)
 * - public void playSoundAtEntity(Entity entity, String s, float f, float f1)
 * - public void playRecord(String s, int i, int j, int k)
 * - public boolean addWeatherEffect(Entity entity)
 * - public boolean entityJoinedWorld(Entity entity)
 * - protected void obtainEntitySkin(Entity entity)
 * - protected void releaseEntitySkin(Entity entity)
 * - public void setEntityDead(Entity entity)
 * - public void addWorldAccess(IWorldAccess iworldaccess)
 * - public void removeWorldAccess(IWorldAccess iworldaccess)
 * - public List getCollidingBoundingBoxes(Entity entity, AxisAlignedBB axisalignedbb)
 * - public int calculateSkylightSubtracted(float f)
 * - public Vec3D func_4079_a(Entity entity, float f)
 * - public float getCelestialAngle(float f)
 * - public Vec3D func_628_d(float f)
 * - public Vec3D getFogColor(float f)
 * - public int findTopSolidBlock(int i, int j)
 * - public float getStarBrightness(float f)
 * - public void scheduleBlockUpdate(int i, int j, int k, int l, int i1)
 * - public void updateEntities()
 * - public void func_31054_a(Collection collection)
 * - public void updateEntity(Entity entity)
 * - public void updateEntityWithOptionalForce(Entity entity, boolean flag)
 * - public boolean checkIfAABBIsClear(AxisAlignedBB axisalignedbb)
 * - public boolean getIsAnyLiquid(AxisAlignedBB axisalignedbb)
 * - public boolean isBoundingBoxBurning(AxisAlignedBB axisalignedbb)
 * - public boolean handleMaterialAcceleration(AxisAlignedBB axisalignedbb, Material material, Entity entity)
 * - public boolean isMaterialInBB(AxisAlignedBB axisalignedbb, Material material)
 * - public boolean isAABBInMaterial(AxisAlignedBB axisalignedbb, Material material)
 * - public float func_675_a(Vec3D vec3d, AxisAlignedBB axisalignedbb)
 * - public void onBlockHit(EntityPlayer entityplayer, int i, int j, int k, int l)
 * - public Entity func_4085_a(Class class1)
 * - public String func_687_d()
 * - public String func_21119_g()
 * - public TileEntity getBlockTileEntity(int i, int j, int k)
 * - public void setBlockTileEntity(int i, int j, int k, TileEntity tileentity)
 * - public void removeBlockTileEntity(int i, int j, int k)
 * - public boolean isBlockOpaqueCube(int i, int j, int k)
 * - public boolean isBlockNormalCube(int i, int j, int k)
 * - public void saveWorldIndirectly(IProgressUpdate iprogressupdate)
 * - public boolean updatingLighting()
 * - public void scheduleLightingUpdate(EnumSkyBlock enumskyblock, int i, int j, int k, int l, int i1, int j1)
 * - public void calculateInitialSkylight()
 * - public void setAllowedMobSpawns(boolean flag, boolean flag1)
 * - public void tick()
 * - private void func_27163_E()
 * - protected void updateWeather()
 * - private void stopPrecipitation()
 * - protected void updateBlocksAndPlayCaveSounds()
 * - public boolean TickUpdates(boolean flag)
 * - public void randomDisplayUpdates(int i, int j, int k)
 * - public List getEntitiesWithinAABBExcludingEntity(Entity entity, AxisAlignedBB axisalignedbb)
 * - public List getEntitiesWithinAABB(Class class1, AxisAlignedBB axisalignedbb)
 * - public List getLoadedEntityList()
 * - public void func_698_b(int i, int j, int k, TileEntity tileentity)
 * - public int countEntities(Class class1)
 * - public void func_636_a(List list)
 * - public void func_632_b(List list)
 * - public void func_656_j()
 * - public boolean canBlockBePlacedAt(int i, int j, int k, int l, boolean flag, int i1)
 * - public PathEntity getPathToEntity(Entity entity, Entity entity1, float f)
 * - public PathEntity getEntityPathToXYZ(Entity entity, int i, int j, int k, float f)
 * - public boolean isBlockProvidingPowerTo(int i, int j, int k, int l)
 * - public boolean isBlockGettingPowered(int i, int j, int k)
 * - public boolean isBlockIndirectlyProvidingPowerTo(int i, int j, int k, int l)
 * - public boolean isBlockIndirectlyGettingPowered(int i, int j, int k)
 * - public EntityPlayer getClosestPlayerToEntity(Entity entity, double d)
 * - public EntityPlayer getClosestPlayer(double d, double d1, double d2, double d3)
 * - public EntityPlayer getPlayerEntityByName(String s)
 * - public void setChunkData(int i, int j, int k, int l, int i1, int j1, byte abyte0[])
 * - public void sendQuittingDisconnectingPacket()
 * - public void checkSessionLock()
 * - public void setWorldTime(long l)
 * - public long getRandomSeed()
 * - public long getWorldTime()
 * - public ChunkCoordinates getSpawnPoint()
 * - public void setSpawnPoint(ChunkCoordinates chunkcoordinates)
 * - public void joinEntityInSurroundings(Entity entity)
 * - public boolean func_6466_a(EntityPlayer entityplayer, int i, int j, int k)
 * - public void func_9425_a(Entity entity, byte byte0)
 * - public void updateEntityList()
 * - public IChunkProvider getIChunkProvider()
 * - public void playNoteAt(int i, int j, int k, int l, int i1)
 * - public WorldInfo getWorldInfo()
 * - public void updateAllPlayersSleepingFlag()
 * - protected void wakeUpAllPlayers()
 * - public boolean isAllPlayersFullyAsleep()
 * - public float func_27166_f(float f)
 * - public float func_27162_g(float f)
 * - public void func_27158_h(float f)
 * - public boolean func_27160_B()
 * - public boolean func_27161_C()
 * - public boolean canBlockBeRainedOn(int i, int j, int k)
 * - public void setItemData(String s, MapDataBase mapdatabase)
 * - public MapDataBase loadItemData(Class class1, String s)
 * - public int getUniqueDataId(String s)
 * - public void func_28106_e(int i, int j, int k, int l, int i1)
 * - public void func_28107_a(EntityPlayer entityplayer, int i, int j, int k, int l, int i1)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include "../30_item/clonemc_java_port_30_item.h"
#include <stdlib.h>
#include <math.h>
#include <string.h>

void CloneMCJ_World_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_World_JavaName(void)
{
    return "net.minecraft.src.World";
}

const char *CloneMCJ_World_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_World_JavaSourceHash32(void)
{
    return 0x01A4B5BFUL;
}

/* Priority 3 chunk-backed World.java companion.
 * Priority 4 replaces the flat/debug generator with ChunkProviderGenerate.java.
 */
static int CloneMCJ_World_JavaTerrainGenerator(CloneMCJ_Chunk *chunk, int chunkX, int chunkZ, void *userData)
{
    CloneMCJ_World *world;
    world = (CloneMCJ_World *)userData;
    if (!world) { return 0; }
    if (world->worldProvider.isHellWorld)
        return CloneMCJ_ChunkProviderHell_GenerateChunk(&world->hellProvider, chunk, chunkX, chunkZ);
    if (world->worldProvider.worldType == 1)
        return CloneMCJ_ChunkProviderEnd_GenerateChunk(&world->skyProvider, chunk, chunkX, chunkZ);
    return CloneMCJ_ChunkProviderGenerate_GenerateChunk(&world->terrainProvider, chunk, chunkX, chunkZ);
}

static int CloneMCJ_World_RadiusForChunkLimit(int chunkLimit)
{
    int radius;
    int total;
    if(chunkLimit<1)chunkLimit=1;
    radius=0;total=1;
    /* Restore V135's stable budget-to-ring conversion.  The ring describes
     * streaming priority; ChunkProviderLoadOrGenerate remains bounded by the
     * exact resident target, so a 32-chunk Win98 profile never allocates 41. */
    while(total<chunkLimit&&radius<CLONEMC_J_CHUNK_STREAM_MAX_RADIUS){
        ++radius;total=1+2*radius*(radius+1);
    }
    return radius;
}

static void CloneMCJ_World_InitializeInternal(CloneMCJ_World *world,
    CloneMCJLong seed,int activeChunkBudget,int prepareSpawn)
{
    if (!world) { return; }
    memset(world, 0, sizeof(*world));
    world->randomSeed = seed;
    world->worldTime = (CloneMCJLong)0;
    world->skylightSubtracted = 0;
    world->multiplayerWorld = 0;
    world->playerChunkX = 0;
    world->playerChunkZ = 0;
    /* V141 restores the V135 contract: the option is a chunk budget, not a
     * radius.  The derived Manhattan ring is only an ordered streaming search
     * boundary; provider admission and eviction enforce the exact budget. */
    if(activeChunkBudget<1)activeChunkBudget=1;
    if(activeChunkBudget>CLONEMC_J_CHUNK_STREAM_MAX_TARGET)
        activeChunkBudget=CLONEMC_J_CHUNK_STREAM_MAX_TARGET;
    world->activeChunkLimit=activeChunkBudget;
    world->activeRadius=CloneMCJ_World_RadiusForChunkLimit(activeChunkBudget);
    /* V142 keeps the legacy counters for diagnostics only.  Gameplay and
     * entity movement have no independent synchronous admission allowance. */
    world->playerChunkLoadBudget=0;
    world->entityChunkLoadBudget=0;
    world->chunkMemoryBudgetBytes=CLONEMC_J_CHUNK_MEMORY_BUDGET_BYTES;
    world->saveHandler = 0;
    /* Minecraft ticks at 20 TPS: 600 ticks is a 30-second checkpoint.  The
     * provider still writes at most two dirty chunks per checkpoint, so old
     * disks do not receive a full resident-set write burst. */
    world->autosavePeriod = 600;
    world->randomTickLCG = (CloneMCJInt)seed;
    CloneMCJavaRandom_SetSeed(&world->rand, seed);
    CloneMCJ_WorldProvider_InitializeSurface(&world->worldProvider);
    CloneMCJ_WorldInfo_Initialize(&world->worldInfo, seed, "World");
        CloneMCJ_WorldChunkManager_Initialize(&world->chunkManager, seed);
    CloneMCJ_ChunkProviderGenerate_Initialize(&world->terrainProvider, seed, &world->chunkManager);
    CloneMCJ_ChunkProviderHell_Initialize(&world->hellProvider, seed);
    CloneMCJ_ChunkProviderEnd_Initialize(&world->skyProvider, seed);
    CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&world->chunkProvider, seed);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetWorldTimePointer(&world->chunkProvider, &world->worldTime);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&world->chunkProvider,
        world->activeChunkLimit);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(&world->chunkProvider, 0, 0, CloneMCJ_World_JavaTerrainGenerator, world, 0, 0);
    CloneMCJ_BlockSimulation_RegisterWorld(world);
    if(prepareSpawn)CloneMCJ_World_SetPlayerGlobalPosition(world, 0.0, 0.0);
}

void CloneMCJ_World_Initialize(CloneMCJ_World *world,CloneMCJLong seed,
    int activeChunkBudget)
{
    CloneMCJ_World_InitializeInternal(world,seed,activeChunkBudget,1);
}

void CloneMCJ_World_InitializeDeferred(CloneMCJ_World *world,CloneMCJLong seed,
    int activeChunkBudget)
{
    /* MinecraftImpl attaches level.dat/McRegion before the first spawn-area
     * prepare. This avoids generating and freeing a preview 3x3 with the wrong
     * seed, then immediately generating it a second time. */
    CloneMCJ_World_InitializeInternal(world,seed,activeChunkBudget,0);
}

void CloneMCJ_World_Destroy(CloneMCJ_World *world)
{
    if (!world) { return; }
    CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&world->chunkProvider);
    CloneMCJ_ChunkProviderGenerate_Destroy(&world->terrainProvider);
    CloneMCJ_ChunkProviderHell_Destroy(&world->hellProvider);
    CloneMCJ_ChunkProviderEnd_Destroy(&world->skyProvider);
    CloneMCJ_WorldChunkManager_Destroy(&world->chunkManager);
    CloneMCJ_WorldInfo_Destroy(&world->worldInfo);
    world->saveHandler = 0;
    world->localPlayerEntity = (struct CloneMCJ_EntityTag *)0;
}

int CloneMCJ_World_GlobalToChunk(int blockCoord)
{
    if (blockCoord >= 0) { return blockCoord >> 4; }
    /* Explicit blockCoord < 0 path: Java floor division for negative global coordinates. */
    return -(((-blockCoord) + 15) >> 4);
}

int CloneMCJ_World_GlobalToLocal(int blockCoord)
{
    int chunk;
    chunk = CloneMCJ_World_GlobalToChunk(blockCoord);
    return blockCoord - chunk * 16;
}

static CloneMCJ_Chunk *CloneMCJ_World_FindLoadedChunk(CloneMCJ_World *, int, int);

static int CloneMCJ_World_PopulationQueueContains(const CloneMCJ_World *world,
    int chunkX, int chunkZ)
{
    unsigned short i;
    unsigned short index;
    if (!world) return 0;
    index = world->populationQueueHead;
    for (i = 0; i < world->populationQueueCount; ++i) {
        if (world->populationQueueX[index] == chunkX &&
            world->populationQueueZ[index] == chunkZ) return 1;
        index = (unsigned short)((index + 1U) % CLONEMC_J_POPULATION_QUEUE_CAPACITY);
    }
    return 0;
}

static void CloneMCJ_World_QueuePopulationCandidate(CloneMCJ_World *world,
    int chunkX, int chunkZ)
{
    unsigned short index;
    if (!world || CloneMCJ_World_PopulationQueueContains(world, chunkX, chunkZ))
        return;
    if (world->populationQueueCount >= CLONEMC_J_POPULATION_QUEUE_CAPACITY) {
        ++world->populationCandidatesDropped;
        return;
    }
    index = world->populationQueueTail;
    world->populationQueueX[index] = chunkX;
    world->populationQueueZ[index] = chunkZ;
    world->populationQueueTail = (unsigned short)((index + 1U) %
        CLONEMC_J_POPULATION_QUEUE_CAPACITY);
    ++world->populationQueueCount;
    ++world->populationCandidatesQueued;
}

static void CloneMCJ_World_QueuePopulationNeighborhood(CloneMCJ_World *world,
    int chunkX, int chunkZ)
{
    /* Populate(x,z) depends on x+1/z+1. A newly admitted chunk can therefore
     * make exactly four candidates ready; do not restart a radius-wide scan. */
    CloneMCJ_World_QueuePopulationCandidate(world, chunkX, chunkZ);
    CloneMCJ_World_QueuePopulationCandidate(world, chunkX - 1, chunkZ);
    CloneMCJ_World_QueuePopulationCandidate(world, chunkX, chunkZ - 1);
    CloneMCJ_World_QueuePopulationCandidate(world, chunkX - 1, chunkZ - 1);
}

static int CloneMCJ_World_PopPopulationCandidate(CloneMCJ_World *world,
    int *chunkX, int *chunkZ)
{
    unsigned short index;
    if (!world || !chunkX || !chunkZ || world->populationQueueCount == 0)
        return 0;
    index = world->populationQueueHead;
    *chunkX = world->populationQueueX[index];
    *chunkZ = world->populationQueueZ[index];
    world->populationQueueHead = (unsigned short)((index + 1U) %
        CLONEMC_J_POPULATION_QUEUE_CAPACITY);
    --world->populationQueueCount;
    return 1;
}

static void CloneMCJ_World_ResetChunkStreaming(CloneMCJ_World *world)
{
    int i;
    CloneMCJ_Chunk *chunk;
    if (!world) return;
    world->streamCenterX = world->playerChunkX;
    world->streamCenterZ = world->playerChunkZ;
    world->streamGenerationRing = 0;
    world->streamGenerationCursor = 0;
    world->streamPopulationRing = 0;
    world->streamPopulationCursor = 0;
    world->streamGenerationComplete = 0;
    world->streamPopulationComplete = 0;
    world->streamRetryTick = 0UL;
    world->populationQueueHead = 0;
    world->populationQueueTail = 0;
    world->populationQueueCount = 0;
    for (i = 0; i < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++i) {
        chunk = world->chunkProvider.slots[i].chunk;
        if (world->chunkProvider.slots[i].used && chunk &&
            !chunk->isTerrainPopulated)
            CloneMCJ_World_QueuePopulationCandidate(world,
                chunk->xPosition, chunk->zPosition);
    }
}

static int CloneMCJ_World_StreamCoordinate(int centerX, int centerZ, int ring,
    int cursor, int *chunkX, int *chunkZ)
{
    int edge;
    int offset;
    int dx;
    int dz;
    if (!chunkX || !chunkZ || ring < 0 || cursor < 0) return 0;
    if (ring == 0) {
        if (cursor != 0) return 0;
        *chunkX = centerX;
        *chunkZ = centerZ;
        return 1;
    }
    /* Manhattan perimeter.  The four segments include each cardinal vertex
     * exactly once and avoid the large square-corner memory penalty. */
    if (cursor >= ring * 4) return 0;
    edge = cursor / ring;
    offset = cursor % ring;
    if (edge == 0) { dx = offset; dz = -ring + offset; }
    else if (edge == 1) { dx = ring - offset; dz = offset; }
    else if (edge == 2) { dx = -offset; dz = ring - offset; }
    else { dx = -ring + offset; dz = -offset; }
    *chunkX = centerX + dx;
    *chunkZ = centerZ + dz;
    return 1;
}

static void CloneMCJ_World_AdvanceStreamCursor(int maximumRing, int *ring,
    int *cursor, unsigned char *complete)
{
    int count;
    if (!ring || !cursor || !complete || *complete) return;
    count = *ring == 0 ? 1 : *ring * 4;
    ++(*cursor);
    if (*cursor >= count) {
        *cursor = 0;
        ++(*ring);
        if (*ring > maximumRing) *complete = 1;
    }
}

void CloneMCJ_World_SetActiveRadius(CloneMCJ_World *world, int chunkBudget)
{
    int radius;
    if(!world)return;
    if(chunkBudget<1)chunkBudget=1;
    if(chunkBudget>CLONEMC_J_CHUNK_STREAM_MAX_TARGET)
        chunkBudget=CLONEMC_J_CHUNK_STREAM_MAX_TARGET;
    radius=CloneMCJ_World_RadiusForChunkLimit(chunkBudget);
    if(world->activeRadius==radius&&world->activeChunkLimit==chunkBudget&&
       world->playerChunkInitialized)return;
    world->activeRadius=radius;
    world->activeChunkLimit=chunkBudget;
    CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&world->chunkProvider,
        chunkBudget);
    if(world->playerChunkInitialized)CloneMCJ_World_ResetChunkStreaming(world);
}

void CloneMCJ_World_SetChunkMemoryBudget(CloneMCJ_World *world,
    unsigned long budgetBytes)
{
    if(!world)return;
    CloneMCJ_ChunkProviderLoadOrGenerate_SetMemoryBudget(&world->chunkProvider,
        budgetBytes);
    world->chunkMemoryBudgetBytes=world->chunkProvider.runtimeMemoryBudgetBytes;
}

void CloneMCJ_World_SetPlayerGlobalPosition(CloneMCJ_World *world, double x, double z)
{
    int newChunkX;
    int newChunkZ;
    CloneMCJ_Chunk *center;
    if (!world) return;
    newChunkX = CloneMCJ_World_GlobalToChunk(CloneMCJava_FloorDouble(x));
    newChunkZ = CloneMCJ_World_GlobalToChunk(CloneMCJava_FloorDouble(z));
    if (world->playerChunkInitialized && world->playerChunkX == newChunkX &&
        world->playerChunkZ == newChunkZ) return;
    world->playerChunkX = newChunkX;
    world->playerChunkZ = newChunkZ;
    world->playerChunkInitialized = 1;
    if (world->multiplayerWorld) return;
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(&world->chunkProvider,
        newChunkX, newChunkZ);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&world->chunkProvider,
        world->activeChunkLimit);
    CloneMCJ_World_ResetChunkStreaming(world);
    /* Only the center chunk is synchronous.  EntityPlayer needs its height map
     * to select a safe spawn, but all surrounding generation, population,
     * lighting and unloading is paced by ServiceChunkStreaming. */
    center = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider,
        newChunkX, newChunkZ);
    if (center && center != &world->chunkProvider.blankChunk) {
        ++world->streamedChunksPrepared;
        CloneMCJ_World_AdvanceStreamCursor(world->activeRadius,
            &world->streamGenerationRing, &world->streamGenerationCursor,
            &world->streamGenerationComplete);
    }
}


static void CloneMCJ_World_ScheduleChunkEmissionLighting(CloneMCJ_World *world,
    CloneMCJ_Chunk *chunk)
{
    int section;
    int localX;
    int localY;
    int localZ;
    int blockID;
    int minX;
    int minY;
    int minZ;
    int maxX;
    int maxY;
    int maxZ;
    int found;
    int baseX;
    int baseZ;
    if (!world || !chunk) return;
    baseX = chunk->xPosition * 16;
    baseZ = chunk->zPosition * 16;
    /* Chunk height-map generation already writes vertical skylight.  Java's
     * block-light pass only needs seeds around emissive blocks.  Scan bounded
     * sixteen-block sections and queue compact boxes instead of a 32,768-cell
     * full-height region for every streamed chunk. */
    for (section = 0; section < 8; ++section) {
        found = 0;
        minX = minZ = 15;
        minY = section * 16 + 15;
        maxX = maxZ = 0;
        maxY = section * 16;
        for (localY = section * 16; localY < section * 16 + 16; ++localY) {
            for (localZ = 0; localZ < 16; ++localZ) {
                for (localX = 0; localX < 16; ++localX) {
                    blockID = CloneMCJ_Chunk_GetBlockID(chunk, localX, localY, localZ);
                    if (CloneMCJ_World_GetBlockLightEmission(blockID) <= 0) continue;
                    found = 1;
                    if (localX < minX) minX = localX;
                    if (localX > maxX) maxX = localX;
                    if (localY < minY) minY = localY;
                    if (localY > maxY) maxY = localY;
                    if (localZ < minZ) minZ = localZ;
                    if (localZ > maxZ) maxZ = localZ;
                }
            }
        }
        if (found) {
            if (minX > 0) --minX;
            if (minY > 0) --minY;
            if (minZ > 0) --minZ;
            if (maxX < 15) ++maxX;
            if (maxY < 127) ++maxY;
            if (maxZ < 15) ++maxZ;
            CloneMCJ_World_ScheduleLightingUpdate(world,
                CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, baseX + minX, minY, baseZ + minZ,
                baseX + maxX, maxY, baseZ + maxZ);
        }
    }
}

int CloneMCJ_World_EnsureChunksExist(CloneMCJ_World *world,
    int minX,int minZ,int maxX,int maxZ,int maxLoads,int requestClass)
{
    /* V142: this legacy symbol is deliberately a pure residency query.
     * V139 made it synchronously evict, save, allocate and generate terrain
     * from entity movement and AI.  Callers may test readiness, but only the
     * central World_ServiceChunkStreaming path owns chunk admission. */
    (void)maxLoads;
    (void)requestClass;
    if(!world||minX>maxX||minZ>maxZ)return 0;
    return CloneMCJ_World_CheckChunksExist(world,minX,0,minZ,maxX,
        CLONEMC_J_CHUNK_HEIGHT-1,maxZ);
}

static int CloneMCJ_World_CanPopulateLoadedChunk(CloneMCJ_World *world,
    int chunkX, int chunkZ)
{
    if (!world) return 0;
    return CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
               chunkX, chunkZ) &&
        CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
               chunkX + 1, chunkZ) &&
        CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
               chunkX, chunkZ + 1) &&
        CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
               chunkX + 1, chunkZ + 1);
}

void CloneMCJ_World_ServiceChunkStreaming(CloneMCJ_World *world)
{
    static const int generationIntervals[4]={1,1,2,2};
    static const int populationIntervals[4]={1,2,2,3};
    int attempts;
    int maximumAttempts;
    int chunkX;
    int chunkZ;
    CloneMCJ_Chunk *chunk;
    int removed;
    int generationInterval;
    int populationInterval;
    int unloadBudget;
    int canGenerate;
    if (!world || world->multiplayerWorld || !world->playerChunkInitialized) return;
    if (world->streamCenterX != world->playerChunkX ||
        world->streamCenterZ != world->playerChunkZ) CloneMCJ_World_ResetChunkStreaming(world);

    /* Priority 17 performance tiers preserve the exact resident-chunk cap but
     * reduce background admission pressure as the selected horizon grows. */
    if (world->activeChunkLimit <= 8) world->performanceTier = 0;
    else if (world->activeChunkLimit <= 16) world->performanceTier = 1;
    else if (world->activeChunkLimit <= 24) world->performanceTier = 2;
    else world->performanceTier = 3;
    /* Admission is centralized below.  Gameplay may not consume a separate
     * synchronous player/entity loading budget. */
    world->playerChunkLoadBudget=0;
    world->entityChunkLoadBudget=0;
    /* Display-list publication removes the old per-frame CPU-array submission
     * bottleneck.  Keep generation bounded to one successful chunk per service
     * call, but do not make a larger requested horizon load four times slower. */
    generationInterval=generationIntervals[(int)world->performanceTier];
    populationInterval=populationIntervals[(int)world->performanceTier];
    maximumAttempts = 8 + (int)world->performanceTier * 2;
    unloadBudget = 4 + (int)world->performanceTier;
    /* On the 8 MiB Win98 chunk profile, synchronous terrain generation and
     * population must not compete with every presentation frame.  Priority
     * movement loads remain available, while background work is staggered. */
    if(world->chunkMemoryBudgetBytes<=8UL*1024UL*1024UL){
        if(generationInterval<3)generationInterval=3;
        if(populationInterval<4)populationInterval=4;
        if(maximumAttempts>4)maximumAttempts=4;
        world->playerChunkLoadBudget=0;
        world->entityChunkLoadBudget=0;
        if(unloadBudget>2)unloadBudget=2;
    }
    if (world->ticksRun < 80UL && generationInterval < 2) generationInterval = 2;
    canGenerate = (world->ticksRun % (unsigned long)generationInterval) == 0UL;

    attempts = 0;
    while (canGenerate && !world->streamGenerationComplete &&
           attempts < maximumAttempts) {
        if (!CloneMCJ_World_StreamCoordinate(world->streamCenterX,
                world->streamCenterZ, world->streamGenerationRing,
                world->streamGenerationCursor, &chunkX, &chunkZ)) {
            world->streamGenerationComplete = 1;
            break;
        }
        ++attempts;
        ++world->streamCoordinatesScanned;
        if (!CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(
                &world->chunkProvider, chunkX, chunkZ)) {
            CloneMCJ_World_AdvanceStreamCursor(world->activeRadius,
                &world->streamGenerationRing, &world->streamGenerationCursor,
                &world->streamGenerationComplete);
            continue;
        }
        if (CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
                chunkX, chunkZ)) {
            CloneMCJ_World_AdvanceStreamCursor(world->activeRadius,
                &world->streamGenerationRing, &world->streamGenerationCursor,
                &world->streamGenerationComplete);
            continue;
        }
        if (world->streamRetryTick > world->ticksRun) break;
        chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider,
            chunkX, chunkZ);
        if (chunk && chunk != &world->chunkProvider.blankChunk) {
            CloneMCJ_World_AdvanceStreamCursor(world->activeRadius,
                &world->streamGenerationRing, &world->streamGenerationCursor,
                &world->streamGenerationComplete);
            ++world->streamedChunksPrepared;
            CloneMCJ_World_QueuePopulationNeighborhood(world, chunkX, chunkZ);
            if (chunk->lightDirty) {
                CloneMCJ_World_ScheduleChunkEmissionLighting(world, chunk);
                chunk->lightDirty = 0;
            }
        } else {
            ++world->streamAllocationFailures;
            world->streamRetryTick = world->ticksRun + 20UL;
        }
        break;
    }

    /* Process a finite candidate queue. Java population dependencies are local
     * to a 2x2 chunk square; a failed candidate is reconsidered only when one
     * of those four chunks is admitted, eliminating repeated radius scans. */
    if ((world->ticksRun % (unsigned long)populationInterval) == 0UL &&
        CloneMCJ_World_PopPopulationCandidate(world, &chunkX, &chunkZ)) {
        if (CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(
                &world->chunkProvider, chunkX, chunkZ)) {
            chunk = CloneMCJ_World_FindLoadedChunk(world, chunkX, chunkZ);
            if (chunk && !chunk->isTerrainPopulated &&
                CloneMCJ_World_CanPopulateLoadedChunk(world, chunkX, chunkZ)) {
                if (world->worldProvider.isHellWorld)
                    CloneMCJ_ChunkProviderHell_PopulateWorldChunk(&world->hellProvider,
                        world, chunkX, chunkZ);
                else if (world->worldProvider.worldType == 1)
                    CloneMCJ_ChunkProviderEnd_PopulateWorldChunk(&world->skyProvider,
                        world, chunkX, chunkZ);
                else
                    CloneMCJ_ChunkProviderGenerate_PopulateWorldChunk(&world->terrainProvider,
                        world, chunkX, chunkZ);
                ++world->streamedChunksPopulated;
                if (chunk->lightDirty) {
                    CloneMCJ_World_ScheduleChunkEmissionLighting(world, chunk);
                    chunk->lightDirty = 0;
                }
            }
        }
    }
    world->streamPopulationComplete = world->streamGenerationComplete &&
        world->populationQueueCount == 0;

    removed = CloneMCJ_ChunkProviderLoadOrGenerate_UnloadOldestChunks(
        &world->chunkProvider, unloadBudget);
    if (removed > 0) world->streamedChunksUnloaded += (unsigned long)removed;
}

CloneMCJ_Chunk *CloneMCJ_World_GetChunkFromChunkCoords(CloneMCJ_World *world, int chunkX, int chunkZ)
{
    if (!world) { return 0; }
    if(world->multiplayerWorld)
        return CloneMCJ_ChunkProviderClient_ProvideChunk(&((CloneMCJ_WorldClient *)world)->clientChunkProvider,chunkX,chunkZ);
    return CloneMCJ_ChunkProviderLoadOrGenerate_ProvideChunk(&world->chunkProvider, chunkX, chunkZ);
}

CloneMCJ_Chunk *CloneMCJ_World_GetChunkFromBlockCoords(CloneMCJ_World *world, int blockX, int blockZ)
{
    return CloneMCJ_World_GetChunkFromChunkCoords(world, CloneMCJ_World_GlobalToChunk(blockX), CloneMCJ_World_GlobalToChunk(blockZ));
}

int CloneMCJ_World_GetBlockId(CloneMCJ_World *world, int blockX, int y, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    if (!world || y < 0 || y >= 128) { return 0; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, blockX, blockZ);
    return CloneMCJ_Chunk_GetBlockID(chunk, CloneMCJ_World_GlobalToLocal(blockX), y, CloneMCJ_World_GlobalToLocal(blockZ));
}

static CloneMCJ_Chunk *CloneMCJ_World_FindLoadedChunk(CloneMCJ_World *world,
    int chunkX, int chunkZ)
{
    int slot;
    if (!world) { return 0; }
    if (world->multiplayerWorld) {
        CloneMCJ_ChunkProviderClient *provider;
        provider = &((CloneMCJ_WorldClient *)world)->clientChunkProvider;
        for (slot=0;slot<CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY;++slot) {
            if (provider->slots[slot].used && provider->slots[slot].chunk &&
                provider->slots[slot].chunkX == chunkX &&
                provider->slots[slot].chunkZ == chunkZ) return provider->slots[slot].chunk;
        }
    } else {
        for (slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot) {
            CloneMCJ_ChunkCacheSlot *entry;
            entry=&world->chunkProvider.slots[slot];
            if (entry->used && entry->chunk &&
                CloneMCJ_Chunk_IsAtLocation(entry->chunk,chunkX,chunkZ)) return entry->chunk;
        }
    }
    return 0;
}

CloneMCJ_Chunk *CloneMCJ_World_GetLoadedChunkFromChunkCoords(
    CloneMCJ_World *world,int chunkX,int chunkZ)
{
    /* Unlike getChunkFromChunkCoords, this is a pure residency query.  Entity
     * physics and serialization must never generate terrain merely to decide
     * whether an entity is eligible to tick. */
    return CloneMCJ_World_FindLoadedChunk(world,chunkX,chunkZ);
}

int CloneMCJ_World_CheckChunksExist(CloneMCJ_World *world,
    int minX,int minY,int minZ,int maxX,int maxY,int maxZ)
{
    int minChunkX,minChunkZ,maxChunkX,maxChunkZ;
    int required,found,slot,chunkX,chunkZ;
    CloneMCJ_Chunk *chunk;
    if(!world||maxY<0||minY>=CLONEMC_J_CHUNK_HEIGHT||
       minX>maxX||minZ>maxZ)return 0;
    minChunkX=CloneMCJ_World_GlobalToChunk(minX);
    minChunkZ=CloneMCJ_World_GlobalToChunk(minZ);
    maxChunkX=CloneMCJ_World_GlobalToChunk(maxX);
    maxChunkZ=CloneMCJ_World_GlobalToChunk(maxZ);
    required=(maxChunkX-minChunkX+1)*(maxChunkZ-minChunkZ+1);
    if(required<=0)return 0;
    found=0;
    if(world->multiplayerWorld){
        CloneMCJ_ChunkProviderClient *provider;
        provider=&((CloneMCJ_WorldClient *)world)->clientChunkProvider;
        for(slot=0;slot<CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY;++slot){
            if(!provider->slots[slot].used||!provider->slots[slot].chunk)continue;
            chunkX=provider->slots[slot].chunkX;
            chunkZ=provider->slots[slot].chunkZ;
            if(chunkX>=minChunkX&&chunkX<=maxChunkX&&
               chunkZ>=minChunkZ&&chunkZ<=maxChunkZ&&
               provider->slots[slot].chunk->loaded)++found;
        }
    }else{
        for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot){
            if(!world->chunkProvider.slots[slot].used||
               !world->chunkProvider.slots[slot].chunk)continue;
            chunk=world->chunkProvider.slots[slot].chunk;
            if(chunk->xPosition>=minChunkX&&chunk->xPosition<=maxChunkX&&
               chunk->zPosition>=minChunkZ&&chunk->zPosition<=maxChunkZ&&
               chunk->loaded)++found;
        }
    }
    return found>=required;
}

int CloneMCJ_World_GetLoadedBlockId(CloneMCJ_World *world, int blockX, int y, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    if (!world || y < 0 || y >= CLONEMC_J_CHUNK_HEIGHT) { return 0; }
    chunk = CloneMCJ_World_FindLoadedChunk(world,
        CloneMCJ_World_GlobalToChunk(blockX),CloneMCJ_World_GlobalToChunk(blockZ));
    if (!chunk) { return 0; }
    return CloneMCJ_Chunk_GetBlockID(chunk, CloneMCJ_World_GlobalToLocal(blockX), y,
        CloneMCJ_World_GlobalToLocal(blockZ));
}

int CloneMCJ_World_GetLoadedBlockMetadata(CloneMCJ_World *world, int blockX, int y, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    if (!world || y < 0 || y >= CLONEMC_J_CHUNK_HEIGHT) return 0;
    chunk=CloneMCJ_World_FindLoadedChunk(world,
        CloneMCJ_World_GlobalToChunk(blockX),CloneMCJ_World_GlobalToChunk(blockZ));
    if(!chunk)return 0;
    return CloneMCJ_Chunk_GetBlockMetadata(chunk,CloneMCJ_World_GlobalToLocal(blockX),
        y,CloneMCJ_World_GlobalToLocal(blockZ));
}

int CloneMCJ_World_GetBlockMetadata(CloneMCJ_World *world, int blockX, int y, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    if (!world || y < 0 || y >= 128) { return 0; }
    if (world->blockRemovalActive && blockX == world->removalBlockX &&
        y == world->removalBlockY && blockZ == world->removalBlockZ)
        return world->removalOldMetadata;
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, blockX, blockZ);
    return CloneMCJ_Chunk_GetBlockMetadata(chunk, CloneMCJ_World_GlobalToLocal(blockX), y, CloneMCJ_World_GlobalToLocal(blockZ));
}

static int CloneMCJ_World_BlockOpacityCallback(int blockID, void *userData)
{
    (void)userData;
    return CloneMCJ_World_GetBlockLightOpacity(blockID);
}

static void CloneMCJ_World_MarkEditMeshesDirty(CloneMCJ_World *world,int blockX,int blockZ)
{
    int chunkX;int chunkZ;int localX;int localZ;CloneMCJ_Chunk *chunk;
    if(!world)return;
    chunkX=CloneMCJ_World_GlobalToChunk(blockX);chunkZ=CloneMCJ_World_GlobalToChunk(blockZ);
    localX=CloneMCJ_World_GlobalToLocal(blockX);localZ=CloneMCJ_World_GlobalToLocal(blockZ);
    chunk=CloneMCJ_World_FindLoadedChunk(world,chunkX,chunkZ);if(chunk)chunk->meshDirty=1;
    if(localX==0){chunk=CloneMCJ_World_FindLoadedChunk(world,chunkX-1,chunkZ);if(chunk)chunk->meshDirty=1;}
    else if(localX==15){chunk=CloneMCJ_World_FindLoadedChunk(world,chunkX+1,chunkZ);if(chunk)chunk->meshDirty=1;}
    if(localZ==0){chunk=CloneMCJ_World_FindLoadedChunk(world,chunkX,chunkZ-1);if(chunk)chunk->meshDirty=1;}
    else if(localZ==15){chunk=CloneMCJ_World_FindLoadedChunk(world,chunkX,chunkZ+1);if(chunk)chunk->meshDirty=1;}
}

void CloneMCJ_World_MarkLightingRegionDirty(CloneMCJ_World *world,
    int minX,int minZ,int maxX,int maxZ)
{
    CloneMCJ_Chunk *chunk;int minChunkX,minChunkZ,maxChunkX,maxChunkZ,chunkX,chunkZ;
    if(!world)return;
    /* One-block expansion covers faces in an adjacent chunk that sample light
     * from the changed edge.  This is called once per processed light region,
     * not once for every propagated light cell. */
    minChunkX=CloneMCJ_World_GlobalToChunk(minX-1);
    minChunkZ=CloneMCJ_World_GlobalToChunk(minZ-1);
    maxChunkX=CloneMCJ_World_GlobalToChunk(maxX+1);
    maxChunkZ=CloneMCJ_World_GlobalToChunk(maxZ+1);
    for(chunkX=minChunkX;chunkX<=maxChunkX;++chunkX)
        for(chunkZ=minChunkZ;chunkZ<=maxChunkZ;++chunkZ){
            chunk=CloneMCJ_World_FindLoadedChunk(world,chunkX,chunkZ);
            if(chunk)chunk->meshDirty=1;
        }
}

int CloneMCJ_World_SetBlockWithMetadata(CloneMCJ_World *world, int blockX, int y, int blockZ, int blockID, int metadata)
{
    CloneMCJ_Chunk *chunk;
    const CloneMCJ_BlockDefinition *oldBlock;
    const CloneMCJ_BlockDefinition *newBlock;
    int oldID;
    int oldMetadata;
    int changed;
    if (!world || y < 0 || y >= 128 || world->multiplayerWorld) { return 0; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, blockX, blockZ);
    if (!chunk) { return 0; }
    oldID = CloneMCJ_Chunk_GetBlockID(chunk, CloneMCJ_World_GlobalToLocal(blockX), y,
        CloneMCJ_World_GlobalToLocal(blockZ));
    oldMetadata = CloneMCJ_Chunk_GetBlockMetadata(chunk,
        CloneMCJ_World_GlobalToLocal(blockX), y,
        CloneMCJ_World_GlobalToLocal(blockZ));
    changed = CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk, CloneMCJ_World_GlobalToLocal(blockX), y,
        CloneMCJ_World_GlobalToLocal(blockZ), blockID, metadata,
        CloneMCJ_World_BlockOpacityCallback, 0);
    if (changed) {
        CloneMCJ_World_ScheduleLightingUpdate(world, CLONEMC_J_ENUM_SKY_BLOCK_SKY,
            blockX, y, blockZ, blockX, y, blockZ);
        if (oldID != blockID) {
            oldBlock = CloneMCJ_BlockRegistry_Get(oldID);
            newBlock = CloneMCJ_BlockRegistry_Get(blockID);
            if (oldBlock && oldBlock->onBlockRemoved) {
                world->blockRemovalActive = 1;
                world->removalBlockX = blockX;
                world->removalBlockY = y;
                world->removalBlockZ = blockZ;
                world->removalOldBlockID = oldID;
                world->removalOldMetadata = oldMetadata;
                oldBlock->onBlockRemoved(world, blockX, y, blockZ);
                world->blockRemovalActive = 0;
            }
            if (newBlock && newBlock->onBlockAdded)
                newBlock->onBlockAdded(world, blockX, y, blockZ);
        }
        CloneMCJ_World_ScheduleLightingUpdate(world, CLONEMC_J_ENUM_SKY_BLOCK_BLOCK,
            blockX, y, blockZ, blockX, y, blockZ);
        CloneMCJ_World_MarkEditMeshesDirty(world,blockX,blockZ);
    }
    return changed;
}



int CloneMCJ_World_SetBlock(CloneMCJ_World *world, int blockX, int y, int blockZ, int blockID)
{
    return CloneMCJ_World_SetBlockWithMetadata(world, blockX, y, blockZ, blockID, 0);
}

int CloneMCJ_World_SetBlockMetadata(CloneMCJ_World *world, int blockX, int y, int blockZ,
    int metadata)
{
    CloneMCJ_Chunk *chunk;
    int oldMetadata;
    if (!world || y < 0 || y >= 128 || world->multiplayerWorld) { return 0; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, blockX, blockZ);
    if (!chunk) { return 0; }
    oldMetadata = CloneMCJ_Chunk_GetBlockMetadata(chunk, CloneMCJ_World_GlobalToLocal(blockX),
        y, CloneMCJ_World_GlobalToLocal(blockZ));
    metadata &= 15;
    if (oldMetadata == metadata) { return 0; }
    CloneMCJ_Chunk_SetBlockMetadata(chunk, CloneMCJ_World_GlobalToLocal(blockX), y,
        CloneMCJ_World_GlobalToLocal(blockZ), metadata);
    CloneMCJ_World_MarkEditMeshesDirty(world,blockX,blockZ);
    return 1;
}

void CloneMCJ_World_NotifyBlockOfNeighborChange(CloneMCJ_World *world, int x, int y,
    int z, int neighborID)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if (!world || world->multiplayerWorld || y < 0 || y >= 128) { return; }
    if (world->neighborNotifyDepth >= 64) {
        ++world->neighborNotificationsDropped;
        return;
    }
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    block = CloneMCJ_BlockRegistry_Get(id);
    if (!block || !block->neighborChanged) { return; }
    ++world->neighborNotifyDepth;
    ++world->neighborNotifications;
    block->neighborChanged(world, x, y, z, neighborID);
    --world->neighborNotifyDepth;
}

void CloneMCJ_World_NotifyBlocksOfNeighborChange(CloneMCJ_World *world, int x, int y,
    int z, int neighborID)
{
    if (!world || world->editingBlocks) { return; }
    CloneMCJ_World_NotifyBlockOfNeighborChange(world, x - 1, y, z, neighborID);
    CloneMCJ_World_NotifyBlockOfNeighborChange(world, x + 1, y, z, neighborID);
    CloneMCJ_World_NotifyBlockOfNeighborChange(world, x, y - 1, z, neighborID);
    CloneMCJ_World_NotifyBlockOfNeighborChange(world, x, y + 1, z, neighborID);
    CloneMCJ_World_NotifyBlockOfNeighborChange(world, x, y, z - 1, neighborID);
    CloneMCJ_World_NotifyBlockOfNeighborChange(world, x, y, z + 1, neighborID);
}

int CloneMCJ_World_SetBlockWithMetadataNotify(CloneMCJ_World *world, int x, int y,
    int z, int blockID, int metadata)
{
    if (!CloneMCJ_World_SetBlockWithMetadata(world, x, y, z, blockID, metadata)) return 0;
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world, x, y, z, blockID);
    return 1;
}

int CloneMCJ_World_SetBlockNotify(CloneMCJ_World *world, int x, int y, int z, int blockID)
{
    return CloneMCJ_World_SetBlockWithMetadataNotify(world, x, y, z, blockID, 0);
}

int CloneMCJ_World_SetBlockMetadataNotify(CloneMCJ_World *world, int x, int y, int z,
    int metadata)
{
    int id;
    if (!world) return 0;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (!CloneMCJ_World_SetBlockMetadata(world, x, y, z, metadata)) return 0;
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world, x, y, z, id);
    return 1;
}

static int CloneMCJ_World_IsNormalCubeForPower(CloneMCJ_World *world,
    int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

static int CloneMCJ_World_TorchWeakPower(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    int metadata;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=76)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(metadata==5&&side==1)return 0;
    if(metadata==3&&side==3)return 0;
    if(metadata==4&&side==2)return 0;
    if(metadata==1&&side==5)return 0;
    return metadata!=2||side!=4;
}

static int CloneMCJ_World_RepeaterPower(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    int direction;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=94)return 0;
    direction=CloneMCJ_World_GetBlockMetadata(world,x,y,z)&3;
    if(direction==0&&side==3)return 1;
    if(direction==1&&side==4)return 1;
    if(direction==2&&side==2)return 1;
    return direction==3&&side==5;
}

/* World.java isBlockProvidingPowerTo: asks a block for strong/directional power. */
int CloneMCJ_World_IsBlockProvidingPowerTo(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    int id,metadata,orientation;
    if(!world)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id==0)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(id==69){
        if((metadata&8)==0)return 0;
        orientation=metadata&7;
        return ((orientation==5||orientation==6)&&side==1)||
            (orientation==4&&side==2)||(orientation==3&&side==3)||
            (orientation==2&&side==4)||(orientation==1&&side==5);
    }
    if(id==77){
        if((metadata&8)==0)return 0;
        orientation=metadata&7;
        return (orientation==5&&side==1)||(orientation==4&&side==2)||
            (orientation==3&&side==3)||(orientation==2&&side==4)||
            (orientation==1&&side==5);
    }
    if(id==70||id==72)return metadata>0&&side==1;
    if(id==94)return CloneMCJ_World_RepeaterPower(world,x,y,z,side);
    if(id==55)return CloneMCJ_BlockRedstoneWire_IsPoweringToNative(world,x,y,z,side);
    if(id==76)return side==0&&CloneMCJ_World_TorchWeakPower(world,x,y,z,side);
    return 0;
}

int CloneMCJ_World_IsBlockGettingPowered(CloneMCJ_World *world,int x,int y,int z)
{
    if(!world)return 0;
    if(CloneMCJ_World_IsBlockProvidingPowerTo(world,x,y-1,z,0))return 1;
    if(CloneMCJ_World_IsBlockProvidingPowerTo(world,x,y+1,z,1))return 1;
    if(CloneMCJ_World_IsBlockProvidingPowerTo(world,x,y,z-1,2))return 1;
    if(CloneMCJ_World_IsBlockProvidingPowerTo(world,x,y,z+1,3))return 1;
    if(CloneMCJ_World_IsBlockProvidingPowerTo(world,x-1,y,z,4))return 1;
    return CloneMCJ_World_IsBlockProvidingPowerTo(world,x+1,y,z,5);
}

/* World.java isBlockIndirectlyProvidingPowerTo: normal cubes relay strong input;
 * non-cubes provide their ordinary weak power on the requested face. */
int CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    int id,metadata;
    if(!world)return 0;
    if(CloneMCJ_World_IsNormalCubeForPower(world,x,y,z))
        return CloneMCJ_World_IsBlockGettingPowered(world,x,y,z);
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id==0)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(id==69||id==77)return (metadata&8)!=0;
    if(id==70||id==72)return metadata>0;
    if(id==94)return CloneMCJ_World_RepeaterPower(world,x,y,z,side);
    if(id==55)return CloneMCJ_BlockRedstoneWire_IsPoweringToNative(world,x,y,z,side);
    if(id==76)return CloneMCJ_World_TorchWeakPower(world,x,y,z,side);
    return 0;
}

int CloneMCJ_World_IsBlockIndirectlyGettingPowered(CloneMCJ_World *world,
    int x,int y,int z)
{
    if(!world)return 0;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y-1,z,0))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y+1,z,1))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y,z-1,2))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y,z+1,3))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x-1,y,z,4))return 1;
    return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x+1,y,z,5);
}

int CloneMCJ_World_IsAirBlock(CloneMCJ_World *world, int x, int y, int z)
{
    return CloneMCJ_World_GetBlockId(world, x, y, z) == CLONEMC_J_BLOCK_AIR;
}

int CloneMCJ_World_IsWaterBlock(int id)
{
    return id == CLONEMC_J_BLOCK_WATER_MOVING || id == CLONEMC_J_BLOCK_WATER_STILL;
}

int CloneMCJ_World_IsLiquidBlock(int id)
{
    return CloneMCJ_World_IsWaterBlock(id) || id == CLONEMC_J_BLOCK_LAVA_MOVING || id == CLONEMC_J_BLOCK_LAVA_STILL;
}

int CloneMCJ_World_IsSolidBlockID(int id)
{
    if (id == CLONEMC_J_BLOCK_AIR || CloneMCJ_World_IsLiquidBlock(id)) { return 0; }
    if (id == CLONEMC_J_BLOCK_LEAVES || id == CLONEMC_J_BLOCK_TALL_GRASS || id == CLONEMC_J_BLOCK_DEAD_BUSH ||
        id == CLONEMC_J_BLOCK_PLANT_YELLOW || id == CLONEMC_J_BLOCK_PLANT_RED ||
        id == CLONEMC_J_BLOCK_MUSHROOM_BROWN || id == CLONEMC_J_BLOCK_MUSHROOM_RED ||
        id == CLONEMC_J_BLOCK_SNOW || id == CLONEMC_J_BLOCK_REED) { return 0; }
    return 1;
}

int CloneMCJ_World_IsReplaceableForTree(int id)
{
    return id == CLONEMC_J_BLOCK_AIR || id == CLONEMC_J_BLOCK_LEAVES;
}

int CloneMCJ_World_CanPlantStay(CloneMCJ_World *world, int x, int y, int z, int plantID)
{
    int below;
    if (!world || y <= 0 || y >= 128 || !CloneMCJ_World_IsAirBlock(world, x, y, z)) { return 0; }
    below = CloneMCJ_World_GetBlockId(world, x, y - 1, z);
    if (plantID == CLONEMC_J_BLOCK_DEAD_BUSH) { return below == CLONEMC_J_BLOCK_SAND; }
    if (plantID == CLONEMC_J_BLOCK_MUSHROOM_BROWN || plantID == CLONEMC_J_BLOCK_MUSHROOM_RED) {
        return below != CLONEMC_J_BLOCK_AIR && !CloneMCJ_World_IsLiquidBlock(below);
    }
    return below == CLONEMC_J_BLOCK_GRASS || below == CLONEMC_J_BLOCK_DIRT;
}

int CloneMCJ_World_CanReedStay(CloneMCJ_World *world, int x, int y, int z)
{
    int below;
    if (!world || y <= 0 || y >= 128) { return 0; }
    below = CloneMCJ_World_GetBlockId(world, x, y - 1, z);
    if (below == CLONEMC_J_BLOCK_REED) { return 1; }
    if (below != CLONEMC_J_BLOCK_GRASS && below != CLONEMC_J_BLOCK_DIRT) { return 0; }
    return CloneMCJ_World_IsWaterBlock(CloneMCJ_World_GetBlockId(world, x - 1, y - 1, z)) ||
           CloneMCJ_World_IsWaterBlock(CloneMCJ_World_GetBlockId(world, x + 1, y - 1, z)) ||
           CloneMCJ_World_IsWaterBlock(CloneMCJ_World_GetBlockId(world, x, y - 1, z - 1)) ||
           CloneMCJ_World_IsWaterBlock(CloneMCJ_World_GetBlockId(world, x, y - 1, z + 1));
}

int CloneMCJ_World_CanCactusStay(CloneMCJ_World *world, int x, int y, int z)
{
    int below;
    if (!world || y <= 0 || y >= 128) { return 0; }
    if (CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world, x - 1, y, z)) ||
        CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world, x + 1, y, z)) ||
        CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world, x, y, z - 1)) ||
        CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world, x, y, z + 1))) { return 0; }
    below = CloneMCJ_World_GetBlockId(world, x, y - 1, z);
    return below == CLONEMC_J_BLOCK_CACTUS || below == CLONEMC_J_BLOCK_SAND;
}

int CloneMCJ_World_GetSavedLightValue(CloneMCJ_World *world, int skyBlock, int x, int y, int z)
{
    CloneMCJ_Chunk *chunk;
    if (!world) { return skyBlock == CLONEMC_J_ENUM_SKY_BLOCK_SKY ? 15 : 0; }
    if (y < 0) { y = 0; }
    if (y >= 128) { y = 127; }
    if(world->multiplayerWorld){
        if(!CloneMCJ_ChunkProviderClient_ChunkExists(&((CloneMCJ_WorldClient *)world)->clientChunkProvider,
            CloneMCJ_World_GlobalToChunk(x),CloneMCJ_World_GlobalToChunk(z)))return 0;
    }else if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
            CloneMCJ_World_GlobalToChunk(x), CloneMCJ_World_GlobalToChunk(z))) { return 0; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, x, z);
    if (!chunk) { return 0; }
    return CloneMCJ_Chunk_GetSavedLightValue(chunk, skyBlock, CloneMCJ_World_GlobalToLocal(x), y, CloneMCJ_World_GlobalToLocal(z));
}

int CloneMCJ_World_ScheduleBlockUpdate(CloneMCJ_World *world, int blockX, int y, int blockZ, int blockID, CloneMCJLong delay)
{
    CloneMCJ_Chunk *chunk;
    int i;
    if (!world || y < 0 || y >= 128 || world->multiplayerWorld) { return 0; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, blockX, blockZ);
    if (!chunk) { return 0; }
    for (i = 0; i < (int)chunk->scheduledTickCount; ++i) {
        if (chunk->scheduledTicks[i].xCoord == blockX && chunk->scheduledTicks[i].yCoord == y &&
            chunk->scheduledTicks[i].zCoord == blockZ && chunk->scheduledTicks[i].blockID == blockID) {
            return 1;
        }
    }
    if (delay < (CloneMCJLong)0) delay = (CloneMCJLong)0;
    if (!CloneMCJ_Chunk_ScheduleTick(chunk, CloneMCJ_World_GlobalToLocal(blockX), y,
            CloneMCJ_World_GlobalToLocal(blockZ), blockID, world->worldTime + delay)) {
        ++world->scheduledTicksDropped;
        return 0;
    }
    return 1;
}

void CloneMCJ_World_TickTime(CloneMCJ_World *world, int ticks)
{
    if (!world) { return; }
    if (ticks > 0) { world->worldTime += (CloneMCJLong)ticks; world->worldInfo.worldTime = world->worldTime; }
}

int CloneMCJ_World_GetBlockLightOpacity(int blockID)
{
    if (blockID <= 0) { return 0; }
    switch (blockID & 255) {
    case 6: case CLONEMC_J_BLOCK_GLASS: case 27: case 28: case 30:
    case CLONEMC_J_BLOCK_TALL_GRASS: case CLONEMC_J_BLOCK_DEAD_BUSH:
    case 33: case 34: case 36: case CLONEMC_J_BLOCK_PLANT_YELLOW:
    case CLONEMC_J_BLOCK_PLANT_RED: case CLONEMC_J_BLOCK_MUSHROOM_BROWN:
    case CLONEMC_J_BLOCK_MUSHROOM_RED: case CLONEMC_J_BLOCK_TORCH:
    case CLONEMC_J_BLOCK_FIRE: case 55: case 59: case 63: case 64:
    case 65: case 66: case 68: case 69: case 70: case 71: case 72:
    case 75: case CLONEMC_J_BLOCK_REDSTONE_TORCH_ACTIVE: case 77:
    case CLONEMC_J_BLOCK_SNOW: case CLONEMC_J_BLOCK_REED:
    case CLONEMC_J_BLOCK_PORTAL: case 92: case 93: case 94: case 96:
    case 115:
        return 0;
    case CLONEMC_J_BLOCK_LEAVES:
        return 1;
    case CLONEMC_J_BLOCK_WATER_MOVING: case CLONEMC_J_BLOCK_WATER_STILL:
    case CLONEMC_J_BLOCK_ICE:
        return 3;
    default:
        return 255;
    }
}

int CloneMCJ_World_GetBlockLightEmission(int blockID)
{
    switch (blockID & 255) {
    case CLONEMC_J_BLOCK_LAVA_MOVING: case CLONEMC_J_BLOCK_LAVA_STILL:
    case CLONEMC_J_BLOCK_FIRE: case CLONEMC_J_BLOCK_GLOWSTONE:
    case CLONEMC_J_BLOCK_PUMPKIN_LANTERN:
        return 15;
    case CLONEMC_J_BLOCK_TORCH:
        return 14;
    case CLONEMC_J_BLOCK_FURNACE_ACTIVE:
        return 13;
    case CLONEMC_J_BLOCK_PORTAL:
        return 11;
    case CLONEMC_J_BLOCK_ORE_REDSTONE_GLOWING:
        return 9;
    case CLONEMC_J_BLOCK_REDSTONE_TORCH_ACTIVE:
        return 7;
    case CLONEMC_J_BLOCK_MUSHROOM_BROWN:
        return 1;
    default:
        return 0;
    }
}

float CloneMCJ_World_GetRainStrength(const CloneMCJ_World *world, float partialTick)
{
    if (!world) { return 0.0F; }
    return world->prevRainingStrength +
        (world->rainingStrength - world->prevRainingStrength) * partialTick;
}

float CloneMCJ_World_GetThunderStrength(const CloneMCJ_World *world, float partialTick)
{
    float thunder;
    if (!world) { return 0.0F; }
    thunder = world->prevThunderingStrength +
        (world->thunderingStrength - world->prevThunderingStrength) * partialTick;
    return thunder * CloneMCJ_World_GetRainStrength(world, partialTick);
}

void CloneMCJ_World_UpdateWeather(CloneMCJ_World *world)
{
    int timer;
    if (!world || world->worldProvider.hasNoSky) { return; }
    if (world->lightningFlash > 0) { --world->lightningFlash; }
    timer = world->worldInfo.thunderTime;
    if (timer <= 0) {
        if (world->worldInfo.thundering) { timer = CloneMCJavaRandom_NextIntBound(&world->rand, 12000) + 3600; }
        else { timer = CloneMCJavaRandom_NextIntBound(&world->rand, 0x29040L) + 12000; }
    } else {
        --timer;
        if (timer <= 0) { world->worldInfo.thundering = (unsigned char)!world->worldInfo.thundering; }
    }
    world->worldInfo.thunderTime = timer;
    timer = world->worldInfo.rainTime;
    if (timer <= 0) {
        if (world->worldInfo.raining) { timer = CloneMCJavaRandom_NextIntBound(&world->rand, 12000) + 12000; }
        else { timer = CloneMCJavaRandom_NextIntBound(&world->rand, 0x29040L) + 12000; }
    } else {
        --timer;
        if (timer <= 0) { world->worldInfo.raining = (unsigned char)!world->worldInfo.raining; }
    }
    world->worldInfo.rainTime = timer;
    world->prevRainingStrength = world->rainingStrength;
    world->rainingStrength += world->worldInfo.raining ? 0.01F : -0.01F;
    if (world->rainingStrength < 0.0F) { world->rainingStrength = 0.0F; }
    if (world->rainingStrength > 1.0F) { world->rainingStrength = 1.0F; }
    world->prevThunderingStrength = world->thunderingStrength;
    world->thunderingStrength += world->worldInfo.thundering ? 0.01F : -0.01F;
    if (world->thunderingStrength < 0.0F) { world->thunderingStrength = 0.0F; }
    if (world->thunderingStrength > 1.0F) { world->thunderingStrength = 1.0F; }
}

void CloneMCJ_World_StopPrecipitation(CloneMCJ_World *world)
{
    if (!world) { return; }
    world->worldInfo.rainTime = 0;
    world->worldInfo.raining = 0;
    world->worldInfo.thunderTime = 0;
    world->worldInfo.thundering = 0;
}

float CloneMCJ_World_GetCelestialAngle(const CloneMCJ_World *world, float partialTick)
{
    if (!world) { return 0.0F; }
    if (world->worldProvider.isHellWorld) return 0.5F;
    if (world->worldProvider.worldType == 1) return 0.0F;
    return CloneMCJ_WorldProvider_CalculateCelestialAngle(world->worldTime, partialTick);
}

int CloneMCJ_World_CalculateSkylightSubtracted(const CloneMCJ_World *world, float partialTick)
{
    float angle;
    float darkness;
    float rain;
    float thunder;
    if (!world || world->worldProvider.hasNoSky) { return 0; }
    angle = CloneMCJ_World_GetCelestialAngle(world, partialTick);
    darkness = 1.0F - (CloneMCMathHelper_Cos(angle * 3.141593F * 2.0F) * 2.0F + 0.5F);
    if (darkness < 0.0F) { darkness = 0.0F; }
    if (darkness > 1.0F) { darkness = 1.0F; }
    darkness = 1.0F - darkness;
    rain = CloneMCJ_World_GetRainStrength(world, partialTick);
    thunder = CloneMCJ_World_GetThunderStrength(world, partialTick);
    darkness *= 1.0F - rain * 5.0F / 16.0F;
    darkness *= 1.0F - thunder * 5.0F / 16.0F;
    darkness = 1.0F - darkness;
    return (int)(darkness * 11.0F);
}

float CloneMCJ_World_GetStarBrightness(const CloneMCJ_World *world, float partialTick)
{
    float angle;
    float brightness;
    if (!world) { return 0.0F; }
    angle = CloneMCJ_World_GetCelestialAngle(world, partialTick);
    brightness = 1.0F - (CloneMCMathHelper_Cos(angle * 3.141593F * 2.0F) * 2.0F + 0.75F);
    if (brightness < 0.0F) { brightness = 0.0F; }
    if (brightness > 1.0F) { brightness = 1.0F; }
    return brightness * brightness * 0.5F;
}

void CloneMCJ_World_GetSkyColor(const CloneMCJ_World *world, float partialTick,
    float *red, float *green, float *blue)
{
    float angle;
    float daylight;
    float r;
    float g;
    float b;
    float weather;
    float gray;
    if (!world) { return; }
    if (world->worldProvider.isHellWorld) {
        CloneMCJ_WorldProviderHell_GetFogColor(red, green, blue);
        return;
    }
    angle = CloneMCJ_World_GetCelestialAngle(world, partialTick);
    if (world->worldProvider.worldType == 1) {
        CloneMCJ_WorldProviderSky_GetSkyColor(angle, red, green, blue);
        return;
    }
    daylight = CloneMCMathHelper_Cos(angle * 3.141593F * 2.0F) * 2.0F + 0.5F;
    if (daylight < 0.0F) { daylight = 0.0F; }
    if (daylight > 1.0F) { daylight = 1.0F; }
    r = 0.5F * daylight;
    g = 0.7F * daylight;
    b = 1.0F * daylight;
    weather = CloneMCJ_World_GetRainStrength(world, partialTick);
    if (weather > 0.0F) {
        gray = (r * 0.3F + g * 0.59F + b * 0.11F) * 0.6F;
        daylight = 1.0F - weather * 0.75F;
        r = r * daylight + gray * (1.0F - daylight);
        g = g * daylight + gray * (1.0F - daylight);
        b = b * daylight + gray * (1.0F - daylight);
    }
    weather = CloneMCJ_World_GetThunderStrength(world, partialTick);
    if (weather > 0.0F) {
        gray = (r * 0.3F + g * 0.59F + b * 0.11F) * 0.2F;
        daylight = 1.0F - weather * 0.75F;
        r = r * daylight + gray * (1.0F - daylight);
        g = g * daylight + gray * (1.0F - daylight);
        b = b * daylight + gray * (1.0F - daylight);
    }
    if (red) { *red = r; }
    if (green) { *green = g; }
    if (blue) { *blue = b; }
}

static void CloneMCJ_World_HSBToRGB(float hue, float saturation, float brightness,
    float *red, float *green, float *blue)
{
    float h;
    float fraction;
    float p;
    float q;
    float t;
    int sector;
    if (saturation <= 0.0F) {
        if (red) { *red = brightness; }
        if (green) { *green = brightness; }
        if (blue) { *blue = brightness; }
        return;
    }
    h = (hue - (float)floor((double)hue)) * 6.0F;
    sector = (int)h;
    fraction = h - (float)sector;
    p = brightness * (1.0F - saturation);
    q = brightness * (1.0F - saturation * fraction);
    t = brightness * (1.0F - saturation * (1.0F - fraction));
    switch (sector) {
    case 0: if(red)*red=brightness;if(green)*green=t;if(blue)*blue=p;break;
    case 1: if(red)*red=q;if(green)*green=brightness;if(blue)*blue=p;break;
    case 2: if(red)*red=p;if(green)*green=brightness;if(blue)*blue=t;break;
    case 3: if(red)*red=p;if(green)*green=q;if(blue)*blue=brightness;break;
    case 4: if(red)*red=t;if(green)*green=p;if(blue)*blue=brightness;break;
    default: if(red)*red=brightness;if(green)*green=p;if(blue)*blue=q;break;
    }
}

static void CloneMCJ_World_GetSkyColorAtInternal(const CloneMCJ_World *world,
    int blockX,int blockZ,float partialTick,int allowLightningFlash,
    float *red,float *green,float *blue)
{
    float angle;
    float daylight;
    float temperature;
    float r;
    float g;
    float b;
    float weather;
    float gray;
    float flash;
    if (!world) { return; }
    if (world->worldProvider.isHellWorld) {
        CloneMCJ_WorldProviderHell_GetFogColor(red,green,blue);
        return;
    }
    angle = CloneMCJ_World_GetCelestialAngle(world,partialTick);
    if (world->worldProvider.worldType == 1) {
        CloneMCJ_WorldProviderSky_GetSkyColor(angle,red,green,blue);
        return;
    }
    daylight = CloneMCMathHelper_Cos(angle*3.141593F*2.0F)*2.0F+0.5F;
    if (daylight < 0.0F) { daylight = 0.0F; }
    if (daylight > 1.0F) { daylight = 1.0F; }
    temperature = (float)CloneMCJ_WorldChunkManager_GetTemperature(
        (CloneMCJ_WorldChunkManager *)&world->chunkManager,blockX,blockZ)/3.0F;
    if (temperature < -1.0F) { temperature = -1.0F; }
    if (temperature > 1.0F) { temperature = 1.0F; }
    CloneMCJ_World_HSBToRGB(0.6222222F-temperature*0.05F,
        0.5F+temperature*0.1F,1.0F,&r,&g,&b);
    r=(float)((int)(r*255.0F+0.5F))/255.0F;
    g=(float)((int)(g*255.0F+0.5F))/255.0F;
    b=(float)((int)(b*255.0F+0.5F))/255.0F;
    r*=daylight;g*=daylight;b*=daylight;
    weather=CloneMCJ_World_GetRainStrength(world,partialTick);
    if(weather>0.0F){gray=(r*0.3F+g*0.59F+b*0.11F)*0.6F;
        daylight=1.0F-weather*0.75F;r=r*daylight+gray*(1.0F-daylight);
        g=g*daylight+gray*(1.0F-daylight);b=b*daylight+gray*(1.0F-daylight);}
    weather=CloneMCJ_World_GetThunderStrength(world,partialTick);
    if(weather>0.0F){gray=(r*0.3F+g*0.59F+b*0.11F)*0.2F;
        daylight=1.0F-weather*0.75F;r=r*daylight+gray*(1.0F-daylight);
        g=g*daylight+gray*(1.0F-daylight);b=b*daylight+gray*(1.0F-daylight);}
    if(allowLightningFlash&&world->lightningFlash>0){
        flash=(float)world->lightningFlash-partialTick;
        if(flash>1.0F)flash=1.0F;
        if(flash<0.0F)flash=0.0F;
        flash*=0.45F;
        r=r*(1.0F-flash)+0.8F*flash;g=g*(1.0F-flash)+0.8F*flash;
        b=b*(1.0F-flash)+flash;}
    if(red)*red=r;
    if(green)*green=g;
    if(blue)*blue=b;
}

void CloneMCJ_World_GetSkyColorAt(const CloneMCJ_World *world, int blockX,
    int blockZ, float partialTick, float *red, float *green, float *blue)
{
    CloneMCJ_World_GetSkyColorAtInternal(world,blockX,blockZ,partialTick,1,
        red,green,blue);
}

void CloneMCJ_World_GetSkyColorAtVisualSafe(const CloneMCJ_World *world,
    int blockX,int blockZ,float partialTick,float *red,float *green,float *blue)
{
    /* Preserve Java weather/daylight color, but omit its full-sky lightning
     * brightening.  The world lightning timer and gameplay event still tick. */
    CloneMCJ_World_GetSkyColorAtInternal(world,blockX,blockZ,partialTick,0,
        red,green,blue);
}

void CloneMCJ_World_GetCloudColor(const CloneMCJ_World *world, float partialTick,
    float *red, float *green, float *blue)
{
    float angle;
    float daylight;
    float r;
    float g;
    float b;
    float weather;
    float gray;
    if (!world) { return; }
    angle = CloneMCJ_World_GetCelestialAngle(world, partialTick);
    daylight = CloneMCMathHelper_Cos(angle * 3.141593F * 2.0F) * 2.0F + 0.5F;
    if (daylight < 0.0F) { daylight = 0.0F; }
    if (daylight > 1.0F) { daylight = 1.0F; }
    r = daylight * 0.9F + 0.1F;
    g = daylight * 0.9F + 0.1F;
    b = daylight * 0.85F + 0.15F;
    weather = CloneMCJ_World_GetRainStrength(world, partialTick);
    if (weather > 0.0F) {
        gray = (r * 0.3F + g * 0.59F + b * 0.11F) * 0.6F;
        daylight = 1.0F - weather * 0.95F;
        r = r * daylight + gray * (1.0F - daylight);
        g = g * daylight + gray * (1.0F - daylight);
        b = b * daylight + gray * (1.0F - daylight);
    }
    weather = CloneMCJ_World_GetThunderStrength(world, partialTick);
    if (weather > 0.0F) {
        gray = (r * 0.3F + g * 0.59F + b * 0.11F) * 0.2F;
        daylight = 1.0F - weather * 0.95F;
        r = r * daylight + gray * (1.0F - daylight);
        g = g * daylight + gray * (1.0F - daylight);
        b = b * daylight + gray * (1.0F - daylight);
    }
    if (red) { *red = r; }
    if (green) { *green = g; }
    if (blue) { *blue = b; }
}

int CloneMCJ_World_CanExistingBlockSeeTheSky(CloneMCJ_World *world, int x, int y, int z)
{
    CloneMCJ_Chunk *chunk;
    if (!world || y < 0) { return 0; }
    if (y >= 128) { return 1; }
    if (world->multiplayerWorld) {
        if (!CloneMCJ_ChunkProviderClient_ChunkExists(&((CloneMCJ_WorldClient *)world)->clientChunkProvider,
                CloneMCJ_World_GlobalToChunk(x), CloneMCJ_World_GlobalToChunk(z))) { return 0; }
    } else if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
            CloneMCJ_World_GlobalToChunk(x), CloneMCJ_World_GlobalToChunk(z))) { return 0; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, x, z);
    return CloneMCJ_Chunk_CanBlockSeeTheSky(chunk, CloneMCJ_World_GlobalToLocal(x), y,
        CloneMCJ_World_GlobalToLocal(z));
}

int CloneMCJ_World_CanBlockBeRainedOn(CloneMCJ_World *world, int x, int y, int z)
{
    const CloneMCJ_BiomeGenBase *biome;
    if (!world || world->worldProvider.isHellWorld ||
        CloneMCJ_World_GetRainStrength(world, 1.0F) <= 0.2F) return 0;
    if (!CloneMCJ_World_CanExistingBlockSeeTheSky(world, x, y, z)) return 0;
    if (CloneMCJ_World_FindTopSolidBlock(world, x, z) > y) return 0;
    biome = CloneMCJ_WorldChunkManager_GetBiomeGenAt(&world->chunkManager, x, z);
    return CloneMCJ_BiomeGenBase_CanSpawnLightningBolt(biome);
}

void CloneMCJ_World_SetLightValue(CloneMCJ_World *world, int skyBlock, int x, int y, int z, int value)
{
    CloneMCJ_Chunk *chunk;
    if (!world || y < 0 || y >= 128 || world->multiplayerWorld) { return; }
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
            CloneMCJ_World_GlobalToChunk(x), CloneMCJ_World_GlobalToChunk(z))) { return; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, x, z);
    CloneMCJ_Chunk_SetLightValue(chunk, skyBlock, CloneMCJ_World_GlobalToLocal(x), y,
        CloneMCJ_World_GlobalToLocal(z), value);
    /* Light is vertex color in the fixed-function renderer.  Rebuild the
     * owning mesh and an edge neighbor when a propagated value crosses a
     * chunk boundary, without loading or generating any hidden chunks. */
    CloneMCJ_World_MarkEditMeshesDirty(world,x,z);
}

int CloneMCJ_World_GetBlockLightValue(CloneMCJ_World *world, int x, int y, int z)
{
    CloneMCJ_Chunk *chunk;
    if (!world || y < 0) { return 0; }
    if (y >= 128) { y = 127; }
    chunk=CloneMCJ_World_FindLoadedChunk(world,CloneMCJ_World_GlobalToChunk(x),
        CloneMCJ_World_GlobalToChunk(z));
    if(!chunk)return 0;
    return CloneMCJ_Chunk_GetBlockLightValue(chunk, CloneMCJ_World_GlobalToLocal(x), y,
        CloneMCJ_World_GlobalToLocal(z), world->skylightSubtracted);
}

int CloneMCJ_World_GetFullBlockLightValue(CloneMCJ_World *world, int x, int y, int z)
{
    CloneMCJ_Chunk *chunk;
    if(!world||y<0)return 0;
    if(y>=CLONEMC_J_CHUNK_HEIGHT)y=CLONEMC_J_CHUNK_HEIGHT-1;
    chunk=CloneMCJ_World_FindLoadedChunk(world,
        CloneMCJ_World_GlobalToChunk(x),CloneMCJ_World_GlobalToChunk(z));
    if(!chunk)return 0;
    /* Chunk.getBlockLightValue(..., 0) is Java's full-brightness query.  The
     * old wrapper temporarily changed world state and accidentally left
     * processingScheduledTicks set forever, suppressing later tick work. */
    return CloneMCJ_Chunk_GetBlockLightValue(chunk,
        CloneMCJ_World_GlobalToLocal(x),y,
        CloneMCJ_World_GlobalToLocal(z),0);
}

int CloneMCJ_World_ScheduleLightingUpdate(CloneMCJ_World *world, int skyBlock,
    int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
{
    int i;
    int first;
    int centerX;
    int centerZ;
    if (!world || (world->worldProvider.hasNoSky && skyBlock == CLONEMC_J_ENUM_SKY_BLOCK_SKY)) { return 0; }
    if (world->lightingUpdatesScheduled >= 49) { return 0; }
    ++world->lightingUpdatesScheduled;
    centerX = (minX + maxX) / 2;
    centerZ = (minZ + maxZ) / 2;
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
            CloneMCJ_World_GlobalToChunk(centerX), CloneMCJ_World_GlobalToChunk(centerZ))) {
        --world->lightingUpdatesScheduled;
        return 0;
    }
    first = world->lightingUpdateCount > 5 ? world->lightingUpdateCount - 5 : 0;
    for (i = world->lightingUpdateCount - 1; i >= first; --i) {
        if (world->lightingToUpdate[i].skyBlock == skyBlock &&
            CloneMCJ_MetadataChunkBlock_CanCombine(&world->lightingToUpdate[i],
                minX, minY, minZ, maxX, maxY, maxZ)) {
            --world->lightingUpdatesScheduled;
            return 1;
        }
    }
    if (world->lightingUpdateCount >= CLONEMC_J_LIGHT_UPDATE_CAPACITY) {
        int resetCursor;
        resetCursor=0;
        if(world->lightingRegionsDropped!=~0UL)++world->lightingRegionsDropped;
        if(skyBlock>=0&&skyBlock<2){
            if(!world->lightingOverflowActive[skyBlock]){
                world->lightingOverflowActive[skyBlock]=1;
                world->lightingOverflowMinX[skyBlock]=minX;
                world->lightingOverflowMinY[skyBlock]=minY;
                world->lightingOverflowMinZ[skyBlock]=minZ;
                world->lightingOverflowMaxX[skyBlock]=maxX;
                world->lightingOverflowMaxY[skyBlock]=maxY;
                world->lightingOverflowMaxZ[skyBlock]=maxZ;
                resetCursor=1;
            }else{
                if(minX<world->lightingOverflowMinX[skyBlock]){
                    world->lightingOverflowMinX[skyBlock]=minX;resetCursor=1;}
                if(minY<world->lightingOverflowMinY[skyBlock]){
                    world->lightingOverflowMinY[skyBlock]=minY;resetCursor=1;}
                if(minZ<world->lightingOverflowMinZ[skyBlock]){
                    world->lightingOverflowMinZ[skyBlock]=minZ;resetCursor=1;}
                if(maxX>world->lightingOverflowMaxX[skyBlock])
                    world->lightingOverflowMaxX[skyBlock]=maxX;
                if(maxY>world->lightingOverflowMaxY[skyBlock])
                    world->lightingOverflowMaxY[skyBlock]=maxY;
                if(maxZ>world->lightingOverflowMaxZ[skyBlock])
                    world->lightingOverflowMaxZ[skyBlock]=maxZ;
            }
            if(resetCursor){
                world->lightingOverflowCursorX[skyBlock]=world->lightingOverflowMinX[skyBlock];
                world->lightingOverflowCursorY[skyBlock]=world->lightingOverflowMinY[skyBlock];
                world->lightingOverflowCursorZ[skyBlock]=world->lightingOverflowMinZ[skyBlock];
            }
        }
        --world->lightingUpdatesScheduled;
        return 0;
    }
    CloneMCJ_MetadataChunkBlock_Initialize(&world->lightingToUpdate[world->lightingUpdateCount++],
        skyBlock, minX, minY, minZ, maxX, maxY, maxZ);
    --world->lightingUpdatesScheduled;
    return 1;
}

void CloneMCJ_World_NeighborLightPropagationChanged(CloneMCJ_World *world, int skyBlock,
    int x, int y, int z, int expectedLight)
{
    int blockID;
    int emission;
    if (!world || y < 0 || y >= 128) { return; }
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,
            CloneMCJ_World_GlobalToChunk(x), CloneMCJ_World_GlobalToChunk(z))) { return; }
    if (skyBlock == CLONEMC_J_ENUM_SKY_BLOCK_SKY &&
        CloneMCJ_World_CanExistingBlockSeeTheSky(world, x, y, z)) { expectedLight = 15; }
    if (skyBlock == CLONEMC_J_ENUM_SKY_BLOCK_BLOCK) {
        blockID = CloneMCJ_World_GetBlockId(world, x, y, z);
        emission = CloneMCJ_World_GetBlockLightEmission(blockID);
        if (emission > expectedLight) { expectedLight = emission; }
    }
    if (CloneMCJ_World_GetSavedLightValue(world, skyBlock, x, y, z) != expectedLight) {
        CloneMCJ_World_ScheduleLightingUpdate(world, skyBlock, x, y, z, x, y, z);
    }
}

static int CloneMCJ_World_QueueOverflowLightingSlice(CloneMCJ_World *world,int skyBlock)
{
    int minX,minY,minZ,maxX,maxY,maxZ;
    if(!world||skyBlock<0||skyBlock>1||!world->lightingOverflowActive[skyBlock]||
       world->lightingUpdateCount>=CLONEMC_J_LIGHT_UPDATE_CAPACITY)return 0;
    minX=world->lightingOverflowCursorX[skyBlock];
    minY=world->lightingOverflowCursorY[skyBlock];
    minZ=world->lightingOverflowCursorZ[skyBlock];
    maxX=minX+15;if(maxX>world->lightingOverflowMaxX[skyBlock])
        maxX=world->lightingOverflowMaxX[skyBlock];
    maxY=minY+15;if(maxY>world->lightingOverflowMaxY[skyBlock])
        maxY=world->lightingOverflowMaxY[skyBlock];
    maxZ=minZ+15;if(maxZ>world->lightingOverflowMaxZ[skyBlock])
        maxZ=world->lightingOverflowMaxZ[skyBlock];
    CloneMCJ_MetadataChunkBlock_Initialize(
        &world->lightingToUpdate[world->lightingUpdateCount++],skyBlock,
        minX,minY,minZ,maxX,maxY,maxZ);
    if(world->lightingOverflowSlicesRecovered!=~0UL)
        ++world->lightingOverflowSlicesRecovered;
    world->lightingOverflowCursorY[skyBlock]+=16;
    if(world->lightingOverflowCursorY[skyBlock]>world->lightingOverflowMaxY[skyBlock]){
        world->lightingOverflowCursorY[skyBlock]=world->lightingOverflowMinY[skyBlock];
        world->lightingOverflowCursorZ[skyBlock]+=16;
        if(world->lightingOverflowCursorZ[skyBlock]>world->lightingOverflowMaxZ[skyBlock]){
            world->lightingOverflowCursorZ[skyBlock]=world->lightingOverflowMinZ[skyBlock];
            world->lightingOverflowCursorX[skyBlock]+=16;
            if(world->lightingOverflowCursorX[skyBlock]>world->lightingOverflowMaxX[skyBlock])
                world->lightingOverflowActive[skyBlock]=0;
        }
    }
    return 1;
}

int CloneMCJ_World_UpdatingLighting(CloneMCJ_World *world)
{
    int budget,recoveryBudget,skyBlock;
    CloneMCJ_MetadataChunkBlock region;
    if (!world || world->lightingUpdatesCounter >= 50) { return 0; }
    ++world->lightingUpdatesCounter;
    budget = CLONEMC_J_LIGHT_UPDATES_PER_TICK;
    while (world->lightingUpdateCount > 0 && budget-- > 0) {
        /* World.updatingLighting removes the newest MetadataChunkBlock and
         * processes at most 500 regions.  This remains a hard per-update bound
         * for legacy systems while preventing stale torch/skylight from taking
         * hundreds of ticks to disappear from vertex-colored chunk meshes. */
        region = world->lightingToUpdate[--world->lightingUpdateCount];
        CloneMCJ_MetadataChunkBlock_Process(&region, world);
        if(world->lightingRegionsProcessed!=~0UL)++world->lightingRegionsProcessed;
    }
    /* Recovery is deliberately much smaller than the normal 500-region
     * budget.  At most four 16x16x16 regions are admitted after the queue has
     * drained, so relighting cannot monopolize a Windows 98 frame. */
    recoveryBudget=4;
    for(skyBlock=0;skyBlock<2&&recoveryBudget>0;++skyBlock)
        while(recoveryBudget>0&&world->lightingOverflowActive[skyBlock]&&
              world->lightingUpdateCount<CLONEMC_J_LIGHT_UPDATE_CAPACITY){
            if(!CloneMCJ_World_QueueOverflowLightingSlice(world,skyBlock))break;
            --recoveryBudget;
        }
    --world->lightingUpdatesCounter;
    return world->lightingUpdateCount != 0||
        world->lightingOverflowActive[0]||world->lightingOverflowActive[1];
}

void CloneMCJ_World_RegisterBlockTick(CloneMCJ_World *world, int blockID, int tickOnLoad,
    CloneMCJ_BlockTickProc callback, void *userData)
{
    if (!world || blockID < 0 || blockID > 255) { return; }
    world->tickOnLoad[blockID] = (unsigned char)(tickOnLoad ? 1 : 0);
    world->blockTickCallbacks[blockID] = callback;
    world->blockTickUserData[blockID] = userData;
}

void CloneMCJ_World_SetGameplayHooks(CloneMCJ_World *world, CloneMCJ_GameplayTickProc tickProc,
    CloneMCJ_GameplayPrepareSaveProc prepareSaveProc, void *userData)
{
    if (!world) { return; }
    world->gameplayTick = tickProc;
    world->gameplayPrepareSave = prepareSaveProc;
    world->gameplayUserData = userData;
}

void CloneMCJ_World_SetGameplayDimensionHook(CloneMCJ_World *world,
    CloneMCJ_GameplayDimensionProc dimensionProc)
{
    if(world)world->gameplayDimensionChanged=dimensionProc;
}

int CloneMCJ_World_ProcessScheduledTicks(CloneMCJ_World *world, int force)
{
    CloneMCJ_Chunk *bestChunk;
    CloneMCJ_Chunk *chunk;
    CloneMCJ_NextTickListEntry bestEntry;
    CloneMCJ_NextTickListEntry entry;
    int bestIndex;
    int slot;
    int index;
    int move;
    int found;
    int processed;
    int currentBlock;
    if (!world) { return 0; }
    processed = 0;
    while (processed < CLONEMC_J_SCHEDULED_TICKS_PER_TICK) {
        found = 0;
        bestChunk = 0;
        bestIndex = -1;
        for (slot = 0; slot < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++slot) {
            if (!world->chunkProvider.slots[slot].used || !world->chunkProvider.slots[slot].chunk) { continue; }
            chunk = world->chunkProvider.slots[slot].chunk;
            for (index = 0; index < (int)chunk->scheduledTickCount; ++index) {
                if (!found || CloneMCJ_NextTickListEntry_Compare(&chunk->scheduledTicks[index], &bestEntry) < 0) {
                    bestEntry = chunk->scheduledTicks[index];
                    bestChunk = chunk;
                    bestIndex = index;
                    found = 1;
                }
            }
        }
        if (!found || (!force && bestEntry.scheduledTime > world->worldTime)) { break; }
        entry = bestEntry;
        for (move = bestIndex + 1; move < (int)bestChunk->scheduledTickCount; ++move) {
            bestChunk->scheduledTicks[move - 1] = bestChunk->scheduledTicks[move];
        }
        --bestChunk->scheduledTickCount;
        currentBlock = CloneMCJ_World_GetBlockId(world, entry.xCoord, entry.yCoord, entry.zCoord);
        if (currentBlock == entry.blockID && currentBlock > 0 && world->blockTickCallbacks[currentBlock]) {
            world->blockTickCallbacks[currentBlock](world, entry.xCoord, entry.yCoord, entry.zCoord,
                currentBlock, &world->rand, world->blockTickUserData[currentBlock]);
        }
        ++processed;
    }
    world->scheduledTicksRun += (unsigned long)processed;
    world->processingScheduledTicks = 0;
    return processed;
}

void CloneMCJ_World_UpdateRandomBlocks(CloneMCJ_World *world)
{
    CloneMCJ_Chunk *chunk;
    int slot;
    int tick;
    int localX;
    int localY;
    int localZ;
    int blockID;
    CloneMCJInt bits;
    if (!world) { return; }
    for (slot = 0; slot < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++slot) {
        if (!world->chunkProvider.slots[slot].used || !world->chunkProvider.slots[slot].chunk) { continue; }
        chunk = world->chunkProvider.slots[slot].chunk;
        if (CloneMCJavaRandom_NextIntBound(&world->rand, 16) == 0) {
            int weatherX;
            int weatherY;
            int weatherZ;
            int belowID;
            int targetID;
            int globalX;
            int globalZ;
            const CloneMCJ_BiomeGenBase *biome;
            const CloneMCJ_BlockDefinition *support;
            world->randomTickLCG = CloneMCJava_AddInt(
                CloneMCJava_MulInt(world->randomTickLCG, 3), (CloneMCJInt)0x3C6EF35FL);
            bits = world->randomTickLCG >> 2;
            weatherX = bits & 15;
            weatherZ = (bits >> 8) & 15;
            weatherY = CloneMCJ_Chunk_GetHeightValue(chunk, weatherX, weatherZ);
            globalX = chunk->xPosition * 16 + weatherX;
            globalZ = chunk->zPosition * 16 + weatherZ;
            biome = CloneMCJ_WorldChunkManager_GetBiomeGenAt(&world->chunkManager,
                globalX, globalZ);
            if (CloneMCJ_BiomeGenBase_GetEnableSnow(biome) && weatherY >= 0 &&
                weatherY < 128 && CloneMCJ_Chunk_GetSavedLightValue(chunk,
                    CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, weatherX, weatherY, weatherZ) < 10) {
                belowID = weatherY > 0 ? CloneMCJ_Chunk_GetBlockID(chunk,
                    weatherX, weatherY - 1, weatherZ) : 0;
                targetID = CloneMCJ_Chunk_GetBlockID(chunk, weatherX, weatherY, weatherZ);
                support = CloneMCJ_BlockRegistry_Get(belowID);
                if (CloneMCJ_World_GetRainStrength(world, 1.0F) > 0.2F && targetID == 0 &&
                    belowID != 0 && belowID != 79 && support && support->solid && support->opaque)
                    CloneMCJ_World_SetBlockNotify(world, globalX, weatherY, globalZ, 78);
                if (belowID == 9 && weatherY > 0 &&
                    CloneMCJ_Chunk_GetBlockMetadata(chunk, weatherX, weatherY - 1, weatherZ) == 0)
                    CloneMCJ_World_SetBlockNotify(world, globalX, weatherY - 1, globalZ, 79);
            }
        }
        for (tick = 0; tick < CLONEMC_J_RANDOM_TICKS_PER_CHUNK; ++tick) {
            world->randomTickLCG = CloneMCJava_AddInt(CloneMCJava_MulInt(world->randomTickLCG, 3), (CloneMCJInt)0x3C6EF35FL);
            bits = world->randomTickLCG >> 2;
            localX = bits & 15;
            localZ = (bits >> 8) & 15;
            localY = (bits >> 16) & 127;
            blockID = CloneMCJ_Chunk_GetBlockID(chunk, localX, localY, localZ);
            if (world->tickOnLoad[blockID] && world->blockTickCallbacks[blockID]) {
                world->blockTickCallbacks[blockID](world, chunk->xPosition * 16 + localX, localY,
                    chunk->zPosition * 16 + localZ, blockID, &world->rand,
                    world->blockTickUserData[blockID]);
            }
            ++world->randomTicksRun;
        }
    }
}

static void CloneMCJ_World_MarkDaylightMeshesDirty(CloneMCJ_World *world)
{
    int index;
    if(!world)return;
    if(world->multiplayerWorld){
        CloneMCJ_WorldClient *client;
        client=(CloneMCJ_WorldClient *)world;
        for(index=0;index<CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY;++index)
            if(client->clientChunkProvider.slots[index].used&&
               client->clientChunkProvider.slots[index].chunk)
                client->clientChunkProvider.slots[index].chunk->meshDirty=1;
    }else{
        for(index=0;index<CLONEMC_J_CHUNK_CACHE_CAPACITY;++index)
            if(world->chunkProvider.slots[index].used&&
               world->chunkProvider.slots[index].chunk)
                world->chunkProvider.slots[index].chunk->meshDirty=1;
    }
}

void CloneMCJ_World_Tick(CloneMCJ_World *world)
{
    int newSkylight;
    if(!world)return;
    world->playerChunkLoadsThisTick=0;
    world->entityChunkLoadsThisTick=0; /* retained for diagnostics; V142 admits none here */
    /* WorldClient.java receives time, weather, blocks, chunks and entities from
       NetClientHandler.  Local prediction is limited to the player controller;
       never run the singleplayer random/scheduled/save simulation on its world. */
    if (world->multiplayerWorld) {
        newSkylight=CloneMCJ_World_CalculateSkylightSubtracted(world,1.0F);
        if(newSkylight!=world->skylightSubtracted){
            world->skylightSubtracted=newSkylight;
            CloneMCJ_World_MarkDaylightMeshesDirty(world);
        }
        if (world->gameplayTick) { world->gameplayTick(world, world->gameplayUserData); }
        ++world->ticksRun;
        return;
    }
    CloneMCJ_World_UpdateWeather(world);
    CloneMCJ_World_ServiceChunkStreaming(world);
    newSkylight = CloneMCJ_World_CalculateSkylightSubtracted(world, 1.0F);
    if(newSkylight!=world->skylightSubtracted){
        world->skylightSubtracted=newSkylight;
        /* Vertex colors are baked into OpenGL 1.1 meshes.  Invalidate once per
         * integer daylight step, not once per frame; the existing nearest-first
         * rebuild budget spreads the work and keeps legacy frame pacing stable. */
        CloneMCJ_World_MarkDaylightMeshesDirty(world);
    }
    ++world->worldTime;
    world->worldInfo.worldTime = world->worldTime;
    if (world->autosavePeriod > 0 && world->worldTime % (CloneMCJLong)world->autosavePeriod == 0 && world->saveHandler) {
        CloneMCJ_World_SaveAll(world, 0);
    }
    CloneMCJ_World_ProcessScheduledTicks(world, 0);
    CloneMCJ_World_UpdateRandomBlocks(world);
    if (world->gameplayTick) { world->gameplayTick(world, world->gameplayUserData); }
    CloneMCJ_World_UpdatingLighting(world);
    ++world->ticksRun;
}

int CloneMCJ_World_IsChunkLoaded(CloneMCJ_World *world,int chunkX,int chunkZ)
{
    return CloneMCJ_World_FindLoadedChunk(world,chunkX,chunkZ)!=(CloneMCJ_Chunk *)0;
}

int CloneMCJ_World_CountLoadedChunks(const CloneMCJ_World *world)
{
    if (!world) { return 0; }
    return CloneMCJ_ChunkProviderLoadOrGenerate_CountLoaded(&world->chunkProvider);
}

int CloneMCJ_World_CountLoadedChunksNearPlayer(CloneMCJ_World *world,int radius)
{
    int dx;int dz;int count;
    if(!world||!world->playerChunkInitialized)return 0;
    if(radius<0)radius=0;count=0;
    for(dz=-radius;dz<=radius;++dz)for(dx=-radius;dx<=radius;++dx)
        if((dx<0?-dx:dx)+(dz<0?-dz:dz)<=radius&&
           CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(&world->chunkProvider,
               world->playerChunkX+dx,world->playerChunkZ+dz)&&
           CloneMCJ_World_IsChunkLoaded(world,world->playerChunkX+dx,
               world->playerChunkZ+dz))++count;
    return count;
}

int CloneMCJ_World_BootstrapSpawnStep(CloneMCJ_World *world, int targetRadius)
{
    int desired;
    int before;
    int after;
    int attempts;
    if (!world || world->multiplayerWorld || !world->playerChunkInitialized)
        return 0;
    if (targetRadius < 0) targetRadius = 0;
    if (targetRadius > world->activeRadius) targetRadius = world->activeRadius;
    desired = 1 + 2 * targetRadius * (targetRadius + 1);
    if (desired > world->activeChunkLimit) desired = world->activeChunkLimit;
    before = CloneMCJ_World_CountLoadedChunksNearPlayer(world,targetRadius);
    if (before >= desired) return before;
    /* Bootstrap uses the same nearest-first streamer, but advances only the
     * private scheduling counter so a loading screen can admit one chunk per
     * presentation update without advancing time, weather, mobs, or autosave. */
    attempts = 0;
    after = before;
    while (after == before && attempts < 8) {
        world->ticksRun += 4UL;
        CloneMCJ_World_ServiceChunkStreaming(world);
        after = CloneMCJ_World_CountLoadedChunksNearPlayer(world,targetRadius);
        ++attempts;
        if (world->streamRetryTick > world->ticksRun) break;
    }
    return after;
}


int CloneMCJ_World_BlockExists(CloneMCJ_World *world, int blockX, int y, int blockZ)
{
    if (!world || y < 0 || y >= 128) { return 0; }
    return CloneMCJ_World_GetChunkFromBlockCoords(world, blockX, blockZ) != 0;
}

int CloneMCJ_World_FindTopSolidBlock(CloneMCJ_World *world, int blockX, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    int lx;
    int lz;
    if (!world) { return 0; }
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, blockX, blockZ);
    lx = CloneMCJ_World_GlobalToLocal(blockX);
    lz = CloneMCJ_World_GlobalToLocal(blockZ);
    if (!chunk) { return 0; }
    return CloneMCJ_Chunk_GetHeightValue(chunk, lx, lz);
}


int CloneMCJ_World_AttachSaveHandler(CloneMCJ_World *world, CloneMCJ_SaveHandler *handler, const char *levelName)
{
    CloneMCJ_WorldInfo loaded;
    CloneMCJ_McRegionChunkLoader *loader;
    int existingWorld;
    if (!world || !handler || !handler->initialized) { return 0; }
    memset(&loaded, 0, sizeof(loaded));
    world->saveHandler = handler;
    existingWorld = CloneMCJ_SaveHandler_LoadWorldInfo(handler, &loaded);
    /* A missing level.dat is a new world; an existing but undecodable
     * level.dat is not.  Preserve the Java backup fallback and never replace a
     * damaged save with freshly generated metadata. */
    if (!existingWorld && CloneMCJ_SaveHandler_GetLastError(handler)[0]) return 0;
    if (existingWorld) {
        CloneMCJ_WorldInfo_Destroy(&world->worldInfo);
        world->worldInfo = loaded;
        world->randomSeed = loaded.randomSeed;
        world->worldTime = loaded.worldTime;
        world->rainingStrength = loaded.raining ? 1.0F : 0.0F;
        world->prevRainingStrength = world->rainingStrength;
        world->thunderingStrength = loaded.thundering ? 1.0F : 0.0F;
        world->prevThunderingStrength = world->thunderingStrength;
        if (world->worldInfo.dimension != -1 && world->worldInfo.dimension != 0 &&
            world->worldInfo.dimension != 1) world->worldInfo.dimension = 0;
    } else {
        if (levelName) {
            strncpy(world->worldInfo.levelName, levelName,
                sizeof(world->worldInfo.levelName) - 1);
            world->worldInfo.levelName[sizeof(world->worldInfo.levelName) - 1] = '\0';
        }
        world->worldInfo.randomSeed = world->randomSeed;
        world->worldInfo.worldTime = world->worldTime;
        /* Commit the small Java-compatible GZIP NBT transaction before chunk
         * providers allocate and populate the spawn area.  On 32-bit Watcom
         * this keeps metadata creation independent of the large generation
         * memory peak, and makes the save visible in GuiSelectWorld at once. */
        if (!CloneMCJ_SaveHandler_SaveWorldInfo(handler, &world->worldInfo,
                (const CloneMCJ_NBTTagCompound *)0)) return 0;
    }
    /* Rebuild provider state after loading level.dat.  World_Initialize may have
     * generated preview chunks before the save handler was attached; retaining
     * them would mask on-disk chunks and can overwrite valid edits. */
    CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&world->chunkProvider);
    CloneMCJ_ChunkProviderGenerate_Destroy(&world->terrainProvider);
    CloneMCJ_ChunkProviderHell_Destroy(&world->hellProvider);
    CloneMCJ_ChunkProviderEnd_Destroy(&world->skyProvider);
    CloneMCJ_WorldChunkManager_Destroy(&world->chunkManager);
    if (world->worldInfo.dimension == -1)
        CloneMCJ_WorldProviderHell_Initialize(&world->worldProvider);
    else if (world->worldInfo.dimension == 1)
        CloneMCJ_WorldProviderEnd_Initialize(&world->worldProvider);
    else
        CloneMCJ_WorldProvider_InitializeSurface(&world->worldProvider);
    if (world->worldInfo.dimension == -1)
        CloneMCJ_WorldChunkManager_InitializeFixed(&world->chunkManager,
            CLONEMC_J_BIOME_HELL, 1.0, 0.0);
    else if (world->worldInfo.dimension == 1)
        CloneMCJ_WorldChunkManager_InitializeFixed(&world->chunkManager,
            CLONEMC_J_BIOME_SKY, 0.5, 0.0);
    else CloneMCJ_WorldChunkManager_Initialize(&world->chunkManager, world->randomSeed);
    CloneMCJavaRandom_SetSeed(&world->rand, world->randomSeed);
    CloneMCJ_ChunkProviderGenerate_Initialize(&world->terrainProvider, world->randomSeed, &world->chunkManager);
    CloneMCJ_ChunkProviderHell_Initialize(&world->hellProvider, world->randomSeed);
    CloneMCJ_ChunkProviderEnd_Initialize(&world->skyProvider, world->randomSeed);
    CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&world->chunkProvider, world->randomSeed);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetMemoryBudget(&world->chunkProvider,
        world->chunkMemoryBudgetBytes);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetWorldTimePointer(&world->chunkProvider, &world->worldTime);
    loader = CloneMCJ_SaveHandler_GetChunkLoader(handler, world->worldInfo.dimension);
    if (!loader) return 0;
    CloneMCJ_McRegionChunkLoader_SetWorldTimePointer(loader, &world->worldTime);
    CloneMCJ_McRegionChunkLoader_SetWorldInfoPointer(loader, &world->worldInfo);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(&world->chunkProvider,
        CloneMCJ_McRegionChunkLoader_LoadCallback, loader,
        CloneMCJ_World_JavaTerrainGenerator, world,
        CloneMCJ_McRegionChunkLoader_SaveCallback, loader);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&world->chunkProvider,
        world->activeChunkLimit);
    world->playerChunkInitialized = 0;
    CloneMCJ_World_SetPlayerGlobalPosition(world, (double)world->worldInfo.spawnX, (double)world->worldInfo.spawnZ);
    return 1;
}

int CloneMCJ_World_PrepareSaveSnapshot(CloneMCJ_World *world)
{
    const char *detail;
    if (!world) return 0;
    world->lastSaveError[0]='\0';
    if(world->multiplayerWorld){strcpy(world->lastSaveError,"A multiplayer world is owned by the server and cannot be saved locally");return 0;}
    if(!world->saveHandler){strcpy(world->lastSaveError,"No save handler is attached to the current world");return 0;}
    if (!CloneMCJ_SaveHandler_CheckSessionLock(world->saveHandler)){
        detail=CloneMCJ_SaveHandler_GetLastError(world->saveHandler);
        strncpy(world->lastSaveError,detail&&*detail?detail:"The session.lock file no longer belongs to this game instance",sizeof(world->lastSaveError)-1);
        world->lastSaveError[sizeof(world->lastSaveError)-1]='\0';
        return 0;
    }
    if (world->gameplayPrepareSave &&
        !world->gameplayPrepareSave(world, world->gameplayUserData)){
        if(!world->lastSaveError[0])strcpy(world->lastSaveError,"The current Player NBT snapshot could not be created");
        return 0;
    }
    world->worldInfo.randomSeed = world->randomSeed;
    world->worldInfo.worldTime = world->worldTime;
    return 1;
}

const char *CloneMCJ_World_GetLastSaveError(const CloneMCJ_World *world)
{
    return world?world->lastSaveError:"";
}

void CloneMCJ_World_MarkResidentChunksModified(CloneMCJ_World *world)
{
    int slot;
    if(!world)return;
    /* A failed final durable flush has an unknown commit boundary.  Re-dirty
     * every resident chunk conservatively so Retry Save and quit rewrites a
     * complete, self-consistent resident set instead of trusting buffered data. */
    for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot)
        if(world->chunkProvider.slots[slot].used&&world->chunkProvider.slots[slot].chunk)
            CloneMCJ_Chunk_SetModified(world->chunkProvider.slots[slot].chunk);
}

int CloneMCJ_World_SaveChunksBudget(CloneMCJ_World *world, int force,
    int maximum, int *remaining)
{
    if (remaining) *remaining = 0;
    if (!world || world->multiplayerWorld || !world->saveHandler) return -1;
    return CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunksBudget(
        &world->chunkProvider, force, maximum, remaining);
}

int CloneMCJ_World_CommitLevelSave(CloneMCJ_World *world)
{
    if (!world || world->multiplayerWorld || !world->saveHandler) return 0;
    return CloneMCJ_SaveHandler_SaveWorldInfo(world->saveHandler,
        &world->worldInfo,
        (CloneMCJ_NBTTagCompound *)world->worldInfo.playerTag);
}

int CloneMCJ_World_SaveAll(CloneMCJ_World *world, int force)
{
    int saved;
    int remaining;
    if (!CloneMCJ_World_PrepareSaveSnapshot(world)) return 0;
    saved = CloneMCJ_World_SaveChunksBudget(world, force,
        force ? CLONEMC_J_CHUNK_CACHE_CAPACITY : 2, &remaining);
    if (saved < 0) return 0;
    if (!CloneMCJ_World_CommitLevelSave(world)) return 0;
    return saved + 1;
}

int CloneMCJ_World_SetDimension(CloneMCJ_World *world, int dimension, int prepareSpawn)
{
    CloneMCJ_McRegionChunkLoader *loader;
    CloneMCJ_ChunkSerializationHooks hooks;
    int blockX;
    int blockZ;
    if (!world || world->multiplayerWorld ||
        (dimension != 0 && dimension != -1 && dimension != 1)) return 0;
    if (world->worldProvider.worldType == dimension) return 1;
    memset(&hooks, 0, sizeof(hooks));
    if (world->saveHandler) hooks = world->saveHandler->chunkLoader.hooks;
    /* A dimension transfer must never discard the source dimension.  Java
     * saves the current world before replacing the provider; abort when the
     * transactional chunk/level write fails so the player remains in the
     * still-resident source world with every edit intact. */
    if (world->saveHandler && !CloneMCJ_World_SaveAll(world, 1)) return 0;
    blockX = world->playerChunkX * 16 + 8;
    blockZ = world->playerChunkZ * 16 + 8;
    CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&world->chunkProvider);
    CloneMCJ_ChunkProviderGenerate_Destroy(&world->terrainProvider);
    CloneMCJ_ChunkProviderHell_Destroy(&world->hellProvider);
    CloneMCJ_ChunkProviderEnd_Destroy(&world->skyProvider);
    CloneMCJ_WorldChunkManager_Destroy(&world->chunkManager);
    if (dimension == -1) CloneMCJ_WorldProviderHell_Initialize(&world->worldProvider);
    else if (dimension == 1) CloneMCJ_WorldProviderEnd_Initialize(&world->worldProvider);
    else CloneMCJ_WorldProvider_InitializeSurface(&world->worldProvider);
    world->worldInfo.dimension = dimension;
    if (dimension == -1) CloneMCJ_WorldChunkManager_InitializeFixed(&world->chunkManager,
        CLONEMC_J_BIOME_HELL, 1.0, 0.0);
    else if (dimension == 1) CloneMCJ_WorldChunkManager_InitializeFixed(&world->chunkManager,
        CLONEMC_J_BIOME_SKY, 0.5, 0.0);
    else CloneMCJ_WorldChunkManager_Initialize(&world->chunkManager, world->randomSeed);
    CloneMCJ_ChunkProviderGenerate_Initialize(&world->terrainProvider, world->randomSeed,
        &world->chunkManager);
    CloneMCJ_ChunkProviderHell_Initialize(&world->hellProvider, world->randomSeed);
    CloneMCJ_ChunkProviderEnd_Initialize(&world->skyProvider, world->randomSeed);
    CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&world->chunkProvider, world->randomSeed);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetMemoryBudget(&world->chunkProvider,
        world->chunkMemoryBudgetBytes);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetWorldTimePointer(&world->chunkProvider,
        &world->worldTime);
    loader = world->saveHandler ? CloneMCJ_SaveHandler_GetChunkLoader(world->saveHandler,
        dimension) : (CloneMCJ_McRegionChunkLoader *)0;
    if (loader) {
        CloneMCJ_McRegionChunkLoader_SetHooks(loader, &hooks);
        CloneMCJ_McRegionChunkLoader_SetWorldTimePointer(loader, &world->worldTime);
        CloneMCJ_McRegionChunkLoader_SetWorldInfoPointer(loader, &world->worldInfo);
        CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(&world->chunkProvider,
            CloneMCJ_McRegionChunkLoader_LoadCallback, loader,
            CloneMCJ_World_JavaTerrainGenerator, world,
            CloneMCJ_McRegionChunkLoader_SaveCallback, loader);
    } else CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(&world->chunkProvider,
        0, 0, CloneMCJ_World_JavaTerrainGenerator, world, 0, 0);
    CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(&world->chunkProvider,
        world->activeChunkLimit);
    CloneMCJ_BlockSimulation_RegisterWorld(world);
    world->playerChunkInitialized = 0;
    if(world->gameplayUserData&&world->gameplayDimensionChanged)
        world->gameplayDimensionChanged(world,world->gameplayUserData,dimension);
    if (prepareSpawn) CloneMCJ_World_SetPlayerGlobalPosition(world, (double)blockX,
        (double)blockZ);
    return 1;
}

static void CloneMCJ_Priority6_TestTick(CloneMCJ_World *world, int x, int y, int z,
    int blockID, CloneMCJavaRandom *random, void *userData)
{
    int *count;
    (void)world; (void)x; (void)y; (void)z; (void)blockID; (void)random;
    count = (int *)userData;
    if (count) { ++*count; }
}

static int CloneMCJ_Priority6_Close(float left, float right, float epsilon)
{
    float difference;
    difference = left - right;
    if (difference < 0.0F) { difference = -difference; }
    return difference <= epsilon;
}

int CloneMCJ_Priority6_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJ_WorldProvider provider;
    CloneMCJ_MetadataChunkBlock region;
    CloneMCJ_World *world;
    CloneMCJ_Chunk *chunk;
    int x;
    int z;
    int callbackCount;
    int ok;
    const char *failure;
    failure = 0;
    CloneMCJ_WorldProvider_InitializeSurface(&provider);
    if (!CloneMCJ_Priority6_Close(CloneMCJ_WorldProvider_CalculateCelestialAngle(0, 0.0F), 0.784518F, 0.00002F) ||
        !CloneMCJ_Priority6_Close(CloneMCJ_WorldProvider_CalculateCelestialAngle(6000, 0.0F), 0.0F, 0.00002F) ||
        !CloneMCJ_Priority6_Close(CloneMCJ_WorldProvider_CalculateCelestialAngle(12000, 0.0F), 0.215482F, 0.00002F) ||
        !CloneMCJ_Priority6_Close(CloneMCJ_WorldProvider_CalculateCelestialAngle(18000, 0.0F), 0.5F, 0.00002F)) {
        failure = "Priority 6 celestial-angle vectors failed";
    } else if (!CloneMCJ_Priority6_Close(provider.lightBrightnessTable[0], 0.05F, 0.00001F) ||
               !CloneMCJ_Priority6_Close(provider.lightBrightnessTable[15], 1.0F, 0.00001F)) {
        failure = "Priority 6 light-brightness table failed";
    } else if (CloneMCJ_World_GetBlockLightOpacity(CLONEMC_J_BLOCK_LEAVES) != 1 ||
               CloneMCJ_World_GetBlockLightOpacity(CLONEMC_J_BLOCK_WATER_STILL) != 3 ||
               CloneMCJ_World_GetBlockLightEmission(CLONEMC_J_BLOCK_TORCH) != 14 ||
               CloneMCJ_World_GetBlockLightEmission(CLONEMC_J_BLOCK_GLOWSTONE) != 15) {
        failure = "Priority 6 block light tables failed";
    }
    CloneMCJ_MetadataChunkBlock_Initialize(&region, CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, 0, 1, 0, 0, 1, 0);
    if (!failure && (!CloneMCJ_MetadataChunkBlock_CanCombine(&region, 1, 1, 0, 1, 1, 0) || region.maxX != 1)) {
        failure = "Priority 6 MetadataChunkBlock merge failed";
    }
    world = 0;
    if (!failure) {
        world = (CloneMCJ_World *)malloc(sizeof(CloneMCJ_World));
        if (!world) { failure = "Priority 6 self-test allocation failed"; }
    }
    if (!failure) {
        memset(world, 0, sizeof(*world));
        world->randomSeed = 1;
        world->autosavePeriod = 600;
        CloneMCJavaRandom_SetSeed(&world->rand, 1);
        CloneMCJ_WorldProvider_InitializeSurface(&world->worldProvider);
        CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&world->chunkProvider, 1);
        CloneMCJ_ChunkProviderLoadOrGenerate_SetWorldTimePointer(&world->chunkProvider, &world->worldTime);
        for (x = -1; x <= 1; ++x) {
            for (z = -1; z <= 1; ++z) {
                CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider, x, z);
            }
        }
        chunk = CloneMCJ_World_GetChunkFromChunkCoords(world, 0, 0);
        CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk, 8, 64, 8, CLONEMC_J_BLOCK_TORCH, 0,
            CloneMCJ_World_BlockOpacityCallback, 0);
        CloneMCJ_World_ScheduleLightingUpdate(world, CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, 8, 64, 8, 8, 64, 8);
        ok = 0;
        for (x = 0; x < 32 && world->lightingUpdateCount; ++x) { CloneMCJ_World_UpdatingLighting(world); }
        if (CloneMCJ_World_GetSavedLightValue(world, CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, 8, 64, 8) == 14 &&
            CloneMCJ_World_GetSavedLightValue(world, CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, 9, 64, 8) >= 13) { ok = 1; }
        if (!ok) { failure = "Priority 6 cross-block light propagation failed"; }
        /* Removing an emitter must schedule the same Java MetadataChunkBlock
         * flood in reverse; stale torch light may not remain baked into a
         * rebuilt OpenGL 1.1 chunk mesh. */
        CloneMCJ_World_SetBlockWithMetadataNotify(world,8,64,8,0,0);
        for(x=0;x<64&&world->lightingUpdateCount;++x)
            CloneMCJ_World_UpdatingLighting(world);
        if(!failure&&(CloneMCJ_World_GetSavedLightValue(world,
                CLONEMC_J_ENUM_SKY_BLOCK_BLOCK,8,64,8)!=0||
            CloneMCJ_World_GetSavedLightValue(world,
                CLONEMC_J_ENUM_SKY_BLOCK_BLOCK,9,64,8)!=0))
            failure="Priority 6 removed-emitter light decay failed";
        CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,8,64,8,
            CLONEMC_J_BLOCK_TORCH,0,CloneMCJ_World_BlockOpacityCallback,0);
        callbackCount = 0;
        CloneMCJ_World_RegisterBlockTick(world, CLONEMC_J_BLOCK_TORCH, 0, CloneMCJ_Priority6_TestTick, &callbackCount);
        CloneMCJ_World_ScheduleBlockUpdate(world, 8, 64, 8, CLONEMC_J_BLOCK_TORCH, 0);
        CloneMCJ_World_ProcessScheduledTicks(world, 0);
        if (!failure && callbackCount != 1) { failure = "Priority 6 scheduled tick ordering failed"; }
        CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&world->chunkProvider);
    }
    if (world) { free(world); }
    if (message && messageCapacity > 0) {
        const char *text;
        text = failure ? failure : "Priority 6 fixed-step/world-time/weather/lighting tests: PASS";
        strncpy(message, text, messageCapacity - 1);
        message[messageCapacity - 1] = '\0';
    }
    return failure ? 0 : 1;
}
