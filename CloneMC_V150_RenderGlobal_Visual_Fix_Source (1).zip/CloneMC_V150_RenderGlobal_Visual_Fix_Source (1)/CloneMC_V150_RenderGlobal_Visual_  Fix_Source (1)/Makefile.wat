# Minimal source build: no Python verification or documentation targets.
EXE = CloneMC_V150_DualStage_ChunkStreaming_Win9x.exe
OBJ = project2finalalpharecreation.obj
SRC = project2finalalpharecreation.c
LNK = clonemc_v150_dualstage_chunk_streaming_win9x.lnk

all: $(EXE)

$(OBJ): .SYMBOLIC
	wcc386 -q -otexan -bt=nt -dWINVER=0x0400 -d_WIN32_WINNT=0x0400 -dCLONEMC_BUILD_OPEN_WATCOM_V2=1 -dCLONEMC_REFERENCE_DEFAULT=0 -fo=$(OBJ) $(SRC)

$(EXE): $(OBJ) $(LNK)
	wlink @$(LNK)

clean: .SYMBOLIC
	-del $(OBJ)
	-del $(EXE)
	-del CloneMC_V150_DualStage_ChunkStreaming_Win9x.map
