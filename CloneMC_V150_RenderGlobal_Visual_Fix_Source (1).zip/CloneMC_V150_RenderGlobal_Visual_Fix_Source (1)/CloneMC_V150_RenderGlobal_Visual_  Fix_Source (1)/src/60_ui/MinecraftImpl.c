/*
 * CloneMC Java port scaffold: MinecraftImpl
 *
 * Java source: MinecraftImpl.java
 * Java type: class MinecraftImpl
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: Minecraft
 * Implements: (none declared)
 * Source SHA-256: 227690ba4a36cd91b40f6076e76f96e208be4343a994a918e793e5a7081010cc
 * Java lines: 32
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: PanelCrashReport, UnexpectedThrowable, canvas, minecraftapplet, i, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public MinecraftImpl(Component component, Canvas canvas, MinecraftApplet minecraftapplet, int i, int j, boolean flag, Frame frame)
 * - public void displayUnexpectedThrowable(UnexpectedThrowable unexpectedthrowable)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"
#include "../../clonemc_version.h"
#include "../00_core/clonemc_java_port_00_core.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../70_render/clonemc_java_port_70_render.h"
#include "../NETWORK/clonemc_java_port_network.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <windows.h>
#include <mmsystem.h>
#include <GL/gl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int CloneMCPlatform_StrICmp(const char *left,const char *right)
{
    unsigned char a,b;if(!left)left="";if(!right)right="";
    for(;;){a=(unsigned char)*left++;b=(unsigned char)*right++;
        if(a>='A'&&a<='Z')a=(unsigned char)(a-'A'+'a');
        if(b>='A'&&b<='Z')b=(unsigned char)(b-'A'+'a');
        if(a!=b)return (int)a-(int)b;if(a==0)return 0;}
}

#ifndef WM_MOUSEWHEEL
#define WM_MOUSEWHEEL 0x020A
#endif
#ifndef WM_CHAR
#define WM_CHAR 0x0102
#endif
#ifndef WHEEL_DELTA
#define WHEEL_DELTA 120
#endif
#ifndef PFD_GENERIC_ACCELERATED
#define PFD_GENERIC_ACCELERATED 0x00001000
#endif
#ifndef WM_ENTERSIZEMOVE
#define WM_ENTERSIZEMOVE 0x0231
#endif
#ifndef WM_EXITSIZEMOVE
#define WM_EXITSIZEMOVE 0x0232
#endif

#define CLONEMC_WINDOW_CLASS "CloneMC_OpenWatcom_GL11"
#define CLONEMC_SETTINGS_FILE "options.txt"
#define CLONEMC_LEGACY_SETTINGS_FILE "options_clonemc.cfg"
#define CLONEMC_LOG_FILE "clonemc_platform.log"
#define CLONEMC_SAVE_TIMEOUT_MS 30000UL
#define CLONEMC_SAVE_URGENT_MS 10000UL
#define CLONEMC_SAVE_FINAL_BATCH 16

typedef struct CloneMCCompatibilityPolicyTag {
    int strictReference;
    int exposeExtendedGameModes;
    int allowCommands;
    int enableOnlineResources;
} CloneMCCompatibilityPolicy;

typedef struct CloneMCWin32AppTag {
    HINSTANCE instance;
    HWND window;
    HDC deviceContext;
    HGLRC renderingContext;
    HPALETTE palette;
    PIXELFORMATDESCRIPTOR pixelFormat;
    int pixelFormatIndex;
    int fullscreenActive;
    int classRegistered;
    int systemPaletteChanged;
    CloneMCGameSettings settings;
    CloneMCWindowListenerState listener;
    CloneMCInputState input;
    CloneMCMouseHelperState mouse;
    CloneMCTimer timer;
    CloneMCGLCaps glCaps;
    CloneMCRenderBootstrap renderer;
    CloneMCJ_GuiIngameState guiIngame;
    CloneMCJ_GuiScreenState guiScreen;
    CloneMCJ_LoadingScreenState loadingScreen;
    CloneMCJ_SoundManagerState soundManager;
    CloneMCJ_World *world;
    CloneMCJ_WorldClient *worldClient;
    CloneMCJ_SaveHandler saveHandler;
    CloneMCJ_MapStorage mapStorage;
    CloneMCJ_GameplayState *gameplay;
    CloneMCNetworkManager networkManager;
    CloneMCNetClientHandler netClientHandler;
    CloneMCPlayerControllerMP multiplayerController;
    CloneMCCompatibilityMetrics metrics;
    CloneMCLegacyProfile performanceProfile;
    char serverHost[128];
    char username[64];
    char worldName[64];
    char worldDisplayName[96];
    CloneMCJLong worldSeed;
    int pendingGameMode;
    int pendingAllowCheats;
    int creatingNewWorld;
    unsigned long lastForwardTapMilliseconds;
    unsigned short serverPort;
    int multiplayerMode;
    int frontendActive;
    int win98SafeProfile;
    int legacyCompatibilityMode;
    int realWin9xMode;
    int compatibilityShimMode;
    int softwareGLRequested;
    CloneMCCompatibilityPolicy compatibilityPolicy;
    int screenshotRequested;
    int resizePending;
    int resizeApplying;
    int resizeInteraction;
    int resizeRestoreMouseGrab;
    int resizeAwaitingPresent;
    int resizeSettingsDirty;
    int settingsDirty;
    unsigned long settingsDirtyMilliseconds;
    int pendingResizeWidth;
    int pendingResizeHeight;
    int netClientInitialized;
    int disconnectReported;
    int worldInitialized;
    int saveHandlerInitialized;
    int mapStorageInitialized;
    int sessionExitRequested;
    int sessionExitShowsError;
    int gracefulDisconnect;
    int saveCompletedForExit;
    int saveInProgress;
    int closeAfterSave;
    int saveStage;
    int respawnRequested;
    char saveFailureDetail[256];
    char sessionExitTitle[96];
    char sessionExitDetail[192];
    unsigned long gameTicks;
    unsigned long worldRuntimeTicks;
    unsigned long framesThisSecond;
    unsigned long ticksThisSecond;
    unsigned long lastFramesPerSecond;
    unsigned long lastTicksPerSecond;
    double statisticsStartSeconds;
    unsigned long statsPreviousBlocksMined, statsPreviousBlocksPlaced;
    unsigned long statsLastCraftedSerial, statsLastSmeltedSerial;
    unsigned long statsLastPeriodicSaveTick;
    double statsPreviousX, statsPreviousY, statsPreviousZ;
    int statsPreviousHealth, statsStateKnown, statsPreviousOnGround;
    int statsPigFallArmed, statsLeaveRecorded;
    int statsSeenMobIds[CLONEMC_J_MAX_MOBS];
    int statsSeenMobCount;
    CloneMCJ_TileEntity *editingSign;
    int signEditLine;
    unsigned long signEditCounter;
} CloneMCWin32App;

static CloneMCWin32App *g_cloneMCWin32App = 0;
static volatile unsigned int g_cloneMCCrashPhase = 0;
static char g_cloneMCCrashDescription[160] = "process bootstrap";
static void CloneMCPlatform_SetFrontendScreen(CloneMCWin32App *,int);
static int CloneMCPlatform_ApplyPendingResize(CloneMCWin32App *);
static void CloneMCPlatform_WaitForFrameDeadline(double);

static int CloneMCPlatform_PathJoin(char *output,unsigned long capacity,
    const char *directory,const char *relativePath)
{
    unsigned long directoryLength,relativeLength,needsSlash;
    if(!output||capacity==0||!directory||!relativePath)return 0;
    directoryLength=(unsigned long)strlen(directory);
    relativeLength=(unsigned long)strlen(relativePath);
    needsSlash=directoryLength>0&&directory[directoryLength-1]!='\\'&&
        directory[directoryLength-1]!='/'?1UL:0UL;
    if(directoryLength+needsSlash+relativeLength+1UL>capacity)return 0;
    strcpy(output,directory);
    if(needsSlash)strcat(output,"\\");
    strcat(output,relativePath);return 1;
}

static int CloneMCPlatform_FileExists(const char *path)
{
    DWORD attributes;
    if(!path||!*path)return 0;
    attributes=GetFileAttributesA(path);
    return attributes!=0xFFFFFFFFUL&&(attributes&FILE_ATTRIBUTE_DIRECTORY)==0;
}

static int CloneMCPlatform_DataRootIsValid(const char *directory)
{
    char terrain[MAX_PATH];
    char gui[MAX_PATH];
    if(!directory||!*directory)return 0;
    if(!CloneMCPlatform_PathJoin(terrain,sizeof(terrain),directory,"assets\\terrain.tga")||
       !CloneMCPlatform_PathJoin(gui,sizeof(gui),directory,"assets\\gui\\gui.tga"))return 0;
    return CloneMCPlatform_FileExists(terrain)&&CloneMCPlatform_FileExists(gui);
}

static int CloneMCPlatform_TryDataRoot(const char *directory)
{
    if(!CloneMCPlatform_DataRootIsValid(directory))return 0;
    return SetCurrentDirectoryA(directory)?1:0;
}

static int CloneMCPlatform_TryDataRootChildren(const char *directory)
{
    static const char *children[]={"game","data","CloneMC","clonemc"};
    char candidate[MAX_PATH];
    unsigned int index;
    if(CloneMCPlatform_TryDataRoot(directory))return 1;
    for(index=0;index<sizeof(children)/sizeof(children[0]);++index){
        if(CloneMCPlatform_PathJoin(candidate,sizeof(candidate),directory,children[index])&&
           CloneMCPlatform_TryDataRoot(candidate))return 1;
    }
    return 0;
}

static int CloneMCPlatform_ParentDirectory(char *path)
{
    char *slash;
    unsigned long length;
    if(!path||!*path)return 0;
    length=(unsigned long)strlen(path);
    while(length>3UL&&(path[length-1]=='\\'||path[length-1]=='/'))path[--length]='\0';
    slash=strrchr(path,'\\');
    if(!slash)slash=strrchr(path,'/');
    if(!slash)return 0;
    if(slash==path+2&&path[1]==':'){slash[1]='\0';return 1;}
    if(slash==path)return 0;
    *slash='\0';return 1;
}

static int CloneMCPlatform_TryRootAndParents(const char *startDirectory)
{
    char candidate[MAX_PATH];
    unsigned int depth;
    if(!startDirectory||!*startDirectory||strlen(startDirectory)>=MAX_PATH)return 0;
    strcpy(candidate,startDirectory);
    for(depth=0;depth<5U;++depth){
        if(CloneMCPlatform_TryDataRootChildren(candidate))return 1;
        if(!CloneMCPlatform_ParentDirectory(candidate))break;
    }
    return 0;
}

/*
 * Establish one deterministic project root before any assets, saves or logs are
 * opened.  This allows the EXE to be launched from Explorer, a shortcut, a bin
 * folder, or a command prompt whose current directory is elsewhere.
 */
int CloneMCPlatform_UseDataRoot(void)
{
    char environment[MAX_PATH];
    char modulePath[MAX_PATH];
    char moduleDirectory[MAX_PATH];
    char currentDirectory[MAX_PATH];
    char *slash;
    DWORD length;
    length=GetEnvironmentVariableA("CLONEMC_HOME",environment,MAX_PATH);
    if(length>0&&length<MAX_PATH&&CloneMCPlatform_TryRootAndParents(environment))return 1;
    length=GetModuleFileNameA((HMODULE)0,modulePath,MAX_PATH);
    moduleDirectory[0]='\0';
    if(length>0&&length<MAX_PATH){
        strcpy(moduleDirectory,modulePath);
        slash=strrchr(moduleDirectory,'\\');if(!slash)slash=strrchr(moduleDirectory,'/');
        if(slash){*slash='\0';if(CloneMCPlatform_TryRootAndParents(moduleDirectory))return 1;}
    }
    length=GetCurrentDirectoryA(MAX_PATH,currentDirectory);
    if(length>0&&length<MAX_PATH&&CloneMCPlatform_TryRootAndParents(currentDirectory))return 1;
    /* Even without assets, keep logs/saves beside the executable instead of an arbitrary CWD. */
    if(moduleDirectory[0])SetCurrentDirectoryA(moduleDirectory);
    return 0;
}

static void CloneMCPlatform_CopyText(char *destination,unsigned long capacity,
    const char *source)
{
    if(!destination||capacity==0)return;
    if(!source)source="";
    strncpy(destination,source,capacity-1);destination[capacity-1]='\0';
}

static void CloneMCPlatform_Log(const char *message)
{
    FILE *file;
    if (!message) { return; }
    file = fopen(CLONEMC_LOG_FILE, "at");
    if (file) {
        fputs(message, file);
        fputs("\n", file);
        fclose(file);
    }
    OutputDebugStringA(message);
    OutputDebugStringA("\r\n");
}

static void CloneMCPlatform_SetRuntimePhase(unsigned int phase,const char *message)
{
    g_cloneMCCrashPhase=phase;
    if(message){
        strncpy(g_cloneMCCrashDescription,message,
            sizeof(g_cloneMCCrashDescription)-1);
        g_cloneMCCrashDescription[sizeof(g_cloneMCCrashDescription)-1]='\0';
    }
}

static void CloneMCPlatform_LogStartupPhase(unsigned int phase, const char *message)
{
    char line[512];
    CloneMCPlatform_SetRuntimePhase(phase,message);
    sprintf(line, "STARTUP %02u: %s", phase, message ? message : "(no description)");
    CloneMCPlatform_Log(line);
}

static void CloneMCPlatform_CrashBreadcrumb(const char *message)
{
    char line[256];
    if(message){strncpy(g_cloneMCCrashDescription,message,
        sizeof(g_cloneMCCrashDescription)-1);
        g_cloneMCCrashDescription[sizeof(g_cloneMCCrashDescription)-1]='\0';}
    sprintf(line,"RUNTIME phase %u: %s",(unsigned int)g_cloneMCCrashPhase,
        message?message:"(no description)");
    CloneMCPlatform_Log(line);
}

static void CloneMCPlatform_RequestSessionExit(CloneMCWin32App *app,
    int showError,int graceful,const char *title,const char *detail)
{
    if(!app)return;
    app->sessionExitRequested=1;app->sessionExitShowsError=showError?1:0;
    app->gracefulDisconnect=graceful?1:0;
    CloneMCPlatform_CopyText(app->sessionExitTitle,sizeof(app->sessionExitTitle),
        title&&*title?title:"Connection lost");
    CloneMCPlatform_CopyText(app->sessionExitDetail,sizeof(app->sessionExitDetail),
        detail&&*detail?detail:"Disconnected");
    CloneMCPlatform_CrashBreadcrumb(detail&&*detail?detail:"leaving current world");
}

static void CloneMCPlatform_CrashSignal(int signalNumber)
{
    FILE *file;
    char message[512];
    const char *signalName;
    signalName="unknown";
    if(signalNumber==SIGABRT)signalName="SIGABRT";
    else if(signalNumber==SIGFPE)signalName="SIGFPE";
    else if(signalNumber==SIGILL)signalName="SIGILL";
    else if(signalNumber==SIGSEGV)signalName="SIGSEGV";
    file=fopen("clonemc_crash.log","at");
    if(file){fprintf(file,"%s\nFatal C runtime signal %d (%s) during phase %u: %s\n",
        CLONEMC_VERSION_DISPLAY,signalNumber,signalName,
        (unsigned int)g_cloneMCCrashPhase,g_cloneMCCrashDescription);
        fclose(file);}
    sprintf(message,"%s\n\nCloneMC stopped with signal %d (%s) during runtime phase %u:\n%s\n\nSee clonemc_crash.log and clonemc_platform.log.",
        CLONEMC_VERSION_DISPLAY,signalNumber,signalName,
        (unsigned int)g_cloneMCCrashPhase,g_cloneMCCrashDescription);
    MessageBoxA((HWND)0,message,"CloneMC crash report",MB_OK|MB_ICONERROR);
    signal(signalNumber,SIG_DFL);
    exit(128+signalNumber);
}

static void CloneMCPlatform_InstallCrashHandlers(void)
{
    signal(SIGABRT,CloneMCPlatform_CrashSignal);
    signal(SIGFPE,CloneMCPlatform_CrashSignal);
    signal(SIGILL,CloneMCPlatform_CrashSignal);
    signal(SIGSEGV,CloneMCPlatform_CrashSignal);
}

static int CloneMCPlatform_HasArgument(const char *commandLine, const char *argument)
{
    const char *start;
    const char *end;
    unsigned long argumentLength;
    if (!commandLine || !argument || !*argument) { return 0; }
    argumentLength = (unsigned long)strlen(argument);
    start = commandLine;
    while (*start) {
        while (*start == ' ' || *start == '\t') { ++start; }
        if (!*start) { break; }
        end = start;
        while (*end && *end != ' ' && *end != '\t') { ++end; }
        if ((unsigned long)(end - start) == argumentLength &&
            strncmp(start, argument, argumentLength) == 0) { return 1; }
        start = end;
    }
    return 0;
}

static int CloneMCPlatform_IsRealWin9x(DWORD version)
{
    return (version&0x80000000UL)!=0UL;
}

static int CloneMCPlatform_IsModernCompatibilityShim(DWORD version)
{
    HMODULE kernel;
    int majorVersion;
    majorVersion=(int)(version&0xffUL);
    if(CloneMCPlatform_IsRealWin9x(version)||majorVersion>=5)return 0;
    /* A Windows 95/98 AppCompat version lie on a modern NT kernel reports 4.x
     * but still exports APIs that do not exist on real Win9x or NT4.  Resolve
     * them dynamically so the executable import table remains Win32 4.0-safe. */
    kernel=GetModuleHandleA("KERNEL32.DLL");
    if(!kernel)return 0;
    return GetProcAddress(kernel,"GetTickCount64")!=0||
        GetProcAddress(kernel,"GetNativeSystemInfo")!=0;
}

static int CloneMCPlatform_IsLegacyWindowsVersion(DWORD version)
{
    int majorVersion;
    majorVersion=(int)(version&0xffUL);
    return CloneMCPlatform_IsRealWin9x(version)||majorVersion<5;
}

/* Frontend/driver compatibility is an operating-system decision, not a RAM
 * tier.  V143 accidentally enabled the proven texture-free frontend only for
 * the 32-chunk win98-safe profile, so a real Win98 PC with 128 MiB selected
 * win98-high and fell back to the fragile modern GUI/audio path.  Explicit
 * -no-win98safe always wins so AppCompat version lies can be overridden. */
static int CloneMCPlatform_ShouldUseLegacyCompatibility(DWORD version,
    const char *commandLine)
{
    if(CloneMCPlatform_HasArgument(commandLine,"-no-win98safe"))return 0;
    if(CloneMCPlatform_HasArgument(commandLine,"-win98safe"))return 1;
    return CloneMCPlatform_IsLegacyWindowsVersion(version);
}

static int CloneMCPlatform_GetArgumentValue(const char *commandLine,
    const char *prefix,char *output,unsigned long capacity)
{
    const char *start;
    const char *end;
    unsigned long prefixLength;
    unsigned long valueLength;
    if(output&&capacity)output[0]='\0';
    if(!commandLine||!prefix||!output||capacity<2UL)return 0;
    prefixLength=(unsigned long)strlen(prefix);
    start=commandLine;
    while(*start){
        while(*start==' '||*start=='\t')++start;
        if(!*start)break;
        end=start;while(*end&&*end!=' '&&*end!='\t')++end;
        if((unsigned long)(end-start)>prefixLength&&
           strncmp(start,prefix,prefixLength)==0){
            valueLength=(unsigned long)(end-start)-prefixLength;
            if(valueLength>=capacity)valueLength=capacity-1UL;
            memcpy(output,start+prefixLength,valueLength);
            output[valueLength]='\0';
            return 1;
        }
        start=end;
    }
    return 0;
}

static void CloneMCPlatform_SetProfile(CloneMCLegacyProfile *profile,
    const char *name,unsigned long processMiB,unsigned long chunkMiB,
    unsigned long meshMiB,unsigned long networkKiB,int chunks,int particles,
    int regions,int meshSteps,double meshSeconds)
{
    unsigned long detected;
    detected=profile->detectedPhysicalBytes;
    memset(profile,0,sizeof(*profile));
    profile->detectedPhysicalBytes=detected;
    strncpy(profile->name,name,sizeof(profile->name)-1);
    profile->processMemoryCeilingBytes=processMiB*1024UL*1024UL;
    profile->chunkMemoryCeilingBytes=chunkMiB*1024UL*1024UL;
    profile->meshMemoryCeilingBytes=meshMiB*1024UL*1024UL;
    profile->networkReadQueueCeilingBytes=networkKiB*1024UL;
    profile->residentChunkTarget=chunks;
    profile->particleLimit=particles;
    profile->regionFileLimit=regions;
    profile->meshStepsPerFrame=meshSteps;
    profile->meshWorkSeconds=meshSeconds;
}

static void CloneMCPlatform_ResolvePerformanceProfile(
    CloneMCLegacyProfile *profile,const char *commandLine)
{
    MEMORYSTATUS memoryStatus;
    DWORD version;
    char requested[32];
    char line[320];
    int legacyWindows;
    int compatibilityShim;
    int majorVersion;
    if(!profile)return;
    memset(profile,0,sizeof(*profile));
    memset(&memoryStatus,0,sizeof(memoryStatus));
    memoryStatus.dwLength=sizeof(memoryStatus);
    GlobalMemoryStatus(&memoryStatus);
    profile->detectedPhysicalBytes=(unsigned long)memoryStatus.dwTotalPhys;
    version=GetVersion();
    majorVersion=(int)(version&0xffUL);
    legacyWindows=CloneMCPlatform_IsLegacyWindowsVersion(version);
    compatibilityShim=CloneMCPlatform_IsModernCompatibilityShim(version);
    requested[0]='\0';
    CloneMCPlatform_GetArgumentValue(commandLine,"-profile=",requested,
        sizeof(requested));
    if(strcmp(requested,"auto")==0)requested[0]='\0';
    if(CloneMCPlatform_HasArgument(commandLine,"-no-win98safe"))
        strcpy(requested,"modern");
    else if(CloneMCPlatform_HasArgument(commandLine,"-win98safe"))
        strcpy(requested,"win98safe");
    if(strcmp(requested,"win98safe")==0||
       (requested[0]=='\0'&&compatibilityShim)||
       (requested[0]=='\0'&&legacyWindows&&
        (profile->detectedPhysicalBytes==0UL||
         profile->detectedPhysicalBytes<134217728UL))){
        /* AppCompat is a frontend compatibility request, not proof that the
         * process should start a 64-chunk workload.  V135 used this bounded
         * 32-chunk profile for every automatic legacy launch. */
        CloneMCPlatform_SetProfile(profile,"win98-safe",64UL,8UL,20UL,512UL,
            32,192,8,1,0.0015);
    }else if(strcmp(requested,"win98high")==0||
            (requested[0]=='\0'&&legacyWindows&&!compatibilityShim&&
             profile->detectedPhysicalBytes>=134217728UL)||
            (requested[0]=='\0'&&majorVersion==5&&
             profile->detectedPhysicalBytes>0UL&&
             profile->detectedPhysicalBytes<=134217728UL)){
        /* A 128 MiB-class Win98 system can retain the exact nearest 64-chunk
         * V135 set without entering the V139 eviction cascade.  Mesh and
         * display-list work remain independently time-budgeted. */
        CloneMCPlatform_SetProfile(profile,"win98-high",128UL,16UL,40UL,1024UL,
            64,320,16,2,0.0020);
    }else if(strcmp(requested,"xp")==0||
            (requested[0]=='\0'&&majorVersion==5)||
            (requested[0]=='\0'&&profile->detectedPhysicalBytes>0UL&&
             profile->detectedPhysicalBytes<=268435456UL)){
        CloneMCPlatform_SetProfile(profile,"xp-normal",256UL,20UL,64UL,4096UL,
            80,512,32,3,0.0025);
    }else{
        CloneMCPlatform_SetProfile(profile,"modern",384UL,32UL,96UL,8192UL,
            128,512,64,4,0.0025);
    }
    sprintf(line,
        "V148 performance profile=%s physical=%lu MiB processCeiling=%lu MiB chunks=%d/%lu MiB mesh=%lu MiB particles=%d network=%lu KiB regions=%d meshSteps=%d meshSlice=%lu us.",
        profile->name,profile->detectedPhysicalBytes/(1024UL*1024UL),
        profile->processMemoryCeilingBytes/(1024UL*1024UL),
        profile->residentChunkTarget,
        profile->chunkMemoryCeilingBytes/(1024UL*1024UL),
        profile->meshMemoryCeilingBytes/(1024UL*1024UL),
        profile->particleLimit,
        profile->networkReadQueueCeilingBytes/1024UL,
        profile->regionFileLimit,profile->meshStepsPerFrame,
        (unsigned long)(profile->meshWorkSeconds*1000000.0));
    CloneMCPlatform_Log(line);
}

static void CloneMCPlatform_ApplyPerformanceSettings(CloneMCGameSettings *settings,
    const CloneMCLegacyProfile *profile)
{
    int maximumChunks;
    if(!settings||!profile)return;
    /* Restore V135's stable meaning: this value is the total resident/visible
     * chunk target.  World derives the largest complete ring that fits it. */
    maximumChunks=profile->residentChunkTarget;
    if(maximumChunks<CLONEMC_RENDER_DISTANCE_MIN_CHUNKS)
        maximumChunks=CLONEMC_RENDER_DISTANCE_MIN_CHUNKS;
    if(maximumChunks>CLONEMC_RENDER_DISTANCE_MAX_CHUNKS)
        maximumChunks=CLONEMC_RENDER_DISTANCE_MAX_CHUNKS;
    settings->renderDistanceMaximumChunks=maximumChunks;
    if(settings->renderDistanceChunks>maximumChunks)
        settings->renderDistanceChunks=maximumChunks;
    CloneMCGameSettings_SynchronizeDerived(settings);
}

static void CloneMCPlatform_ApplyLegacyCompatibilitySettings(
    CloneMCGameSettings *settings,int enabled)
{
    if(!settings)return;
    settings->legacyCompatibility=enabled?1:0;
    if(!enabled)return;
    /* 640x480 is universally representable by Win95/98 display drivers and
     * avoids the former 854x480 -> 800x480 mode that produced a 400x240 GUI
     * on the first frame.  These display/GUI constraints apply to both the
     * 32-chunk and 64-chunk Win98 memory profiles. */
    if(settings->width>640)settings->width=640;
    if(settings->height>480)settings->height=480;
    settings->fullscreen=0;
    if(CloneMCPlatform_IsRealWin9x(GetVersion())){
        settings->colorBits=16;settings->depthBits=16;
    }else{
        /* Do not force a modern OpenGL ICD into an obsolete 16/16 format merely
         * because Explorer applied a Windows 98 version lie.  Several drivers
         * expose that format through the generic software path and fail only
         * after the first successful buffer swap. */
        settings->colorBits=32;settings->depthBits=24;
    }
    settings->fancyGraphics=0;settings->ambientOcclusion=0;
    settings->volumetricClouds=0;
    settings->advancedOpenGL=0;settings->guiScale=1;
    /* Restore the V135 presentation policy.  The forced V146/V147 60 FPS wait
     * loop was entered only in compatibility mode and repeatedly mixed QPC,
     * timeGetTime and Sleep immediately after phase 19.  Users can re-enable a
     * cap after validating the driver, but startup itself remains uncapped. */
    settings->framerateMaximum=60;
    settings->framerateUnlimitedAllowed=1;
    settings->limitFramerate=0;
    CloneMCGameSettings_SynchronizeDerived(settings);
}

/* Retained as a diagnostic compatibility seam for V127SelfTest.  Runtime
 * startup resolves the complete Priority 2 profile once and does not call
 * this helper. */
static int CloneMCPlatform_ApplyWin98SafeProfile(CloneMCGameSettings *settings,
    const char *commandLine)
{
    CloneMCLegacyProfile profile;
    CloneMCPlatform_ResolvePerformanceProfile(&profile,
        commandLine?commandLine:"");
    if(strcmp(profile.name,"win98-safe")!=0)return 0;
    CloneMCPlatform_ApplyPerformanceSettings(settings,&profile);
    CloneMCPlatform_ApplyLegacyCompatibilitySettings(settings,1);
    return 1;
}

static int CloneMCPlatform_AbsoluteInt(int value)
{
    return value < 0 ? -value : value;
}

static int CloneMCPlatform_ParseLongArgument(const char *text, CloneMCJLong *valueOut)
{
    CloneMCJULong value;
    CloneMCJULong limit;
    int negative;
    int digit;
    int count;
    if (!text || !valueOut) { return 0; }
    negative = *text == '-';
    if (*text == '-' || *text == '+') { ++text; }
    limit = ((CloneMCJULong)(negative ? 0x80000000UL : 0x7fffffffUL) << 32) |
        (CloneMCJULong)0xffffffffUL;
    value = 0;
    count = 0;
    while (*text >= '0' && *text <= '9') {
        digit = *text++ - '0';
        if (value > (limit - (CloneMCJULong)digit) / (CloneMCJULong)10) { return 0; }
        value = value * (CloneMCJULong)10 + (CloneMCJULong)digit;
        ++count;
    }
    if (count == 0 || (*text && *text != ' ' && *text != '\t')) { return 0; }
    if (negative) {
        if (value == ((CloneMCJULong)0x80000000UL << 32))
            *valueOut = (CloneMCJLong)value;
        else *valueOut = -(CloneMCJLong)value;
    } else *valueOut = (CloneMCJLong)value;
    return 1;
}

static int CloneMCPlatform_IsUsernameCharacter(unsigned char character)
{
    return (character>='0'&&character<='9')||
        (character>='A'&&character<='Z')||
        (character>='a'&&character<='z')||character=='_';
}

static void CloneMCPlatform_SetUsername(CloneMCWin32App *app,const char *source)
{
    char clean[17];
    unsigned long readIndex;
    unsigned long writeIndex;
    unsigned char character;
    if(!app)return;
    writeIndex=0;
    if(source)for(readIndex=0;source[readIndex]&&writeIndex<16UL;++readIndex){
        character=(unsigned char)source[readIndex];
        if(CloneMCPlatform_IsUsernameCharacter(character))
            clean[writeIndex++]=(char)character;
    }
    clean[writeIndex]='\0';
    if(writeIndex<3UL)strcpy(clean,"Player");
    CloneMCPlatform_CopyText(app->username,sizeof(app->username),clean);
}

static void CloneMCPlatform_ParseMultiplayer(CloneMCWin32App *app, const char *commandLine)
{
    const char *server;
    const char *username;
    const char *end;
    const char *colon;
    unsigned long length;
    int port;
    if(!app)return;
    strcpy(app->username, "Player");
    strcpy(app->worldName, "World1");
    strcpy(app->worldDisplayName,"World1");
    app->worldSeed = (CloneMCJLong)0;
    app->serverPort = 25565;
    if (!commandLine) { return; }
    username = strstr(commandLine, "-username=");
    if (username) {
        username += 10;
        end = username;
        while (*end && *end != ' ' && *end != '\t') { ++end; }
        length = (unsigned long)(end - username);
        if (length > 0 && length < sizeof(app->username)) {
            memcpy(app->username, username, length);
            app->username[length] = '\0';
        }
    }
    CloneMCPlatform_SetUsername(app,app->username);
    username = strstr(commandLine, "-world=");
    if (username) {
        username += 7;
        end = username;
        while (*end && *end != ' ' && *end != '\t') { ++end; }
        length = (unsigned long)(end - username);
        if (length > 0 && length < sizeof(app->worldName)) {
            unsigned long index;
            int safe;
            safe = 1;
            for (index = 0; index < length; ++index) {
                char c;
                c = username[index];
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                      (c >= '0' && c <= '9') || c == '_' || c == '-')) { safe = 0; break; }
            }
            if (safe) { memcpy(app->worldName, username, length); app->worldName[length] = '\0';
                CloneMCPlatform_CopyText(app->worldDisplayName,sizeof(app->worldDisplayName),
                    app->worldName); }
        }
    }
    username = strstr(commandLine, "-seed=");
    if (username) { CloneMCPlatform_ParseLongArgument(username + 6, &app->worldSeed); }
    server = strstr(commandLine, "-server=");
    if (!server) { return; }
    server += 8;
    end = server;
    while (*end && *end != ' ' && *end != '\t') { ++end; }
    colon = server;
    while (colon < end && *colon != ':') { ++colon; }
    length = (unsigned long)((colon < end ? colon : end) - server);
    if (length == 0 || length >= sizeof(app->serverHost)) { return; }
    memcpy(app->serverHost, server, length);
    app->serverHost[length] = '\0';
    if (colon < end) {
        port = atoi(colon + 1);
        if (port > 0 && port <= 65535) { app->serverPort = (unsigned short)port; }
    }
    app->multiplayerMode = 1;
}

static int CloneMCPlatform_CountClientChunks(const CloneMCJ_WorldClient *client)
{
    int i;
    int count;
    if (!client) { return 0; }
    count = 0;
    for (i = 0; i < CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY; ++i) {
        if (client->clientChunkProvider.slots[i].used &&
            client->clientChunkProvider.slots[i].chunk) { ++count; }
    }
    return count;
}

static unsigned long CloneMCPlatform_CountEntities(const CloneMCWin32App *app)
{
    int i;
    unsigned long count;
    if (!app || !app->gameplay) { return 0; }
    count = 1;
    if (app->multiplayerMode) {
        for (i = 0; i < CLONEMC_NET_REMOTE_ENTITIES; ++i) {
            if (app->netClientHandler.remoteEntities[i].active) { ++count; }
        }
    } else {
        for (i = 0; i < CLONEMC_J_MAX_MOBS; ++i) {
            if (app->gameplay->mobs[i].active) { ++count; }
        }
    }
    return count;
}

static CloneMCJ_ItemStack *CloneMCPlatform_GetInventorySlot(
    CloneMCJ_InventoryPlayer *inventory, int logicalSlot)
{
    if (!inventory) { return (CloneMCJ_ItemStack *)0; }
    if (logicalSlot >= 0 && logicalSlot < CLONEMC_J_MAIN_INVENTORY_SIZE) {
        return &inventory->mainInventory[logicalSlot];
    }
    logicalSlot -= CLONEMC_J_MAIN_INVENTORY_SIZE;
    if (logicalSlot >= 0 && logicalSlot < CLONEMC_J_ARMOR_INVENTORY_SIZE) {
        return &inventory->armorInventory[logicalSlot];
    }
    return (CloneMCJ_ItemStack *)0;
}

static int CloneMCPlatform_ClickExternalSlot(CloneMCJ_InventoryPlayer *inventory,
    CloneMCJ_ItemStack *slot,int mouseButton)
{
    CloneMCJ_ItemStack temporary;int amount,room;
    if(!inventory||!slot)return 0;
    if(mouseButton==0){
        if(CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)){
            inventory->carriedStack=*slot;CloneMCJ_ItemStack_Clear(slot);
        }else if(CloneMCJ_ItemStack_IsEmpty(slot)){
            *slot=inventory->carriedStack;CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
        }else if(CloneMCJ_ItemStack_IsStackableWith(slot,&inventory->carriedStack)){
            room=CloneMCJ_ItemStack_GetMaxStackSize(slot)-slot->stackSize;
            amount=room<inventory->carriedStack.stackSize?room:inventory->carriedStack.stackSize;
            slot->stackSize+=amount;inventory->carriedStack.stackSize-=amount;
            if(inventory->carriedStack.stackSize<=0)CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
        }else{temporary=*slot;*slot=inventory->carriedStack;inventory->carriedStack=temporary;}
    }else{
        if(CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)){
            amount=(slot->stackSize+1)/2;inventory->carriedStack=CloneMCJ_ItemStack_Split(slot,amount);
        }else if(CloneMCJ_ItemStack_IsEmpty(slot))*slot=CloneMCJ_ItemStack_Split(&inventory->carriedStack,1);
        else if(CloneMCJ_ItemStack_IsStackableWith(slot,&inventory->carriedStack)&&
            slot->stackSize<CloneMCJ_ItemStack_GetMaxStackSize(slot)){
            ++slot->stackSize;--inventory->carriedStack.stackSize;
            if(inventory->carriedStack.stackSize<=0)CloneMCJ_ItemStack_Clear(&inventory->carriedStack);}
    }
    inventory->inventoryChanged=1;return 1;
}

static int CloneMCPlatform_GetContainerGuiHeight(
    const CloneMCJ_Container *container)
{
    int rows;
    if (!container) return 166;
    if (container->type == CLONEMC_J_CONTAINER_CHEST &&
        container->tileSlotStart >= 0 && container->tileSlotEnd >=
        container->tileSlotStart) {
        /*
         * Inclusive slot count is end - start + 1; ceiling(count / 9) is
         * therefore (end - start + 9) / 9.  The old +10 reported four rows
         * for 27 slots and seven rows for 54, moving the GUI origin away from
         * its actual slot coordinates.
         */
        rows = (container->tileSlotEnd - container->tileSlotStart + 9) / 9;
        if (rows < 1) rows = 1;
        if (rows > 6) rows = 6;
        return 114 + rows * 18;
    }
    return 166;
}

static int CloneMCPlatform_GetGameplayContainerSlotAt(
    const CloneMCJ_GuiIngameState *gui, const CloneMCJ_Container *container,
    int mouseX, int mouseY)
{
    int left;
    int top;
    int height;
    if (!gui || !container) return -1;
    height = CloneMCPlatform_GetContainerGuiHeight(container);
    left = (gui->scaledWidth - 176) / 2;
    top = (gui->scaledHeight - height) / 2;
    /* Java distinguishes an empty gap inside GuiContainer from a click outside
     * the GUI.  Only an outside click is slot -999 and may drop the carried
     * stack.  Treating every negative hit as -999 made clicks between slots
     * unexpectedly throw items and was the root of several apparent slot and
     * armor failures. */
    if (mouseX < left || mouseX >= left + 176 ||
        mouseY < top || mouseY >= top + height) return -999;
    return CloneMCJ_Container_GetSlotAt(container, mouseX - left,
        mouseY - top);
}

static int CloneMCPlatform_GetInventorySlotAt(const CloneMCJ_GuiIngameState *gui,
    int mouseX, int mouseY, int *containerSlot,int chestOpen)
{
    int left;
    int top;
    int column;
    int row;
    if (!gui) { return -1; }
    left = (gui->scaledWidth - 176) / 2;
    top = (gui->scaledHeight - 166) / 2;
    if(chestOpen&&mouseX>=left+8&&mouseX<left+170&&mouseY>=top+18&&mouseY<top+72){
        column=(mouseX-left-8)/18;row=(mouseY-top-18)/18;
        if((mouseX-left-8)%18<16&&(mouseY-top-18)%18<16){
            if(containerSlot)*containerSlot=row*9+column;
            return 40+row*9+column;
        }
    }
    if (mouseX >= left + 8 && mouseX < left + 170 &&
        mouseY >= top + 84 && mouseY < top + 138) {
        column = (mouseX - left - 8) / 18;
        row = (mouseY - top - 84) / 18;
        if ((mouseX - left - 8) % 18 < 16 && (mouseY - top - 84) % 18 < 16) {
            if (containerSlot) { *containerSlot = chestOpen?27+row*9+column:9+row*9+column; }
            return 9 + row * 9 + column;
        }
    }
    if (mouseX >= left + 8 && mouseX < left + 170 &&
        mouseY >= top + 142 && mouseY < top + 158) {
        column = (mouseX - left - 8) / 18;
        if ((mouseX - left - 8) % 18 < 16) {
            if (containerSlot) { *containerSlot = chestOpen?54+column:36+column; }
            return column;
        }
    }
    if (!chestOpen&&mouseX >= left + 8 && mouseX < left + 24 &&
        mouseY >= top + 8 && mouseY < top + 80) {
        row = (mouseY - top - 8) / 18;
        if ((mouseY - top - 8) % 18 < 16 && row >= 0 && row < 4) {
            if (containerSlot) { *containerSlot = 5 + row; }
            return CLONEMC_J_MAIN_INVENTORY_SIZE + (3 - row);
        }
    }
    return -1;
}

static int CloneMCPlatform_MoveStackRange(CloneMCJ_InventoryPlayer *inventory,
    int sourceSlot, int firstSlot, int lastSlot)
{
    CloneMCJ_ItemStack *source;
    CloneMCJ_ItemStack *target;
    int index;
    int maximum;
    int room;
    int transfer;
    int moved;
    source = CloneMCPlatform_GetInventorySlot(inventory, sourceSlot);
    if (!source || CloneMCJ_ItemStack_IsEmpty(source)) { return 0; }
    moved = 0;
    for (index = firstSlot; index <= lastSlot && !CloneMCJ_ItemStack_IsEmpty(source); ++index) {
        target = CloneMCPlatform_GetInventorySlot(inventory, index);
        if (!target || !CloneMCJ_ItemStack_IsStackableWith(target, source)) { continue; }
        maximum = CloneMCJ_ItemStack_GetMaxStackSize(target);
        room = maximum - target->stackSize;
        transfer = room < source->stackSize ? room : source->stackSize;
        if (transfer > 0) {
            target->stackSize += transfer;
            source->stackSize -= transfer;
            moved = 1;
        }
    }
    for (index = firstSlot; index <= lastSlot && !CloneMCJ_ItemStack_IsEmpty(source); ++index) {
        target = CloneMCPlatform_GetInventorySlot(inventory, index);
        if (!target || !CloneMCJ_ItemStack_IsEmpty(target)) { continue; }
        *target = *source;
        CloneMCJ_ItemStack_Clear(source);
        moved = 1;
    }
    if (source->stackSize <= 0) { CloneMCJ_ItemStack_Clear(source); }
    if (moved) { inventory->inventoryChanged = 1; }
    return moved;
}

static int CloneMCPlatform_MoveStackToCargo(CloneMCJ_InventoryPlayer *inventory,
    CloneMCJ_ItemStack *source,CloneMCJ_ItemStack cargo[27])
{
    int index,maximum,room,transfer,moved;moved=0;
    if(!inventory||!source||CloneMCJ_ItemStack_IsEmpty(source))return 0;
    for(index=0;index<27&&!CloneMCJ_ItemStack_IsEmpty(source);++index){
        if(!CloneMCJ_ItemStack_IsStackableWith(&cargo[index],source))continue;
        maximum=CloneMCJ_ItemStack_GetMaxStackSize(&cargo[index]);room=maximum-cargo[index].stackSize;
        transfer=room<source->stackSize?room:source->stackSize;if(transfer>0){
            cargo[index].stackSize+=transfer;source->stackSize-=transfer;moved=1;}}
    for(index=0;index<27&&!CloneMCJ_ItemStack_IsEmpty(source);++index)if(CloneMCJ_ItemStack_IsEmpty(&cargo[index])){
        cargo[index]=*source;CloneMCJ_ItemStack_Clear(source);moved=1;break;}
    if(moved)inventory->inventoryChanged=1;
    return moved;
}

static int CloneMCPlatform_ShiftInventorySlot(CloneMCJ_InventoryPlayer *inventory,
    int logicalSlot)
{
    if (logicalSlot >= 0 && logicalSlot < 9) {
        return CloneMCPlatform_MoveStackRange(inventory, logicalSlot, 9, 35);
    }
    if (logicalSlot >= 9 && logicalSlot < 36) {
        return CloneMCPlatform_MoveStackRange(inventory, logicalSlot, 0, 8);
    }
    if (logicalSlot >= 36 && logicalSlot < 40) {
        return CloneMCPlatform_MoveStackRange(inventory, logicalSlot, 9, 35);
    }
    return 0;
}

static int CloneMCPlatform_CreativeBlockAllowed(int id)
{
    /* Skip air, flowing/still liquid internals, fire, piston transient pieces,
     * powered-state duplicates, portal and locked-chest placeholders. */
    if(id<=0||id>=256)return 0;
    if((id>=8&&id<=11)||id==34||id==36||id==51||id==62||id==74||id==90||id==94||id==95)
        return 0;
    return CloneMCJ_BlockRegistry_Get(id)->registered!=0;
}

static void CloneMCPlatform_CreativeAppend(CloneMCJ_GuiIngameState *gui,int itemID,int damage)
{
    int index;if(!gui||gui->creativeCatalogCount>=CLONEMC_GUI_CREATIVE_CAPACITY)return;
    for(index=0;index<gui->creativeCatalogCount;++index)
        if(gui->creativeItemID[index]==itemID&&gui->creativeItemDamage[index]==damage)return;
    index=gui->creativeCatalogCount++;gui->creativeItemID[index]=(short)itemID;
    gui->creativeItemDamage[index]=(short)damage;
}

static void CloneMCPlatform_RebuildCreativeCatalog(CloneMCWin32App *app,int tab)
{
    CloneMCJ_GuiIngameState *gui;const CloneMCJ_ItemDefinition *item;
    static const short blockItems[][2]={
        {4,0},{1,0},{56,0},{14,0},{15,0},{16,0},{21,0},{73,0},
        {98,0},{98,1},{98,2},{98,3},{82,0},{57,0},{41,0},{42,0},
        {7,0},{22,0},{45,0},{48,0},{44,0},{44,1},{44,2},{44,3},
        {44,4},{44,5},{49,0},{87,0},{88,0},{89,0},
        {17,0},{17,1},{17,2},{17,3},{18,0},{18,1},{18,2},{18,3},
        {3,0},{2,0},{12,0},{24,0},{13,0},{30,0},{5,0},
        {6,0},{6,1},{6,2},{6,3},{32,0},{19,0},{79,0},{80,0},
        {37,0},{38,0},{39,0},{40,0},{81,0},{103,0},{86,0},{91,0},
        {106,0},{101,0},{102,0},{112,0},{113,0},{114,0},{121,0},
        {110,0},{111,0},{31,1},{31,2},{54,0},{58,0},{20,0},{46,0},
        {47,0},{35,0},{35,1},{35,2},{35,3},{35,4},{35,5},{35,6},
        {35,7},{35,8},{35,9},{35,10},{35,11},{35,12},{35,13},
        {35,14},{35,15},{23,0},{61,0},{25,0},{84,0},{29,0},{33,0},
        {85,0},{107,0},{65,0},{66,0},{27,0},{28,0},{50,0},{53,0},
        {67,0},{108,0},{109,0},{69,0},{70,0},{72,0},{76,0},{77,0},
        {96,0},{116,0},{123,0}
    };
    static const short eggIDs[]={
        50,51,52,54,55,56,57,58,59,60,61,62,
        90,91,92,93,94,95,96,98,120
    };
    unsigned int index;
    int id,damage;if(!app)return;gui=&app->guiIngame;gui->creativeCatalogCount=0;
    gui->creativeTab=tab;if(gui->creativeTab<0||gui->creativeTab>2)gui->creativeTab=0;
    if(gui->creativeTab==0||gui->creativeTab==1){
        /* ContainerCreative.java uses a hand-authored list, not a scan of all
         * 256 block IDs.  This removes moving-piston, lit-state and unknown
         * placeholders while retaining every intentional metadata variant. */
        for(index=0;index<sizeof(blockItems)/sizeof(blockItems[0]);++index)
            CloneMCPlatform_CreativeAppend(gui,blockItems[index][0],
                blockItems[index][1]);
    }
    if(gui->creativeTab==0||gui->creativeTab==2){
        for(id=256;id<CLONEMC_J_ITEM_REGISTRY_SIZE;++id){
            item=CloneMCJ_ItemRegistry_Get(id);
            if(!item||!CloneMCJ_ItemRegistry_IsRegistered(id))continue;
            if(id==373||id==383)continue;
            CloneMCPlatform_CreativeAppend(gui,id,0);
        }
        for(damage=1;damage<16;++damage)
            CloneMCPlatform_CreativeAppend(gui,351,damage);
        for(index=0;index<sizeof(eggIDs)/sizeof(eggIDs[0]);++index)
            CloneMCPlatform_CreativeAppend(gui,383,eggIDs[index]);
    }
    gui->creativePage=0;
}

static void CloneMCPlatform_OpenCreativeInventory(CloneMCWin32App *app)
{
    if(!app||!app->gameplay)return;
    app->guiIngame.inventoryOpen=1;app->guiIngame.creativeInventoryOpen=1;
    app->guiIngame.pauseMenu=0;app->guiIngame.hoveredSlot=-1;
    app->gameplay->openVehicleInventoryId=0;
    if(app->gameplay->openContainerActive)CloneMCJ_Gameplay_CloseOpenContainer(app->gameplay);
    CloneMCPlatform_RebuildCreativeCatalog(app,app->guiIngame.creativeTab);
}

static int CloneMCPlatform_CreativeSlotAt(const CloneMCJ_GuiIngameState *gui,int mouseX,int mouseY)
{
    int left,top,column,row,local;if(!gui)return -1;
    left=(gui->scaledWidth-176)/2;top=(gui->scaledHeight-166)/2;
    if(mouseX>=left+7&&mouseX<left+169&&mouseY>=top+18&&mouseY<top+108){
        column=(mouseX-left-7)/18;row=(mouseY-top-18)/18;
        if(column>=0&&column<9&&row>=0&&row<5&&
           ((mouseX-left-7)%18)<16&&((mouseY-top-18)%18)<16){
            local=row*9+column;
            if(gui->creativePage*CLONEMC_GUI_CREATIVE_PAGE_SIZE+local<gui->creativeCatalogCount)
                return local;
        }
    }
    return -1;
}

static int CloneMCPlatform_CreativeHotbarSlotAt(const CloneMCJ_GuiIngameState *gui,
    int mouseX,int mouseY)
{
    int left,top,column;if(!gui)return -1;
    left=(gui->scaledWidth-176)/2;top=(gui->scaledHeight-166)/2;
    if(mouseX>=left+8&&mouseX<left+170&&mouseY>=top+142&&mouseY<top+158){
        column=(mouseX-left-8)/18;
        if(column>=0&&column<9&&((mouseX-left-8)%18)<16)return column;
    }
    return -1;
}

static void CloneMCPlatform_CreativeSetCarried(CloneMCWin32App *app,int catalogIndex,int count,int toHotbar)
{
    CloneMCJ_InventoryPlayer *inventory;const CloneMCJ_ItemDefinition *definition;
    CloneMCJ_ItemStack stack;int maximum;if(!app||!app->gameplay)return;
    if(catalogIndex<0||catalogIndex>=app->guiIngame.creativeCatalogCount)return;
    inventory=&app->gameplay->player.inventory;
    CloneMCJ_ItemStack_Initialize(&stack,app->guiIngame.creativeItemID[catalogIndex],1,
        app->guiIngame.creativeItemDamage[catalogIndex]);
    definition=CloneMCJ_ItemRegistry_Get(stack.itemID);maximum=definition?definition->maxStackSize:64;
    if(maximum<1)maximum=1;if(maximum>64)maximum=64;stack.stackSize=count>0?count:maximum;
    if(stack.stackSize>maximum)stack.stackSize=maximum;
    if(toHotbar){inventory->mainInventory[inventory->currentItem]=stack;inventory->inventoryChanged=1;}
    else inventory->carriedStack=stack;
}

static void CloneMCPlatform_HandleCreativeClick(CloneMCWin32App *app,int mouseButton)
{
    CloneMCJ_InventoryPlayer *inventory;
    int local,index,left,top,pageCount,hotbarSlot;int shift;
    if(!app||!app->gameplay)return;
    inventory=&app->gameplay->player.inventory;
    left=(app->guiIngame.scaledWidth-176)/2;top=(app->guiIngame.scaledHeight-166)/2;
    /* Tabs: All, Blocks, Items. */
    if(app->guiIngame.mouseY>=top-18&&app->guiIngame.mouseY<top+2){
        if(app->guiIngame.mouseX>=left+6&&app->guiIngame.mouseX<left+56)
            CloneMCPlatform_RebuildCreativeCatalog(app,0);
        else if(app->guiIngame.mouseX>=left+62&&app->guiIngame.mouseX<left+112)
            CloneMCPlatform_RebuildCreativeCatalog(app,1);
        else if(app->guiIngame.mouseX>=left+118&&app->guiIngame.mouseX<left+168)
            CloneMCPlatform_RebuildCreativeCatalog(app,2);
        return;
    }
    pageCount=(app->guiIngame.creativeCatalogCount+CLONEMC_GUI_CREATIVE_PAGE_SIZE-1)/CLONEMC_GUI_CREATIVE_PAGE_SIZE;
    if(pageCount<1)pageCount=1;
    if(app->guiIngame.mouseY>=top+112&&app->guiIngame.mouseY<top+132){
        if(app->guiIngame.mouseX>=left+8&&app->guiIngame.mouseX<left+38){
            if(app->guiIngame.creativePage>0)--app->guiIngame.creativePage;return;}
        if(app->guiIngame.mouseX>=left+138&&app->guiIngame.mouseX<left+168){
            if(app->guiIngame.creativePage+1<pageCount)++app->guiIngame.creativePage;return;}
    }
    /* The catalogue is generated UI, not an InventoryPlayer container.  Give
     * its visible hotbar an explicit route into the real nine usable slots. */
    hotbarSlot=CloneMCPlatform_CreativeHotbarSlotAt(&app->guiIngame,
        app->guiIngame.mouseX,app->guiIngame.mouseY);
    if(hotbarSlot>=0){
        CloneMCPlatform_ClickExternalSlot(inventory,
            &inventory->mainInventory[hotbarSlot],mouseButton);
        return;
    }
    local=CloneMCPlatform_CreativeSlotAt(&app->guiIngame,app->guiIngame.mouseX,
        app->guiIngame.mouseY);if(local<0)return;
    index=app->guiIngame.creativePage*CLONEMC_GUI_CREATIVE_PAGE_SIZE+local;
    shift=CloneMCInput_IsKeyDown(&app->input,VK_SHIFT);
    CloneMCPlatform_CreativeSetCarried(app,index,mouseButton==1?1:0,shift);
}

static int CloneMCPlatform_HandleForwardTapAt(CloneMCWin32App *app,unsigned long now)
{
    unsigned long elapsed;CloneMCJ_EntityPlayer *player;char line[64];
    if(!app||!app->gameplay)return 0;player=&app->gameplay->player;
    if(player->gameMode==CLONEMC_J_GAMEMODE_SURVIVAL){
        if(!app->settings.doubleTapSprint||app->multiplayerMode||
           (app->world&&app->world->multiplayerWorld)){
            CloneMCJ_EntityPlayer_SetSprinting(player,0);
            app->lastForwardTapMilliseconds=0UL;return 0;
        }
        elapsed=now-app->lastForwardTapMilliseconds;
        if(app->lastForwardTapMilliseconds&&elapsed>=40UL&&elapsed<=350UL){
            /* Java starts the legacy double-tap sprint from the ground, then
             * keeps it active through a jump until another cancellation rule
             * fires.  Requiring ground only here avoids cancelling the sprint
             * on the first airborne tick. */
            if(!player->entity.onGround){
                app->lastForwardTapMilliseconds=0UL;return 0;
            }
            CloneMCJ_EntityPlayer_SetSprinting(player,1);
            app->lastForwardTapMilliseconds=0UL;
            return CloneMCJ_EntityPlayer_IsSprinting(player);
        }
        app->lastForwardTapMilliseconds=now;return 0;
    }
    CloneMCJ_EntityPlayer_SetSprinting(player,0);
    if(!player->allowFlying){app->lastForwardTapMilliseconds=0UL;return 0;}
    elapsed=now-app->lastForwardTapMilliseconds;
    if(app->lastForwardTapMilliseconds&&elapsed>=40UL&&elapsed<=350UL){
        if(player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR)player->flying=1;
        else player->flying=(unsigned char)(player->flying?0:1);
        player->entity.noClip=(unsigned char)(player->gameMode==CLONEMC_J_GAMEMODE_SPECTATOR);
        player->entity.fallDistance=0.0F;player->entity.motionY=0.0;
        sprintf(line,"Flight %s",player->flying?"enabled":"disabled");
        CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,line);
        app->lastForwardTapMilliseconds=0UL;return 1;
    }
    app->lastForwardTapMilliseconds=now;return 0;
}

static void CloneMCPlatform_ToggleFlightFromForwardTap(CloneMCWin32App *app,int guiBlocksInput)
{
    int forwardKey;if(!app||!app->gameplay)return;
    if(app->gameplay->player.gameMode==CLONEMC_J_GAMEMODE_SURVIVAL&&
       (!app->settings.doubleTapSprint||app->multiplayerMode))
        CloneMCJ_EntityPlayer_SetSprinting(&app->gameplay->player,0);
    if(guiBlocksInput)return;
    forwardKey=app->settings.keyCodes[0];
    if(!CloneMCInput_ConsumeKeyPress(&app->input,forwardKey))return;
    (void)CloneMCPlatform_HandleForwardTapAt(app,timeGetTime());
}

static void CloneMCPlatform_UpdateGuiCursor(CloneMCWin32App *app)
{
    int clientX;
    int clientY;
    int containerSlot;
    int chestOpen;
    CloneMCJ_Container *gameplayContainer;
    if (!app || app->listener.width < 1 || app->listener.height < 1) { return; }
    if (!CloneMCMouseHelper_GetClientPosition(&app->mouse, &clientX, &clientY)) { return; }
    app->guiIngame.mouseX = clientX * app->guiIngame.scaledWidth / app->listener.width;
    app->guiIngame.mouseY = clientY * app->guiIngame.scaledHeight / app->listener.height;
    containerSlot = -1;
    gameplayContainer = app->gameplay ?
        CloneMCJ_Gameplay_GetOpenContainer(app->gameplay) :
        (CloneMCJ_Container *)0;
    if(app->guiIngame.inventoryOpen&&app->guiIngame.creativeInventoryOpen){
        app->guiIngame.hoveredSlot=CloneMCPlatform_CreativeSlotAt(&app->guiIngame,
            app->guiIngame.mouseX,app->guiIngame.mouseY);
        if(app->guiIngame.hoveredSlot<0){
            int creativeHotbarSlot;
            creativeHotbarSlot=CloneMCPlatform_CreativeHotbarSlotAt(&app->guiIngame,
                app->guiIngame.mouseX,app->guiIngame.mouseY);
            if(creativeHotbarSlot>=0)
                app->guiIngame.hoveredSlot=CLONEMC_GUI_CREATIVE_PAGE_SIZE+
                    creativeHotbarSlot;
        }
    } else if (app->guiIngame.inventoryOpen && gameplayContainer) {
        app->guiIngame.hoveredSlot =
            CloneMCPlatform_GetGameplayContainerSlotAt(&app->guiIngame,
                gameplayContainer, app->guiIngame.mouseX,
                app->guiIngame.mouseY);
        if (app->guiIngame.hoveredSlot < 0)
            app->guiIngame.hoveredSlot = -1;
    } else {
        chestOpen=app->gameplay&&
            CloneMCJ_Gameplay_GetOpenVehicleInventory(app->gameplay)?1:0;
        app->guiIngame.hoveredSlot = app->guiIngame.inventoryOpen ?
            CloneMCPlatform_GetInventorySlotAt(&app->guiIngame,
                app->guiIngame.mouseX, app->guiIngame.mouseY,
                &containerSlot,chestOpen) : -1;
    }
}

static void CloneMCPlatform_CloseInventory(CloneMCWin32App *app)
{
    CloneMCJ_ItemStack *carried;
    if (!app || !app->guiIngame.inventoryOpen) { return; }
    if (app->multiplayerMode) {
        CloneMCPlayerControllerMP_SendCloseWindow(&app->multiplayerController,
            app->netClientHandler.openWindowId >= 0 ? app->netClientHandler.openWindowId : 0);
    } else if (app->gameplay) {
        if (app->gameplay->openContainerActive)
            CloneMCJ_Gameplay_CloseOpenContainer(app->gameplay);
        carried = &app->gameplay->player.inventory.carriedStack;
        if(app->guiIngame.creativeInventoryOpen){
            /* Creative catalog stacks are generated, not owned world items.
             * Closing the screen discards the cursor copy instead of spawning
             * an infinite ground-item entity. */
            CloneMCJ_ItemStack_Clear(carried);
        }else if (!CloneMCJ_ItemStack_IsEmpty(carried) &&
            CloneMCJ_Gameplay_SpawnDrop(app->gameplay, app->gameplay->player.entity.posX,
                app->gameplay->player.entity.posY + 1.32,
                app->gameplay->player.entity.posZ, carried, 40, 0)) {
            CloneMCJ_ItemStack_Clear(carried);
        }
    }
    app->guiIngame.inventoryOpen = 0;
    app->guiIngame.creativeInventoryOpen=0;
    app->guiIngame.hoveredSlot = -1;
    if(app->gameplay){
        app->gameplay->openVehicleInventoryId=0;
        app->gameplay->openContainerActive=0;
    }
}

static void CloneMCPlatform_HandleInventoryClick(CloneMCWin32App *app, int mouseButton)
{
    CloneMCJ_InventoryPlayer *inventory;
    CloneMCJ_ItemStack before;
    CloneMCJ_ItemStack *slotStack;
    int logicalSlot;
    int containerSlot;
    int shift;
    int windowId;
    CloneMCJ_Vehicle *chest;
    if (!app || !app->gameplay || !app->guiIngame.inventoryOpen) { return; }
    if(app->guiIngame.creativeInventoryOpen){CloneMCPlatform_HandleCreativeClick(app,mouseButton);return;}
    inventory = &app->gameplay->player.inventory;
    {
        CloneMCJ_Container *gameplayContainer;
        CloneMCJ_ItemStack dropped;
        short action;
        int changed;
        int enchantLeft;
        int enchantTop;
        int enchantOffer;
        int merchantLeft;
        int merchantTop;
        int merchantOffer;
        gameplayContainer = CloneMCJ_Gameplay_GetOpenContainer(app->gameplay);
        if (gameplayContainer) {
            if(gameplayContainer->type==CLONEMC_J_CONTAINER_MERCHANT&&
               app->gameplay->openMerchantMobIndex>=0){
                CloneMCJ_Mob *merchant;
                merchant=&app->gameplay->mobs[
                    app->gameplay->openMerchantMobIndex];
                merchantLeft=(app->guiIngame.scaledWidth-176)/2;
                merchantTop=(app->guiIngame.scaledHeight-166)/2;
                merchantOffer=merchant->selectedTrade;
                if(app->guiIngame.mouseY>=merchantTop+27&&
                   app->guiIngame.mouseY<merchantTop+47){
                    if(app->guiIngame.mouseX>=merchantLeft+78&&
                       app->guiIngame.mouseX<merchantLeft+91)
                        CloneMCJ_V136_SelectMerchantTrade(app->gameplay,
                            merchantOffer>0?merchantOffer-1:
                            merchant->tradeCount-1);
                    else if(app->guiIngame.mouseX>=merchantLeft+101&&
                            app->guiIngame.mouseX<merchantLeft+114)
                        CloneMCJ_V136_SelectMerchantTrade(app->gameplay,
                            merchantOffer+1<merchant->tradeCount?
                            merchantOffer+1:0);
                    else merchantOffer=-1;
                    if(merchantOffer>=0)return;
                }
            }
            if(gameplayContainer->type==CLONEMC_J_CONTAINER_ENCHANTMENT){
                enchantLeft=(app->guiIngame.scaledWidth-176)/2;
                enchantTop=(app->guiIngame.scaledHeight-166)/2;
                for(enchantOffer=0;enchantOffer<3;++enchantOffer)
                    if(app->guiIngame.mouseX>=enchantLeft+60&&
                       app->guiIngame.mouseX<enchantLeft+168&&
                       app->guiIngame.mouseY>=enchantTop+14+enchantOffer*19&&
                       app->guiIngame.mouseY<enchantTop+31+enchantOffer*19){
                        CloneMCJ_Progression_ClickEnchant(app->gameplay,
                            enchantOffer);
                        return;
                    }
            }
            containerSlot = CloneMCPlatform_GetGameplayContainerSlotAt(
                &app->guiIngame, gameplayContainer,
                app->guiIngame.mouseX, app->guiIngame.mouseY);
            /* Empty background inside the GUI is not an outside drop. */
            if (containerSlot == -1) return;
            if(gameplayContainer->type==CLONEMC_J_CONTAINER_MERCHANT&&
               containerSlot==2){
                CloneMCJ_V136_CompleteMerchantTrade(app->gameplay);
                return;
            }
            CloneMCJ_ItemStack_Clear(&before);
            if (containerSlot >= 0 &&
                containerSlot < gameplayContainer->slotCount &&
                gameplayContainer->slots[containerSlot] &&
                !CloneMCJ_ItemStack_IsEmpty(
                    gameplayContainer->slots[containerSlot]))
                before = *gameplayContainer->slots[containerSlot];
            shift = CloneMCInput_IsKeyDown(&app->input, VK_SHIFT);
            action = app->multiplayerMode ?
                app->netClientHandler.nextTransactionId : (short)-1;
            if (app->multiplayerMode &&
                !CloneMCJ_Container_BeginTransactionWithId(gameplayContainer,
                    inventory, action))
                return;
            changed = CloneMCJ_Container_ClickEx(gameplayContainer,
                inventory, containerSlot, mouseButton, shift);
            if(changed&&!app->multiplayerMode&&
               gameplayContainer->type==
               CLONEMC_J_CONTAINER_ENCHANTMENT)
                CloneMCJ_Progression_RefreshEnchantOffers(app->gameplay);
            if(changed&&!app->multiplayerMode&&
               gameplayContainer->type==CLONEMC_J_CONTAINER_MERCHANT)
                CloneMCJ_V136_RefreshMerchantResult(app->gameplay);
            if (!changed && app->multiplayerMode)
                CloneMCJ_Container_ResolveTransaction(gameplayContainer,
                    inventory, action, 1);
            if (CloneMCJ_Container_TakeDroppedStack(gameplayContainer,
                &dropped)) {
                if (!app->multiplayerMode)
                    CloneMCJ_Gameplay_SpawnDrop(app->gameplay,
                        app->gameplay->player.entity.posX,
                        app->gameplay->player.entity.posY + 1.32,
                        app->gameplay->player.entity.posZ,
                        &dropped, 40, 0);
            }
            if (changed && app->multiplayerMode) {
                windowId = app->netClientHandler.openWindowId >= 0 ?
                    app->netClientHandler.openWindowId : 0;
                if (!CloneMCPlayerControllerMP_SendWindowClick(
                    &app->multiplayerController, windowId,
                    containerSlot, mouseButton, shift, &before))
                    CloneMCJ_Container_ResolveTransaction(gameplayContainer,
                        inventory, action, 0);
            }
            return;
        }
    }
    chest=CloneMCJ_Gameplay_GetOpenVehicleInventory(app->gameplay);
    containerSlot = -1;
    logicalSlot = CloneMCPlatform_GetInventorySlotAt(&app->guiIngame,
        app->guiIngame.mouseX, app->guiIngame.mouseY, &containerSlot,chest?1:0);
    if (logicalSlot < 0) { return; }
    slotStack=logicalSlot>=40&&logicalSlot<67&&chest?&chest->cargo[logicalSlot-40]:
        CloneMCPlatform_GetInventorySlot(inventory,logicalSlot);
    CloneMCJ_ItemStack_Clear(&before);
    if (slotStack && !CloneMCJ_ItemStack_IsEmpty(slotStack)) { before = *slotStack; }
    shift = CloneMCInput_IsKeyDown(&app->input, VK_SHIFT);
    if(shift&&chest&&logicalSlot>=40)CloneMCJ_InventoryPlayer_AddItemStack(inventory,slotStack);
    else if(shift&&chest)CloneMCPlatform_MoveStackToCargo(inventory,slotStack,chest->cargo);
    else if(shift)CloneMCPlatform_ShiftInventorySlot(inventory,logicalSlot);
    else if(chest&&logicalSlot>=40)CloneMCPlatform_ClickExternalSlot(inventory,slotStack,mouseButton);
    else CloneMCJ_InventoryPlayer_ClickSlot(inventory,logicalSlot,mouseButton);
    if (app->multiplayerMode) {
        windowId = app->netClientHandler.openWindowId >= 0 ?
            app->netClientHandler.openWindowId : 0;
        CloneMCPlayerControllerMP_SendWindowClick(&app->multiplayerController, windowId,
            containerSlot, mouseButton, shift, &before);
    }
}

static void CloneMCPlatform_CloseChat(CloneMCWin32App *app)
{
    if (!app) return;
    app->guiIngame.chatOpen = 0;
    app->guiIngame.chatInput[0] = '\0';
    app->input.typedCharacterCount = 0;
    CloneMCMouseHelper_SetGrabbed(&app->mouse,
        app->guiIngame.inventoryOpen || app->guiIngame.pauseMenu ? 0 : 1);
}

static void CloneMCPlatform_OpenChat(CloneMCWin32App *app)
{
    if (!app || app->guiIngame.inventoryOpen || app->guiIngame.pauseMenu) return;
    app->guiIngame.chatOpen = 1;
    app->guiIngame.chatInput[0] = '\0';
    /* Drop the WM_CHAR generated by the key that opened the screen, matching
     * GuiChat rather than inserting a leading 't'. */
    app->input.typedCharacterCount = 0;
    CloneMCMouseHelper_SetGrabbed(&app->mouse, 0);
}

static const char *CloneMCPlatform_GameModeName(int mode)
{
    if(mode==CLONEMC_J_GAMEMODE_CREATIVE)return "Creative";
    if(mode==CLONEMC_J_GAMEMODE_SPECTATOR)return "Spectator";
    return "Survival";
}

static void CloneMCPlatform_ApplyGameMode(CloneMCWin32App *app,int mode,int announce)
{
    char line[96];CloneMCJ_EntityPlayer *player;
    if(!app||!app->gameplay||!app->world)return;
    if(mode!=CLONEMC_J_GAMEMODE_CREATIVE&&mode!=CLONEMC_J_GAMEMODE_SPECTATOR)
        mode=CLONEMC_J_GAMEMODE_SURVIVAL;
    player=&app->gameplay->player;player->gameMode=mode;
    player->sprinting=0;app->lastForwardTapMilliseconds=0UL;
    player->allowFlying=(unsigned char)(mode!=CLONEMC_J_GAMEMODE_SURVIVAL);
    player->flying=(unsigned char)(mode==CLONEMC_J_GAMEMODE_SPECTATOR);
    player->invulnerable=player->allowFlying;
    player->entity.noClip=(unsigned char)(mode==CLONEMC_J_GAMEMODE_SPECTATOR);
    if(mode==CLONEMC_J_GAMEMODE_SPECTATOR)player->flying=1;
    player->entity.fallDistance=0.0F;if(player->health<=0)player->health=20;
    app->world->worldInfo.gameType=mode;
    if(announce){sprintf(line,"Game mode changed to %s",CloneMCPlatform_GameModeName(mode));
        CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,line);}
}

static int CloneMCPlatform_ParseGameMode(const char *text)
{
    if(!text)return -1;while(*text==' '||*text=='\t')++text;
    if(!strcmp(text,"0")||!CloneMCPlatform_StrICmp(text,"survival")||
       !CloneMCPlatform_StrICmp(text,"s"))return CLONEMC_J_GAMEMODE_SURVIVAL;
    if(!strcmp(text,"1")||!CloneMCPlatform_StrICmp(text,"creative")||
       !CloneMCPlatform_StrICmp(text,"c"))return CLONEMC_J_GAMEMODE_CREATIVE;
    if(!strcmp(text,"3")||!CloneMCPlatform_StrICmp(text,"spectator")||
       !CloneMCPlatform_StrICmp(text,"sp"))return CLONEMC_J_GAMEMODE_SPECTATOR;
    return -1;
}

static void CloneMCPlatform_SubmitChat(CloneMCWin32App *app)
{
    char message[101];
    int first;
    int last;
    int length;
    if (!app) return;
    strncpy(message, app->guiIngame.chatInput, sizeof(message) - 1);
    message[sizeof(message) - 1] = '\0';
    length = (int)strlen(message);
    first = 0;
    while (first < length && (message[first] == ' ' || message[first] == '\t')) ++first;
    last = length;
    while (last > first && (message[last - 1] == ' ' || message[last - 1] == '\t')) --last;
    if (first > 0 && last > first) memmove(message, message + first,
        (unsigned long)(last - first));
    message[last - first] = '\0';
    if (message[0]) {
        if (app->multiplayerMode && app->netClientInitialized &&
            app->networkManager.connected) {
            /* Packet 3 carries chat and slash commands verbatim.  Do not
             * interpret /login, /register or server plugin commands locally. */
            if (!CloneMCPlayerControllerMP_SendChat(&app->multiplayerController,
                    message))
                CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,
                    "Unable to queue chat message");
        } else if(message[0]=='/'&&app->compatibilityPolicy.allowCommands&&
            app->world&&app->gameplay) {
            if(!strncmp(message,"/gamemode",9)&&(message[9]==' '||message[9]=='\t')){
                int mode;if(!app->world->worldInfo.allowCommands)
                    CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,
                        "Cheats are not enabled for this world");
                else{mode=CloneMCPlatform_ParseGameMode(message+10);
                    if(mode<0)CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,
                        "Usage: /gamemode survival|creative|spectator");
                    else CloneMCPlatform_ApplyGameMode(app,mode,1);}
            }else CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,"Unknown command");
        } else {
            CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,message);
        }
    }
    CloneMCPlatform_CloseChat(app);
}

static void CloneMCPlatform_ProcessChatInput(CloneMCWin32App *app)
{
    int character;
    int length;
    if (!app || !app->guiIngame.chatOpen) return;
    character = CloneMCInput_ConsumeCharacter(&app->input);
    while (character >= 0) {
        length = (int)strlen(app->guiIngame.chatInput);
        if (character == 8) {
            if (length > 0) app->guiIngame.chatInput[length - 1] = '\0';
        } else if (character == 13 || character == 10) {
            CloneMCPlatform_SubmitChat(app);
            return;
        } else if (character == 27) {
            CloneMCPlatform_CloseChat(app);
            return;
        } else if (length < 100 &&
                   CloneMCJ_ChatAllowedCharacters_IsAllowedNative(character)) {
            app->guiIngame.chatInput[length] = (char)character;
            app->guiIngame.chatInput[length + 1] = '\0';
        }
        character = CloneMCInput_ConsumeCharacter(&app->input);
    }
}


static CloneMCJ_TileEntity *CloneMCPlatform_GetSignTile(CloneMCWin32App *app,
    int x,int y,int z)
{
    CloneMCJ_Chunk *chunk;
    CloneMCJ_TileEntity *tile;
    if(!app||!app->world)return (CloneMCJ_TileEntity *)0;
    chunk=CloneMCJ_World_GetChunkFromBlockCoords(app->world,x,z);
    tile=chunk?(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(
        chunk,x&15,y,z&15):(CloneMCJ_TileEntity *)0;
    return tile&&tile->type==CLONEMC_J_TILE_SIGN?tile:(CloneMCJ_TileEntity *)0;
}

static void CloneMCPlatform_CloseSignEditor(CloneMCWin32App *app)
{
    CloneMCJ_Chunk *chunk;
    if(!app||!app->editingSign)return;
    app->editingSign->signLineBeingEdited=-1;
    chunk=app->world?CloneMCJ_World_GetChunkFromBlockCoords(app->world,
        app->editingSign->xCoord,app->editingSign->zCoord):(CloneMCJ_Chunk *)0;
    if(chunk)CloneMCJ_Chunk_SetModified(chunk);
    app->editingSign=(CloneMCJ_TileEntity *)0;
    app->signEditLine=0;app->signEditCounter=0;
    app->guiIngame.signEditorOpen=0;app->guiIngame.editingSign=(CloneMCJ_TileEntity *)0;
    app->guiIngame.signEditLine=0;app->guiIngame.signEditCounter=0;
    app->input.typedCharacterCount=0;
    CloneMCMouseHelper_SetGrabbed(&app->mouse,1);
}

static void CloneMCPlatform_OpenSignEditor(CloneMCWin32App *app,int x,int y,int z)
{
    CloneMCJ_TileEntity *tile;
    if(!app)return;
    tile=CloneMCPlatform_GetSignTile(app,x,y,z);
    if(!tile)return;
    app->editingSign=tile;app->signEditLine=0;app->signEditCounter=0;
    app->guiIngame.signEditorOpen=1;app->guiIngame.editingSign=tile;
    app->guiIngame.signEditLine=0;app->guiIngame.signEditCounter=0;
    tile->signLineBeingEdited=0;
    app->guiIngame.pauseMenu=0;app->guiIngame.inventoryOpen=0;
    app->guiIngame.chatOpen=0;app->input.typedCharacterCount=0;
    CloneMCMouseHelper_SetGrabbed(&app->mouse,0);
    CloneMCJ_GuiIngame_AddChatMessage(&app->guiIngame,
        "Editing sign: type text, Up/Down or Enter changes line, Esc saves");
}

static void CloneMCPlatform_PollSignEditor(CloneMCWin32App *app)
{
    if(!app||!app->gameplay)return;
    if(app->gameplay->editSignRequested){
        int x,y,z;
        x=app->gameplay->editSignX;y=app->gameplay->editSignY;
        z=app->gameplay->editSignZ;app->gameplay->editSignRequested=0;
        CloneMCPlatform_OpenSignEditor(app,x,y,z);
    }
}

static void CloneMCPlatform_ProcessSignInput(CloneMCWin32App *app)
{
    int character,changed;
    if(!app||!app->editingSign)return;
    changed=0;
    if(CloneMCInput_ConsumeKeyPress(&app->input,VK_UP))
        changed|=CloneMCJ_GuiEditSign_KeyTileNative(app->editingSign,
            &app->signEditLine,200,0);
    if(CloneMCInput_ConsumeKeyPress(&app->input,VK_DOWN))
        changed|=CloneMCJ_GuiEditSign_KeyTileNative(app->editingSign,
            &app->signEditLine,208,0);
    character=CloneMCInput_ConsumeCharacter(&app->input);
    while(character>=0){
        if(character!=27)changed|=CloneMCJ_GuiEditSign_KeyTileNative(
            app->editingSign,&app->signEditLine,0,character);
        character=CloneMCInput_ConsumeCharacter(&app->input);
    }
    ++app->signEditCounter;
    app->editingSign->signLineBeingEdited=
        ((app->signEditCounter/6UL)&1UL)?-1:app->signEditLine;
    app->guiIngame.signEditLine=app->signEditLine;
    app->guiIngame.signEditCounter=(int)app->signEditCounter;
    if(changed){
        CloneMCJ_Chunk *chunk;
        chunk=CloneMCJ_World_GetChunkFromBlockCoords(app->world,
            app->editingSign->xCoord,app->editingSign->zCoord);
        if(chunk)CloneMCJ_Chunk_SetModified(chunk);
    }
}

static int CloneMCPlatform_PointInButton(const CloneMCJ_GuiIngameState *gui,
    int centerX, int top, int width)
{
    if (!gui) { return 0; }
    return gui->mouseX >= centerX - width / 2 && gui->mouseX < centerX + width / 2 &&
        gui->mouseY >= top && gui->mouseY < top + 20;
}

static int CloneMCPlatform_ScorePixelFormat(const PIXELFORMATDESCRIPTOR *format,
    int wantedColorBits,int wantedDepthBits,int preferGeneric)
{
    int score;
    if (!format) { return -1000000; }
    if (!(format->dwFlags & PFD_DRAW_TO_WINDOW)) { return -1000000; }
    if (!(format->dwFlags & PFD_SUPPORT_OPENGL)) { return -1000000; }
    if (!(format->dwFlags & PFD_DOUBLEBUFFER)) { return -1000000; }
    if (format->iPixelType != PFD_TYPE_RGBA) { return -1000000; }
    if (format->iLayerType != PFD_MAIN_PLANE) { return -1000000; }

    score = 100000;
    score -= CloneMCPlatform_AbsoluteInt((int)format->cColorBits - wantedColorBits) * 300;
    score -= CloneMCPlatform_AbsoluteInt((int)format->cDepthBits - wantedDepthBits) * 250;
    score -= CloneMCPlatform_AbsoluteInt((int)format->cAlphaBits - 8) * 20;
    if (format->cColorBits < 16) { score -= 30000; }
    if (format->cDepthBits < 16) { score -= 30000; }
    if(preferGeneric){
        if(format->dwFlags&PFD_GENERIC_FORMAT)score+=200000;
        if(format->dwFlags&PFD_GENERIC_ACCELERATED)score+=5000;
    }else if (format->dwFlags & PFD_GENERIC_FORMAT) { score -= 1000; }
    return score;
}

static int CloneMCPlatform_SelectPixelFormat(CloneMCWin32App *app)
{
    PIXELFORMATDESCRIPTOR format;
    PIXELFORMATDESCRIPTOR request;
    int count;
    int index;
    int bestIndex;
    int score;
    int bestScore;

    if (!app || !app->deviceContext) { return 0; }
    memset(&format, 0, sizeof(format));
    count = DescribePixelFormat(app->deviceContext, 1, sizeof(format), &format);
    bestIndex = 0;
    bestScore = -1000000;
    for (index = 1; index <= count; index++) {
        memset(&format, 0, sizeof(format));
        if (!DescribePixelFormat(app->deviceContext, index, sizeof(format), &format)) { continue; }
        score = CloneMCPlatform_ScorePixelFormat(&format,app->settings.colorBits,
            app->settings.depthBits,app->softwareGLRequested);
        if (score > bestScore) {
            bestScore = score;
            bestIndex = index;
            app->pixelFormat = format;
        }
    }

    if (!bestIndex) {
        memset(&request, 0, sizeof(request));
        request.nSize = sizeof(request);
        request.nVersion = 1;
        request.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
        request.iPixelType = PFD_TYPE_RGBA;
        request.cColorBits = (BYTE)app->settings.colorBits;
        request.cDepthBits = (BYTE)app->settings.depthBits;
        request.cAlphaBits = 8;
        request.iLayerType = PFD_MAIN_PLANE;
        bestIndex = ChoosePixelFormat(app->deviceContext, &request);
        if (!bestIndex) { return 0; }
        memset(&app->pixelFormat, 0, sizeof(app->pixelFormat));
        if (!DescribePixelFormat(app->deviceContext, bestIndex,
                                 sizeof(app->pixelFormat), &app->pixelFormat)) { return 0; }
    }
    app->pixelFormatIndex = bestIndex;
    return 1;
}

static int CloneMCPlatform_CreatePalette(CloneMCWin32App *app)
{
    LOGPALETTE *logicalPalette;
    int entryCount;
    int index;
    int redMask;
    int greenMask;
    int blueMask;
    size_t bytes;

    if (!app || !(app->pixelFormat.dwFlags & PFD_NEED_PALETTE)) { return 1; }
    entryCount = 1 << app->pixelFormat.cColorBits;
    if (entryCount > 256) { entryCount = 256; }
    if (entryCount < 1) { return 0; }
    bytes = sizeof(LOGPALETTE) + (size_t)(entryCount - 1) * sizeof(PALETTEENTRY);
    logicalPalette = (LOGPALETTE *)malloc(bytes);
    if (!logicalPalette) { return 0; }
    logicalPalette->palVersion = 0x300;
    logicalPalette->palNumEntries = (WORD)entryCount;
    redMask = (1 << app->pixelFormat.cRedBits) - 1;
    greenMask = (1 << app->pixelFormat.cGreenBits) - 1;
    blueMask = (1 << app->pixelFormat.cBlueBits) - 1;
    for (index = 0; index < entryCount; index++) {
        logicalPalette->palPalEntry[index].peRed = redMask ?
            (BYTE)((((index >> app->pixelFormat.cRedShift) & redMask) * 255) / redMask) : 0;
        logicalPalette->palPalEntry[index].peGreen = greenMask ?
            (BYTE)((((index >> app->pixelFormat.cGreenShift) & greenMask) * 255) / greenMask) : 0;
        logicalPalette->palPalEntry[index].peBlue = blueMask ?
            (BYTE)((((index >> app->pixelFormat.cBlueShift) & blueMask) * 255) / blueMask) : 0;
        logicalPalette->palPalEntry[index].peFlags = 0;
    }
    app->palette = CreatePalette(logicalPalette);
    free(logicalPalette);
    if (!app->palette) { return 0; }
    if(app->pixelFormat.dwFlags&PFD_NEED_SYSTEM_PALETTE){
        /* Windows 95 256-colour hardware can expose one shared hardware
         * palette.  The PFD contract requires a one-to-one mapping while the
         * OpenGL window is active; restore the static colors on shutdown. */
        SetSystemPaletteUse(app->deviceContext,SYSPAL_NOSTATIC);
        app->systemPaletteChanged=1;
    }
    SelectPalette(app->deviceContext, app->palette, FALSE);
    RealizePalette(app->deviceContext);
    return 1;
}

static void CloneMCPlatform_UpdateTitle(CloneMCWin32App *app)
{
    char base[512];
    char title[640];
    if (!app || !app->window) { return; }
    CloneMCOpenGL_FormatWindowTitle(&app->glCaps, base, sizeof(base));
    sprintf(title, "%s | %s/%s | FPS %lu | TPS %lu | p95 %lums | chunks %lu | net %lu",
            base, app->multiplayerMode ? "multiplayer" : "singleplayer",
            app->performanceProfile.name,
            app->lastFramesPerSecond, app->lastTicksPerSecond,
            app->metrics.frameP95Microseconds/1000UL,
            app->metrics.loadedChunkBytes / (unsigned long)sizeof(CloneMCJ_Chunk),
            app->metrics.networkQueueBytes);
    SetWindowTextA(app->window, title);
}

static void CloneMCPlatform_ReleaseGraphics(CloneMCWin32App *app)
{
    if (!app) { return; }
    CloneMCMouseHelper_SetGrabbed(&app->mouse, 0);
    CloneMCRender_Shutdown(&app->renderer);
    if (wglGetCurrentContext() == app->renderingContext) {
        wglMakeCurrent((HDC)0, (HGLRC)0);
    }
    if (app->renderingContext) {
        wglDeleteContext(app->renderingContext);
        app->renderingContext = (HGLRC)0;
    }
    if(app->systemPaletteChanged&&app->deviceContext){
        SetSystemPaletteUse(app->deviceContext,SYSPAL_STATIC);
        app->systemPaletteChanged=0;
    }
    if (app->palette) {
        DeleteObject(app->palette);
        app->palette = (HPALETTE)0;
    }
    if (app->window && app->deviceContext) {
        ReleaseDC(app->window, app->deviceContext);
        app->deviceContext = (HDC)0;
    }
}

static void CloneMCPlatform_QueueResize(CloneMCWin32App *app,int width,
    int height,int minimized)
{
    if(!app)return;
    if(minimized){app->listener.minimized=1;return;}
    app->listener.minimized=0;
    if(width<1||height<1)return;
    /* Before WGL/renderer initialization there is nothing unsafe to defer and
     * the actual client size is needed by renderer startup. */
    if(!app->renderer.initialized){
        CloneMCWindowListener_OnResize(&app->listener,width,height,0);
        return;
    }
    /* WM_SIZE can arrive dozens of times while the Win9x non-client loop owns
     * the thread.  Coalesce to the newest dimensions; never enter OpenGL from
     * the window procedure. */
    app->pendingResizeWidth=width;
    app->pendingResizeHeight=height;
    app->resizePending=1;
}

static int CloneMCPlatform_ApplyPendingResize(CloneMCWin32App *app)
{
    int width,height,oldWidth,oldHeight;
    GLenum resizeError;
    char line[192];
    if(!app||!app->resizePending||app->resizeApplying||app->resizeInteraction||
       app->listener.minimized)
        return 1;
    width=app->pendingResizeWidth;height=app->pendingResizeHeight;
    if(width<1||height<1){app->resizePending=0;return 1;}
    if(app->renderingContext&&wglGetCurrentContext()!=app->renderingContext){
        if(!wglMakeCurrent(app->deviceContext,app->renderingContext)){
            CloneMCPlatform_Log("Deferred resize could not restore the WGL context; resize remains pending.");
            return 0;
        }
    }
    app->resizeApplying=1;app->resizePending=0;
    oldWidth=app->listener.width;oldHeight=app->listener.height;
    CloneMCWindowListener_OnResize(&app->listener,width,height,0);
    app->settings.width=width;app->settings.height=height;
    app->resizeSettingsDirty=1;
    sprintf(line,"Applying deferred client resize %d x %d -> %d x %d",
        oldWidth,oldHeight,width,height);
    CloneMCPlatform_CrashBreadcrumb(line);
    CloneMCRender_Resize(&app->renderer,width,height);
    resizeError=glGetError();
    if(resizeError!=GL_NO_ERROR){
        sprintf(line,"Deferred resize returned OpenGL error 0x%04x",
            (unsigned int)resizeError);
        CloneMCPlatform_Log(line);++app->renderer.glErrorCount;
    }
    if(app->frontendActive)
        CloneMCPlatform_SetFrontendScreen(app,app->guiScreen.screenType);
    CloneMCJ_GuiIngame_UpdateResolutionWithScale(&app->guiIngame,width,height,
        app->settings.guiScale);
    app->resizeAwaitingPresent=1;app->resizeApplying=0;
    if(app->resizeRestoreMouseGrab&&!app->frontendActive&&app->gameplay&&
       !app->guiIngame.inventoryOpen&&!app->guiIngame.pauseMenu&&
       !app->guiIngame.chatOpen&&!app->editingSign){
        CloneMCMouseHelper_SetGrabbed(&app->mouse,1);
    }
    app->resizeRestoreMouseGrab=0;
    CloneMCPlatform_CrashBreadcrumb("deferred resize state committed; post-resize frame pending");
    return 1;
}

static LRESULT CALLBACK CloneMCPlatform_WindowProc(HWND window, UINT message,
                                                    WPARAM wParam, LPARAM lParam)
{
    CloneMCWin32App *app;
    int width;
    int height;
    int minimized;
    int wheel;
    PAINTSTRUCT paint;
    RECT resizeRect;
    MINMAXINFO *minimums;

    app = g_cloneMCWin32App;
    switch (message) {
    case WM_CLOSE:
        if(app){
            if(app->saveInProgress){
                app->closeAfterSave=1;
            }else if(app->world&&app->worldInitialized){
                /* Treat the window close button like Java's disconnect/save
                 * path.  Do not tear down a single-player world before its
                 * forced save transaction succeeds. */
                CloneMCPlatform_RequestSessionExit(app,0,
                    app->multiplayerMode?1:0,"","Window close requested");
            }else CloneMCWindowListener_RequestClose(&app->listener);
        }
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    case WM_ACTIVATEAPP:
        if (app) {
            CloneMCWindowListener_OnFocus(&app->listener, wParam ? 1 : 0,
                                          GetFocus() == window ? 1 : 0);
            if (!wParam) {
                CloneMCInput_Clear(&app->input);
                CloneMCMouseHelper_SetGrabbed(&app->mouse, 0);
            }
        }
        return 0;
    case WM_SETFOCUS:
        if (app) { CloneMCWindowListener_OnFocus(&app->listener, 1, 1); }
        return 0;
    case WM_KILLFOCUS:
        if (app) {
            CloneMCWindowListener_OnFocus(&app->listener, app->listener.active, 0);
            CloneMCInput_Clear(&app->input);
            CloneMCMouseHelper_SetGrabbed(&app->mouse, 0);
        }
        return 0;
    case WM_SIZE:
        if (app) {
            width = (int)(unsigned short)(lParam & 0xffff);
            height = (int)(unsigned short)((lParam >> 16) & 0xffff);
            minimized = wParam == SIZE_MINIMIZED ? 1 : 0;
            CloneMCPlatform_QueueResize(app,width,height,minimized);
        }
        return 0;
    case WM_ENTERSIZEMOVE:
        if(app){
            app->resizeInteraction=1;
            if(app->mouse.grabbed){app->resizeRestoreMouseGrab=1;
                CloneMCMouseHelper_SetGrabbed(&app->mouse,0);}
        }
        return 0;
    case WM_EXITSIZEMOVE:
        if(app){
            app->resizeInteraction=0;
            if(GetClientRect(window,&resizeRect))
                CloneMCPlatform_QueueResize(app,resizeRect.right-resizeRect.left,
                    resizeRect.bottom-resizeRect.top,0);
        }
        return 0;
    case WM_GETMINMAXINFO:
        minimums=(MINMAXINFO *)lParam;
        if(minimums){
            resizeRect.left=0;resizeRect.top=0;
            resizeRect.right=320;resizeRect.bottom=240;
            AdjustWindowRectEx(&resizeRect,(DWORD)GetWindowLongA(window,GWL_STYLE),
                FALSE,(DWORD)GetWindowLongA(window,GWL_EXSTYLE));
            minimums->ptMinTrackSize.x=resizeRect.right-resizeRect.left;
            minimums->ptMinTrackSize.y=resizeRect.bottom-resizeRect.top;
        }
        return 0;
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
        if (app) {
            CloneMCInput_SetKey(&app->input, (int)wParam, 1);
            if (message == WM_SYSKEYDOWN && (int)wParam == VK_F4) {
                CloneMCWindowListener_RequestClose(&app->listener);
            }
        }
        return 0;
    case WM_CHAR:
        if(app){CloneMCInput_AddCharacter(&app->input,(int)wParam);}
        return 0;
    case WM_KEYUP:
    case WM_SYSKEYUP:
        if (app) { CloneMCInput_SetKey(&app->input, (int)wParam, 0); }
        return 0;
    case WM_LBUTTONDOWN:
        if (app) {
            CloneMCInput_SetMouseButton(&app->input, 0, 1);
            if (app->listener.active && app->listener.focused && !app->frontendActive &&
                !app->guiIngame.inventoryOpen && !app->guiIngame.pauseMenu) {
                CloneMCMouseHelper_SetGrabbed(&app->mouse, 1);
            }
        }
        return 0;
    case WM_LBUTTONUP:
        if (app) { CloneMCInput_SetMouseButton(&app->input, 0, 0); }
        return 0;
    case WM_RBUTTONDOWN:
        if (app) { CloneMCInput_SetMouseButton(&app->input, 1, 1); }
        return 0;
    case WM_RBUTTONUP:
        if (app) { CloneMCInput_SetMouseButton(&app->input, 1, 0); }
        return 0;
    case WM_MBUTTONDOWN:
        if (app) { CloneMCInput_SetMouseButton(&app->input, 2, 1); }
        return 0;
    case WM_MBUTTONUP:
        if (app) { CloneMCInput_SetMouseButton(&app->input, 2, 0); }
        return 0;
    case WM_MOUSEWHEEL:
        if (app) {
            wheel = (int)(short)((wParam >> 16) & 0xffff);
            CloneMCInput_AddWheel(&app->input, wheel / WHEEL_DELTA);
        }
        return 0;
    case WM_QUERYNEWPALETTE:
        if (app && app->palette && app->deviceContext) {
            SelectPalette(app->deviceContext, app->palette, FALSE);
            wheel=(int)RealizePalette(app->deviceContext);
            InvalidateRect(window, (const RECT *)0, FALSE);
            return wheel?TRUE:FALSE;
        }
        break;
    case WM_PALETTECHANGED:
        if (app && app->palette && app->deviceContext && (HWND)wParam != window) {
            SelectPalette(app->deviceContext, app->palette, FALSE);
            RealizePalette(app->deviceContext);
            InvalidateRect(window,(const RECT *)0,FALSE);
        }
        return 0;
    case WM_ERASEBKGND:
        return 1;
    case WM_PAINT:
        BeginPaint(window, &paint);
        EndPaint(window, &paint);
        return 0;
    default:
        break;
    }
    return DefWindowProcA(window, message, wParam, lParam);
}

static int CloneMCPlatform_RegisterWindowClass(CloneMCWin32App *app)
{
    WNDCLASSA windowClass;
    if (!app) { return 0; }
    memset(&windowClass, 0, sizeof(windowClass));
    windowClass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    windowClass.lpfnWndProc = CloneMCPlatform_WindowProc;
    windowClass.hInstance = app->instance;
    windowClass.hIcon = LoadIconA((HINSTANCE)0, IDI_APPLICATION);
    windowClass.hCursor = LoadCursorA((HINSTANCE)0, IDC_ARROW);
    windowClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    windowClass.lpszClassName = CLONEMC_WINDOW_CLASS;
    if (!RegisterClassA(&windowClass)) { return 0; }
    app->classRegistered = 1;
    return 1;
}

static int CloneMCPlatform_TryFullscreen(CloneMCWin32App *app)
{
    DEVMODEA mode;
    LONG result;
    if (!app || !app->settings.fullscreen) { return 0; }
    memset(&mode, 0, sizeof(mode));
    mode.dmSize = sizeof(mode);
    mode.dmPelsWidth = (DWORD)app->settings.width;
    mode.dmPelsHeight = (DWORD)app->settings.height;
    mode.dmBitsPerPel = (DWORD)app->settings.colorBits;
    mode.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL;
    result = ChangeDisplaySettingsA(&mode, CDS_FULLSCREEN);
    if (result != DISP_CHANGE_SUCCESSFUL) {
        app->settings.fullscreen = 0;
        return 0;
    }
    app->fullscreenActive = 1;
    return 1;
}

static int CloneMCPlatform_CreateWindowAndContext(CloneMCWin32App *app, int showCommand)
{
    DWORD style;
    DWORD extendedStyle;
    RECT rectangle;
    int x;
    int y;
    char pixelLine[256];

    if (!app) { return 0; }
    if (!CloneMCPlatform_RegisterWindowClass(app)) {
        CloneMCPlatform_Log("RegisterClassA failed.");
        return 0;
    }
    CloneMCPlatform_TryFullscreen(app);
    style = app->fullscreenActive ? WS_POPUP : WS_OVERLAPPEDWINDOW;
    extendedStyle = app->fullscreenActive ? WS_EX_APPWINDOW : (WS_EX_APPWINDOW | WS_EX_WINDOWEDGE);
    rectangle.left = 0; rectangle.top = 0;
    rectangle.right = app->settings.width; rectangle.bottom = app->settings.height;
    AdjustWindowRectEx(&rectangle, style, FALSE, extendedStyle);
    x = app->fullscreenActive ? 0 : CW_USEDEFAULT;
    y = app->fullscreenActive ? 0 : CW_USEDEFAULT;
    app->window = CreateWindowExA(extendedStyle, CLONEMC_WINDOW_CLASS,
                                  CLONEMC_VERSION_DISPLAY,
                                  style, x, y,
                                  rectangle.right - rectangle.left,
                                  rectangle.bottom - rectangle.top,
                                  (HWND)0, (HMENU)0, app->instance, (LPVOID)0);
    if (!app->window) {
        CloneMCPlatform_Log("CreateWindowExA failed.");
        return 0;
    }
    app->deviceContext = GetDC(app->window);
    if (!app->deviceContext) {
        CloneMCPlatform_Log("GetDC failed.");
        return 0;
    }
    if (!CloneMCPlatform_SelectPixelFormat(app)) {
        CloneMCPlatform_Log("No double-buffered RGBA OpenGL pixel format was found.");
        return 0;
    }
    sprintf(pixelLine,
        "Selected pixel format %d: color=%u depth=%u alpha=%u flags=0x%08lx generic=%d genericAccelerated=%d%s",
        app->pixelFormatIndex,(unsigned int)app->pixelFormat.cColorBits,
        (unsigned int)app->pixelFormat.cDepthBits,
        (unsigned int)app->pixelFormat.cAlphaBits,
        (unsigned long)app->pixelFormat.dwFlags,
        (app->pixelFormat.dwFlags&PFD_GENERIC_FORMAT)?1:0,
        (app->pixelFormat.dwFlags&PFD_GENERIC_ACCELERATED)?1:0,
        app->softwareGLRequested?" (-softwaregl requested)":"");
    CloneMCPlatform_Log(pixelLine);
    if (!SetPixelFormat(app->deviceContext, app->pixelFormatIndex, &app->pixelFormat)) {
        CloneMCPlatform_Log("SetPixelFormat failed. Pixel format must only be set once.");
        return 0;
    }
    if (!CloneMCPlatform_CreatePalette(app)) {
        CloneMCPlatform_Log("The selected paletted OpenGL mode could not create a palette.");
        return 0;
    }
    app->renderingContext = wglCreateContext(app->deviceContext);
    if (!app->renderingContext) {
        CloneMCPlatform_Log("wglCreateContext failed.");
        return 0;
    }
    if (!wglMakeCurrent(app->deviceContext, app->renderingContext)) {
        CloneMCPlatform_Log("wglMakeCurrent failed.");
        return 0;
    }
    ShowWindow(app->window, showCommand == 0 ? SW_SHOW : showCommand);
    UpdateWindow(app->window);
    return 1;
}


static int CloneMCPlatform_StatisticsSave(CloneMCWin32App *app)
{
    if(!app)return 0;
    if(!app->netClientHandler.statistics.dirty)return 1;
    return CloneMCJ_StatFileWriter_SaveJsonFileNative(
        &app->netClientHandler.statistics,"stats_clonemc.json",
        "assets/achievement/map.txt",app->username,"local");
}

static int CloneMCPlatform_InventoryContains(const CloneMCJ_InventoryPlayer *inventory,int itemID)
{
    int index;if(!inventory)return 0;
    for(index=0;index<CLONEMC_J_MAIN_INVENTORY_SIZE;++index)
        if(!CloneMCJ_ItemStack_IsEmpty(&inventory->mainInventory[index])&&
           inventory->mainInventory[index].itemID==itemID)return 1;
    if(!CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)&&
       inventory->carriedStack.itemID==itemID)return 1;
    return 0;
}

static int CloneMCPlatform_UnlockAchievement(CloneMCWin32App *app,int index)
{
    const CloneMCJ_AchievementDefinition *achievement;
    if(!app||!CloneMCJ_Achievement_UnlockNative(&app->netClientHandler.statistics,index))return 0;
    achievement=CloneMCJ_AchievementList_GetNative(index);
    if(achievement&&app->gameplay)
        CloneMCJ_GuiAchievement_QueueNative(&app->guiIngame,"Achievement get!",achievement->title);
    return 1;
}

static void CloneMCPlatform_CheckInventoryAchievements(CloneMCWin32App *app)
{
    const CloneMCJ_InventoryPlayer *inventory;
    if(!app||!app->gameplay)return;inventory=&app->gameplay->player.inventory;
    if(CloneMCPlatform_InventoryContains(inventory,58))CloneMCPlatform_UnlockAchievement(app,2);
    if(CloneMCPlatform_InventoryContains(inventory,270))CloneMCPlatform_UnlockAchievement(app,3);
    if(CloneMCPlatform_InventoryContains(inventory,61)||CloneMCPlatform_InventoryContains(inventory,62))CloneMCPlatform_UnlockAchievement(app,4);
    if(CloneMCPlatform_InventoryContains(inventory,265))CloneMCPlatform_UnlockAchievement(app,5);
    if(CloneMCPlatform_InventoryContains(inventory,290))CloneMCPlatform_UnlockAchievement(app,6);
    if(CloneMCPlatform_InventoryContains(inventory,297))CloneMCPlatform_UnlockAchievement(app,7);
    if(CloneMCPlatform_InventoryContains(inventory,354))CloneMCPlatform_UnlockAchievement(app,8);
    if(CloneMCPlatform_InventoryContains(inventory,274)||CloneMCPlatform_InventoryContains(inventory,257)||CloneMCPlatform_InventoryContains(inventory,278))CloneMCPlatform_UnlockAchievement(app,9);
    if(CloneMCPlatform_InventoryContains(inventory,350))CloneMCPlatform_UnlockAchievement(app,10);
    if(CloneMCPlatform_InventoryContains(inventory,268))CloneMCPlatform_UnlockAchievement(app,12);
    if(CloneMCPlatform_InventoryContains(inventory,334))CloneMCPlatform_UnlockAchievement(app,14);
}

static int CloneMCPlatform_StatisticsMobAlreadySeen(CloneMCWin32App *app,int entityId)
{
    int index;if(!app||entityId<=0)return 1;
    for(index=0;index<app->statsSeenMobCount;++index)
        if(app->statsSeenMobIds[index]==entityId)return 1;
    if(app->statsSeenMobCount<CLONEMC_J_MAX_MOBS)
        app->statsSeenMobIds[app->statsSeenMobCount++]=entityId;
    else app->statsSeenMobIds[(unsigned int)entityId%CLONEMC_J_MAX_MOBS]=entityId;
    return 0;
}

static void CloneMCPlatform_StatisticsTick(CloneMCWin32App *app)
{
    CloneMCJ_EntityPlayer *player;
    CloneMCJ_Container *container;
    CloneMCJ_Vehicle *vehicle;
    CloneMCJ_Mob *mob;
    double dx,dy,dz,distance;
    int centimeters,statId,index,ridingType;
    unsigned long minedDelta,placedDelta;
    if(!app||!app->gameplay)return;player=&app->gameplay->player;
    CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,1100,1);
    if(!app->statsStateKnown){
        app->statsPreviousX=player->entity.posX;app->statsPreviousY=player->entity.posY;
        app->statsPreviousZ=player->entity.posZ;app->statsPreviousHealth=player->health;
        app->statsPreviousOnGround=player->entity.onGround;
        app->statsPreviousBlocksMined=player->blocksMined;
        app->statsPreviousBlocksPlaced=player->blocksPlaced;
        app->statsStateKnown=1;
    }else{
        dx=player->entity.posX-app->statsPreviousX;dy=player->entity.posY-app->statsPreviousY;
        dz=player->entity.posZ-app->statsPreviousZ;distance=sqrt(dx*dx+dy*dy+dz*dz);
        centimeters=(int)(distance*100.0+0.5);statId=2000;ridingType=0;
        vehicle=0;mob=0;
        if(player->ridingEntityId){
            for(index=0;index<app->gameplay->vehicleCount;++index)
                if(app->gameplay->vehicles[index].active&&app->gameplay->vehicles[index].entity.entityId==player->ridingEntityId){vehicle=&app->gameplay->vehicles[index];break;}
            if(!vehicle)for(index=0;index<app->gameplay->mobCount;++index)
                if(app->gameplay->mobs[index].active&&app->gameplay->mobs[index].entity.entityId==player->ridingEntityId){mob=&app->gameplay->mobs[index];break;}
        }
        if(vehicle&&vehicle->type==CLONEMC_J_VEHICLE_MINECART){statId=2006;ridingType=1;}
        else if(vehicle&&vehicle->type==CLONEMC_J_VEHICLE_BOAT){statId=2007;ridingType=2;}
        else if(mob&&mob->type==CLONEMC_J_MOB_PIG){statId=2008;ridingType=3;}
        else if(player->entity.inWater)statId=dy<0.0?2005:2001;
        else if(player->entity.collidedHorizontally&&dy>0.0)statId=2003;
        else if(!player->entity.onGround&&dy<0.0)statId=2002;
        else if(!player->entity.onGround)statId=2004;
        if(centimeters>0)CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,statId,centimeters);
        if(app->statsPreviousOnGround&&!player->entity.onGround&&player->entity.motionY>0.1)
            CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,2010,1);
        if(app->statsPreviousHealth>player->health)
            CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,2021,app->statsPreviousHealth-player->health);
        if(app->statsPreviousHealth>0&&player->health<=0)
            CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,2022,1);
        if(ridingType==3&&player->entity.fallDistance>5.0F)app->statsPigFallArmed=1;
        if(app->statsPigFallArmed&&!player->ridingEntityId){CloneMCPlatform_UnlockAchievement(app,15);app->statsPigFallArmed=0;}
        if(CloneMCJ_StatFileWriter_GetNative(&app->netClientHandler.statistics,2006)>=100000)
            CloneMCPlatform_UnlockAchievement(app,11);
    }
    minedDelta=player->blocksMined-app->statsPreviousBlocksMined;
    if(minedDelta&&player->lastMinedBlockID>=0){
        CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,
            CLONEMC_J_STAT_MINE_BLOCK_BASE+player->lastMinedBlockID,(int)minedDelta);
        if(player->lastMinedBlockID==17)CloneMCPlatform_UnlockAchievement(app,1);
    }
    placedDelta=player->blocksPlaced-app->statsPreviousBlocksPlaced;
    if(placedDelta&&player->lastPlacedBlockID>=0)
        CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,
            CLONEMC_J_STAT_USE_ITEM_BASE+player->lastPlacedBlockID,(int)placedDelta);
    container=CloneMCJ_Gameplay_GetOpenContainer(app->gameplay);
    if(container){
        if(container->craftedSerial!=app->statsLastCraftedSerial){
            if(container->lastCraftedItemID>=0&&container->lastCraftedCount>0)
                CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,
                    CLONEMC_J_STAT_CRAFT_ITEM_BASE+container->lastCraftedItemID,container->lastCraftedCount);
            app->statsLastCraftedSerial=container->craftedSerial;
        }
        if(container->smeltedSerial!=app->statsLastSmeltedSerial){
            if(container->lastSmeltedItemID>=0&&container->lastSmeltedCount>0)
                CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,
                    CLONEMC_J_STAT_CRAFT_ITEM_BASE+container->lastSmeltedItemID,container->lastSmeltedCount);
            app->statsLastSmeltedSerial=container->smeltedSerial;
        }
    }else{app->statsLastCraftedSerial=0;app->statsLastSmeltedSerial=0;}
    for(index=0;index<app->gameplay->mobCount;++index){mob=&app->gameplay->mobs[index];
        if(mob->active&&mob->health<=0&&mob->recentlyHit>0&&
           !CloneMCPlatform_StatisticsMobAlreadySeen(app,mob->entity.entityId)){
            CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,2023,1);
            CloneMCPlatform_UnlockAchievement(app,13);
        }
    }
    CloneMCPlatform_CheckInventoryAchievements(app);
    app->statsPreviousX=player->entity.posX;app->statsPreviousY=player->entity.posY;
    app->statsPreviousZ=player->entity.posZ;app->statsPreviousHealth=player->health;
    app->statsPreviousOnGround=player->entity.onGround;
    app->statsPreviousBlocksMined=player->blocksMined;
    app->statsPreviousBlocksPlaced=player->blocksPlaced;
    if(app->gameTicks-app->statsLastPeriodicSaveTick>=1200UL&&
       app->netClientHandler.statistics.dirty){
        if(CloneMCPlatform_StatisticsSave(app))app->statsLastPeriodicSaveTick=app->gameTicks;
    }
}

static int CloneMCPlatform_GuiScale(const CloneMCWin32App *app)
{
    int scale;
    if(!app)return 1;
    scale=app->settings.guiScale;
    if(scale<1){scale=1;while(scale<4&&app->listener.width/(scale+1)>=320&&
        app->listener.height/(scale+1)>=240)++scale;}
    if(scale>4)scale=4;
    return scale;
}

static void CloneMCPlatform_SetFrontendScreen(CloneMCWin32App *app,int screenType)
{
    int scale,oldType,preserveText;
    char breadcrumb[96];
    char savedText[128];
    char savedSecondary[128];
    int savedFocus,savedCreate;
    if(!app)return;
    if(screenType<CLONEMC_GUI_SCREEN_MAIN_MENU||
       screenType>CLONEMC_GUI_SCREEN_CONFLICT)
        screenType=CLONEMC_GUI_SCREEN_MAIN_MENU;
    sprintf(breadcrumb,"installing frontend screen %d",screenType);
    CloneMCPlatform_CrashBreadcrumb(breadcrumb);
    oldType=app->guiScreen.screenType;scale=CloneMCPlatform_GuiScale(app);
    /* Java releases the old GuiButton objects when displayGuiScreen installs
     * a replacement.  Clear native drag/hover state before their fixed array
     * storage is reused so a held Win32 mouse button cannot act on the new
     * screen during the same frontend iteration. */
    CloneMCJ_GuiScreen_ReleaseMouseNative(&app->guiScreen);
    preserveText=oldType==screenType&&(screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER||
        screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD||screenType==CLONEMC_GUI_SCREEN_RENAME_WORLD);
    savedText[0]='\0';savedSecondary[0]='\0';savedFocus=0;savedCreate=0;
    if(preserveText){strncpy(savedText,app->guiScreen.textField,sizeof(savedText)-1);
        savedText[sizeof(savedText)-1]='\0';
        strncpy(savedSecondary,app->guiScreen.textFieldSecondary,sizeof(savedSecondary)-1);
        savedSecondary[sizeof(savedSecondary)-1]='\0';savedFocus=app->guiScreen.textFocused;
        savedCreate=app->guiScreen.createClicked;}
    CloneMCJ_GuiScreen_SetResolutionNative(&app->guiScreen,app->listener.width,
        app->listener.height,scale);
    app->guiScreen.screenType=oldType;
    if(screenType==CLONEMC_GUI_SCREEN_MAIN_MENU)CloneMCJ_GuiMainMenu_InitNative(&app->guiScreen);
    else if(screenType==CLONEMC_GUI_SCREEN_SELECT_WORLD){
        CloneMCJ_GuiSelectWorld_InitNative(&app->guiScreen);
        CloneMCJ_GuiSelectWorld_LoadNative(&app->guiScreen,"saves");
    }
    else if(screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER)CloneMCJ_GuiMultiplayer_InitNative(
        &app->guiScreen,app->settings.lastServer[0]?app->settings.lastServer:
        "localhost:25565",app->username);
    else if(screenType==CLONEMC_GUI_SCREEN_OPTIONS)CloneMCJ_GuiOptions_InitNative(
        &app->guiScreen,&app->settings);
    else if(screenType==CLONEMC_GUI_SCREEN_VIDEO)CloneMCJ_GuiVideoSettings_InitNative(
        &app->guiScreen,&app->settings);
    else if(screenType==CLONEMC_GUI_SCREEN_CONTROLS)CloneMCJ_GuiControls_InitNative(
        &app->guiScreen,&app->settings);
    else if(screenType==CLONEMC_GUI_SCREEN_TEXTURE_PACKS)CloneMCJ_GuiTexturePacks_InitNative(&app->guiScreen);
    else if(screenType==CLONEMC_GUI_SCREEN_ACHIEVEMENTS)CloneMCJ_GuiAchievements_InitNative(&app->guiScreen);
    else if(screenType==CLONEMC_GUI_SCREEN_STATS)CloneMCJ_GuiStats_InitNative(&app->guiScreen);
    else if(screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD)CloneMCJ_GuiCreateWorld_InitNative(
        &app->guiScreen,app->compatibilityPolicy.strictReference);
    else if(screenType==CLONEMC_GUI_SCREEN_CONNECTING)CloneMCJ_GuiConnecting_InitNative(
        &app->guiScreen,app->settings.lastServer);
    else if(screenType==CLONEMC_GUI_SCREEN_ERROR)CloneMCJ_GuiErrorScreen_InitNative(
        &app->guiScreen,app->sessionExitTitle[0]?app->sessionExitTitle:"Connection lost",
        app->sessionExitDetail[0]?app->sessionExitDetail:"Disconnected");
    else if(screenType==CLONEMC_GUI_SCREEN_GAME_OVER)CloneMCJ_GuiGameOver_InitNative(
        &app->guiScreen,app->gameplay?app->gameplay->player.score:0);
    else if(screenType==CLONEMC_GUI_SCREEN_RENAME_WORLD)
        CloneMCJ_GuiRenameWorld_InitNative(&app->guiScreen,
            app->worldDisplayName[0]?app->worldDisplayName:app->worldName);
    else if(screenType==CLONEMC_GUI_SCREEN_YES_NO)
        CloneMCJ_GuiYesNo_InitNative(&app->guiScreen,
            app->sessionExitTitle[0]?app->sessionExitTitle:"Are you sure?",
            app->sessionExitDetail);
    else if(screenType==CLONEMC_GUI_SCREEN_DOWNLOAD_TERRAIN)
        CloneMCJ_GuiDownloadTerrain_InitNative(&app->guiScreen);
    else if(screenType==CLONEMC_GUI_SCREEN_SLEEP)
        CloneMCJ_GuiSleepMP_InitNative(&app->guiScreen);
    else if(screenType==CLONEMC_GUI_SCREEN_CONFLICT)
        CloneMCJ_GuiConflictWarning_InitNative(&app->guiScreen,
            app->sessionExitDetail[0]?app->sessionExitDetail:
            "Another action is already using this world.");
    else CloneMCJ_GuiMainMenu_InitNative(&app->guiScreen);
    if(screenType==CLONEMC_GUI_SCREEN_ACHIEVEMENTS)
        CloneMCJ_GuiAchievements_SetStatsNative(&app->guiScreen,&app->netClientHandler.statistics);
    else if(screenType==CLONEMC_GUI_SCREEN_STATS)
        CloneMCJ_GuiStats_SetStatsNative(&app->guiScreen,&app->netClientHandler.statistics);
    if(preserveText){strncpy(app->guiScreen.textField,savedText,sizeof(app->guiScreen.textField)-1);
        app->guiScreen.textField[sizeof(app->guiScreen.textField)-1]='\0';
        strncpy(app->guiScreen.textFieldSecondary,savedSecondary,
            sizeof(app->guiScreen.textFieldSecondary)-1);
        app->guiScreen.textFieldSecondary[sizeof(app->guiScreen.textFieldSecondary)-1]='\0';
        app->guiScreen.textFocused=savedFocus;app->guiScreen.createClicked=savedCreate;
        if(screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD)
            CloneMCJ_GuiCreateWorld_UpdateFolderNative(&app->guiScreen,"saves");}
    if(!CloneMCJ_GuiScreen_ValidateNative(&app->guiScreen))
        CloneMCPlatform_Log("GUI state required native bounds repair.");
    sprintf(breadcrumb,"frontend screen %d installed (%d x %d)",screenType,
        app->guiScreen.width,app->guiScreen.height);
    CloneMCPlatform_CrashBreadcrumb(breadcrumb);
}

static int CloneMCPlatform_ReloadTexturePack(CloneMCWin32App *app)
{
    CloneMCJ_GameplayState *gameplay;
    CloneMCJ_GuiIngameState *gui;
    CloneMCGameSettings *settings;
    CloneMCJ_MapStorage *mapStorage;
    int legacyFrontend,loaded,requestedDefault;
    if(!app||!app->renderer.initialized)return 0;
    requestedDefault=strcmp(CloneMCTexturePacks_GetSelectedName(),"Default")==0;
    gameplay=app->renderer.gameplay;gui=app->renderer.guiIngame;
    settings=app->renderer.settings;mapStorage=app->renderer.mapStorage;
    legacyFrontend=app->renderer.legacyFrontend;
    CloneMCRender_Shutdown(&app->renderer);
    loaded=CloneMCRender_Initialize(&app->renderer,app->listener.width,
        app->listener.height);
    if(!loaded){
        CloneMCTexturePacks_Select(0);
        loaded=CloneMCRender_Initialize(&app->renderer,app->listener.width,
            app->listener.height);
    }
    if(!loaded)return 0;
    app->renderer.legacyFrontend=legacyFrontend;
    CloneMCRender_SetPriority9State(&app->renderer,gameplay,gui,settings);
    CloneMCRender_SetMapStorage(&app->renderer,mapStorage);
    return requestedDefault||
        strcmp(CloneMCTexturePacks_GetSelectedName(),"Default")!=0;
}

static CloneMCJLong CloneMCPlatform_NewWorldSeed(void)
{
    CloneMCJavaRandom random;
    CloneMCJULong seed;
    static unsigned long sequence=0;
    ++sequence;
    seed=((CloneMCJULong)timeGetTime()<<32)^
        ((CloneMCJULong)sequence*(CloneMCJULong)0x9e3779b9UL);
    CloneMCJavaRandom_SetSeed(&random,(CloneMCJLong)seed);
    return CloneMCJavaRandom_NextLong(&random);
}

static void CloneMCPlatform_ShowLoading(CloneMCWin32App *app,const char *title,
    const char *message,int progress)
{
    int scale;
    int shouldPresent;
    if(!app||!app->renderer.initialized)return;
    (void)CloneMCPlatform_ApplyPendingResize(app);
    if(!app->loadingScreen.running)
        CloneMCJ_LoadingScreenRenderer_InitializeNative(&app->loadingScreen);
    scale=CloneMCPlatform_GuiScale(app);
    CloneMCJ_GuiScreen_SetResolutionNative(&app->guiScreen,app->listener.width,
        app->listener.height,scale);
    if(title&&strcmp(title,app->loadingScreen.title)!=0)
        CloneMCJ_LoadingScreenRenderer_PrintTextNative(&app->loadingScreen,
            &app->guiScreen,title);
    if(message&&strcmp(message,app->loadingScreen.message)!=0)
        CloneMCJ_LoadingScreenRenderer_DisplayStringNative(&app->loadingScreen,
            &app->guiScreen,message);
    shouldPresent=CloneMCJ_LoadingScreenRenderer_SetProgressNative(
        &app->loadingScreen,&app->guiScreen,progress,timeGetTime());
    if(!shouldPresent&&!app->resizeAwaitingPresent)return;
    if(app->resizeAwaitingPresent)
        CloneMCPlatform_CrashBreadcrumb("post-resize loading frame draw begins");
    CloneMCRender_DrawGuiScreen(&app->renderer,&app->guiScreen,&app->settings);
    if(app->resizeAwaitingPresent)
        CloneMCPlatform_CrashBreadcrumb("post-resize loading draw completed; SwapBuffers begins");
    if(!SwapBuffers(app->deviceContext))
        CloneMCPlatform_Log("SwapBuffers failed while presenting a resized loading frame.");
    else if(app->resizeAwaitingPresent){
        app->resizeAwaitingPresent=0;
        CloneMCPlatform_CrashBreadcrumb("post-resize loading frame presented successfully");
    }
}

static int CloneMCPlatform_PumpLoadingMessages(CloneMCWin32App *app)
{
    MSG message;
    if (!app) return 0;
    while (PeekMessageA(&message,(HWND)0,0,0,PM_REMOVE)) {
        if(message.message==WM_QUIT){
            /* Finish the in-flight transaction before honoring shutdown. */
            app->closeAfterSave=1;
            continue;
        }
        TranslateMessage(&message);
        DispatchMessageA(&message);
    }
    (void)CloneMCPlatform_ApplyPendingResize(app);
    if(app->listener.closeRequested){
        app->closeAfterSave=1;
        app->listener.closeRequested=0;
    }
    return 1;
}

static int CloneMCPlatform_BootstrapSpawnArea(CloneMCWin32App *app)
{
    int targetRadius;
    int desired;
    int loaded;
    int previous;
    int progress;
    int idlePasses;
    char message[96];
    if (!app || !app->world || app->multiplayerMode) return 1;
    targetRadius = app->world->activeRadius < 2 ?
        app->world->activeRadius : 2;
    if (targetRadius < 0) targetRadius = 0;
    desired = 1 + 2 * targetRadius * (targetRadius + 1);
    if (desired > app->world->activeChunkLimit)
        desired = app->world->activeChunkLimit;
    loaded = CloneMCJ_World_CountLoadedChunksNearPlayer(app->world,targetRadius);
    idlePasses = 0;
    while (loaded < desired && idlePasses < 80 &&
           !app->listener.closeRequested) {
        previous = loaded;
        loaded = CloneMCJ_World_BootstrapSpawnStep(app->world,targetRadius);
        if (loaded <= previous) {
            ++idlePasses;
            Sleep(5);
        } else idlePasses = 0;
        progress = 45 + loaded * 45 / (desired ? desired : 1);
        if (progress > 90) progress = 90;
        sprintf(message,"Preparing spawn area: %d / %d chunks",loaded,desired);
        CloneMCPlatform_ShowLoading(app,"Building terrain",message,progress);
        if (!CloneMCPlatform_PumpLoadingMessages(app)) return 0;
    }
    /* Do not enter gameplay with only an unrelated edge chunk loaded.  The
     * center chunk is mandatory, and the bounded radius must be complete so
     * mesh warmup has real terrain surrounding the restored camera. */
    return loaded >= desired && app->world->playerChunkInitialized &&
        CloneMCJ_World_IsChunkLoaded(app->world,app->world->playerChunkX,
            app->world->playerChunkZ);
}

static void CloneMCPlatform_SetSaveFailure(CloneMCWin32App *app,
    const char *fallback)
{
    const char *detail;
    if(!app)return;
    detail=app->world?CloneMCJ_World_GetLastSaveError(app->world):0;
    if((!detail||!*detail)&&app->saveHandlerInitialized)
        detail=CloneMCJ_SaveHandler_GetLastError(&app->saveHandler);
    if((!detail||!*detail)&&app->saveHandlerInitialized&&
       app->saveHandler.chunkLoader.lastSaveDetail[0])
        detail=app->saveHandler.chunkLoader.lastSaveDetail;
    if(!detail||!*detail)detail=fallback&&*fallback?fallback:
        "The save transaction did not complete";
    CloneMCPlatform_CopyText(app->saveFailureDetail,
        sizeof(app->saveFailureDetail),detail);
    CloneMCPlatform_CrashBreadcrumb(app->saveFailureDetail);
}

static int CloneMCPlatform_SaveWorldWithLoading(CloneMCWin32App *app)
{
    int total;
    int remaining;
    int saved;
    int progress;
    int success;
    int batchSize;
    int timedOut;
    DWORD saveStarted;
    DWORD elapsed;
    char message[128];
    if(!app||!app->world||app->multiplayerMode)return 0;
    if(app->saveInProgress){
        CloneMCPlatform_SetSaveFailure(app,
            "A world save is already in progress; a second save was rejected");
        return 0;
    }
    app->saveInProgress=1;
    app->guiIngame.savingWorld=1;
    app->guiIngame.saveFailed=0;
    app->guiIngame.saveProgress=0;
    CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
        sizeof(app->guiIngame.saveStatus),"Saving level..");
    app->saveCompletedForExit=0;
    app->saveStage=1;
    app->saveFailureDetail[0]='\0';
    success=0;
    timedOut=0;
    saveStarted=timeGetTime();

    /* Minecraft.saveWorld(true, progress) captures one coherent player/world
     * snapshot, then forces dirty chunks, then commits level.dat.  Keeping the
     * metadata transaction last means an old level.dat can never advertise a
     * player/world state whose edited chunks failed to reach the region file. */
    CloneMCPlatform_ShowLoading(app,"Saving level","Preparing world data",1);
    if(!CloneMCJ_World_PrepareSaveSnapshot(app->world)){
        CloneMCPlatform_SetSaveFailure(app,
            "Could not capture the current player and world metadata");
        goto save_finished;
    }
    if(!CloneMCPlatform_PumpLoadingMessages(app)){
        CloneMCPlatform_SetSaveFailure(app,"The loading-screen message pump failed");
        goto save_finished;
    }

    app->saveStage=2;
    total=CloneMCJ_ChunkProviderLoadOrGenerate_CountChunksNeedingSave(
        &app->world->chunkProvider,1);
    remaining=total;
    CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
        sizeof(app->guiIngame.saveStatus),"Saving chunks..");
    CloneMCPlatform_ShowLoading(app,"Saving chunks","Preparing chunks",5);
    while(remaining>0){
        elapsed=(DWORD)(timeGetTime()-saveStarted);
        batchSize=4;
        if(elapsed>=5000UL)batchSize=12;
        /* Never promote the whole dirty set into one unbounded synchronous
         * call.  That was able to keep the loading screen alive indefinitely
         * when a large resident set, a slow disk, antivirus, or a damaged
         * region repeatedly delayed one forced batch.  The main loop must get
         * control back between bounded writes so the 30-second title deadline
         * can be observed. */
        if(elapsed>=CLONEMC_SAVE_URGENT_MS)batchSize=CLONEMC_SAVE_FINAL_BATCH;
        if(batchSize>remaining)batchSize=remaining;
        if(batchSize<1)batchSize=1;
        if(elapsed>=CLONEMC_SAVE_TIMEOUT_MS){
            timedOut=1;
            app->saveCompletedForExit=1;
            app->saveStage=6;
            success=1;
            CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
                sizeof(app->guiIngame.saveStatus),
                "30-second save deadline reached - returning to title");
            CloneMCPlatform_ShowLoading(app,"Saving level",
                "30-second deadline reached - returning to title",100);
            CloneMCPlatform_PumpLoadingMessages(app);
            goto save_finished;
        }
        saved=CloneMCJ_World_SaveChunksBudget(app->world,1,batchSize,&remaining);
        if(saved<0){
            CloneMCPlatform_SetSaveFailure(app,
                "A dirty chunk could not be written after a verified region-file retry");
            goto save_finished;
        }
        if(saved==0&&remaining>0){
            CloneMCPlatform_SetSaveFailure(app,
                "The forced chunk save made no progress");
            goto save_finished;
        }
        elapsed=(DWORD)(timeGetTime()-saveStarted);
        progress=total>0?5+(total-remaining)*82/total:87;
        if(progress>87)progress=87;
        app->guiIngame.saveProgress=progress;
        if(elapsed<CLONEMC_SAVE_TIMEOUT_MS)
            sprintf(message,"Saving chunks: %d / %d  (%lu s remaining)",
                total-remaining,total,(unsigned long)((CLONEMC_SAVE_TIMEOUT_MS-elapsed+999UL)/1000UL));
        else{
            sprintf(message,"Finishing verified save: %d / %d",total-remaining,total);
            timedOut=1;
        }
        CloneMCPlatform_ShowLoading(app,"Saving chunks",message,progress);
        if(!CloneMCPlatform_PumpLoadingMessages(app)){
            CloneMCPlatform_SetSaveFailure(app,
                "The loading-screen message pump failed while saving chunks");
            goto save_finished;
        }
        /* The title transition is intentionally unconditional at 30 seconds.
         * Any chunks that completed before the deadline remain saved.  The game
         * does not keep the player trapped on this screen waiting for a retry,
         * flush, or region operation that may never report completion. */
        if(elapsed>=CLONEMC_SAVE_TIMEOUT_MS&&remaining>0){
            timedOut=1;
            app->saveCompletedForExit=1;
            app->saveStage=6;
            success=1;
            CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
                sizeof(app->guiIngame.saveStatus),
                "30-second save deadline reached - returning to title");
            goto save_finished;
        }
    }

    elapsed=(DWORD)(timeGetTime()-saveStarted);
    if(elapsed>=CLONEMC_SAVE_TIMEOUT_MS){
        timedOut=1;app->saveCompletedForExit=1;app->saveStage=6;success=1;
        CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
            sizeof(app->guiIngame.saveStatus),
            "30-second save deadline reached - returning to title");
        goto save_finished;
    }
    app->saveStage=3;
    CloneMCPlatform_ShowLoading(app,"Saving chunks","Flushing region files",90);
    if(!CloneMCJ_SaveHandler_FlushChunkData(&app->saveHandler)){
        CloneMCJ_World_MarkResidentChunksModified(app->world);
        CloneMCPlatform_SetSaveFailure(app,
            "Could not durably commit the McRegion files; resident chunks were re-queued for Retry Save and quit");
        goto save_finished;
    }

    elapsed=(DWORD)(timeGetTime()-saveStarted);
    if(elapsed>=CLONEMC_SAVE_TIMEOUT_MS){
        timedOut=1;app->saveCompletedForExit=1;app->saveStage=6;success=1;
        CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
            sizeof(app->guiIngame.saveStatus),
            "30-second save deadline reached - returning to title");
        goto save_finished;
    }
    /* Commit the exact prepared Player/WorldInfo tree once.  SaveHandler writes
     * level.dat_new, reads it back, rotates level.dat to level.dat_old, and only
     * then installs the verified new file. */
    app->saveStage=4;
    CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
        sizeof(app->guiIngame.saveStatus),"Saving level..");
    CloneMCPlatform_ShowLoading(app,"Saving level","Saving level data",94);
    if(!CloneMCJ_World_CommitLevelSave(app->world)){
        CloneMCPlatform_SetSaveFailure(app,"Could not commit level.dat");
        goto save_finished;
    }
    /* Java World.saveLevel commits level/player metadata and then the dirty
     * MapStorage records.  Keep that ordering so map_<id>.dat and idcounts
     * remain part of the same user-visible save operation. */
    if(app->mapStorageInitialized&&
       !CloneMCJ_MapStorage_SaveAllData(&app->mapStorage)){
        CloneMCPlatform_SetSaveFailure(app,
            "Could not commit one or more map data files");
        goto save_finished;
    }

    app->saveStage=5;
    CloneMCPlatform_ShowLoading(app,"Saving level","Verifying level data",98);
    if(!CloneMCJ_SaveHandler_VerifyWorldInfo(&app->saveHandler,
            &app->world->worldInfo,
            (const CloneMCJ_NBTTagCompound *)app->world->worldInfo.playerTag)){
        CloneMCPlatform_SetSaveFailure(app,
            "The saved level.dat did not match the current world snapshot");
        goto save_finished;
    }
    elapsed=(DWORD)(timeGetTime()-saveStarted);
    if(elapsed>=CLONEMC_SAVE_TIMEOUT_MS)timedOut=1;
    CloneMCPlatform_ShowLoading(app,"Saving level",
        timedOut?"30-second save deadline reached - returning to title":
            "Save complete - returning to title",100);
    CloneMCPlatform_PumpLoadingMessages(app);
    app->saveCompletedForExit=1;
    app->saveStage=6;
    success=1;

save_finished:
    /* LoadingScreenRenderer is a modal presentation state.  Leaving it marked
     * running after a verified save can cover the newly opened title screen even
     * though the world has already reached disk.  End it unconditionally before
     * the caller requests the session transition. */
    app->loadingScreen.running=0;
    app->saveInProgress=0;
    app->guiIngame.savingWorld=0;
    app->guiIngame.saveFailed=success?0:1;
    app->guiIngame.saveProgress=success?100:0;
    if(!success){
        app->saveCompletedForExit=0;
        CloneMCPlatform_CopyText(app->guiIngame.saveStatus,
            sizeof(app->guiIngame.saveStatus),
            app->saveFailureDetail[0]?app->saveFailureDetail:"Save failed");
    }
    return success;
}

static int CloneMCPlatform_WarmSpawnMeshes(CloneMCWin32App *app)
{
    int prepared;
    int target;
    int nearest;
    int index;
    int result;
    int sectionSteps;
    int completedSteps;
    int expectedSteps;
    int progress;
    float nearestDistance;
    char message[96];
    CloneMCWorldRenderer *candidate;
    if (!app || !app->world || !app->gameplay ||
        !app->renderer.initialized) return 1;
    target = 5;
    prepared = 0;
    completedSteps = 0;
    expectedSteps = target * 8;
    CloneMCRenderGlobal_Synchronize(&app->renderer.renderGlobal,app->world,
        app->gameplay->player.entity.posX,
        app->gameplay->player.entity.posY,
        app->gameplay->player.entity.posZ);
    while (prepared < target && !app->listener.closeRequested) {
        nearest = -1;
        nearestDistance = 3.4E38F;
        for (index = 0; index < CLONEMC_RENDER_MAX_CHUNKS; ++index) {
            candidate = &app->renderer.renderGlobal.worldRenderers[index];
            if (!candidate->initialized || !candidate->isWithinDistance ||
                !candidate->needsUpdate) continue;
            if (candidate->distanceSquared < nearestDistance) {
                nearestDistance = candidate->distanceSquared;
                nearest = index;
            }
        }
        if (nearest < 0) break;
        candidate = &app->renderer.renderGlobal.worldRenderers[nearest];
        candidate->desiredLod = 0;
        sectionSteps = 0;
        do {
            result = CloneMCWorldRenderer_UpdateStep(candidate);
            if (result < 0) {
                /* Mesh warmup is a latency optimization, not a condition for
                 * opening a valid saved world.  Keep the loading screen
                 * responsive and let the bounded in-game queue retry later. */
                candidate->needsUpdate = 1;
                break;
            }
            ++sectionSteps;
            ++completedSteps;
            progress = 92 + completedSteps * 7 /
                (expectedSteps ? expectedSteps : 1);
            if (progress > 99) progress = 99;
            sprintf(message,"Preparing visible terrain: %d / %d",prepared + 1,
                target);
            CloneMCPlatform_ShowLoading(app,"Building terrain",message,progress);
            if (!CloneMCPlatform_PumpLoadingMessages(app)) return 0;
        } while (result == 0 && sectionSteps < 16);
        if (result > 0) {
            candidate->buildSerial = ++app->renderer.renderGlobal.buildSerial;
            ++app->renderer.renderGlobal.chunksUpdated;
            ++app->renderer.renderGlobal.fullMeshBuilds;
            ++prepared;
        } else break;
    }
    return !app->listener.closeRequested;
}

static int CloneMCPlatform_ParseServerField(CloneMCWin32App *app,const char *text)
{
    const char *colon;unsigned long length;int port;
    if(!app||!text||!*text)return 0;
    colon=strrchr(text,':');length=(unsigned long)strlen(text);port=25565;
    if(colon){length=(unsigned long)(colon-text);port=atoi(colon+1);
        if(port<1||port>65535)return 0;}
    if(length<1||length>=sizeof(app->serverHost))return 0;
    memcpy(app->serverHost,text,length);app->serverHost[length]='\0';
    app->serverPort=(unsigned short)port;app->multiplayerMode=1;return 1;
}

static void CloneMCPlatform_MarkSettingsDirty(CloneMCWin32App *app)
{
    if(!app)return;
    app->settingsDirty=1;
    app->settingsDirtyMilliseconds=(unsigned long)timeGetTime();
}

static int CloneMCPlatform_FlushSettings(CloneMCWin32App *app,int force)
{
    unsigned long now;
    if(!app||!app->settingsDirty)return 1;
    now=(unsigned long)timeGetTime();
    /* GuiSlider.java changes its value in mouseDragged without calling
     * saveOptions.  Match that property: never perform disk I/O while the
     * button is held, and coalesce a run of button/slider changes. */
    if(!force&&(app->input.mouseDown[0]||
       now-app->settingsDirtyMilliseconds<500UL))return 1;
    if(!CloneMCGameSettings_Save(&app->settings,CLONEMC_SETTINGS_FILE)){
        CloneMCPlatform_Log("Options save failed; the previous atomic options file was retained.");
        return 0;
    }
    app->settingsDirty=0;
    return 1;
}

/* Returns 0 for quit, 1 for singleplayer, or 2 for multiplayer. */
static int CloneMCPlatform_RunFrontend(CloneMCWin32App *app,int initialScreen,int returnToGame)
{
    MSG message;int clientX,clientY,id,character,screenType,choice,keyCode;
    int selectedResult,firstFrame,presented;
    double frontendInterval;
    double frontendDeadline;
    double frontendNow;
    GLenum frontendError;
    char frontendBreadcrumb[128];
    if(!app)return 0;
    app->frontendActive=1;
    CloneMCMouseHelper_SetGrabbed(&app->mouse,0);
    CloneMCPlatform_SetFrontendScreen(app,initialScreen);
    SetWindowTextA(app->window,"CloneMC - Minecraft Beta 1.7.3 Main Menu");
    choice=-1;firstFrame=1;
    frontendInterval=app->renderer.legacyFrontend?0.025:(1.0/60.0);
    frontendDeadline=CloneMCTimer_NowSeconds()+frontendInterval;
    while(choice<0&&!app->listener.closeRequested){
        while(PeekMessageA(&message,(HWND)0,0,0,PM_REMOVE)){
            if(message.message==WM_QUIT){app->listener.closeRequested=1;break;}
            TranslateMessage(&message);DispatchMessageA(&message);
        }
        if(app->listener.closeRequested)break;
        (void)CloneMCPlatform_ApplyPendingResize(app);
        if(!app->listener.active||app->listener.minimized){
            CloneMCTimer_SetActive(&app->timer,0);Sleep(20);
            frontendDeadline=CloneMCTimer_NowSeconds()+frontendInterval;
            continue;}
        CloneMCTimer_SetActive(&app->timer,1);
        /* Java keeps NetClientHandler running while a multiplayer GuiScreen is
         * open.  Without this service point, Options/Stats/GameOver can fill
         * receive buffers or time out the server and leave stale session state. */
        if(returnToGame&&app->multiplayerMode&&app->netClientInitialized&&
           app->networkManager.connected){
            CloneMCNetworkManager_Pump(&app->networkManager);
            CloneMCNetClientHandler_ProcessReadPackets(&app->netClientHandler);
            CloneMCNetClientHandler_DrainEvents(&app->netClientHandler);
        }
        if(returnToGame&&app->multiplayerMode&&app->netClientInitialized&&
           !app->networkManager.connected&&!app->sessionExitRequested){
            const char *reason;
            reason=app->netClientHandler.disconnectReason[0]?
                app->netClientHandler.disconnectReason:app->networkManager.terminationReason;
            CloneMCPlatform_RequestSessionExit(app,1,0,"Connection lost",
                reason&&reason[0]?reason:"Disconnected while a menu was open");
            choice=3;continue;
        }
        if(!CloneMCJ_GuiScreen_ValidateNative(&app->guiScreen))
            CloneMCPlatform_Log("Frontend GUI bounds were repaired before input dispatch.");
        if(app->listener.width>0&&app->listener.height>0&&
           CloneMCMouseHelper_GetClientPosition(&app->mouse,&clientX,&clientY)){
            app->guiScreen.mouseX=clientX*app->guiScreen.width/app->listener.width;
            app->guiScreen.mouseY=clientY*app->guiScreen.height/app->listener.height;
        }
        ++app->guiScreen.cursorCounter;++app->guiScreen.updateCounter;
        if(app->guiScreen.screenType==CLONEMC_GUI_SCREEN_ACHIEVEMENTS){
            CloneMCJ_GuiAchievements_DragNative(&app->guiScreen,app->guiScreen.mouseX,
                app->guiScreen.mouseY,app->input.mouseDown[0]);
            CloneMCJ_GuiAchievements_UpdateNative(&app->guiScreen);
        }
        if((app->guiScreen.updateCounter%5UL)==0UL)
            CloneMCJ_SoundManager_TickNative(&app->soundManager,0);
        character=CloneMCInput_ConsumeCharacter(&app->input);
        while(character>=0){CloneMCJ_GuiScreen_KeyTypedNative(&app->guiScreen,character);
            if(app->guiScreen.screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD)
                CloneMCJ_GuiCreateWorld_UpdateFolderNative(&app->guiScreen,"saves");
            character=CloneMCInput_ConsumeCharacter(&app->input);}
        if(app->guiScreen.screenType==CLONEMC_GUI_SCREEN_CONTROLS&&
           app->guiScreen.keyBindingCapture>=0){
            keyCode=CloneMCInput_ConsumeAnyKeyPress(&app->input);
            if(keyCode>=0&&CloneMCJ_GuiControls_KeyNative(&app->guiScreen,&app->settings,keyCode))
                CloneMCPlatform_MarkSettingsDirty(app);
        }
        id=-1;
        if(CloneMCInput_ConsumeMousePress(&app->input,0))id=CloneMCJ_GuiScreen_MouseClickedNative(
            &app->guiScreen,app->guiScreen.mouseX,app->guiScreen.mouseY);
        if(app->guiScreen.screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER&&
            CloneMCInput_ConsumeKeyPress(&app->input,13))id=0;
        else if((app->guiScreen.screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD||
                 app->guiScreen.screenType==CLONEMC_GUI_SCREEN_RENAME_WORLD)&&
            CloneMCInput_ConsumeKeyPress(&app->input,13))id=0;
        screenType=app->guiScreen.screenType;
        if(app->guiScreen.keyBindingCapture<0&&
           CloneMCInput_ConsumeKeyPress(&app->input,VK_ESCAPE)){
            if(screenType==CLONEMC_GUI_SCREEN_VIDEO||screenType==CLONEMC_GUI_SCREEN_CONTROLS)
                CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_OPTIONS);
            else if(returnToGame&&screenType==CLONEMC_GUI_SCREEN_OPTIONS)choice=3;
            else if(screenType==CLONEMC_GUI_SCREEN_GAME_OVER){
                /* GuiGameOver.keyTyped intentionally cannot dismiss death. */
            }
            else if(screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD)
                CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_SELECT_WORLD);
            else if(screenType==CLONEMC_GUI_SCREEN_RENAME_WORLD||
                    screenType==CLONEMC_GUI_SCREEN_YES_NO)
                CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_SELECT_WORLD);
            else if(screenType!=CLONEMC_GUI_SCREEN_MAIN_MENU)
                CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MAIN_MENU);
        }else if(id>=0){
            sprintf(frontendBreadcrumb,
                "frontend screen %d button %d accepted; click audio begins",screenType,id);
            CloneMCPlatform_CrashBreadcrumb(frontendBreadcrumb);
            /* SoundManager resolves random.click to its preloaded PCM cache
             * and queues it on a bounded waveOut channel.  No file open,
             * codec probe, or MCI call occurs in this GUI dispatch path. */
            CloneMCJ_SoundManager_PlaySoundFX(&app->soundManager,
                "random.click",1.0F,1.0F);
            sprintf(frontendBreadcrumb,
                "frontend screen %d button %d click audio completed; action begins",screenType,id);
            CloneMCPlatform_CrashBreadcrumb(frontendBreadcrumb);
            if(screenType==CLONEMC_GUI_SCREEN_MAIN_MENU){
                if(id==1)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_SELECT_WORLD);
                else if(id==2)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MULTIPLAYER);
                else if(id==3)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_TEXTURE_PACKS);
                else if(id==0)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_OPTIONS);
                else if(id==4)choice=0;
            }else if(screenType==CLONEMC_GUI_SCREEN_SELECT_WORLD){
                if(id>=1000&&id<1000+app->guiScreen.worldCount){
                    selectedResult=CloneMCJ_GuiSelectWorld_SelectNative(&app->guiScreen,id-1000);
                    if(selectedResult==2){
                        CloneMCPlatform_CopyText(app->worldName,sizeof(app->worldName),
                            app->guiScreen.worlds[id-1000].fileName);
                        CloneMCPlatform_CopyText(app->worldDisplayName,sizeof(app->worldDisplayName),
                            app->guiScreen.worlds[id-1000].displayName);app->worldSeed=0;
                        app->creatingNewWorld=0;choice=1;
                    }
                }else if(id==1&&app->guiScreen.selectedWorld>=0){
                    int worldIndex;worldIndex=app->guiScreen.selectedWorld;
                    CloneMCPlatform_CopyText(app->worldName,sizeof(app->worldName),
                        app->guiScreen.worlds[worldIndex].fileName);
                    CloneMCPlatform_CopyText(app->worldDisplayName,sizeof(app->worldDisplayName),
                        app->guiScreen.worlds[worldIndex].displayName);app->worldSeed=0;
                    app->creatingNewWorld=0;choice=1;
                }
                else if(id==3)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_CREATE_WORLD);
                else if((id==6||id==2)&&app->guiScreen.selectedWorld>=0){
                    int worldIndex;worldIndex=app->guiScreen.selectedWorld;
                    CloneMCPlatform_CopyText(app->worldName,sizeof(app->worldName),
                        app->guiScreen.worlds[worldIndex].fileName);
                    CloneMCPlatform_CopyText(app->worldDisplayName,sizeof(app->worldDisplayName),
                        app->guiScreen.worlds[worldIndex].displayName);
                    if(id==6)CloneMCPlatform_SetFrontendScreen(app,
                        CLONEMC_GUI_SCREEN_RENAME_WORLD);
                    else{
                        CloneMCPlatform_CopyText(app->sessionExitTitle,
                            sizeof(app->sessionExitTitle),
                            CloneMCJ_StringTranslate_TranslateKeyNative(
                                "selectWorld.deleteQuestion"));
                        CloneMCPlatform_CopyText(app->sessionExitDetail,
                            sizeof(app->sessionExitDetail),app->worldDisplayName);
                        CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_YES_NO);
                    }
                }
                else if(id==0)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MAIN_MENU);
            }else if(screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD){
                if(id==2&&app->compatibilityPolicy.exposeExtendedGameModes){
                    CloneMCJ_GuiCreateWorld_CycleGameModeNative(&app->guiScreen);
                }else if(id==3&&app->compatibilityPolicy.allowCommands){
                    CloneMCJ_GuiCreateWorld_ToggleCheatsNative(&app->guiScreen);
                }else if(id==0&&app->guiScreen.textField[0]&&!app->guiScreen.createClicked){
                    app->guiScreen.createClicked=1;
                    CloneMCJ_GuiCreateWorld_UpdateFolderNative(&app->guiScreen,"saves");
                    CloneMCPlatform_CopyText(app->worldName,sizeof(app->worldName),
                        app->guiScreen.folderName);
                    CloneMCPlatform_CopyText(app->worldDisplayName,sizeof(app->worldDisplayName),
                        app->guiScreen.textField);
                    app->worldSeed=CloneMCJ_GuiCreateWorld_ResolveSeedNative(&app->guiScreen,
                        CloneMCPlatform_NewWorldSeed());
                    app->pendingGameMode=app->compatibilityPolicy.strictReference?
                        CLONEMC_J_GAMEMODE_SURVIVAL:app->guiScreen.createGameMode;
                    app->pendingAllowCheats=app->compatibilityPolicy.strictReference?
                        0:app->guiScreen.createAllowCheats;
                    app->creatingNewWorld=1;choice=1;
                }
                else if(id==1)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_SELECT_WORLD);
            }else if(screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER){
                if(id==0){
                    CloneMCPlatform_SetUsername(app,app->guiScreen.textField);
                    CloneMCPlatform_CopyText(app->guiScreen.textField,
                        sizeof(app->guiScreen.textField),app->username);
                    if(CloneMCPlatform_ParseServerField(app,
                        app->guiScreen.textFieldSecondary)){
                        CloneMCPlatform_CopyText(app->settings.lastServer,
                            sizeof(app->settings.lastServer),
                            app->guiScreen.textFieldSecondary);choice=2;}
                    else{
                        CloneMCPlatform_CopyText(app->sessionExitTitle,
                            sizeof(app->sessionExitTitle),"Invalid server");
                        CloneMCPlatform_CopyText(app->sessionExitDetail,
                            sizeof(app->sessionExitDetail),"Use host or host:port");
                        CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_ERROR);
                    }}
                else if(id==1)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MAIN_MENU);
            }else if(screenType==CLONEMC_GUI_SCREEN_RENAME_WORLD){
                if(id==0&&app->guiScreen.textField[0]){
                    CloneMCJ_SaveFormatOld_RenameWorld("saves",app->worldName,
                        app->guiScreen.textField);
                    CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_SELECT_WORLD);
                }else if(id==1)CloneMCPlatform_SetFrontendScreen(app,
                    CLONEMC_GUI_SCREEN_SELECT_WORLD);
            }else if(screenType==CLONEMC_GUI_SCREEN_YES_NO){
                if(id==0)CloneMCJ_SaveFormatOld_DeleteWorld("saves",app->worldName);
                if(id==0||id==1)CloneMCPlatform_SetFrontendScreen(app,
                    CLONEMC_GUI_SCREEN_SELECT_WORLD);
            }else if(screenType==CLONEMC_GUI_SCREEN_OPTIONS){
                if(id==101)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_VIDEO);
                else if(id==100)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_CONTROLS);
                else if(id==200){CloneMCPlatform_MarkSettingsDirty(app);
                    if(returnToGame)choice=3;
                    else CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MAIN_MENU);}
                else if(CloneMCJ_GuiOptions_ActivateNative(&app->guiScreen,&app->settings,id)){
                    app->soundManager.soundVolume=app->settings.soundVolume;
                    app->soundManager.musicVolume=app->settings.musicVolume;
                    CloneMCPlatform_MarkSettingsDirty(app);}
            }else if(screenType==CLONEMC_GUI_SCREEN_VIDEO){
                if(id==200){CloneMCPlatform_MarkSettingsDirty(app);
                    CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_OPTIONS);}
                else if(CloneMCJ_GuiVideoSettings_ActivateNative(&app->guiScreen,&app->settings,id)){
                    CloneMCPlatform_MarkSettingsDirty(app);
                    /* GuiVideoSettings.actionPerformed calls setWorldAndResolution
                       after GUI scale changes.  Rebuild this native screen for the
                       new ScaledResolution immediately as the Java client does. */
                    if(id==CLONEMC_OPTION_GUI_SCALE)
                        CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_VIDEO);
                }
            }else if(screenType==CLONEMC_GUI_SCREEN_CONTROLS){
                if(id==200)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_OPTIONS);
                else if(CloneMCJ_GuiControls_ActivateNative(&app->guiScreen,
                    &app->settings,id))
                    CloneMCPlatform_MarkSettingsDirty(app);
            }else if(screenType==CLONEMC_GUI_SCREEN_TEXTURE_PACKS){
                if(id==200)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MAIN_MENU);
                else if(id>=1000&&
                    id<1000+CloneMCTexturePacks_GetCount()){
                    if(CloneMCTexturePacks_Select(id-1000)&&
                       CloneMCPlatform_ReloadTexturePack(app)){
                        CloneMCPlatform_CopyText(app->settings.skin,
                            sizeof(app->settings.skin),
                            CloneMCTexturePacks_GetSelectedName());
                        CloneMCPlatform_MarkSettingsDirty(app);
                    }else{
                        CloneMCPlatform_CopyText(app->settings.skin,
                            sizeof(app->settings.skin),"Default");
                        CloneMCPlatform_MarkSettingsDirty(app);
                    }
                    CloneMCPlatform_SetFrontendScreen(app,
                        CLONEMC_GUI_SCREEN_TEXTURE_PACKS);
                }
            }else if(screenType==CLONEMC_GUI_SCREEN_ACHIEVEMENTS||
                     screenType==CLONEMC_GUI_SCREEN_STATS){
                if(screenType==CLONEMC_GUI_SCREEN_STATS&&id>=1&&id<=3){
                    CloneMCJ_GuiStats_SelectTabNative(&app->guiScreen,id-1);
                    CloneMCJ_GuiStats_SetStatsNative(&app->guiScreen,
                        &app->netClientHandler.statistics);
                }else if(id==200){if(returnToGame)choice=3;
                    else CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MAIN_MENU);}
            }else if(screenType==CLONEMC_GUI_SCREEN_ERROR){
                if(id==0)CloneMCPlatform_SetFrontendScreen(app,CLONEMC_GUI_SCREEN_MAIN_MENU);
            }else if(screenType==CLONEMC_GUI_SCREEN_GAME_OVER){
                if(id==1)choice=4;
                else if(id==2)choice=5;
            }else if(screenType==CLONEMC_GUI_SCREEN_CONFLICT){
                if(id==200)CloneMCPlatform_SetFrontendScreen(app,
                    returnToGame?CLONEMC_GUI_SCREEN_OPTIONS:CLONEMC_GUI_SCREEN_MAIN_MENU);
            }else if(screenType==CLONEMC_GUI_SCREEN_SLEEP){
                if(id==1)choice=3;
            }
        }
        /* An action may have replaced the Java-shaped screen object.  All
         * wheel and drag routing below must use that installed screen, never
         * the screen which accepted the original click. */
        screenType=app->guiScreen.screenType;
        if(screenType==CLONEMC_GUI_SCREEN_SELECT_WORLD){
            int wheel;wheel=CloneMCInput_ConsumeWheel(&app->input);
            if(wheel)CloneMCJ_GuiSelectWorld_ScrollNative(&app->guiScreen,-wheel);
        }else if(screenType==CLONEMC_GUI_SCREEN_STATS){
            int wheel;wheel=CloneMCInput_ConsumeWheel(&app->input);
            if(wheel)CloneMCJ_GuiStats_ScrollNative(&app->guiScreen,-wheel);
        }else if(screenType==CLONEMC_GUI_SCREEN_ACHIEVEMENTS){
            int wheel;wheel=CloneMCInput_ConsumeWheel(&app->input);
            if(wheel){app->guiScreen.achievementTargetY-=wheel*12.0;
                if(app->guiScreen.achievementTargetY<-232.0)app->guiScreen.achievementTargetY=-232.0;
                if(app->guiScreen.achievementTargetY>=67.0)app->guiScreen.achievementTargetY=66.0;}
        }
        if((screenType==CLONEMC_GUI_SCREEN_OPTIONS||screenType==CLONEMC_GUI_SCREEN_VIDEO)&&
           app->input.mouseDown[0]){
            if(CloneMCJ_GuiOptions_DragSliderNative(&app->guiScreen,&app->settings)){
                app->soundManager.soundVolume=app->settings.soundVolume;
                app->soundManager.musicVolume=app->settings.musicVolume;
                /* The exact 2..32 chunk value is authoritative immediately.  A
                 * drag changes only the stream target; it never synchronously
                 * fills the new radius.  Shrinking begins bounded eviction and
                 * growing resumes the nearest-first loader. */
                if(app->world)
                    CloneMCJ_World_SetActiveRadius(app->world,
                        app->settings.renderDistanceChunks);
                CloneMCPlatform_MarkSettingsDirty(app);}
        }else CloneMCJ_GuiScreen_ReleaseMouseNative(&app->guiScreen);
        if(app->resizeAwaitingPresent)
            CloneMCPlatform_CrashBreadcrumb("post-resize frontend frame draw begins");
        else if(firstFrame)CloneMCPlatform_CrashBreadcrumb(
            app->renderer.legacyFrontend?
            "legacy frontend first OpenGL draw begins":"textured frontend first OpenGL draw begins");
        CloneMCRender_DrawGuiScreen(&app->renderer,&app->guiScreen,&app->settings);
        if(app->renderer.legacyFrontend)glFlush();
        if(firstFrame||app->resizeAwaitingPresent){
            frontendError=glGetError();
            if(frontendError!=GL_NO_ERROR){
                sprintf(frontendBreadcrumb,"frontend first draw returned OpenGL error 0x%04x",
                    (unsigned int)frontendError);
                CloneMCPlatform_Log(frontendBreadcrumb);
            }
            CloneMCPlatform_CrashBreadcrumb(app->resizeAwaitingPresent?
                "post-resize frontend draw completed; SwapBuffers begins":
                "frontend first OpenGL draw completed; SwapBuffers begins");
        }
        presented=SwapBuffers(app->deviceContext)?1:0;
        if(!presented){
            CloneMCPlatform_Log("SwapBuffers failed while presenting a frontend frame.");
            choice=returnToGame?3:0;
            continue;
        }
        if(firstFrame){
            CloneMCPlatform_CrashBreadcrumb("frontend first frame presented successfully");
            firstFrame=0;
        }
        if(app->resizeAwaitingPresent){
            app->resizeAwaitingPresent=0;
            CloneMCPlatform_CrashBreadcrumb("post-resize frontend frame presented successfully");
        }
        (void)CloneMCPlatform_FlushSettings(app,0);
        CloneMCPlatform_WaitForFrameDeadline(frontendDeadline);
        frontendNow=CloneMCTimer_NowSeconds();
        if(frontendNow-frontendDeadline>frontendInterval*2.0)
            frontendDeadline=frontendNow+frontendInterval;
        else frontendDeadline+=frontendInterval;
    }
    (void)CloneMCPlatform_FlushSettings(app,1);
    CloneMCInput_Clear(&app->input);
    app->frontendActive=0;
    return choice<0?0:choice;
}

static int CloneMCPlatform_EndSession(CloneMCWin32App *app,int graceful)
{
    DWORD saveStart;
    int pumpCount;
    if(!app)return 0;
    CloneMCMouseHelper_SetGrabbed(&app->mouse,0);
    if(graceful&&app->netClientInitialized&&app->networkManager.connected){
        CloneMCNetClientHandler_SendDisconnect(&app->netClientHandler,"Quitting");
        for(pumpCount=0;pumpCount<32&&app->networkManager.connected&&
            (app->networkManager.sendCount||app->networkManager.activeSendPacket);++pumpCount){
            CloneMCNetworkManager_Pump(&app->networkManager);Sleep(1);
        }
    }
    if(!app->statsLeaveRecorded){
        CloneMCJ_StatFileWriter_AddNative(&app->netClientHandler.statistics,1004,1);
        app->statsLeaveRecorded=1;
    }
    if(!CloneMCPlatform_StatisticsSave(app))++app->metrics.saveFailures;
    CloneMCNetworkManager_Shutdown(&app->networkManager, "Client shutdown");
    if (!app->multiplayerMode && app->world && app->worldInitialized && app->gameplay &&
        !app->saveCompletedForExit) {
        saveStart = timeGetTime();
        if(!CloneMCPlatform_SaveWorldWithLoading(app)){
            ++app->metrics.saveFailures;
            app->metrics.saveMilliseconds+=(unsigned long)(timeGetTime()-saveStart);
            return 0;
        }
        app->metrics.saveMilliseconds+=(unsigned long)(timeGetTime()-saveStart);
    }
    CloneMCRender_SetPriority9State(&app->renderer,0,0,0);
    CloneMCRender_SetMapStorage(&app->renderer,0);
    if(app->netClientInitialized)
        CloneMCNetClientHandler_BindMapStorage(&app->netClientHandler,0);
    if(app->mapStorageInitialized){
        CloneMCJ_MapStorage_Destroy(&app->mapStorage,1);
        app->mapStorageInitialized=0;
    }
    if(app->renderer.initialized){
        CloneMCRenderGlobal_Destroy(&app->renderer.renderGlobal);
        CloneMCRenderGlobal_Initialize(&app->renderer.renderGlobal);
        CloneMCRenderGlobal_SetPerformanceLimits(&app->renderer.renderGlobal,
            app->performanceProfile.meshMemoryCeilingBytes,
            app->performanceProfile.meshStepsPerFrame,
            app->performanceProfile.meshWorkSeconds);
    }
    if (app->gameplay) {
        CloneMCJ_Gameplay_Destroy(app->gameplay);
        free(app->gameplay);
        app->gameplay = 0;
    }
    if (app->worldClient) {
        if (app->worldInitialized) { CloneMCJ_WorldClient_Destroy(app->worldClient); }
        free(app->worldClient);
        app->worldClient = 0;
        app->world = 0;
        app->worldInitialized = 0;
    } else if (app->world) {
        if (app->worldInitialized) { CloneMCJ_World_Destroy(app->world); }
        free(app->world);
        app->world = 0;
        app->worldInitialized = 0;
    }
    if (app->saveHandlerInitialized) {
        CloneMCJ_SaveHandler_Destroy(&app->saveHandler);
        app->saveHandlerInitialized = 0;
    }
    memset(&app->netClientHandler,0,sizeof(app->netClientHandler));
    CloneMCJ_StatFileWriter_InitializeNative(&app->netClientHandler.statistics);
    CloneMCJ_StatFileWriter_LoadJsonFileNative(&app->netClientHandler.statistics,
        "stats_clonemc.json","assets/achievement/map.txt","local");
    memset(&app->multiplayerController,0,sizeof(app->multiplayerController));
    memset(&app->guiIngame,0,sizeof(app->guiIngame));
    app->netClientInitialized=0;app->disconnectReported=0;
    app->respawnRequested=0;
    CloneMCNetworkManager_Initialize(&app->networkManager);
    CloneMCNetworkManager_SetReadQueueCeiling(&app->networkManager,
        app->performanceProfile.networkReadQueueCeilingBytes);
    app->soundManager.playerHealthKnown=0;
    app->soundManager.previousItemsPickedUp=0;
    app->soundManager.previousBlocksMined=0;
    app->soundManager.previousBlocksPlaced=0;
    app->soundManager.walkDistance=0.0;
    memset(app->soundManager.previousMobActive,0,
        sizeof(app->soundManager.previousMobActive));
    memset(app->soundManager.mobTalkCounter,0,sizeof(app->soundManager.mobTalkCounter));
    CloneMCInput_Clear(&app->input);
    app->loadingScreen.running=0;
    app->statsStateKnown=0;app->statsPreviousBlocksMined=0;app->statsPreviousBlocksPlaced=0;
    app->statsLastCraftedSerial=0;app->statsLastSmeltedSerial=0;app->statsPigFallArmed=0;
    app->statsSeenMobCount=0;app->statsLeaveRecorded=0;
    app->saveCompletedForExit=0;
    app->saveStage=0;
    app->closeAfterSave=0;
    CloneMCTimer_Reset(&app->timer);
    return 1;
}

static void CloneMCPlatform_Destroy(CloneMCWin32App *app)
{
    if (!app) { return; }
    (void)CloneMCPlatform_EndSession(app,0);
    if(app->resizeSettingsDirty)
        (void)CloneMCGameSettings_Save(&app->settings,CLONEMC_SETTINGS_FILE);
    CloneMCJ_SoundManager_ShutdownNative(&app->soundManager);
    CloneMCTimer_Shutdown(&app->timer);
    CloneMCPlatform_ReleaseGraphics(app);
    if (app->window && IsWindow(app->window)) { DestroyWindow(app->window); }
    app->window = (HWND)0;
    if (app->fullscreenActive) {
        ChangeDisplaySettingsA((DEVMODEA *)0, 0);
        app->fullscreenActive = 0;
    }
    if (app->classRegistered) {
        UnregisterClassA(CLONEMC_WINDOW_CLASS, app->instance);
        app->classRegistered = 0;
    }
    g_cloneMCWin32App = 0;
}

void CloneMCJ_MinecraftImpl_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MinecraftImpl_JavaName(void)
{
    return "net.minecraft.src.MinecraftImpl";
}

const char *CloneMCJ_MinecraftImpl_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_MinecraftImpl_JavaSourceHash32(void)
{
    return 0x227690BAUL;
}

static void CloneMCPlatform_WaitForFrameDeadline(double deadlineSeconds)
{
    double remaining;
    int yields;
    yields=0;
    for(;;){
        remaining=deadlineSeconds-CloneMCTimer_NowSeconds();
        if(remaining<=0.0)return;
        if(remaining>0.006){
            DWORD milliseconds;
            milliseconds=(DWORD)(remaining*1000.0);
            if(milliseconds>3UL)Sleep(milliseconds-3UL);else Sleep(1);
        }else if(remaining>0.0015){
            Sleep(1);
        }else{
            Sleep(0);
            if(++yields>=32)return;
        }
    }
}

static void CloneMCPlatform_RecordFrame(CloneMCCompatibilityMetrics *metrics,
    double seconds)
{
    unsigned long microseconds;
    unsigned long bucket;
    if(!metrics||seconds<0.0)return;
    if(seconds>4294.0)microseconds=0xFFFFFFFFUL;
    else microseconds=(unsigned long)(seconds*1000000.0+0.5);
    bucket=microseconds/2000UL;
    if(bucket>=64UL)bucket=63UL;
    ++metrics->frameHistogram[bucket];
    ++metrics->frameSamples;
    if(microseconds>metrics->frameMaximumMicroseconds)
        metrics->frameMaximumMicroseconds=microseconds;
}

static unsigned long CloneMCPlatform_FramePercentile(
    const CloneMCCompatibilityMetrics *metrics,unsigned long numerator)
{
    unsigned long target;
    unsigned long cumulative;
    unsigned long bucket;
    if(!metrics||!metrics->frameSamples)return 0UL;
    target=(metrics->frameSamples/100UL)*numerator+
        ((metrics->frameSamples%100UL)*numerator+99UL)/100UL;
    cumulative=0UL;
    for(bucket=0UL;bucket<64UL;++bucket){
        cumulative+=metrics->frameHistogram[bucket];
        if(cumulative>=target)return bucket*2000UL+1000UL;
    }
    return 127000UL;
}

int CloneMCMinecraftImpl_Run(void *instanceHandle, const char *commandLine, int showCommand)
{
    /*
     * This state is intentionally static.  CloneMCRenderBootstrap, networking,
     * statistics and compatibility state make CloneMCWin32App far too large for
     * the one-megabyte stack used by earlier linker files.  Open Watcom reserves
     * automatic storage at function entry, so the old local object could fault
     * before the first log line or window was created.
     */
    static CloneMCWin32App app;
    MSG message;
    int tick;
    int runSelfTests;
    int frontendChoice;
    int frontendInitialScreen;
    int gameOverChoice;
    int legacySafeAudio;
    int mouseDeltaX;
    int mouseDeltaY;
    int guiBlocksInput;
    int pauseQuarter;
    int dataRootReady;
    double nowSeconds;
    double frameStartSeconds;
    double targetFrameSeconds;
    double remainingSeconds;
    char title[512];
    char logLine[768];
    char compatibilityMessage[256];
    char playerSkinPath[MAX_PATH];
    CloneMCRenderWorldPresentation presentation;
    float sunriseColors[4];
    float lookScale;

    /* V143 added executable-relative data-root discovery but never invoked it.
     * Explorer, shortcuts and Win9x compatibility launchers are not required
     * to start in the EXE directory, so every relative atlas lookup could fail
     * together: terrain, placed blocks, inventory items, mobs and GUI art.
     * Resolve the root before even the log/settings/localization paths open. */
    dataRootReady=CloneMCPlatform_UseDataRoot();
    CloneMCPlatform_Log(CLONEMC_VERSION_DISPLAY);
    CloneMCPlatform_Log(dataRootReady?
        "V144 data root verified: packaged terrain and GUI atlases are reachable.":
        "V144 data root ERROR: assets\\terrain.tga and assets\\gui\\gui.tga were not found beside the executable or in a supported parent/data folder.");
    if(!dataRootReady){
        MessageBoxA((HWND)0,
            "CloneMC could not find assets\\terrain.tga and assets\\gui\\gui.tga. Keep the EXE with the packaged assets folder, or set CLONEMC_HOME to that folder.",
            "CloneMC V144 missing rendering assets",MB_OK|MB_ICONERROR);
        return 40;
    }
    sprintf(logLine,
        "Build profile=%s; referenceManifest=%s; parityManifest=%s; sourceArchive=%s",
        CLONEMC_BUILD_PROFILE,CLONEMC_REFERENCE_MANIFEST_SHA256,
        CLONEMC_PARITY_MANIFEST_SHA256,CLONEMC_SOURCE_ARCHIVE_SHA256);
    CloneMCPlatform_Log(logLine);
    CloneMCPlatform_LogStartupPhase(1U, "runtime entry reached; crash log is writable");
    memset(&app, 0, sizeof(app));
    /* The uploaded original package exposed its game-mode and cheat controls
     * by default.  V130 inverted that default while adding an opt-in reference
     * policy, which made valid controls disappear and silently forced Survival.
     * Preserve -reference for explicit Java-only diagnostics, but restore the
     * original extended frontend for ordinary Win9x launches. */
    app.compatibilityPolicy.strictReference=
        CloneMCPlatform_HasArgument(commandLine,"-reference")?1:0;
    app.compatibilityPolicy.exposeExtendedGameModes=
        app.compatibilityPolicy.strictReference?0:1;
    app.compatibilityPolicy.allowCommands=
        app.compatibilityPolicy.strictReference?0:1;
    app.compatibilityPolicy.enableOnlineResources=0;
    sprintf(logLine, "Application state uses static storage (%lu bytes); command line: %s",
        (unsigned long)sizeof(app), commandLine && *commandLine ? commandLine : "(none)");
    CloneMCPlatform_Log(logLine);
    CloneMCPlatform_Log(app.compatibilityPolicy.strictReference?
        "Reference mode active: uploaded Java behavior is authoritative and CloneMC-only game modes/commands are hidden.":
        "Extended mode active: CloneMC creative, spectator, cheats and extension commands are enabled.");
    CloneMCNetworkManager_Initialize(&app.networkManager);
    app.instance = (HINSTANCE)instanceHandle;
    if (!app.instance) { app.instance = GetModuleHandleA((LPCSTR)0); }
    CloneMCGameSettings_SetDefaults(&app.settings);
    if(!CloneMCGameSettings_Load(&app.settings, CLONEMC_SETTINGS_FILE))
        CloneMCGameSettings_Load(&app.settings,CLONEMC_LEGACY_SETTINGS_FILE);
    CloneMCJ_StringTranslate_InitializeNative("assets/lang/en_US.lang",
        "assets/lang/stats_US.lang");
    CloneMCGameSettings_ApplyCommandLine(&app.settings, commandLine ? commandLine : "");
    CloneMCTexturePacks_Initialize(app.settings.skin);
    CloneMCPlatform_ResolvePerformanceProfile(&app.performanceProfile,
        commandLine?commandLine:"");
    CloneMCNetworkManager_SetReadQueueCeiling(&app.networkManager,
        app.performanceProfile.networkReadQueueCeilingBytes);
    CloneMCPlatform_ApplyPerformanceSettings(&app.settings,
        &app.performanceProfile);
    app.win98SafeProfile=strcmp(app.performanceProfile.name,"win98-safe")==0;
    app.realWin9xMode=CloneMCPlatform_IsRealWin9x(GetVersion());
    app.compatibilityShimMode=CloneMCPlatform_IsModernCompatibilityShim(GetVersion());
    app.legacyCompatibilityMode=CloneMCPlatform_ShouldUseLegacyCompatibility(
        GetVersion(),commandLine?commandLine:"");
    CloneMCPlatform_ApplyLegacyCompatibilitySettings(&app.settings,
        app.legacyCompatibilityMode);
    CloneMCTimer_ForceFallbackClock(app.legacyCompatibilityMode);
    app.softwareGLRequested=CloneMCPlatform_HasArgument(commandLine,"-softwaregl");
    if(app.legacyCompatibilityMode){
        sprintf(logLine,
            "Windows 95/98 compatibility active: kernel=%s, profile=%s, resident cap=%d chunks, 640x480 maximum, scale-1 frontend, %s pixel format, basic graphics, fallback clock, and driver-isolated audio.",
            app.realWin9xMode?"real Win9x":
                (app.compatibilityShimMode?"modern AppCompat":"legacy NT"),
            app.performanceProfile.name,
            app.performanceProfile.residentChunkTarget,
            app.realWin9xMode?"16/16":"32/24");
        CloneMCPlatform_Log(logLine);
    }
    CloneMCPlatform_ParseMultiplayer(&app, commandLine ? commandLine : "");
    CloneMCJ_StatFileWriter_InitializeNative(&app.netClientHandler.statistics);
    CloneMCJ_StatFileWriter_LoadJsonFileNative(&app.netClientHandler.statistics,
        "stats_clonemc.json","assets/achievement/map.txt","local");
    CloneMCJ_StatFileWriter_AddNative(&app.netClientHandler.statistics,1000,1);
    if(!app.serverHost[0]&&app.settings.lastServer[0])
        CloneMCPlatform_ParseServerField(&app,app.settings.lastServer);
    if(!strstr(commandLine?commandLine:"","-server="))app.multiplayerMode=0;
    CloneMCWindowListener_Initialize(&app.listener, app.settings.width, app.settings.height);
    CloneMCInput_Initialize(&app.input);
    g_cloneMCWin32App = &app;
    CloneMCPlatform_LogStartupPhase(2U, "settings, command line, input and network state initialized");

    /* Java Minecraft does not execute a large native regression suite on every
     * launch.  Keep the tests for diagnostics without placing their large local
     * world/chunk/gameplay objects on the normal startup stack. */
    runSelfTests = CloneMCPlatform_HasArgument(commandLine, "-selftest") ||
        CloneMCPlatform_HasArgument(commandLine, "-diagnostics");
    if (runSelfTests) {
        CloneMCPlatform_LogStartupPhase(3U, "explicit startup self-tests begin");
        if (!CloneMCJavaCore_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 10;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCPacket_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 15;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCNetworkManager_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 16;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_SaveHandler_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 21;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_Priority7_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 14;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_Priority13_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 17;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_Priority12_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 16;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_Priority14_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 18;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_Priority16_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 24;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_Priority17_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 25;
        }
        if(!CloneMCJ_Progression_RunSelfTests(compatibilityMessage,
            sizeof(compatibilityMessage))){
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCPlatform_Log("BOOTSTRAP 02: progression self-test FAILED");
            MessageBoxA(0,compatibilityMessage,"CloneMC progression self-test",
                MB_OK|MB_ICONERROR);
            return 2;
        }
        if(!CloneMCJ_EntityAITasks_RunSelfTests(compatibilityMessage,
            sizeof(compatibilityMessage))){
            CloneMCPlatform_Log(compatibilityMessage);
            MessageBoxA(0,compatibilityMessage,
                "CloneMC Java 1.2.3 AI scheduler self-test",
                MB_OK|MB_ICONERROR);
            return 2;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if(!CloneMCJ_V136_RunGameplaySelfTests(compatibilityMessage,
            sizeof(compatibilityMessage))){
            MessageBoxA((HWND)0,compatibilityMessage,
                "CloneMC V136 village/dragon self-test failed",
                MB_OK|MB_ICONERROR);
            CloneMCPlatform_Log(compatibilityMessage);
            return 2;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        CloneMCPlatform_Log(compatibilityMessage);
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_V127_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 27;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_Priority6_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 13;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_ChunkProviderLoadOrGenerate_RunLimitSelfTests(
                compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 25;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCNoise_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 11;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCChunk_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 12;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if(!CloneMCJ_ChunkProviderGenerate_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))){
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 37;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRenderV116_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 19;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRender_RunV1324PerformanceSelfTests(
                compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 34;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRender_RunV1325VisualSafetySelfTests(
                compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 35;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCWorldRenderer_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 22;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRenderGlobal_RunV119SelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 23;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_ChunkProviderLoadOrGenerate_RunV119SelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 24;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCModelRenderer_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 40;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRenderLiving_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 20;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCDynamicTextures_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 28;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCJ_MapPipeline_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 29;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCTexturePack_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 30;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRenderBoat_RunSelfTests(compatibilityMessage, sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 26;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRenderMinecart_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 31;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRenderManager_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 32;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        if (!CloneMCRenderPlayerSkin_RunSelfTests(compatibilityMessage,
                sizeof(compatibilityMessage))) {
            CloneMCPlatform_Log(compatibilityMessage);
            CloneMCMinecraftAppletImpl_ReportError(compatibilityMessage);
            CloneMCPlatform_Destroy(&app);
            return 33;
        }
        CloneMCPlatform_Log(compatibilityMessage);
        CloneMCPlatform_LogStartupPhase(4U, "explicit startup self-tests passed");
    } else {
        CloneMCPlatform_Log("Startup self-tests skipped for normal play; use -selftest to run them.");
    }
    CloneMCPlatform_LogStartupPhase(5U, "initializing fixed-step timer");
    if (!CloneMCTimer_Initialize(&app.timer, CLONEMC_TIMER_DEFAULT_TPS)) {
        CloneMCMinecraftAppletImpl_ReportError("The CloneMC fixed-step timer could not initialize.");
        CloneMCPlatform_Destroy(&app);
        return 1;
    }
    CloneMCPlatform_LogStartupPhase(6U, "creating Win32 window and OpenGL rendering context");
    if (!CloneMCPlatform_CreateWindowAndContext(&app, showCommand)) {
        CloneMCMinecraftAppletImpl_ReportError("CloneMC could not create a compatible Win32 OpenGL context. See clonemc_platform.log.");
        CloneMCPlatform_Destroy(&app);
        return 2;
    }
    CloneMCPlatform_LogStartupPhase(7U, "window and OpenGL context created");
    CloneMCMouseHelper_Initialize(&app.mouse, app.window);
    if (!CloneMCOpenGL_QueryCaps(&app.glCaps,
            (app.pixelFormat.dwFlags & PFD_DOUBLEBUFFER) ? 1 : 0)) {
        CloneMCMinecraftAppletImpl_ReportError("OpenGL 1.1 or a 64-pixel texture size is not available.");
        CloneMCPlatform_Destroy(&app);
        return 3;
    }
    CloneMCPlatform_LogStartupPhase(8U, "OpenGL 1.1 capability checks passed");
    sprintf(logLine,"Startup OpenGL vendor=%s renderer=%s version=%s maxTexture=%d",
        app.glCaps.vendor,app.glCaps.renderer,app.glCaps.version,
        app.glCaps.maxTextureSize);
    CloneMCPlatform_Log(logLine);
    if(app.glCaps.softwareRenderer)
        CloneMCPlatform_Log(
            "Software OpenGL renderer detected: the configured 30-260/Max frame slider remains authoritative; simulation remains fixed at 20 TPS.");
    if (!CloneMCRender_Initialize(&app.renderer, app.listener.width, app.listener.height)) {
        CloneMCMinecraftAppletImpl_ReportError("The OpenGL 1.1 fixed-function renderer could not initialize.");
        CloneMCPlatform_Destroy(&app);
        return 4;
    }
    /* EntityPlayerSP assigns a username skin URL in the uploaded Java.  The
     * Win9x port keeps that behavior local and deterministic: an explicit
     * -playerskin=path wins, otherwise skins/<username>.png or .tga is tried.
     * Missing/malformed files always fall back to assets/mob/char.tga. */
    if(CloneMCPlatform_GetArgumentValue(commandLine,"-playerskin=",
            playerSkinPath,sizeof(playerSkinPath))){
        if(CloneMCRender_ApplyPlayerSkin(&app.renderer,playerSkinPath,
                compatibilityMessage,sizeof(compatibilityMessage)))
            CloneMCPlatform_Log(compatibilityMessage);
        else{
            sprintf(logLine,"%s: %s",compatibilityMessage,playerSkinPath);
            CloneMCPlatform_Log(logLine);
        }
    }else{
        sprintf(playerSkinPath,"skins/%s.png",app.username);
        if(CloneMCRender_ApplyPlayerSkin(&app.renderer,playerSkinPath,
                compatibilityMessage,sizeof(compatibilityMessage)))
            CloneMCPlatform_Log(compatibilityMessage);
        else{
            sprintf(playerSkinPath,"skins/%s.tga",app.username);
            if(CloneMCRender_ApplyPlayerSkin(&app.renderer,playerSkinPath,
                    compatibilityMessage,sizeof(compatibilityMessage)))
                CloneMCPlatform_Log(compatibilityMessage);
            else CloneMCPlatform_Log(
                "No local custom player skin selected; using assets/mob/char.tga.");
        }
    }
    CloneMCRender_SetPerformanceLimits(&app.renderer,
        app.performanceProfile.meshMemoryCeilingBytes,
        app.performanceProfile.meshStepsPerFrame,
        app.performanceProfile.meshWorkSeconds,
        app.performanceProfile.particleLimit);
    app.renderer.legacyFrontend=(app.legacyCompatibilityMode&&
        !CloneMCPlatform_HasArgument(commandLine,"-no-legacygui"))||
        CloneMCPlatform_HasArgument(commandLine,"-legacygui");
    CloneMCPlatform_LogStartupPhase(9U, "renderer and presentation assets initialized");
    legacySafeAudio=(app.legacyCompatibilityMode&&
        !CloneMCPlatform_HasArgument(commandLine,"-no-safeaudio"))||
        CloneMCPlatform_HasArgument(commandLine,"-safeaudio");
    if(CloneMCPlatform_HasArgument(commandLine,"-no-safeaudio"))legacySafeAudio=0;
    CloneMCJ_LoadingScreenRenderer_InitializeNative(&app.loadingScreen);
    CloneMCPlatform_LogStartupPhase(91U,
        legacySafeAudio?"loading screen ready; opening single-channel compatibility audio":
        "loading screen ready; opening bounded multichannel audio");
    CloneMCJ_SoundManager_InitializeNativeWithMode(&app.soundManager,
        &app.settings,legacySafeAudio);
    CloneMCPlatform_LogStartupPhase(92U,
        app.soundManager.soundAvailable?"audio backend initialized":
        "audio backend unavailable; continuing without sound");
    CloneMCPlatform_Log(legacySafeAudio?
        "Compatibility PCM audio active: bounded preloaded waveOut effects; WAV music and records use separately polled waveaudio streams.":
        "Bounded PCM waveOut effects and WAV streaming audio active.");
    frontendChoice=1;
    if(!strstr(commandLine?commandLine:"","-server=")&&
       !strstr(commandLine?commandLine:"","-world=")&&
       !CloneMCPlatform_HasArgument(commandLine,"-quickplay")){
        CloneMCPlatform_LogStartupPhase(10U,"Java-shaped title menu is active before world loading");
        frontendChoice=CloneMCPlatform_RunFrontend(&app,CLONEMC_GUI_SCREEN_MAIN_MENU,0);
        if(frontendChoice==0){CloneMCPlatform_Log("User exited from the title menu.");
            CloneMCPlatform_Destroy(&app);return 0;}
        app.multiplayerMode=frontendChoice==2?1:0;
        CloneMCPlatform_LogStartupPhase(11U,frontendChoice==2?
            "multiplayer selected; preparing WorldClient":"singleplayer world selected");
    }else CloneMCPlatform_Log("Command-line quick play bypassed the title menu.");
start_world_session:
    app.sessionExitRequested=0;app.sessionExitShowsError=0;app.gracefulDisconnect=0;
    app.saveCompletedForExit=0;
    app.saveInProgress=0;
    app.closeAfterSave=0;
    app.saveStage=0;
    app.saveFailureDetail[0]='\0';
    app.respawnRequested=0;
    app.sessionExitTitle[0]='\0';app.sessionExitDetail[0]='\0';
    app.disconnectReported=0;
    app.worldRuntimeTicks=0UL;
    CloneMCPlatform_ShowLoading(&app,"Loading world","Preparing level",5);
    if (app.multiplayerMode) {
        CloneMCPlatform_LogStartupPhase(12U, "allocating authoritative multiplayer world");
        app.worldClient = (CloneMCJ_WorldClient *)calloc(1,sizeof(CloneMCJ_WorldClient));
        if (!app.worldClient) {
            CloneMCPlatform_RequestSessionExit(&app,1,0,"Out of memory",
                "CloneMC could not allocate the multiplayer world.");
            goto session_finished;
        }
        CloneMCJ_WorldClient_Initialize(app.worldClient, &app.networkManager, (CloneMCJLong)0, 0);
        app.world = &app.worldClient->baseWorld;
        CloneMCJ_World_SetActiveRadius(app.world,
            app.settings.renderDistanceChunks);
        app.worldInitialized = 1;
    } else {
        CloneMCPlatform_LogStartupPhase(12U, "allocating and initializing singleplayer world");
        app.world = (CloneMCJ_World *)calloc(1,sizeof(CloneMCJ_World));
        if (!app.world) {
            CloneMCPlatform_RequestSessionExit(&app,1,0,"Out of memory",
                "CloneMC could not allocate the singleplayer world.");
            goto session_finished;
        }
        CloneMCJ_World_InitializeDeferred(app.world, app.worldSeed, app.settings.renderDistanceChunks);
        CloneMCJ_World_SetChunkMemoryBudget(app.world,
            app.performanceProfile.chunkMemoryCeilingBytes);
        app.worldInitialized = 1;
        CloneMCPlatform_ShowLoading(&app,0,"Opening save",25);
        CloneMCPlatform_LogStartupPhase(13U, "opening save directory and session lock");
        if (!CloneMCJ_SaveHandler_Initialize(&app.saveHandler, "saves", app.worldName, 1)) {
            CloneMCPlatform_RequestSessionExit(&app,1,0,"Unable to load world",
                CloneMCJ_SaveHandler_GetLastError(&app.saveHandler)[0]?
                CloneMCJ_SaveHandler_GetLastError(&app.saveHandler):
                "The selected save is locked or its directory cannot be opened.");
            goto session_finished;
        }
        CloneMCJ_RegionFileCache_SetLimit(&app.saveHandler.regionCache,
            app.performanceProfile.regionFileLimit);
        app.saveHandlerInitialized = 1;
        CloneMCPlatform_LogStartupPhase(14U, "loading level metadata and McRegion chunks");
        CloneMCPlatform_ShowLoading(&app,0,"Building terrain",45);
        if (!CloneMCJ_World_AttachSaveHandler(app.world, &app.saveHandler,
                app.worldDisplayName[0]?app.worldDisplayName:app.worldName)) {
            CloneMCPlatform_RequestSessionExit(&app,1,0,"Unable to load world",
                CloneMCJ_SaveHandler_GetLastError(&app.saveHandler)[0]?
                CloneMCJ_SaveHandler_GetLastError(&app.saveHandler):
                "The level.dat or McRegion data could not be opened safely.");
            goto session_finished;
        }
        app.world->worldInfo.writeExtensionTags=(unsigned char)
            (app.compatibilityPolicy.strictReference?0:1);
        if(app.creatingNewWorld){app.world->worldInfo.gameType=app.pendingGameMode;
            app.world->worldInfo.allowCommands=(unsigned char)(app.pendingAllowCheats?1:0);}
        if (!CloneMCPlatform_BootstrapSpawnArea(&app)) {
            CloneMCPlatform_RequestSessionExit(&app,1,0,"Unable to load world",
                "The nearest spawn chunks could not be prepared within the bounded memory budget.");
            goto session_finished;
        }
    }
    CloneMCJ_MapStorage_Initialize(&app.mapStorage,
        app.multiplayerMode?(CloneMCJ_SaveHandler *)0:&app.saveHandler);
    app.mapStorageInitialized=1;
    CloneMCPlatform_LogStartupPhase(15U, "allocating integrated gameplay and player state");
    CloneMCPlatform_ShowLoading(&app,0,"Simulating world for a bit",92);
    app.gameplay = (CloneMCJ_GameplayState *)calloc(1,sizeof(CloneMCJ_GameplayState));
    app.editingSign=(CloneMCJ_TileEntity *)0;app.signEditLine=0;
    app.signEditCounter=0;
    if (!app.gameplay) {
        CloneMCPlatform_RequestSessionExit(&app,1,0,"Out of memory",
            "CloneMC could not allocate the player and entity state.");
        goto session_finished;
    }
    CloneMCJ_Gameplay_Initialize(app.gameplay, app.world, app.username);
    app.gameplay->difficulty=app.settings.difficulty;
    if(!app.multiplayerMode)CloneMCPlatform_ApplyGameMode(&app,
        app.world->worldInfo.gameType,0);
    /* A returning player can be many chunks from the spawn window prepared
     * above.  Build the same bounded radius around the NBT-restored position
     * before mesh warmup, otherwise the first world frame contains only sky. */
    if(!app.multiplayerMode&&!CloneMCPlatform_BootstrapSpawnArea(&app)){
        CloneMCPlatform_RequestSessionExit(&app,1,0,"Unable to load world",
            "The chunks around the saved player position could not be loaded safely.");
        goto session_finished;
    }
    CloneMCJ_GuiIngame_Initialize(&app.guiIngame);
    app.guiIngame.multiplayerWorld=app.multiplayerMode;
    CloneMCJ_GuiIngame_UpdateResolutionWithScale(&app.guiIngame,app.listener.width,
        app.listener.height,app.settings.guiScale);
    CloneMCRender_SetPriority9State(&app.renderer,app.gameplay,&app.guiIngame,
        &app.settings);
    CloneMCRender_SetMapStorage(&app.renderer,&app.mapStorage);
    if (!CloneMCPlatform_WarmSpawnMeshes(&app)) goto session_finished;
    CloneMCPlatform_ShowLoading(&app,0,"Simulating world for a bit",99);
    app.loadingScreen.running=0;
    CloneMCPlatform_LogStartupPhase(16U, "gameplay, GUI and non-fatal audio initialization complete");
    if (app.multiplayerMode) {
        CloneMCNetClientHandler_Initialize(&app.netClientHandler, &app.networkManager,
            app.worldClient, app.gameplay, &app.guiIngame);
        CloneMCNetClientHandler_BindMapStorage(&app.netClientHandler,&app.mapStorage);
        CloneMCNetClientHandler_BindSound(&app.netClientHandler,&app.soundManager);
        app.netClientInitialized = 1;
        CloneMCJ_StatFileWriter_LoadJsonFileNative(&app.netClientHandler.statistics,
            "stats_clonemc.json", "assets/achievement/map.txt", "local");
        CloneMCJ_StatFileWriter_AddNative(&app.netClientHandler.statistics,1000,1);
        CloneMCJ_StatFileWriter_AddNative(&app.netClientHandler.statistics,1003,1);
        CloneMCPlayerControllerMP_Initialize(&app.multiplayerController, &app.netClientHandler);
        CloneMCPlayerControllerMP_BindGameplay(&app.multiplayerController, app.gameplay);
        if (!CloneMCNetworkManager_Connect(&app.networkManager, app.serverHost, app.serverPort)) {
            sprintf(logLine, "Could not connect to %s:%u: %s", app.serverHost,
                (unsigned int)app.serverPort, app.networkManager.terminationReason);
            CloneMCPlatform_Log(logLine);
            CloneMCPlatform_RequestSessionExit(&app,1,0,"Failed to connect",logLine);
            goto session_finished;
        }
        if (!CloneMCNetClientHandler_SendHandshake(&app.netClientHandler, app.username)) {
            CloneMCPlatform_RequestSessionExit(&app,1,0,"Failed to connect",
                "Could not queue the Beta 1.7.3 handshake packet.");
            goto session_finished;
        }
        sprintf(logLine, "Connecting to %s:%u as %s (protocol %d)", app.serverHost,
            (unsigned int)app.serverPort, app.username, CLONEMC_NET_PROTOCOL_VERSION);
        CloneMCJ_GuiIngame_AddChatMessage(&app.guiIngame, logLine);
        CloneMCPlatform_Log(logLine);
    } else {
        CloneMCJ_StatFileWriter_AddNative(&app.netClientHandler.statistics,1002,1);
        CloneMCJ_GuiIngame_AddChatMessage(&app.guiIngame,
            app.compatibilityPolicy.strictReference?
            CLONEMC_VERSION_DISPLAY " - Reference mode":
            CLONEMC_VERSION_DISPLAY " - Extended mode");
    }

    CloneMCOpenGL_FormatWindowTitle(&app.glCaps, title, sizeof(title));
    SetWindowTextA(app.window, title);
    sprintf(logLine, "OpenGL vendor=%s renderer=%s version=%s maxTexture=%d color=%d depth=%d software=%d",
            app.glCaps.vendor, app.glCaps.renderer, app.glCaps.version,
            app.glCaps.maxTextureSize, app.glCaps.colorBits,
            app.glCaps.depthBits, app.glCaps.softwareRenderer);
    CloneMCPlatform_Log(logLine);
    CloneMCPlatform_Log(app.renderer.priority6AssetsLoaded ?
        "Priority 6 sun, moon, cloud and rain TGA assets loaded." :
        "One or more Priority 6 presentation assets were unavailable; fixed-function fallbacks remain active.");
    CloneMCPlatform_Log(app.renderer.priority8AssetsLoaded ?
        "Priority 8 terrain atlas loaded; Java-shaped three-pass chunk renderer active." :
        "Priority 8 terrain atlas is unavailable; chunk geometry remains active without terrain texels.");
    CloneMCPlatform_Log(app.renderer.priority9AssetsLoaded ?
        "Priority 9 GUI, font, item and mob TGA assets loaded." :
        "One or more Priority 9 presentation assets are unavailable; state-safe fallbacks remain active.");
    CloneMCGameSettings_Save(&app.settings, CLONEMC_SETTINGS_FILE);
    CloneMCTimer_Reset(&app.timer);
    app.statisticsStartSeconds = CloneMCTimer_NowSeconds();
    targetFrameSeconds = app.settings.targetFramesPerSecond > 0 ?
        1.0 / (double)app.settings.targetFramesPerSecond : 0.0;
    CloneMCPlatform_LogStartupPhase(17U, "entering main event, simulation and render loop");

world_loop_resume:
    while(!app.listener.closeRequested){
        CloneMCPlatform_SetRuntimePhase(190U,"runtime message pump and input");
        frameStartSeconds = CloneMCTimer_NowSeconds();
        while (PeekMessageA(&message, (HWND)0, 0, 0, PM_REMOVE)) {
            if (message.message == WM_QUIT) { app.listener.closeRequested = 1; break; }
            TranslateMessage(&message);
            DispatchMessageA(&message);
        }
        if (app.listener.closeRequested) { break; }
        (void)CloneMCPlatform_ApplyPendingResize(&app);
        if (!app.listener.active || app.listener.minimized) {
            CloneMCTimer_SetActive(&app.timer,0);
            Sleep(20);
            continue;
        }
        CloneMCTimer_SetActive(&app.timer,1);

        CloneMCJ_GuiIngame_UpdateResolutionWithScale(&app.guiIngame,app.listener.width,
            app.listener.height,app.settings.guiScale);
        CloneMCPlatform_UpdateGuiCursor(&app);
        CloneMCPlatform_PollSignEditor(&app);
        if (CloneMCInput_ConsumeKeyPress(&app.input, VK_ESCAPE)) {
            if(CloneMCJ_GuiWinGame_IsActiveNative()){
                CloneMCJ_GuiWinGame_FinishNative();
                CloneMCMouseHelper_SetGrabbed(&app.mouse,1);
            }else if(app.editingSign){
                CloneMCPlatform_CloseSignEditor(&app);
            } else if (app.guiIngame.chatOpen) {
                CloneMCPlatform_CloseChat(&app);
            } else if (app.guiIngame.inventoryOpen) {
                CloneMCPlatform_CloseInventory(&app);
            } else {
                app.guiIngame.pauseMenu = !app.guiIngame.pauseMenu;
                /* GuiIngameMenu pauses single-player but does not begin a second
                 * hidden metadata transaction immediately before the explicit
                 * Save and quit transaction.  Autosave remains bounded in the
                 * normal world tick path. */
            }
            CloneMCInput_ConsumeMousePress(&app.input, 0);
            CloneMCInput_ConsumeMousePress(&app.input, 1);
            CloneMCMouseHelper_SetGrabbed(&app.mouse,
                app.guiIngame.inventoryOpen || app.guiIngame.pauseMenu ||
                app.guiIngame.chatOpen || app.editingSign ? 0 : 1);
        }
        if(app.editingSign&&CloneMCInput_ConsumeMousePress(&app.input,0)){
            if(CloneMCPlatform_PointInButton(&app.guiIngame,
                app.guiIngame.scaledWidth/2,app.guiIngame.scaledHeight/4+120,200))
                CloneMCPlatform_CloseSignEditor(&app);
        }
        if (app.guiIngame.pauseMenu && CloneMCInput_ConsumeMousePress(&app.input, 0)) {
            pauseQuarter = app.guiIngame.scaledHeight / 4;
            if (CloneMCPlatform_PointInButton(&app.guiIngame,
                    app.guiIngame.scaledWidth / 2, pauseQuarter + 8, 200)) {
                app.guiIngame.pauseMenu = 0;
                app.guiIngame.saveFailed=0;
                app.guiIngame.saveStatus[0]='\0';
                CloneMCMouseHelper_SetGrabbed(&app.mouse, 1);
            } else if (CloneMCPlatform_PointInButton(&app.guiIngame,
                    app.guiIngame.scaledWidth / 2-51, pauseQuarter + 32, 98)) {
                CloneMCPlatform_RunFrontend(&app,CLONEMC_GUI_SCREEN_ACHIEVEMENTS,1);
                CloneMCOpenGL_FormatWindowTitle(&app.glCaps,title,sizeof(title));SetWindowTextA(app.window,title);
                CloneMCTimer_Reset(&app.timer);
            } else if (CloneMCPlatform_PointInButton(&app.guiIngame,
                    app.guiIngame.scaledWidth / 2+51, pauseQuarter + 32, 98)) {
                CloneMCPlatform_RunFrontend(&app,CLONEMC_GUI_SCREEN_STATS,1);
                CloneMCOpenGL_FormatWindowTitle(&app.glCaps,title,sizeof(title));SetWindowTextA(app.window,title);
                CloneMCTimer_Reset(&app.timer);
            } else if (CloneMCPlatform_PointInButton(&app.guiIngame,
                    app.guiIngame.scaledWidth / 2, pauseQuarter + 80, 200)) {
                CloneMCPlatform_RunFrontend(&app,CLONEMC_GUI_SCREEN_OPTIONS,1);
                CloneMCOpenGL_FormatWindowTitle(&app.glCaps,title,sizeof(title));SetWindowTextA(app.window,title);
                app.soundManager.soundVolume=app.settings.soundVolume;
                app.soundManager.musicVolume=app.settings.musicVolume;
                if(app.gameplay)
                    app.gameplay->difficulty=app.settings.difficulty;
                if (app.world)
                    CloneMCJ_World_SetActiveRadius(app.world,
                        app.settings.renderDistanceChunks);
                targetFrameSeconds=app.settings.targetFramesPerSecond>0?
                    1.0/(double)app.settings.targetFramesPerSecond:0.0;
                CloneMCTimer_Reset(&app.timer);
            } else if (CloneMCPlatform_PointInButton(&app.guiIngame,
                    app.guiIngame.scaledWidth / 2, pauseQuarter + 104, 200)) {
                CloneMCJ_SoundManager_PlaySoundFX(&app.soundManager,
                    "random.click",1.0F,1.0F);
                if(app.multiplayerMode){
                    CloneMCPlatform_RequestSessionExit(&app,0,1,"",
                        "Disconnect selected; returning to title");
                }else{
                    DWORD quitSaveStart;
                    quitSaveStart=timeGetTime();
                    if(CloneMCPlatform_SaveWorldWithLoading(&app)){
                        app.metrics.saveMilliseconds+=(unsigned long)(timeGetTime()-quitSaveStart);
                        CloneMCPlatform_RequestSessionExit(&app,0,0,"",
                            "Save and quit completed; returning to title");
                    }else{
                        ++app.metrics.saveFailures;
                        app.saveCompletedForExit=0;
                        /* Keep the OpenGL context and live world intact.  The
                         * pause GUI displays the error and offers the same Save
                         * and quit button as a retry; do not enter a modal Win32
                         * message loop during a failed filesystem transaction. */
                        app.guiIngame.pauseMenu=1;
                        app.guiIngame.saveFailed=1;
                        CloneMCPlatform_CopyText(app.guiIngame.saveStatus,
                            sizeof(app.guiIngame.saveStatus),
                            app.saveFailureDetail[0]?app.saveFailureDetail:
                            "Save failed; the world remains open");
                    }
                }
            }
        }
        if(app.sessionExitRequested)break;
        if (!app.guiIngame.pauseMenu && !app.guiIngame.inventoryOpen &&
            !app.guiIngame.chatOpen &&
            CloneMCInput_ConsumeKeyPress(&app.input, app.settings.keyCodes[8]))
            CloneMCPlatform_OpenChat(&app);
        /* Restore the V135 Far/Normal/Short/Tiny budget cycle.  The slider
         * still permits every integer chunk target up to the profile ceiling. */
        if(!app.guiIngame.pauseMenu&&!app.guiIngame.inventoryOpen&&
           !app.guiIngame.chatOpen&&
           CloneMCInput_ConsumeKeyPress(&app.input,app.settings.keyCodes[9])){
            int maximumChunks;
            maximumChunks=app.settings.renderDistanceMaximumChunks;
            if(maximumChunks<CLONEMC_RENDER_DISTANCE_MIN_CHUNKS||
               maximumChunks>CLONEMC_RENDER_DISTANCE_MAX_CHUNKS)
                maximumChunks=CLONEMC_RENDER_DISTANCE_MAX_CHUNKS;
            if(app.settings.renderDistanceChunks>16&&maximumChunks>=16)
                app.settings.renderDistanceChunks=16;
            else if(app.settings.renderDistanceChunks>8&&maximumChunks>=8)
                app.settings.renderDistanceChunks=8;
            else if(app.settings.renderDistanceChunks>4&&maximumChunks>=4)
                app.settings.renderDistanceChunks=4;
            else if(app.settings.renderDistanceChunks>2)
                app.settings.renderDistanceChunks=2;
            else if(maximumChunks>=16)app.settings.renderDistanceChunks=16;
            else if(maximumChunks>=8)app.settings.renderDistanceChunks=8;
            else if(maximumChunks>=4)app.settings.renderDistanceChunks=4;
            else app.settings.renderDistanceChunks=maximumChunks;
            CloneMCGameSettings_SynchronizeDerived(&app.settings);
            if(app.world)CloneMCJ_World_SetActiveRadius(app.world,
                app.settings.renderDistanceChunks);
            CloneMCGameSettings_Save(&app.settings,CLONEMC_SETTINGS_FILE);
        }
        if(app.editingSign)CloneMCPlatform_ProcessSignInput(&app);
        if (app.guiIngame.chatOpen)
            CloneMCPlatform_ProcessChatInput(&app);
        /* Consume a key-return fallback for keyboards/drivers that do not emit
         * WM_CHAR for Return while the OpenGL window owns focus. */
        if (app.guiIngame.chatOpen &&
            CloneMCInput_ConsumeKeyPress(&app.input, VK_RETURN))
            CloneMCPlatform_SubmitChat(&app);
        if (!app.guiIngame.pauseMenu && !app.guiIngame.chatOpen &&
            CloneMCInput_ConsumeKeyPress(&app.input,
                app.settings.keyCodes[7])) {
            if (app.guiIngame.inventoryOpen) { CloneMCPlatform_CloseInventory(&app); }
            else {
                if(app.gameplay&&app.gameplay->player.gameMode==CLONEMC_J_GAMEMODE_CREATIVE)
                    CloneMCPlatform_OpenCreativeInventory(&app);
                else {
                    if(app.gameplay){app.gameplay->openVehicleInventoryId=0;
                        CloneMCJ_Gameplay_OpenPlayerContainer(app.gameplay);}
                    app.guiIngame.inventoryOpen=1;app.guiIngame.creativeInventoryOpen=0;
                }
                CloneMCPlatform_UnlockAchievement(&app,0);
            }
            CloneMCInput_ConsumeMousePress(&app.input, 0);
            CloneMCInput_ConsumeMousePress(&app.input, 1);
            CloneMCMouseHelper_SetGrabbed(&app.mouse,app.guiIngame.inventoryOpen?0:1);
        }
        CloneMCPlatform_UpdateGuiCursor(&app);
        if (app.guiIngame.inventoryOpen) {
            if (CloneMCInput_ConsumeMousePress(&app.input, 0)) {
                CloneMCPlatform_HandleInventoryClick(&app, 0);
            }
            if (CloneMCInput_ConsumeMousePress(&app.input, 1)) {
                CloneMCPlatform_HandleInventoryClick(&app, 1);
            }
        }
        guiBlocksInput = app.guiIngame.inventoryOpen ||
            app.guiIngame.pauseMenu || app.guiIngame.chatOpen ||
            app.editingSign!=0||CloneMCJ_GuiWinGame_IsActiveNative();
        /* Minecraft's in-game function keys are runtime state, not persisted
         * options.  Keep their ownership in GameSettings exactly as the Java
         * client does, and defer F2 until the completely composed back buffer
         * is available immediately before SwapBuffers. */
        if(CloneMCInput_ConsumeKeyPress(&app.input,VK_F1))
            app.settings.hideGUI=!app.settings.hideGUI;
        if(CloneMCInput_ConsumeKeyPress(&app.input,VK_F2))
            app.screenshotRequested=1;
        if(CloneMCInput_ConsumeKeyPress(&app.input,VK_F3)){
            app.settings.showDebugInfo=!app.settings.showDebugInfo;
            app.guiIngame.showDebugInfo=app.settings.showDebugInfo;
        }
        if(!guiBlocksInput&&CloneMCInput_ConsumeKeyPress(&app.input,VK_F5))
            app.settings.thirdPersonView=!app.settings.thirdPersonView;
        CloneMCPlatform_ToggleFlightFromForwardTap(&app,guiBlocksInput);
        CloneMCMouseHelper_Update(&app.mouse, app.listener.active && app.listener.focused && !guiBlocksInput);
        CloneMCMouseHelper_ConsumeDelta(&app.mouse, &mouseDeltaX, &mouseDeltaY);
        if(!guiBlocksInput){
            lookScale=app.settings.mouseSensitivity*0.6F+0.2F;
            lookScale=lookScale*lookScale*lookScale*8.0F*0.15F;
            CloneMCJ_Gameplay_AddLook(app.gameplay,mouseDeltaX*lookScale,
                mouseDeltaY*lookScale*(app.settings.invertMouse?-1.0F:1.0F));
        }
        if(app.guiIngame.creativeInventoryOpen){
            int wheel,pageCount;wheel=CloneMCInput_ConsumeWheel(&app.input);
            pageCount=(app.guiIngame.creativeCatalogCount+CLONEMC_GUI_CREATIVE_PAGE_SIZE-1)/
                CLONEMC_GUI_CREATIVE_PAGE_SIZE;if(pageCount<1)pageCount=1;
            if(wheel>0&&app.guiIngame.creativePage>0)--app.guiIngame.creativePage;
            else if(wheel<0&&app.guiIngame.creativePage+1<pageCount)++app.guiIngame.creativePage;
        }
        if (!guiBlocksInput) {
            int hotbarKey;
            int previousHotbarSlot;
            previousHotbarSlot=app.gameplay->player.inventory.currentItem;
            CloneMCJ_InventoryPlayer_ChangeCurrentItem(&app.gameplay->player.inventory,
                CloneMCInput_ConsumeWheel(&app.input));
            for(hotbarKey=0;hotbarKey<9;++hotbarKey){
                if(CloneMCInput_ConsumeKeyPress(&app.input,'1'+hotbarKey)||
                   CloneMCInput_ConsumeKeyPress(&app.input,VK_NUMPAD1+hotbarKey)){
                    app.gameplay->player.inventory.currentItem=hotbarKey;
                    break;
                }
            }
            if(previousHotbarSlot!=app.gameplay->player.inventory.currentItem){
                app.gameplay->player.inventory.inventoryChanged=1;
                if(app.multiplayerMode&&
                   !CloneMCPlayerControllerMP_SyncHeldItem(&app.multiplayerController,
                        app.gameplay)){
                    app.gameplay->player.inventory.currentItem=previousHotbarSlot;
                    app.gameplay->player.inventory.inventoryChanged=1;
                }
            }
        } else { CloneMCInput_ConsumeWheel(&app.input); }
        if (!guiBlocksInput&&CloneMCInput_ConsumeKeyPress(&app.input,
                app.settings.keyCodes[6])){
            if(CloneMCJ_Gameplay_DropCurrentItem(app.gameplay,0))
                CloneMCJ_StatFileWriter_AddNative(&app.netClientHandler.statistics,2011,1);
        }
        CloneMCJ_Gameplay_SetInput(app.gameplay,
            guiBlocksInput?0.0F:
            (CloneMCInput_IsKeyDown(&app.input,app.settings.keyCodes[1]) ? 1.0F : 0.0F) -
            (CloneMCInput_IsKeyDown(&app.input,app.settings.keyCodes[3]) ? 1.0F : 0.0F),
            guiBlocksInput?0.0F:
            (CloneMCInput_IsKeyDown(&app.input,app.settings.keyCodes[0]) ? 1.0F : 0.0F) -
            (CloneMCInput_IsKeyDown(&app.input,app.settings.keyCodes[2]) ? 1.0F : 0.0F),
            !guiBlocksInput&&CloneMCInput_IsKeyDown(&app.input,app.settings.keyCodes[4]),
            !guiBlocksInput&&CloneMCInput_IsKeyDown(&app.input,app.settings.keyCodes[5]),
            !guiBlocksInput&&app.input.mouseDown[0],
            !guiBlocksInput&&app.input.mouseDown[1]);
        CloneMCPlatform_SetRuntimePhase(191U,"fixed-step timer update");
        CloneMCTimer_Update(&app.timer);
        for (tick = 0; tick < app.timer.elapsedTicks; tick++) {
            app.gameTicks++;
            app.ticksThisSecond++;
            if(app.gameplay&&app.gameplay->endCreditsRequested){
                app.gameplay->endCreditsRequested=0;
                app.guiIngame.inventoryOpen=0;
                app.guiIngame.pauseMenu=0;
                app.guiIngame.chatOpen=0;
                CloneMCJ_GuiWinGame_StartNative(app.username);
                CloneMCMouseHelper_SetGrabbed(&app.mouse,0);
            }
            if(CloneMCJ_GuiWinGame_IsActiveNative()){
                if(!CloneMCJ_GuiWinGame_UpdateNative(
                    app.guiIngame.scaledHeight))
                    CloneMCMouseHelper_SetGrabbed(&app.mouse,1);
                CloneMCJ_GuiIngame_UpdateTick(&app.guiIngame);
                continue;
            }
            if (app.multiplayerMode) {
                CloneMCPlatform_SetRuntimePhase(192U,"multiplayer packet pump");
                if (app.networkManager.connected) {
                    CloneMCNetworkManager_Pump(&app.networkManager);
                    CloneMCNetClientHandler_ProcessReadPackets(&app.netClientHandler);
                    CloneMCNetClientHandler_TickAuthoritativeState(&app.netClientHandler);
                    CloneMCNetClientHandler_DrainEvents(&app.netClientHandler);
                }
                if (!app.networkManager.connected && !app.disconnectReported) {
                    const char *reason;
                    reason = app.netClientHandler.disconnectReason[0] ?
                        app.netClientHandler.disconnectReason : app.networkManager.terminationReason;
                    CloneMCJ_GuiIngame_AddChatMessage(&app.guiIngame,
                        reason && reason[0] ? reason : "Disconnected");
                    ++app.metrics.networkDisconnects;
                    app.disconnectReported = 1;
                    CloneMCPlatform_RequestSessionExit(&app,1,0,"Connection lost",
                        reason&&reason[0]?reason:"Disconnected");
                    break;
                }
            }
            if (!app.guiIngame.pauseMenu || app.multiplayerMode) {
                CloneMCPlatform_SetRuntimePhase(193U,"world and entity simulation tick");
                CloneMCJ_World_Tick(app.world);
                ++app.worldRuntimeTicks;
                if(!app.multiplayerMode&&app.mapStorageInitialized)
                    CloneMCJ_ItemMap_TickInventory(&app.mapStorage,app.world,
                        &app.gameplay->player);
                ++app.metrics.simulationTicks;
                if (app.multiplayerMode && app.netClientHandler.loggedIn &&
                    app.netClientHandler.terrainReady && app.networkManager.connected) {
                    CloneMCPlayerControllerMP_Update(&app.multiplayerController, app.gameplay);
                    CloneMCNetClientHandler_SendMovement(&app.netClientHandler,
                        &app.gameplay->player);
                }
                CloneMCPlatform_SetRuntimePhase(194U,"sound and gameplay event service");
                if(app.worldRuntimeTicks>=40UL)
                    CloneMCJ_SoundManager_TickGameplayNative(&app.soundManager,app.gameplay);
                CloneMCPlatform_SetRuntimePhase(195U,"statistics service");
                CloneMCPlatform_StatisticsTick(&app);
            }
            if(app.gameplay&&app.gameplay->endCreditsRequested){
                app.gameplay->endCreditsRequested=0;
                app.guiIngame.inventoryOpen=0;
                app.guiIngame.pauseMenu=0;
                app.guiIngame.chatOpen=0;
                CloneMCJ_GuiWinGame_StartNative(app.username);
                CloneMCMouseHelper_SetGrabbed(&app.mouse,0);
            }
            if(app.gameplay&&app.gameplay->openContainerActive){
                if(CloneMCJ_Gameplay_IsOpenContainerUsable(app.gameplay)){
                    if(!app.guiIngame.inventoryOpen){
                        app.guiIngame.inventoryOpen=1;
                        app.guiIngame.pauseMenu=0;
                        app.guiIngame.hoveredSlot=-1;
                        CloneMCMouseHelper_SetGrabbed(&app.mouse,0);
                    }
                }else{
                    if(app.guiIngame.inventoryOpen)
                        CloneMCPlatform_CloseInventory(&app);
                    else
                        CloneMCJ_Gameplay_CloseOpenContainer(app.gameplay);
                }
            }
            if(app.gameplay&&app.gameplay->openVehicleInventoryId>0){
                if(CloneMCJ_Gameplay_GetOpenVehicleInventory(app.gameplay)){
                    if(!app.guiIngame.inventoryOpen){
                        app.guiIngame.inventoryOpen=1;
                        app.guiIngame.pauseMenu=0;
                        app.guiIngame.hoveredSlot=-1;
                        CloneMCMouseHelper_SetGrabbed(&app.mouse,0);
                    }
                }else{
                    if(app.guiIngame.inventoryOpen)CloneMCPlatform_CloseInventory(&app);
                    app.gameplay->openVehicleInventoryId=0;
                }
            }
            if(app.gameplay){
                CloneMCJ_ItemStack *selectedStack;
                const char *nameKey;
                const char *displayName;
                selectedStack=CloneMCJ_InventoryPlayer_GetCurrent(
                    &app.gameplay->player.inventory);
                if(selectedStack&&!CloneMCJ_ItemStack_IsEmpty(selectedStack)){
                    nameKey=CloneMCJ_ItemStack_GetNameKey(selectedStack);
                    displayName=CloneMCJ_StringTranslate_TranslateNamedKeyNative(nameKey);
                    if(!displayName||!*displayName){
                        static char fallbackItemName[48];
                        sprintf(fallbackItemName,"Unknown item #%d",selectedStack->itemID);
                        displayName=fallbackItemName;
                    }
                    CloneMCJ_GuiIngame_UpdateSelectedItem(&app.guiIngame,
                        app.gameplay->player.inventory.currentItem,
                        selectedStack->itemID,selectedStack->itemDamage,displayName);
                }else CloneMCJ_GuiIngame_UpdateSelectedItem(&app.guiIngame,
                    app.gameplay->player.inventory.currentItem,-1,0,"");
            }
            CloneMCJ_GuiIngame_UpdateTick(&app.guiIngame);
        }
        if(app.gameplay&&app.gameplay->player.health>0)app.respawnRequested=0;
        if(!app.sessionExitRequested&&app.gameplay&&app.gameplay->player.health<=0&&
           !app.respawnRequested){
            if(!app.multiplayerMode)CloneMCJ_Gameplay_HandlePlayerDeath(app.gameplay);
            app.guiIngame.inventoryOpen=0;app.guiIngame.pauseMenu=0;
            gameOverChoice=CloneMCPlatform_RunFrontend(&app,CLONEMC_GUI_SCREEN_GAME_OVER,1);
            CloneMCOpenGL_FormatWindowTitle(&app.glCaps,title,sizeof(title));
            SetWindowTextA(app.window,title);
            if(app.sessionExitRequested){
                /* A networking failure detected by the modal service loop wins. */
            }else if(gameOverChoice==4){
                if(app.multiplayerMode){
                    if(CloneMCPlayerControllerMP_SendRespawn(&app.multiplayerController,
                            app.gameplay->player.dimension))app.respawnRequested=1;
                    else CloneMCPlatform_RequestSessionExit(&app,1,0,"Connection lost",
                        "The respawn request could not be queued.");
                }else CloneMCJ_Gameplay_RespawnPlayer(app.gameplay);
                CloneMCMouseHelper_SetGrabbed(&app.mouse,1);CloneMCTimer_Reset(&app.timer);
            }else if(gameOverChoice==5){
                if(app.multiplayerMode){
                    CloneMCPlatform_RequestSessionExit(&app,0,1,"",
                        "Disconnecting after death; returning to title");
                }else if(CloneMCPlatform_SaveWorldWithLoading(&app)){
                    CloneMCPlatform_RequestSessionExit(&app,0,0,"",
                        "Saving after death completed; returning to title");
                }else{
                    ++app.metrics.saveFailures;
                    app.saveCompletedForExit=0;
                    MessageBoxA(app.window,
                        "The world could not be saved, so CloneMC did not return to the title screen.",
                        "Save failed",MB_OK|MB_ICONERROR);
                }
            }
        }
        if(app.sessionExitRequested)break;
        CloneMCPlatform_SetRuntimePhase(196U,"world presentation state calculation");
        memset(&presentation, 0, sizeof(presentation));
        presentation.partialTick = (float)app.timer.renderPartialTicks;
        presentation.worldTime = app.world->worldTime;
        presentation.renderDistance = app.settings.renderDistance;
        presentation.renderDistanceChunks = app.settings.renderDistanceChunks;
        presentation.fancyGraphics = app.settings.fancyGraphics;
        presentation.ambientOcclusion = app.settings.ambientOcclusion;
        presentation.volumetricClouds = app.settings.volumetricClouds;
        presentation.celestialAngle = CloneMCJ_World_GetCelestialAngle(app.world, presentation.partialTick);
        presentation.rainStrength = CloneMCJ_World_GetRainStrength(app.world, presentation.partialTick);
        presentation.thunderStrength = CloneMCJ_World_GetThunderStrength(app.world, presentation.partialTick);
        presentation.starBrightness = CloneMCJ_World_GetStarBrightness(app.world, presentation.partialTick);
        presentation.skylightSubtracted = CloneMCJ_World_CalculateSkylightSubtracted(app.world, presentation.partialTick);
        CloneMCJ_World_GetSkyColorAt(app.world,
                CloneMCJava_FloorDouble(app.gameplay->player.entity.posX),
                CloneMCJava_FloorDouble(app.gameplay->player.entity.posZ),
                presentation.partialTick,&presentation.skyRed,
                &presentation.skyGreen,&presentation.skyBlue);
        CloneMCJ_World_GetCloudColor(app.world, presentation.partialTick,
            &presentation.cloudRed, &presentation.cloudGreen, &presentation.cloudBlue);
        CloneMCJ_WorldProvider_GetFogColor(presentation.celestialAngle, presentation.partialTick,
            &presentation.fogRed, &presentation.fogGreen, &presentation.fogBlue);
        presentation.hasSunriseColors = CloneMCJ_WorldProvider_CalcSunriseSunsetColors(
            &app.world->worldProvider, presentation.celestialAngle, presentation.partialTick, sunriseColors);
        if (presentation.hasSunriseColors) {
            presentation.sunriseRed = sunriseColors[0];
            presentation.sunriseGreen = sunriseColors[1];
            presentation.sunriseBlue = sunriseColors[2];
            presentation.sunriseAlpha = sunriseColors[3];
        }
        if (app.metrics.renderFrames == 0UL) {
            CloneMCPlatform_LogStartupPhase(18U, "first world frame draw begins");
        }
        if(app.resizeAwaitingPresent)
            CloneMCPlatform_CrashBreadcrumb("post-resize world frame draw begins");
        CloneMCPlatform_SetRuntimePhase(197U,"OpenGL world draw");
        if(app.settings.anaglyph){
            CloneMCRender_DrawPriority8World(&app.renderer,&presentation,app.world,
                &app.gameplay->player,1);
            CloneMCRender_DrawPriority8World(&app.renderer,&presentation,app.world,
                &app.gameplay->player,2);
            glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
        }else CloneMCRender_DrawPriority8World(&app.renderer,&presentation,
            app.world,&app.gameplay->player,0);
        if(app.screenshotRequested){
            char screenshotMessage[MAX_PATH+64];
            screenshotMessage[0]='\0';
            (void)CloneMCJ_ScreenShotHelper_SaveNative(app.listener.width,
                app.listener.height,screenshotMessage,
                (unsigned long)sizeof(screenshotMessage));
            if(screenshotMessage[0]){
                CloneMCJ_GuiIngame_AddChatMessage(&app.guiIngame,
                    screenshotMessage);
                CloneMCPlatform_Log(screenshotMessage);
            }
            app.screenshotRequested=0;
        }
        if(app.resizeAwaitingPresent)
            CloneMCPlatform_CrashBreadcrumb("post-resize world draw completed; SwapBuffers begins");
        CloneMCPlatform_SetRuntimePhase(198U,"OpenGL SwapBuffers presentation");
        if(!SwapBuffers(app.deviceContext)){
            CloneMCPlatform_Log("SwapBuffers failed while presenting a resized world frame.");
            CloneMCPlatform_RequestSessionExit(&app,1,0,"OpenGL presentation failed",
                "The resized frame could not be presented; the world remains available for saving.");
        }else if(app.resizeAwaitingPresent){
            app.resizeAwaitingPresent=0;
            CloneMCPlatform_CrashBreadcrumb("post-resize world frame presented successfully");
        }
        if (app.metrics.renderFrames == 0UL) {
            CloneMCPlatform_LogStartupPhase(19U, "first frame presented successfully; startup complete");
        }
        CloneMCPlatform_SetRuntimePhase(199U,"post-present metrics and frame pacing");
        ++app.metrics.renderFrames;
        app.metrics.meshesRebuilt = app.renderer.renderGlobal.chunksUpdated;
        app.metrics.glErrors = app.renderer.glErrorCount;
        app.metrics.malformedPackets = app.networkManager.malformedPackets;
        if(app.renderer.renderGlobal.meshBytes>app.metrics.meshBytesHighWater)
            app.metrics.meshBytesHighWater=app.renderer.renderGlobal.meshBytes;
        app.metrics.textureBindsIssued=CloneMCGL_GetTextureBindsIssued();
        app.metrics.textureBindsSuppressed=CloneMCGL_GetTextureBindsSuppressed();
        app.framesThisSecond++;

        nowSeconds = CloneMCTimer_NowSeconds();
        if (nowSeconds - app.statisticsStartSeconds >= 1.0) {
            /* Diagnostics are human-scale, not render-scale.  Scanning entity
             * and chunk tables at 500 FPS repeated the same answers hundreds
             * of times.  Sample them once per title/statistics interval while
             * retaining exact cumulative render and tick counters. */
            app.metrics.entityCount=CloneMCPlatform_CountEntities(&app);
            app.metrics.lightingQueueSize=app.world->lightingUpdateCount;
            app.metrics.networkQueueBytes=
                app.networkManager.sendQueueByteLength+
                app.networkManager.receiveLength;
            if(app.multiplayerMode){
                app.metrics.loadedChunkBytes=(unsigned long)
                    CloneMCPlatform_CountClientChunks(app.worldClient)*
                    (unsigned long)sizeof(CloneMCJ_Chunk);
                app.metrics.chunksGenerated=
                    app.netClientHandler.authoritativeChunks;
            }else{
                app.metrics.loadedChunkBytes=(unsigned long)
                    CloneMCJ_World_CountLoadedChunks(app.world)*
                    (unsigned long)sizeof(CloneMCJ_Chunk);
                app.metrics.chunksGenerated=
                    app.world->chunkProvider.chunksGeneratedNew;
            }
            if(app.metrics.loadedChunkBytes>app.metrics.chunkBytesHighWater)
                app.metrics.chunkBytesHighWater=app.metrics.loadedChunkBytes;
            if(app.metrics.networkQueueBytes>app.metrics.networkBytesHighWater)
                app.metrics.networkBytesHighWater=app.metrics.networkQueueBytes;
            app.lastFramesPerSecond = app.framesThisSecond;
            app.lastTicksPerSecond = app.ticksThisSecond;
            app.framesThisSecond = 0;
            app.ticksThisSecond = 0;
            app.statisticsStartSeconds = nowSeconds;
            app.metrics.frameP50Microseconds=
                CloneMCPlatform_FramePercentile(&app.metrics,50UL);
            app.metrics.frameP95Microseconds=
                CloneMCPlatform_FramePercentile(&app.metrics,95UL);
            app.metrics.frameP99Microseconds=
                CloneMCPlatform_FramePercentile(&app.metrics,99UL);
            CloneMCPlatform_UpdateTitle(&app);
        }

        if (app.settings.limitFramerate && targetFrameSeconds > 0.0) {
            remainingSeconds = targetFrameSeconds -
                (CloneMCTimer_NowSeconds() - frameStartSeconds);
            if (remainingSeconds > 0.0)
                CloneMCPlatform_WaitForFrameDeadline(
                    frameStartSeconds + targetFrameSeconds);
        }
        CloneMCPlatform_RecordFrame(&app.metrics,
            CloneMCTimer_NowSeconds()-frameStartSeconds);
        CloneMCPlatform_SetRuntimePhase(190U,"runtime message pump and input");
    }

session_finished:
    if(app.sessionExitRequested&&!app.listener.closeRequested){
        frontendInitialScreen=app.sessionExitShowsError?CLONEMC_GUI_SCREEN_ERROR:
            CLONEMC_GUI_SCREEN_MAIN_MENU;
        if(!CloneMCPlatform_EndSession(&app,app.gracefulDisconnect)){
            app.sessionExitRequested=0;
            app.sessionExitShowsError=0;
            app.gracefulDisconnect=0;
            app.listener.closeRequested=0;
            app.closeAfterSave=0;
            app.guiIngame.pauseMenu=1;
            app.guiIngame.saveFailed=1;
            CloneMCPlatform_CopyText(app.guiIngame.saveStatus,
                sizeof(app.guiIngame.saveStatus),
                app.saveFailureDetail[0]?app.saveFailureDetail:
                "Save failed; the world remains open");
            CloneMCTimer_Reset(&app.timer);
            goto world_loop_resume;
        }
        CloneMCPlatform_LogStartupPhase(20U,app.sessionExitShowsError?
            "session ended after a recoverable error; showing disconnect screen":
            "session saved and released; returning to title menu");
        frontendChoice=CloneMCPlatform_RunFrontend(&app,frontendInitialScreen,0);
        if(frontendChoice!=0){
            app.multiplayerMode=frontendChoice==2?1:0;
            CloneMCPlatform_LogStartupPhase(21U,app.multiplayerMode?
                "new multiplayer session selected":"new singleplayer session selected");
            goto start_world_session;
        }
        app.listener.closeRequested=1;
    }

    app.metrics.frameP50Microseconds=
        CloneMCPlatform_FramePercentile(&app.metrics,50UL);
    app.metrics.frameP95Microseconds=
        CloneMCPlatform_FramePercentile(&app.metrics,95UL);
    app.metrics.frameP99Microseconds=
        CloneMCPlatform_FramePercentile(&app.metrics,99UL);
    sprintf(logLine, "V140.0 shutdown: profile=%s ticks=%lu frames=%lu chunks=%lu meshes=%lu entities=%lu netBytes=%lu malformed=%lu glErrors=%lu frame_us_p50=%lu p95=%lu p99=%lu max=%lu meshHigh=%lu chunkHigh=%lu netHigh=%lu binds=%lu skippedBinds=%lu recvCompactions=%lu batchBuilds=%lu batchCalls=%lu batchedChunks=%lu batchFallbacks=%lu residentSyncs=%lu slotScans=%lu listUploads=%lu listDeferrals=%lu directLists=%lu cpuSkips=%lu frustumTests=%lu frustumSkipped=%lu sortRebuilds=%lu",
        app.performanceProfile.name,
        app.metrics.simulationTicks, app.metrics.renderFrames, app.metrics.chunksGenerated,
        app.metrics.meshesRebuilt, app.metrics.entityCount, app.metrics.networkQueueBytes,
        app.metrics.malformedPackets, app.metrics.glErrors,
        app.metrics.frameP50Microseconds,app.metrics.frameP95Microseconds,
        app.metrics.frameP99Microseconds,app.metrics.frameMaximumMicroseconds,
        app.metrics.meshBytesHighWater,app.metrics.chunkBytesHighWater,
        app.metrics.networkBytesHighWater,app.metrics.textureBindsIssued,
        app.metrics.textureBindsSuppressed,app.networkManager.receiveCompactions,
        app.renderer.renderGlobal.terrainBatchBuilds,
        app.renderer.renderGlobal.terrainBatchCalls,
        app.renderer.renderGlobal.terrainChunkCallsBatched,
        app.renderer.renderGlobal.terrainFallbackDraws,
        app.renderer.renderGlobal.residentSetRebuilds,
        app.renderer.renderGlobal.rendererSlotsScanned,
        app.renderer.renderGlobal.displayListUploads,
        app.renderer.renderGlobal.displayListUploadDeferrals,
        app.renderer.renderGlobal.directChunkListCalls,
        app.renderer.renderGlobal.cpuFallbackDrawsSkipped,
        app.renderer.renderGlobal.frustumTests,
        app.renderer.renderGlobal.frustumTestsSkipped,
        app.renderer.renderGlobal.visibleSortRebuilds);
    CloneMCPlatform_Log(logLine);
    CloneMCPlatform_Destroy(&app);
    return 0;
}
