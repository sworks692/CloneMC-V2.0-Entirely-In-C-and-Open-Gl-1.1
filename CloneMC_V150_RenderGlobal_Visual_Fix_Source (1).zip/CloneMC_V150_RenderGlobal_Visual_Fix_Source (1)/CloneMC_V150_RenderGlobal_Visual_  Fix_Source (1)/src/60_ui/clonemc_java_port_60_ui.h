/*
 * Shared public declarations for Java modules assigned to src/60_ui.
 * 93 class-specific C implementations use this one subsystem header.
 * Detailed Java field/method inventories remain beside the implementation in
 * each same-named class C file, avoiding hundreds of tiny public headers.
 */
#ifndef CLONEMC_JAVA_PORT_60_UI_H
#define CLONEMC_JAVA_PORT_60_UI_H

#include "../00_core/clonemc_java_port_00_core.h"

#ifdef __cplusplus
extern "C" {
#endif

struct CloneMCJ_TileEntityTag;

/* Achievement.java: class, 116 Java lines. */
void CloneMCJ_Achievement_Register(void);
const char *CloneMCJ_Achievement_JavaName(void);
const char *CloneMCJ_Achievement_AssignedFolder(void);
unsigned long CloneMCJ_Achievement_JavaSourceHash32(void);

/* AchievementList.java: class, 69 Java lines. */
void CloneMCJ_AchievementList_Register(void);
const char *CloneMCJ_AchievementList_JavaName(void);
const char *CloneMCJ_AchievementList_AssignedFolder(void);
unsigned long CloneMCJ_AchievementList_JavaSourceHash32(void);

/* AchievementMap.java: class, 45 Java lines. */
void CloneMCJ_AchievementMap_Register(void);
const char *CloneMCJ_AchievementMap_JavaName(void);
const char *CloneMCJ_AchievementMap_AssignedFolder(void);
unsigned long CloneMCJ_AchievementMap_JavaSourceHash32(void);

/* CanvasCrashReport.java: class, 19 Java lines. */
void CloneMCJ_CanvasCrashReport_Register(void);
const char *CloneMCJ_CanvasCrashReport_JavaName(void);
const char *CloneMCJ_CanvasCrashReport_AssignedFolder(void);
unsigned long CloneMCJ_CanvasCrashReport_JavaSourceHash32(void);

/* CanvasMinecraftApplet.java: class, 33 Java lines. */
void CloneMCJ_CanvasMinecraftApplet_Register(void);
const char *CloneMCJ_CanvasMinecraftApplet_JavaName(void);
const char *CloneMCJ_CanvasMinecraftApplet_AssignedFolder(void);
unsigned long CloneMCJ_CanvasMinecraftApplet_JavaSourceHash32(void);

/* CanvasMojangLogo.java: class, 38 Java lines. */
void CloneMCJ_CanvasMojangLogo_Register(void);
const char *CloneMCJ_CanvasMojangLogo_JavaName(void);
const char *CloneMCJ_CanvasMojangLogo_AssignedFolder(void);
unsigned long CloneMCJ_CanvasMojangLogo_JavaSourceHash32(void);

/* ChatAllowedCharacters.java: class, 49 Java lines. */
void CloneMCJ_ChatAllowedCharacters_Register(void);
const char *CloneMCJ_ChatAllowedCharacters_JavaName(void);
const char *CloneMCJ_ChatAllowedCharacters_AssignedFolder(void);
unsigned long CloneMCJ_ChatAllowedCharacters_JavaSourceHash32(void);

/* ChatLine.java: class, 20 Java lines. */
void CloneMCJ_ChatLine_Register(void);
const char *CloneMCJ_ChatLine_JavaName(void);
const char *CloneMCJ_ChatLine_AssignedFolder(void);
unsigned long CloneMCJ_ChatLine_JavaSourceHash32(void);

/* CodecMus.java: class, 32 Java lines. */
void CloneMCJ_CodecMus_Register(void);
const char *CloneMCJ_CodecMus_JavaName(void);
const char *CloneMCJ_CodecMus_AssignedFolder(void);
unsigned long CloneMCJ_CodecMus_JavaSourceHash32(void);

/* EnumOptions.java: enum, 120 Java lines. */
void CloneMCJ_EnumOptions_Register(void);
const char *CloneMCJ_EnumOptions_JavaName(void);
const char *CloneMCJ_EnumOptions_AssignedFolder(void);
unsigned long CloneMCJ_EnumOptions_JavaSourceHash32(void);

/* EnumOptionsMappingHelper.java: class, 46 Java lines. */
void CloneMCJ_EnumOptionsMappingHelper_Register(void);
const char *CloneMCJ_EnumOptionsMappingHelper_JavaName(void);
const char *CloneMCJ_EnumOptionsMappingHelper_AssignedFolder(void);
unsigned long CloneMCJ_EnumOptionsMappingHelper_JavaSourceHash32(void);

/* EnumOS1.java: class, 53 Java lines. */
void CloneMCJ_EnumOS1_Register(void);
const char *CloneMCJ_EnumOS1_JavaName(void);
const char *CloneMCJ_EnumOS1_AssignedFolder(void);
unsigned long CloneMCJ_EnumOS1_JavaSourceHash32(void);

/* EnumOS2.java: enum, 53 Java lines. */
void CloneMCJ_EnumOS2_Register(void);
const char *CloneMCJ_EnumOS2_JavaName(void);
const char *CloneMCJ_EnumOS2_AssignedFolder(void);
unsigned long CloneMCJ_EnumOS2_JavaSourceHash32(void);

/* EnumOSMappingHelper.java: class, 41 Java lines. */
void CloneMCJ_EnumOSMappingHelper_Register(void);
const char *CloneMCJ_EnumOSMappingHelper_JavaName(void);
const char *CloneMCJ_EnumOSMappingHelper_AssignedFolder(void);
unsigned long CloneMCJ_EnumOSMappingHelper_JavaSourceHash32(void);

/* GameSettings.java: class, 495 Java lines. */
void CloneMCJ_GameSettings_Register(void);
const char *CloneMCJ_GameSettings_JavaName(void);
const char *CloneMCJ_GameSettings_AssignedFolder(void);
unsigned long CloneMCJ_GameSettings_JavaSourceHash32(void);

/* GameWindowListener.java: class, 38 Java lines. */
void CloneMCJ_GameWindowListener_Register(void);
const char *CloneMCJ_GameWindowListener_JavaName(void);
const char *CloneMCJ_GameWindowListener_AssignedFolder(void);
unsigned long CloneMCJ_GameWindowListener_JavaSourceHash32(void);

/* Gui.java: class, 130 Java lines. */
void CloneMCJ_Gui_Register(void);
const char *CloneMCJ_Gui_JavaName(void);
const char *CloneMCJ_Gui_AssignedFolder(void);
unsigned long CloneMCJ_Gui_JavaSourceHash32(void);

/* GuiAchievement.java: class, 145 Java lines. */
void CloneMCJ_GuiAchievement_Register(void);
const char *CloneMCJ_GuiAchievement_JavaName(void);
const char *CloneMCJ_GuiAchievement_AssignedFolder(void);
unsigned long CloneMCJ_GuiAchievement_JavaSourceHash32(void);

/* GuiAchievements.java: class, 400 Java lines. */
void CloneMCJ_GuiAchievements_Register(void);
const char *CloneMCJ_GuiAchievements_JavaName(void);
const char *CloneMCJ_GuiAchievements_AssignedFolder(void);
unsigned long CloneMCJ_GuiAchievements_JavaSourceHash32(void);

/* GuiButton.java: class, 98 Java lines. */
void CloneMCJ_GuiButton_Register(void);
const char *CloneMCJ_GuiButton_JavaName(void);
const char *CloneMCJ_GuiButton_AssignedFolder(void);
unsigned long CloneMCJ_GuiButton_JavaSourceHash32(void);

/* GuiChat.java: class, 107 Java lines. */
void CloneMCJ_GuiChat_Register(void);
const char *CloneMCJ_GuiChat_JavaName(void);
const char *CloneMCJ_GuiChat_AssignedFolder(void);
unsigned long CloneMCJ_GuiChat_JavaSourceHash32(void);

/* GuiChest.java: class, 51 Java lines. */
void CloneMCJ_GuiChest_Register(void);
const char *CloneMCJ_GuiChest_JavaName(void);
const char *CloneMCJ_GuiChest_AssignedFolder(void);
unsigned long CloneMCJ_GuiChest_JavaSourceHash32(void);

/* GuiConflictWarning.java: class, 57 Java lines. */
void CloneMCJ_GuiConflictWarning_Register(void);
const char *CloneMCJ_GuiConflictWarning_JavaName(void);
const char *CloneMCJ_GuiConflictWarning_AssignedFolder(void);
unsigned long CloneMCJ_GuiConflictWarning_JavaSourceHash32(void);

/* GuiConnectFailed.java: class, 63 Java lines. */
void CloneMCJ_GuiConnectFailed_Register(void);
const char *CloneMCJ_GuiConnectFailed_JavaName(void);
const char *CloneMCJ_GuiConnectFailed_AssignedFolder(void);
unsigned long CloneMCJ_GuiConnectFailed_JavaSourceHash32(void);

/* GuiConnecting.java: class, 92 Java lines. */
void CloneMCJ_GuiConnecting_Register(void);
const char *CloneMCJ_GuiConnecting_JavaName(void);
const char *CloneMCJ_GuiConnecting_AssignedFolder(void);
unsigned long CloneMCJ_GuiConnecting_JavaSourceHash32(void);

/* GuiContainer.java: class, 217 Java lines. */
void CloneMCJ_GuiContainer_Register(void);
const char *CloneMCJ_GuiContainer_JavaName(void);
const char *CloneMCJ_GuiContainer_AssignedFolder(void);
unsigned long CloneMCJ_GuiContainer_JavaSourceHash32(void);

/* GuiControls.java: class, 91 Java lines. */
void CloneMCJ_GuiControls_Register(void);
const char *CloneMCJ_GuiControls_JavaName(void);
const char *CloneMCJ_GuiControls_AssignedFolder(void);
unsigned long CloneMCJ_GuiControls_JavaSourceHash32(void);

/* GuiCrafting.java: class, 44 Java lines. */
void CloneMCJ_GuiCrafting_Register(void);
const char *CloneMCJ_GuiCrafting_JavaName(void);
const char *CloneMCJ_GuiCrafting_AssignedFolder(void);
unsigned long CloneMCJ_GuiCrafting_JavaSourceHash32(void);

/* GuiCreateWorld.java: class, 171 Java lines. */
void CloneMCJ_GuiCreateWorld_Register(void);
const char *CloneMCJ_GuiCreateWorld_JavaName(void);
const char *CloneMCJ_GuiCreateWorld_AssignedFolder(void);
unsigned long CloneMCJ_GuiCreateWorld_JavaSourceHash32(void);

/* GuiDispenser.java: class, 38 Java lines. */
void CloneMCJ_GuiDispenser_Register(void);
const char *CloneMCJ_GuiDispenser_JavaName(void);
const char *CloneMCJ_GuiDispenser_AssignedFolder(void);
unsigned long CloneMCJ_GuiDispenser_JavaSourceHash32(void);

/* GuiDownloadTerrain.java: class, 59 Java lines. */
void CloneMCJ_GuiDownloadTerrain_Register(void);
const char *CloneMCJ_GuiDownloadTerrain_JavaName(void);
const char *CloneMCJ_GuiDownloadTerrain_AssignedFolder(void);
unsigned long CloneMCJ_GuiDownloadTerrain_JavaSourceHash32(void);

/* GuiEditSign.java: class, 136 Java lines. */
void CloneMCJ_GuiEditSign_Register(void);
const char *CloneMCJ_GuiEditSign_JavaName(void);
const char *CloneMCJ_GuiEditSign_AssignedFolder(void);
unsigned long CloneMCJ_GuiEditSign_JavaSourceHash32(void);

/* GuiErrorScreen.java: class, 52 Java lines. */
void CloneMCJ_GuiErrorScreen_Register(void);
const char *CloneMCJ_GuiErrorScreen_JavaName(void);
const char *CloneMCJ_GuiErrorScreen_AssignedFolder(void);
unsigned long CloneMCJ_GuiErrorScreen_JavaSourceHash32(void);

/* GuiFurnace.java: class, 48 Java lines. */
void CloneMCJ_GuiFurnace_Register(void);
const char *CloneMCJ_GuiFurnace_JavaName(void);
const char *CloneMCJ_GuiFurnace_AssignedFolder(void);
unsigned long CloneMCJ_GuiFurnace_JavaSourceHash32(void);

/* GuiGameOver.java: class, 67 Java lines. */
void CloneMCJ_GuiGameOver_Register(void);
const char *CloneMCJ_GuiGameOver_JavaName(void);
const char *CloneMCJ_GuiGameOver_AssignedFolder(void);
unsigned long CloneMCJ_GuiGameOver_JavaSourceHash32(void);

/* GuiIngame.java: class, 444 Java lines. */
void CloneMCJ_GuiIngame_Register(void);
const char *CloneMCJ_GuiIngame_JavaName(void);
const char *CloneMCJ_GuiIngame_AssignedFolder(void);
unsigned long CloneMCJ_GuiIngame_JavaSourceHash32(void);

/* GuiIngameMenu.java: class, 95 Java lines. */
void CloneMCJ_GuiIngameMenu_Register(void);
const char *CloneMCJ_GuiIngameMenu_JavaName(void);
const char *CloneMCJ_GuiIngameMenu_AssignedFolder(void);
unsigned long CloneMCJ_GuiIngameMenu_JavaSourceHash32(void);

/* GuiInventory.java: class, 98 Java lines. */
void CloneMCJ_GuiInventory_Register(void);
const char *CloneMCJ_GuiInventory_JavaName(void);
const char *CloneMCJ_GuiInventory_AssignedFolder(void);
unsigned long CloneMCJ_GuiInventory_JavaSourceHash32(void);

/* GuiMainMenu.java: class, 153 Java lines. */
void CloneMCJ_GuiMainMenu_Register(void);
const char *CloneMCJ_GuiMainMenu_JavaName(void);
const char *CloneMCJ_GuiMainMenu_AssignedFolder(void);
unsigned long CloneMCJ_GuiMainMenu_JavaSourceHash32(void);

/* GuiMultiplayer.java: class, 135 Java lines. */
void CloneMCJ_GuiMultiplayer_Register(void);
const char *CloneMCJ_GuiMultiplayer_JavaName(void);
const char *CloneMCJ_GuiMultiplayer_AssignedFolder(void);
unsigned long CloneMCJ_GuiMultiplayer_JavaSourceHash32(void);

/* GuiOptions.java: class, 97 Java lines. */
void CloneMCJ_GuiOptions_Register(void);
const char *CloneMCJ_GuiOptions_JavaName(void);
const char *CloneMCJ_GuiOptions_AssignedFolder(void);
unsigned long CloneMCJ_GuiOptions_JavaSourceHash32(void);

/* GuiParticle.java: class, 60 Java lines. */
void CloneMCJ_GuiParticle_Register(void);
const char *CloneMCJ_GuiParticle_JavaName(void);
const char *CloneMCJ_GuiParticle_AssignedFolder(void);
unsigned long CloneMCJ_GuiParticle_JavaSourceHash32(void);

/* GuiRenameWorld.java: class, 97 Java lines. */
void CloneMCJ_GuiRenameWorld_Register(void);
const char *CloneMCJ_GuiRenameWorld_JavaName(void);
const char *CloneMCJ_GuiRenameWorld_AssignedFolder(void);
unsigned long CloneMCJ_GuiRenameWorld_JavaSourceHash32(void);

/* GuiScreen.java: class, 205 Java lines. */
void CloneMCJ_GuiScreen_Register(void);
const char *CloneMCJ_GuiScreen_JavaName(void);
const char *CloneMCJ_GuiScreen_AssignedFolder(void);
unsigned long CloneMCJ_GuiScreen_JavaSourceHash32(void);

/* GuiSelectWorld.java: class, 219 Java lines. */
void CloneMCJ_GuiSelectWorld_Register(void);
const char *CloneMCJ_GuiSelectWorld_JavaName(void);
const char *CloneMCJ_GuiSelectWorld_AssignedFolder(void);
unsigned long CloneMCJ_GuiSelectWorld_JavaSourceHash32(void);

/* GuiSleepMP.java: class, 79 Java lines. */
void CloneMCJ_GuiSleepMP_Register(void);
const char *CloneMCJ_GuiSleepMP_JavaName(void);
const char *CloneMCJ_GuiSleepMP_AssignedFolder(void);
unsigned long CloneMCJ_GuiSleepMP_JavaSourceHash32(void);

/* GuiSlider.java: class, 88 Java lines. */
void CloneMCJ_GuiSlider_Register(void);
const char *CloneMCJ_GuiSlider_JavaName(void);
const char *CloneMCJ_GuiSlider_AssignedFolder(void);
unsigned long CloneMCJ_GuiSlider_JavaSourceHash32(void);

/* GuiSlot.java: class, 362 Java lines. */
void CloneMCJ_GuiSlot_Register(void);
const char *CloneMCJ_GuiSlot_JavaName(void);
const char *CloneMCJ_GuiSlot_AssignedFolder(void);
unsigned long CloneMCJ_GuiSlot_JavaSourceHash32(void);

/* GuiSlotStats.java: class, 227 Java lines. */
void CloneMCJ_GuiSlotStats_Register(void);
const char *CloneMCJ_GuiSlotStats_JavaName(void);
const char *CloneMCJ_GuiSlotStats_AssignedFolder(void);
unsigned long CloneMCJ_GuiSlotStats_JavaSourceHash32(void);

/* GuiSlotStatsBlock.java: class, 104 Java lines. */
void CloneMCJ_GuiSlotStatsBlock_Register(void);
const char *CloneMCJ_GuiSlotStatsBlock_JavaName(void);
const char *CloneMCJ_GuiSlotStatsBlock_AssignedFolder(void);
unsigned long CloneMCJ_GuiSlotStatsBlock_JavaSourceHash32(void);

/* GuiSlotStatsGeneral.java: class, 57 Java lines. */
void CloneMCJ_GuiSlotStatsGeneral_Register(void);
const char *CloneMCJ_GuiSlotStatsGeneral_JavaName(void);
const char *CloneMCJ_GuiSlotStatsGeneral_AssignedFolder(void);
unsigned long CloneMCJ_GuiSlotStatsGeneral_JavaSourceHash32(void);

/* GuiSlotStatsItem.java: class, 104 Java lines. */
void CloneMCJ_GuiSlotStatsItem_Register(void);
const char *CloneMCJ_GuiSlotStatsItem_JavaName(void);
const char *CloneMCJ_GuiSlotStatsItem_AssignedFolder(void);
unsigned long CloneMCJ_GuiSlotStatsItem_JavaSourceHash32(void);

/* GuiSmallButton.java: class, 38 Java lines. */
void CloneMCJ_GuiSmallButton_Register(void);
const char *CloneMCJ_GuiSmallButton_JavaName(void);
const char *CloneMCJ_GuiSmallButton_AssignedFolder(void);
unsigned long CloneMCJ_GuiSmallButton_JavaSourceHash32(void);

/* GuiStats.java: class, 231 Java lines. */
void CloneMCJ_GuiStats_Register(void);
const char *CloneMCJ_GuiStats_JavaName(void);
const char *CloneMCJ_GuiStats_AssignedFolder(void);
unsigned long CloneMCJ_GuiStats_JavaSourceHash32(void);

/* GuiTextField.java: class, 127 Java lines. */
void CloneMCJ_GuiTextField_Register(void);
const char *CloneMCJ_GuiTextField_JavaName(void);
const char *CloneMCJ_GuiTextField_AssignedFolder(void);
unsigned long CloneMCJ_GuiTextField_JavaSourceHash32(void);

/* GuiTexturePacks.java: class, 152 Java lines. */
void CloneMCJ_GuiTexturePacks_Register(void);
const char *CloneMCJ_GuiTexturePacks_JavaName(void);
const char *CloneMCJ_GuiTexturePacks_AssignedFolder(void);
unsigned long CloneMCJ_GuiTexturePacks_JavaSourceHash32(void);

/* GuiTexturePackSlot.java: class, 72 Java lines. */
void CloneMCJ_GuiTexturePackSlot_Register(void);
const char *CloneMCJ_GuiTexturePackSlot_JavaName(void);
const char *CloneMCJ_GuiTexturePackSlot_AssignedFolder(void);
unsigned long CloneMCJ_GuiTexturePackSlot_JavaSourceHash32(void);

/* GuiUnused.java: class, 33 Java lines. */
void CloneMCJ_GuiUnused_Register(void);
const char *CloneMCJ_GuiUnused_JavaName(void);
const char *CloneMCJ_GuiUnused_AssignedFolder(void);
unsigned long CloneMCJ_GuiUnused_JavaSourceHash32(void);

/* GuiVideoSettings.java: class, 88 Java lines. */
void CloneMCJ_GuiVideoSettings_Register(void);
const char *CloneMCJ_GuiVideoSettings_JavaName(void);
const char *CloneMCJ_GuiVideoSettings_AssignedFolder(void);
unsigned long CloneMCJ_GuiVideoSettings_JavaSourceHash32(void);

/* GuiWorldSlot.java: class, 81 Java lines. */
void CloneMCJ_GuiWorldSlot_Register(void);
const char *CloneMCJ_GuiWorldSlot_JavaName(void);
const char *CloneMCJ_GuiWorldSlot_AssignedFolder(void);
unsigned long CloneMCJ_GuiWorldSlot_JavaSourceHash32(void);

/* GuiYesNo.java: class, 51 Java lines. */
void CloneMCJ_GuiYesNo_Register(void);
const char *CloneMCJ_GuiYesNo_JavaName(void);
const char *CloneMCJ_GuiYesNo_AssignedFolder(void);
unsigned long CloneMCJ_GuiYesNo_JavaSourceHash32(void);

/* IProgressUpdate.java: interface, 17 Java lines. */
void CloneMCJ_IProgressUpdate_Register(void);
const char *CloneMCJ_IProgressUpdate_JavaName(void);
const char *CloneMCJ_IProgressUpdate_AssignedFolder(void);
unsigned long CloneMCJ_IProgressUpdate_JavaSourceHash32(void);

/* KeyBinding.java: class, 20 Java lines. */
void CloneMCJ_KeyBinding_Register(void);
const char *CloneMCJ_KeyBinding_JavaName(void);
const char *CloneMCJ_KeyBinding_AssignedFolder(void);
unsigned long CloneMCJ_KeyBinding_JavaSourceHash32(void);

/* LoadingScreenRenderer.java: class, 164 Java lines. */
void CloneMCJ_LoadingScreenRenderer_Register(void);
const char *CloneMCJ_LoadingScreenRenderer_JavaName(void);
const char *CloneMCJ_LoadingScreenRenderer_AssignedFolder(void);
unsigned long CloneMCJ_LoadingScreenRenderer_JavaSourceHash32(void);

/* MinecraftAppletImpl.java: class, 33 Java lines. */
void CloneMCJ_MinecraftAppletImpl_Register(void);
const char *CloneMCJ_MinecraftAppletImpl_JavaName(void);
const char *CloneMCJ_MinecraftAppletImpl_AssignedFolder(void);
unsigned long CloneMCJ_MinecraftAppletImpl_JavaSourceHash32(void);

/* MinecraftImpl.java: class, 32 Java lines. */
void CloneMCJ_MinecraftImpl_Register(void);
const char *CloneMCJ_MinecraftImpl_JavaName(void);
const char *CloneMCJ_MinecraftImpl_AssignedFolder(void);
unsigned long CloneMCJ_MinecraftImpl_JavaSourceHash32(void);

/* MouseHelper.java: class, 62 Java lines. */
void CloneMCJ_MouseHelper_Register(void);
const char *CloneMCJ_MouseHelper_JavaName(void);
const char *CloneMCJ_MouseHelper_AssignedFolder(void);
unsigned long CloneMCJ_MouseHelper_JavaSourceHash32(void);

/* MusInputStream.java: class, 62 Java lines. */
void CloneMCJ_MusInputStream_Register(void);
const char *CloneMCJ_MusInputStream_JavaName(void);
const char *CloneMCJ_MusInputStream_AssignedFolder(void);
unsigned long CloneMCJ_MusInputStream_JavaSourceHash32(void);

/* PanelCrashReport.java: class, 97 Java lines. */
void CloneMCJ_PanelCrashReport_Register(void);
const char *CloneMCJ_PanelCrashReport_JavaName(void);
const char *CloneMCJ_PanelCrashReport_AssignedFolder(void);
unsigned long CloneMCJ_PanelCrashReport_JavaSourceHash32(void);

/* ScaledResolution.java: class, 47 Java lines. */
void CloneMCJ_ScaledResolution_Register(void);
const char *CloneMCJ_ScaledResolution_JavaName(void);
const char *CloneMCJ_ScaledResolution_AssignedFolder(void);
unsigned long CloneMCJ_ScaledResolution_JavaSourceHash32(void);

/* Session.java: class, 60 Java lines. */
void CloneMCJ_Session_Register(void);
const char *CloneMCJ_Session_JavaName(void);
const char *CloneMCJ_Session_AssignedFolder(void);
unsigned long CloneMCJ_Session_JavaSourceHash32(void);

/* SorterStatsBlock.java: class, 73 Java lines. */
void CloneMCJ_SorterStatsBlock_Register(void);
const char *CloneMCJ_SorterStatsBlock_JavaName(void);
const char *CloneMCJ_SorterStatsBlock_AssignedFolder(void);
unsigned long CloneMCJ_SorterStatsBlock_JavaSourceHash32(void);

/* SorterStatsItem.java: class, 73 Java lines. */
void CloneMCJ_SorterStatsItem_Register(void);
const char *CloneMCJ_SorterStatsItem_JavaName(void);
const char *CloneMCJ_SorterStatsItem_AssignedFolder(void);
unsigned long CloneMCJ_SorterStatsItem_JavaSourceHash32(void);

/* SoundManager.java: class, 253 Java lines. */
void CloneMCJ_SoundManager_Register(void);
const char *CloneMCJ_SoundManager_JavaName(void);
const char *CloneMCJ_SoundManager_AssignedFolder(void);
unsigned long CloneMCJ_SoundManager_JavaSourceHash32(void);

/* SoundPool.java: class, 84 Java lines. */
void CloneMCJ_SoundPool_Register(void);
const char *CloneMCJ_SoundPool_JavaName(void);
const char *CloneMCJ_SoundPool_AssignedFolder(void);
unsigned long CloneMCJ_SoundPool_JavaSourceHash32(void);

/* SoundPoolEntry.java: class, 21 Java lines. */
void CloneMCJ_SoundPoolEntry_Register(void);
const char *CloneMCJ_SoundPoolEntry_JavaName(void);
const char *CloneMCJ_SoundPoolEntry_AssignedFolder(void);
unsigned long CloneMCJ_SoundPoolEntry_JavaSourceHash32(void);

/* StatBase.java: class, 92 Java lines. */
void CloneMCJ_StatBase_Register(void);
const char *CloneMCJ_StatBase_JavaName(void);
const char *CloneMCJ_StatBase_AssignedFolder(void);
unsigned long CloneMCJ_StatBase_JavaSourceHash32(void);

/* StatBasic.java: class, 32 Java lines. */
void CloneMCJ_StatBasic_Register(void);
const char *CloneMCJ_StatBasic_JavaName(void);
const char *CloneMCJ_StatBasic_AssignedFolder(void);
unsigned long CloneMCJ_StatBasic_JavaSourceHash32(void);

/* StatCollector.java: class, 31 Java lines. */
void CloneMCJ_StatCollector_Register(void);
const char *CloneMCJ_StatCollector_JavaName(void);
const char *CloneMCJ_StatCollector_AssignedFolder(void);
unsigned long CloneMCJ_StatCollector_JavaSourceHash32(void);

/* StatCrafting.java: class, 27 Java lines. */
void CloneMCJ_StatCrafting_Register(void);
const char *CloneMCJ_StatCrafting_JavaName(void);
const char *CloneMCJ_StatCrafting_AssignedFolder(void);
unsigned long CloneMCJ_StatCrafting_JavaSourceHash32(void);

/* StatFileWriter.java: class, 242 Java lines. */
void CloneMCJ_StatFileWriter_Register(void);
const char *CloneMCJ_StatFileWriter_JavaName(void);
const char *CloneMCJ_StatFileWriter_AssignedFolder(void);
unsigned long CloneMCJ_StatFileWriter_JavaSourceHash32(void);

/* StatList.java: class, 233 Java lines. */
void CloneMCJ_StatList_Register(void);
const char *CloneMCJ_StatList_JavaName(void);
const char *CloneMCJ_StatList_AssignedFolder(void);
unsigned long CloneMCJ_StatList_JavaSourceHash32(void);

/* StatsSyncher.java: class, 288 Java lines. */
void CloneMCJ_StatsSyncher_Register(void);
const char *CloneMCJ_StatsSyncher_JavaName(void);
const char *CloneMCJ_StatsSyncher_AssignedFolder(void);
unsigned long CloneMCJ_StatsSyncher_JavaSourceHash32(void);

/* StatStringFormatKeyInv.java: class, 32 Java lines. */
void CloneMCJ_StatStringFormatKeyInv_Register(void);
const char *CloneMCJ_StatStringFormatKeyInv_JavaName(void);
const char *CloneMCJ_StatStringFormatKeyInv_AssignedFolder(void);
unsigned long CloneMCJ_StatStringFormatKeyInv_JavaSourceHash32(void);

/* StatTypeDistance.java: class, 38 Java lines. */
void CloneMCJ_StatTypeDistance_Register(void);
const char *CloneMCJ_StatTypeDistance_JavaName(void);
const char *CloneMCJ_StatTypeDistance_AssignedFolder(void);
unsigned long CloneMCJ_StatTypeDistance_JavaSourceHash32(void);

/* StatTypeSimple.java: class, 25 Java lines. */
void CloneMCJ_StatTypeSimple_Register(void);
const char *CloneMCJ_StatTypeSimple_JavaName(void);
const char *CloneMCJ_StatTypeSimple_AssignedFolder(void);
unsigned long CloneMCJ_StatTypeSimple_JavaSourceHash32(void);

/* StatTypeTime.java: class, 48 Java lines. */
void CloneMCJ_StatTypeTime_Register(void);
const char *CloneMCJ_StatTypeTime_JavaName(void);
const char *CloneMCJ_StatTypeTime_AssignedFolder(void);
unsigned long CloneMCJ_StatTypeTime_JavaSourceHash32(void);

/* StringTranslate.java: class, 52 Java lines. */
void CloneMCJ_StringTranslate_Register(void);
const char *CloneMCJ_StringTranslate_JavaName(void);
const char *CloneMCJ_StringTranslate_AssignedFolder(void);
unsigned long CloneMCJ_StringTranslate_JavaSourceHash32(void);

/* ThreadCheckHasPaid.java: class, 43 Java lines. */
void CloneMCJ_ThreadCheckHasPaid_Register(void);
const char *CloneMCJ_ThreadCheckHasPaid_JavaName(void);
const char *CloneMCJ_ThreadCheckHasPaid_AssignedFolder(void);
unsigned long CloneMCJ_ThreadCheckHasPaid_JavaSourceHash32(void);

/* ThreadDownloadResources.java: class, 166 Java lines. */
void CloneMCJ_ThreadDownloadResources_Register(void);
const char *CloneMCJ_ThreadDownloadResources_JavaName(void);
const char *CloneMCJ_ThreadDownloadResources_AssignedFolder(void);
unsigned long CloneMCJ_ThreadDownloadResources_JavaSourceHash32(void);

/* ThreadStatSyncherReceive.java: class, 46 Java lines. */
void CloneMCJ_ThreadStatSyncherReceive_Register(void);
const char *CloneMCJ_ThreadStatSyncherReceive_JavaName(void);
const char *CloneMCJ_ThreadStatSyncherReceive_AssignedFolder(void);
unsigned long CloneMCJ_ThreadStatSyncherReceive_JavaSourceHash32(void);

/* ThreadStatSyncherSend.java: class, 41 Java lines. */
void CloneMCJ_ThreadStatSyncherSend_Register(void);
const char *CloneMCJ_ThreadStatSyncherSend_JavaName(void);
const char *CloneMCJ_ThreadStatSyncherSend_AssignedFolder(void);
unsigned long CloneMCJ_ThreadStatSyncherSend_JavaSourceHash32(void);

/* UnexpectedThrowable.java: class, 20 Java lines. */
void CloneMCJ_UnexpectedThrowable_Register(void);
const char *CloneMCJ_UnexpectedThrowable_JavaName(void);
const char *CloneMCJ_UnexpectedThrowable_AssignedFolder(void);
unsigned long CloneMCJ_UnexpectedThrowable_JavaSourceHash32(void);

/* Priority 1: Win32 platform settings, input, focus and lifecycle. */
#define CLONEMC_PLATFORM_KEY_COUNT 256
#define CLONEMC_PLATFORM_MOUSE_BUTTON_COUNT 8
#define CLONEMC_GAME_KEY_BINDING_COUNT 10

typedef enum CloneMCJ_EnumOptionsNativeTag {
    CLONEMC_OPTION_MUSIC = 0,
    CLONEMC_OPTION_SOUND = 1,
    CLONEMC_OPTION_INVERT_MOUSE = 2,
    CLONEMC_OPTION_SENSITIVITY = 3,
    CLONEMC_OPTION_RENDER_DISTANCE = 4,
    CLONEMC_OPTION_VIEW_BOBBING = 5,
    CLONEMC_OPTION_ANAGLYPH = 6,
    CLONEMC_OPTION_ADVANCED_OPENGL = 7,
    CLONEMC_OPTION_FRAMERATE_LIMIT = 8,
    CLONEMC_OPTION_DIFFICULTY = 9,
    CLONEMC_OPTION_GRAPHICS = 10,
    CLONEMC_OPTION_AMBIENT_OCCLUSION = 11,
    CLONEMC_OPTION_GUI_SCALE = 12,
    /* Independent fixed-function fancy-cloud control.  This extension keeps
     * the expensive 3-D path opt-in instead of tying it to chunk graphics. */
    CLONEMC_OPTION_VOLUMETRIC_CLOUDS = 13,
    /* Ordinal 14 was a CloneMC-only Visual Safety option.  It is retained as
     * a rejected legacy identifier so old callers fail safely, but it is not
     * part of Minecraft 1.2.3's option table or Video Settings GUI. */
    CLONEMC_OPTION_VISUAL_SAFETY = 14,
    CLONEMC_OPTION_COUNT = 14
} CloneMCJ_EnumOptionsNative;

typedef struct CloneMCJ_EnumOptionDefinitionTag {
    int ordinal;
    const char *translationKey;
    unsigned char isFloat;
    unsigned char isBoolean;
} CloneMCJ_EnumOptionDefinition;

#define CLONEMC_RENDER_DISTANCE_MIN_CHUNKS 2
#define CLONEMC_RENDER_DISTANCE_MAX_CHUNKS 128
#define CLONEMC_RENDER_DISTANCE_DEFAULT_CHUNKS 8
#define CLONEMC_RENDER_DISTANCE_MAX_RADIUS 8
#define CLONEMC_FRAMERATE_MIN 30
#define CLONEMC_FRAMERATE_MAX 260

typedef struct CloneMCGameSettingsTag {
    int width;
    int height;
    int colorBits;
    int depthBits;
    int fullscreen;
    int renderDistance;
    int renderDistanceChunks;
    /* V141: V135-compatible resident/visible chunk budget ceiling derived
     * from the selected legacy-memory profile.  The slider is a chunk target,
     * not a raw radius.  It is intentionally not persisted so moving the same
     * options.txt does not permanently lower the preferred distance. */
    int renderDistanceMaximumChunks;
    int limitFramerate;
    int targetFramesPerSecond;
    /* Runtime-only presentation policy.  These values are deliberately not
     * persisted: moving options.txt to a faster machine must restore the full
     * slider, while Win95/98 compatibility mode gets a bounded 30..60 FPS
     * range instead of the CPU-saturating unlimited endpoint. */
    int framerateMaximum;
    int framerateUnlimitedAllowed;
    int legacyCompatibility;
    int invertMouse;
    float mouseSensitivity;
    float soundVolume;
    float musicVolume;
    int difficulty;
    int fancyGraphics;
    int ambientOcclusion;
    int volumetricClouds;
    int viewBobbing;
    int anaglyph;
    int advancedOpenGL;
    int guiScale;
    int hideGUI;
    int thirdPersonView;
    int showDebugInfo;
    int smoothCamera;
    /* Retained only so V132 settings structs remain source-compatible.
     * Validation always forces this removed non-Java option to zero. */
    int visualSafety;
    /* V132.3: local survival input preference.  This controls the legacy
     * double-forward gesture only; it is deliberately not a network option
     * and never changes the multiplayer packet stream. */
    int doubleTapSprint;
    char skin[260];
    char lastServer[128];
    int keyCodes[CLONEMC_GAME_KEY_BINDING_COUNT];
} CloneMCGameSettings;

typedef struct CloneMCJ_ScaledResolutionNativeTag {
    int scaledWidth;
    int scaledHeight;
    double scaledWidthExact;
    double scaledHeightExact;
    int scaleFactor;
} CloneMCJ_ScaledResolutionNative;

typedef struct CloneMCJ_SessionNativeTag {
    char username[64];
    char sessionId[128];
    char mpPassParameter[128];
} CloneMCJ_SessionNative;

typedef struct CloneMCWindowListenerStateTag {
    int closeRequested;
    int active;
    int focused;
    int minimized;
    int width;
    int height;
} CloneMCWindowListenerState;

typedef struct CloneMCInputStateTag {
    unsigned char keyDown[CLONEMC_PLATFORM_KEY_COUNT];
    unsigned char keyPressed[CLONEMC_PLATFORM_KEY_COUNT];
    unsigned char mouseDown[CLONEMC_PLATFORM_MOUSE_BUTTON_COUNT];
    unsigned char mousePressed[CLONEMC_PLATFORM_MOUSE_BUTTON_COUNT];
    int mouseWheel;
    char typedCharacters[32];
    int typedCharacterCount;
} CloneMCInputState;

typedef struct CloneMCMouseHelperStateTag {
    void *windowHandle;
    int grabbed;
    int deltaX;
    int deltaY;
    int centerX;
    int centerY;
} CloneMCMouseHelperState;

typedef struct CloneMCKeyBindingStateTag {
    char description[64];
    int virtualKey;
    int pressed;
    int pressCount;
} CloneMCKeyBindingState;

/* Priority 9: Java GuiIngame and Win32-safe audio presentation state. */
#define CLONEMC_GUI_CHAT_LINES 10
#define CLONEMC_SOUND_POOL_CAPACITY 160
#define CLONEMC_SOUND_EFFECT_CHANNELS 8
#define CLONEMC_SOUND_MOB_SLOTS 64
#define CLONEMC_GUI_MAX_BUTTONS 24
#define CLONEMC_GUI_MAX_WORLDS 16
#define CLONEMC_GUI_CREATIVE_CAPACITY 384
#define CLONEMC_GUI_CREATIVE_PAGE_SIZE 45

enum CloneMCJ_GuiScreenType {
    CLONEMC_GUI_SCREEN_NONE = 0,
    CLONEMC_GUI_SCREEN_MAIN_MENU = 1,
    CLONEMC_GUI_SCREEN_SELECT_WORLD = 2,
    CLONEMC_GUI_SCREEN_MULTIPLAYER = 3,
    CLONEMC_GUI_SCREEN_OPTIONS = 4,
    CLONEMC_GUI_SCREEN_VIDEO = 5,
    CLONEMC_GUI_SCREEN_CONTROLS = 6,
    CLONEMC_GUI_SCREEN_TEXTURE_PACKS = 7,
    CLONEMC_GUI_SCREEN_CONNECTING = 8,
    CLONEMC_GUI_SCREEN_ERROR = 9,
    CLONEMC_GUI_SCREEN_YES_NO = 10,
    CLONEMC_GUI_SCREEN_ACHIEVEMENTS = 11,
    CLONEMC_GUI_SCREEN_STATS = 12,
    CLONEMC_GUI_SCREEN_CREATE_WORLD = 13,
    CLONEMC_GUI_SCREEN_RENAME_WORLD = 14,
    CLONEMC_GUI_SCREEN_GAME_OVER = 15,
    CLONEMC_GUI_SCREEN_DOWNLOAD_TERRAIN = 16,
    CLONEMC_GUI_SCREEN_SLEEP = 17,
    CLONEMC_GUI_SCREEN_CONFLICT = 18
};

typedef struct CloneMCJ_GuiButtonNativeTag {
    int id;
    int xPosition, yPosition, width, height;
    int enabled, visible, hovered;
    int optionOrdinal;
    int slider, dragging;
    float sliderValue;
    char displayString[72];
} CloneMCJ_GuiButtonNative;

typedef struct CloneMCJ_GuiWorldEntryNativeTag {
    char fileName[64];
    char displayName[96];
    CloneMCJLong lastPlayed;
    CloneMCJLong sizeOnDisk;
    unsigned char requiresConversion;
} CloneMCJ_GuiWorldEntryNative;


#define CLONEMC_J_ACHIEVEMENT_COUNT 16
typedef struct CloneMCJ_StatFileStateTag CloneMCJ_StatFileState;
#define CLONEMC_J_ACHIEVEMENT_STAT_BASE 0x500000
#define CLONEMC_J_STAT_MINE_BLOCK_BASE 0x1000000
#define CLONEMC_J_STAT_CRAFT_ITEM_BASE 0x1010000
#define CLONEMC_J_STAT_USE_ITEM_BASE 0x1020000
#define CLONEMC_J_STAT_BREAK_ITEM_BASE 0x1030000
#define CLONEMC_GUI_STATS_VISIBLE_ROWS 12
#define CLONEMC_GUI_STATS_CAPACITY 128

typedef struct CloneMCJ_AchievementDefinitionTag {
    int statId;
    const char *key;
    const char *title;
    const char *description;
    int displayColumn, displayRow;
    int parentIndex;
    int itemID;
    unsigned char isSpecial;
} CloneMCJ_AchievementDefinition;

typedef struct CloneMCJ_StatDefinitionTag {
    int statId;
    const char *name;
    unsigned char category;
    unsigned char distanceValue;
    unsigned char timeValue;
} CloneMCJ_StatDefinition;

typedef struct CloneMCJ_GuiScreenStateTag {
    int screenType, parentType;
    int width, height, scaleFactor;
    int mouseX, mouseY;
    int selectedButton, buttonCount;
    int selectedWorld;
    int textFocused, cursorCounter;
    int keyBindingCapture;
    int createClicked;
    int createGameMode;
    int createAllowCheats;
    int loadingProgress;
    int worldCount, worldScroll;
    unsigned long lastWorldClickCounter;
    unsigned long updateCounter;
    double achievementScrollX, achievementScrollY;
    double achievementPreviousX, achievementPreviousY;
    double achievementTargetX, achievementTargetY;
    int achievementDragging, achievementLastMouseX, achievementLastMouseY;
    unsigned long achievementUnlockedMask, achievementAvailableMask;
    int statsTab, statsScroll, statsSortColumn, statsSortDescending;
    int statsCount;
    int statsIds[CLONEMC_GUI_STATS_CAPACITY];
    int statsValues[CLONEMC_GUI_STATS_CAPACITY];
    char title[72];
    char message[192];
    char textField[128];
    char textFieldSecondary[128];
    char folderName[128];
    CloneMCJ_GuiWorldEntryNative worlds[CLONEMC_GUI_MAX_WORLDS];
    CloneMCJ_GuiButtonNative buttons[CLONEMC_GUI_MAX_BUTTONS];
} CloneMCJ_GuiScreenState;

typedef struct CloneMCJ_LoadingScreenStateTag {
    char title[96];
    char message[192];
    int progress;
    unsigned long lastUpdateMilliseconds;
    unsigned char running;
} CloneMCJ_LoadingScreenState;

typedef struct CloneMCJ_GuiContainerLayoutTag {
    char title[48];
    int xSize,ySize,rows,columns;
    int textureKind;
} CloneMCJ_GuiContainerLayout;

typedef struct CloneMCJ_GuiSlotStateTag {
    int width,height,top,bottom,slotHeight;
    int itemCount,selectedIndex;
    float amountScrolled;
} CloneMCJ_GuiSlotState;

typedef struct CloneMCJ_GuiIngameStateTag {
    unsigned long updateCounter;
    int scaledWidth, scaledHeight, scaleFactor;
    int inventoryOpen, pauseMenu, chatOpen, multiplayerWorld, showDebugInfo;
    int creativeInventoryOpen, creativeTab, creativePage, creativeCatalogCount;
    short creativeItemID[CLONEMC_GUI_CREATIVE_CAPACITY];
    short creativeItemDamage[CLONEMC_GUI_CREATIVE_CAPACITY];
    int savingWorld, saveProgress, saveFailed;
    int signEditorOpen, signEditLine, signEditCounter;
    struct CloneMCJ_TileEntityTag *editingSign;
    int mouseX, mouseY, hoveredSlot;
    int recordPlayingUpFor;
    int selectedItemUpFor, lastSelectedSlot, lastSelectedItemId, lastSelectedDamage;
    char recordPlaying[96];
    char selectedItemName[96];
    char saveStatus[96];
    char chatInput[101];
    char chat[CLONEMC_GUI_CHAT_LINES][128];
    unsigned short chatAge[CLONEMC_GUI_CHAT_LINES];
    int chatCount;
} CloneMCJ_GuiIngameState;

typedef struct CloneMCJ_SoundPoolEntryNativeTag {
    char name[48];
    char path[160];
    unsigned char streaming;
} CloneMCJ_SoundPoolEntryNative;

typedef struct CloneMCJ_SoundManagerStateTag {
    CloneMCJ_SoundPoolEntryNative entries[CLONEMC_SOUND_POOL_CAPACITY];
    int entryCount, initialized, soundAvailable, musicOpen, effectOpen;
    int legacySafeMode;
    unsigned char effectChannels[CLONEMC_SOUND_EFFECT_CHANNELS];
    unsigned char effectPriority[CLONEMC_SOUND_EFFECT_CHANNELS];
    unsigned long effectStartedTick[CLONEMC_SOUND_EFFECT_CHANNELS];
    float effectAudible[CLONEMC_SOUND_EFFECT_CHANNELS];
    char effectNames[CLONEMC_SOUND_EFFECT_CHANNELS][48];
    int effectNext, recordChannel, ticksBeforeMusic, currentMusic;
    int previousPlayerHealth, playerHealthKnown;
    int previousMobHealth[CLONEMC_SOUND_MOB_SLOTS];
    int mobTalkCounter[CLONEMC_SOUND_MOB_SLOTS];
    unsigned char previousMobActive[CLONEMC_SOUND_MOB_SLOTS];
    unsigned long tickCount, soundsPlayed, soundFailures, soundsCulled;
    unsigned long soundsDuplicateSuppressed, soundsPriorityRejected;
    unsigned long previousItemsPickedUp, previousBlocksMined, previousBlocksPlaced;
    unsigned long lastBlockBreakEventSequence;
    unsigned long lastExplosionEventSequence;
    unsigned long lastGameplayAudioEventSequence;
    int previousGhastAttackCounter[CLONEMC_SOUND_MOB_SLOTS];
    unsigned long previousBlocksActivated;
    unsigned char previousContainerActive;
    int previousContainerType, previousContainerX, previousContainerY, previousContainerZ;
    float soundVolume, musicVolume;
    double listenerX, listenerY, listenerZ;
    float listenerYaw;
    double previousPlayerX, previousPlayerZ, walkDistance;
    void *audioBackend;
    CloneMCJavaRandom random;
} CloneMCJ_SoundManagerState;

struct CloneMCJ_EntityPlayerTag;
struct CloneMCJ_GameplayStateTag;

void CloneMCJ_GuiIngame_Initialize(CloneMCJ_GuiIngameState *);
void CloneMCJ_GuiIngame_UpdateTick(CloneMCJ_GuiIngameState *);
void CloneMCJ_GuiIngame_UpdateResolution(CloneMCJ_GuiIngameState *, int, int);
void CloneMCJ_GuiIngame_UpdateResolutionWithScale(CloneMCJ_GuiIngameState *, int, int, int);
void CloneMCJ_GuiIngame_AddChatMessage(CloneMCJ_GuiIngameState *, const char *);
void CloneMCJ_GuiIngame_SetRecordPlaying(CloneMCJ_GuiIngameState *, const char *);
void CloneMCJ_GuiIngame_UpdateSelectedItem(CloneMCJ_GuiIngameState *, int, int, int, const char *);
int CloneMCJ_GuiWinGame_StartNative(const char *);
int CloneMCJ_GuiWinGame_UpdateNative(int);
void CloneMCJ_GuiWinGame_FinishNative(void);
int CloneMCJ_GuiWinGame_IsActiveNative(void);
unsigned long CloneMCJ_GuiWinGame_GetTicksNative(void);
int CloneMCJ_GuiWinGame_GetLineCountNative(void);
const char *CloneMCJ_GuiWinGame_GetLineNative(int, int *);
int CloneMCJ_GuiWinGame_GetTotalHeightNative(void);

void CloneMCJ_GuiButton_InitializeNative(CloneMCJ_GuiButtonNative *, int, int, int,
    int, int, const char *);
int CloneMCJ_GuiButton_MousePressedNative(CloneMCJ_GuiButtonNative *, int, int);
void CloneMCJ_GuiScreen_InitializeNative(CloneMCJ_GuiScreenState *, int, int, int);
void CloneMCJ_GuiScreen_SetResolutionNative(CloneMCJ_GuiScreenState *, int, int, int);
CloneMCJ_GuiButtonNative *CloneMCJ_GuiScreen_AddButtonNative(CloneMCJ_GuiScreenState *,
    int, int, int, int, int, const char *);
int CloneMCJ_GuiScreen_MouseClickedNative(CloneMCJ_GuiScreenState *, int, int);
void CloneMCJ_GuiScreen_ReleaseMouseNative(CloneMCJ_GuiScreenState *);
int CloneMCJ_GuiScreen_KeyTypedNative(CloneMCJ_GuiScreenState *, int);
int CloneMCJ_GuiScreen_ValidateNative(CloneMCJ_GuiScreenState *);
void CloneMCJ_GuiMainMenu_InitNative(CloneMCJ_GuiScreenState *);
void CloneMCJ_GuiSelectWorld_InitNative(CloneMCJ_GuiScreenState *);
int CloneMCJ_GuiSelectWorld_LoadNative(CloneMCJ_GuiScreenState *, const char *);
int CloneMCJ_GuiSelectWorld_SelectNative(CloneMCJ_GuiScreenState *, int);
int CloneMCJ_GuiSelectWorld_ScrollNative(CloneMCJ_GuiScreenState *, int);
void CloneMCJ_GuiMultiplayer_InitNative(CloneMCJ_GuiScreenState *, const char *,
    const char *);
void CloneMCJ_GuiOptions_InitNative(CloneMCJ_GuiScreenState *, const CloneMCGameSettings *);
void CloneMCJ_GuiVideoSettings_InitNative(CloneMCJ_GuiScreenState *, const CloneMCGameSettings *);
void CloneMCJ_GuiControls_InitNative(CloneMCJ_GuiScreenState *,
    const CloneMCGameSettings *);
void CloneMCJ_GuiTexturePacks_InitNative(CloneMCJ_GuiScreenState *);
void CloneMCTexturePacks_Initialize(const char *);
int CloneMCTexturePacks_Refresh(void);
int CloneMCTexturePacks_GetCount(void);
const char *CloneMCTexturePacks_GetName(int);
const char *CloneMCTexturePacks_GetDescription(int);
const char *CloneMCTexturePacks_GetSelectedName(void);
const char *CloneMCTexturePacks_GetSelectedPath(void);
int CloneMCTexturePacks_Select(int);
int CloneMCTexturePack_LoadRGBA(const char *,unsigned char **,int *,int *);
int CloneMCTexture_LoadLocalRGBA(const char *,unsigned char **,int *,int *);
int CloneMCTexturePack_ReadEntryFromFile(const char *,const char *,
    unsigned char **,unsigned long *);
int CloneMCTexturePack_ReadMetadata(const char *,char *,unsigned int,
    char *,unsigned int);
int CloneMCTexturePack_IsArchive(const char *);
int CloneMCTexturePack_RunSelfTests(char *,unsigned int);
void CloneMCJ_GuiErrorScreen_InitNative(CloneMCJ_GuiScreenState *, const char *, const char *);
void CloneMCJ_GuiAchievements_InitNative(CloneMCJ_GuiScreenState *);
void CloneMCJ_GuiAchievements_SetStatsNative(CloneMCJ_GuiScreenState *, const CloneMCJ_StatFileState *);
void CloneMCJ_GuiAchievements_UpdateNative(CloneMCJ_GuiScreenState *);
void CloneMCJ_GuiAchievements_DragNative(CloneMCJ_GuiScreenState *, int, int, int);
void CloneMCJ_GuiStats_InitNative(CloneMCJ_GuiScreenState *);
void CloneMCJ_GuiStats_SetStatsNative(CloneMCJ_GuiScreenState *, const CloneMCJ_StatFileState *);
void CloneMCJ_GuiStats_SelectTabNative(CloneMCJ_GuiScreenState *, int);
void CloneMCJ_GuiStats_ScrollNative(CloneMCJ_GuiScreenState *, int);
const CloneMCJ_AchievementDefinition *CloneMCJ_AchievementList_GetNative(int);
int CloneMCJ_AchievementList_CountNative(void);
int CloneMCJ_Achievement_IsUnlockedNative(const CloneMCJ_StatFileState *, int);
int CloneMCJ_Achievement_CanUnlockNative(const CloneMCJ_StatFileState *, int);
int CloneMCJ_Achievement_UnlockNative(CloneMCJ_StatFileState *, int);
const CloneMCJ_StatDefinition *CloneMCJ_StatList_GetGeneralNative(int);
int CloneMCJ_StatList_GeneralCountNative(void);
const char *CloneMCJ_StatList_NameNative(int, char *, unsigned long);
void CloneMCJ_StatList_FormatValueNative(int, int, char *, unsigned long);
void CloneMCJ_GuiCreateWorld_InitNative(CloneMCJ_GuiScreenState *, int);
int CloneMCJ_GuiCreateWorld_UpdateFolderNative(CloneMCJ_GuiScreenState *, const char *);
void CloneMCJ_GuiCreateWorld_SelectNextFieldNative(CloneMCJ_GuiScreenState *);
int CloneMCJ_GuiCreateWorld_CycleGameModeNative(CloneMCJ_GuiScreenState *);
int CloneMCJ_GuiCreateWorld_ToggleCheatsNative(CloneMCJ_GuiScreenState *);
CloneMCJLong CloneMCJ_GuiCreateWorld_ResolveSeedNative(
    const CloneMCJ_GuiScreenState *, CloneMCJLong);
void CloneMCJ_GuiRenameWorld_InitNative(CloneMCJ_GuiScreenState *, const char *);
void CloneMCJ_GuiYesNo_InitNative(CloneMCJ_GuiScreenState *, const char *, const char *);
void CloneMCJ_GuiGameOver_InitNative(CloneMCJ_GuiScreenState *, int);
void CloneMCJ_GuiDownloadTerrain_InitNative(CloneMCJ_GuiScreenState *);
void CloneMCJ_GuiSleepMP_InitNative(CloneMCJ_GuiScreenState *);
void CloneMCJ_GuiConflictWarning_InitNative(CloneMCJ_GuiScreenState *, const char *);
void CloneMCJ_GuiIngameMenu_InitNative(CloneMCJ_GuiScreenState *, int);
void CloneMCJ_GuiConnecting_InitNative(CloneMCJ_GuiScreenState *, const char *);
void CloneMCJ_GuiConnectFailed_InitNative(CloneMCJ_GuiScreenState *, const char *);
void CloneMCJ_GuiTextField_SetTextNative(CloneMCJ_GuiScreenState *, const char *);
int CloneMCJ_GuiTextField_KeyNative(CloneMCJ_GuiScreenState *, int);
void CloneMCJ_GuiSmallButton_InitializeNative(CloneMCJ_GuiButtonNative *, int, int, int, const char *);
void CloneMCJ_GuiSlider_SetNative(CloneMCJ_GuiButtonNative *, float *, float);
void CloneMCJ_GuiWorldSlot_InitializeNative(CloneMCJ_GuiButtonNative *, int, int, int,
    int, const char *);
void CloneMCJ_GuiInventory_SetOpenNative(CloneMCJ_GuiIngameState *, int);
int CloneMCJ_GuiContainer_SlotAtNative(int, int, int, int, int, int, int);
int CloneMCJ_GuiChat_EditNative(char *, unsigned long, int);
void CloneMCJ_Gui_ColorNative(unsigned long, float *, float *, float *, float *);
void CloneMCJ_GuiAchievement_QueueNative(CloneMCJ_GuiIngameState *, const char *, const char *);
void CloneMCJ_GuiChest_LayoutNative(CloneMCJ_GuiContainerLayout *, int);
void CloneMCJ_GuiCrafting_LayoutNative(CloneMCJ_GuiContainerLayout *);
void CloneMCJ_GuiDispenser_LayoutNative(CloneMCJ_GuiContainerLayout *);
void CloneMCJ_GuiFurnace_LayoutNative(CloneMCJ_GuiContainerLayout *);
int CloneMCJ_GuiEditSign_KeyNative(char [4][16], int *, int, int);
int CloneMCJ_GuiEditSign_KeyTileNative(struct CloneMCJ_TileEntityTag *, int *, int, int);
unsigned long CloneMCJ_GuiParticle_UpdateNative(unsigned long, float *, float *);
void CloneMCJ_GuiSlot_InitializeNative(CloneMCJ_GuiSlotState *, int, int, int, int, int, int);
void CloneMCJ_GuiSlot_ScrollNative(CloneMCJ_GuiSlotState *, int);
int CloneMCJ_GuiSlot_IndexAtNative(const CloneMCJ_GuiSlotState *, int, int);
void CloneMCJ_GuiSlotStats_SortNative(int *, int *, int);
const char *CloneMCJ_GuiSlotStatsBlock_LabelNative(int);
const char *CloneMCJ_GuiSlotStatsItem_LabelNative(int);
void CloneMCJ_GuiSlotStatsGeneral_FormatNative(const char *, int, char *, unsigned long);
void CloneMCJ_GuiTexturePackSlot_InitializeNative(CloneMCJ_GuiButtonNative *, int,
    int, int, const char *);
void CloneMCJ_GuiUnused_InitNative(CloneMCJ_GuiScreenState *, const char *, const char *);
int CloneMCJ_GuiOptions_ActivateNative(CloneMCJ_GuiScreenState *, CloneMCGameSettings *, int);
int CloneMCJ_GuiVideoSettings_ActivateNative(CloneMCJ_GuiScreenState *, CloneMCGameSettings *, int);
int CloneMCJ_GuiOptions_DragSliderNative(CloneMCJ_GuiScreenState *, CloneMCGameSettings *);
int CloneMCJ_GuiControls_ActivateNative(CloneMCJ_GuiScreenState *, CloneMCGameSettings *, int);
int CloneMCJ_GuiControls_KeyNative(CloneMCJ_GuiScreenState *, CloneMCGameSettings *, int);
void CloneMCJ_LoadingScreenRenderer_InitializeNative(CloneMCJ_LoadingScreenState *);
void CloneMCJ_LoadingScreenRenderer_PrintTextNative(CloneMCJ_LoadingScreenState *,
    CloneMCJ_GuiScreenState *, const char *);
void CloneMCJ_LoadingScreenRenderer_DisplayStringNative(CloneMCJ_LoadingScreenState *,
    CloneMCJ_GuiScreenState *, const char *);
int CloneMCJ_LoadingScreenRenderer_SetProgressNative(CloneMCJ_LoadingScreenState *,
    CloneMCJ_GuiScreenState *, int, unsigned long);

void CloneMCJ_SoundManager_InitializeNative(CloneMCJ_SoundManagerState *,
    const CloneMCGameSettings *);
void CloneMCJ_SoundManager_InitializeNativeWithMode(CloneMCJ_SoundManagerState *,
    const CloneMCGameSettings *, int);
void CloneMCJ_SoundManager_SetLegacySafeMode(CloneMCJ_SoundManagerState *, int);
int CloneMCJ_SoundManager_GetEffectChannelCount(
    const CloneMCJ_SoundManagerState *);
void CloneMCJ_SoundManager_ShutdownNative(CloneMCJ_SoundManagerState *);
int CloneMCJ_SoundManager_PlaySound(CloneMCJ_SoundManagerState *, const char *);
int CloneMCJ_SoundManager_PlaySoundFX(CloneMCJ_SoundManagerState *, const char *,
    float, float);
int CloneMCJ_SoundManager_PlaySoundAt(CloneMCJ_SoundManagerState *, const char *,
    float, float, float, float, float);
int CloneMCJ_SoundManager_PlayStreaming(CloneMCJ_SoundManagerState *, const char *,
    float, float, float, float, float);
void CloneMCJ_SoundManager_TickNative(CloneMCJ_SoundManagerState *,
    const struct CloneMCJ_EntityPlayerTag *);
void CloneMCJ_SoundManager_TickGameplayNative(CloneMCJ_SoundManagerState *,
    const struct CloneMCJ_GameplayStateTag *);
int CloneMCJ_SoundPool_AddNative(CloneMCJ_SoundManagerState *, const char *, const char *, int);
const CloneMCJ_SoundPoolEntryNative *CloneMCJ_SoundPool_GetNative(
    const CloneMCJ_SoundManagerState *, const char *, unsigned long);

/* StatFileWriter.java and J_Json*.java: bounded native stats JSON state. */
#define CLONEMC_STAT_CAPACITY 512
typedef struct CloneMCJ_StatEntryTag {
    int statId;
    int value;
    char guid[33];
} CloneMCJ_StatEntry;

struct CloneMCJ_StatFileStateTag {
    CloneMCJ_StatEntry entries[CLONEMC_STAT_CAPACITY];
    int count;
    int dirty;
    unsigned long jsonErrors;
    char checksum[64];
};

void CloneMCJ_StatFileWriter_InitializeNative(CloneMCJ_StatFileState *);
int CloneMCJ_StatFileWriter_SetNative(CloneMCJ_StatFileState *, int, int);
int CloneMCJ_StatFileWriter_AddNative(CloneMCJ_StatFileState *, int, int);
int CloneMCJ_StatFileWriter_GetNative(const CloneMCJ_StatFileState *, int);
int CloneMCJ_StatFileWriter_ParseJsonNative(CloneMCJ_StatFileState *, const char *);
int CloneMCJ_StatFileWriter_LoadGuidsNative(CloneMCJ_StatFileState *, const char *);
int CloneMCJ_StatFileWriter_ComputeChecksumNative(const CloneMCJ_StatFileState *,
    const char *, char *, unsigned long);
int CloneMCJ_StatFileWriter_ValidateChecksumNative(const CloneMCJ_StatFileState *, const char *);
int CloneMCJ_StatFileWriter_LoadJsonFileNative(CloneMCJ_StatFileState *, const char *,
    const char *, const char *);
int CloneMCJ_StatFileWriter_SaveJsonFileNative(CloneMCJ_StatFileState *, const char *,
    const char *, const char *, const char *);
int CloneMCJ_StatFileWriter_WriteJsonNative(const CloneMCJ_StatFileState *,
    const char *, const char *, const char *, char *, unsigned long);
int CloneMCJ_Priority17_RunSelfTests(char *, unsigned int);
int CloneMCJ_V127_RunSelfTests(char *, unsigned int);

void CloneMCGameSettings_SetDefaults(CloneMCGameSettings *settings);
int CloneMCGameSettings_Load(CloneMCGameSettings *settings, const char *filename);
int CloneMCGameSettings_Save(const CloneMCGameSettings *settings, const char *filename);
void CloneMCGameSettings_ApplyCommandLine(CloneMCGameSettings *settings, const char *commandLine);
void CloneMCGameSettings_SynchronizeDerived(CloneMCGameSettings *);
float CloneMCGameSettings_GetOptionFloat(const CloneMCGameSettings *, int);
int CloneMCGameSettings_SetOptionFloat(CloneMCGameSettings *, int, float);
int CloneMCGameSettings_SetOptionValue(CloneMCGameSettings *, int, int);
void CloneMCGameSettings_FormatOption(const CloneMCGameSettings *, int, char *, unsigned long);
const char *CloneMCGameSettings_GetKeyDescription(int);
void CloneMCGameSettings_FormatKeyName(int, char *, unsigned long);
int CloneMCGameSettings_SetKeyBinding(CloneMCGameSettings *, int, int);
const CloneMCJ_EnumOptionDefinition *CloneMCJ_EnumOptions_GetNative(int);

void CloneMCJ_ScaledResolution_CalculateNative(
    const CloneMCGameSettings *, int, int, CloneMCJ_ScaledResolutionNative *);
int CloneMCJ_ChatAllowedCharacters_IsAllowedNative(int);
int CloneMCJ_ChatAllowedCharacters_IsIllegalFilenameNative(int);
void CloneMCJ_Session_InitializeNative(CloneMCJ_SessionNative *,
    const char *, const char *);
const int *CloneMCJ_Session_GetRegisteredBlocksNative(int *);

int CloneMCJ_StringTranslate_InitializeNative(const char *, const char *);
const char *CloneMCJ_StringTranslate_TranslateKeyNative(const char *);
const char *CloneMCJ_StringTranslate_TranslateNamedKeyNative(const char *);
const char *CloneMCJ_StatCollector_TranslateToLocalNative(const char *);

void CloneMCWindowListener_Initialize(CloneMCWindowListenerState *state, int width, int height);
void CloneMCWindowListener_OnFocus(CloneMCWindowListenerState *state, int active, int focused);
void CloneMCWindowListener_OnResize(CloneMCWindowListenerState *state, int width, int height, int minimized);
void CloneMCWindowListener_RequestClose(CloneMCWindowListenerState *state);

void CloneMCInput_Initialize(CloneMCInputState *input);
void CloneMCInput_SetKey(CloneMCInputState *input, int virtualKey, int down);
int CloneMCInput_IsKeyDown(const CloneMCInputState *input, int virtualKey);
int CloneMCInput_ConsumeKeyPress(CloneMCInputState *input, int virtualKey);
int CloneMCInput_ConsumeAnyKeyPress(CloneMCInputState *input);
void CloneMCInput_SetMouseButton(CloneMCInputState *input, int button, int down);
int CloneMCInput_ConsumeMousePress(CloneMCInputState *input, int button);
void CloneMCInput_AddWheel(CloneMCInputState *input, int amount);
int CloneMCInput_ConsumeWheel(CloneMCInputState *input);
void CloneMCInput_AddCharacter(CloneMCInputState *input, int character);
int CloneMCInput_ConsumeCharacter(CloneMCInputState *input);
void CloneMCInput_Clear(CloneMCInputState *input);

void CloneMCKeyBinding_Initialize(CloneMCKeyBindingState *binding, const char *description, int virtualKey);
void CloneMCKeyBinding_Update(CloneMCKeyBindingState *binding, const CloneMCInputState *input);
int CloneMCKeyBinding_ConsumePress(CloneMCKeyBindingState *binding);

void CloneMCMouseHelper_Initialize(CloneMCMouseHelperState *mouse, void *windowHandle);
void CloneMCMouseHelper_SetGrabbed(CloneMCMouseHelperState *mouse, int grabbed);
void CloneMCMouseHelper_Update(CloneMCMouseHelperState *mouse, int active);
void CloneMCMouseHelper_ConsumeDelta(CloneMCMouseHelperState *mouse, int *deltaX, int *deltaY);
int CloneMCMouseHelper_GetClientPosition(const CloneMCMouseHelperState *mouse, int *x, int *y);

void CloneMCMinecraftAppletImpl_ReportError(const char *message);
int CloneMCPlatform_UseDataRoot(void);
int CloneMCMinecraftImpl_Run(void *instanceHandle, const char *commandLine, int showCommand);

#ifdef __cplusplus
}
#endif

#endif /* CLONEMC_JAVA_PORT_60_UI_H */
