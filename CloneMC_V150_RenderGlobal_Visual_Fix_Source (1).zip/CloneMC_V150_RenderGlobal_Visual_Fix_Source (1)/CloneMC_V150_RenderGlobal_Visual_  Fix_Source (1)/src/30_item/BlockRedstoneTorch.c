/*
 * CloneMC Java port scaffold: BlockRedstoneTorch
 *
 * Java source: BlockRedstoneTorch.java
 * Java type: class BlockRedstoneTorch
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockTorch
 * Implements: (none declared)
 * Source SHA-256: 7fb3404240d4662c00cb9b4bbd14491a00725b820c211340618ae856002657a6
 * Java lines: 230
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: BlockTorch, Block, RedstoneUpdateInfo, World, IBlockAccess, j, k, i, world.notifyBlocksOfNeighborChange
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private boolean torchActive
 *
 * Java method/constructor inventory:
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - private boolean checkForBurnout(World world, int i, int j, int k, boolean flag)
 * - protected BlockRedstoneTorch(int i, int j, boolean flag)
 * - public int tickRate()
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onBlockRemoval(World world, int i, int j, int k)
 * - public boolean isPoweringTo(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - private boolean func_30002_h(World world, int i, int j, int k)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public boolean isIndirectlyPoweringTo(World world, int i, int j, int k, int l)
 * - public int idDropped(int i, Random random)
 * - public boolean canProvidePower()
 * - public void randomDisplayTick(World world, int i, int j, int k, Random random)
 * - private static List torchUpdates = new ArrayList()
 *
 * Priority 11 directly connects redstone-torch neighbor scheduling and active/
 * inactive transitions below.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

#define CLONEMC_J_TORCH_UPDATE_CAPACITY 256
typedef struct CloneMCJ_RedstoneTorchUpdateTag {
    CloneMCJ_World *world;
    int x,y,z;
    CloneMCJLong updateTime;
} CloneMCJ_RedstoneTorchUpdate;

/* BlockRedstoneTorch.java keeps a 100-tick global history and considers the
 * eighth off transition at one location a burnout.  A fixed array preserves
 * that behavior without Java allocation or unbounded growth on Win9x. */
static CloneMCJ_RedstoneTorchUpdate g_cloneMCTorchUpdates[CLONEMC_J_TORCH_UPDATE_CAPACITY];
static int g_cloneMCTorchUpdateCount;

static void CloneMCJ_BlockRedstoneTorch_Prune(CloneMCJ_World *world)
{
    int removeCount,i;
    if(!world)return;
    removeCount=0;
    while(removeCount<g_cloneMCTorchUpdateCount){
        CloneMCJ_RedstoneTorchUpdate *entry=&g_cloneMCTorchUpdates[removeCount];
        if(entry->world==world&&world->worldTime-entry->updateTime<=100)break;
        ++removeCount;
    }
    if(removeCount>0){
        for(i=removeCount;i<g_cloneMCTorchUpdateCount;++i)
            g_cloneMCTorchUpdates[i-removeCount]=g_cloneMCTorchUpdates[i];
        g_cloneMCTorchUpdateCount-=removeCount;
    }
}

static int CloneMCJ_BlockRedstoneTorch_CheckBurnout(CloneMCJ_World *world,
    int x,int y,int z,int add)
{
    int i,count;
    CloneMCJ_BlockRedstoneTorch_Prune(world);
    if(add){
        if(g_cloneMCTorchUpdateCount>=CLONEMC_J_TORCH_UPDATE_CAPACITY){
            for(i=1;i<g_cloneMCTorchUpdateCount;++i)
                g_cloneMCTorchUpdates[i-1]=g_cloneMCTorchUpdates[i];
            --g_cloneMCTorchUpdateCount;
        }
        g_cloneMCTorchUpdates[g_cloneMCTorchUpdateCount].world=world;
        g_cloneMCTorchUpdates[g_cloneMCTorchUpdateCount].x=x;
        g_cloneMCTorchUpdates[g_cloneMCTorchUpdateCount].y=y;
        g_cloneMCTorchUpdates[g_cloneMCTorchUpdateCount].z=z;
        g_cloneMCTorchUpdates[g_cloneMCTorchUpdateCount].updateTime=world->worldTime;
        ++g_cloneMCTorchUpdateCount;
    }
    count=0;
    for(i=0;i<g_cloneMCTorchUpdateCount;++i){
        CloneMCJ_RedstoneTorchUpdate *entry=&g_cloneMCTorchUpdates[i];
        if(entry->world==world&&entry->x==x&&entry->y==y&&entry->z==z&&
           ++count>=8)return 1;
    }
    return 0;
}

/* Java func_30002_h: only the block to which the torch is attached may switch
 * it off.  Querying the torch cell itself feeds the torch's own output back
 * through adjacent conductors and creates the visible on/off instability. */
static int CloneMCJ_BlockRedstoneTorch_SupportPowered(CloneMCJ_World *world,
    int x,int y,int z)
{
    int metadata;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(metadata==5)return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(
        world,x,y-1,z,0);
    if(metadata==3)return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(
        world,x,y,z-1,2);
    if(metadata==4)return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(
        world,x,y,z+1,3);
    if(metadata==1)return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(
        world,x-1,y,z,4);
    if(metadata==2)return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(
        world,x+1,y,z,5);
    return 0;
}

static void CloneMCJ_BlockRedstoneTorch_UpdateTick(CloneMCJ_World *world, int x,
    int y, int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int powered;
    int metadata;
    (void)random; (void)userData;
    if (!world || CloneMCJ_World_GetBlockId(world,x,y,z)!=blockID ||
        (blockID != 75 && blockID != 76)) return;
    powered = CloneMCJ_BlockRedstoneTorch_SupportPowered(world,x,y,z);
    CloneMCJ_BlockRedstoneTorch_Prune(world);
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if(blockID==76&&powered){
        CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,75,metadata);
        (void)CloneMCJ_BlockRedstoneTorch_CheckBurnout(world,x,y,z,1);
    }else if(blockID==75&&!powered&&
             !CloneMCJ_BlockRedstoneTorch_CheckBurnout(world,x,y,z,0)){
        CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,76,metadata);
    }
}

static void CloneMCJ_BlockRedstoneTorch_Neighbor(CloneMCJ_World *world, int x,
    int y, int z, int neighborID)
{
    int id;
    (void)neighborID;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (id == 75 || id == 76) CloneMCJ_World_ScheduleBlockUpdate(world, x, y, z, id, 2);
}

static void CloneMCJ_BlockRedstoneTorch_ActiveChanged(CloneMCJ_World *world, int x,
    int y, int z)
{
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z,76);
}

void CloneMCJ_BlockRedstoneTorch_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    int id;
    for (id = 75; id <= 76; ++id) {
        block = CloneMCJ_BlockRegistry_GetMutable(id);
        if (block) {
            block->neighborChanged = CloneMCJ_BlockRedstoneTorch_Neighbor;
            block->onBlockAdded = id==76?CloneMCJ_BlockRedstoneTorch_ActiveChanged:0;
            block->onBlockRemoved = id==76?CloneMCJ_BlockRedstoneTorch_ActiveChanged:0;
        }
        CloneMCJ_World_RegisterBlockTick(world, id, 1,
            CloneMCJ_BlockRedstoneTorch_UpdateTick, 0);
    }
}

void CloneMCJ_BlockRedstoneTorch_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockRedstoneTorch_JavaName(void)
{
    return "net.minecraft.src.BlockRedstoneTorch";
}

const char *CloneMCJ_BlockRedstoneTorch_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockRedstoneTorch_JavaSourceHash32(void)
{
    return 0x7FB34042UL;
}
