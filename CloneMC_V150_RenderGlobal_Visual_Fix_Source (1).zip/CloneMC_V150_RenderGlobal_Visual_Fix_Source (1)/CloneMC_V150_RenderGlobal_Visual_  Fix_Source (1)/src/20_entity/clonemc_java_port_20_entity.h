/*
 * Shared public declarations for Java modules assigned to src/20_entity.
 * 55 class-specific C implementations use this one subsystem header.
 * Detailed Java field/method inventories remain beside the implementation in
 * each same-named class C file, avoiding hundreds of tiny public headers.
 */
#ifndef CLONEMC_JAVA_PORT_20_ENTITY_H
#define CLONEMC_JAVA_PORT_20_ENTITY_H

#include "../00_core/clonemc_java_port_00_core.h"
#include "../30_item/clonemc_java_port_30_item.h"

#ifdef __cplusplus
extern "C" {
#endif

/* DataWatcher.java: class, 240 Java lines. */
void CloneMCJ_DataWatcher_Register(void);
const char *CloneMCJ_DataWatcher_JavaName(void);
const char *CloneMCJ_DataWatcher_AssignedFolder(void);
unsigned long CloneMCJ_DataWatcher_JavaSourceHash32(void);

/* Entity.java: class, 1318 Java lines. */
void CloneMCJ_Entity_Register(void);
const char *CloneMCJ_Entity_JavaName(void);
const char *CloneMCJ_Entity_AssignedFolder(void);
unsigned long CloneMCJ_Entity_JavaSourceHash32(void);

/* EntityAnimal.java: class, 54 Java lines. */
void CloneMCJ_EntityAnimal_Register(void);
const char *CloneMCJ_EntityAnimal_JavaName(void);
const char *CloneMCJ_EntityAnimal_AssignedFolder(void);
unsigned long CloneMCJ_EntityAnimal_JavaSourceHash32(void);

/* EntityArrow.java: class, 325 Java lines. */
void CloneMCJ_EntityArrow_Register(void);
const char *CloneMCJ_EntityArrow_JavaName(void);
const char *CloneMCJ_EntityArrow_AssignedFolder(void);
unsigned long CloneMCJ_EntityArrow_JavaSourceHash32(void);

/* EntityBoat.java: class, 384 Java lines. */
void CloneMCJ_EntityBoat_Register(void);
const char *CloneMCJ_EntityBoat_JavaName(void);
const char *CloneMCJ_EntityBoat_AssignedFolder(void);
unsigned long CloneMCJ_EntityBoat_JavaSourceHash32(void);

/* EntityChicken.java: class, 102 Java lines. */
void CloneMCJ_EntityChicken_Register(void);
const char *CloneMCJ_EntityChicken_JavaName(void);
const char *CloneMCJ_EntityChicken_AssignedFolder(void);
unsigned long CloneMCJ_EntityChicken_JavaSourceHash32(void);

/* EntityClientPlayerMP.java: class, 222 Java lines. */
void CloneMCJ_EntityClientPlayerMP_Register(void);
const char *CloneMCJ_EntityClientPlayerMP_JavaName(void);
const char *CloneMCJ_EntityClientPlayerMP_AssignedFolder(void);
unsigned long CloneMCJ_EntityClientPlayerMP_JavaSourceHash32(void);

/* EntityCow.java: class, 70 Java lines. */
void CloneMCJ_EntityCow_Register(void);
const char *CloneMCJ_EntityCow_JavaName(void);
const char *CloneMCJ_EntityCow_AssignedFolder(void);
unsigned long CloneMCJ_EntityCow_JavaSourceHash32(void);

/* EntityCreature.java: class, 213 Java lines. */
void CloneMCJ_EntityCreature_Register(void);
const char *CloneMCJ_EntityCreature_JavaName(void);
const char *CloneMCJ_EntityCreature_AssignedFolder(void);
unsigned long CloneMCJ_EntityCreature_JavaSourceHash32(void);

/* EntityCreeper.java: class, 184 Java lines. */
void CloneMCJ_EntityCreeper_Register(void);
const char *CloneMCJ_EntityCreeper_JavaName(void);
const char *CloneMCJ_EntityCreeper_AssignedFolder(void);
unsigned long CloneMCJ_EntityCreeper_JavaSourceHash32(void);

/* EntityEgg.java: class, 297 Java lines. */
void CloneMCJ_EntityEgg_Register(void);
const char *CloneMCJ_EntityEgg_JavaName(void);
const char *CloneMCJ_EntityEgg_AssignedFolder(void);
unsigned long CloneMCJ_EntityEgg_JavaSourceHash32(void);

/* EntityFallingSand.java: class, 117 Java lines. */
void CloneMCJ_EntityFallingSand_Register(void);
const char *CloneMCJ_EntityFallingSand_JavaName(void);
const char *CloneMCJ_EntityFallingSand_AssignedFolder(void);
unsigned long CloneMCJ_EntityFallingSand_JavaSourceHash32(void);

/* EntityFireball.java: class, 270 Java lines. */
void CloneMCJ_EntityFireball_Register(void);
const char *CloneMCJ_EntityFireball_JavaName(void);
const char *CloneMCJ_EntityFireball_AssignedFolder(void);
unsigned long CloneMCJ_EntityFireball_JavaSourceHash32(void);

/* EntityFish.java: class, 413 Java lines. */
void CloneMCJ_EntityFish_Register(void);
const char *CloneMCJ_EntityFish_JavaName(void);
const char *CloneMCJ_EntityFish_AssignedFolder(void);
unsigned long CloneMCJ_EntityFish_JavaSourceHash32(void);

/* EntityFlying.java: class, 87 Java lines. */
void CloneMCJ_EntityFlying_Register(void);
const char *CloneMCJ_EntityFlying_JavaName(void);
const char *CloneMCJ_EntityFlying_AssignedFolder(void);
unsigned long CloneMCJ_EntityFlying_JavaSourceHash32(void);

/* EntityGhast.java: class, 202 Java lines. */
void CloneMCJ_EntityGhast_Register(void);
const char *CloneMCJ_EntityGhast_JavaName(void);
const char *CloneMCJ_EntityGhast_AssignedFolder(void);
unsigned long CloneMCJ_EntityGhast_JavaSourceHash32(void);

/* EntityGiantZombie.java: class, 30 Java lines. */
void CloneMCJ_EntityGiantZombie_Register(void);
const char *CloneMCJ_EntityGiantZombie_JavaName(void);
const char *CloneMCJ_EntityGiantZombie_AssignedFolder(void);
unsigned long CloneMCJ_EntityGiantZombie_JavaSourceHash32(void);

/* EntityItem.java: class, 167 Java lines. */
void CloneMCJ_EntityItem_Register(void);
const char *CloneMCJ_EntityItem_JavaName(void);
const char *CloneMCJ_EntityItem_AssignedFolder(void);
unsigned long CloneMCJ_EntityItem_JavaSourceHash32(void);

/* EntityLightningBolt.java: class, 116 Java lines. */
void CloneMCJ_EntityLightningBolt_Register(void);
const char *CloneMCJ_EntityLightningBolt_JavaName(void);
const char *CloneMCJ_EntityLightningBolt_AssignedFolder(void);
unsigned long CloneMCJ_EntityLightningBolt_JavaSourceHash32(void);

/* EntityList.java: class, 156 Java lines. */
void CloneMCJ_EntityList_Register(void);
const char *CloneMCJ_EntityList_JavaName(void);
const char *CloneMCJ_EntityList_AssignedFolder(void);
unsigned long CloneMCJ_EntityList_JavaSourceHash32(void);

/* EntityLiving.java: class, 974 Java lines. */
void CloneMCJ_EntityLiving_Register(void);
const char *CloneMCJ_EntityLiving_JavaName(void);
const char *CloneMCJ_EntityLiving_AssignedFolder(void);
unsigned long CloneMCJ_EntityLiving_JavaSourceHash32(void);

/* EntityMinecart.java: class, 997 Java lines. */
void CloneMCJ_EntityMinecart_Register(void);
const char *CloneMCJ_EntityMinecart_JavaName(void);
const char *CloneMCJ_EntityMinecart_AssignedFolder(void);
unsigned long CloneMCJ_EntityMinecart_JavaSourceHash32(void);

/* EntityMob.java: class, 120 Java lines. */
void CloneMCJ_EntityMob_Register(void);
const char *CloneMCJ_EntityMob_JavaName(void);
const char *CloneMCJ_EntityMob_AssignedFolder(void);
unsigned long CloneMCJ_EntityMob_JavaSourceHash32(void);

/* EntityOtherPlayerMP.java: class, 137 Java lines. */
void CloneMCJ_EntityOtherPlayerMP_Register(void);
const char *CloneMCJ_EntityOtherPlayerMP_JavaName(void);
const char *CloneMCJ_EntityOtherPlayerMP_AssignedFolder(void);
unsigned long CloneMCJ_EntityOtherPlayerMP_JavaSourceHash32(void);

/* EntityPainting.java: class, 299 Java lines. */
void CloneMCJ_EntityPainting_Register(void);
const char *CloneMCJ_EntityPainting_JavaName(void);
const char *CloneMCJ_EntityPainting_AssignedFolder(void);
unsigned long CloneMCJ_EntityPainting_JavaSourceHash32(void);

/* EntityPig.java: class, 118 Java lines. */
void CloneMCJ_EntityPig_Register(void);
const char *CloneMCJ_EntityPig_JavaName(void);
const char *CloneMCJ_EntityPig_AssignedFolder(void);
unsigned long CloneMCJ_EntityPig_JavaSourceHash32(void);

/* EntityPigZombie.java: class, 132 Java lines. */
void CloneMCJ_EntityPigZombie_Register(void);
const char *CloneMCJ_EntityPigZombie_JavaName(void);
const char *CloneMCJ_EntityPigZombie_AssignedFolder(void);
unsigned long CloneMCJ_EntityPigZombie_JavaSourceHash32(void);

/* EntityPlayer.java: class, 972 Java lines. */
void CloneMCJ_EntityPlayer_Register(void);
const char *CloneMCJ_EntityPlayer_JavaName(void);
const char *CloneMCJ_EntityPlayer_AssignedFolder(void);
unsigned long CloneMCJ_EntityPlayer_JavaSourceHash32(void);

/* EntityPlayerSP.java: class, 306 Java lines. */
void CloneMCJ_EntityPlayerSP_Register(void);
const char *CloneMCJ_EntityPlayerSP_JavaName(void);
const char *CloneMCJ_EntityPlayerSP_AssignedFolder(void);
unsigned long CloneMCJ_EntityPlayerSP_JavaSourceHash32(void);

/* EntitySheep.java: class, 187 Java lines. */
void CloneMCJ_EntitySheep_Register(void);
const char *CloneMCJ_EntitySheep_JavaName(void);
const char *CloneMCJ_EntitySheep_AssignedFolder(void);
unsigned long CloneMCJ_EntitySheep_JavaSourceHash32(void);

/* EntitySkeleton.java: class, 115 Java lines. */
void CloneMCJ_EntitySkeleton_Register(void);
const char *CloneMCJ_EntitySkeleton_JavaName(void);
const char *CloneMCJ_EntitySkeleton_AssignedFolder(void);
unsigned long CloneMCJ_EntitySkeleton_JavaSourceHash32(void);

/* EntitySlime.java: class, 183 Java lines. */
void CloneMCJ_EntitySlime_Register(void);
const char *CloneMCJ_EntitySlime_JavaName(void);
const char *CloneMCJ_EntitySlime_AssignedFolder(void);
unsigned long CloneMCJ_EntitySlime_JavaSourceHash32(void);

/* EntitySnowball.java: class, 281 Java lines. */
void CloneMCJ_EntitySnowball_Register(void);
const char *CloneMCJ_EntitySnowball_JavaName(void);
const char *CloneMCJ_EntitySnowball_AssignedFolder(void);
unsigned long CloneMCJ_EntitySnowball_JavaSourceHash32(void);

/* EntitySpider.java: class, 107 Java lines. */
void CloneMCJ_EntitySpider_Register(void);
const char *CloneMCJ_EntitySpider_JavaName(void);
const char *CloneMCJ_EntitySpider_AssignedFolder(void);
unsigned long CloneMCJ_EntitySpider_JavaSourceHash32(void);

/* EntitySquid.java: class, 187 Java lines. */
void CloneMCJ_EntitySquid_Register(void);
const char *CloneMCJ_EntitySquid_JavaName(void);
const char *CloneMCJ_EntitySquid_AssignedFolder(void);
unsigned long CloneMCJ_EntitySquid_JavaSourceHash32(void);

/* EntityTNTPrimed.java: class, 106 Java lines. */
void CloneMCJ_EntityTNTPrimed_Register(void);
const char *CloneMCJ_EntityTNTPrimed_JavaName(void);
const char *CloneMCJ_EntityTNTPrimed_AssignedFolder(void);
unsigned long CloneMCJ_EntityTNTPrimed_JavaSourceHash32(void);

/* EntityWaterMob.java: class, 44 Java lines. */
void CloneMCJ_EntityWaterMob_Register(void);
const char *CloneMCJ_EntityWaterMob_JavaName(void);
const char *CloneMCJ_EntityWaterMob_AssignedFolder(void);
unsigned long CloneMCJ_EntityWaterMob_JavaSourceHash32(void);

/* EntityWeatherEffect.java: class, 19 Java lines. */
void CloneMCJ_EntityWeatherEffect_Register(void);
const char *CloneMCJ_EntityWeatherEffect_JavaName(void);
const char *CloneMCJ_EntityWeatherEffect_AssignedFolder(void);
unsigned long CloneMCJ_EntityWeatherEffect_JavaSourceHash32(void);

/* EntityWolf.java: class, 611 Java lines. */
void CloneMCJ_EntityWolf_Register(void);
const char *CloneMCJ_EntityWolf_JavaName(void);
const char *CloneMCJ_EntityWolf_AssignedFolder(void);
unsigned long CloneMCJ_EntityWolf_JavaSourceHash32(void);

/* EntityZombie.java: class, 56 Java lines. */
void CloneMCJ_EntityZombie_Register(void);
const char *CloneMCJ_EntityZombie_JavaName(void);
const char *CloneMCJ_EntityZombie_AssignedFolder(void);
unsigned long CloneMCJ_EntityZombie_JavaSourceHash32(void);

/* EnumArt.java: enum, 126 Java lines. */
void CloneMCJ_EnumArt_Register(void);
const char *CloneMCJ_EnumArt_JavaName(void);
const char *CloneMCJ_EnumArt_AssignedFolder(void);
unsigned long CloneMCJ_EnumArt_JavaSourceHash32(void);

/* EnumMobType.java: enum, 47 Java lines. */
void CloneMCJ_EnumMobType_Register(void);
const char *CloneMCJ_EnumMobType_JavaName(void);
const char *CloneMCJ_EnumMobType_AssignedFolder(void);
unsigned long CloneMCJ_EnumMobType_JavaSourceHash32(void);

/* EnumMovingObjectType.java: enum, 44 Java lines. */
void CloneMCJ_EnumMovingObjectType_Register(void);
const char *CloneMCJ_EnumMovingObjectType_JavaName(void);
const char *CloneMCJ_EnumMovingObjectType_AssignedFolder(void);
unsigned long CloneMCJ_EnumMovingObjectType_JavaSourceHash32(void);

/* IMob.java: interface, 11 Java lines. */
void CloneMCJ_IMob_Register(void);
const char *CloneMCJ_IMob_JavaName(void);
const char *CloneMCJ_IMob_AssignedFolder(void);
unsigned long CloneMCJ_IMob_JavaSourceHash32(void);

/* MovementInput.java: class, 41 Java lines. */
void CloneMCJ_MovementInput_Register(void);
const char *CloneMCJ_MovementInput_JavaName(void);
const char *CloneMCJ_MovementInput_AssignedFolder(void);
unsigned long CloneMCJ_MovementInput_JavaSourceHash32(void);

/* MovementInputFromOptions.java: class, 94 Java lines. */
void CloneMCJ_MovementInputFromOptions_Register(void);
const char *CloneMCJ_MovementInputFromOptions_JavaName(void);
const char *CloneMCJ_MovementInputFromOptions_AssignedFolder(void);
unsigned long CloneMCJ_MovementInputFromOptions_JavaSourceHash32(void);

/* MovingObjectPosition.java: class, 39 Java lines. */
void CloneMCJ_MovingObjectPosition_Register(void);
const char *CloneMCJ_MovingObjectPosition_JavaName(void);
const char *CloneMCJ_MovingObjectPosition_AssignedFolder(void);
unsigned long CloneMCJ_MovingObjectPosition_JavaSourceHash32(void);

/* Path.java: class, 149 Java lines. */
void CloneMCJ_Path_Register(void);
const char *CloneMCJ_Path_JavaName(void);
const char *CloneMCJ_Path_AssignedFolder(void);
unsigned long CloneMCJ_Path_JavaSourceHash32(void);

/* PathEntity.java: class, 53 Java lines. */
void CloneMCJ_PathEntity_Register(void);
const char *CloneMCJ_PathEntity_JavaName(void);
const char *CloneMCJ_PathEntity_AssignedFolder(void);
unsigned long CloneMCJ_PathEntity_JavaSourceHash32(void);

/* Pathfinder.java: class, 247 Java lines. */
void CloneMCJ_Pathfinder_Register(void);
const char *CloneMCJ_Pathfinder_JavaName(void);
const char *CloneMCJ_Pathfinder_AssignedFolder(void);
unsigned long CloneMCJ_Pathfinder_JavaSourceHash32(void);

/* PathPoint.java: class, 75 Java lines. */
void CloneMCJ_PathPoint_Register(void);
const char *CloneMCJ_PathPoint_JavaName(void);
const char *CloneMCJ_PathPoint_AssignedFolder(void);
unsigned long CloneMCJ_PathPoint_JavaSourceHash32(void);

/* PlayerController.java: class, 144 Java lines. */
void CloneMCJ_PlayerController_Register(void);
const char *CloneMCJ_PlayerController_JavaName(void);
const char *CloneMCJ_PlayerController_AssignedFolder(void);
unsigned long CloneMCJ_PlayerController_JavaSourceHash32(void);

/* PlayerControllerSP.java: class, 155 Java lines. */
void CloneMCJ_PlayerControllerSP_Register(void);
const char *CloneMCJ_PlayerControllerSP_JavaName(void);
const char *CloneMCJ_PlayerControllerSP_AssignedFolder(void);
unsigned long CloneMCJ_PlayerControllerSP_JavaSourceHash32(void);

/* PlayerControllerTest.java: class, 52 Java lines. */
void CloneMCJ_PlayerControllerTest_Register(void);
const char *CloneMCJ_PlayerControllerTest_JavaName(void);
const char *CloneMCJ_PlayerControllerTest_AssignedFolder(void);
unsigned long CloneMCJ_PlayerControllerTest_JavaSourceHash32(void);

/* WatchableObject.java: class, 49 Java lines. */
void CloneMCJ_WatchableObject_Register(void);
const char *CloneMCJ_WatchableObject_JavaName(void);
const char *CloneMCJ_WatchableObject_AssignedFolder(void);
unsigned long CloneMCJ_WatchableObject_JavaSourceHash32(void);

/* Priority 7: direct entity/player/dropped-item gameplay layer. */
#define CLONEMC_J_MAX_DROPPED_ITEMS 512
#define CLONEMC_J_MAX_PENDING_DROPS 128
#define CLONEMC_J_MAX_MOBS 64
#define CLONEMC_J_MAX_PROJECTILES 128
#define CLONEMC_J_MAX_VEHICLES 64
#define CLONEMC_J_MAX_PATH_POINTS 128
#define CLONEMC_J_PATH_SEARCH_NODES 512

typedef struct CloneMCJ_EntityTag {
    struct CloneMCJ_WorldTag *worldObj;
    int entityId;
    double prevPosX, prevPosY, prevPosZ;
    double posX, posY, posZ;
    double motionX, motionY, motionZ;
    float rotationYaw, rotationPitch;
    float prevRotationYaw, prevRotationPitch;
    /* Entity.updateRidden accumulates mount rotation separately from mouse
     * look, then releases at most ten degrees per tick.  Keeping these as
     * doubles preserves the supplied Java behavior through 180-degree cart
     * direction flips without snapping the camera. */
    double entityRiderYawDelta, entityRiderPitchDelta;
    float width, height, yOffset, ySize, stepHeight;
    /* Entity.java exposes a per-entity minimum brightness which luminous
     * renderers may raise above the sampled world light. */
    float entityBrightness;
    float fallDistance;
    CloneMCAxisAlignedBB boundingBox;
    unsigned char onGround, collidedHorizontally, collidedVertically, collided;
    unsigned char inWater, inLava, inWeb, sneaking, noClip, isDead;
    unsigned char addedToChunk;
    int chunkCoordX, chunkCoordY, chunkCoordZ;
    int ticksExisted, fire, air;
    CloneMCJavaRandom rand;
} CloneMCJ_Entity;

/* Native identity reservation used by the chunk/NBT factory.  Java's runtime
 * allocates a fresh identity after every reconstructed Entity.  Persisted C
 * identities are explicit, so reopening a world must advance the allocator
 * past the largest restored value before anything new is spawned. */
void CloneMCJ_Entity_ReserveID(int);
float CloneMCJ_Entity_GetBrightness(const CloneMCJ_Entity *);
int CloneMCJ_Entity_IsInsideOpaqueBlock(const CloneMCJ_Entity *,float);

typedef struct CloneMCJ_MovementInputTag {
    float moveStrafe, moveForward;
    unsigned char jump, sneak;
} CloneMCJ_MovementInput;

#define CLONEMC_J_GAMEMODE_SURVIVAL 0
#define CLONEMC_J_GAMEMODE_CREATIVE 1
#define CLONEMC_J_GAMEMODE_SPECTATOR 3
#define CLONEMC_J_SPRINT_SPEED_MULTIPLIER 1.30F
#define CLONEMC_J_SPRINT_JUMP_IMPULSE 0.20
#define CLONEMC_J_SPRINT_FOV_MULTIPLIER 1.15F
#define CLONEMC_J_ENCHANT_PROTECTION            0
#define CLONEMC_J_ENCHANT_FIRE_PROTECTION       1
#define CLONEMC_J_ENCHANT_FEATHER_FALLING       2
#define CLONEMC_J_ENCHANT_BLAST_PROTECTION      3
#define CLONEMC_J_ENCHANT_PROJECTILE_PROTECTION 4
#define CLONEMC_J_ENCHANT_RESPIRATION           5
#define CLONEMC_J_ENCHANT_AQUA_AFFINITY         6
#define CLONEMC_J_ENCHANT_SHARPNESS            16
#define CLONEMC_J_ENCHANT_SMITE                17
#define CLONEMC_J_ENCHANT_BANE_ARTHROPODS      18
#define CLONEMC_J_ENCHANT_KNOCKBACK            19
#define CLONEMC_J_ENCHANT_FIRE_ASPECT          20
#define CLONEMC_J_ENCHANT_LOOTING              21
#define CLONEMC_J_ENCHANT_EFFICIENCY           32
#define CLONEMC_J_ENCHANT_SILK_TOUCH           33
#define CLONEMC_J_ENCHANT_UNBREAKING           34
#define CLONEMC_J_ENCHANT_FORTUNE              35
#define CLONEMC_J_ENCHANT_POWER                48
#define CLONEMC_J_ENCHANT_PUNCH                49
#define CLONEMC_J_ENCHANT_FLAME                50
#define CLONEMC_J_ENCHANT_INFINITY             51
#define CLONEMC_J_MAX_ACTIVE_EFFECTS       32
#define CLONEMC_J_EFFECT_SPEED             1
#define CLONEMC_J_EFFECT_SLOWNESS          2
#define CLONEMC_J_EFFECT_HASTE             3
#define CLONEMC_J_EFFECT_MINING_FATIGUE    4
#define CLONEMC_J_EFFECT_STRENGTH          5
#define CLONEMC_J_EFFECT_HEAL              6
#define CLONEMC_J_EFFECT_HARM              7
#define CLONEMC_J_EFFECT_JUMP              8
#define CLONEMC_J_EFFECT_NAUSEA            9
#define CLONEMC_J_EFFECT_REGENERATION      10
#define CLONEMC_J_EFFECT_RESISTANCE        11
#define CLONEMC_J_EFFECT_FIRE_RESISTANCE   12
#define CLONEMC_J_EFFECT_WATER_BREATHING   13
#define CLONEMC_J_EFFECT_INVISIBILITY      14
#define CLONEMC_J_EFFECT_BLINDNESS         15
#define CLONEMC_J_EFFECT_NIGHT_VISION      16
#define CLONEMC_J_EFFECT_HUNGER            17
#define CLONEMC_J_EFFECT_WEAKNESS          18
#define CLONEMC_J_EFFECT_POISON            19
#define CLONEMC_J_POTION_WATER             0
#define CLONEMC_J_POTION_AWKWARD           1
#define CLONEMC_J_POTION_SPEED             2
#define CLONEMC_J_POTION_REGENERATION      3
#define CLONEMC_J_POTION_FIRE_RESISTANCE   4
#define CLONEMC_J_POTION_HEALING           5
#define CLONEMC_J_POTION_HARMING           6
#define CLONEMC_J_POTION_TYPE_MASK         15
#define CLONEMC_J_POTION_STRONG            32
#define CLONEMC_J_POTION_EXTENDED          64
#define CLONEMC_J_POTION_SPLASH            16384

typedef struct CloneMCJ_PotionEffectNativeTag {
    int effectId;
    int duration;
    int amplifier;
    int liquidColor;
    unsigned char instant;
} CloneMCJ_PotionEffectNative;

typedef struct CloneMCJ_EntityPlayerTag {
    CloneMCJ_Entity entity;
    CloneMCJ_InventoryPlayer inventory;
    CloneMCJ_MovementInput movementInput;
    char username[64];
    int health, score, dimension, ridingEntityId;
    int gameMode;
    unsigned char allowFlying, flying, invulnerable, sprinting;
    float sprintFovModifier, prevSprintFovModifier;
    float swingProgress, prevSwingProgress;
    /* EntityPlayer cloak chase coordinates (field_20066_r..field_20061_w). */
    double cloakPrevX,cloakPrevY,cloakPrevZ;
    double cloakX,cloakY,cloakZ;
    int swingProgressInt;
    unsigned char isSwinging;
    /* Priority 16: exact Beta portal and bed state. */
    int timeUntilPortal;
    float timeInPortal, prevTimeInPortal;
    unsigned char inPortal, sleeping;
    int sleepTimer;
    int bedX, bedY, bedZ;
    int spawnX, spawnY, spawnZ;
    unsigned char hasBedSpawn;
    int lastAttackerEntityId, lastAttackTargetEntityId;
    int hurtTime, maxHurtTime, hurtResistantTime, lastDamage, damageRemainder;
    int experienceLevel, experienceTotal;
    float experienceProgress;
    int activeEffectDuration[CLONEMC_J_MAX_ACTIVE_EFFECTS];
    unsigned char activeEffectId[CLONEMC_J_MAX_ACTIVE_EFFECTS];
    unsigned char activeEffectAmplifier[CLONEMC_J_MAX_ACTIVE_EFFECTS];
    unsigned long itemsPickedUp, blocksMined, blocksPlaced;
    /* V115: retain the exact block/action location until the render/audio tick
     * consumes the counter change.  Using the player position and a hard-coded
     * stone sound made grass, wood, glass and plants all sound identical and
     * made break particles sample the wrong block after it had become air. */
    int lastMinedBlockID, lastMinedMetadata;
    int lastMinedX, lastMinedY, lastMinedZ;
    int lastPlacedBlockID, lastPlacedMetadata;
    int lastPlacedX, lastPlacedY, lastPlacedZ;
    unsigned long blocksActivated;
    int lastActivatedBlockID, lastActivatedMetadata;
    int lastActivatedX, lastActivatedY, lastActivatedZ;
} CloneMCJ_EntityPlayer;

typedef struct CloneMCJ_EntityItemTag {
    CloneMCJ_Entity entity;
    CloneMCJ_ItemStack item;
    int age, delayBeforeCanPickup, health;
    float hoverStart;
    unsigned char active;
} CloneMCJ_EntityItem;

/* A fully initialized EntityItem waiting for an active pool slot.  Constructing
 * it at the original spawn call preserves entity identity, Java RNG use,
 * pickup delay, hover phase, and directed/dispenser motion even when the
 * visible pool is temporarily saturated. */
typedef struct CloneMCJ_PendingDropTag {
    CloneMCJ_EntityItem itemEntity;
    unsigned char active;
} CloneMCJ_PendingDrop;

/*
 * Release-era EntityXPOrb equivalent.  A bounded pool keeps later progression
 * deterministic on 32-64 MB Win9x systems and prevents pickup particles from
 * becoming an unbounded heap workload.
 */
#define CLONEMC_J_MAX_EXPERIENCE_ORBS 64
typedef struct CloneMCJ_ExperienceOrbTag {
    CloneMCJ_Entity entity;
    int value, age, pickupDelay;
    unsigned char active;
} CloneMCJ_ExperienceOrb;

typedef enum CloneMCJ_MobTypeTag {
    CLONEMC_J_MOB_PIG = 0,
    CLONEMC_J_MOB_SHEEP,
    CLONEMC_J_MOB_COW,
    CLONEMC_J_MOB_CHICKEN,
    CLONEMC_J_MOB_ZOMBIE,
    CLONEMC_J_MOB_GIANT,
    CLONEMC_J_MOB_GHAST,
    CLONEMC_J_MOB_PIG_ZOMBIE,
    CLONEMC_J_MOB_SKELETON,
    CLONEMC_J_MOB_CREEPER,
    CLONEMC_J_MOB_SPIDER,
    CLONEMC_J_MOB_SLIME,
    CLONEMC_J_MOB_WOLF,
    CLONEMC_J_MOB_SQUID,
    CLONEMC_J_MOB_ENDERMAN,
    CLONEMC_J_MOB_BLAZE,
    CLONEMC_J_MOB_MAGMA_CUBE,
    CLONEMC_J_MOB_ENDER_DRAGON,
    CLONEMC_J_MOB_ENDER_CRYSTAL,
    CLONEMC_J_MOB_VILLAGER,
    CLONEMC_J_MOB_CAVE_SPIDER,
    CLONEMC_J_MOB_SILVERFISH,
    CLONEMC_J_MOB_MOOSHROOM,
    CLONEMC_J_MOB_SNOWMAN,
    CLONEMC_J_MOB_OCELOT,
    CLONEMC_J_MOB_IRON_GOLEM,
    CLONEMC_J_MOB_TYPE_COUNT
} CloneMCJ_MobType;

/* Priority 12 uses bounded native equivalents of PathPoint/PathEntity.  The
 * Java path finder can grow its heap dynamically; the fixed limits keep the
 * DOS-era/Open Watcom memory profile predictable and fail closed when a path
 * is too complex. */
typedef struct CloneMCJ_PathPointNativeTag {
    int xCoord, yCoord, zCoord;
    int hash, heapIndex, previousIndex;
    float totalPathDistance, distanceToNext, distanceToTarget;
    unsigned char opened, closed;
} CloneMCJ_PathPointNative;

typedef struct CloneMCJ_PathEntityNativeTag {
    CloneMCJ_PathPointNative points[CLONEMC_J_MAX_PATH_POINTS];
    int pathLength, pathIndex;
} CloneMCJ_PathEntityNative;

/* Villager trading was introduced after the uploaded 1.2.3 Java snapshot,
 * but existed in CloneMC's earlier native extension and is intentionally
 * restored as a bounded, saveable subsystem. */
#define CLONEMC_J_MAX_VILLAGER_TRADES 10

typedef struct CloneMCJ_VillagerTradeTag {
    short buyItemID, buyItemDamage, buyCount;
    short secondBuyItemID, secondBuyItemDamage, secondBuyCount;
    short sellItemID, sellItemDamage, sellCount;
    short uses, maximumUses;
} CloneMCJ_VillagerTrade;

int CloneMCJ_PathPoint_Hash(int, int, int);
void CloneMCJ_PathPoint_InitializeNative(CloneMCJ_PathPointNative *, int, int, int);
float CloneMCJ_PathPoint_DistanceTo(const CloneMCJ_PathPointNative *,
    const CloneMCJ_PathPointNative *);
int CloneMCJ_PathPoint_EqualsNative(const CloneMCJ_PathPointNative *,
    const CloneMCJ_PathPointNative *);
int CloneMCJ_Path_AddPoint(int *, int *, CloneMCJ_PathPointNative *, int, int);
int CloneMCJ_Path_Dequeue(int *, int *, CloneMCJ_PathPointNative *);
void CloneMCJ_Path_ChangeDistance(int *, int, CloneMCJ_PathPointNative *, int, float);

#define CLONEMC_J_MAX_AI_TASKS 16

typedef int (*CloneMCJ_AIShouldExecuteProc)(void *);
typedef int (*CloneMCJ_AIContinueProc)(void *);
typedef void (*CloneMCJ_AITaskProc)(void *);

typedef struct CloneMCJ_EntityAIBaseNativeTag {
    CloneMCJ_AIShouldExecuteProc shouldExecute;
    CloneMCJ_AIContinueProc continueExecuting;
    CloneMCJ_AITaskProc startTask;
    CloneMCJ_AITaskProc resetTask;
    CloneMCJ_AITaskProc updateTask;
    void *userData;
    int mutexBits;
    unsigned char continuous;
} CloneMCJ_EntityAIBaseNative;

typedef struct CloneMCJ_EntityAITaskEntryNativeTag {
    CloneMCJ_EntityAIBaseNative action;
    int priority;
    unsigned char executing;
} CloneMCJ_EntityAITaskEntryNative;

typedef struct CloneMCJ_EntityAITasksNativeTag {
    CloneMCJ_EntityAITaskEntryNative entries[CLONEMC_J_MAX_AI_TASKS];
    int count;
} CloneMCJ_EntityAITasksNative;

typedef struct CloneMCJ_MobTag {
    CloneMCJ_Entity entity;
    CloneMCJ_MobType type;
    int health, prevHealth, maxHealth, attackStrength, attackTime, deathTime;
    int entityAge, livingSoundTime, targetTicks, specialTimer;
    int hurtTime, maxHurtTime, hurtResistantTime, lastDamage, recentlyHit;
    int timeSinceIgnited, lastActiveTime, fuseTime, creeperState;
    int angerLevel, attackCounter, prevAttackCounter, courseChangeCooldown;
    /* Java 1.2.3 mob-specific transient counters.  These remain explicit so
     * Blaze charging and Enderman gaze/teleport timing do not alias generic
     * AI timers and accidentally reset when a path is recalculated. */
    int blazeHeightOffsetUpdateTime;
    int endermanTeleportDelay, endermanGazeTicks, magmaArmorCarryover;
    int slimeSize, woolColor, slimeJumpDelay;
    /* EntityEnderman data-watcher slots 16/17 and NBT carried fields. */
    int carriedBlockId, carriedBlockData;
    /* EntityVillager.java uses a persistent profession index:
     * 0 farmer, 1 librarian, 2 priest, 3 smith, 4 butcher. */
    int profession;
    int catType;
    int riderEntityId, targetEntityId, lastAttackerEntityId;
    int targetMemoryTicks, targetUnseenTicks, idleTicks, stuckTicks;
    int pathRecalcDelay, pathFailureCount, pathAge;
    float moveSpeed, moveForward, moveStrafing, randomYawVelocity;
    float limbSwing, prevLimbSwing, limbSwingAmount, prevLimbSwingAmount;
    float swingProgress, prevSwingProgress;
    int swingProgressInt;
    float renderYawOffset, prevRenderYawOffset;
    float interestedAngle, prevInterestedAngle;
    float shakeTime, prevShakeTime;
    /* EntityWolf.handleHealthUpdate byte 6/7 is represented as a transient,
     * monotonic event.  Keeping it on the entity lets the fixed renderer
     * consume every local taming result without an allocating event list. */
    unsigned long wolfTameEffectSequence;
    float slimeSquish, prevSlimeSquish, slimeSquishAmount;
    float blazeHeightOffset;
    /* Exact EntitySquid animation/steering state shared with RenderSquid. */
    float squidPitch, prevSquidPitch;
    float squidBodyYaw, prevSquidBodyYaw;
    float squidPhase, prevSquidPhase;
    float squidTentacleAngle, prevSquidTentacleAngle;
    float squidRandomMotionSpeed, squidPhaseVelocity, squidTentacleSpeed;
    float squidRandomMotionX, squidRandomMotionY, squidRandomMotionZ;
    float renderScale;
    char owner[64];
    unsigned char active, hostile, daylightBurns, jumping, isSwinging, riding, sprinting;
    unsigned char sheared, saddled, tamed, angry, sitting, inWater, renderAsPlayer;
    unsigned char sleeping;
    unsigned char looksWithInterest, wolfShaking, wolfShakeStarted, lootDropped;
    unsigned char wolfTameEffect;
    unsigned char hasPath, persistenceRequired, targetAcquired, canSeeTarget;
    unsigned char wasOnGround, rangedAttackPending, pathAvoidsSun, pathAvoidsWater;
    unsigned char killedBySkeleton;
    unsigned char blazeCharged, endermanAttacking;
    /* Priority 15 authoritative equipment mirror: slot 0 is held item;
     * slots 1-4 retain the server armor state for rendering/reconciliation. */
    int equipmentId[5], equipmentDamage[5];
    unsigned char equipmentEnchanted[5];
    /* RenderPlayer heldItemRight values: 0 none, 1 normal, 3 blocking;
     * aimedBow is kept separately because Java applies it to all biped models. */
    unsigned char heldItemUseAction,aimedBow;
    double cloakPrevX,cloakPrevY,cloakPrevZ;
    double cloakX,cloakY,cloakZ;
    int bedX,bedY,bedZ;
    int growingAge, inLove, breedingTicks;
    int activeEffectDuration[CLONEMC_J_MAX_ACTIVE_EFFECTS];
    unsigned char activeEffectId[CLONEMC_J_MAX_ACTIVE_EFFECTS];
    unsigned char activeEffectAmplifier[CLONEMC_J_MAX_ACTIVE_EFFECTS];
    int villagerAITimer, villagerHomeX, villagerHomeY, villagerHomeZ;
    int villagerHomeRadius, customerEntityId, selectedTrade;
    int villagerMateEntityId, villagerMateTicks;
    int villagerPlaymateEntityId, villagerPlayTicks;
    int tradeCount;
    unsigned char tradesInitialized;
    CloneMCJ_VillagerTrade trades[CLONEMC_J_MAX_VILLAGER_TRADES];
    double waypointX, waypointY, waypointZ;
    double lastTargetX, lastTargetY, lastTargetZ;
    double lastProgressX, lastProgressY, lastProgressZ;
    CloneMCJ_PathEntityNative path;
    struct CloneMCJ_MobTag *combatTarget;
} CloneMCJ_Mob;

#define CLONEMC_J_MAX_VILLAGES 16
#define CLONEMC_J_MAX_VILLAGE_DOORS 64
#define CLONEMC_J_MAX_DRAGONS 2
#define CLONEMC_J_DRAGON_PART_COUNT 7

typedef struct CloneMCJ_VillageDoorNativeTag {
    int x, y, z;
    int insideX, insideZ;
    unsigned long lastActivityTick;
    unsigned char active;
} CloneMCJ_VillageDoorNative;

typedef struct CloneMCJ_VillageNativeTag {
    CloneMCJ_VillageDoorNative doors[CLONEMC_J_MAX_VILLAGE_DOORS];
    int doorCount, centerX, centerY, centerZ, radius;
    int population, breedingCooldown;
    unsigned long lastUpdateTick;
    unsigned char active;
} CloneMCJ_VillageNative;

typedef struct CloneMCJ_DragonPartNativeTag {
    double x, y, z;
    float width, height;
} CloneMCJ_DragonPartNative;

typedef struct CloneMCJ_DragonNativeTag {
    int entityId, historyIndex, deathTicks, healingCrystalEntityId;
    double history[64][3];
    CloneMCJ_DragonPartNative parts[CLONEMC_J_DRAGON_PART_COUNT];
    float animation, previousAnimation;
    unsigned char active, initialized, slowedByProtectedBlock;
} CloneMCJ_DragonNative;

typedef enum CloneMCJ_ProjectileTypeTag {
    CLONEMC_J_PROJECTILE_ARROW = 10,
    CLONEMC_J_PROJECTILE_SNOWBALL = 11,
    CLONEMC_J_PROJECTILE_EGG = 12,
    CLONEMC_J_PROJECTILE_FIREBALL = 13,
    CLONEMC_J_PROJECTILE_FISHING = 14,
    CLONEMC_J_PROJECTILE_POTION = 15,
    CLONEMC_J_PROJECTILE_XP_BOTTLE = 16,
    CLONEMC_J_PROJECTILE_SMALL_FIREBALL = 17,
    CLONEMC_J_PROJECTILE_ENDER_PEARL = 18,
    CLONEMC_J_PROJECTILE_ENDER_EYE = 19
} CloneMCJ_ProjectileType;

typedef struct CloneMCJ_ProjectileTag {
    CloneMCJ_Entity entity;
    CloneMCJ_ProjectileType type;
    int xTile, yTile, zTile, inTile, inData;
    int ticksInGround, ticksInAir, shake, ownerEntityId;
    int ticksCatchable, hookedEntityId;
    int damage, age, payloadDamage;
    double accelerationX, accelerationY, accelerationZ;
    unsigned char active, inGround, belongsToPlayer;
} CloneMCJ_Projectile;

typedef enum CloneMCJ_VehicleTypeTag {
    CLONEMC_J_VEHICLE_PRIMED_TNT = 20,
    CLONEMC_J_VEHICLE_FALLING_BLOCK = 21,
    CLONEMC_J_VEHICLE_MINECART = 40,
    CLONEMC_J_VEHICLE_BOAT = 41,
    CLONEMC_J_VEHICLE_PAINTING = 9,
    CLONEMC_J_VEHICLE_LIGHTNING = 200
} CloneMCJ_VehicleType;

typedef struct CloneMCJ_ArtDefinitionTag {
    const char *title;
    int sizeX, sizeY, offsetX, offsetY;
} CloneMCJ_ArtDefinition;

int CloneMCJ_EnumArt_Count(void);
const CloneMCJ_ArtDefinition *CloneMCJ_EnumArt_At(int);
const CloneMCJ_ArtDefinition *CloneMCJ_EnumArt_Find(const char *);

typedef struct CloneMCJ_VehicleTag {
    CloneMCJ_Entity entity;
    CloneMCJ_VehicleType type;
    int damageTaken, timeSinceHit, rockDirection;
    int minecartType, fuel, fuse, blockID, blockData;
    int direction, tileX, tileY, tileZ, riderEntityId;
    int age, lightningState, boltLivingTime;
    int interpolationTicks;
    double targetX, targetY, targetZ;
    float targetYaw, targetPitch;
    double velocityX, velocityY, velocityZ;
    double pushX, pushZ;
    char art[32];
    CloneMCJ_ItemStack cargo[27];
    unsigned char active, dropContentsWhenDead, reversedDirection;
} CloneMCJ_Vehicle;

void CloneMCJ_Gameplay_BeginRidingTickNative(CloneMCJ_EntityPlayer *);
void CloneMCJ_Gameplay_UpdateVehicleRiderNative(CloneMCJ_EntityPlayer *,
    const CloneMCJ_Vehicle *);

typedef struct CloneMCJ_PlayerControllerSPTag {
    struct CloneMCJ_WorldTag *world;
    CloneMCJ_EntityPlayer *player;
    int currentBlockX, currentBlockY, currentBlockZ;
    int blockHitDelay;
    float currentBlockDamage, previousBlockDamage;
    unsigned char hittingBlock;
} CloneMCJ_PlayerControllerSP;

typedef struct CloneMCJ_MovingObjectPositionTag {
    unsigned char hit;
    int blockX, blockY, blockZ;
    int sideHit;
    CloneMCVec3D hitVec;
} CloneMCJ_MovingObjectPosition;

#define CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY 32

typedef struct CloneMCJ_BlockBreakEventTag {
    unsigned long sequence;
    int blockID, metadata;
    int x, y, z;
} CloneMCJ_BlockBreakEvent;

#define CLONEMC_J_EXPLOSION_EVENT_CAPACITY 16

typedef struct CloneMCJ_ExplosionEventTag {
    unsigned long sequence;
    double x, y, z;
    float strength;
    unsigned char flaming;
} CloneMCJ_ExplosionEvent;

#define CLONEMC_J_GAMEPLAY_AUDIO_EVENT_CAPACITY 32

typedef struct CloneMCJ_GameplayAudioEventTag {
    unsigned long sequence;
    char name[32];
    float x,y,z,volume,pitch;
    unsigned char streaming;
} CloneMCJ_GameplayAudioEvent;

typedef struct CloneMCJ_GameplayStateTag {
    struct CloneMCJ_WorldTag *world;
    CloneMCJ_EntityPlayer player;
    CloneMCJ_PlayerControllerSP controller;
    CloneMCJ_EntityItem droppedItems[CLONEMC_J_MAX_DROPPED_ITEMS];
    int droppedItemCount;
    CloneMCJ_PendingDrop pendingDrops[CLONEMC_J_MAX_PENDING_DROPS];
    int pendingDropCount;
    unsigned long queuedDropCount;
    unsigned long rejectedDropCount;
    CloneMCJ_ExperienceOrb experienceOrbs[CLONEMC_J_MAX_EXPERIENCE_ORBS];
    int experienceOrbCount;
    CloneMCJ_Mob mobs[CLONEMC_J_MAX_MOBS];
    int mobCount;
    CloneMCJ_Projectile projectiles[CLONEMC_J_MAX_PROJECTILES];
    int projectileCount;
    CloneMCJ_Vehicle vehicles[CLONEMC_J_MAX_VEHICLES];
    int vehicleCount;
    int nextEntityId;
    int openVehicleInventoryId;
    int openMerchantMobIndex;
    CloneMCJ_Container openContainer;
    CloneMCJ_InventoryCrafting openCraftMatrix;
    CloneMCJ_InventoryCraftResult openCraftResult;
    CloneMCJ_TileEntity openContainerTile;
    int openContainerX, openContainerY, openContainerZ;
    unsigned char openContainerActive;
    unsigned char openContainerIsBlock;
    int difficulty;
    unsigned long ticksRun;
    unsigned long entitySyncFailures;
    unsigned long droppedItemTicks;
    unsigned long droppedItemTicksSuspended;
    unsigned long mobTicksSuspended;
    unsigned long projectileTicksSuspended;
    unsigned long vehicleTicksSuspended;
    unsigned short entityChunkPrefetchCursor;
    unsigned long entityChunkPrefetchScans;
    unsigned long entityChunkPrefetchReady;
    unsigned long droppedItemsDespawned;
    char lastSaveError[192];
    CloneMCJ_BlockBreakEvent blockBreakEvents[CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY];
    unsigned long blockBreakEventSequence;
    CloneMCJ_ExplosionEvent explosionEvents[CLONEMC_J_EXPLOSION_EVENT_CAPACITY];
    unsigned long explosionEventSequence;
    CloneMCJ_GameplayAudioEvent audioEvents[CLONEMC_J_GAMEPLAY_AUDIO_EVENT_CAPACITY];
    unsigned long audioEventSequence;
    unsigned char attackInput, useInput, previousAttack, previousUse;
    void *multiplayerController;
    int (*sendDigIntent)(void *, int, int, int, int, int);
    int (*sendPlaceIntent)(void *, int, int, int, int, const CloneMCJ_ItemStack *);
    int (*sendUseEntityIntent)(void *, int, int, int);
    int (*sendAnimationIntent)(void *, int, int);
    int intentBlockX, intentBlockY, intentBlockZ, intentFace;
    unsigned char intentDigging, deathHandled;
    /* GuiEditSign request is emitted by the interaction/placement path and
     * consumed by MinecraftImpl on the client thread. */
    int editSignX, editSignY, editSignZ;
    unsigned char editSignRequested;
    int enchantmentOffers[3];
    int enchantmentBookshelves;
    unsigned long enchantmentSeed;
    CloneMCJavaRandom enchantmentRandom;
    unsigned char enchantmentRandomInitialized;
    /* Release 1.0 End setup is staged one pillar per tick to avoid a large
     * synchronous block-write spike on late-1990s CPUs. */
    unsigned char endSetupStage;
    unsigned char endPortalCooldown;
    unsigned char endCreditsRequested;
    CloneMCJ_VillageNative villages[CLONEMC_J_MAX_VILLAGES];
    CloneMCJ_DragonNative dragons[CLONEMC_J_MAX_DRAGONS];
} CloneMCJ_GameplayState;

void CloneMCJ_EntityLiving_InitializeMob(CloneMCJ_Mob *, CloneMCJ_MobType,
    struct CloneMCJ_WorldTag *, double, double, double);
void CloneMCJ_EntityLiving_TickMob(CloneMCJ_Mob *, CloneMCJ_EntityPlayer *);
void CloneMCJ_EntityLiving_StartSwing(CloneMCJ_Mob *);
void CloneMCJ_EntityPlayer_SwingItem(CloneMCJ_EntityPlayer *);
int CloneMCJ_EntityLiving_AttackMob(CloneMCJ_Mob *, int);
int CloneMCJ_EntityLiving_AttackMobFrom(CloneMCJ_Mob *, const CloneMCJ_Entity *, int);
int CloneMCJ_EntityEnderman_TeleportRandomly(CloneMCJ_Mob *);
void CloneMCJ_EntityLiving_AngerPigZombie(CloneMCJ_Mob *);
int CloneMCJ_Pathfinder_CreatePath(struct CloneMCJ_WorldTag *, const CloneMCJ_Entity *,
    double, double, double, float, CloneMCJ_PathEntityNative *);
int CloneMCJ_Pathfinder_CreatePathEx(struct CloneMCJ_WorldTag *, const CloneMCJ_Entity *,
    double, double, double, float, int, int, CloneMCJ_PathEntityNative *);
int CloneMCJ_EntityLiving_CanSeeEntity(const CloneMCJ_Entity *, const CloneMCJ_Entity *);
int CloneMCJ_EntityLiving_IsHostileType(CloneMCJ_MobType);
int CloneMCJ_EntityLiving_IsHostileNow(const CloneMCJ_Mob *);
int CloneMCJ_EntityLiving_GetMaxHealth(CloneMCJ_MobType, int);
float CloneMCJ_EntityLiving_GetCreeperFlash(const CloneMCJ_Mob *, float);
int CloneMCJ_PathEntity_GetPosition(const CloneMCJ_PathEntityNative *,
    const CloneMCJ_Entity *, CloneMCVec3D *);
void CloneMCJ_PathEntity_Increment(CloneMCJ_PathEntityNative *);
int CloneMCJ_EntityCreature_CreatePathToPlayer(CloneMCJ_Mob *, const CloneMCJ_EntityPlayer *, float);
int CloneMCJ_EntityAnimal_GetTalkIntervalNative(void);
int CloneMCJ_EntityMob_CanTargetPlayerNative(const CloneMCJ_Mob *,
    const CloneMCJ_EntityPlayer *, float);
int CloneMCJ_EntityWaterMob_CanBreatheUnderwaterNative(void);
int CloneMCJ_SpawnerAnimals_Tick(CloneMCJ_GameplayState *);
void CloneMCJ_EntityWolf_Tick(CloneMCJ_Mob *, CloneMCJ_EntityPlayer *);
int CloneMCJ_EntityWolf_Interact(CloneMCJ_Mob *, CloneMCJ_EntityPlayer *);
float CloneMCJ_EntityWolf_GetInterestedAngle(const CloneMCJ_Mob *, float);
float CloneMCJ_EntityWolf_GetShakeAngle(const CloneMCJ_Mob *, float, float);
float CloneMCJ_EntityWolf_GetShadingWhileShaking(const CloneMCJ_Mob *, float);
float CloneMCJ_EntityWolf_GetTailRotation(const CloneMCJ_Mob *);
int CloneMCJ_EntityWolf_GetTextureState(const CloneMCJ_Mob *);
int CloneMCJ_EntityPig_InteractNative(CloneMCJ_Mob *, CloneMCJ_EntityPlayer *);
int CloneMCJ_EntityPig_IsSaddledNative(const CloneMCJ_Mob *);
int CloneMCJ_EntitySheep_RandomFleeceColor(CloneMCJavaRandom *);
int CloneMCJ_EntitySheep_InteractNative(CloneMCJ_GameplayState *, CloneMCJ_Mob *,
    CloneMCJ_EntityPlayer *);
int CloneMCJ_EntityCow_InteractNative(CloneMCJ_Mob *, CloneMCJ_EntityPlayer *);
void CloneMCJ_EntityGiantZombie_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntityGhast_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntityPigZombie_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntityPigZombie_BecomeAngryNative(CloneMCJ_Mob *);
void CloneMCJ_EntityChicken_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntityCreeper_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntitySkeleton_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntitySlime_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntitySlime_SetSizeNative(CloneMCJ_Mob *, int);
void CloneMCJ_EntitySpider_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntitySquid_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntityZombie_InitializeNative(CloneMCJ_Mob *, struct CloneMCJ_WorldTag *,
    double, double, double);

void CloneMCJ_Projectile_Initialize(CloneMCJ_Projectile *, CloneMCJ_ProjectileType,
    struct CloneMCJ_WorldTag *, const CloneMCJ_Entity *, float, float);
void CloneMCJ_Projectile_SetHeading(CloneMCJ_Projectile *, double, double, double, float, float);
void CloneMCJ_Projectile_Tick(CloneMCJ_Projectile *, CloneMCJ_GameplayState *);
int CloneMCJ_Projectile_WriteNBT(const CloneMCJ_Projectile *, CloneMCJ_NBTTagCompound *);
int CloneMCJ_Projectile_ReadNBT(CloneMCJ_Projectile *, const CloneMCJ_NBTTagCompound *,
    struct CloneMCJ_WorldTag *);
int CloneMCJ_Gameplay_SpawnProjectile(CloneMCJ_GameplayState *, CloneMCJ_ProjectileType,
    const CloneMCJ_Entity *, float, float);
int CloneMCJ_EntityFish_Catch(CloneMCJ_Projectile *, CloneMCJ_GameplayState *);

/* Typed Java-class adapters retain the original inheritance split while the C
 * runtime shares bounded Projectile and Vehicle storage. */
void CloneMCJ_EntitySnowball_InitializeNative(CloneMCJ_Projectile *, struct CloneMCJ_WorldTag *,
    const CloneMCJ_Entity *);
void CloneMCJ_EntityEgg_InitializeNative(CloneMCJ_Projectile *, struct CloneMCJ_WorldTag *,
    const CloneMCJ_Entity *);
void CloneMCJ_EntityFireball_InitializeNative(CloneMCJ_Projectile *, struct CloneMCJ_WorldTag *,
    const CloneMCJ_Entity *, double, double, double);
void CloneMCJ_EntityFish_InitializeNative(CloneMCJ_Projectile *, struct CloneMCJ_WorldTag *,
    const CloneMCJ_Entity *);

void CloneMCJ_Vehicle_Initialize(CloneMCJ_Vehicle *, CloneMCJ_VehicleType,
    struct CloneMCJ_WorldTag *, double, double, double, int);
void CloneMCJ_Vehicle_Tick(CloneMCJ_Vehicle *, CloneMCJ_GameplayState *);
int CloneMCJ_EntityMinecart_RailPositionNative(struct CloneMCJ_WorldTag *,
    double, double, double, CloneMCVec3D *);
int CloneMCJ_EntityMinecart_RailPositionOffsetNative(struct CloneMCJ_WorldTag *,
    double, double, double, double, CloneMCVec3D *);
int CloneMCJ_Vehicle_Attack(CloneMCJ_Vehicle *, CloneMCJ_GameplayState *, int);
void CloneMCJ_Vehicle_ApplyCollision(CloneMCJ_Vehicle *, CloneMCJ_Vehicle *);
int CloneMCJ_Vehicle_ConfigurePainting(CloneMCJ_Vehicle *, int, int, int, int);
int CloneMCJ_Vehicle_WriteNBT(const CloneMCJ_Vehicle *, CloneMCJ_NBTTagCompound *);
int CloneMCJ_Vehicle_ReadNBT(CloneMCJ_Vehicle *, const CloneMCJ_NBTTagCompound *,
    struct CloneMCJ_WorldTag *);
int CloneMCJ_Gameplay_SpawnVehicle(CloneMCJ_GameplayState *, CloneMCJ_VehicleType,
    double, double, double, int);
int CloneMCJ_Gameplay_UsePortal(CloneMCJ_GameplayState *);
int CloneMCJ_Gameplay_ActivateBed(CloneMCJ_GameplayState *, int, int, int);
CloneMCJ_Vehicle *CloneMCJ_Gameplay_GetOpenVehicleInventory(CloneMCJ_GameplayState *);
CloneMCJ_Container *CloneMCJ_Gameplay_GetOpenContainer(CloneMCJ_GameplayState *);
int CloneMCJ_Gameplay_OpenPlayerContainer(CloneMCJ_GameplayState *);
int CloneMCJ_Gameplay_OpenBlockContainer(CloneMCJ_GameplayState *, int, int, int);
int CloneMCJ_Gameplay_CloseOpenContainer(CloneMCJ_GameplayState *);
int CloneMCJ_Gameplay_IsOpenContainerUsable(const CloneMCJ_GameplayState *);
void CloneMCJ_V136_RegisterVillageDoor(struct CloneMCJ_WorldTag *,
    int, int, int, int);
void CloneMCJ_V136_TickWorldSystems(CloneMCJ_GameplayState *);
void CloneMCJ_V136_TickVillager(CloneMCJ_Mob *, CloneMCJ_EntityPlayer *);
void CloneMCJ_V136_InitializeVillagerTrades(CloneMCJ_Mob *);
int CloneMCJ_V136_OpenMerchant(CloneMCJ_GameplayState *, int);
int CloneMCJ_V136_SelectMerchantTrade(CloneMCJ_GameplayState *, int);
int CloneMCJ_V136_CompleteMerchantTrade(CloneMCJ_GameplayState *);
void CloneMCJ_V136_RefreshMerchantResult(CloneMCJ_GameplayState *);
void CloneMCJ_V136_UpdateDragon(CloneMCJ_Mob *, CloneMCJ_EntityPlayer *);
int CloneMCJ_V136_DamageDragon(CloneMCJ_GameplayState *, CloneMCJ_Mob *, int);
int CloneMCJ_V136_DamageDragonAt(CloneMCJ_GameplayState *,CloneMCJ_Mob *,
    const CloneMCJ_Entity *,double,double,double,int);
int CloneMCJ_V136_TickDragonDeath(CloneMCJ_GameplayState *, CloneMCJ_Mob *);
const CloneMCJ_DragonNative *CloneMCJ_V136_GetDragonState(
    const CloneMCJ_GameplayState *, int);
int CloneMCJ_V136_RunGameplaySelfTests(char *, unsigned int);
void CloneMCJ_EntityMinecart_InitializeNative(CloneMCJ_Vehicle *, struct CloneMCJ_WorldTag *,
    double, double, double, int);
void CloneMCJ_EntityPainting_InitializeNative(CloneMCJ_Vehicle *, struct CloneMCJ_WorldTag *,
    int, int, int, int, const char *);
void CloneMCJ_EntityTNTPrimed_InitializeNative(CloneMCJ_Vehicle *, struct CloneMCJ_WorldTag *,
    double, double, double);
void CloneMCJ_EntityFallingSand_InitializeNative(CloneMCJ_Vehicle *, struct CloneMCJ_WorldTag *,
    double, double, double, int, int);
void CloneMCJ_EntityLightningBolt_InitializeNative(CloneMCJ_Vehicle *, struct CloneMCJ_WorldTag *,
    double, double, double);

const char *CloneMCJ_EntityList_NameForMob(CloneMCJ_MobType);
int CloneMCJ_EntityList_MobTypeForName(const char *, CloneMCJ_MobType *);
const char *CloneMCJ_EntityList_NameForNumericID(int);
int CloneMCJ_EntityList_NumericIDForName(const char *);
int CloneMCJ_Mob_WriteNBT(const CloneMCJ_Mob *, CloneMCJ_NBTTagCompound *);
int CloneMCJ_Mob_ReadNBT(CloneMCJ_Mob *, const CloneMCJ_NBTTagCompound *,
    struct CloneMCJ_WorldTag *);

void CloneMCJ_Entity_Initialize(CloneMCJ_Entity *, struct CloneMCJ_WorldTag *);
void CloneMCJ_Entity_SetSize(CloneMCJ_Entity *, float, float);
void CloneMCJ_Entity_SetPosition(CloneMCJ_Entity *, double, double, double);
void CloneMCJ_Entity_SetRotation(CloneMCJ_Entity *, float, float);
void CloneMCJ_Entity_MoveFlying(CloneMCJ_Entity *, float, float, float);
int CloneMCJ_Entity_CanUpdateSafely(const CloneMCJ_Entity *, double, double, double);
int CloneMCJ_Entity_CanMoveSafely(const CloneMCJ_Entity *, double, double, double);
void CloneMCJ_Entity_Move(CloneMCJ_Entity *, double, double, double);
int CloneMCJ_Entity_IsInsideMaterial(const CloneMCJ_Entity *, CloneMCJ_MaterialKind);
int CloneMCJ_Entity_WriteNBT(const CloneMCJ_Entity *, CloneMCJ_NBTTagCompound *, const char *);
int CloneMCJ_Entity_ReadNBT(CloneMCJ_Entity *, const CloneMCJ_NBTTagCompound *);

void CloneMCJ_EntityPlayer_Initialize(CloneMCJ_EntityPlayer *, struct CloneMCJ_WorldTag *, const char *);
void CloneMCJ_EntityPlayer_SetInPortal(CloneMCJ_EntityPlayer *);
void CloneMCJ_EntityPlayer_Tick(CloneMCJ_EntityPlayer *);
int CloneMCJ_EntityPlayer_AttackFrom(CloneMCJ_EntityPlayer *, const CloneMCJ_Entity *, int);
void CloneMCJ_EntityPlayer_SetInput(CloneMCJ_EntityPlayer *, float, float, int, int);
int CloneMCJ_EntityPlayer_CanSprint(const CloneMCJ_EntityPlayer *);
void CloneMCJ_EntityPlayer_SetSprinting(CloneMCJ_EntityPlayer *, int);
int CloneMCJ_EntityPlayer_IsSprinting(const CloneMCJ_EntityPlayer *);
int CloneMCJ_EntityPlayer_TrySleep(CloneMCJ_EntityPlayer *, int, int, int);
void CloneMCJ_EntityPlayer_Wake(CloneMCJ_EntityPlayer *, int, int);
int CloneMCJ_EntityPlayer_FindSafeBedSpawn(struct CloneMCJ_WorldTag *, int, int, int, int *, int *, int *);
int CloneMCJ_EntityPlayer_WriteNBT(const CloneMCJ_EntityPlayer *, CloneMCJ_NBTTagCompound *);
int CloneMCJ_EntityPlayer_ReadNBT(CloneMCJ_EntityPlayer *, const CloneMCJ_NBTTagCompound *);

void CloneMCJ_EntityItem_Initialize(CloneMCJ_EntityItem *, struct CloneMCJ_WorldTag *,
    double, double, double, const CloneMCJ_ItemStack *);
int CloneMCJ_EntityItem_AttackEntityFrom(CloneMCJ_EntityItem *, int);
int CloneMCJ_EntityItem_CanUpdate(const CloneMCJ_EntityItem *);
void CloneMCJ_EntityItem_TickLoaded(CloneMCJ_EntityItem *);
void CloneMCJ_EntityItem_Tick(CloneMCJ_EntityItem *);
int CloneMCJ_EntityItem_TryPickup(CloneMCJ_EntityItem *, CloneMCJ_EntityPlayer *);
int CloneMCJ_EntityItem_WriteNBT(const CloneMCJ_EntityItem *, CloneMCJ_NBTTagCompound *);
int CloneMCJ_EntityItem_ReadNBT(CloneMCJ_EntityItem *, const CloneMCJ_NBTTagCompound *, struct CloneMCJ_WorldTag *);

void CloneMCJ_PlayerControllerSP_Initialize(CloneMCJ_PlayerControllerSP *, struct CloneMCJ_WorldTag *, CloneMCJ_EntityPlayer *);
int CloneMCJ_PlayerControllerSP_ClickBlock(CloneMCJ_PlayerControllerSP *, int, int, int);
int CloneMCJ_PlayerControllerSP_DamageBlock(CloneMCJ_PlayerControllerSP *, int, int, int);
int CloneMCJ_PlayerControllerSP_HarvestBlock(CloneMCJ_PlayerControllerSP *, int, int, int);
int CloneMCJ_PlayerControllerSP_PlaceBlock(CloneMCJ_PlayerControllerSP *, int, int, int, int);

void CloneMCJ_Gameplay_QueueBlockBreakEvent(CloneMCJ_GameplayState *,int,int,int,int,int);
int CloneMCJ_Gameplay_GetBlockBreakEvent(const CloneMCJ_GameplayState *,unsigned long,CloneMCJ_BlockBreakEvent *);
void CloneMCJ_Gameplay_Initialize(CloneMCJ_GameplayState *, struct CloneMCJ_WorldTag *, const char *);
void CloneMCJ_Gameplay_Destroy(CloneMCJ_GameplayState *);
void CloneMCJ_Gameplay_SetInput(CloneMCJ_GameplayState *, float, float, int, int, int, int);
void CloneMCJ_Gameplay_AddLook(CloneMCJ_GameplayState *, float, float);
void CloneMCJ_Gameplay_Tick(struct CloneMCJ_WorldTag *, void *);
void CloneMCJ_Gameplay_SetMultiplayerIntentHooks(CloneMCJ_GameplayState *, void *,
    int (*)(void *, int, int, int, int, int),
    int (*)(void *, int, int, int, int, const CloneMCJ_ItemStack *));
int CloneMCJ_Gameplay_DropCurrentItem(CloneMCJ_GameplayState *, int);
void CloneMCJ_Gameplay_HandlePlayerDeath(CloneMCJ_GameplayState *);
void CloneMCJ_Gameplay_RespawnPlayer(CloneMCJ_GameplayState *);
int CloneMCJ_Explosion_Execute(struct CloneMCJ_WorldTag *, const CloneMCJ_Entity *,
    double, double, double, float, int);
int CloneMCJ_Gameplay_GetExplosionEvent(const CloneMCJ_GameplayState *, unsigned long,
    CloneMCJ_ExplosionEvent *);
void CloneMCJ_Gameplay_QueueAudioEvent(CloneMCJ_GameplayState *,const char *,
    float,float,float,float,float,int);
int CloneMCJ_Gameplay_GetAudioEvent(const CloneMCJ_GameplayState *,unsigned long,
    CloneMCJ_GameplayAudioEvent *);
int CloneMCJ_Gameplay_SpawnDrop(CloneMCJ_GameplayState *, double, double, double,
    const CloneMCJ_ItemStack *, int, int);
CloneMCJ_EntityItem *CloneMCJ_Gameplay_SpawnDropEntity(CloneMCJ_GameplayState *,
    double, double, double, const CloneMCJ_ItemStack *, int, int);
int CloneMCJ_Gameplay_GetDropQueueCapacity(const CloneMCJ_GameplayState *);
void CloneMCJ_Gameplay_FlushPendingDrops(CloneMCJ_GameplayState *);
CloneMCJ_MovingObjectPosition CloneMCJ_Gameplay_RayTrace(const CloneMCJ_EntityPlayer *, double);
int CloneMCJ_Gameplay_FindTargetMob(const CloneMCJ_GameplayState *, double, double *);
int CloneMCJ_Gameplay_AttackMob(CloneMCJ_GameplayState *, int);
int CloneMCJ_Gameplay_InteractMob(CloneMCJ_GameplayState *, int);
void CloneMCJ_Gameplay_AttachSaveHooks(CloneMCJ_GameplayState *);
/* Fixed-capacity post-Beta progression extension. */
void CloneMCJ_Progression_AddExperience(CloneMCJ_EntityPlayer *, int);
int CloneMCJ_Progression_AttackPlayerProtected(CloneMCJ_EntityPlayer *,
    const CloneMCJ_Entity *, int, int);
void CloneMCJ_Progression_SpawnExperience(CloneMCJ_GameplayState *,
    double, double, double, int);
void CloneMCJ_Progression_ApplySplashPotion(CloneMCJ_GameplayState *,
    double, double, double, int);
void CloneMCJ_Progression_TickExperienceOrbs(CloneMCJ_GameplayState *);
void CloneMCJ_Progression_TickPlayerEffects(CloneMCJ_EntityPlayer *);
void CloneMCJ_Progression_TickMobEffects(CloneMCJ_Mob *);
int CloneMCJ_PotionHelper_ApplyIngredient(int,const char *);
const char *CloneMCJ_PotionHelper_IngredientEffect(int);
int CloneMCJ_PotionHelper_Result(int,int);
int CloneMCJ_PotionHelper_GetEffects(int,int,CloneMCJ_PotionEffectNative *,int);
int CloneMCJ_PotionHelper_EffectsEqual(int,int);
int CloneMCJ_PotionHelper_Color(int);
int CloneMCJ_Progression_HasEffect(const CloneMCJ_EntityPlayer *, int, int *);
int CloneMCJ_Progression_EnchantLevel(const CloneMCJ_ItemStack *, int);
int CloneMCJ_Progression_EnchantStackRandom(CloneMCJ_ItemStack *, int,
    CloneMCJavaRandom *);
int CloneMCJ_Progression_OpenBlock(CloneMCJ_GameplayState *, int, int, int, int);
void CloneMCJ_Progression_RefreshEnchantOffers(CloneMCJ_GameplayState *);
int CloneMCJ_Progression_ClickEnchant(CloneMCJ_GameplayState *, int);
void CloneMCJ_Progression_InitializeBrewingContainer(CloneMCJ_Container *,
    CloneMCJ_InventoryPlayer *, CloneMCJ_TileEntity *);
void CloneMCJ_Progression_TickBrewing(CloneMCJ_TileEntity *);
void CloneMCJ_Progression_RegisterWorldTicks(struct CloneMCJ_WorldTag *);
int CloneMCJ_Progression_IsBrewingIngredient(int);
int CloneMCJ_Progression_PotionResult(int, int);
int CloneMCJ_Progression_UsePotion(CloneMCJ_GameplayState *, CloneMCJ_ItemStack *);
int CloneMCJ_Progression_InteractBreeding(CloneMCJ_GameplayState *, CloneMCJ_Mob *);
void CloneMCJ_Progression_TickBreeding(CloneMCJ_GameplayState *);
int CloneMCJ_Progression_RunSelfTests(char *, unsigned int);
int CloneMCJ_Gameplay_PrepareSave(struct CloneMCJ_WorldTag *, void *);
void CloneMCJ_Gameplay_OnDimensionChanged(struct CloneMCJ_WorldTag *, void *, int);
int CloneMCJ_Priority7_RunSelfTests(char *, unsigned int);
int CloneMCJ_Priority12_RunSelfTests(char *, unsigned int);
int CloneMCJ_Priority14_RunSelfTests(char *, unsigned int);
int CloneMCJ_Priority16_RunSelfTests(char *, unsigned int);

#ifdef __cplusplus
}
#endif

#endif /* CLONEMC_JAVA_PORT_20_ENTITY_H */
