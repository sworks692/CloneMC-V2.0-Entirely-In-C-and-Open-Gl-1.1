# CloneMC V135 Java 1.2.3 piston/villager/content build for Open
# Watcom V2.0.  Retains the cumulative gameplay/GUI/UV/performance corrections,
# Win32/OpenGL 1.1 rendering, and the uploaded Java implementation as the
# Beta gameplay authority while adding bounded release-era progression.
# Build from the project root with: wmake -f Makefile.wat
#
# SOURCE GRAPH
#   project2finalalpharecreation.c
#     -> 9 subsystem .inc manifests
#       -> 678 native C modules including the fixed-capacity progression extension
#         -> exactly 10 shared subsystem .h files
#     -> registry .inc and registry .h
#
# Open Watcom compiles the complete graph above as one translation unit and one
# object. WLINK must receive that object, not the source/header files themselves.
# The .SYMBOLIC dependency forces recompilation so edits to any included C, H,
# or INC file are recognized without maintaining a fragile dependency list.

EXE = CloneMC_V135_Java123_PistonVillage_Parity_Win98.exe
OBJ = project2finalalpharecreation.obj
SRC = project2finalalpharecreation.c
LNK = clonemc_v135_java123_piston_village_win98.lnk

all: $(EXE)

$(OBJ): .SYMBOLIC
	wcc386 -q -bt=nt -dWINVER=0x0400 -d_WIN32_WINNT=0x0400 -dCLONEMC_PRIORITY2=1 -dCLONEMC_PRIORITY3_REAL_CHUNKS=1 -dCLONEMC_PRIORITY4_JAVA_TERRAIN=1 -dCLONEMC_PRIORITY5_NATIVE_SAVE=1 -dCLONEMC_PRIORITY6_FIXED_WORLD=1 -dCLONEMC_PRIORITY7_GAMEPLAY=1 -dCLONEMC_PRIORITY8_RENDERER=1 -dCLONEMC_PRIORITY9_PRESENTATION=1 -dCLONEMC_PRIORITY10_MULTIPLAYER=1 -dCLONEMC_PRIORITY11_WORLD_SIMULATION=1 -dCLONEMC_PRIORITY12_ENTITIES_AI=1 -dCLONEMC_PRIORITY13_AUDIO_MULTIPLAYER_STABILITY=1 -dCLONEMC_PRIORITY13_CRAFTING_CONTAINERS=1 -dCLONEMC_PRIORITY14_MOB_AI_COMBAT=1 -dCLONEMC_V111_WORLD_STREAMING_TEXTURES=1 -dCLONEMC_V114_TEXTURE_CHUNK_STABILITY=1 -dCLONEMC_V116_SAVE_INVENTORY_NETWORK_CHUNK_RECOVERY=1 -dCLONEMC_V117_WORLD_CREATION_SAVE_GUI_PERFORMANCE=1 -dCLONEMC_V118_PERSISTENCE_MINING_MOB_UV_VISIBILITY=1 -dCLONEMC_V119_CHUNK_RENDERING_VISIBILITY_SAVEQUIT=1 -dCLONEMC_V120_RENDER_STATE_SAVE_GUI=1 -dCLONEMC_V121_PRIORITY17_FRAME_PACING_REGION_RECOVERY=1 -dCLONEMC_V122_SAVE_GAMEPLAY_ENTITY_FLUID_FIDELITY=1 -dCLONEMC_V123_SAVE_TIMEOUT_TOOLS_LIGHTING_REDSTONE_BOAT=1 -dCLONEMC_V125_REDSTONE_PISTON_BREAK_ARMOR=1 -dCLONEMC_V126_WOOL_REDSTONE_BUCKET_LIGHT_SIGN_BIOME=1 -dCLONEMC_PRIORITIES345_FIDELITY=1 -fo=$(OBJ) $(SRC)

$(EXE): $(OBJ) $(LNK)
	wlink @$(LNK)

clean: .SYMBOLIC
	@if exist $(EXE) del $(EXE)
	@if exist $(OBJ) del $(OBJ)
	@if exist CloneMC_V126_WoolRedstoneBucketsLightingSignsBiomes.map del CloneMC_V126_WoolRedstoneBucketsLightingSignsBiomes.map

rebuild: .SYMBOLIC
	@wmake -f Makefile.wat clean
	@wmake -f Makefile.wat all

help: .SYMBOLIC
	@echo CloneMC Open Watcom build targets:
	@echo   wmake -f Makefile.wat          build the Win32 executable
	@echo   wmake -f Makefile.wat rebuild  clean and rebuild
	@echo   wmake -f Makefile.wat clean    remove generated object, EXE and map
