#ifndef CLONEMC_VERSION_H
#define CLONEMC_VERSION_H

/*
 * Single authoritative build identity for the cumulative V135 release.
 * Keep this header C89/preprocessor-only so Open Watcom V2.0 can include it
 * from the unity build, individual development objects, and resource scripts.
 */
#define CLONEMC_VERSION_MAJOR 135
#define CLONEMC_VERSION_MINOR 0
#define CLONEMC_VERSION_PATCH 0
#define CLONEMC_VERSION_TEXT "V135.0.0"
#define CLONEMC_VERSION_CHANNEL "Java 1.2.3 Piston, Villager and Content Integration"
#define CLONEMC_VERSION_DISPLAY "CloneMC V135.0.0 Java 1.2.3 Piston, Villager and Content Integration"
#define CLONEMC_REFERENCE_JAVA_MODULES 675UL
#define CLONEMC_NATIVE_TEST_MODULES 2UL
#define CLONEMC_TOTAL_C_MODULES 678UL
#define CLONEMC_REFERENCE_ARCHIVE_SHA256 \
    "6fbebcf97d2bbc1f28cdce3a3abe7b6d9267cdfd998c3979ac7a7f712c5a87d2"
#define CLONEMC_REFERENCE_MANIFEST_SHA256 \
    "63b0efb1ebe3cf228f162fad099cc1faae37cd45f65c7cd53500e8919ddc7dd1"
#define CLONEMC_PARITY_MANIFEST_SHA256 \
    "1dc371d3a703d06ee763a9e50abe49a93f3e53f6d04775f78523218fe4a1e5c0"
#define CLONEMC_SOURCE_ARCHIVE_SHA256 \
    "5f15fbc4f0535b58903ea95ef262e3aedae184cca8abc2b684ff48c7111e15f5"
#define CLONEMC_POST_BETA_ASSET_ARCHIVE_SHA256 \
    "dd233df240077e5f263780dc1a4b02702d102a098b6f52fab0a644d4e89967a0"
#define CLONEMC_LICENSE_SHA256 \
    "d90ce01c204f5cbc173088e8ef27ebe348a49124005d7043bf4d1b50d18fca4d"
#define CLONEMC_BUILD_PROFILE "win32-x86-c89-opengl11-win98-winsock2-v135"

#endif
