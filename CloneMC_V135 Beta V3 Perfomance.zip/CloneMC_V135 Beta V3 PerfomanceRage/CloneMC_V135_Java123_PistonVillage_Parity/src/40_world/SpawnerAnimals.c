/*
 * CloneMC Java port scaffold: SpawnerAnimals
 *
 * Java source: SpawnerAnimals.java
 * Java type: class SpawnerAnimals
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 1993c4ac9c49db6752d05400a1a4b4593cfd03f126f3cc3f15d94dd54318e957
 * Java lines: 299
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: World, ChunkPosition, EntityPlayer, MathHelper, ChunkCoordIntPair, EnumCreatureType, WorldChunkManager, BiomeGenBase, SpawnListEntry, ChunkCoordinates, EntityLiving, Material, EntitySpider, EntitySkeleton, EntitySheep, Pathfinder, PathEntity, PathPoint, BlockBed, EntityZombie, l, else
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected static final Class nightSpawnEntities[]
 *
 * Java method/constructor inventory:
 * - public SpawnerAnimals()
 * - protected static ChunkPosition getRandomSpawningPointInChunk(World world, int i, int j)
 * - public static final int performSpawning(World var0, boolean var1, boolean var2)
 * - private static boolean canCreatureTypeSpawnAtLocation(EnumCreatureType enumcreaturetype, World world, int i, int j, int k)
 * - private static void creatureSpecificInit(EntityLiving entityliving, World world, float f, float f1, float f2)
 * - public static boolean performSleepSpawning(World world, List list)
 * - private static Set eligibleChunksForSpawning = new HashSet()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"

static int CloneMCJ_SpawnerAnimals_IsMonster(CloneMCJ_MobType type)
{
    return CloneMCJ_EntityLiving_IsHostileType(type);
}

static int CloneMCJ_SpawnerAnimals_GroupMaximum(CloneMCJ_MobType type)
{
    switch(type){
    case CLONEMC_J_MOB_GHAST:return 1;
    case CLONEMC_J_MOB_WOLF:return 4;
    case CLONEMC_J_MOB_SQUID:return 4;
    default:return 4;
    }
}

static CloneMCJ_MobType CloneMCJ_SpawnerAnimals_ChooseType(CloneMCJ_World *world,
    int category,int x,int z)
{
    int roll,total;
    const CloneMCJ_BiomeGenBase *biome;
    if(!world)return CLONEMC_J_MOB_TYPE_COUNT;
    if(world->worldInfo.dimension==-1){
        if(category!=0)return CLONEMC_J_MOB_TYPE_COUNT;
        /* MapGenNetherBridge supplies its own 1.2.3 spawn table only while
         * the sampled position is inside a fortress component. */
        if(CloneMCJ_ChunkProviderHell_IsFortressAt(
            world->randomSeed,x,z)){
            roll=CloneMCJavaRandom_NextIntBound(&world->rand,23);
            if(roll<10)return CLONEMC_J_MOB_BLAZE;
            if(roll<20)return CLONEMC_J_MOB_PIG_ZOMBIE;
            return CLONEMC_J_MOB_MAGMA_CUBE;
        }
        roll=CloneMCJavaRandom_NextIntBound(&world->rand,151);
        if(roll<50)return CLONEMC_J_MOB_GHAST;
        if(roll<150)return CLONEMC_J_MOB_PIG_ZOMBIE;
        return CLONEMC_J_MOB_MAGMA_CUBE;
    }
    if(world->worldInfo.dimension==1)
        return category==0?CLONEMC_J_MOB_ENDERMAN:
            CLONEMC_J_MOB_TYPE_COUNT;
    if(category==0){
        roll=CloneMCJavaRandom_NextIntBound(&world->rand,100);
        if(roll<20)return CLONEMC_J_MOB_SPIDER;
        if(roll<40)return CLONEMC_J_MOB_ZOMBIE;
        if(roll<60)return CLONEMC_J_MOB_SKELETON;
        if(roll<80)return CLONEMC_J_MOB_CREEPER;
        return CLONEMC_J_MOB_SLIME;
    }
    if(category==2)return CLONEMC_J_MOB_SQUID;
    biome=CloneMCJ_WorldChunkManager_GetBiomeGenAt(&world->chunkManager,x,z);
    total=40;
    if(biome&&(biome->biomeID==CLONEMC_J_BIOME_FOREST||
        biome->biomeID==CLONEMC_J_BIOME_TAIGA))total+=2;
    roll=CloneMCJavaRandom_NextIntBound(&world->rand,total);
    if(roll<12)return CLONEMC_J_MOB_SHEEP;
    if(roll<22)return CLONEMC_J_MOB_PIG;
    if(roll<32)return CLONEMC_J_MOB_CHICKEN;
    if(roll<40)return CLONEMC_J_MOB_COW;
    return CLONEMC_J_MOB_WOLF;
}

static int CloneMCJ_SpawnerAnimals_EligibleChunkCount(const CloneMCJ_World *world)
{
    int radius,side;
    if(!world)return 0;
    radius=world->activeRadius;if(radius<2)radius=2;if(radius>8)radius=8;
    side=radius*2+1;return side*side;
}

static int CloneMCJ_SpawnerAnimals_CategoryCap(const CloneMCJ_World *world,int category)
{
    int base,eligible,cap;
    base=category==0?70:(category==1?15:5);
    eligible=CloneMCJ_SpawnerAnimals_EligibleChunkCount(world);
    cap=base*eligible/256;if(cap<1)cap=1;
    if(cap>CLONEMC_J_MAX_MOBS)cap=CLONEMC_J_MAX_MOBS;
    return cap;
}

static int CloneMCJ_SpawnerAnimals_CountNearChunk(const CloneMCJ_GameplayState *state,
    CloneMCJ_MobType type,int chunkX,int chunkZ)
{
    int index,count,mx,mz;
    count=0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)if(state->mobs[index].active&&
        state->mobs[index].type==type){
        mx=CloneMCJava_FloorDouble(state->mobs[index].entity.posX/16.0);
        mz=CloneMCJava_FloorDouble(state->mobs[index].entity.posZ/16.0);
        if(mx==chunkX&&mz==chunkZ)++count;
    }
    return count;
}

static int CloneMCJ_SpawnerAnimals_CanSpawnAt(CloneMCJ_World *world,
    CloneMCJ_MobType type,int category,int x,int y,int z)
{
    int id,above,belowID,light,skyLight;
    const CloneMCJ_BlockDefinition *block,*below;
    if(!world||y<1||y>=CLONEMC_J_CHUNK_HEIGHT-2)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    above=CloneMCJ_World_GetBlockId(world,x,y+1,z);
    belowID=CloneMCJ_World_GetBlockId(world,x,y-1,z);
    block=CloneMCJ_BlockRegistry_Get(id);below=CloneMCJ_BlockRegistry_Get(belowID);
    if(category==2){
        if(id!=8&&id!=9)return 0;
        if(above!=8&&above!=9&&above!=0)return 0;
        return 1;
    }
    if(type==CLONEMC_J_MOB_GHAST){
        if(id!=0||above!=0||CloneMCJ_World_GetBlockId(world,x,y+2,z)!=0||
            CloneMCJ_World_GetBlockId(world,x,y+3,z)!=0)return 0;
        return 1;
    }
    if(!below||!below->solid||belowID==7)return 0;
    if((block&&block->solid)||id!=0||above!=0)return 0;
    if(category==1){
        if(belowID!=2)return 0;
        if(CloneMCJ_World_GetFullBlockLightValue(world,x,y,z)<=8)return 0;
    }else{
        skyLight=CloneMCJ_World_GetSavedLightValue(world,CLONEMC_J_ENUM_SKY_BLOCK_SKY,x,y,z);
        if(skyLight>CloneMCJavaRandom_NextIntBound(&world->rand,32))return 0;
        light=CloneMCJ_World_GetBlockLightValue(world,x,y,z);
        if(light>CloneMCJavaRandom_NextIntBound(&world->rand,8))return 0;
        if(type==CLONEMC_J_MOB_SLIME){
            int chunkX,chunkZ;
            chunkX=CloneMCJava_FloorDouble((double)x/16.0);
            chunkZ=CloneMCJava_FloorDouble((double)z/16.0);
            if(y>=16||CloneMCJavaRandom_NextIntBound(&world->rand,10)!=0||
                (((chunkX*4987142)^(chunkZ*5947611)^(int)world->randomSeed)&9)!=0)return 0;
        }
    }
    return 1;
}

static int CloneMCJ_SpawnerAnimals_FindFreeSlot(CloneMCJ_GameplayState *state)
{
    int index;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)if(!state->mobs[index].active)return index;
    return -1;
}

int CloneMCJ_SpawnerAnimals_Tick(CloneMCJ_GameplayState *state)
{
    CloneMCJ_World *world;
    CloneMCJ_Chunk *chunk;
    CloneMCJ_MobType type;
    int active,hostile,passive,water,index,category,cap,radius;
    int chunkX,chunkZ,x,y,z,baseX,baseY,baseZ,group,attempt,slot;
    int playerX,playerZ,spawnDX,spawnDZ,spawned,categorySpawned,groupMax;
    int height,localCount;
    if(!state||!state->world)return 0;
    world=state->world;if(world->multiplayerWorld)return 0;
    active=hostile=passive=water=0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)if(state->mobs[index].active){
        ++active;
        if(state->mobs[index].type==CLONEMC_J_MOB_SQUID)++water;
        else if(CloneMCJ_SpawnerAnimals_IsMonster(state->mobs[index].type))++hostile;
        else ++passive;
    }
    state->mobCount=active;if(active>=CLONEMC_J_MAX_MOBS)return 0;
    playerX=CloneMCJava_FloorDouble(state->player.entity.posX);
    playerZ=CloneMCJava_FloorDouble(state->player.entity.posZ);
    radius=world->activeRadius;if(radius<2)radius=2;if(radius>8)radius=8;
    spawned=0;
    for(category=0;category<3;++category){
        categorySpawned=0;cap=CloneMCJ_SpawnerAnimals_CategoryCap(world,category);
        if(category==0){if(hostile>=cap)continue;}
        else if(category==1){if((state->ticksRun%400UL)!=0UL||passive>=cap)continue;}
        else{if(water>=cap)continue;}
        chunkX=CloneMCJava_FloorDouble(state->player.entity.posX/16.0)+
            CloneMCJavaRandom_NextIntBound(&world->rand,radius*2+1)-radius;
        chunkZ=CloneMCJava_FloorDouble(state->player.entity.posZ/16.0)+
            CloneMCJavaRandom_NextIntBound(&world->rand,radius*2+1)-radius;
        if(!CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(&world->chunkProvider,chunkX,chunkZ))continue;
        chunk=CloneMCJ_ChunkProviderLoadOrGenerate_ProvideChunk(&world->chunkProvider,chunkX,chunkZ);
        if(!chunk)continue;
        baseX=chunkX*16+CloneMCJavaRandom_NextIntBound(&world->rand,16);
        baseZ=chunkZ*16+CloneMCJavaRandom_NextIntBound(&world->rand,16);
        height=CloneMCJ_Chunk_GetHeightValue(chunk,baseX&15,baseZ&15);
        if(height<2)height=2;
        if(height>=CLONEMC_J_CHUNK_HEIGHT)height=CLONEMC_J_CHUNK_HEIGHT-1;
        if(category==1)baseY=height;
        else baseY=CloneMCJavaRandom_NextIntBound(&world->rand,height+1);
        type=CloneMCJ_SpawnerAnimals_ChooseType(world,category,baseX,baseZ);
        if(type==CLONEMC_J_MOB_TYPE_COUNT)continue;
        groupMax=CloneMCJ_SpawnerAnimals_GroupMaximum(type);
        localCount=CloneMCJ_SpawnerAnimals_CountNearChunk(state,type,chunkX,chunkZ);
        if(localCount>=groupMax)continue;
        for(group=0;group<3&&categorySpawned<groupMax-localCount;++group){
            x=baseX;y=baseY;z=baseZ;
            for(attempt=0;attempt<4&&categorySpawned<groupMax-localCount;++attempt){
                x+=CloneMCJavaRandom_NextIntBound(&world->rand,6)-CloneMCJavaRandom_NextIntBound(&world->rand,6);
                z+=CloneMCJavaRandom_NextIntBound(&world->rand,6)-CloneMCJavaRandom_NextIntBound(&world->rand,6);
                if(category!=1)y=baseY+CloneMCJavaRandom_NextIntBound(&world->rand,3)-1;
                spawnDX=x-playerX;spawnDZ=z-playerZ;
                if(spawnDX*spawnDX+spawnDZ*spawnDZ<576)continue;
                spawnDX=x-world->worldInfo.spawnX;spawnDZ=z-world->worldInfo.spawnZ;
                if(spawnDX*spawnDX+spawnDZ*spawnDZ<576)continue;
                if(!CloneMCJ_SpawnerAnimals_CanSpawnAt(world,type,category,x,y,z))continue;
                if((category==0&&hostile>=cap)||(category==1&&passive>=cap)||
                    (category==2&&water>=cap))break;
                slot=CloneMCJ_SpawnerAnimals_FindFreeSlot(state);
                if(slot<0){state->mobCount=active;return spawned;}
                CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],type,world,
                    (double)x+0.5,(double)y,(double)z+0.5);
                state->mobs[slot].persistenceRequired=0;
                if(state->nextEntityId<=state->mobs[slot].entity.entityId)
                    state->nextEntityId=state->mobs[slot].entity.entityId+1;
                ++spawned;++categorySpawned;++active;
                if(category==0)++hostile;else if(category==1)++passive;else ++water;
                if(type==CLONEMC_J_MOB_SPIDER&&hostile<cap&&
                    active<CLONEMC_J_MAX_MOBS&&
                    CloneMCJavaRandom_NextIntBound(&world->rand,100)==0){
                    int rider;
                    rider=CloneMCJ_SpawnerAnimals_FindFreeSlot(state);
                    if(rider>=0){
                        CloneMCJ_EntityLiving_InitializeMob(&state->mobs[rider],
                            CLONEMC_J_MOB_SKELETON,world,(double)x+0.5,(double)y,(double)z+0.5);
                        state->mobs[rider].persistenceRequired=0;
                        state->mobs[rider].riderEntityId=state->mobs[slot].entity.entityId;
                        if(state->nextEntityId<=state->mobs[rider].entity.entityId)
                            state->nextEntityId=state->mobs[rider].entity.entityId+1;
                        ++spawned;++categorySpawned;++active;++hostile;
                    }
                }
                if(active>=CLONEMC_J_MAX_MOBS){state->mobCount=active;return spawned;}
                if(type==CLONEMC_J_MOB_GHAST){state->mobCount=active;return spawned;}
            }
        }
    }
    state->mobCount=active;return spawned;
}

void CloneMCJ_SpawnerAnimals_Register(void)
{
    /* Priority 14 uses bounded eligible-chunk caps and grouped spawn attempts. */
}

const char *CloneMCJ_SpawnerAnimals_JavaName(void)
{
    return "net.minecraft.src.SpawnerAnimals";
}

const char *CloneMCJ_SpawnerAnimals_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_SpawnerAnimals_JavaSourceHash32(void)
{
    return 0x1993C4ACUL;
}
