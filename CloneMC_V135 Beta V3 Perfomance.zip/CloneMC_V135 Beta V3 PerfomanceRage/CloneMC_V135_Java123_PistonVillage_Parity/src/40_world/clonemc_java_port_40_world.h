/*
 * CloneMC V90 shared world/chunk/terrain declarations.
 *
 * This is one of the original ten project headers. Java-named classes remain
 * separate C files for editability, while this subsystem header owns all public
 * structs and prototypes for Priority 3 real chunks and Priority 4 terrain.
 */
#ifndef CLONEMC_JAVA_PORT_40_WORLD_H
#define CLONEMC_JAVA_PORT_40_WORLD_H

#include "../00_core/clonemc_java_port_00_core.h"
#include "../50_lighting/clonemc_java_port_50_lighting.h"

#ifdef __cplusplus
extern "C" {
#endif

struct CloneMCJ_EntityTag;

#define CLONEMC_J_CHUNK_WIDTH 16
#define CLONEMC_J_CHUNK_HEIGHT 128
#define CLONEMC_J_CHUNK_COLUMNS 256
#define CLONEMC_J_CHUNK_ENTITY_SLICES 8
#define CLONEMC_J_CHUNK_MAX_ENTITIES_PER_SLICE 64
#define CLONEMC_J_CHUNK_MAX_TILE_ENTITIES 256
#define CLONEMC_J_CHUNK_MAX_SCHEDULED_TICKS 256
#define CLONEMC_J_BLOCK_AIR 0
#define CLONEMC_J_CHUNK_BLOCK_MAP_SIZE 256
#define CLONEMC_J_CHUNK_PROVIDER_RADIUS 33
/* V114 retains the modern-style 2..32 chunk slider.  Streaming uses Manhattan
 * rings instead of a 65x65 square, so radius 32 has 2,113 candidates instead
 * of 4,225.  Chunks are still admitted one at a time and meshes have a separate
 * memory budget; choosing 32 never means generating the whole area at startup. */
#define CLONEMC_J_CHUNK_STREAM_MAX_RADIUS 32
#define CLONEMC_J_CHUNK_STREAM_MAX_TARGET 128
#define CLONEMC_J_CHUNK_STREAM_SCAN_PER_TICK 16
#define CLONEMC_J_POPULATION_QUEUE_CAPACITY 128
#define CLONEMC_J_CHUNK_STREAM_UNLOADS_PER_TICK 8
/* V134: display-list terrain permits up to 128 resident chunks on modern
 * systems while the runtime Win98 safe profile clamps the working set to 32.
 * The provider/save/renderer tables remain bounded at 128 entries. */
#define CLONEMC_J_CHUNK_CACHE_CAPACITY 128
#define CLONEMC_J_CHUNK_MEMORY_BUDGET_BYTES (208UL * 1024UL * 1024UL)
#define CLONEMC_J_CHUNK_CACHE_VIEW_MAX 16
#define CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY 128
#define CLONEMC_J_LIGHT_UPDATE_CAPACITY 2048
/* This is a count of rectangular regions, not individual blocks.  A single
 * full-chunk region may visit 32,768 blocks, so 500 was an unbounded startup
 * workload. */
#define CLONEMC_J_LIGHT_UPDATES_PER_TICK 500
#define CLONEMC_J_SCHEDULED_TICKS_PER_TICK 1000
#define CLONEMC_J_RANDOM_TICKS_PER_CHUNK 80
#define CLONEMC_J_WORLD_DAY_TICKS 24000L

/* Beta 1.7.3 block IDs used by terrain generation. */
#define CLONEMC_J_BLOCK_STONE 1
#define CLONEMC_J_BLOCK_GRASS 2
#define CLONEMC_J_BLOCK_DIRT 3
#define CLONEMC_J_BLOCK_COBBLESTONE 4
#define CLONEMC_J_BLOCK_BEDROCK 7
#define CLONEMC_J_BLOCK_WATER_MOVING 8
#define CLONEMC_J_BLOCK_WATER_STILL 9
#define CLONEMC_J_BLOCK_LAVA_MOVING 10
#define CLONEMC_J_BLOCK_LAVA_STILL 11
#define CLONEMC_J_BLOCK_SAND 12
#define CLONEMC_J_BLOCK_GRAVEL 13
#define CLONEMC_J_BLOCK_ORE_GOLD 14
#define CLONEMC_J_BLOCK_ORE_IRON 15
#define CLONEMC_J_BLOCK_ORE_COAL 16
#define CLONEMC_J_BLOCK_LOG 17
#define CLONEMC_J_BLOCK_LEAVES 18
#define CLONEMC_J_BLOCK_OBSIDIAN 49
#define CLONEMC_J_BLOCK_ORE_LAPIS 21
#define CLONEMC_J_BLOCK_SANDSTONE 24
#define CLONEMC_J_BLOCK_TALL_GRASS 31
#define CLONEMC_J_BLOCK_DEAD_BUSH 32
#define CLONEMC_J_BLOCK_PLANT_YELLOW 37
#define CLONEMC_J_BLOCK_PLANT_RED 38
#define CLONEMC_J_BLOCK_MUSHROOM_BROWN 39
#define CLONEMC_J_BLOCK_MUSHROOM_RED 40
#define CLONEMC_J_BLOCK_MOB_SPAWNER 52
#define CLONEMC_J_BLOCK_CHEST 54
#define CLONEMC_J_BLOCK_ORE_DIAMOND 56
#define CLONEMC_J_BLOCK_COBBLESTONE_MOSSY 48
#define CLONEMC_J_BLOCK_ORE_REDSTONE 73
#define CLONEMC_J_BLOCK_SNOW 78
#define CLONEMC_J_BLOCK_ICE 79
#define CLONEMC_J_BLOCK_CACTUS 81
#define CLONEMC_J_BLOCK_CLAY 82
#define CLONEMC_J_BLOCK_REED 83
#define CLONEMC_J_BLOCK_PUMPKIN 86
#define CLONEMC_J_BLOCK_NETHERRACK 87
#define CLONEMC_J_BLOCK_SOUL_SAND 88

/* Additional Beta 1.7.3 IDs needed by the Priority 6 light-emission table. */
#define CLONEMC_J_BLOCK_GLASS 20
#define CLONEMC_J_BLOCK_TORCH 50
#define CLONEMC_J_BLOCK_FIRE 51
#define CLONEMC_J_BLOCK_FURNACE_ACTIVE 62
#define CLONEMC_J_BLOCK_ORE_REDSTONE_GLOWING 74
#define CLONEMC_J_BLOCK_REDSTONE_TORCH_ACTIVE 76
#define CLONEMC_J_BLOCK_GLOWSTONE 89
#define CLONEMC_J_BLOCK_PORTAL 90
#define CLONEMC_J_BLOCK_PUMPKIN_LANTERN 91

#define CLONEMC_J_BIOME_RAINFOREST 0
#define CLONEMC_J_BIOME_SWAMPLAND 1
#define CLONEMC_J_BIOME_SEASONAL_FOREST 2
#define CLONEMC_J_BIOME_FOREST 3
#define CLONEMC_J_BIOME_SAVANNA 4
#define CLONEMC_J_BIOME_SHRUBLAND 5
#define CLONEMC_J_BIOME_TAIGA 6
#define CLONEMC_J_BIOME_DESERT 7
#define CLONEMC_J_BIOME_PLAINS 8
#define CLONEMC_J_BIOME_ICE_DESERT 9
#define CLONEMC_J_BIOME_TUNDRA 10
#define CLONEMC_J_BIOME_HELL 11
#define CLONEMC_J_BIOME_SKY 12
#define CLONEMC_J_BIOME_COUNT 13

typedef struct CloneMCJ_ChunkCoordIntPairTag { int chunkXPos; int chunkZPos; } CloneMCJ_ChunkCoordIntPair;
typedef struct CloneMCJ_ChunkCoordinatesTag { int x; int y; int z; } CloneMCJ_ChunkCoordinates;
typedef struct CloneMCJ_ChunkPositionTag { int x; int y; int z; } CloneMCJ_ChunkPosition;
typedef struct CloneMCJ_WorldBlockPositionTypeTag { int x; int y; int z; int blockID; int metadata; } CloneMCJ_WorldBlockPositionType;

typedef struct CloneMCJ_NextTickListEntryTag {
    int xCoord; int yCoord; int zCoord; int blockID;
    CloneMCJLong scheduledTime; CloneMCJLong tickEntryID;
} CloneMCJ_NextTickListEntry;

typedef enum CloneMCJ_ChunkStateTag {
    CLONEMC_J_CHUNK_STATE_ABSENT = 0,
    CLONEMC_J_CHUNK_STATE_LOADING,
    CLONEMC_J_CHUNK_STATE_GENERATING_BASE,
    CLONEMC_J_CHUNK_STATE_WAITING_FOR_NEIGHBORS,
    CLONEMC_J_CHUNK_STATE_POPULATING,
    CLONEMC_J_CHUNK_STATE_LIGHTING,
    CLONEMC_J_CHUNK_STATE_MESH_QUEUED,
    CLONEMC_J_CHUNK_STATE_READY,
    CLONEMC_J_CHUNK_STATE_DIRTY_SAVE_QUEUED,
    CLONEMC_J_CHUNK_STATE_UNLOADED
} CloneMCJ_ChunkState;

typedef int (*CloneMCJ_BlockLightOpacityProc)(int blockID, void *userData);

typedef struct CloneMCJ_ChunkTag {
    unsigned char blocks[CLONEMC_J_CHUNK_BLOCK_COUNT];
    CloneMCJ_NibbleArray data, skylightMap, blocklightMap;
    unsigned char dataBytes[CLONEMC_J_CHUNK_NIBBLE_BYTES];
    unsigned char skylightBytes[CLONEMC_J_CHUNK_NIBBLE_BYTES];
    unsigned char blocklightBytes[CLONEMC_J_CHUNK_NIBBLE_BYTES];
    unsigned char heightMap[CLONEMC_J_CHUNK_COLUMNS];
    unsigned char biomeMap[CLONEMC_J_CHUNK_COLUMNS];
    int lowestBlockHeight, xPosition, zPosition;
    unsigned char isChunkLoaded, isTerrainPopulated, isModified, neverSave;
    unsigned char hasEntities, lightDirty, meshDirty, loaded;
    CloneMCJ_ChunkState state;
    CloneMCJLong lastSaveTime;
    void *entities[CLONEMC_J_CHUNK_ENTITY_SLICES][CLONEMC_J_CHUNK_MAX_ENTITIES_PER_SLICE];
    unsigned short entityCount[CLONEMC_J_CHUNK_ENTITY_SLICES];
    void *tileEntities[CLONEMC_J_CHUNK_MAX_TILE_ENTITIES];
    int tileEntityX[CLONEMC_J_CHUNK_MAX_TILE_ENTITIES];
    int tileEntityY[CLONEMC_J_CHUNK_MAX_TILE_ENTITIES];
    int tileEntityZ[CLONEMC_J_CHUNK_MAX_TILE_ENTITIES];
    unsigned short tileEntityCount;
    CloneMCJ_NextTickListEntry scheduledTicks[CLONEMC_J_CHUNK_MAX_SCHEDULED_TICKS];
    unsigned short scheduledTickCount;
    unsigned long lruStamp;
} CloneMCJ_Chunk;

typedef struct CloneMCJ_IChunkProviderTag {
    void *instance;
    int (*chunkExists)(void *, int, int);
    CloneMCJ_Chunk *(*provideChunk)(void *, int, int);
    CloneMCJ_Chunk *(*prepareChunk)(void *, int, int);
    void (*populate)(void *, struct CloneMCJ_IChunkProviderTag *, int, int);
    int (*saveChunks)(void *, int, void *);
    int (*unload100OldestChunks)(void *);
    int (*canSave)(void *);
    const char *(*makeString)(void *);
} CloneMCJ_IChunkProvider;

typedef struct CloneMCJ_IBlockAccessTag {
    void *instance;
    int (*getBlockId)(void *, int, int, int);
    void *(*getBlockTileEntity)(void *, int, int, int);
    float (*getBrightness)(void *, int, int, int, int);
    float (*getLightBrightness)(void *, int, int, int);
    int (*getBlockMetadata)(void *, int, int, int);
    void *(*getBlockMaterial)(void *, int, int, int);
    int (*isBlockOpaqueCube)(void *, int, int, int);
    int (*isBlockNormalCube)(void *, int, int, int);
    void *(*getWorldChunkManager)(void *);
} CloneMCJ_IBlockAccess;

typedef struct CloneMCJ_IWorldAccessTag {
    void *instance;
    void (*markBlockAndNeighborsNeedsUpdate)(void *, int, int, int);
    void (*markBlockRangeNeedsUpdate)(void *, int, int, int, int, int, int);
    void (*obtainEntitySkin)(void *, void *);
    void (*releaseEntitySkin)(void *, void *);
    void (*updateAllRenderers)(void *);
    void (*playRecord)(void *, const char *, int, int, int);
    void (*doNothingWithTileEntity)(void *, int, int, int, void *);
    void (*func28136A)(void *, void *, int, int, int, int, int);
} CloneMCJ_IWorldAccess;

typedef int (*CloneMCJ_ChunkGeneratorProc)(CloneMCJ_Chunk *, int, int, void *);
/* Loader result: 1=loaded, 0=absent/generate, -1=present but corrupt or hard I/O failure. */
typedef int (*CloneMCJ_ChunkLoaderProc)(CloneMCJ_Chunk *, int, int, void *);
typedef int (*CloneMCJ_ChunkSaverProc)(const CloneMCJ_Chunk *, int, void *);

typedef struct CloneMCJ_ChunkCacheSlotTag {
    CloneMCJ_Chunk *chunk; unsigned char used, locked; unsigned long lastAccess;
} CloneMCJ_ChunkCacheSlot;

typedef struct CloneMCJ_ChunkProviderLoadOrGenerateTag {
    CloneMCJ_Chunk blankChunk;
    CloneMCJ_ChunkCacheSlot slots[CLONEMC_J_CHUNK_CACHE_CAPACITY];
    int curChunkX, curChunkZ, allowedRadius, allowedChunkCount, residentCount;
    int saveCursor;
    unsigned long accessClock, residentSerial, allocationFailures;
    unsigned long chunksSavedIncrementally, chunksSavedForced;
    unsigned long chunksLoadedFromDisk, chunksGeneratedNew;
    unsigned long residentHighWaterMark, budgetEvictions, budgetDeferrals;
    unsigned long runtimeMemoryBudgetBytes;
    unsigned long chunkLoadFailures;
    int lastFailedChunkX, lastFailedChunkZ;
    CloneMCJLong worldSeed;
    CloneMCJ_ChunkGeneratorProc generator; CloneMCJ_ChunkLoaderProc loader; CloneMCJ_ChunkSaverProc saver;
    void *generatorUser; void *loaderUser; void *saverUser;
    CloneMCJLong *worldTimePointer;
    CloneMCJ_IChunkProvider providerInterface;
} CloneMCJ_ChunkProviderLoadOrGenerate;

typedef struct CloneMCJ_ChunkProviderTag {
    CloneMCJ_ChunkProviderLoadOrGenerate backing;
    int droppedChunkX[128], droppedChunkZ[128];
    unsigned char droppedUsed[128]; unsigned short droppedCount;
} CloneMCJ_ChunkProvider;

typedef struct CloneMCJ_ChunkProviderClientSlotTag {
    CloneMCJ_Chunk *chunk; int chunkX, chunkZ; unsigned char used; unsigned long lastAccess;
} CloneMCJ_ChunkProviderClientSlot;

typedef struct CloneMCJ_ChunkProviderClientTag {
    CloneMCJ_Chunk blankChunk;
    CloneMCJ_ChunkProviderClientSlot slots[CLONEMC_J_CHUNK_PROVIDER_CLIENT_CAPACITY];
    unsigned long accessClock, residentSerial;
    void *worldObj; CloneMCJ_IChunkProvider providerInterface;
} CloneMCJ_ChunkProviderClient;

typedef struct CloneMCNoisePerlinTag { int permutations[512]; double xCoord, yCoord, zCoord; } CloneMCNoisePerlin;
typedef struct CloneMCNoiseOctavesTag { CloneMCNoisePerlin *generators; int octaveCount; } CloneMCNoiseOctaves;
typedef struct CloneMCNoiseSimplexTag { int permutations[512]; double xCoord, yCoord, zCoord; } CloneMCNoiseSimplex;
typedef struct CloneMCNoiseOctaves2Tag { CloneMCNoiseSimplex *generators; int octaveCount; } CloneMCNoiseOctaves2;

typedef struct CloneMCJ_BiomeGenBaseTag {
    int biomeID; const char *biomeName; int color; unsigned char topBlock, fillerBlock;
    int field_6502_q; unsigned char enableSnow, enableRain;
} CloneMCJ_BiomeGenBase;

typedef struct CloneMCJ_WorldChunkManagerTag {
    CloneMCNoiseOctaves2 field_4194_e, field_4193_f, field_4192_g;
    double temperature[256], humidity[256], field_4196_c[256];
    const CloneMCJ_BiomeGenBase *field_4195_d[256];
    CloneMCJLong worldSeed;
    int fixedBiomeID;
    double fixedTemperature, fixedHumidity;
    unsigned char initialized, fixedMode;
} CloneMCJ_WorldChunkManager;

struct CloneMCJ_WorldTag;
typedef struct CloneMCJ_ChunkProviderGenerateTag {
    CloneMCJavaRandom rand;
    CloneMCNoiseOctaves field_912_k, field_911_l, field_910_m, field_909_n, field_908_o;
    CloneMCNoiseOctaves field_922_a, field_921_b, mobSpawnerNoise;
    CloneMCJLong worldSeed; CloneMCJ_WorldChunkManager *worldChunkManager;
    double field_4180_q[425], sandNoise[256], gravelNoise[256], stoneNoise[256];
    double field_4185_d[425], field_4184_e[425], field_4183_f[425], field_4182_g[25], field_4181_h[25];
    double generatedTemperatures[256]; const CloneMCJ_BiomeGenBase *biomesForGeneration[256];
    unsigned char initialized;
} CloneMCJ_ChunkProviderGenerate;

/* Priority 11 native ownership for ChunkProviderHell.java's seven octave
 * generators and reusable density/surface fields.  Keeping these buffers on
 * the world avoids per-chunk allocation and the world-entry failure mode that
 * resulted from partially constructed dimension providers. */
typedef struct CloneMCJ_ChunkProviderHellTag {
    CloneMCJavaRandom hellRNG;
    CloneMCNoiseOctaves field_4169_i, field_4168_j, field_4167_k;
    CloneMCNoiseOctaves field_4166_l, field_4165_m, field_4177_a, field_4176_b;
    double density[425], surfaceA[256], surfaceB[256], surfaceDepth[256];
    double blend[425], lower[425], upper[425], scale[25], depth[25];
    CloneMCJLong worldSeed;
    unsigned char initialized;
} CloneMCJ_ChunkProviderHell;

/* WorldProviderSky/ChunkProviderSky are present in the uploaded Beta source and
 * are selected by WorldProvider.getProviderForDimension(1). */
typedef struct CloneMCJ_ChunkProviderSkyTag {
    CloneMCJavaRandom skyRNG;
    CloneMCNoiseOctaves field_28086_k, field_28085_l, field_28084_m;
    CloneMCNoiseOctaves field_28083_n, field_28082_o;
    CloneMCNoiseOctaves field_28096_a, field_28095_b, field_28094_c;
    double density[297], lower[297], upper[297], blend[297];
    double scale[9], depth[9];
    double surfaceA[256], surfaceB[256], surfaceDepth[256];
    CloneMCJLong worldSeed;
    unsigned char initialized;
} CloneMCJ_ChunkProviderSky;


/* Priority 5 WorldInfo.java persistent metadata. */
struct CloneMCJ_NBTBaseTag;
typedef struct CloneMCJ_WorldInfoTag {
    CloneMCJLong randomSeed;
    int spawnX, spawnY, spawnZ;
    CloneMCJLong worldTime, lastTimePlayed, sizeOnDisk;
    struct CloneMCJ_NBTBaseTag *playerTag;
    int dimension;
    char levelName[128];
    int saveVersion;
    int gameType;
    unsigned char allowCommands;
    unsigned char writeExtensionTags;
    unsigned char raining, thundering;
    int rainTime, thunderTime;
} CloneMCJ_WorldInfo;
struct CloneMCJ_SaveHandlerTag;

typedef struct CloneMCJ_WorldProviderTag {
    unsigned char isNether, isHellWorld, hasNoSky;
    int worldType;
    float lightBrightnessTable[16];
    float colorsSunriseSunset[4];
} CloneMCJ_WorldProvider;

struct CloneMCJ_WorldTag;
typedef void (*CloneMCJ_BlockTickProc)(struct CloneMCJ_WorldTag *, int, int, int,
    int, CloneMCJavaRandom *, void *);
typedef void (*CloneMCJ_GameplayTickProc)(struct CloneMCJ_WorldTag *, void *);
typedef int (*CloneMCJ_GameplayPrepareSaveProc)(struct CloneMCJ_WorldTag *, void *);
typedef void (*CloneMCJ_GameplayDimensionProc)(struct CloneMCJ_WorldTag *, void *, int);

typedef struct CloneMCJ_WorldTag {
    CloneMCJLong randomSeed, worldTime;
    int skylightSubtracted, multiplayerWorld, playerChunkX, playerChunkZ, activeRadius;
    int activeChunkLimit;
    unsigned long chunkMemoryBudgetBytes;
    int streamGenerationRing, streamGenerationCursor;
    int streamPopulationRing, streamPopulationCursor;
    int streamCenterX, streamCenterZ;
    unsigned char playerChunkInitialized, streamGenerationComplete, streamPopulationComplete;
    unsigned long streamedChunksPrepared, streamedChunksPopulated, streamedChunksUnloaded;
    unsigned long streamAllocationFailures, streamRetryTick;
    int populationQueueX[CLONEMC_J_POPULATION_QUEUE_CAPACITY];
    int populationQueueZ[CLONEMC_J_POPULATION_QUEUE_CAPACITY];
    unsigned short populationQueueHead, populationQueueTail, populationQueueCount;
    unsigned long populationCandidatesQueued, populationCandidatesDropped;
    unsigned long streamCoordinatesScanned;
    unsigned char performanceTier;
    CloneMCJavaRandom rand;
    CloneMCJ_WorldProvider worldProvider;
    float prevRainingStrength, rainingStrength;
    float prevThunderingStrength, thunderingStrength;
    int lightningFlash, autosavePeriod;
    CloneMCJInt randomTickLCG;
    unsigned long ticksRun, scheduledTicksRun, randomTicksRun;
    unsigned long neighborNotifications, neighborNotificationsDropped;
    unsigned long scheduledTicksDropped;
    unsigned short neighborNotifyDepth;
    unsigned char processingScheduledTicks, editingBlocks;
    /* Java Chunk.setBlockIDWithMetadata replaces the ID before invoking the
       former block's removal callback, but leaves the old metadata readable
       until that callback returns.  These transient fields reproduce that
       contract for powered attachments and tile-entity blocks. */
    unsigned char blockRemovalActive;
    int removalBlockX, removalBlockY, removalBlockZ, removalOldBlockID, removalOldMetadata;
    CloneMCJ_MetadataChunkBlock lightingToUpdate[CLONEMC_J_LIGHT_UPDATE_CAPACITY];
    unsigned short lightingUpdateCount;
    unsigned short lightingUpdatesCounter, lightingUpdatesScheduled;
    unsigned long lightingRegionsProcessed, lightingRegionsDropped;
    /* A queue overflow is summarized as a bounding region per light type and
       replayed later in 16-cube slices.  This costs no heap allocation and
       prevents a transient burst from leaving permanently stale light. */
    unsigned char lightingOverflowActive[2];
    int lightingOverflowMinX[2], lightingOverflowMinY[2], lightingOverflowMinZ[2];
    int lightingOverflowMaxX[2], lightingOverflowMaxY[2], lightingOverflowMaxZ[2];
    int lightingOverflowCursorX[2], lightingOverflowCursorY[2], lightingOverflowCursorZ[2];
    unsigned long lightingOverflowSlicesRecovered;
    CloneMCJ_BlockTickProc blockTickCallbacks[256];
    void *blockTickUserData[256];
    unsigned char tickOnLoad[256];
    CloneMCJ_GameplayTickProc gameplayTick;
    CloneMCJ_GameplayPrepareSaveProc gameplayPrepareSave;
    CloneMCJ_GameplayDimensionProc gameplayDimensionChanged;
    void *gameplayUserData;
    CloneMCJ_WorldChunkManager chunkManager;
    CloneMCJ_ChunkProviderGenerate terrainProvider;
    CloneMCJ_ChunkProviderHell hellProvider;
    CloneMCJ_ChunkProviderSky skyProvider;
    CloneMCJ_ChunkProviderLoadOrGenerate chunkProvider;
    CloneMCJ_WorldInfo worldInfo;
    struct CloneMCJ_SaveHandlerTag *saveHandler;
    char lastSaveError[192];
} CloneMCJ_World;

typedef struct CloneMCJ_ChunkCacheViewTag {
    CloneMCJ_World *worldObj; int chunkX, chunkZ, xCount, zCount;
    CloneMCJ_Chunk *chunkArray[CLONEMC_J_CHUNK_CACHE_VIEW_MAX][CLONEMC_J_CHUNK_CACHE_VIEW_MAX];
} CloneMCJ_ChunkCacheView;

typedef struct CloneMCJ_WorldClientTag {
    CloneMCJ_World baseWorld; CloneMCJ_ChunkProviderClient clientChunkProvider;
    void *sendQueue; int dimension;
} CloneMCJ_WorldClient;

/* Priority 3 chunk/coordinate/provider APIs. */
void CloneMCJ_ChunkCoordIntPair_Initialize(CloneMCJ_ChunkCoordIntPair *, int, int);
CloneMCJInt CloneMCJ_ChunkCoordIntPair_ChunkXZ2Int(int, int);
CloneMCJInt CloneMCJ_ChunkCoordIntPair_HashCode(const CloneMCJ_ChunkCoordIntPair *);
int CloneMCJ_ChunkCoordIntPair_Equals(const CloneMCJ_ChunkCoordIntPair *, const CloneMCJ_ChunkCoordIntPair *);
void CloneMCJ_ChunkCoordinates_Initialize(CloneMCJ_ChunkCoordinates *, int, int, int);
void CloneMCJ_ChunkCoordinates_Copy(CloneMCJ_ChunkCoordinates *, const CloneMCJ_ChunkCoordinates *);
int CloneMCJ_ChunkCoordinates_Equals(const CloneMCJ_ChunkCoordinates *, const CloneMCJ_ChunkCoordinates *);
CloneMCJInt CloneMCJ_ChunkCoordinates_HashCode(const CloneMCJ_ChunkCoordinates *);
int CloneMCJ_ChunkCoordinates_Compare(const CloneMCJ_ChunkCoordinates *, const CloneMCJ_ChunkCoordinates *);
double CloneMCJ_ChunkCoordinates_GetSqDistanceTo(const CloneMCJ_ChunkCoordinates *, int, int, int);
void CloneMCJ_ChunkPosition_Initialize(CloneMCJ_ChunkPosition *, int, int, int);
int CloneMCJ_ChunkPosition_Equals(const CloneMCJ_ChunkPosition *, const CloneMCJ_ChunkPosition *);
CloneMCJInt CloneMCJ_ChunkPosition_HashCode(const CloneMCJ_ChunkPosition *);
void CloneMCJ_WorldBlockPositionType_Initialize(CloneMCJ_WorldBlockPositionType *, int, int, int, int, int);
void CloneMCJ_NextTickListEntry_Initialize(CloneMCJ_NextTickListEntry *, int, int, int, int);
CloneMCJ_NextTickListEntry *CloneMCJ_NextTickListEntry_SetScheduledTime(CloneMCJ_NextTickListEntry *, CloneMCJLong);
int CloneMCJ_NextTickListEntry_Equals(const CloneMCJ_NextTickListEntry *, const CloneMCJ_NextTickListEntry *);
CloneMCJInt CloneMCJ_NextTickListEntry_HashCode(const CloneMCJ_NextTickListEntry *);
int CloneMCJ_NextTickListEntry_Compare(const CloneMCJ_NextTickListEntry *, const CloneMCJ_NextTickListEntry *);
void CloneMCJ_NextTickListEntry_ResetIDsForTest(void);
unsigned long CloneMCJ_Chunk_BlockIndex(int, int, int);
int CloneMCJ_Chunk_IsLocalPositionValid(int, int, int);
void CloneMCJ_Chunk_Initialize(CloneMCJ_Chunk *, int, int);
void CloneMCJ_Chunk_InitializeWithBlocks(CloneMCJ_Chunk *, const unsigned char *, int, int);
void CloneMCJ_Chunk_Destroy(CloneMCJ_Chunk *);
int CloneMCJ_Chunk_IsAtLocation(const CloneMCJ_Chunk *, int, int);
int CloneMCJ_Chunk_GetHeightValue(const CloneMCJ_Chunk *, int, int);
void CloneMCJ_Chunk_GenerateHeightMap(CloneMCJ_Chunk *, CloneMCJ_BlockLightOpacityProc, void *);
int CloneMCJ_Chunk_GetBlockID(const CloneMCJ_Chunk *, int, int, int);
int CloneMCJ_Chunk_SetBlockIDWithMetadata(CloneMCJ_Chunk *, int, int, int, int, int, CloneMCJ_BlockLightOpacityProc, void *);
int CloneMCJ_Chunk_SetBlockID(CloneMCJ_Chunk *, int, int, int, int, CloneMCJ_BlockLightOpacityProc, void *);
int CloneMCJ_Chunk_GetBlockMetadata(const CloneMCJ_Chunk *, int, int, int);
void CloneMCJ_Chunk_SetBlockMetadata(CloneMCJ_Chunk *, int, int, int, int);
int CloneMCJ_Chunk_GetSavedLightValue(const CloneMCJ_Chunk *, int, int, int, int);
void CloneMCJ_Chunk_SetLightValue(CloneMCJ_Chunk *, int, int, int, int, int);
int CloneMCJ_Chunk_GetBlockLightValue(const CloneMCJ_Chunk *, int, int, int, int);
int CloneMCJ_Chunk_CanBlockSeeTheSky(const CloneMCJ_Chunk *, int, int, int);
void CloneMCJ_Chunk_SetModified(CloneMCJ_Chunk *);
int CloneMCJ_Chunk_NeedsSaving(const CloneMCJ_Chunk *, int, CloneMCJLong);
int CloneMCJ_Chunk_AddEntity(CloneMCJ_Chunk *, void *, double);
int CloneMCJ_Chunk_RemoveEntity(CloneMCJ_Chunk *, void *, int);
int CloneMCJ_Chunk_SetTileEntity(CloneMCJ_Chunk *, int, int, int, void *);
void *CloneMCJ_Chunk_GetTileEntity(const CloneMCJ_Chunk *, int, int, int);
void CloneMCJ_Chunk_RemoveTileEntity(CloneMCJ_Chunk *, int, int, int);
int CloneMCJ_Chunk_ScheduleTick(CloneMCJ_Chunk *, int, int, int, int, CloneMCJLong);
CloneMCJavaRandom CloneMCJ_Chunk_CreateRandom(const CloneMCJ_Chunk *, CloneMCJLong, CloneMCJLong);
int CloneMCChunk_RunSelfTests(char *, unsigned int);
void CloneMCJ_ChunkBlockMap_Reset(void);
void CloneMCJ_ChunkBlockMap_CopyFrom(const unsigned char *, unsigned int);
void CloneMCJ_ChunkBlockMap_Func26002A(unsigned char *, unsigned long);
unsigned char CloneMCJ_ChunkBlockMap_MapBlock(unsigned char);
void CloneMCJ_EmptyChunk_Initialize(CloneMCJ_Chunk *, int, int);
int CloneMCJ_EmptyChunk_IsEmptyReadOnly(const CloneMCJ_Chunk *);
void CloneMCJ_IBlockAccess_InitializeEmpty(CloneMCJ_IBlockAccess *, void *);
int CloneMCJ_IBlockAccess_GetBlockId(CloneMCJ_IBlockAccess *, int, int, int);
int CloneMCJ_IBlockAccess_GetBlockMetadata(CloneMCJ_IBlockAccess *, int, int, int);
float CloneMCJ_IBlockAccess_GetLightBrightness(CloneMCJ_IBlockAccess *, int, int, int);
void CloneMCJ_IWorldAccess_InitializeEmpty(CloneMCJ_IWorldAccess *, void *);
void CloneMCJ_IWorldAccess_MarkBlockAndNeighborsNeedsUpdate(CloneMCJ_IWorldAccess *, int, int, int);
void CloneMCJ_IWorldAccess_MarkBlockRangeNeedsUpdate(CloneMCJ_IWorldAccess *, int, int, int, int, int, int);
void CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(CloneMCJ_ChunkProviderLoadOrGenerate *, CloneMCJLong);
void CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(CloneMCJ_ChunkProviderLoadOrGenerate *);
void CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(CloneMCJ_ChunkProviderLoadOrGenerate *, CloneMCJ_ChunkLoaderProc, void *, CloneMCJ_ChunkGeneratorProc, void *, CloneMCJ_ChunkSaverProc, void *);
void CloneMCJ_ChunkProviderLoadOrGenerate_SetCurrentChunkOver(CloneMCJ_ChunkProviderLoadOrGenerate *, int, int);
void CloneMCJ_ChunkProviderLoadOrGenerate_SetAllowedRadius(CloneMCJ_ChunkProviderLoadOrGenerate *, int);
void CloneMCJ_ChunkProviderLoadOrGenerate_SetChunkLimit(CloneMCJ_ChunkProviderLoadOrGenerate *, int);
void CloneMCJ_ChunkProviderLoadOrGenerate_SetMemoryBudget(CloneMCJ_ChunkProviderLoadOrGenerate *, unsigned long);
int CloneMCJ_ChunkProviderLoadOrGenerate_ChunkRank(const CloneMCJ_ChunkProviderLoadOrGenerate *, int, int);
int CloneMCJ_ChunkProviderLoadOrGenerate_RunV119SelfTests(char *, unsigned int);
int CloneMCJ_ChunkProviderLoadOrGenerate_CanChunkExist(const CloneMCJ_ChunkProviderLoadOrGenerate *, int, int);
int CloneMCJ_ChunkProviderLoadOrGenerate_RunLimitSelfTests(char *, unsigned int);
int CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(const CloneMCJ_ChunkProviderLoadOrGenerate *, int, int);
void CloneMCJ_ChunkProviderLoadOrGenerate_SetWorldTimePointer(CloneMCJ_ChunkProviderLoadOrGenerate *, CloneMCJLong *);
CloneMCJ_Chunk *CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(CloneMCJ_ChunkProviderLoadOrGenerate *, int, int);
CloneMCJ_Chunk *CloneMCJ_ChunkProviderLoadOrGenerate_ProvideChunk(CloneMCJ_ChunkProviderLoadOrGenerate *, int, int);
void CloneMCJ_ChunkProviderLoadOrGenerate_Populate(CloneMCJ_ChunkProviderLoadOrGenerate *, int, int);
int CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunks(CloneMCJ_ChunkProviderLoadOrGenerate *, int);
int CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunksBudget(CloneMCJ_ChunkProviderLoadOrGenerate *, int, int, int *);
int CloneMCJ_ChunkProviderLoadOrGenerate_CountChunksNeedingSave(const CloneMCJ_ChunkProviderLoadOrGenerate *, int);
int CloneMCJ_ChunkProviderLoadOrGenerate_UnloadOldestChunks(CloneMCJ_ChunkProviderLoadOrGenerate *, int);
int CloneMCJ_ChunkProviderLoadOrGenerate_Unload100OldestChunks(CloneMCJ_ChunkProviderLoadOrGenerate *);
int CloneMCJ_ChunkProviderLoadOrGenerate_CanSave(const CloneMCJ_ChunkProviderLoadOrGenerate *);
const char *CloneMCJ_ChunkProviderLoadOrGenerate_MakeString(const CloneMCJ_ChunkProviderLoadOrGenerate *);
CloneMCJ_IChunkProvider *CloneMCJ_ChunkProviderLoadOrGenerate_AsIChunkProvider(CloneMCJ_ChunkProviderLoadOrGenerate *);
int CloneMCJ_ChunkProviderLoadOrGenerate_CountLoaded(const CloneMCJ_ChunkProviderLoadOrGenerate *);
void CloneMCJ_ChunkProvider_Initialize(CloneMCJ_ChunkProvider *, CloneMCJLong);
void CloneMCJ_ChunkProvider_Destroy(CloneMCJ_ChunkProvider *);
void CloneMCJ_ChunkProvider_SetCallbacks(CloneMCJ_ChunkProvider *, CloneMCJ_ChunkLoaderProc, void *, CloneMCJ_ChunkGeneratorProc, void *, CloneMCJ_ChunkSaverProc, void *);
int CloneMCJ_ChunkProvider_ChunkExists(CloneMCJ_ChunkProvider *, int, int);
CloneMCJ_Chunk *CloneMCJ_ChunkProvider_PrepareChunk(CloneMCJ_ChunkProvider *, int, int);
CloneMCJ_Chunk *CloneMCJ_ChunkProvider_ProvideChunk(CloneMCJ_ChunkProvider *, int, int);
void CloneMCJ_ChunkProvider_DropChunk(CloneMCJ_ChunkProvider *, int, int);
void CloneMCJ_ChunkProvider_Populate(CloneMCJ_ChunkProvider *, int, int);
int CloneMCJ_ChunkProvider_SaveChunks(CloneMCJ_ChunkProvider *, int);
int CloneMCJ_ChunkProvider_Unload100OldestChunks(CloneMCJ_ChunkProvider *);
int CloneMCJ_ChunkProvider_CanSave(CloneMCJ_ChunkProvider *);
const char *CloneMCJ_ChunkProvider_MakeString(CloneMCJ_ChunkProvider *);
CloneMCJ_IChunkProvider *CloneMCJ_ChunkProvider_AsIChunkProvider(CloneMCJ_ChunkProvider *);
void CloneMCJ_ChunkProviderClient_Initialize(CloneMCJ_ChunkProviderClient *, void *);
void CloneMCJ_ChunkProviderClient_Destroy(CloneMCJ_ChunkProviderClient *);
int CloneMCJ_ChunkProviderClient_ChunkExists(const CloneMCJ_ChunkProviderClient *, int, int);
void CloneMCJ_ChunkProviderClient_DoPreChunk(CloneMCJ_ChunkProviderClient *, int, int, int);
CloneMCJ_Chunk *CloneMCJ_ChunkProviderClient_PrepareChunk(CloneMCJ_ChunkProviderClient *, int, int);
CloneMCJ_Chunk *CloneMCJ_ChunkProviderClient_ProvideChunk(CloneMCJ_ChunkProviderClient *, int, int);
int CloneMCJ_ChunkProviderClient_SaveChunks(CloneMCJ_ChunkProviderClient *, int);
int CloneMCJ_ChunkProviderClient_Unload100OldestChunks(CloneMCJ_ChunkProviderClient *);
int CloneMCJ_ChunkProviderClient_CanSave(const CloneMCJ_ChunkProviderClient *);
const char *CloneMCJ_ChunkProviderClient_MakeString(const CloneMCJ_ChunkProviderClient *);
CloneMCJ_IChunkProvider *CloneMCJ_ChunkProviderClient_AsIChunkProvider(CloneMCJ_ChunkProviderClient *);

/* Priority 2 exact Java numerical/noise APIs. */
void CloneMCNoisePerlin_Initialize(CloneMCNoisePerlin *, CloneMCJavaRandom *);
double CloneMCNoisePerlin_Generate(const CloneMCNoisePerlin *, double, double, double);
double CloneMCNoisePerlin_Generate2D(const CloneMCNoisePerlin *, double, double);
void CloneMCNoisePerlin_Add(const CloneMCNoisePerlin *, double *, double, double, double, int, int, int, double, double, double, double);
int CloneMCNoiseOctaves_Initialize(CloneMCNoiseOctaves *, CloneMCJavaRandom *, int);
void CloneMCNoiseOctaves_Destroy(CloneMCNoiseOctaves *);
double CloneMCNoiseOctaves_Generate2D(const CloneMCNoiseOctaves *, double, double);
int CloneMCNoiseOctaves_Generate(const CloneMCNoiseOctaves *, double *, unsigned long, double, double, double, int, int, int, double, double, double);
void CloneMCNoiseSimplex_Initialize(CloneMCNoiseSimplex *, CloneMCJavaRandom *);
void CloneMCNoiseSimplex_Add(const CloneMCNoiseSimplex *, double *, double, double, int, int, double, double, double);
int CloneMCNoiseOctaves2_Initialize(CloneMCNoiseOctaves2 *, CloneMCJavaRandom *, int);
void CloneMCNoiseOctaves2_Destroy(CloneMCNoiseOctaves2 *);
int CloneMCNoiseOctaves2_Generate(const CloneMCNoiseOctaves2 *, double *, unsigned long, double, double, int, int, double, double, double, double);
int CloneMCNoise_RunSelfTests(char *, unsigned int);

/* Priority 4 biome, chunk generator and world APIs. */
void CloneMCJ_BiomeGenBase_InitializeTable(void);
const CloneMCJ_BiomeGenBase *CloneMCJ_BiomeGenBase_GetByID(int);
const CloneMCJ_BiomeGenBase *CloneMCJ_BiomeGenBase_GetBiome(float, float);
const CloneMCJ_BiomeGenBase *CloneMCJ_BiomeGenBase_GetBiomeFromLookup(double, double);
int CloneMCJ_BiomeGenBase_GetEnableSnow(const CloneMCJ_BiomeGenBase *);
int CloneMCJ_BiomeGenBase_CanSpawnLightningBolt(const CloneMCJ_BiomeGenBase *);
int CloneMCJ_BiomeGenBase_RunSelfTests(char *, unsigned int);
int CloneMCJ_WorldChunkManager_Initialize(CloneMCJ_WorldChunkManager *, CloneMCJLong);
int CloneMCJ_WorldChunkManager_InitializeFixed(CloneMCJ_WorldChunkManager *, int, double, double);
void CloneMCJ_WorldChunkManager_Destroy(CloneMCJ_WorldChunkManager *);
const CloneMCJ_BiomeGenBase *CloneMCJ_WorldChunkManager_GetBiomeGenAt(CloneMCJ_WorldChunkManager *, int, int);
double CloneMCJ_WorldChunkManager_GetTemperature(CloneMCJ_WorldChunkManager *, int, int);
double CloneMCJ_WorldChunkManager_GetHumidity(CloneMCJ_WorldChunkManager *, int, int);
double *CloneMCJ_WorldChunkManager_GetTemperatures(CloneMCJ_WorldChunkManager *, double *, int, int, int, int);
const CloneMCJ_BiomeGenBase **CloneMCJ_WorldChunkManager_LoadBlockGeneratorData(CloneMCJ_WorldChunkManager *, const CloneMCJ_BiomeGenBase **, int, int, int, int);
int CloneMCJ_WorldChunkManager_RunSelfTests(char *, unsigned int);
int CloneMCJ_ChunkProviderGenerate_Initialize(CloneMCJ_ChunkProviderGenerate *, CloneMCJLong, CloneMCJ_WorldChunkManager *);
void CloneMCJ_ChunkProviderGenerate_Destroy(CloneMCJ_ChunkProviderGenerate *);
double *CloneMCJ_ChunkProviderGenerate_InitializeNoiseField(CloneMCJ_ChunkProviderGenerate *, int, int, int, int, int, int);
void CloneMCJ_ChunkProviderGenerate_GenerateTerrain(CloneMCJ_ChunkProviderGenerate *, int, int, CloneMCJ_Chunk *);
void CloneMCJ_ChunkProviderGenerate_ReplaceBlocksForBiome(CloneMCJ_ChunkProviderGenerate *, int, int, CloneMCJ_Chunk *);
int CloneMCJ_ChunkProviderGenerate_GenerateChunk(CloneMCJ_ChunkProviderGenerate *, CloneMCJ_Chunk *, int, int);
void CloneMCJ_ChunkProviderGenerate_PopulateWorldChunk(CloneMCJ_ChunkProviderGenerate *, CloneMCJ_World *, int, int);
void CloneMCJ_ChunkProviderGenerate_PopulateJavaOrder(CloneMCJ_ChunkProviderGenerate *, CloneMCJ_World *, int, int, int);
void CloneMCJ_ChunkProviderGenerate_StrongholdCoordinates(CloneMCJLong,
    int [3],int [3]);
int CloneMCJ_ChunkProviderGenerate_FindClosestStronghold(CloneMCJLong,
    double,double,int *,int *);
int CloneMCJ_ChunkProviderGenerate_IsVillageStart(CloneMCJLong,int,int,
    CloneMCJ_WorldChunkManager *);
void CloneMCJ_Gameplay_SpawnVillageResidents(CloneMCJ_World *,int,int,int,
    CloneMCJavaRandom *);
const char *CloneMCJ_ChunkProviderGenerate_MakeString(const CloneMCJ_ChunkProviderGenerate *);
int CloneMCJ_ChunkProviderGenerate_RunSelfTests(char *, unsigned int);
void CloneMCJ_MapGenBase_GenerateCaves(CloneMCJLong, int, int, CloneMCJ_Chunk *);
void CloneMCJ_MapGenCaves_Carve(CloneMCJLong, int, int, CloneMCJ_Chunk *);
void CloneMCJ_MapGenCaves_CarveFromSource(CloneMCJavaRandom *, int, int, int, int, CloneMCJ_Chunk *);
void CloneMCJ_MapGenCaves_CarveHellTunnel(CloneMCJavaRandom *, int, int,
    CloneMCJ_Chunk *, double, double, double, float, float, float, int, int, double);
void CloneMCJ_MapGenCavesHell_Generate(CloneMCJLong, int, int, CloneMCJ_Chunk *);


void CloneMCJ_WorldInfo_Initialize(CloneMCJ_WorldInfo *, CloneMCJLong, const char *);
void CloneMCJ_WorldInfo_Copy(CloneMCJ_WorldInfo *, const CloneMCJ_WorldInfo *);
void CloneMCJ_WorldInfo_Destroy(CloneMCJ_WorldInfo *);
int CloneMCJ_WorldInfo_LoadFromNBT(CloneMCJ_WorldInfo *, const struct CloneMCJ_NBTBaseTag *);
struct CloneMCJ_NBTBaseTag *CloneMCJ_WorldInfo_CreateNBT(const CloneMCJ_WorldInfo *, const struct CloneMCJ_NBTBaseTag *);

void CloneMCJ_World_Initialize(CloneMCJ_World *, CloneMCJLong, int);
void CloneMCJ_World_InitializeDeferred(CloneMCJ_World *, CloneMCJLong, int);
void CloneMCJ_World_Destroy(CloneMCJ_World *);
void CloneMCJ_World_SetActiveRadius(CloneMCJ_World *, int);
void CloneMCJ_World_SetChunkMemoryBudget(CloneMCJ_World *, unsigned long);
void CloneMCJ_World_SetPlayerGlobalPosition(CloneMCJ_World *, double, double);
void CloneMCJ_World_ServiceChunkStreaming(CloneMCJ_World *);
int CloneMCJ_World_GlobalToChunk(int);
int CloneMCJ_World_GlobalToLocal(int);
CloneMCJ_Chunk *CloneMCJ_World_GetChunkFromChunkCoords(CloneMCJ_World *, int, int);
CloneMCJ_Chunk *CloneMCJ_World_GetChunkFromBlockCoords(CloneMCJ_World *, int, int);
CloneMCJ_Chunk *CloneMCJ_World_GetLoadedChunkFromChunkCoords(CloneMCJ_World *, int, int);
int CloneMCJ_World_CheckChunksExist(CloneMCJ_World *, int, int, int, int, int, int);
int CloneMCJ_World_GetBlockId(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_GetLoadedBlockId(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_GetLoadedBlockMetadata(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_GetBlockMetadata(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_SetBlockWithMetadata(CloneMCJ_World *, int, int, int, int, int);
int CloneMCJ_World_SetBlock(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_SetBlockWithMetadataNotify(CloneMCJ_World *, int, int, int, int, int);
int CloneMCJ_World_SetBlockNotify(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_SetBlockMetadata(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_SetBlockMetadataNotify(CloneMCJ_World *, int, int, int, int);
void CloneMCJ_World_NotifyBlockOfNeighborChange(CloneMCJ_World *, int, int, int, int);
void CloneMCJ_World_NotifyBlocksOfNeighborChange(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_IsBlockProvidingPowerTo(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_IsBlockGettingPowered(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_IsBlockIndirectlyGettingPowered(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_IsAirBlock(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_IsWaterBlock(int);
int CloneMCJ_World_IsLiquidBlock(int);
int CloneMCJ_World_IsSolidBlockID(int);
int CloneMCJ_World_IsReplaceableForTree(int);
int CloneMCJ_World_CanPlantStay(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_CanReedStay(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_CanCactusStay(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_GetSavedLightValue(CloneMCJ_World *, int, int, int, int);
int CloneMCJ_World_ScheduleBlockUpdate(CloneMCJ_World *, int, int, int, int, CloneMCJLong);
void CloneMCJ_World_TickTime(CloneMCJ_World *, int);
void CloneMCJ_World_Tick(CloneMCJ_World *);
void CloneMCJ_World_UpdateWeather(CloneMCJ_World *);
void CloneMCJ_World_StopPrecipitation(CloneMCJ_World *);
float CloneMCJ_World_GetRainStrength(const CloneMCJ_World *, float);
float CloneMCJ_World_GetThunderStrength(const CloneMCJ_World *, float);
float CloneMCJ_WorldProvider_CalculateCelestialAngle(CloneMCJLong, float);
void CloneMCJ_WorldProvider_InitializeSurface(CloneMCJ_WorldProvider *);
void CloneMCJ_WorldProviderHell_Initialize(CloneMCJ_WorldProvider *);
void CloneMCJ_WorldProviderHell_GetFogColor(float *, float *, float *);
void CloneMCJ_WorldProviderSky_Initialize(CloneMCJ_WorldProvider *);
void CloneMCJ_WorldProviderSky_GetSkyColor(float, float *, float *, float *);
void CloneMCJ_WorldProvider_GenerateLightBrightnessTable(CloneMCJ_WorldProvider *);
int CloneMCJ_WorldProvider_CalcSunriseSunsetColors(CloneMCJ_WorldProvider *, float, float, float *);
void CloneMCJ_WorldProvider_GetFogColor(float, float, float *, float *, float *);
float CloneMCJ_World_GetCelestialAngle(const CloneMCJ_World *, float);
int CloneMCJ_World_CalculateSkylightSubtracted(const CloneMCJ_World *, float);
float CloneMCJ_World_GetStarBrightness(const CloneMCJ_World *, float);
void CloneMCJ_World_GetSkyColor(const CloneMCJ_World *, float, float *, float *, float *);
void CloneMCJ_World_GetSkyColorAt(const CloneMCJ_World *, int, int, float,
    float *, float *, float *);
void CloneMCJ_World_GetSkyColorAtVisualSafe(const CloneMCJ_World *, int, int,
    float, float *, float *, float *);
void CloneMCJ_World_GetCloudColor(const CloneMCJ_World *, float, float *, float *, float *);
int CloneMCJ_World_CanExistingBlockSeeTheSky(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_CanBlockBeRainedOn(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_GetBlockLightValue(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_GetFullBlockLightValue(CloneMCJ_World *, int, int, int);
void CloneMCJ_World_SetLightValue(CloneMCJ_World *, int, int, int, int, int);
void CloneMCJ_World_MarkLightingRegionDirty(CloneMCJ_World *, int, int, int, int);
void CloneMCJ_World_NeighborLightPropagationChanged(CloneMCJ_World *, int, int, int, int, int);
int CloneMCJ_World_ScheduleLightingUpdate(CloneMCJ_World *, int, int, int, int, int, int, int);
int CloneMCJ_World_UpdatingLighting(CloneMCJ_World *);
int CloneMCJ_World_GetBlockLightOpacity(int);
int CloneMCJ_World_GetBlockLightEmission(int);
void CloneMCJ_World_RegisterBlockTick(CloneMCJ_World *, int, int, CloneMCJ_BlockTickProc, void *);
int CloneMCJ_World_ProcessScheduledTicks(CloneMCJ_World *, int);
void CloneMCJ_World_UpdateRandomBlocks(CloneMCJ_World *);
void CloneMCJ_World_SetGameplayHooks(CloneMCJ_World *, CloneMCJ_GameplayTickProc,
    CloneMCJ_GameplayPrepareSaveProc, void *);
void CloneMCJ_World_SetGameplayDimensionHook(CloneMCJ_World *, CloneMCJ_GameplayDimensionProc);
int CloneMCJ_Priority6_RunSelfTests(char *, unsigned int);
int CloneMCJ_World_CountLoadedChunks(const CloneMCJ_World *);
int CloneMCJ_World_CountLoadedChunksNearPlayer(CloneMCJ_World *, int);
int CloneMCJ_World_IsChunkLoaded(CloneMCJ_World *, int, int);
int CloneMCJ_World_FindTopSolidBlock(CloneMCJ_World *, int, int);
int CloneMCJ_World_BlockExists(CloneMCJ_World *, int, int, int);
int CloneMCJ_World_AttachSaveHandler(CloneMCJ_World *, struct CloneMCJ_SaveHandlerTag *, const char *);
int CloneMCJ_World_SaveAll(CloneMCJ_World *, int);
int CloneMCJ_World_PrepareSaveSnapshot(CloneMCJ_World *);
const char *CloneMCJ_World_GetLastSaveError(const CloneMCJ_World *);
void CloneMCJ_World_MarkResidentChunksModified(CloneMCJ_World *);
int CloneMCJ_World_SaveChunksBudget(CloneMCJ_World *, int, int, int *);
int CloneMCJ_World_CommitLevelSave(CloneMCJ_World *);
int CloneMCJ_World_BootstrapSpawnStep(CloneMCJ_World *, int);
int CloneMCJ_World_SetDimension(CloneMCJ_World *, int, int);
int CloneMCJ_Teleporter_PlaceInPortal(CloneMCJ_World *, struct CloneMCJ_EntityTag *);
int CloneMCJ_Teleporter_FindPortal(CloneMCJ_World *, struct CloneMCJ_EntityTag *, int);
int CloneMCJ_Teleporter_CreatePortal(CloneMCJ_World *, struct CloneMCJ_EntityTag *);

int CloneMCJ_ChunkProviderHell_Initialize(CloneMCJ_ChunkProviderHell *, CloneMCJLong);
void CloneMCJ_ChunkProviderHell_Destroy(CloneMCJ_ChunkProviderHell *);
int CloneMCJ_ChunkProviderHell_IsFortressAt(CloneMCJLong, int, int);
int CloneMCJ_ChunkProviderHell_GenerateChunk(CloneMCJ_ChunkProviderHell *, CloneMCJ_Chunk *, int, int);
void CloneMCJ_ChunkProviderHell_PopulateWorldChunk(CloneMCJ_ChunkProviderHell *, CloneMCJ_World *, int, int);
int CloneMCJ_ChunkProviderSky_Initialize(CloneMCJ_ChunkProviderSky *, CloneMCJLong);
void CloneMCJ_ChunkProviderSky_Destroy(CloneMCJ_ChunkProviderSky *);
int CloneMCJ_ChunkProviderSky_GenerateChunk(CloneMCJ_ChunkProviderSky *, CloneMCJ_Chunk *, int, int);
void CloneMCJ_ChunkProviderSky_PopulateWorldChunk(CloneMCJ_ChunkProviderSky *, CloneMCJ_World *, int, int);

/* Direct Java WorldGen* APIs, implemented in same-named C files. */
int CloneMCJ_WorldGenLakes_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int);
int CloneMCJ_WorldGenDungeons_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenClay_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int);
int CloneMCJ_WorldGenMinable_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int, int);
int CloneMCJ_WorldGenTrees_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenForest_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenBigTree_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenTaiga1_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenTaiga2_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenHellLava_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int);
int CloneMCJ_WorldGenFire_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenGlowStone1_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenGlowStone2_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenFlowers_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int);
int CloneMCJ_WorldGenTallGrass_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int, int);
int CloneMCJ_WorldGenDeadBush_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int);
int CloneMCJ_WorldGenReed_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenPumpkin_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenCactus_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_WorldGenLiquids_Generate(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int, int);
int CloneMCJ_BiomeGenBase_GenerateDefaultTree(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_BiomeGenForest_GenerateTree(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_BiomeGenRainforest_GenerateTree(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_BiomeGenTaiga_GenerateTree(CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
int CloneMCJ_BiomeGenBase_GenerateTree(const CloneMCJ_BiomeGenBase *, CloneMCJ_World *, CloneMCJavaRandom *, int, int, int);
void CloneMCJ_WorldGenerator_SetScale(double, double, double);

int CloneMCJ_ChunkCache_Initialize(CloneMCJ_ChunkCacheView *, CloneMCJ_World *, int, int, int, int, int, int);
int CloneMCJ_ChunkCache_GetBlockId(CloneMCJ_ChunkCacheView *, int, int, int);
int CloneMCJ_ChunkCache_GetBlockMetadata(CloneMCJ_ChunkCacheView *, int, int, int);
int CloneMCJ_ChunkCache_GetLightValue(CloneMCJ_ChunkCacheView *, int, int, int);
void CloneMCJ_WorldClient_Initialize(CloneMCJ_WorldClient *, void *, CloneMCJLong, int);
void CloneMCJ_WorldClient_Destroy(CloneMCJ_WorldClient *);
void CloneMCJ_WorldClient_DoPreChunk(CloneMCJ_WorldClient *, int, int, int);
CloneMCJ_Chunk *CloneMCJ_WorldClient_GetChunkFromChunkCoords(CloneMCJ_WorldClient *, int, int);
int CloneMCJ_WorldClient_SetBlockAndMetadata(CloneMCJ_WorldClient *, int, int, int, int, int);
int CloneMCJ_WorldClient_SetBlock(CloneMCJ_WorldClient *, int, int, int, int);

/* BiomeGenBase.java: class, 237 Java lines. */
void CloneMCJ_BiomeGenBase_Register(void);
const char *CloneMCJ_BiomeGenBase_JavaName(void);
const char *CloneMCJ_BiomeGenBase_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenBase_JavaSourceHash32(void);

/* BiomeGenDesert.java: class, 18 Java lines. */
void CloneMCJ_BiomeGenDesert_Register(void);
const char *CloneMCJ_BiomeGenDesert_JavaName(void);
const char *CloneMCJ_BiomeGenDesert_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenDesert_JavaSourceHash32(void);

/* BiomeGenForest.java: class, 37 Java lines. */
void CloneMCJ_BiomeGenForest_Register(void);
const char *CloneMCJ_BiomeGenForest_JavaName(void);
const char *CloneMCJ_BiomeGenForest_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenForest_JavaSourceHash32(void);

/* BiomeGenHell.java: class, 24 Java lines. */
void CloneMCJ_BiomeGenHell_Register(void);
const char *CloneMCJ_BiomeGenHell_JavaName(void);
const char *CloneMCJ_BiomeGenHell_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenHell_JavaSourceHash32(void);

/* BiomeGenRainforest.java: class, 30 Java lines. */
void CloneMCJ_BiomeGenRainforest_Register(void);
const char *CloneMCJ_BiomeGenRainforest_JavaName(void);
const char *CloneMCJ_BiomeGenRainforest_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenRainforest_JavaSourceHash32(void);

/* BiomeGenSky.java: class, 28 Java lines. */
void CloneMCJ_BiomeGenSky_Register(void);
const char *CloneMCJ_BiomeGenSky_JavaName(void);
const char *CloneMCJ_BiomeGenSky_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenSky_JavaSourceHash32(void);

/* BiomeGenSwamp.java: class, 18 Java lines. */
void CloneMCJ_BiomeGenSwamp_Register(void);
const char *CloneMCJ_BiomeGenSwamp_JavaName(void);
const char *CloneMCJ_BiomeGenSwamp_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenSwamp_JavaSourceHash32(void);

/* BiomeGenTaiga.java: class, 33 Java lines. */
void CloneMCJ_BiomeGenTaiga_Register(void);
const char *CloneMCJ_BiomeGenTaiga_JavaName(void);
const char *CloneMCJ_BiomeGenTaiga_AssignedFolder(void);
unsigned long CloneMCJ_BiomeGenTaiga_JavaSourceHash32(void);

/* Chunk.java: class, 696 Java lines. */
void CloneMCJ_Chunk_Register(void);
const char *CloneMCJ_Chunk_JavaName(void);
const char *CloneMCJ_Chunk_AssignedFolder(void);
unsigned long CloneMCJ_Chunk_JavaSourceHash32(void);

/* ChunkBlockMap.java: class, 51 Java lines. */
void CloneMCJ_ChunkBlockMap_Register(void);
const char *CloneMCJ_ChunkBlockMap_JavaName(void);
const char *CloneMCJ_ChunkBlockMap_AssignedFolder(void);
unsigned long CloneMCJ_ChunkBlockMap_JavaSourceHash32(void);

/* ChunkCache.java: class, 206 Java lines. */
void CloneMCJ_ChunkCache_Register(void);
const char *CloneMCJ_ChunkCache_JavaName(void);
const char *CloneMCJ_ChunkCache_AssignedFolder(void);
unsigned long CloneMCJ_ChunkCache_JavaSourceHash32(void);

/* ChunkCoordinates.java: class, 81 Java lines. */
void CloneMCJ_ChunkCoordinates_Register(void);
const char *CloneMCJ_ChunkCoordinates_JavaName(void);
const char *CloneMCJ_ChunkCoordinates_AssignedFolder(void);
unsigned long CloneMCJ_ChunkCoordinates_JavaSourceHash32(void);

/* ChunkCoordIntPair.java: class, 36 Java lines. */
void CloneMCJ_ChunkCoordIntPair_Register(void);
const char *CloneMCJ_ChunkCoordIntPair_JavaName(void);
const char *CloneMCJ_ChunkCoordIntPair_AssignedFolder(void);
unsigned long CloneMCJ_ChunkCoordIntPair_JavaSourceHash32(void);

/* ChunkPosition.java: class, 39 Java lines. */
void CloneMCJ_ChunkPosition_Register(void);
const char *CloneMCJ_ChunkPosition_JavaName(void);
const char *CloneMCJ_ChunkPosition_AssignedFolder(void);
unsigned long CloneMCJ_ChunkPosition_JavaSourceHash32(void);

/* ChunkProvider.java: class, 235 Java lines. */
void CloneMCJ_ChunkProvider_Register(void);
const char *CloneMCJ_ChunkProvider_JavaName(void);
const char *CloneMCJ_ChunkProvider_AssignedFolder(void);
unsigned long CloneMCJ_ChunkProvider_JavaSourceHash32(void);

/* ChunkProviderClient.java: class, 101 Java lines. */
void CloneMCJ_ChunkProviderClient_Register(void);
const char *CloneMCJ_ChunkProviderClient_JavaName(void);
const char *CloneMCJ_ChunkProviderClient_AssignedFolder(void);
unsigned long CloneMCJ_ChunkProviderClient_JavaSourceHash32(void);

/* ChunkProviderGenerate.java: class, 700 Java lines. */
void CloneMCJ_ChunkProviderGenerate_Register(void);
const char *CloneMCJ_ChunkProviderGenerate_JavaName(void);
const char *CloneMCJ_ChunkProviderGenerate_AssignedFolder(void);
unsigned long CloneMCJ_ChunkProviderGenerate_JavaSourceHash32(void);

/* ChunkProviderHell.java: class, 435 Java lines. */
void CloneMCJ_ChunkProviderHell_Register(void);
const char *CloneMCJ_ChunkProviderHell_JavaName(void);
const char *CloneMCJ_ChunkProviderHell_AssignedFolder(void);
unsigned long CloneMCJ_ChunkProviderHell_JavaSourceHash32(void);

/* ChunkProviderLoadOrGenerate.java: class, 266 Java lines. */
void CloneMCJ_ChunkProviderLoadOrGenerate_Register(void);
const char *CloneMCJ_ChunkProviderLoadOrGenerate_JavaName(void);
const char *CloneMCJ_ChunkProviderLoadOrGenerate_AssignedFolder(void);
unsigned long CloneMCJ_ChunkProviderLoadOrGenerate_JavaSourceHash32(void);

/* ChunkProviderSky.java: class, 586 Java lines. */
void CloneMCJ_ChunkProviderSky_Register(void);
const char *CloneMCJ_ChunkProviderSky_JavaName(void);
const char *CloneMCJ_ChunkProviderSky_AssignedFolder(void);
unsigned long CloneMCJ_ChunkProviderSky_JavaSourceHash32(void);

/* EmptyChunk.java: class, 172 Java lines. */
void CloneMCJ_EmptyChunk_Register(void);
const char *CloneMCJ_EmptyChunk_JavaName(void);
const char *CloneMCJ_EmptyChunk_AssignedFolder(void);
unsigned long CloneMCJ_EmptyChunk_JavaSourceHash32(void);

/* EnumCreatureType.java: enum, 78 Java lines. */
void CloneMCJ_EnumCreatureType_Register(void);
const char *CloneMCJ_EnumCreatureType_JavaName(void);
const char *CloneMCJ_EnumCreatureType_AssignedFolder(void);
unsigned long CloneMCJ_EnumCreatureType_JavaSourceHash32(void);

/* Explosion.java: class, 191 Java lines. */
void CloneMCJ_Explosion_Register(void);
const char *CloneMCJ_Explosion_JavaName(void);
const char *CloneMCJ_Explosion_AssignedFolder(void);
unsigned long CloneMCJ_Explosion_JavaSourceHash32(void);

/* IBlockAccess.java: interface, 32 Java lines. */
void CloneMCJ_IBlockAccess_Register(void);
const char *CloneMCJ_IBlockAccess_JavaName(void);
const char *CloneMCJ_IBlockAccess_AssignedFolder(void);
unsigned long CloneMCJ_IBlockAccess_JavaSourceHash32(void);

/* IChunkProvider.java: interface, 30 Java lines. */
void CloneMCJ_IChunkProvider_Register(void);
const char *CloneMCJ_IChunkProvider_JavaName(void);
const char *CloneMCJ_IChunkProvider_AssignedFolder(void);
unsigned long CloneMCJ_IChunkProvider_JavaSourceHash32(void);

/* IWorldAccess.java: interface, 36 Java lines. */
void CloneMCJ_IWorldAccess_Register(void);
const char *CloneMCJ_IWorldAccess_JavaName(void);
const char *CloneMCJ_IWorldAccess_AssignedFolder(void);
unsigned long CloneMCJ_IWorldAccess_JavaSourceHash32(void);

/* MapGenBase.java: class, 46 Java lines. */
void CloneMCJ_MapGenBase_Register(void);
const char *CloneMCJ_MapGenBase_JavaName(void);
const char *CloneMCJ_MapGenBase_AssignedFolder(void);
unsigned long CloneMCJ_MapGenBase_JavaSourceHash32(void);

/* MapGenCaves.java: class, 240 Java lines. */
void CloneMCJ_MapGenCaves_Register(void);
const char *CloneMCJ_MapGenCaves_JavaName(void);
const char *CloneMCJ_MapGenCaves_AssignedFolder(void);
unsigned long CloneMCJ_MapGenCaves_JavaSourceHash32(void);

/* MapGenCavesHell.java: class, 215 Java lines. */
void CloneMCJ_MapGenCavesHell_Register(void);
const char *CloneMCJ_MapGenCavesHell_JavaName(void);
const char *CloneMCJ_MapGenCavesHell_AssignedFolder(void);
unsigned long CloneMCJ_MapGenCavesHell_JavaSourceHash32(void);

/* NextTickListEntry.java: class, 75 Java lines. */
void CloneMCJ_NextTickListEntry_Register(void);
const char *CloneMCJ_NextTickListEntry_JavaName(void);
const char *CloneMCJ_NextTickListEntry_AssignedFolder(void);
unsigned long CloneMCJ_NextTickListEntry_JavaSourceHash32(void);

/* NoiseGenerator.java: class, 15 Java lines. */
void CloneMCJ_NoiseGenerator_Register(void);
const char *CloneMCJ_NoiseGenerator_JavaName(void);
const char *CloneMCJ_NoiseGenerator_AssignedFolder(void);
unsigned long CloneMCJ_NoiseGenerator_JavaSourceHash32(void);

/* NoiseGenerator2.java: class, 159 Java lines. */
void CloneMCJ_NoiseGenerator2_Register(void);
const char *CloneMCJ_NoiseGenerator2_JavaName(void);
const char *CloneMCJ_NoiseGenerator2_AssignedFolder(void);
unsigned long CloneMCJ_NoiseGenerator2_JavaSourceHash32(void);

/* NoiseGeneratorOctaves.java: class, 73 Java lines. */
void CloneMCJ_NoiseGeneratorOctaves_Register(void);
const char *CloneMCJ_NoiseGeneratorOctaves_JavaName(void);
const char *CloneMCJ_NoiseGeneratorOctaves_AssignedFolder(void);
unsigned long CloneMCJ_NoiseGeneratorOctaves_JavaSourceHash32(void);

/* NoiseGeneratorOctaves2.java: class, 63 Java lines. */
void CloneMCJ_NoiseGeneratorOctaves2_Register(void);
const char *CloneMCJ_NoiseGeneratorOctaves2_JavaName(void);
const char *CloneMCJ_NoiseGeneratorOctaves2_AssignedFolder(void);
unsigned long CloneMCJ_NoiseGeneratorOctaves2_JavaSourceHash32(void);

/* NoiseGeneratorPerlin.java: class, 233 Java lines. */
void CloneMCJ_NoiseGeneratorPerlin_Register(void);
const char *CloneMCJ_NoiseGeneratorPerlin_JavaName(void);
const char *CloneMCJ_NoiseGeneratorPerlin_AssignedFolder(void);
unsigned long CloneMCJ_NoiseGeneratorPerlin_JavaSourceHash32(void);

/* SpawnerAnimals.java: class, 299 Java lines. */
void CloneMCJ_SpawnerAnimals_Register(void);
const char *CloneMCJ_SpawnerAnimals_JavaName(void);
const char *CloneMCJ_SpawnerAnimals_AssignedFolder(void);
unsigned long CloneMCJ_SpawnerAnimals_JavaSourceHash32(void);

/* SpawnListEntry.java: class, 20 Java lines. */
void CloneMCJ_SpawnListEntry_Register(void);
const char *CloneMCJ_SpawnListEntry_JavaName(void);
const char *CloneMCJ_SpawnListEntry_AssignedFolder(void);
unsigned long CloneMCJ_SpawnListEntry_JavaSourceHash32(void);

/* Teleporter.java: class, 306 Java lines. */
void CloneMCJ_Teleporter_Register(void);
const char *CloneMCJ_Teleporter_JavaName(void);
const char *CloneMCJ_Teleporter_AssignedFolder(void);
unsigned long CloneMCJ_Teleporter_JavaSourceHash32(void);

/* World.java: class, 2940 Java lines. */
void CloneMCJ_World_Register(void);
const char *CloneMCJ_World_JavaName(void);
const char *CloneMCJ_World_AssignedFolder(void);
unsigned long CloneMCJ_World_JavaSourceHash32(void);

/* WorldBlockPositionType.java: class, 34 Java lines. */
void CloneMCJ_WorldBlockPositionType_Register(void);
const char *CloneMCJ_WorldBlockPositionType_JavaName(void);
const char *CloneMCJ_WorldBlockPositionType_AssignedFolder(void);
unsigned long CloneMCJ_WorldBlockPositionType_JavaSourceHash32(void);

/* WorldChunkManager.java: class, 139 Java lines. */
void CloneMCJ_WorldChunkManager_Register(void);
const char *CloneMCJ_WorldChunkManager_JavaName(void);
const char *CloneMCJ_WorldChunkManager_AssignedFolder(void);
unsigned long CloneMCJ_WorldChunkManager_JavaSourceHash32(void);

/* WorldChunkManagerHell.java: class, 74 Java lines. */
void CloneMCJ_WorldChunkManagerHell_Register(void);
const char *CloneMCJ_WorldChunkManagerHell_JavaName(void);
const char *CloneMCJ_WorldChunkManagerHell_AssignedFolder(void);
unsigned long CloneMCJ_WorldChunkManagerHell_JavaSourceHash32(void);

/* WorldClient.java: class, 296 Java lines. */
void CloneMCJ_WorldClient_Register(void);
const char *CloneMCJ_WorldClient_JavaName(void);
const char *CloneMCJ_WorldClient_AssignedFolder(void);
unsigned long CloneMCJ_WorldClient_JavaSourceHash32(void);

/* WorldGenBigTree.java: class, 455 Java lines. */
void CloneMCJ_WorldGenBigTree_Register(void);
const char *CloneMCJ_WorldGenBigTree_JavaName(void);
const char *CloneMCJ_WorldGenBigTree_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenBigTree_JavaSourceHash32(void);

/* WorldGenCactus.java: class, 44 Java lines. */
void CloneMCJ_WorldGenCactus_Register(void);
const char *CloneMCJ_WorldGenCactus_JavaName(void);
const char *CloneMCJ_WorldGenCactus_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenCactus_JavaSourceHash32(void);

/* WorldGenClay.java: class, 81 Java lines. */
void CloneMCJ_WorldGenClay_Register(void);
const char *CloneMCJ_WorldGenClay_JavaName(void);
const char *CloneMCJ_WorldGenClay_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenClay_JavaSourceHash32(void);

/* WorldGenDeadBush.java: class, 40 Java lines. */
void CloneMCJ_WorldGenDeadBush_Register(void);
const char *CloneMCJ_WorldGenDeadBush_JavaName(void);
const char *CloneMCJ_WorldGenDeadBush_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenDeadBush_JavaSourceHash32(void);

/* WorldGenDungeons.java: class, 224 Java lines. */
void CloneMCJ_WorldGenDungeons_Register(void);
const char *CloneMCJ_WorldGenDungeons_JavaName(void);
const char *CloneMCJ_WorldGenDungeons_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenDungeons_JavaSourceHash32(void);

/* WorldGenerator.java: class, 25 Java lines. */
void CloneMCJ_WorldGenerator_Register(void);
const char *CloneMCJ_WorldGenerator_JavaName(void);
const char *CloneMCJ_WorldGenerator_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenerator_JavaSourceHash32(void);

/* WorldGenFire.java: class, 35 Java lines. */
void CloneMCJ_WorldGenFire_Register(void);
const char *CloneMCJ_WorldGenFire_JavaName(void);
const char *CloneMCJ_WorldGenFire_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenFire_JavaSourceHash32(void);

/* WorldGenFlowers.java: class, 38 Java lines. */
void CloneMCJ_WorldGenFlowers_Register(void);
const char *CloneMCJ_WorldGenFlowers_JavaName(void);
const char *CloneMCJ_WorldGenFlowers_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenFlowers_JavaSourceHash32(void);

/* WorldGenForest.java: class, 102 Java lines. */
void CloneMCJ_WorldGenForest_Register(void);
const char *CloneMCJ_WorldGenForest_JavaName(void);
const char *CloneMCJ_WorldGenForest_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenForest_JavaSourceHash32(void);

/* WorldGenGlowStone1.java: class, 82 Java lines. */
void CloneMCJ_WorldGenGlowStone1_Register(void);
const char *CloneMCJ_WorldGenGlowStone1_JavaName(void);
const char *CloneMCJ_WorldGenGlowStone1_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenGlowStone1_JavaSourceHash32(void);

/* WorldGenGlowStone2.java: class, 82 Java lines. */
void CloneMCJ_WorldGenGlowStone2_Register(void);
const char *CloneMCJ_WorldGenGlowStone2_JavaName(void);
const char *CloneMCJ_WorldGenGlowStone2_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenGlowStone2_JavaSourceHash32(void);

/* WorldGenHellLava.java: class, 84 Java lines. */
void CloneMCJ_WorldGenHellLava_Register(void);
const char *CloneMCJ_WorldGenHellLava_JavaName(void);
const char *CloneMCJ_WorldGenHellLava_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenHellLava_JavaSourceHash32(void);

/* WorldGenLakes.java: class, 141 Java lines. */
void CloneMCJ_WorldGenLakes_Register(void);
const char *CloneMCJ_WorldGenLakes_JavaName(void);
const char *CloneMCJ_WorldGenLakes_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenLakes_JavaSourceHash32(void);

/* WorldGenLiquids.java: class, 80 Java lines. */
void CloneMCJ_WorldGenLiquids_Register(void);
const char *CloneMCJ_WorldGenLiquids_JavaName(void);
const char *CloneMCJ_WorldGenLiquids_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenLiquids_JavaSourceHash32(void);

/* WorldGenMinable.java: class, 79 Java lines. */
void CloneMCJ_WorldGenMinable_Register(void);
const char *CloneMCJ_WorldGenMinable_JavaName(void);
const char *CloneMCJ_WorldGenMinable_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenMinable_JavaSourceHash32(void);

/* WorldGenPumpkin.java: class, 35 Java lines. */
void CloneMCJ_WorldGenPumpkin_Register(void);
const char *CloneMCJ_WorldGenPumpkin_JavaName(void);
const char *CloneMCJ_WorldGenPumpkin_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenPumpkin_JavaSourceHash32(void);

/* WorldGenReed.java: class, 44 Java lines. */
void CloneMCJ_WorldGenReed_Register(void);
const char *CloneMCJ_WorldGenReed_JavaName(void);
const char *CloneMCJ_WorldGenReed_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenReed_JavaSourceHash32(void);

/* WorldGenTaiga1.java: class, 112 Java lines. */
void CloneMCJ_WorldGenTaiga1_Register(void);
const char *CloneMCJ_WorldGenTaiga1_JavaName(void);
const char *CloneMCJ_WorldGenTaiga1_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenTaiga1_JavaSourceHash32(void);

/* WorldGenTaiga2.java: class, 119 Java lines. */
void CloneMCJ_WorldGenTaiga2_Register(void);
const char *CloneMCJ_WorldGenTaiga2_JavaName(void);
const char *CloneMCJ_WorldGenTaiga2_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenTaiga2_JavaSourceHash32(void);

/* WorldGenTallGrass.java: class, 42 Java lines. */
void CloneMCJ_WorldGenTallGrass_Register(void);
const char *CloneMCJ_WorldGenTallGrass_JavaName(void);
const char *CloneMCJ_WorldGenTallGrass_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenTallGrass_JavaSourceHash32(void);

/* WorldGenTrees.java: class, 102 Java lines. */
void CloneMCJ_WorldGenTrees_Register(void);
const char *CloneMCJ_WorldGenTrees_JavaName(void);
const char *CloneMCJ_WorldGenTrees_AssignedFolder(void);
unsigned long CloneMCJ_WorldGenTrees_JavaSourceHash32(void);

/* WorldInfo.java: class, 266 Java lines. */
void CloneMCJ_WorldInfo_Register(void);
const char *CloneMCJ_WorldInfo_JavaName(void);
const char *CloneMCJ_WorldInfo_AssignedFolder(void);
unsigned long CloneMCJ_WorldInfo_JavaSourceHash32(void);

/* WorldProvider.java: class, 162 Java lines. */
void CloneMCJ_WorldProvider_Register(void);
const char *CloneMCJ_WorldProvider_JavaName(void);
const char *CloneMCJ_WorldProvider_AssignedFolder(void);
unsigned long CloneMCJ_WorldProvider_JavaSourceHash32(void);

/* WorldProviderHell.java: class, 73 Java lines. */
void CloneMCJ_WorldProviderHell_Register(void);
const char *CloneMCJ_WorldProviderHell_JavaName(void);
const char *CloneMCJ_WorldProviderHell_AssignedFolder(void);
unsigned long CloneMCJ_WorldProviderHell_JavaSourceHash32(void);

/* WorldProviderSky.java: class, 84 Java lines. */
void CloneMCJ_WorldProviderSky_Register(void);
const char *CloneMCJ_WorldProviderSky_JavaName(void);
const char *CloneMCJ_WorldProviderSky_AssignedFolder(void);
unsigned long CloneMCJ_WorldProviderSky_JavaSourceHash32(void);

/* WorldProviderSurface.java: class, 18 Java lines. */
void CloneMCJ_WorldProviderSurface_Register(void);
const char *CloneMCJ_WorldProviderSurface_JavaName(void);
const char *CloneMCJ_WorldProviderSurface_AssignedFolder(void);
unsigned long CloneMCJ_WorldProviderSurface_JavaSourceHash32(void);

#ifdef __cplusplus
}
#endif
#endif /* CLONEMC_JAVA_PORT_40_WORLD_H */
