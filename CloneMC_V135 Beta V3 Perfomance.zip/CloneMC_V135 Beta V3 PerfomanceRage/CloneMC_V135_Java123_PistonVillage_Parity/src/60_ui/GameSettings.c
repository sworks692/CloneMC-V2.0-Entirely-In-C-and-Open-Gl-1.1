/*
 * CloneMC Java port scaffold: GameSettings
 *
 * Java source: GameSettings.java
 * Java type: class GameSettings
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 763a9181d87b03be2aec5ee0968aac37bd39b10ad0492bab0884088c27b82764
 * Java lines: 495
 * Discovered declared fields: 36
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: KeyBinding, StringTranslate, EnumOptions, SoundManager, RenderGlobal, RenderEngine, EnumOptionsMappingHelper, StatCollector, keyBindForward, keyBindLeft, keyBindBack, keyBindRight, keyBindJump, keyBindSneak, keyBindDrop, keyBindInventory, keyBindChat, keyBindToggleFog, mouseSensit
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public float musicVolume
 * - public float soundVolume
 * - public float mouseSensitivity
 * - public boolean invertMouse
 * - public int renderDistance
 * - public boolean viewBobbing
 * - public boolean anaglyph
 * - public boolean advancedOpengl
 * - public int limitFramerate
 * - public boolean fancyGraphics
 * - public boolean ambientOcclusion
 * - public String skin
 * - public KeyBinding keyBindForward
 * - public KeyBinding keyBindLeft
 * - public KeyBinding keyBindBack
 * - public KeyBinding keyBindRight
 * - public KeyBinding keyBindJump
 * - public KeyBinding keyBindInventory
 * - public KeyBinding keyBindDrop
 * - public KeyBinding keyBindChat
 * - public KeyBinding keyBindToggleFog
 * - public KeyBinding keyBindSneak
 * - public KeyBinding keyBindings[]
 * - protected Minecraft mc
 * - private File optionsFile
 * - public int difficulty
 * - public boolean hideGUI
 * - public boolean thirdPersonView
 * - public boolean showDebugInfo
 * - public String lastServer
 * - public boolean field_22275_C
 * - public boolean smoothCamera
 * - public boolean field_22273_E
 * - public float field_22272_F
 * - public float field_22271_G
 * - public int guiScale
 *
 * Java method/constructor inventory:
 * - public GameSettings(Minecraft minecraft, File file)
 * - public GameSettings()
 * - public String getKeyBindingDescription(int i)
 * - public String getOptionDisplayString(int i)
 * - public void setKeyBinding(int i, int j)
 * - public void setOptionFloatValue(EnumOptions enumoptions, float f)
 * - public void setOptionValue(EnumOptions enumoptions, int i)
 * - public float getOptionFloatValue(EnumOptions enumoptions)
 * - public boolean getOptionOrdinalValue(EnumOptions enumoptions)
 * - public String getKeyBinding(EnumOptions enumoptions)
 * - public void loadOptions()
 * - private float parseFloat(String s)
 * - public void saveOptions()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static int CloneMCSettings_ClampInt(int value, int minimum, int maximum)
{
    if (value < minimum) { return minimum; }
    if (value > maximum) { return maximum; }
    return value;
}

static float CloneMCSettings_ClampFloat(float value, float minimum, float maximum)
{
    if (value < minimum) { return minimum; }
    if (value > maximum) { return maximum; }
    return value;
}

static int CloneMCSettings_ParseBoolean(const char *value)
{
    if (!value) return 0;
    return !strcmp(value, "true") || !strcmp(value, "TRUE") || atoi(value) != 0;
}

static void CloneMCSettings_Copy(char *destination, unsigned long capacity,
    const char *source)
{
    if (!destination || capacity == 0) return;
    if (!source) source = "";
    strncpy(destination, source, capacity - 1);
    destination[capacity - 1] = '\0';
}

static void CloneMCSettings_Append(char *destination,unsigned long capacity,
    const char *source)
{
    unsigned long used;
    if(!destination||capacity==0)return;
    used=(unsigned long)strlen(destination);
    if(used>=capacity){destination[capacity-1]='\0';return;}
    CloneMCSettings_Copy(destination+used,capacity-used,source);
}

static char *CloneMCSettings_Trim(char *text)
{
    char *end;
    while (*text && isspace((unsigned char)*text)) { text++; }
    end = text + strlen(text);
    while (end > text && isspace((unsigned char)end[-1])) { end--; }
    *end = '\0';
    return text;
}

static void CloneMCSettings_ApplyPair(CloneMCGameSettings *settings, const char *key, const char *value)
{
    int index;
    static const char *keyNames[CLONEMC_GAME_KEY_BINDING_COUNT] = {
        "key.forward","key.left","key.back","key.right","key.jump",
        "key.sneak","key.drop","key.inventory","key.chat","key.fog"
    };
    if (!settings || !key || !value) { return; }
    if (strcmp(key, "width") == 0 || strcmp(key, "clonemcWidth") == 0) { settings->width = atoi(value); }
    else if (strcmp(key, "height") == 0 || strcmp(key, "clonemcHeight") == 0) { settings->height = atoi(value); }
    else if (strcmp(key, "colorBits") == 0 || strcmp(key, "clonemcColorBits") == 0) { settings->colorBits = atoi(value); }
    else if (strcmp(key, "depthBits") == 0 || strcmp(key, "clonemcDepthBits") == 0) { settings->depthBits = atoi(value); }
    else if (strcmp(key, "fullscreen") == 0 || strcmp(key, "clonemcFullscreen") == 0) { settings->fullscreen = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "viewDistance") == 0) {
        static const int legacyChunks[4] = {16, 8, 4, 2};
        index = CloneMCSettings_ClampInt(atoi(value), 0, 3);
        settings->renderDistanceChunks = legacyChunks[index];
    }
    else if (strcmp(key, "renderDistanceChunks") == 0) {
        settings->renderDistanceChunks = atoi(value);
    }
    else if (strcmp(key, "fpsLimit") == 0 || strcmp(key, "limitFramerate") == 0) { settings->limitFramerate = atoi(value); }
    else if (strcmp(key, "invertYMouse") == 0 || strcmp(key, "invertMouse") == 0) { settings->invertMouse = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "mouseSensitivity") == 0) { settings->mouseSensitivity = (float)atof(value); }
    else if (strcmp(key, "sound") == 0 || strcmp(key, "soundVolume") == 0) { settings->soundVolume = (float)atof(value); }
    else if (strcmp(key, "music") == 0 || strcmp(key, "musicVolume") == 0) { settings->musicVolume = (float)atof(value); }
    else if (strcmp(key, "difficulty") == 0) { settings->difficulty = atoi(value); }
    else if (strcmp(key, "fancyGraphics") == 0) { settings->fancyGraphics = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "ao") == 0 || strcmp(key, "ambientOcclusion") == 0) { settings->ambientOcclusion = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "bobView") == 0 || strcmp(key, "viewBobbing") == 0) { settings->viewBobbing = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "anaglyph3d") == 0) { settings->anaglyph = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "advancedOpengl") == 0) { settings->advancedOpenGL = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "guiScale") == 0) { settings->guiScale = atoi(value); }
    /* "visualSafety" was a V132-only extension.  Accept and ignore the key so
     * an existing options.txt remains readable without reviving the feature. */
    else if (strcmp(key, "visualSafety") == 0) { settings->visualSafety = 0; }
    else if (strcmp(key, "doubleTapSprint") == 0) { settings->doubleTapSprint = CloneMCSettings_ParseBoolean(value); }
    else if (strcmp(key, "skin") == 0) { CloneMCSettings_Copy(settings->skin, sizeof(settings->skin), value); }
    else if (strcmp(key, "lastServer") == 0) { CloneMCSettings_Copy(settings->lastServer, sizeof(settings->lastServer), value); }
    else {
        for (index = 0; index < CLONEMC_GAME_KEY_BINDING_COUNT; ++index) {
            char fullName[64];
            strcpy(fullName, "key_");
            strcat(fullName, keyNames[index]);
            if (!strcmp(key, fullName)) {
                settings->keyCodes[index] = atoi(value);
                break;
            }
        }
    }
}

void CloneMCGameSettings_SynchronizeDerived(CloneMCGameSettings *settings)
{
    int chunks;
    if (!settings) return;
    chunks = CloneMCSettings_ClampInt(settings->renderDistanceChunks,
        CLONEMC_RENDER_DISTANCE_MIN_CHUNKS,
        CLONEMC_RENDER_DISTANCE_MAX_CHUNKS);
    settings->renderDistanceChunks = chunks;
    /* Keep the old four-state field only for protocol-era fog/UI compatibility.
     * The exact chunk slider remains authoritative. */
    settings->renderDistance = chunks >= 16 ? 0 : chunks >= 8 ? 1 :
        chunks >= 4 ? 2 : 3;
    /* Migrate the former Max/Balanced/Power-saver ordinals once, then retain
     * a real frame target.  Zero is the explicit Max/unlimited endpoint. */
    if(settings->limitFramerate==1)settings->limitFramerate=120;
    else if(settings->limitFramerate==2)settings->limitFramerate=40;
    if(settings->limitFramerate!=0)
        settings->limitFramerate=CloneMCSettings_ClampInt(
            settings->limitFramerate,CLONEMC_FRAMERATE_MIN,
            CLONEMC_FRAMERATE_MAX);
    settings->targetFramesPerSecond=settings->limitFramerate;
}

static void CloneMCSettings_Validate(CloneMCGameSettings *settings)
{
    if (!settings) { return; }
    settings->width = CloneMCSettings_ClampInt(settings->width, 320, 4096);
    settings->height = CloneMCSettings_ClampInt(settings->height, 240, 2160);
    if (settings->colorBits != 16 && settings->colorBits != 24 && settings->colorBits != 32) { settings->colorBits = 32; }
    if (settings->depthBits != 16 && settings->depthBits != 24 && settings->depthBits != 32) { settings->depthBits = 24; }
    settings->mouseSensitivity = CloneMCSettings_ClampFloat(settings->mouseSensitivity, 0.0f, 1.0f);
    settings->soundVolume = CloneMCSettings_ClampFloat(settings->soundVolume, 0.0f, 1.0f);
    settings->musicVolume = CloneMCSettings_ClampFloat(settings->musicVolume, 0.0f, 1.0f);
    settings->difficulty = CloneMCSettings_ClampInt(settings->difficulty, 0, 3);
    settings->guiScale = CloneMCSettings_ClampInt(settings->guiScale, 0, 3);
    settings->fullscreen = settings->fullscreen ? 1 : 0;
    settings->invertMouse = settings->invertMouse ? 1 : 0;
    settings->fancyGraphics = settings->fancyGraphics ? 1 : 0;
    settings->ambientOcclusion = settings->ambientOcclusion ? 1 : 0;
    settings->viewBobbing = settings->viewBobbing ? 1 : 0;
    settings->anaglyph = settings->anaglyph ? 1 : 0;
    settings->advancedOpenGL = settings->advancedOpenGL ? 1 : 0;
    settings->visualSafety = 0;
    settings->doubleTapSprint = settings->doubleTapSprint ? 1 : 0;
    CloneMCGameSettings_SynchronizeDerived(settings);
}

void CloneMCJ_GameSettings_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GameSettings_JavaName(void)
{
    return "net.minecraft.src.GameSettings";
}

const char *CloneMCJ_GameSettings_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GameSettings_JavaSourceHash32(void)
{
    return 0x763A9181UL;
}

void CloneMCGameSettings_SetDefaults(CloneMCGameSettings *settings)
{
    if (!settings) { return; }
    memset(settings, 0, sizeof(*settings));
    settings->width = 854;
    settings->height = 480;
    settings->colorBits = 32;
    settings->depthBits = 24;
    settings->fullscreen = 0;
    settings->renderDistance = 1;
    settings->renderDistanceChunks = CLONEMC_RENDER_DISTANCE_DEFAULT_CHUNKS;
    settings->limitFramerate = 120;
    settings->invertMouse = 0;
    settings->mouseSensitivity = 0.5f;
    settings->soundVolume = 1.0f;
    settings->musicVolume = 1.0f;
    settings->difficulty = 2;
    settings->fancyGraphics = 1;
    settings->ambientOcclusion = 1;
    settings->viewBobbing = 1;
    settings->guiScale = 0;
    settings->visualSafety = 0;
    settings->doubleTapSprint = 1;
    strcpy(settings->skin, "Default");
    settings->keyCodes[0] = 'W';
    settings->keyCodes[1] = 'A';
    settings->keyCodes[2] = 'S';
    settings->keyCodes[3] = 'D';
    settings->keyCodes[4] = 32;
    settings->keyCodes[5] = 16;
    settings->keyCodes[6] = 'Q';
    settings->keyCodes[7] = 'E';
    settings->keyCodes[8] = 'T';
    settings->keyCodes[9] = 'F';
    CloneMCSettings_Validate(settings);
}

int CloneMCGameSettings_Load(CloneMCGameSettings *settings, const char *filename)
{
    FILE *file;
    char line[256];
    char *separator;
    char *key;
    char *value;

    if (!settings || !filename) { return 0; }
    file = fopen(filename, "rt");
    if (!file) { CloneMCSettings_Validate(settings); return 0; }
    while (fgets(line, sizeof(line), file)) {
        key = CloneMCSettings_Trim(line);
        if (!key[0] || key[0] == '#' || key[0] == ';') { continue; }
        separator = strchr(key, ':');
        if (!separator) separator = strchr(key, '=');
        if (!separator) { continue; }
        *separator = '\0';
        value = CloneMCSettings_Trim(separator + 1);
        key = CloneMCSettings_Trim(key);
        CloneMCSettings_ApplyPair(settings, key, value);
    }
    fclose(file);
    CloneMCSettings_Validate(settings);
    return 1;
}

int CloneMCGameSettings_Save(const CloneMCGameSettings *settings, const char *filename)
{
    FILE *file;
    static const char *keyNames[CLONEMC_GAME_KEY_BINDING_COUNT] = {
        "key.forward","key.left","key.back","key.right","key.jump",
        "key.sneak","key.drop","key.inventory","key.chat","key.fog"
    };
    int index;
    if (!settings || !filename) { return 0; }
    file = fopen(filename, "wt");
    if (!file) { return 0; }
    fprintf(file, "music:%.4f\n", settings->musicVolume);
    fprintf(file, "sound:%.4f\n", settings->soundVolume);
    fprintf(file, "invertYMouse:%s\n", settings->invertMouse ? "true" : "false");
    fprintf(file, "mouseSensitivity:%.4f\n", settings->mouseSensitivity);
    fprintf(file, "viewDistance:%d\n", settings->renderDistance);
    fprintf(file, "renderDistanceChunks:%d\n", settings->renderDistanceChunks);
    fprintf(file, "guiScale:%d\n", settings->guiScale);
    fprintf(file, "bobView:%s\n", settings->viewBobbing ? "true" : "false");
    fprintf(file, "anaglyph3d:%s\n", settings->anaglyph ? "true" : "false");
    fprintf(file, "advancedOpengl:%s\n", settings->advancedOpenGL ? "true" : "false");
    fprintf(file, "doubleTapSprint:%s\n", settings->doubleTapSprint ? "true" : "false");
    fprintf(file, "fpsLimit:%d\n", settings->limitFramerate);
    fprintf(file, "difficulty:%d\n", settings->difficulty);
    fprintf(file, "fancyGraphics:%s\n", settings->fancyGraphics ? "true" : "false");
    fprintf(file, "ao:%s\n", settings->ambientOcclusion ? "true" : "false");
    fprintf(file, "skin:%s\n", settings->skin);
    fprintf(file, "lastServer:%s\n", settings->lastServer);
    for (index = 0; index < CLONEMC_GAME_KEY_BINDING_COUNT; ++index)
        fprintf(file, "key_%s:%d\n", keyNames[index], settings->keyCodes[index]);
    fprintf(file, "clonemcWidth:%d\n", settings->width);
    fprintf(file, "clonemcHeight:%d\n", settings->height);
    fprintf(file, "clonemcColorBits:%d\n", settings->colorBits);
    fprintf(file, "clonemcDepthBits:%d\n", settings->depthBits);
    fprintf(file, "clonemcFullscreen:%s\n", settings->fullscreen ? "true" : "false");
    fclose(file);
    return 1;
}

void CloneMCGameSettings_ApplyCommandLine(CloneMCGameSettings *settings, const char *commandLine)
{
    const char *position;
    if (!settings || !commandLine) { return; }
    if (strstr(commandLine, "-fullscreen")) { settings->fullscreen = 1; }
    if (strstr(commandLine, "-windowed")) { settings->fullscreen = 0; }
    position = strstr(commandLine, "-width=");
    if (position) { settings->width = atoi(position + 7); }
    position = strstr(commandLine, "-height=");
    if (position) { settings->height = atoi(position + 8); }
    position = strstr(commandLine, "-bpp=");
    if (position) { settings->colorBits = atoi(position + 5); }
    CloneMCSettings_Validate(settings);
}

float CloneMCGameSettings_GetOptionFloat(const CloneMCGameSettings *settings,
    int option)
{
    if (!settings) return 0.0F;
    if (option == CLONEMC_OPTION_MUSIC) return settings->musicVolume;
    if (option == CLONEMC_OPTION_SOUND) return settings->soundVolume;
    if (option == CLONEMC_OPTION_SENSITIVITY) return settings->mouseSensitivity;
    if (option == CLONEMC_OPTION_RENDER_DISTANCE)
        return (float)(settings->renderDistanceChunks-
            CLONEMC_RENDER_DISTANCE_MIN_CHUNKS) /
            (float)(CLONEMC_RENDER_DISTANCE_MAX_CHUNKS-
            CLONEMC_RENDER_DISTANCE_MIN_CHUNKS);
    if(option==CLONEMC_OPTION_FRAMERATE_LIMIT){
        if(settings->limitFramerate==0)return 1.0F;
        return ((float)(settings->limitFramerate-CLONEMC_FRAMERATE_MIN)/
            (float)(CLONEMC_FRAMERATE_MAX-CLONEMC_FRAMERATE_MIN))*0.99F;
    }
    return 0.0F;
}

int CloneMCGameSettings_SetOptionFloat(CloneMCGameSettings *settings,int option,
    float value)
{
    if (!settings) return 0;
    value = CloneMCSettings_ClampFloat(value, 0.0F, 1.0F);
    if (option == CLONEMC_OPTION_MUSIC) settings->musicVolume = value;
    else if (option == CLONEMC_OPTION_SOUND) settings->soundVolume = value;
    else if (option == CLONEMC_OPTION_SENSITIVITY) settings->mouseSensitivity = value;
    else if (option == CLONEMC_OPTION_RENDER_DISTANCE) {
        int span;
        span = CLONEMC_RENDER_DISTANCE_MAX_CHUNKS-
            CLONEMC_RENDER_DISTANCE_MIN_CHUNKS;
        settings->renderDistanceChunks = CLONEMC_RENDER_DISTANCE_MIN_CHUNKS+
            (int)(value*(float)span+0.5F);
        CloneMCGameSettings_SynchronizeDerived(settings);
    } else if(option==CLONEMC_OPTION_FRAMERATE_LIMIT){
        if(value>=0.995F)settings->limitFramerate=0;
        else{
            int target;
            target=CLONEMC_FRAMERATE_MIN+(int)((value/0.99F)*
                (float)(CLONEMC_FRAMERATE_MAX-CLONEMC_FRAMERATE_MIN)+0.5F);
            target=((target+2)/5)*5;
            settings->limitFramerate=CloneMCSettings_ClampInt(target,
                CLONEMC_FRAMERATE_MIN,CLONEMC_FRAMERATE_MAX);
        }
        CloneMCGameSettings_SynchronizeDerived(settings);
    } else return 0;
    return 1;
}

int CloneMCGameSettings_SetOptionValue(CloneMCGameSettings *settings,int option,
    int increment)
{
    if (!settings) return 0;
    if (option == CLONEMC_OPTION_INVERT_MOUSE) settings->invertMouse = !settings->invertMouse;
    else if (option == CLONEMC_OPTION_RENDER_DISTANCE) {
        settings->renderDistanceChunks += increment;
        if (settings->renderDistanceChunks > CLONEMC_RENDER_DISTANCE_MAX_CHUNKS)
            settings->renderDistanceChunks = CLONEMC_RENDER_DISTANCE_MIN_CHUNKS;
        if (settings->renderDistanceChunks < CLONEMC_RENDER_DISTANCE_MIN_CHUNKS)
            settings->renderDistanceChunks = CLONEMC_RENDER_DISTANCE_MAX_CHUNKS;
    }
    else if (option == CLONEMC_OPTION_GUI_SCALE)
        settings->guiScale = (settings->guiScale + increment) & 3;
    else if (option == CLONEMC_OPTION_VIEW_BOBBING) settings->viewBobbing = !settings->viewBobbing;
    else if (option == CLONEMC_OPTION_ADVANCED_OPENGL) settings->advancedOpenGL = !settings->advancedOpenGL;
    else if (option == CLONEMC_OPTION_ANAGLYPH) settings->anaglyph = !settings->anaglyph;
    else if (option == CLONEMC_OPTION_FRAMERATE_LIMIT){
        if(settings->limitFramerate==0)
            settings->limitFramerate=increment<0?CLONEMC_FRAMERATE_MAX:
                CLONEMC_FRAMERATE_MIN;
        else{
            settings->limitFramerate+=increment*5;
            if(settings->limitFramerate>CLONEMC_FRAMERATE_MAX)
                settings->limitFramerate=0;
            else if(settings->limitFramerate<CLONEMC_FRAMERATE_MIN)
                settings->limitFramerate=0;
        }
    }
    else if (option == CLONEMC_OPTION_DIFFICULTY)
        settings->difficulty = (settings->difficulty + increment) & 3;
    else if (option == CLONEMC_OPTION_GRAPHICS) settings->fancyGraphics = !settings->fancyGraphics;
    else if (option == CLONEMC_OPTION_AMBIENT_OCCLUSION)
        settings->ambientOcclusion = !settings->ambientOcclusion;
    else return 0;
    CloneMCGameSettings_SynchronizeDerived(settings);
    return 1;
}

static const char *CloneMCGameSettings_Translate(const char *key,const char *fallback)
{
    const char *translated;
    translated = CloneMCJ_StringTranslate_TranslateKeyNative(key);
    if (!translated || translated == key || !strcmp(translated, key)) return fallback;
    return translated;
}

void CloneMCGameSettings_FormatOption(const CloneMCGameSettings *settings,
    int option,char *output,unsigned long capacity)
{
    const CloneMCJ_EnumOptionDefinition *definition;
    const char *name;
    const char *value;
    int percentage;
    char suffix[32];

    static const char *difficultyKeys[4] = {"options.difficulty.peaceful",
        "options.difficulty.easy","options.difficulty.normal","options.difficulty.hard"};
    static const char *difficultyFallback[4] = {"Peaceful","Easy","Normal","Hard"};
    static const char *scaleKeys[4] = {"options.guiScale.auto","options.guiScale.small",
        "options.guiScale.normal","options.guiScale.large"};
    static const char *scaleFallback[4] = {"Auto","Small","Normal","Large"};
    if (!output || capacity == 0) return;
    output[0] = '\0';
    if (!settings) return;
    definition = CloneMCJ_EnumOptions_GetNative(option);
    if (!definition) return;
    name = CloneMCGameSettings_Translate(definition->translationKey,
        definition->translationKey);
    if (option == CLONEMC_OPTION_RENDER_DISTANCE) {
        sprintf(suffix,": %d chunks",settings->renderDistanceChunks);
        CloneMCSettings_Copy(output,capacity,name);
        CloneMCSettings_Append(output,capacity,suffix);
        return;
    }
    if(option==CLONEMC_OPTION_FRAMERATE_LIMIT){
        if(settings->limitFramerate==0)
            value=CloneMCGameSettings_Translate("performance.max","Max");
        else{
            sprintf(suffix,": %d FPS",settings->limitFramerate);
            CloneMCSettings_Copy(output,capacity,name);
            CloneMCSettings_Append(output,capacity,suffix);
            return;
        }
        CloneMCSettings_Copy(output,capacity,name);
        CloneMCSettings_Append(output,capacity,": ");
        CloneMCSettings_Append(output,capacity,value);
        return;
    }
    if (definition->isFloat) {
        float setting;
        setting = CloneMCGameSettings_GetOptionFloat(settings, option);
        if (option == CLONEMC_OPTION_SENSITIVITY) {
            if (setting == 0.0F) value = CloneMCGameSettings_Translate(
                "options.sensitivity.min", "*yawn*");
            else if (setting == 1.0F) value = CloneMCGameSettings_Translate(
                "options.sensitivity.max", "HYPERSPEED!!!");
            else {
                percentage = (int)(setting * 200.0F);
                sprintf(suffix,": %d%%",percentage);
                CloneMCSettings_Copy(output,capacity,name);
                CloneMCSettings_Append(output,capacity,suffix);
                return;
            }
        } else if (setting == 0.0F) value = CloneMCGameSettings_Translate(
            "options.off", "OFF");
        else {
            percentage = (int)(setting * 100.0F);
            sprintf(suffix,": %d%%",percentage);
            CloneMCSettings_Copy(output,capacity,name);
            CloneMCSettings_Append(output,capacity,suffix);
            return;
        }
    } else if (definition->isBoolean) {
        int enabled;
        enabled = option == CLONEMC_OPTION_INVERT_MOUSE ? settings->invertMouse :
            option == CLONEMC_OPTION_VIEW_BOBBING ? settings->viewBobbing :
            option == CLONEMC_OPTION_ANAGLYPH ? settings->anaglyph :
            option == CLONEMC_OPTION_ADVANCED_OPENGL ? settings->advancedOpenGL :
            settings->ambientOcclusion;
        value = enabled ? CloneMCGameSettings_Translate("options.on", "ON") :
            CloneMCGameSettings_Translate("options.off", "OFF");
    }
    else if (option == CLONEMC_OPTION_DIFFICULTY)
        value = CloneMCGameSettings_Translate(difficultyKeys[settings->difficulty],
            difficultyFallback[settings->difficulty]);
    else if (option == CLONEMC_OPTION_GUI_SCALE)
        value = CloneMCGameSettings_Translate(scaleKeys[settings->guiScale],
            scaleFallback[settings->guiScale]);
    else if (option == CLONEMC_OPTION_GRAPHICS)
        value = settings->fancyGraphics ? CloneMCGameSettings_Translate(
            "options.graphics.fancy", "Fancy") : CloneMCGameSettings_Translate(
            "options.graphics.fast", "Fast");
    else value = "";
    if (strlen(name) + strlen(value) + 3 >= capacity) {
        CloneMCSettings_Copy(output, capacity, name);
        return;
    }
    strcpy(output, name);
    strcat(output, ": ");
    strcat(output, value);
}

const char *CloneMCGameSettings_GetKeyDescription(int index)
{
    static const char *keys[CLONEMC_GAME_KEY_BINDING_COUNT] = {
        "key.forward","key.left","key.back","key.right","key.jump",
        "key.sneak","key.drop","key.inventory","key.chat","key.fog"
    };
    if (index < 0 || index >= CLONEMC_GAME_KEY_BINDING_COUNT) return "";
    return CloneMCJ_StringTranslate_TranslateKeyNative(keys[index]);
}

void CloneMCGameSettings_FormatKeyName(int keyCode,char *output,
    unsigned long capacity)
{
    const char *name;
    char single[2];
    if (!output || capacity == 0) return;
    name = 0;
    if (keyCode == 8) name = "BACKSPACE";
    else if (keyCode == 9) name = "TAB";
    else if (keyCode == 13) name = "RETURN";
    else if (keyCode == 16) name = "LSHIFT";
    else if (keyCode == 17) name = "LCTRL";
    else if (keyCode == 18) name = "LALT";
    else if (keyCode == 27) name = "ESCAPE";
    else if (keyCode == 32) name = "SPACE";
    else if (keyCode == 37) name = "LEFT";
    else if (keyCode == 38) name = "UP";
    else if (keyCode == 39) name = "RIGHT";
    else if (keyCode == 40) name = "DOWN";
    if (name) CloneMCSettings_Copy(output, capacity, name);
    else if (keyCode >= 33 && keyCode <= 126) {
        single[0] = (char)keyCode;
        single[1] = '\0';
        CloneMCSettings_Copy(output, capacity, single);
    } else {
        char numeric[32];
        sprintf(numeric,"KEY%d",keyCode);
        CloneMCSettings_Copy(output,capacity,numeric);
    }
}

int CloneMCGameSettings_SetKeyBinding(CloneMCGameSettings *settings,int index,
    int keyCode)
{
    if (!settings || index < 0 || index >= CLONEMC_GAME_KEY_BINDING_COUNT ||
        keyCode < 0 || keyCode > 255) return 0;
    settings->keyCodes[index] = keyCode;
    return 1;
}
