/*
 * CloneMC fixed-capacity post-Beta progression extension.
 *
 * This module deliberately keeps the later mechanics separate from the Beta
 * simulation.  It uses release-era numeric IDs and behavior, but stores at
 * most three enchantments and four active effects per object.  There are no
 * per-tick allocations, hash tables, or unbounded lists.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <math.h>
#include <string.h>

static int CloneMCJ_Progression_XPThreshold(int level)
{
    if(level<0)level=0;
    /* EntityPlayer.xpBarCap in the uploaded 1.2.3 source.  The piecewise
     * formula previously used here belongs to substantially later releases. */
    return 7+((level*7)>>1);
}

void CloneMCJ_Progression_AddExperience(CloneMCJ_EntityPlayer *player, int amount)
{
    int threshold;
    float points;
    if (!player || amount <= 0) return;
    if (player->experienceTotal <= 0x7FFFFFFF - amount)
        player->experienceTotal += amount;
    else
        player->experienceTotal = 0x7FFFFFFF;
    points = player->experienceProgress *
        (float)CloneMCJ_Progression_XPThreshold(player->experienceLevel);
    points += (float)amount;
    threshold = CloneMCJ_Progression_XPThreshold(player->experienceLevel);
    while (points >= (float)threshold && player->experienceLevel < 21863) {
        points -= (float)threshold;
        ++player->experienceLevel;
        threshold = CloneMCJ_Progression_XPThreshold(player->experienceLevel);
    }
    player->experienceProgress = threshold > 0 ?
        points / (float)threshold : 0.0F;
}

static int CloneMCJ_Progression_XPSplit(int amount)
{
    if (amount >= 2477) return 2477;
    if (amount >= 1237) return 1237;
    if (amount >= 617) return 617;
    if (amount >= 307) return 307;
    if (amount >= 149) return 149;
    if (amount >= 73) return 73;
    if (amount >= 37) return 37;
    if (amount >= 17) return 17;
    if (amount >= 7) return 7;
    if (amount >= 3) return 3;
    return 1;
}

void CloneMCJ_Progression_SpawnExperience(CloneMCJ_GameplayState *state,
    double x,double y,double z,int amount)
{
    int i;
    int value;
    CloneMCJ_ExperienceOrb *orb;
    if(!state||!state->world||amount<=0)return;
    while(amount>0){
        value=CloneMCJ_Progression_XPSplit(amount);
        for(i=0;i<CLONEMC_J_MAX_EXPERIENCE_ORBS;++i)
            if(!state->experienceOrbs[i].active)break;
        if(i>=CLONEMC_J_MAX_EXPERIENCE_ORBS){
            /*
             * Coalesce instead of dropping XP or allocating.  The first live
             * orb remains collectable and preserves the total reward.
             */
            orb=&state->experienceOrbs[0];
            if(orb->active&&orb->value<=0x7FFFFFFF-amount)
                orb->value+=amount;
            else
                CloneMCJ_Progression_AddExperience(&state->player,amount);
            return;
        }
        orb=&state->experienceOrbs[i];
        memset(orb,0,sizeof(*orb));
        CloneMCJ_Entity_Initialize(&orb->entity,state->world);
        CloneMCJ_Entity_SetSize(&orb->entity,0.5F,0.5F);
        CloneMCJ_Entity_SetPosition(&orb->entity,x,y,z);
        orb->entity.entityId=state->nextEntityId++;
        orb->entity.motionX=(CloneMCJavaRandom_NextFloat(
            &state->player.entity.rand)-0.5F)*0.2F;
        orb->entity.motionY=0.2F;
        orb->entity.motionZ=(CloneMCJavaRandom_NextFloat(
            &state->player.entity.rand)-0.5F)*0.2F;
        orb->value=value;
        orb->pickupDelay=2;
        orb->active=1;
        if(i>=state->experienceOrbCount)state->experienceOrbCount=i+1;
        amount-=value;
    }
}

void CloneMCJ_Progression_TickExperienceOrbs(CloneMCJ_GameplayState *state)
{
    int i;
    int chunkX;
    int chunkZ;
    double dx,dy,dz,distance,attraction;
    float groundFriction;
    int blockId;
    const CloneMCJ_BlockDefinition *block;
    CloneMCJ_ExperienceOrb *orb;
    if(!state||!state->world)return;
    for(i=0;i<state->experienceOrbCount;++i){
        orb=&state->experienceOrbs[i];
        if(!orb->active)continue;
        chunkX=CloneMCJ_World_GlobalToChunk(
            CloneMCJava_FloorDouble(orb->entity.posX));
        chunkZ=CloneMCJ_World_GlobalToChunk(
            CloneMCJava_FloorDouble(orb->entity.posZ));
        /*
         * Match the dropped-item chunk-safety contract: unloaded chunks freeze
         * the orb and its despawn clock, so neither gravity nor age can make it
         * disappear through an absent collision map.
         */
        if(!CloneMCJ_World_IsChunkLoaded(state->world,chunkX,chunkZ))continue;
        orb->entity.prevPosX=orb->entity.posX;
        orb->entity.prevPosY=orb->entity.posY;
        orb->entity.prevPosZ=orb->entity.posZ;
        if(orb->pickupDelay>0)--orb->pickupDelay;
        orb->entity.motionY-=0.03;
        blockId=CloneMCJ_World_GetLoadedBlockId(state->world,
            CloneMCJava_FloorDouble(orb->entity.posX),
            CloneMCJava_FloorDouble(orb->entity.posY),
            CloneMCJava_FloorDouble(orb->entity.posZ));
        if(blockId==10||blockId==11){
            orb->entity.motionY=0.2;
            orb->entity.motionX=(CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand)-CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand))*0.2F;
            orb->entity.motionZ=(CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand)-CloneMCJavaRandom_NextFloat(
                &state->player.entity.rand))*0.2F;
        }
        dx=state->player.entity.posX-orb->entity.posX;
        dy=state->player.entity.posY+state->player.entity.height*0.5-
            orb->entity.posY;
        dz=state->player.entity.posZ-orb->entity.posZ;
        distance=sqrt(dx*dx+dy*dy+dz*dz);
        if(distance>0.001&&distance<8.0){
            attraction=1.0-distance/8.0;
            attraction=attraction*attraction*0.1;
            orb->entity.motionX+=dx/distance*attraction;
            orb->entity.motionY+=dy/distance*attraction;
            orb->entity.motionZ+=dz/distance*attraction;
        }
        CloneMCJ_Entity_Move(&orb->entity,orb->entity.motionX,
            orb->entity.motionY,orb->entity.motionZ);
        groundFriction=0.98F;
        if(orb->entity.onGround){
            groundFriction=0.5880001F;
            blockId=CloneMCJ_World_GetLoadedBlockId(state->world,
                CloneMCJava_FloorDouble(orb->entity.posX),
                CloneMCJava_FloorDouble(orb->entity.boundingBox.minY)-1,
                CloneMCJava_FloorDouble(orb->entity.posZ));
            block=CloneMCJ_BlockRegistry_Get(blockId);
            if(blockId>0&&block)groundFriction=block->slipperiness*0.98F;
        }
        orb->entity.motionX*=groundFriction;
        orb->entity.motionY*=0.98;
        orb->entity.motionZ*=groundFriction;
        if(orb->entity.onGround){
            orb->entity.motionY*=-0.9;
        }
        ++orb->age;
        dx=state->player.entity.posX-orb->entity.posX;
        dy=state->player.entity.posY+0.5-orb->entity.posY;
        dz=state->player.entity.posZ-orb->entity.posZ;
        if(orb->pickupDelay<=0&&dx*dx+dy*dy+dz*dz<2.25){
            CloneMCJ_Progression_AddExperience(&state->player,orb->value);
            orb->active=0;
        }else if(orb->age>=6000||orb->entity.posY<-64.0)
            orb->active=0;
    }
    while(state->experienceOrbCount>0&&
          !state->experienceOrbs[state->experienceOrbCount-1].active)
        --state->experienceOrbCount;
}

int CloneMCJ_Progression_HasEffect(const CloneMCJ_EntityPlayer *player,
    int effectId, int *amplifier)
{
    int i;
    if (amplifier) *amplifier = 0;
    if (!player) return 0;
    for (i = 0; i < 4; ++i)
        if (player->activeEffectDuration[i] > 0 &&
            player->activeEffectId[i] == effectId) {
            if (amplifier) *amplifier = player->activeEffectAmplifier[i];
            return 1;
        }
    return 0;
}

static void CloneMCJ_Progression_AddEffect(CloneMCJ_EntityPlayer *player,
    int effectId, int duration, int amplifier)
{
    int i;
    int replacement;
    if (!player || duration <= 0) return;
    replacement = 0;
    for (i = 0; i < 4; ++i) {
        if (player->activeEffectDuration[i] <= 0 ||
            player->activeEffectId[i] == effectId) {
            replacement = i;
            break;
        }
        if (player->activeEffectDuration[i] <
            player->activeEffectDuration[replacement]) replacement = i;
    }
    if (player->activeEffectId[replacement] == effectId &&
        player->activeEffectAmplifier[replacement] > amplifier &&
        player->activeEffectDuration[replacement] >= duration) return;
    player->activeEffectId[replacement] = (unsigned char)effectId;
    player->activeEffectAmplifier[replacement] = (unsigned char)amplifier;
    player->activeEffectDuration[replacement] = duration;
}

void CloneMCJ_Progression_ApplySplashPotion(CloneMCJ_GameplayState *state,
    double x,double y,double z,int damage)
{
    CloneMCJ_Mob *mob;
    double dx,dy,dz,distanceSquared,factor;
    int type,amplifier,duration,amount,index;
    if(!state)return;
    type=damage&CLONEMC_J_POTION_TYPE_MASK;
    amplifier=(damage&CLONEMC_J_POTION_STRONG)?1:0;
    dx=state->player.entity.posX-x;
    dy=state->player.entity.posY+0.9-y;
    dz=state->player.entity.posZ-z;
    distanceSquared=dx*dx+dy*dy+dz*dz;
    if(distanceSquared<16.0&&state->player.health>0){
        factor=1.0-sqrt(distanceSquared)/4.0;
        if(factor<0.0)factor=0.0;
        duration=(damage&CLONEMC_J_POTION_EXTENDED)?9600:3600;
        if(type==CLONEMC_J_POTION_SPEED){
            duration=(int)((double)duration*factor+0.5);
            if(duration>20)CloneMCJ_Progression_AddEffect(&state->player,
                CLONEMC_J_EFFECT_SPEED,duration,amplifier);
        }else if(type==CLONEMC_J_POTION_REGENERATION){
            duration=(damage&CLONEMC_J_POTION_EXTENDED)?1800:900;
            duration=(int)((double)duration*factor+0.5);
            if(duration>20)CloneMCJ_Progression_AddEffect(&state->player,
                CLONEMC_J_EFFECT_REGENERATION,duration,amplifier);
        }else if(type==CLONEMC_J_POTION_FIRE_RESISTANCE){
            duration=(int)((double)duration*factor+0.5);
            if(duration>20)CloneMCJ_Progression_AddEffect(&state->player,
                CLONEMC_J_EFFECT_FIRE_RESISTANCE,duration,0);
        }else if(type==CLONEMC_J_POTION_HEALING){
            amount=(int)((double)(amplifier?8:4)*factor+0.5);
            state->player.health+=amount;
            if(state->player.health>20)state->player.health=20;
        }else if(type==CLONEMC_J_POTION_HARMING){
            amount=(int)((double)(amplifier?12:6)*factor+0.5);
            if(amount>0)CloneMCJ_EntityPlayer_AttackFrom(&state->player,
                (const CloneMCJ_Entity *)0,amount);
        }
    }
    /* This fixed-capacity runtime does not store arbitrary status-effect maps
     * on mobs.  Instant splash effects still match EntityPotion's four-block
     * radial falloff; timed player effects use the existing bounded slots. */
    if(type!=CLONEMC_J_POTION_HEALING&&type!=CLONEMC_J_POTION_HARMING)return;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index){
        mob=&state->mobs[index];
        if(!mob->active||mob->health<=0)continue;
        dx=mob->entity.posX-x;
        dy=mob->entity.posY+(double)mob->entity.height*0.5-y;
        dz=mob->entity.posZ-z;
        distanceSquared=dx*dx+dy*dy+dz*dz;
        if(distanceSquared>=16.0)continue;
        factor=1.0-sqrt(distanceSquared)/4.0;
        amount=(int)((double)(type==CLONEMC_J_POTION_HEALING?
            (amplifier?8:4):(amplifier?12:6))*factor+0.5);
        if(amount<=0)continue;
        if(type==CLONEMC_J_POTION_HEALING){
            mob->health+=amount;if(mob->health>mob->maxHealth)
                mob->health=mob->maxHealth;
        }else CloneMCJ_EntityLiving_AttackMobFrom(mob,
            (const CloneMCJ_Entity *)0,amount);
    }
}

void CloneMCJ_Progression_TickPlayerEffects(CloneMCJ_EntityPlayer *player)
{
    int i;
    int amplifier;
    int interval;
    if (!player) return;
    for (i = 0; i < 4; ++i) {
        if (player->activeEffectDuration[i] <= 0) continue;
        amplifier = player->activeEffectAmplifier[i];
        if (player->activeEffectId[i] == CLONEMC_J_EFFECT_REGENERATION &&
            player->health > 0 && player->health < 20) {
            interval = 50 >> amplifier;
            if (interval < 1) interval = 1;
            if ((player->activeEffectDuration[i] % interval) == 0)
                ++player->health;
        }
        --player->activeEffectDuration[i];
        if (player->activeEffectDuration[i] <= 0) {
            player->activeEffectId[i] = 0;
            player->activeEffectAmplifier[i] = 0;
        }
    }
}

int CloneMCJ_Progression_EnchantLevel(const CloneMCJ_ItemStack *stack,
    int enchantmentId)
{
    int i;
    if (!stack || CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    for (i = 0; i < (int)stack->enchantmentCount && i < 3; ++i)
        if (stack->enchantmentId[i] == enchantmentId)
            return stack->enchantmentLevel[i];
    return 0;
}

int CloneMCJ_Progression_AttackPlayerProtected(
    CloneMCJ_EntityPlayer *player,const CloneMCJ_Entity *source,int damage,
    int protectionEnchantment)
{
    int i;
    int protection;
    if(!player||damage<=0)return 0;
    protection=0;
    for(i=0;i<CLONEMC_J_ARMOR_INVENTORY_SIZE;++i)
        protection+=CloneMCJ_Progression_EnchantLevel(
            &player->inventory.armorInventory[i],protectionEnchantment)*2;
    if(protection>20)protection=20;
    damage=damage*(25-protection)/25;
    if(damage<1)damage=1;
    return CloneMCJ_EntityPlayer_AttackFrom(player,source,damage);
}

static int CloneMCJ_Progression_CountBookshelves(CloneMCJ_World *world,
    int x, int y, int z)
{
    int dx;
    int dz;
    int count;
    if (!world) return 0;
    count = 0;
    for (dx = -1; dx <= 1 && count < 30; ++dx)
        for (dz = -1; dz <= 1 && count < 30; ++dz) {
            if (dx == 0 && dz == 0) continue;
            if (CloneMCJ_World_GetBlockId(world, x + dx, y, z + dz) != 0 ||
                CloneMCJ_World_GetBlockId(world, x + dx, y + 1, z + dz) != 0)
                continue;
            if (CloneMCJ_World_GetBlockId(world, x + dx * 2, y,
                z + dz * 2) == 47) ++count;
            if (count < 30 && CloneMCJ_World_GetBlockId(world, x + dx * 2,
                y + 1, z + dz * 2) == 47) ++count;
            if (dx != 0 && dz != 0) {
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx * 2, y, z + dz) == 47) ++count;
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx * 2, y + 1, z + dz) == 47) ++count;
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx, y, z + dz * 2) == 47) ++count;
                if (count < 30 && CloneMCJ_World_GetBlockId(world,
                    x + dx, y + 1, z + dz * 2) == 47) ++count;
            }
        }
    return count;
}

static void CloneMCJ_Progression_RebuildOffers(CloneMCJ_GameplayState *state)
{
    CloneMCJavaRandom random;
    CloneMCJLong seed;
    int power;
    int base;
    int shelves;
    int offer;
    if (!state) return;
    shelves = state->enchantmentBookshelves;
    if(shelves>30)shelves=30;
    seed=(CloneMCJLong)state->enchantmentSeed^
        state->world->worldInfo.randomSeed^(CloneMCJLong)state->ticksRun;
    CloneMCJavaRandom_SetSeed(&random,seed);
    /* EnchantmentHelper.calcItemStackEnchantability, Minecraft 1.2.3. */
    for(offer=0;offer<3;++offer){
        power=1+(shelves>>1)+
            (int)CloneMCJavaRandom_NextIntBound(&random,shelves+1);
        base=(int)CloneMCJavaRandom_NextIntBound(&random,5)+power;
        if(offer==0){
            state->enchantmentOffers[offer]=(base>>1)+1;
        }else if(offer==1)
            state->enchantmentOffers[offer]=base*2/3+1;
        else state->enchantmentOffers[offer]=base;
    }
    ++state->enchantmentSeed;
}

void CloneMCJ_Progression_RefreshEnchantOffers(
    CloneMCJ_GameplayState *state)
{
    CloneMCJ_ItemStack *stack;
    const CloneMCJ_ItemDefinition *item;
    int enchantable;
    if(!state||state->openContainer.type!=
       CLONEMC_J_CONTAINER_ENCHANTMENT)return;
    stack=&state->openContainerTile.items[0];
    enchantable=0;
    if(!CloneMCJ_ItemStack_IsEmpty(stack)&&stack->enchantmentCount==0){
        item=CloneMCJ_ItemRegistry_Get(stack->itemID);
        enchantable=stack->itemID==340||
            (stack->itemID>=298&&stack->itemID<=317)||
            (item&&item->toolClass!=CLONEMC_J_TOOL_NONE);
    }
    if(!enchantable){
        state->enchantmentOffers[0]=0;
        state->enchantmentOffers[1]=0;
        state->enchantmentOffers[2]=0;
        return;
    }
    CloneMCJ_Progression_RebuildOffers(state);
}

static void CloneMCJ_Progression_AddPlayerSlots(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, int inventoryY, int hotbarY)
{
    int row;
    int column;
    int index;
    container->playerSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 9; ++column) {
            index = column + (row + 1) * 9;
            CloneMCJ_Container_AddTypedSlot(container,
                &inventory->mainInventory[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 8 + column * 18, inventoryY + row * 18);
        }
    container->hotbarSlotStart = container->slotCount;
    for (column = 0; column < 9; ++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column], 64, CLONEMC_J_SLOT_NORMAL,
            -1, column, 8 + column * 18, hotbarY);
    container->hotbarSlotEnd = container->slotCount - 1;
    container->playerSlotEnd = container->hotbarSlotEnd;
}

int CloneMCJ_Progression_OpenBlock(CloneMCJ_GameplayState *state, int blockId,
    int x, int y, int z)
{
    int i;
    if (!state || !state->world || blockId != 116) return 0;
    CloneMCJ_Container_Initialize(&state->openContainer);
    memset(&state->openContainerTile, 0, sizeof(state->openContainerTile));
    state->openContainerTile.type = CLONEMC_J_TILE_NONE;
    state->openContainerTile.itemCount = 1;
    for (i = 0; i < CLONEMC_J_CHEST_INVENTORY_SIZE; ++i)
        CloneMCJ_ItemStack_Clear(&state->openContainerTile.items[i]);
    state->openContainer.type = CLONEMC_J_CONTAINER_ENCHANTMENT;
    state->openContainer.playerInventory = &state->player.inventory;
    state->openContainer.tileEntity = &state->openContainerTile;
    state->openContainer.tileSlotStart = state->openContainer.slotCount;
    CloneMCJ_Container_AddTypedSlot(&state->openContainer,
        &state->openContainerTile.items[0], 1, CLONEMC_J_SLOT_ENCHANT_INPUT,
        -1, 0, 15, 47);
    state->openContainer.tileSlotEnd = state->openContainer.slotCount - 1;
    CloneMCJ_Progression_AddPlayerSlots(&state->openContainer,
        &state->player.inventory, 84, 142);
    state->enchantmentBookshelves =
        CloneMCJ_Progression_CountBookshelves(state->world, x, y, z);
    CloneMCJ_Progression_RefreshEnchantOffers(state);
    return 1;
}

static int CloneMCJ_Progression_IsArmor(int itemId)
{
    return itemId >= 298 && itemId <= 317;
}

typedef struct CloneMCJ_ProgressionEnchantCandidateTag {
    int id;
    int level;
    int weight;
    unsigned char available;
} CloneMCJ_ProgressionEnchantCandidate;

static int CloneMCJ_Progression_ItemEnchantability(int itemId)
{
    if(itemId>=298&&itemId<=301)return 15;
    if(itemId>=302&&itemId<=305)return 12;
    if(itemId>=306&&itemId<=309)return 9;
    if(itemId>=310&&itemId<=313)return 10;
    if(itemId>=314&&itemId<=317)return 25;
    if(itemId==268||itemId==269||itemId==270||itemId==271||itemId==290)
        return 15;
    if((itemId>=272&&itemId<=275)||itemId==291)return 5;
    if(itemId==256||itemId==257||itemId==258||itemId==267||itemId==292)
        return 14;
    if((itemId>=276&&itemId<=279)||itemId==293)return 10;
    if((itemId>=283&&itemId<=286)||itemId==294)return 22;
    if(itemId==340)return 1;
    return 0;
}

static int CloneMCJ_Progression_MaxEnchantLevel(int enchantmentId)
{
    if (enchantmentId == CLONEMC_J_ENCHANT_KNOCKBACK) return 2;
    if (enchantmentId == CLONEMC_J_ENCHANT_UNBREAKING) return 3;
    if(enchantmentId==CLONEMC_J_ENCHANT_SHARPNESS||
       enchantmentId==CLONEMC_J_ENCHANT_EFFICIENCY)return 5;
    return 4;
}

static int CloneMCJ_Progression_EnchantWeight(int enchantmentId)
{
    if(enchantmentId==CLONEMC_J_ENCHANT_PROTECTION||
       enchantmentId==CLONEMC_J_ENCHANT_SHARPNESS||
       enchantmentId==CLONEMC_J_ENCHANT_EFFICIENCY)return 10;
    if(enchantmentId==CLONEMC_J_ENCHANT_BLAST_PROTECTION)return 2;
    return 5;
}

static int CloneMCJ_Progression_EnchantMin(int enchantmentId,int level)
{
    if(enchantmentId==CLONEMC_J_ENCHANT_PROTECTION)
        return 1+(level-1)*16;
    if(enchantmentId==CLONEMC_J_ENCHANT_FIRE_PROTECTION)
        return 10+(level-1)*8;
    if(enchantmentId==CLONEMC_J_ENCHANT_BLAST_PROTECTION)
        return 5+(level-1)*8;
    if(enchantmentId==CLONEMC_J_ENCHANT_SHARPNESS)
        return 1+(level-1)*16;
    if(enchantmentId==CLONEMC_J_ENCHANT_KNOCKBACK)
        return 5+(level-1)*20;
    if(enchantmentId==CLONEMC_J_ENCHANT_EFFICIENCY)
        return 1+(level-1)*15;
    return 5+(level-1)*10;
}

static int CloneMCJ_Progression_EnchantMax(int enchantmentId,int level)
{
    int minimum;
    minimum=CloneMCJ_Progression_EnchantMin(enchantmentId,level);
    if(enchantmentId==CLONEMC_J_ENCHANT_PROTECTION||
       enchantmentId==CLONEMC_J_ENCHANT_SHARPNESS)return minimum+20;
    if(enchantmentId==CLONEMC_J_ENCHANT_FIRE_PROTECTION||
       enchantmentId==CLONEMC_J_ENCHANT_BLAST_PROTECTION)return minimum+12;
    /* Digging/knockback/durability call Enchantment's base min method when
     * computing max in the uploaded 1.2.3 classes. */
    return 51+level*10;
}

static int CloneMCJ_Progression_EnchantApplies(
    const CloneMCJ_ItemStack *stack,int enchantmentId)
{
    const CloneMCJ_ItemDefinition *item;
    if(!stack)return 0;
    if(stack->itemID==340)return 1;
    item=CloneMCJ_ItemRegistry_Get(stack->itemID);
    if(enchantmentId==CLONEMC_J_ENCHANT_PROTECTION||
       enchantmentId==CLONEMC_J_ENCHANT_FIRE_PROTECTION||
       enchantmentId==CLONEMC_J_ENCHANT_BLAST_PROTECTION)
        return CloneMCJ_Progression_IsArmor(stack->itemID);
    if(enchantmentId==CLONEMC_J_ENCHANT_SHARPNESS||
       enchantmentId==CLONEMC_J_ENCHANT_KNOCKBACK)
        return item&&item->toolClass==CLONEMC_J_TOOL_SWORD;
    if(enchantmentId==CLONEMC_J_ENCHANT_EFFICIENCY)
        return item&&(item->toolClass==CLONEMC_J_TOOL_PICKAXE||
            item->toolClass==CLONEMC_J_TOOL_AXE||
            item->toolClass==CLONEMC_J_TOOL_SHOVEL);
    return item&&item->maxDamage>0;
}

static int CloneMCJ_Progression_BuildCandidates(const CloneMCJ_ItemStack *stack,
    int power,CloneMCJ_ProgressionEnchantCandidate *candidates)
{
    static const int ids[7]={
        CLONEMC_J_ENCHANT_PROTECTION,CLONEMC_J_ENCHANT_FIRE_PROTECTION,
        CLONEMC_J_ENCHANT_BLAST_PROTECTION,CLONEMC_J_ENCHANT_SHARPNESS,
        CLONEMC_J_ENCHANT_KNOCKBACK,CLONEMC_J_ENCHANT_EFFICIENCY,
        CLONEMC_J_ENCHANT_UNBREAKING};
    int index;
    int level;
    int count;
    count=0;
    for(index=0;index<7;++index){
        if(!CloneMCJ_Progression_EnchantApplies(stack,ids[index]))continue;
        for(level=CloneMCJ_Progression_MaxEnchantLevel(ids[index]);
            level>=1;--level)
            if(power>=CloneMCJ_Progression_EnchantMin(ids[index],level)&&
               power<=CloneMCJ_Progression_EnchantMax(ids[index],level)){
                candidates[count].id=ids[index];
                candidates[count].level=level;
                candidates[count].weight=
                    CloneMCJ_Progression_EnchantWeight(ids[index]);
                candidates[count].available=1;
                ++count;
                break;
            }
    }
    return count;
}

static int CloneMCJ_Progression_WeightedCandidate(CloneMCJavaRandom *random,
    CloneMCJ_ProgressionEnchantCandidate *candidates,int count)
{
    int index;
    int total;
    int choice;
    total=0;
    for(index=0;index<count;++index)
        if(candidates[index].available)total+=candidates[index].weight;
    if(total<=0)return -1;
    choice=(int)CloneMCJavaRandom_NextIntBound(random,total);
    for(index=0;index<count;++index)if(candidates[index].available){
        choice-=candidates[index].weight;
        if(choice<0)return index;
    }
    return -1;
}

static int CloneMCJ_Progression_EnchantsCompatible(int first,int second)
{
    int firstProtection;
    int secondProtection;
    if(first==second)return 0;
    firstProtection=first==CLONEMC_J_ENCHANT_PROTECTION||
        first==CLONEMC_J_ENCHANT_FIRE_PROTECTION||
        first==CLONEMC_J_ENCHANT_BLAST_PROTECTION;
    secondProtection=second==CLONEMC_J_ENCHANT_PROTECTION||
        second==CLONEMC_J_ENCHANT_FIRE_PROTECTION||
        second==CLONEMC_J_ENCHANT_BLAST_PROTECTION;
    return !(firstProtection&&secondProtection);
}

int CloneMCJ_Progression_ClickEnchant(CloneMCJ_GameplayState *state,
    int offerIndex)
{
    CloneMCJ_ItemStack *stack;
    CloneMCJavaRandom random;
    CloneMCJ_ProgressionEnchantCandidate candidates[7];
    CloneMCJLong seed;
    int cost;
    int enchantability;
    int power;
    float variance;
    int candidateCount;
    int selected;
    int count;
    int i;
    int loopPower;
    if (!state || !state->openContainerActive ||
        state->openContainer.type != CLONEMC_J_CONTAINER_ENCHANTMENT ||
        offerIndex < 0 || offerIndex > 2) return 0;
    stack = &state->openContainerTile.items[0];
    if (CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    /*
     * The pre-anvil enchanting table does not replace or reroll an already
     * enchanted stack.  Reject it before touching the fixed enchantment
     * array so a GUI double click can never erase the item's saved NBT.
     */
    if (stack->enchantmentCount > 0) return 0;
    cost = state->enchantmentOffers[offerIndex];
    if (cost <= 0 || (state->player.gameMode == CLONEMC_J_GAMEMODE_SURVIVAL &&
        state->player.experienceLevel < cost)) return 0;
    enchantability=CloneMCJ_Progression_ItemEnchantability(stack->itemID);
    if(enchantability<=0)return 0;
    seed=(CloneMCJLong)state->enchantmentSeed^
        ((CloneMCJLong)stack->itemID<<16)^
        ((CloneMCJLong)cost<<32)^state->world->worldInfo.randomSeed;
    CloneMCJavaRandom_SetSeed(&random,seed);
    power=1+(int)CloneMCJavaRandom_NextIntBound(&random,
        (enchantability>>1)+1)+(int)CloneMCJavaRandom_NextIntBound(&random,
        (enchantability>>1)+1)+cost;
    variance=(CloneMCJavaRandom_NextFloat(&random)+
        CloneMCJavaRandom_NextFloat(&random)-1.0F)*0.25F;
    power=(int)((float)power*(1.0F+variance)+0.5F);
    candidateCount=CloneMCJ_Progression_BuildCandidates(stack,power,candidates);
    selected=CloneMCJ_Progression_WeightedCandidate(&random,candidates,
        candidateCount);
    if(selected<0)return 0;
    stack->enchantmentCount = 0;
    stack->enchantmentId[0]=(unsigned char)candidates[selected].id;
    stack->enchantmentLevel[0]=(unsigned char)candidates[selected].level;
    stack->enchantmentCount=1;
    count=1;
    for(loopPower=power>>1;
        count<3&&CloneMCJavaRandom_NextIntBound(&random,50)<=loopPower;
        loopPower>>=1){
        for(i=0;i<candidateCount;++i)
            if(candidates[i].available&&
               !CloneMCJ_Progression_EnchantsCompatible(
                    candidates[selected].id,candidates[i].id))
                candidates[i].available=0;
        selected=CloneMCJ_Progression_WeightedCandidate(&random,candidates,
            candidateCount);
        if(selected<0)break;
        stack->enchantmentId[count]=(unsigned char)candidates[selected].id;
        stack->enchantmentLevel[count]=(unsigned char)candidates[selected].level;
        ++count;stack->enchantmentCount=(unsigned char)count;
    }
    if (stack->enchantmentCount == 0) return 0;
    if (state->player.gameMode == CLONEMC_J_GAMEMODE_SURVIVAL) {
        state->player.experienceLevel -= cost;
        if (state->player.experienceLevel < 0) state->player.experienceLevel = 0;
        /* Java spends levels but retains partial-level progress.  XpTotal is
         * the cumulative statistic and is not the enchantment wallet. */
    }
    state->player.inventory.inventoryChanged = 1;
    CloneMCJ_Progression_RefreshEnchantOffers(state);
    return 1;
}

void CloneMCJ_Progression_InitializeBrewingContainer(
    CloneMCJ_Container *container, CloneMCJ_InventoryPlayer *inventory,
    CloneMCJ_TileEntity *tile)
{
    int i;
    if (!container || !inventory || !tile ||
        tile->type != CLONEMC_J_TILE_BREWING_STAND) return;
    CloneMCJ_Container_Initialize(container);
    container->type = CLONEMC_J_CONTAINER_BREWING;
    container->playerInventory = inventory;
    container->tileEntity = tile;
    container->tileSlotStart = container->slotCount;
    for (i = 0; i < 3; ++i)
        CloneMCJ_Container_AddTypedSlot(container, &tile->items[i], 1,
            CLONEMC_J_SLOT_BREWING_BOTTLE, -1, i,
            i == 0 ? 56 : (i == 1 ? 79 : 102), 51);
    CloneMCJ_Container_AddTypedSlot(container, &tile->items[3], 64,
        CLONEMC_J_SLOT_BREWING_INGREDIENT, -1, 3, 79, 17);
    container->tileSlotEnd = container->slotCount - 1;
    CloneMCJ_Progression_AddPlayerSlots(container, inventory, 84, 142);
}

int CloneMCJ_Progression_IsBrewingIngredient(int itemId)
{
    return itemId == 372 || itemId == 353 || itemId == 370 ||
        itemId == 378 || itemId == 382 || itemId == 376 ||
        itemId == 348 || itemId == 331;
}

int CloneMCJ_Progression_PotionResult(int potionDamage, int ingredientId)
{
    int type;
    int flags;
    type = potionDamage & CLONEMC_J_POTION_TYPE_MASK;
    flags = potionDamage & (CLONEMC_J_POTION_STRONG |
        CLONEMC_J_POTION_EXTENDED);
    if (ingredientId == 372 && type == CLONEMC_J_POTION_WATER)
        return CLONEMC_J_POTION_AWKWARD;
    if (ingredientId == 353 && type == CLONEMC_J_POTION_AWKWARD)
        return CLONEMC_J_POTION_SPEED;
    if (ingredientId == 370 && type == CLONEMC_J_POTION_AWKWARD)
        return CLONEMC_J_POTION_REGENERATION;
    if (ingredientId == 378 && type == CLONEMC_J_POTION_AWKWARD)
        return CLONEMC_J_POTION_FIRE_RESISTANCE;
    if (ingredientId == 382 && type == CLONEMC_J_POTION_AWKWARD)
        return CLONEMC_J_POTION_HEALING;
    if (ingredientId == 376 && type == CLONEMC_J_POTION_HEALING)
        return CLONEMC_J_POTION_HARMING;
    if (ingredientId == 348 && (type == CLONEMC_J_POTION_SPEED ||
        type == CLONEMC_J_POTION_REGENERATION ||
        type == CLONEMC_J_POTION_HEALING ||
        type == CLONEMC_J_POTION_HARMING) &&
        !(flags & CLONEMC_J_POTION_EXTENDED))
        return type | CLONEMC_J_POTION_STRONG;
    if (ingredientId == 331 && (type == CLONEMC_J_POTION_SPEED ||
        type == CLONEMC_J_POTION_REGENERATION ||
        type == CLONEMC_J_POTION_FIRE_RESISTANCE) &&
        !(flags & CLONEMC_J_POTION_STRONG))
        return type | CLONEMC_J_POTION_EXTENDED;
    return potionDamage;
}

static int CloneMCJ_Progression_CanBrew(const CloneMCJ_TileEntity *tile)
{
    int i;
    int result;
    if (!tile || tile->type != CLONEMC_J_TILE_BREWING_STAND ||
        CloneMCJ_ItemStack_IsEmpty(&tile->items[3]) ||
        !CloneMCJ_Progression_IsBrewingIngredient(tile->items[3].itemID))
        return 0;
    for (i = 0; i < 3; ++i)
        if (!CloneMCJ_ItemStack_IsEmpty(&tile->items[i]) &&
            tile->items[i].itemID == 373) {
            result = CloneMCJ_Progression_PotionResult(
                tile->items[i].itemDamage, tile->items[3].itemID);
            if (result != tile->items[i].itemDamage) return 1;
        }
    return 0;
}

static void CloneMCJ_Progression_MarkTileDirty(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_Chunk *chunk;
    if (!tile || !tile->worldObj) return;
    chunk = CloneMCJ_World_GetLoadedChunkFromChunkCoords(tile->worldObj,
        CloneMCJava_FloorDouble((double)tile->xCoord / 16.0),
        CloneMCJava_FloorDouble((double)tile->zCoord / 16.0));
    if (chunk) chunk->isModified = 1;
}

void CloneMCJ_Progression_TickBrewing(CloneMCJ_TileEntity *tile)
{
    int ingredientId;
    int i;
    if (!tile || tile->type != CLONEMC_J_TILE_BREWING_STAND) return;
    if (tile->brewingTime > 0) {
        --tile->brewingTime;
        if (tile->brewingTime == 0) {
            if (CloneMCJ_Progression_CanBrew(tile) &&
                tile->brewingIngredientId == tile->items[3].itemID) {
                ingredientId = tile->items[3].itemID;
                for (i = 0; i < 3; ++i)
                    if (!CloneMCJ_ItemStack_IsEmpty(&tile->items[i]) &&
                        tile->items[i].itemID == 373)
                        tile->items[i].itemDamage =
                            CloneMCJ_Progression_PotionResult(
                                tile->items[i].itemDamage, ingredientId);
                --tile->items[3].stackSize;
                if (tile->items[3].stackSize <= 0)
                    CloneMCJ_ItemStack_Clear(&tile->items[3]);
                CloneMCJ_Progression_MarkTileDirty(tile);
            }
        } else if (!CloneMCJ_Progression_CanBrew(tile) ||
            tile->brewingIngredientId != tile->items[3].itemID) {
            tile->brewingTime = 0;
        }
    } else if (CloneMCJ_Progression_CanBrew(tile)) {
        tile->brewingTime = 400;
        tile->brewingIngredientId = tile->items[3].itemID;
        CloneMCJ_Progression_MarkTileDirty(tile);
    }
}

static void CloneMCJ_Progression_NetherWartTick(CloneMCJ_World *world,
    int x, int y, int z, int blockId, CloneMCJavaRandom *random,
    void *userData)
{
    int metadata;
    (void)blockId;
    (void)userData;
    if (!world || !random) return;
    if (CloneMCJ_World_GetBlockId(world, x, y - 1, z) != 88) {
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
        return;
    }
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (metadata < 3 && CloneMCJavaRandom_NextIntBound(random, 10) == 0)
        CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, metadata + 1);
}

void CloneMCJ_Progression_RegisterWorldTicks(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    if (!world) return;
    block = CloneMCJ_BlockRegistry_GetMutable(115);
    if (block) block->tickRandomly = 1;
    CloneMCJ_World_RegisterBlockTick(world, 115, 1,
        CloneMCJ_Progression_NetherWartTick, (void *)0);
}

int CloneMCJ_Progression_UsePotion(CloneMCJ_GameplayState *state,
    CloneMCJ_ItemStack *stack)
{
    CloneMCJ_ItemStack bottle;
    int damage;
    int type;
    int amplifier;
    int duration;
    if (!state || !stack || stack->itemID != 373 || stack->stackSize <= 0)
        return 0;
    damage = stack->itemDamage;
    type = damage & CLONEMC_J_POTION_TYPE_MASK;
    amplifier = (damage & CLONEMC_J_POTION_STRONG) ? 1 : 0;
    duration = (damage & CLONEMC_J_POTION_EXTENDED) ? 9600 : 3600;
    if (type == CLONEMC_J_POTION_SPEED)
        CloneMCJ_Progression_AddEffect(&state->player,
            CLONEMC_J_EFFECT_SPEED, duration, amplifier);
    else if (type == CLONEMC_J_POTION_REGENERATION)
        CloneMCJ_Progression_AddEffect(&state->player,
            CLONEMC_J_EFFECT_REGENERATION,
            (damage & CLONEMC_J_POTION_EXTENDED) ? 1800 : 900, amplifier);
    else if (type == CLONEMC_J_POTION_FIRE_RESISTANCE)
        CloneMCJ_Progression_AddEffect(&state->player,
            CLONEMC_J_EFFECT_FIRE_RESISTANCE, duration, 0);
    else if (type == CLONEMC_J_POTION_HEALING) {
        state->player.health += amplifier ? 8 : 4;
        if (state->player.health > 20) state->player.health = 20;
    } else if (type == CLONEMC_J_POTION_HARMING) {
        CloneMCJ_EntityPlayer_AttackFrom(&state->player,
            (const CloneMCJ_Entity *)0, amplifier ? 12 : 6);
    } else return 0;
    --stack->stackSize;
    if (stack->stackSize <= 0) CloneMCJ_ItemStack_Clear(stack);
    CloneMCJ_ItemStack_Initialize(&bottle, 374, 1, 0);
    if (!CloneMCJ_InventoryPlayer_AddItemStack(&state->player.inventory,
        &bottle) && !CloneMCJ_ItemStack_IsEmpty(&bottle))
        CloneMCJ_Gameplay_SpawnDrop(state, state->player.entity.posX,
            state->player.entity.posY + 1.0, state->player.entity.posZ,
            &bottle, 20, 0);
    state->player.inventory.inventoryChanged = 1;
    return 1;
}

static int CloneMCJ_Progression_IsBreedable(const CloneMCJ_Mob *mob)
{
    if (!mob) return 0;
    return mob->type == CLONEMC_J_MOB_PIG ||
        mob->type == CLONEMC_J_MOB_SHEEP ||
        mob->type == CLONEMC_J_MOB_COW ||
        mob->type == CLONEMC_J_MOB_CHICKEN;
}

int CloneMCJ_Progression_InteractBreeding(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *mob)
{
    CloneMCJ_ItemStack *held;
    if (!state || !mob || !mob->active || mob->health <= 0 ||
        !CloneMCJ_Progression_IsBreedable(mob) ||
        mob->growingAge != 0 || mob->inLove > 0) return 0;
    held = CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if (!held || CloneMCJ_ItemStack_IsEmpty(held) || held->itemID != 296)
        return 0;
    if (state->player.gameMode == CLONEMC_J_GAMEMODE_SURVIVAL) {
        --held->stackSize;
        if (held->stackSize <= 0) CloneMCJ_ItemStack_Clear(held);
    }
    mob->inLove = 600;
    mob->breedingTicks = 0;
    mob->persistenceRequired = 1;
    state->player.inventory.inventoryChanged = 1;
    return 1;
}

static int CloneMCJ_Progression_FindFreeMobSlot(CloneMCJ_GameplayState *state)
{
    int i;
    for (i = 0; i < CLONEMC_J_MAX_MOBS; ++i)
        if (!state->mobs[i].active) return i;
    return -1;
}

void CloneMCJ_Progression_TickBreeding(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *mob;
    CloneMCJ_Mob *mate;
    CloneMCJ_Mob *child;
    int i;
    int j;
    int slot;
    double dx;
    double dy;
    double dz;
    double distanceSquared;
    if (!state || !state->world || state->world->multiplayerWorld) return;
    for (i = 0; i < CLONEMC_J_MAX_MOBS; ++i) {
        mob = &state->mobs[i];
        if (!mob->active || !CloneMCJ_Progression_IsBreedable(mob)) continue;
        if (mob->growingAge < 0) ++mob->growingAge;
        else if (mob->growingAge > 0) --mob->growingAge;
        mob->renderScale = mob->growingAge < 0 ? 0.5F : 1.0F;
        if (mob->inLove <= 0 || mob->growingAge != 0) continue;
        --mob->inLove;
        mate = (CloneMCJ_Mob *)0;
        distanceSquared = 64.0;
        for (j = 0; j < CLONEMC_J_MAX_MOBS; ++j) {
            double candidateDistance;
            if (j == i || !state->mobs[j].active ||
                state->mobs[j].type != mob->type ||
                state->mobs[j].health <= 0 ||
                state->mobs[j].growingAge != 0 ||
                state->mobs[j].inLove <= 0) continue;
            dx = state->mobs[j].entity.posX - mob->entity.posX;
            dy = state->mobs[j].entity.posY - mob->entity.posY;
            dz = state->mobs[j].entity.posZ - mob->entity.posZ;
            candidateDistance = dx * dx + dy * dy + dz * dz;
            if (candidateDistance < distanceSquared) {
                distanceSquared = candidateDistance;
                mate = &state->mobs[j];
            }
        }
        if (!mate) {
            mob->breedingTicks = 0;
            continue;
        }
        dx = mate->entity.posX - mob->entity.posX;
        dz = mate->entity.posZ - mob->entity.posZ;
        if (distanceSquared > 2.25) {
            double length;
            length = sqrt(dx * dx + dz * dz);
            if (length > 0.001) {
                mob->entity.motionX += dx / length * 0.02;
                mob->entity.motionZ += dz / length * 0.02;
            }
            mob->breedingTicks = 0;
            continue;
        }
        ++mob->breedingTicks;
        if (mob->breedingTicks < 60 || mate->breedingTicks >= 60) continue;
        slot = CloneMCJ_Progression_FindFreeMobSlot(state);
        if (slot < 0) {
            mob->breedingTicks = 0;
            continue;
        }
        child = &state->mobs[slot];
        CloneMCJ_EntityLiving_InitializeMob(child, mob->type, state->world,
            (mob->entity.posX + mate->entity.posX) * 0.5,
            (mob->entity.posY + mate->entity.posY) * 0.5,
            (mob->entity.posZ + mate->entity.posZ) * 0.5);
        child->growingAge = -24000;
        child->renderScale = 0.5F;
        child->persistenceRequired = 1;
        mob->growingAge = 6000;
        mate->growingAge = 6000;
        mob->inLove = 0;
        mate->inLove = 0;
        mob->breedingTicks = 0;
        mate->breedingTicks = 0;
        if (slot >= state->mobCount) state->mobCount = slot + 1;
        CloneMCJ_Progression_SpawnExperience(state,
            child->entity.posX,child->entity.posY,child->entity.posZ,3);
    }
}

int CloneMCJ_Progression_RunSelfTests(char *message,unsigned int capacity)
{
    CloneMCJ_EntityPlayer player;
    CloneMCJ_TileEntity stand;
    CloneMCJ_ItemStack enchanted;
    CloneMCJ_ItemStack restored;
    CloneMCJ_NBTTagCompound *tag;
    int i;
    int ok;
    ok=1;
    memset(&player,0,sizeof(player));
    CloneMCJ_Progression_AddExperience(&player,7);
    if(player.experienceLevel!=1||player.experienceProgress!=0.0F||
       player.experienceTotal!=7)ok=0;
    if(CloneMCJ_Progression_XPSplit(1)!=1||
       CloneMCJ_Progression_XPSplit(3)!=3||
       CloneMCJ_Progression_XPSplit(17)!=17||
       CloneMCJ_Progression_XPSplit(2477)!=2477||
       CloneMCJ_Progression_XPSplit(3000)!=2477)ok=0;
    if(CloneMCJ_Progression_PotionResult(0,372)!=1||
       CloneMCJ_Progression_PotionResult(1,353)!=2||
       CloneMCJ_Progression_PotionResult(1,370)!=3||
       CloneMCJ_Progression_PotionResult(1,378)!=4||
       CloneMCJ_Progression_PotionResult(1,382)!=5||
       CloneMCJ_Progression_PotionResult(5,376)!=6||
       CloneMCJ_Progression_PotionResult(2,348)!=(2|32)||
       CloneMCJ_Progression_PotionResult(2,331)!=(2|64))ok=0;
    memset(&stand,0,sizeof(stand));
    stand.type=CLONEMC_J_TILE_BREWING_STAND;
    stand.itemCount=4;
    for(i=0;i<CLONEMC_J_CHEST_INVENTORY_SIZE;++i)
        CloneMCJ_ItemStack_Clear(&stand.items[i]);
    for(i=0;i<3;++i)CloneMCJ_ItemStack_Initialize(&stand.items[i],373,1,0);
    CloneMCJ_ItemStack_Initialize(&stand.items[3],372,1,0);
    for(i=0;i<=400;++i)CloneMCJ_Progression_TickBrewing(&stand);
    if(stand.brewingTime!=0||!CloneMCJ_ItemStack_IsEmpty(&stand.items[3])||
       stand.items[0].itemDamage!=1||stand.items[1].itemDamage!=1||
       stand.items[2].itemDamage!=1)ok=0;
    CloneMCJ_ItemStack_Initialize(&enchanted,276,1,4);
    enchanted.enchantmentCount=2;
    enchanted.enchantmentId[0]=CLONEMC_J_ENCHANT_SHARPNESS;
    enchanted.enchantmentLevel[0]=3;
    enchanted.enchantmentId[1]=CLONEMC_J_ENCHANT_UNBREAKING;
    enchanted.enchantmentLevel[1]=2;
    tag=CloneMCJ_NBTTagCompound_Create();
    CloneMCJ_ItemStack_Clear(&restored);
    if(!tag||!CloneMCJ_ItemStack_WriteNBT(&enchanted,tag)||
       !CloneMCJ_ItemStack_ReadNBT(&restored,tag)||
       restored.enchantmentCount!=2||
       CloneMCJ_Progression_EnchantLevel(&restored,
           CLONEMC_J_ENCHANT_SHARPNESS)!=3||
       CloneMCJ_Progression_EnchantLevel(&restored,
           CLONEMC_J_ENCHANT_UNBREAKING)!=2)ok=0;
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)tag);
    if(message&&capacity){
        strncpy(message,ok?
            "progression: XP/orbs, potion transforms, 400-tick brewing, and enchant NBT passed":
            "progression: fixed-capacity regression failed",capacity-1U);
        message[capacity-1U]='\0';
    }
    return ok;
}
