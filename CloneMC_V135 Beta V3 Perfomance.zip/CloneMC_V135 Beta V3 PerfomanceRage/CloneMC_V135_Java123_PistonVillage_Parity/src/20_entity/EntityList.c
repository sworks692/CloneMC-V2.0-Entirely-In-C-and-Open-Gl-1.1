/*
 * CloneMC Java port scaffold: EntityList
 *
 * Java source: EntityList.java
 * Java type: class EntityList
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 9fc0827cb0fc9b6ed404b41eb01b3ac46c68273a2ef520414d99b68e9758c59d
 * Java lines: 156
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: World, Entity, NBTTagCompound, EntityArrow, EntitySnowball, EntityItem, EntityPainting, EntityLiving, EntityMob, EntityCreeper, EntitySkeleton, EntitySpider, EntityGiantZombie, EntityZombie, EntitySlime, EntityGhast, EntityPigZombie, EntityPig, EntitySheep, EntityCow, EntityChicken, EntitySquid, EntityWolf, EntityTNTPrimed, EntityFallingSand, EntityMinecart, EntityBoat, try, net.minecraft.src.World.class, world, w
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityList()
 * - private static void addMapping(Class class1, String s, int i)
 * - public static Entity createEntityInWorld(String s, World world)
 * - public static Entity createEntityFromNBT(NBTTagCompound nbttagcompound, World world)
 * - public static Entity createEntity(int i, World world)
 * - public static int getEntityID(Entity entity)
 * - public static String getEntityString(Entity entity)
 * - private static Map stringToClassMapping = new HashMap()
 * - private static Map classToStringMapping = new HashMap()
 * - private static Map IDtoClassMapping = new HashMap()
 * - private static Map classToIDMapping = new HashMap()
 *
 * This class now directly owns the uploaded string/numeric entity mappings and
 * living subtype NBT factory dispatch.
 */
#include "clonemc_java_port_20_entity.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <string.h>

typedef struct CloneMCJ_EntityMappingTag {
    const char *name;
    int numericID;
    CloneMCJ_MobType mobType;
    unsigned char isMob;
} CloneMCJ_EntityMapping;

/* EntityList.java static initializer, in the same order and with the same
 * persistent names and numeric IDs used by Beta 1.7.3. */
static const CloneMCJ_EntityMapping g_CloneMCJ_EntityMappings[] = {
    {"Arrow",10,CLONEMC_J_MOB_PIG,0},{"Snowball",11,CLONEMC_J_MOB_PIG,0},
    {"Item",1,CLONEMC_J_MOB_PIG,0},{"Painting",9,CLONEMC_J_MOB_PIG,0},
    {"Mob",48,CLONEMC_J_MOB_PIG,0},{"Monster",49,CLONEMC_J_MOB_ZOMBIE,0},
    {"Creeper",50,CLONEMC_J_MOB_CREEPER,1},
    {"Skeleton",51,CLONEMC_J_MOB_SKELETON,1},
    {"Spider",52,CLONEMC_J_MOB_SPIDER,1},
    {"Giant",53,CLONEMC_J_MOB_GIANT,1},
    {"Zombie",54,CLONEMC_J_MOB_ZOMBIE,1},
    {"Slime",55,CLONEMC_J_MOB_SLIME,1},
    {"Ghast",56,CLONEMC_J_MOB_GHAST,1},
    {"PigZombie",57,CLONEMC_J_MOB_PIG_ZOMBIE,1},
    {"Enderman",58,CLONEMC_J_MOB_ENDERMAN,1},
    {"Blaze",61,CLONEMC_J_MOB_BLAZE,1},
    {"LavaSlime",62,CLONEMC_J_MOB_MAGMA_CUBE,1},
    {"EnderDragon",63,CLONEMC_J_MOB_ENDER_DRAGON,1},
    {"Villager",120,CLONEMC_J_MOB_VILLAGER,1},
    {"Pig",90,CLONEMC_J_MOB_PIG,1},{"Sheep",91,CLONEMC_J_MOB_SHEEP,1},
    {"Cow",92,CLONEMC_J_MOB_COW,1},{"Chicken",93,CLONEMC_J_MOB_CHICKEN,1},
    {"Squid",94,CLONEMC_J_MOB_SQUID,1},{"Wolf",95,CLONEMC_J_MOB_WOLF,1},
    {"PrimedTnt",20,CLONEMC_J_MOB_PIG,0},
    {"FallingSand",21,CLONEMC_J_MOB_PIG,0},
    {"Minecart",40,CLONEMC_J_MOB_PIG,0},{"Boat",41,CLONEMC_J_MOB_PIG,0},
    {"EnderCrystal",200,CLONEMC_J_MOB_ENDER_CRYSTAL,1}
};

const char *CloneMCJ_EntityList_NameForNumericID(int numericID)
{
    unsigned int i;
    for(i=0;i<sizeof(g_CloneMCJ_EntityMappings)/sizeof(g_CloneMCJ_EntityMappings[0]);++i)
        if(g_CloneMCJ_EntityMappings[i].numericID==numericID)return g_CloneMCJ_EntityMappings[i].name;
    return (const char *)0;
}

int CloneMCJ_EntityList_NumericIDForName(const char *name)
{
    unsigned int i;if(!name)return -1;
    for(i=0;i<sizeof(g_CloneMCJ_EntityMappings)/sizeof(g_CloneMCJ_EntityMappings[0]);++i)
        if(!strcmp(g_CloneMCJ_EntityMappings[i].name,name))return g_CloneMCJ_EntityMappings[i].numericID;
    return -1;
}

const char *CloneMCJ_EntityList_NameForMob(CloneMCJ_MobType type)
{
    unsigned int i;
    for(i=0;i<sizeof(g_CloneMCJ_EntityMappings)/sizeof(g_CloneMCJ_EntityMappings[0]);++i)
        if(g_CloneMCJ_EntityMappings[i].isMob&&g_CloneMCJ_EntityMappings[i].mobType==type)
            return g_CloneMCJ_EntityMappings[i].name;
    return "Mob";
}

int CloneMCJ_EntityList_MobTypeForName(const char *name,CloneMCJ_MobType *type)
{
    unsigned int i;
    if(!name||!type)return 0;
    for(i=0;i<sizeof(g_CloneMCJ_EntityMappings)/sizeof(g_CloneMCJ_EntityMappings[0]);++i)
        if(g_CloneMCJ_EntityMappings[i].isMob&&!strcmp(name,g_CloneMCJ_EntityMappings[i].name)){
            *type=g_CloneMCJ_EntityMappings[i].mobType;return 1;
        }
    return 0;
}

int CloneMCJ_Mob_WriteNBT(const CloneMCJ_Mob *mob,CloneMCJ_NBTTagCompound *compound)
{
    const char *name;
    if(!mob||!compound||!mob->active)return 0;
    name=CloneMCJ_EntityList_NameForMob(mob->type);
    if(!CloneMCJ_Entity_WriteNBT(&mob->entity,compound,name))return 0;
    CloneMCJ_NBTTagCompound_SetShort(compound,"Health",(CloneMCJShort)mob->health);
    CloneMCJ_NBTTagCompound_SetShort(compound,"HurtTime",(CloneMCJShort)mob->hurtTime);
    CloneMCJ_NBTTagCompound_SetShort(compound,"DeathTime",(CloneMCJShort)mob->deathTime);
    CloneMCJ_NBTTagCompound_SetShort(compound,"AttackTime",(CloneMCJShort)mob->attackTime);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"EntityId",mob->entity.entityId);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"Age",mob->entityAge);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"GrowingAge",mob->growingAge);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"InLove",mob->inLove);
    CloneMCJ_NBTTagCompound_SetBoolean(compound,"PersistenceRequired",mob->persistenceRequired);
    CloneMCJ_NBTTagCompound_SetShort(compound,"TargetMemory",(CloneMCJShort)mob->targetMemoryTicks);
    if(mob->type==CLONEMC_J_MOB_CREEPER){
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"powered",mob->angry);
        CloneMCJ_NBTTagCompound_SetShort(compound,"Fuse",(CloneMCJShort)mob->timeSinceIgnited);
        CloneMCJ_NBTTagCompound_SetByte(compound,"CreeperState",(CloneMCJByte)mob->creeperState);
    }else if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE)
        CloneMCJ_NBTTagCompound_SetShort(compound,"Anger",(CloneMCJShort)mob->angerLevel);
    else if(mob->type==CLONEMC_J_MOB_SHEEP){
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"Sheared",mob->sheared);
        CloneMCJ_NBTTagCompound_SetByte(compound,"Color",(CloneMCJByte)(mob->woolColor&15));
    }else if(mob->type==CLONEMC_J_MOB_PIG)
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"Saddle",mob->saddled);
    else if(mob->type==CLONEMC_J_MOB_SLIME||
            mob->type==CLONEMC_J_MOB_MAGMA_CUBE){
        CloneMCJ_NBTTagCompound_SetInteger(compound,"Size",mob->slimeSize-1);
        CloneMCJ_NBTTagCompound_SetShort(compound,"JumpDelay",(CloneMCJShort)mob->slimeJumpDelay);
    }else if(mob->type==CLONEMC_J_MOB_WOLF){
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"Angry",mob->angry);
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"Sitting",mob->sitting);
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"Tamed",mob->tamed);
        CloneMCJ_NBTTagCompound_SetString(compound,"Owner",mob->owner);
    }else if(mob->type==CLONEMC_J_MOB_VILLAGER)
        CloneMCJ_NBTTagCompound_SetInteger(compound,"Profession",
            mob->profession);
    return 1;
}

int CloneMCJ_Mob_ReadNBT(CloneMCJ_Mob *mob,const CloneMCJ_NBTTagCompound *compound,
    CloneMCJ_World *world)
{
    CloneMCJ_MobType type;
    const char *id;
    int size,savedHealth;
    if(!mob||!compound)return 0;
    id=CloneMCJ_NBTTagCompound_GetString(compound,"id");
    if(!CloneMCJ_EntityList_MobTypeForName(id,&type))return 0;
    CloneMCJ_EntityLiving_InitializeMob(mob,type,world,0.0,0.0,0.0);
    if(!CloneMCJ_Entity_ReadNBT(&mob->entity,compound))return 0;
    savedHealth=CloneMCJ_NBTTagCompound_HasKey(compound,"Health")?
        CloneMCJ_NBTTagCompound_GetShort(compound,"Health"):mob->maxHealth;
    mob->hurtTime=CloneMCJ_NBTTagCompound_GetShort(compound,"HurtTime");
    mob->deathTime=CloneMCJ_NBTTagCompound_GetShort(compound,"DeathTime");
    mob->attackTime=CloneMCJ_NBTTagCompound_GetShort(compound,"AttackTime");
    size=CloneMCJ_NBTTagCompound_GetInteger(compound,"EntityId");
    if(size>0){mob->entity.entityId=size;CloneMCJ_Entity_ReserveID(size);}
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"Age"))
        mob->entityAge=CloneMCJ_NBTTagCompound_GetInteger(compound,"Age");
    if(mob->entityAge<0)mob->entityAge=0;
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"GrowingAge"))
        mob->growingAge=CloneMCJ_NBTTagCompound_GetInteger(
            compound,"GrowingAge");
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"InLove"))
        mob->inLove=CloneMCJ_NBTTagCompound_GetInteger(compound,"InLove");
    if(mob->inLove<0)mob->inLove=0;
    if(mob->inLove>600)mob->inLove=600;
    mob->renderScale=mob->growingAge<0?0.5F:1.0F;
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"PersistenceRequired"))
        mob->persistenceRequired=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(
            compound,"PersistenceRequired");
    if(CloneMCJ_NBTTagCompound_HasKey(compound,"TargetMemory"))
        mob->targetMemoryTicks=CloneMCJ_NBTTagCompound_GetShort(compound,"TargetMemory");
    if(mob->targetMemoryTicks<0)mob->targetMemoryTicks=0;
    if(type==CLONEMC_J_MOB_CREEPER){
        mob->angry=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound,"powered");
        if(CloneMCJ_NBTTagCompound_HasKey(compound,"Fuse"))
            mob->timeSinceIgnited=CloneMCJ_NBTTagCompound_GetShort(compound,"Fuse");
        if(mob->timeSinceIgnited<0)mob->timeSinceIgnited=0;
        if(mob->timeSinceIgnited>mob->fuseTime)mob->timeSinceIgnited=mob->fuseTime;
        mob->lastActiveTime=mob->timeSinceIgnited;
        if(CloneMCJ_NBTTagCompound_HasKey(compound,"CreeperState"))
            mob->creeperState=CloneMCJ_NBTTagCompound_GetByte(compound,"CreeperState");
        if(mob->creeperState<-1||mob->creeperState>1)mob->creeperState=-1;
    }else if(type==CLONEMC_J_MOB_PIG_ZOMBIE){
        mob->angerLevel=CloneMCJ_NBTTagCompound_GetShort(compound,"Anger");
        if(mob->angerLevel<0)mob->angerLevel=0;
        mob->angry=(unsigned char)(mob->angerLevel>0);mob->hostile=mob->angry;
    }else if(type==CLONEMC_J_MOB_SHEEP){
        mob->sheared=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound,"Sheared");
        mob->woolColor=CloneMCJ_NBTTagCompound_GetByte(compound,"Color")&15;
    }else if(type==CLONEMC_J_MOB_PIG)
        mob->saddled=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound,"Saddle");
    else if(type==CLONEMC_J_MOB_SLIME||
            type==CLONEMC_J_MOB_MAGMA_CUBE){
        size=CloneMCJ_NBTTagCompound_GetInteger(compound,"Size")+1;
        CloneMCJ_EntitySlime_SetSizeNative(mob,size);
        if(CloneMCJ_NBTTagCompound_HasKey(compound,"JumpDelay"))
            mob->slimeJumpDelay=CloneMCJ_NBTTagCompound_GetShort(compound,"JumpDelay");
        if(mob->slimeJumpDelay<1)mob->slimeJumpDelay=1;
    }else if(type==CLONEMC_J_MOB_WOLF){
        mob->angry=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound,"Angry");
        mob->sitting=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound,"Sitting");
        id=CloneMCJ_NBTTagCompound_GetString(compound,"Owner");
        if(id){strncpy(mob->owner,id,sizeof(mob->owner)-1U);
            mob->owner[sizeof(mob->owner)-1U]='\0';}
        mob->tamed=(unsigned char)(mob->owner[0]!='\0'||
            CloneMCJ_NBTTagCompound_GetBoolean(compound,"Tamed"));
        if(mob->tamed){mob->maxHealth=20;mob->persistenceRequired=1;}
    }else if(type==CLONEMC_J_MOB_VILLAGER){
        mob->profession=CloneMCJ_NBTTagCompound_HasKey(compound,"Profession")?
            CloneMCJ_NBTTagCompound_GetInteger(compound,"Profession"):0;
        if(mob->profession<0||mob->profession>4)mob->profession=0;
        mob->persistenceRequired=1;
    }
    mob->health=savedHealth;
    if(mob->health>mob->maxHealth)mob->health=mob->maxHealth;
    if(mob->health<0)mob->health=0;
    mob->prevHealth=mob->health;
    mob->active=1;
    if(type==CLONEMC_J_MOB_WOLF&&mob->tamed)mob->persistenceRequired=1;
    return 1;
}

void CloneMCJ_EntityList_Register(void)
{
    /* The static Java mapping table requires no runtime registration. */
}

const char *CloneMCJ_EntityList_JavaName(void)
{
    return "net.minecraft.src.EntityList";
}

const char *CloneMCJ_EntityList_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityList_JavaSourceHash32(void)
{
    return 0x9FC0827CUL;
}
