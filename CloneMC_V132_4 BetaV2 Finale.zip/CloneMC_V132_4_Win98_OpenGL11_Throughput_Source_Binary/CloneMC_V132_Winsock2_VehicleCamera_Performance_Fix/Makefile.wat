# CloneMC V132.4 Win9x OpenGL 1.1 throughput correction build for
# Open Watcom V2.0.  Retains the cumulative V131 gameplay/GUI/UV corrections,
# Win32/OpenGL 1.1 rendering, and the uploaded Java implementation as the
# vehicle transform and camera authority.
# Build from the project root with: wmake -f Makefile.wat
#
# SOURCE GRAPH
#   project2finalalpharecreation.c
#     -> 9 subsystem .inc manifests
#       -> 677 native C modules including the deterministic Priority 17 regression module
#         -> exactly 10 shared subsystem .h files
#     -> registry .inc and registry .h
#
# Open Watcom compiles the complete graph above as one translation unit and one
# object. WLINK must receive that object, not the source/header files themselves.
# The .SYMBOLIC dependency forces recompilation so edits to any included C, H,
# or INC file are recognized without maintaining a fragile dependency list.

VERSION = V132
EXE = CloneMC_$(VERSION)_Winsock2_VehicleCamera_Performance_Fix.exe
OBJ = project2finalalpharecreation.obj
SRC = project2finalalpharecreation.c
LNK = clonemc_v132_winsock2_vehiclecamera_performance_fix.lnk
PYTHON = python

all: verify $(EXE)

verify: .SYMBOLIC
	$(PYTHON) tools/generate_reference_manifest.py --verify

$(OBJ): .SYMBOLIC
	wcc386 -q -otexan -bt=nt -dWINVER=0x0400 -d_WIN32_WINNT=0x0400 -dCLONEMC_BUILD_OPEN_WATCOM_V2=1 -dCLONEMC_REFERENCE_DEFAULT=0 -fo=$(OBJ) $(SRC)

$(EXE): $(OBJ) $(LNK)
	wlink @$(LNK)

clean: .SYMBOLIC
	$(PYTHON) tools/clean_build.py

rebuild: .SYMBOLIC
	@wmake -f Makefile.wat clean
	@wmake -f Makefile.wat all

help: .SYMBOLIC
	@echo CloneMC Open Watcom build targets:
	@echo   wmake -f Makefile.wat          build the Win32 executable
	@echo   wmake -f Makefile.wat rebuild  clean and rebuild
	@echo   wmake -f Makefile.wat verify   verify source/manifests without compiling
	@echo   wmake -f Makefile.wat clean    remove generated object, EXE and map
