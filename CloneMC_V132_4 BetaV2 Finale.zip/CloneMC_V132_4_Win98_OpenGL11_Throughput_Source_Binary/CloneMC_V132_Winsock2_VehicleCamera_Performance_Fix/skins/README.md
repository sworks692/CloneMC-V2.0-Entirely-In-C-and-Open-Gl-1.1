# Local player skins

CloneMC V132.2 supports local Java-era player skins without an online service.

## Automatic names

For a local or multiplayer username named `Player`, use either:

```text
skins/Player.png
skins/Player.tga
```

PNG is tried before TGA. Usernames are sanitized to at most 16 letters,
digits, or underscores before a file is opened.

## Explicit local skin

```text
CloneMC_V132_Winsock2_VehicleCamera_Performance_Fix.exe -playerskin=skins/Player.png
```

Use a path without spaces.

## Image requirements

- 64x32 or 64x64;
- PNG: 8-bit RGB/RGBA and non-interlaced; or
- TGA: uncompressed true-color 24/32-bit.

The uploaded Java version uses the classic/wide 64x32 player model. A 64x32
skin maps exactly. For a 64x64 skin, CloneMC uses the compatible top-half/base
layer on that classic model. Later slim-arm and lower-half overlay geometry is
not part of the uploaded Beta renderer.

Malformed or unsupported files fall back to `assets/mob/char.tga` without
terminating the game.
