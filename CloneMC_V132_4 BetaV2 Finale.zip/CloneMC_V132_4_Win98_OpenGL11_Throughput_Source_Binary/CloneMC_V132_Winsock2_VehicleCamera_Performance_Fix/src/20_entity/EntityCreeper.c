/*
 * CloneMC Java port scaffold: EntityCreeper
 *
 * Java source: EntityCreeper.java
 * Java type: class EntityCreeper
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityMob
 * Implements: (none declared)
 * Source SHA-256: 5419473aba52c87709e1c7617648602cd54f338400c72f81c16b5dbb232ed865
 * Java lines: 184
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 16
 * Referenced Java classes: EntityMob, DataWatcher, NBTTagCompound, World, EntitySkeleton, Item, Entity, EntityLightningBolt, timeSinceIgnited
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityCreeper(World world)
 * - protected void entityInit()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected void attackBlockedEntity(Entity entity, float f)
 * - public void onUpdate()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - public void onDeath(Entity entity)
 * - protected void attackEntity(Entity entity, float f)
 * - public boolean getPowered()
 * - public float setCreeperFlashTime(float f)
 * - protected int getDropItemId()
 * - private int getCreeperState()
 * - private void setCreeperState(int i)
 * - public void onStruckByLightning(EntityLightningBolt entitylightningbolt)
 *
 * This class now owns typed construction; fuse, powered-lightning state,
 * explosion radius and NBT run in the shared bounded mob runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityCreeper_InitializeNative(CloneMCJ_Mob *creeper,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(creeper,CLONEMC_J_MOB_CREEPER,world,x,y,z);
}

void CloneMCJ_EntityCreeper_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntityCreeper_JavaName(void)
{
    return "net.minecraft.src.EntityCreeper";
}

const char *CloneMCJ_EntityCreeper_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityCreeper_JavaSourceHash32(void)
{
    return 0x5419473AUL;
}
