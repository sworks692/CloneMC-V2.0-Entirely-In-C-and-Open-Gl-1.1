/*
 * CloneMC Java port scaffold: PathPoint
 *
 * Java source: PathPoint.java
 * Java type: class PathPoint
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: dce1d453749c6bf3bfe7281c17a93370a1a14c37611498407e4f15d00c990615
 * Java lines: 75
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: MathHelper, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final int xCoord
 * - public final int yCoord
 * - public final int zCoord
 * - private final int hash
 * - public boolean isFirst
 *
 * Java method/constructor inventory:
 * - public PathPoint(int i, int j, int k)
 * - public static int func_22329_a(int i, int j, int k)
 * - public float distanceTo(PathPoint pathpoint)
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - public boolean isAssigned()
 * - public String toString()
 *
 * This class now directly owns Java coordinate hashing, construction, equality
 * and Euclidean distance behavior used by the bounded A* search.
 */
#include "clonemc_java_port_20_entity.h"
#include <math.h>
#include <string.h>

int CloneMCJ_PathPoint_Hash(int x,int y,int z)
{
    unsigned long value;value=(unsigned long)(y&255);value|=((unsigned long)(x&32767))<<8;
    value|=((unsigned long)(z&32767))<<24;if(x<0)value|=0x80000000UL;
    if(z<0)value|=0x00008000UL;
    return (int)value;
}

void CloneMCJ_PathPoint_InitializeNative(CloneMCJ_PathPointNative *point,int x,int y,int z)
{
    if(!point)return;
    memset(point,0,sizeof(*point));point->xCoord=x;point->yCoord=y;
    point->zCoord=z;point->hash=CloneMCJ_PathPoint_Hash(x,y,z);point->heapIndex=-1;
    point->previousIndex=-1;
}

float CloneMCJ_PathPoint_DistanceTo(const CloneMCJ_PathPointNative *a,
    const CloneMCJ_PathPointNative *b)
{
    float x,y,z;if(!a||!b)return 0.0F;x=(float)(b->xCoord-a->xCoord);
    y=(float)(b->yCoord-a->yCoord);z=(float)(b->zCoord-a->zCoord);
    return (float)sqrt((double)(x*x+y*y+z*z));
}

int CloneMCJ_PathPoint_EqualsNative(const CloneMCJ_PathPointNative *a,
    const CloneMCJ_PathPointNative *b)
{
    return a&&b&&a->hash==b->hash&&a->xCoord==b->xCoord&&a->yCoord==b->yCoord&&a->zCoord==b->zCoord;
}

void CloneMCJ_PathPoint_Register(void)
{
    /* PathPoint behavior is called directly by Pathfinder. */
}

const char *CloneMCJ_PathPoint_JavaName(void)
{
    return "net.minecraft.src.PathPoint";
}

const char *CloneMCJ_PathPoint_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_PathPoint_JavaSourceHash32(void)
{
    return 0xDCE1D453UL;
}
