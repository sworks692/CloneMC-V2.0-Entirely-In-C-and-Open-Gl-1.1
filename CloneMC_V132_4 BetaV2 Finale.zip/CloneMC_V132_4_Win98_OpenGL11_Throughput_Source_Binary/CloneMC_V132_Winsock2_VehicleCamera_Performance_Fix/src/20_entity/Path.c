/*
 * CloneMC Java port scaffold: Path
 *
 * Java source: Path.java
 * Java type: class Path
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 24d158f40d58ccd6d555303b96f7497d31ee366d7e312a49c2159bfc4b89b769
 * Java lines: 149
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: PathPoint, apathpoint, do
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private PathPoint pathPoints[]
 * - private int count
 *
 * Java method/constructor inventory:
 * - public Path()
 * - public PathPoint addPoint(PathPoint pathpoint)
 * - public void clearPath()
 * - public PathPoint dequeue()
 * - public void changeDistance(PathPoint pathpoint, float f)
 * - private void sortBack(int i)
 * - private void sortForward(int i)
 * - public boolean isPathEmpty()
 *
 * This class now directly owns the Java binary-min-heap add, dequeue and
 * change-distance operations used by Pathfinder.
 */
#include "clonemc_java_port_20_entity.h"

static void CloneMCJ_Path_Swap(int *heap,CloneMCJ_PathPointNative *points,int a,int b)
{
    int value;value=heap[a];heap[a]=heap[b];heap[b]=value;
    points[heap[a]].heapIndex=a;points[heap[b]].heapIndex=b;
}

static void CloneMCJ_Path_SortBack(int *heap,int count,CloneMCJ_PathPointNative *points,int position)
{
    int parent;(void)count;while(position>0){parent=(position-1)>>1;
        if(points[heap[position]].distanceToTarget>=points[heap[parent]].distanceToTarget)break;
        CloneMCJ_Path_Swap(heap,points,position,parent);position=parent;}
}

static void CloneMCJ_Path_SortForward(int *heap,int count,CloneMCJ_PathPointNative *points,int position)
{
    int left,right,best;for(;;){left=1+(position<<1);right=left+1;best=position;
        if(left<count&&points[heap[left]].distanceToTarget<points[heap[best]].distanceToTarget)best=left;
        if(right<count&&points[heap[right]].distanceToTarget<points[heap[best]].distanceToTarget)best=right;
        if(best==position)break;
        CloneMCJ_Path_Swap(heap,points,position,best);position=best;}
}

int CloneMCJ_Path_AddPoint(int *heap,int *count,CloneMCJ_PathPointNative *points,
    int pointIndex,int capacity)
{
    int position;if(!heap||!count||!points||pointIndex<0||*count>=capacity)return 0;
    position=(*count)++;heap[position]=pointIndex;points[pointIndex].heapIndex=position;
    points[pointIndex].opened=1;CloneMCJ_Path_SortBack(heap,*count,points,position);return 1;
}

int CloneMCJ_Path_Dequeue(int *heap,int *count,CloneMCJ_PathPointNative *points)
{
    int pointIndex;if(!heap||!count||!points||*count<=0)return -1;pointIndex=heap[0];--(*count);
    if(*count>0){heap[0]=heap[*count];points[heap[0]].heapIndex=0;
        CloneMCJ_Path_SortForward(heap,*count,points,0);}
    points[pointIndex].heapIndex=-1;return pointIndex;
}

void CloneMCJ_Path_ChangeDistance(int *heap,int count,CloneMCJ_PathPointNative *points,
    int pointIndex,float distance)
{
    float old;int position;if(!heap||!points||pointIndex<0)return;
    old=points[pointIndex].distanceToTarget;points[pointIndex].distanceToTarget=distance;
    position=points[pointIndex].heapIndex;if(position<0)return;
    if(distance<old)CloneMCJ_Path_SortBack(heap,count,points,position);
    else CloneMCJ_Path_SortForward(heap,count,points,position);
}

void CloneMCJ_Path_Register(void)
{
    /* The heap is initialized by setting its bounded count to zero. */
}

const char *CloneMCJ_Path_JavaName(void)
{
    return "net.minecraft.src.Path";
}

const char *CloneMCJ_Path_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_Path_JavaSourceHash32(void)
{
    return 0x24D158F4UL;
}
