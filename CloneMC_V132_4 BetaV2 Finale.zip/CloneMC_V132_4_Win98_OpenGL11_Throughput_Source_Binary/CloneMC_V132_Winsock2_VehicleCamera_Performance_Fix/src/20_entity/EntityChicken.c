/*
 * CloneMC Java port scaffold: EntityChicken
 *
 * Java source: EntityChicken.java
 * Java type: class EntityChicken
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityAnimal
 * Implements: (none declared)
 * Source SHA-256: d2f74101bc255d8fa3d25005a8512a24d9f50856250e0711b590aa0fdbd5c860
 * Java lines: 102
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: EntityAnimal, World, Item, NBTTagCompound, protec
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public boolean field_753_a
 * - public float field_752_b
 * - public float destPos
 * - public float field_757_d
 * - public float field_756_e
 * - public float field_755_h
 * - public int timeUntilNextEgg
 *
 * Java method/constructor inventory:
 * - public EntityChicken(World world)
 * - public void onLivingUpdate()
 * - protected void fall(float f)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected int getDropItemId()
 *
 * This class now owns typed construction; EntityLiving and EntityPlayerSP retain
 * the uploaded slow-fall/egg timer state in the shared bounded mob runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityChicken_InitializeNative(CloneMCJ_Mob *chicken,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(chicken,CLONEMC_J_MOB_CHICKEN,world,x,y,z);
}

void CloneMCJ_EntityChicken_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntityChicken_JavaName(void)
{
    return "net.minecraft.src.EntityChicken";
}

const char *CloneMCJ_EntityChicken_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityChicken_JavaSourceHash32(void)
{
    return 0xD2F74101UL;
}
