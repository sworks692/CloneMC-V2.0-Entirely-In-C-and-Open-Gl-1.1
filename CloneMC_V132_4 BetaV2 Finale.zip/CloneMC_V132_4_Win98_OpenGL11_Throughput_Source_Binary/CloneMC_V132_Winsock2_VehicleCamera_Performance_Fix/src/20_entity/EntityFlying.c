/*
 * CloneMC Java port scaffold: EntityFlying
 *
 * Java source: EntityFlying.java
 * Java type: class EntityFlying
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityLiving
 * Implements: (none declared)
 * Source SHA-256: 3829827e1bd32d0e2cfc02251a6e73866b02dda6832d160fa3747cfa65bad988
 * Java lines: 87
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: EntityLiving, MathHelper, AxisAlignedBB, World, Block, f1, motionY
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityFlying(World world)
 * - protected void fall(float f)
 * - public void moveEntityWithHeading(float f, float f1)
 * - public boolean isOnLadder()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityFlying_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityFlying_JavaName(void)
{
    return "net.minecraft.src.EntityFlying";
}

const char *CloneMCJ_EntityFlying_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityFlying_JavaSourceHash32(void)
{
    return 0x3829827EUL;
}
