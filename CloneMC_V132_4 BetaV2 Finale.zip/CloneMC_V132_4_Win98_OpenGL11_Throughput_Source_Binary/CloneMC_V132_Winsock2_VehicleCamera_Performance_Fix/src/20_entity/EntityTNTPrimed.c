/*
 * CloneMC Java port scaffold: EntityTNTPrimed
 *
 * Java source: EntityTNTPrimed.java
 * Java type: class EntityTNTPrimed
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 3991e665380311fcc5c91ae9754884e51f2d6b385f54b8c6a7089ba9719161a4
 * Java lines: 106
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: Entity, MathHelper, World, NBTTagCompound, d1, motionY, posX, posZ
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int fuse
 *
 * Java method/constructor inventory:
 * - public EntityTNTPrimed(World world)
 * - public EntityTNTPrimed(World world, double d, double d1, double d2)
 * - protected void entityInit()
 * - protected boolean canTriggerWalking()
 * - public boolean canBeCollidedWith()
 * - public void onUpdate()
 * - private void explode()
 * - protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public float getShadowSize()
 *
 * This class now owns the Java 80-tick primed-TNT constructor; fuse physics,
 * explosion and NBT are shared by the bounded vehicle runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityTNTPrimed_InitializeNative(CloneMCJ_Vehicle *tnt,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_Vehicle_Initialize(tnt,CLONEMC_J_VEHICLE_PRIMED_TNT,world,x,y,z,0);
}

void CloneMCJ_EntityTNTPrimed_Register(void)
{
    /* Runtime dispatch is installed through the bounded vehicle table. */
}

const char *CloneMCJ_EntityTNTPrimed_JavaName(void)
{
    return "net.minecraft.src.EntityTNTPrimed";
}

const char *CloneMCJ_EntityTNTPrimed_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityTNTPrimed_JavaSourceHash32(void)
{
    return 0x3991E665UL;
}
