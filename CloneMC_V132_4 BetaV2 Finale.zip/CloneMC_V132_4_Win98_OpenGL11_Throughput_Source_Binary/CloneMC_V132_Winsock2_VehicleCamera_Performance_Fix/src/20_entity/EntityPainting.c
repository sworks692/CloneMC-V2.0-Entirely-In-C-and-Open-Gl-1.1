/*
 * CloneMC Java port scaffold: EntityPainting
 *
 * Java source: EntityPainting.java
 * Java type: class EntityPainting
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 0cdcebe5cd105eb2e1eaaf21b662c31b2ac8968c6d7559a4448101622334e266
 * Java lines: 299
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 14
 * Referenced Java classes: Entity, EnumArt, AxisAlignedBB, World, EntityItem, ItemStack, Item, MathHelper, Material, NBTTagCompound, do
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_695_c
 * - public int direction
 * - public int xPosition
 * - public int yPosition
 * - public int zPosition
 * - public EnumArt art
 *
 * Java method/constructor inventory:
 * - public EntityPainting(World world)
 * - public EntityPainting(World world, int i, int j, int k, int l)
 * - public EntityPainting(World world, int i, int j, int k, int l, String s)
 * - protected void entityInit()
 * - public void func_412_b(int i)
 * - private float func_411_c(int i)
 * - public void onUpdate()
 * - public boolean func_410_i()
 * - public boolean canBeCollidedWith()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void moveEntity(double d, double d1, double d2)
 * - public void addVelocity(double d, double d1, double d2)
 *
 * This class now owns painting placement/direction/art initialization; support,
 * damage and NBT use the bounded vehicle runtime.
 */
#include "clonemc_java_port_20_entity.h"
#include <string.h>

void CloneMCJ_EntityPainting_InitializeNative(CloneMCJ_Vehicle *painting,
    struct CloneMCJ_WorldTag *world,int x,int y,int z,int direction,const char *art)
{
    CloneMCJ_Vehicle_Initialize(painting,CLONEMC_J_VEHICLE_PAINTING,world,
        (double)x+0.5,(double)y+0.5,(double)z+0.5,0);
    painting->tileX=x;painting->tileY=y;painting->tileZ=z;painting->direction=direction&3;
    if(art&&art[0]){strncpy(painting->art,art,sizeof(painting->art)-1U);
        painting->art[sizeof(painting->art)-1U]='\0';}
}

void CloneMCJ_EntityPainting_Register(void)
{
    /* Runtime dispatch is installed through the bounded vehicle table. */
}

const char *CloneMCJ_EntityPainting_JavaName(void)
{
    return "net.minecraft.src.EntityPainting";
}

const char *CloneMCJ_EntityPainting_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityPainting_JavaSourceHash32(void)
{
    return 0x0CDCEBE5UL;
}
