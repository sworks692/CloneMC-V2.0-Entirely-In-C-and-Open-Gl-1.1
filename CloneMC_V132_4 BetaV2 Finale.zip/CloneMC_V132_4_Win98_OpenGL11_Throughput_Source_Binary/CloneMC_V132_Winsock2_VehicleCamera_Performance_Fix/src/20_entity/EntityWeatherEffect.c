/*
 * CloneMC Java port scaffold: EntityWeatherEffect
 *
 * Java source: EntityWeatherEffect.java
 * Java type: class EntityWeatherEffect
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 608166ad0ffecf59f7088160733b3583215df9692103a07043adc3b378f9ab01
 * Java lines: 19
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: Entity, World
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityWeatherEffect(World world)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityWeatherEffect_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityWeatherEffect_JavaName(void)
{
    return "net.minecraft.src.EntityWeatherEffect";
}

const char *CloneMCJ_EntityWeatherEffect_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityWeatherEffect_JavaSourceHash32(void)
{
    return 0x608166ADUL;
}
