/*
 * CloneMC Java port scaffold: PathEntity
 *
 * Java source: PathEntity.java
 * Java type: class PathEntity
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 37edc34172ff8015e16567973b1001558e7ba7fa8c01b66d7d56cde4b9008fe6
 * Java lines: 53
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: PathPoint, Entity, Vec3D, d1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final PathPoint points[]
 * - public final int pathLength
 * - private int pathIndex
 *
 * Java method/constructor inventory:
 * - public PathEntity(PathPoint apathpoint[])
 * - public void incrementPathIndex()
 * - public boolean isFinished()
 * - public PathPoint func_22328_c()
 * - public Vec3D getPosition(Entity entity)
 *
 * This class now directly owns path position calculation and index advancement
 * for the bounded Java path representation.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_PathEntity_GetPosition(const CloneMCJ_PathEntityNative *path,
    const CloneMCJ_Entity *entity,CloneMCVec3D *position)
{
    const CloneMCJ_PathPointNative *point;
    int offset;
    if(!path||!entity||!position||path->pathIndex<0||path->pathIndex>=path->pathLength)return 0;
    point=&path->points[path->pathIndex];offset=CloneMCJava_FloorFloat(entity->width+1.0F);
    position->xCoord=(double)point->xCoord+(double)offset*0.5;
    position->yCoord=(double)point->yCoord;
    position->zCoord=(double)point->zCoord+(double)offset*0.5;
    return 1;
}

void CloneMCJ_PathEntity_Increment(CloneMCJ_PathEntityNative *path)
{
    if(path&&path->pathIndex<path->pathLength)++path->pathIndex;
}

void CloneMCJ_PathEntity_Register(void)
{
    /* Path objects are initialized by Pathfinder on demand. */
}

const char *CloneMCJ_PathEntity_JavaName(void)
{
    return "net.minecraft.src.PathEntity";
}

const char *CloneMCJ_PathEntity_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_PathEntity_JavaSourceHash32(void)
{
    return 0x37EDC341UL;
}
