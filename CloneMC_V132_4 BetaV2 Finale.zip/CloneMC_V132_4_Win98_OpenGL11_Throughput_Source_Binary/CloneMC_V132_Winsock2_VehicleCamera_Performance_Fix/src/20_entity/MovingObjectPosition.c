/*
 * CloneMC Java port scaffold: MovingObjectPosition
 *
 * Java source: MovingObjectPosition.java
 * Java type: class MovingObjectPosition
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 54d2534413c3a58ae6cf808821a6cf4c0fb579302725267b0bcc4ff45005f54b
 * Java lines: 39
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: EnumMovingObjectType, Vec3D, Entity, vec3d.yCoord, entity.posY
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public EnumMovingObjectType typeOfHit
 * - public int blockX
 * - public int blockY
 * - public int blockZ
 * - public int sideHit
 * - public Vec3D hitVec
 * - public Entity entityHit
 *
 * Java method/constructor inventory:
 * - public MovingObjectPosition(int i, int j, int k, int l, Vec3D vec3d)
 * - public MovingObjectPosition(Entity entity)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_MovingObjectPosition_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MovingObjectPosition_JavaName(void)
{
    return "net.minecraft.src.MovingObjectPosition";
}

const char *CloneMCJ_MovingObjectPosition_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_MovingObjectPosition_JavaSourceHash32(void)
{
    return 0x54D25344UL;
}
