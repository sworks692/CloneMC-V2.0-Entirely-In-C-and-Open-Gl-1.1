/*
 * CloneMC Java port scaffold: EntitySquid
 *
 * Java source: EntitySquid.java
 * Java type: class EntitySquid
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityWaterMob
 * Implements: (none declared)
 * Source SHA-256: 2fa244e9a1fd8fca7731f1f47bb24a395bc32bc085a30d27e32326734803043d
 * Java lines: 187
 * Discovered declared fields: 14
 * Discovered declared methods/constructors: 14
 * Referenced Java classes: EntityWaterMob, ItemStack, Item, AxisAlignedBB, Material, World, MathHelper, NBTTagCompound, EntityPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public float field_21089_a
 * - public float field_21088_b
 * - public float field_21087_c
 * - public float field_21086_f
 * - public float field_21085_g
 * - public float field_21084_h
 * - public float field_21083_i
 * - public float field_21082_j
 * - private float randomMotionSpeed
 * - private float field_21080_l
 * - private float field_21079_m
 * - private float randomMotionVecX
 * - private float randomMotionVecY
 * - private float randomMotionVecZ
 *
 * Java method/constructor inventory:
 * - public EntitySquid(World world)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected float getSoundVolume()
 * - protected int getDropItemId()
 * - protected void dropFewItems()
 * - public boolean interact(EntityPlayer entityplayer)
 * - public boolean isInWater()
 * - public void onLivingUpdate()
 * - public void moveEntityWithHeading(float f, float f1)
 * - protected void updatePlayerActionState()
 *
 * This class now owns typed construction; water movement, animation, spawning,
 * ink drops and persistence use the shared water-mob runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntitySquid_InitializeNative(CloneMCJ_Mob *squid,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(squid,CLONEMC_J_MOB_SQUID,world,x,y,z);
}

void CloneMCJ_EntitySquid_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntitySquid_JavaName(void)
{
    return "net.minecraft.src.EntitySquid";
}

const char *CloneMCJ_EntitySquid_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntitySquid_JavaSourceHash32(void)
{
    return 0x2FA244E9UL;
}
