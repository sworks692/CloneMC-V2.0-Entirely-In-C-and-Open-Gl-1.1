/*
 * CloneMC Java port scaffold: EntityPigZombie
 *
 * Java source: EntityPigZombie.java
 * Java type: class EntityPigZombie
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityZombie
 * Implements: (none declared)
 * Source SHA-256: ddd7b1d0b03c3a657aae66bc5b9c7d66f47c0f0b429e0cd82616582ba223e5bf
 * Java lines: 132
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 14
 * Referenced Java classes: EntityZombie, World, NBTTagCompound, EntityPlayer, AxisAlignedBB, Entity, Item, ItemStack, b
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int angerLevel
 * - private int randomSoundDelay
 * - private static final ItemStack defaultHeldItem
 *
 * Java method/constructor inventory:
 * - public EntityPigZombie(World world)
 * - public void onUpdate()
 * - public boolean getCanSpawnHere()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected Entity findPlayerToAttack()
 * - public void onLivingUpdate()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - private void becomeAngryAt(Entity entity)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected int getDropItemId()
 * - public ItemStack getHeldItem()
 *
 * This class now owns typed construction and Java anger initialization. Nearby
 * pig zombies are alerted by the player combat path and `Anger` is persisted.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityPigZombie_InitializeNative(CloneMCJ_Mob *pigZombie,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(pigZombie,CLONEMC_J_MOB_PIG_ZOMBIE,world,x,y,z);
}

void CloneMCJ_EntityPigZombie_BecomeAngryNative(CloneMCJ_Mob *pigZombie)
{
    CloneMCJ_EntityLiving_AngerPigZombie(pigZombie);
}

void CloneMCJ_EntityPigZombie_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntityPigZombie_JavaName(void)
{
    return "net.minecraft.src.EntityPigZombie";
}

const char *CloneMCJ_EntityPigZombie_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityPigZombie_JavaSourceHash32(void)
{
    return 0xDDD7B1D0UL;
}
