/*
 * CloneMC Java port scaffold: EntityZombie
 *
 * Java source: EntityZombie.java
 * Java type: class EntityZombie
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityMob
 * Implements: (none declared)
 * Source SHA-256: 30e7e4d442186bf99eda28da8a0e157bb3d68d3fffc7339ded94fbd18a22f9da
 * Java lines: 56
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: EntityMob, World, MathHelper, Item
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityZombie(World world)
 * - public void onLivingUpdate()
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected int getDropItemId()
 *
 * This class now owns typed construction; daylight ignition, path pursuit,
 * melee damage, hurt resistance and drops use the shared hostile-mob runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityZombie_InitializeNative(CloneMCJ_Mob *zombie,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(zombie,CLONEMC_J_MOB_ZOMBIE,world,x,y,z);
}

void CloneMCJ_EntityZombie_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntityZombie_JavaName(void)
{
    return "net.minecraft.src.EntityZombie";
}

const char *CloneMCJ_EntityZombie_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityZombie_JavaSourceHash32(void)
{
    return 0x30E7E4D4UL;
}
