/*
 * CloneMC Java port scaffold: EntityEgg
 *
 * Java source: EntityEgg.java
 * Java type: class EntityEgg
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: b115bd81e2740c49e20813f12c6954fbe8557a1d101c19b1d02e2c9b82d28ae7
 * Java lines: 297
 * Discovered declared fields: 9
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: Entity, AxisAlignedBB, EntityLiving, MathHelper, World, Vec3D, MovingObjectPosition, EntityChicken, NBTTagCompound, EntityPlayer, ItemStack, Item, InventoryPlayer, entityliving.posZ, entityliving.rotationYaw, posY
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_20056_b
 * - private int field_20055_c
 * - private int field_20054_d
 * - private int field_20053_e
 * - private boolean field_20052_f
 * - public int field_20057_a
 * - private EntityLiving field_20051_g
 * - private int field_20050_h
 * - private int field_20049_i
 *
 * Java method/constructor inventory:
 * - public EntityEgg(World world)
 * - protected void entityInit()
 * - public boolean isInRangeToRenderDist(double d)
 * - public EntityEgg(World world, EntityLiving entityliving)
 * - public EntityEgg(World world, double d, double d1, double d2)
 * - public void setVelocity(double d, double d1, double d2)
 * - public void onUpdate()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void onCollideWithPlayer(EntityPlayer entityplayer)
 * - public float getShadowSize()
 *
 * This class owns the typed Java constructor adapter; egg impact/hatching and
 * NBT behavior is implemented once by the bounded projectile runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityEgg_InitializeNative(CloneMCJ_Projectile *egg,
    struct CloneMCJ_WorldTag *world,const CloneMCJ_Entity *thrower)
{
    CloneMCJ_Projectile_Initialize(egg,CLONEMC_J_PROJECTILE_EGG,world,thrower,1.5F,1.0F);
}

void CloneMCJ_EntityEgg_Register(void)
{
    /* Runtime dispatch is installed through the bounded projectile table. */
}

const char *CloneMCJ_EntityEgg_JavaName(void)
{
    return "net.minecraft.src.EntityEgg";
}

const char *CloneMCJ_EntityEgg_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityEgg_JavaSourceHash32(void)
{
    return 0xB115BD81UL;
}
