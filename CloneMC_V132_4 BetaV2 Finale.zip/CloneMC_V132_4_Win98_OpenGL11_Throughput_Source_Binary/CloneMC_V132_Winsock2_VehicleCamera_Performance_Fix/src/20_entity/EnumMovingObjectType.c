/*
 * CloneMC Java port scaffold: EnumMovingObjectType
 *
 * Java source: EnumMovingObjectType.java
 * Java type: enum EnumMovingObjectType
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: cf928f2c58db161084c0afe80f16603fe0a62503a682900a5fea9ee5c98c8a12
 * Java lines: 44
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static final EnumMovingObjectType field_21178_c[]
 *
 * Java method/constructor inventory:
 * - private EnumMovingObjectType(String s, int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EnumMovingObjectType_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumMovingObjectType_JavaName(void)
{
    return "net.minecraft.src.EnumMovingObjectType";
}

const char *CloneMCJ_EnumMovingObjectType_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EnumMovingObjectType_JavaSourceHash32(void)
{
    return 0xCF928F2CUL;
}
