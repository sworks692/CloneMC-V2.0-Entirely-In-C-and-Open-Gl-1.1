/*
 * CloneMC Java port scaffold: MovementInputFromOptions
 *
 * Java source: MovementInputFromOptions.java
 * Java type: class MovementInputFromOptions
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: MovementInput
 * Implements: (none declared)
 * Source SHA-256: 48e0945d79321e0c2e326c9eec3d29542f85794c063bd92630e3cad94489d0a7
 * Java lines: 94
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: MovementInput, GameSettings, KeyBinding, EntityPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private boolean movementKeyStates[]
 * - private GameSettings gameSettings
 *
 * Java method/constructor inventory:
 * - public MovementInputFromOptions(GameSettings gamesettings)
 * - public void checkKeyForMovementInput(int i, boolean flag)
 * - public void resetKeyState()
 * - public void updatePlayerMoveState(EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_MovementInputFromOptions_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MovementInputFromOptions_JavaName(void)
{
    return "net.minecraft.src.MovementInputFromOptions";
}

const char *CloneMCJ_MovementInputFromOptions_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_MovementInputFromOptions_JavaSourceHash32(void)
{
    return 0x48E0945DUL;
}
