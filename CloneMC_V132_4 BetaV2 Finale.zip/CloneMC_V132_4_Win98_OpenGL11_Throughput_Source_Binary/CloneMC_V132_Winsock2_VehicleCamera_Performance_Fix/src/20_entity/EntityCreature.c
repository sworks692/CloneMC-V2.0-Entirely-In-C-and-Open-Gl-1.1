/*
 * CloneMC Java port scaffold: EntityCreature
 *
 * Java source: EntityCreature.java
 * Java type: class EntityCreature
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityLiving
 * Implements: (none declared)
 * Source SHA-256: 8ddd374aab994cca9ca9dadf63bced0ee0103c16546b3ee27be8c7452c45e832
 * Java lines: 213
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: EntityLiving, World, Entity, AxisAlignedBB, MathHelper, PathEntity, Vec3D, playerToAttack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private PathEntity pathToEntity
 * - protected Entity playerToAttack
 * - protected boolean hasAttacked
 *
 * Java method/constructor inventory:
 * - public EntityCreature(World world)
 * - protected boolean isMovementCeased()
 * - protected void updatePlayerActionState()
 * - protected void func_31026_E()
 * - protected void attackEntity(Entity entity, float f)
 * - protected void attackBlockedEntity(Entity entity, float f)
 * - protected float getBlockPathWeight(int i, int j, int k)
 * - protected Entity findPlayerToAttack()
 * - public boolean getCanSpawnHere()
 * - public boolean hasPath()
 * - public void setPathToEntity(PathEntity pathentity)
 * - public Entity getTarget()
 * - public void setTarget(Entity entity)
 *
 * This class now owns target-path creation over the bounded Java PathEntity.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_EntityCreature_CreatePathToPlayer(CloneMCJ_Mob *creature,
    const CloneMCJ_EntityPlayer *player,float range)
{
    if(!creature||!player||!creature->entity.worldObj)return 0;
    creature->hasPath=(unsigned char)CloneMCJ_Pathfinder_CreatePath(creature->entity.worldObj,
        &creature->entity,player->entity.posX,player->entity.boundingBox.minY,
        player->entity.posZ,range,&creature->path);return creature->hasPath;
}

void CloneMCJ_EntityCreature_Register(void)
{
    /* Creature path state is initialized with each bounded mob. */
}

const char *CloneMCJ_EntityCreature_JavaName(void)
{
    return "net.minecraft.src.EntityCreature";
}

const char *CloneMCJ_EntityCreature_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityCreature_JavaSourceHash32(void)
{
    return 0x8DDD374AUL;
}
