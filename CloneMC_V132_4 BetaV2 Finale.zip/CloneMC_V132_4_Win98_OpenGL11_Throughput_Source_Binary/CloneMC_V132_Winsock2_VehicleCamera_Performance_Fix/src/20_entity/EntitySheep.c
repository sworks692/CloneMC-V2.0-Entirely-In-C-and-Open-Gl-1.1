/*
 * CloneMC Java port scaffold: EntitySheep
 *
 * Java source: EntitySheep.java
 * Java type: class EntitySheep
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityAnimal
 * Implements: (none declared)
 * Source SHA-256: ce4119f8751e734cd0070c005aaae43b974941c8bec2fc2038e6fd9e57e89ca2
 * Java lines: 187
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 16
 * Referenced Java classes: EntityAnimal, DataWatcher, ItemStack, Block, EntityPlayer, InventoryPlayer, Item, ItemShears, World, EntityItem, NBTTagCompound, Entity, s
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntitySheep(World world)
 * - protected void entityInit()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - protected void dropFewItems()
 * - protected int getDropItemId()
 * - public boolean interact(EntityPlayer entityplayer)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - public int getFleeceColor()
 * - public void setFleeceColor(int i)
 * - public boolean getSheared()
 * - public void setSheared(boolean flag)
 * - public static int getRandomFleeceColor(Random random)
 *
 * Direct conversion: the exact Java fleece-color random distribution and the
 * shears interaction, 2-4 colored-wool drops and durability cost are native.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_EntitySheep_RandomFleeceColor(CloneMCJavaRandom *random)
{
    int value;
    if(!random)return 0;
    value=CloneMCJavaRandom_NextIntBound(random,100);
    if(value<5)return 15;
    if(value<10)return 7;
    if(value<15)return 8;
    if(value<18)return 12;
    return CloneMCJavaRandom_NextIntBound(random,500)!=0?0:6;
}

int CloneMCJ_EntitySheep_InteractNative(CloneMCJ_GameplayState *state,
    CloneMCJ_Mob *sheep,CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_ItemStack *held;
    int count,index,color;
    if(!state||!sheep||sheep->type!=CLONEMC_J_MOB_SHEEP||!player)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&player->inventory);
    /* ItemDye.saddleEntity runs for entity-target use before the sheep's own
     * shears interaction.  Dye damage is inverted to BlockCloth metadata. */
    if(held&&held->itemID==351&&held->stackSize>0){
        color=CloneMCJ_BlockCloth_DyeToBlockMetadataNative(
            held->itemDamage&15);
        if(!sheep->sheared&&(sheep->woolColor&15)!=color){
            sheep->woolColor=color;
            if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
            player->inventory.inventoryChanged=1;
        }
        return 1;
    }
    if(sheep->sheared||!held||held->itemID!=359||held->stackSize<=0)return 0;
    sheep->sheared=1;count=2+CloneMCJavaRandom_NextIntBound(&sheep->entity.rand,3);
    for(index=0;index<count;++index){
        CloneMCJ_ItemStack wool;
        CloneMCJ_ItemStack_Initialize(&wool,35,1,sheep->woolColor&15);
        CloneMCJ_Gameplay_SpawnDrop(state,sheep->entity.posX,sheep->entity.posY+1.0,
            sheep->entity.posZ,&wool,10,0);
    }
    CloneMCJ_ItemStack_Damage(held,1);
    return 0;
}

void CloneMCJ_EntitySheep_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntitySheep_JavaName(void)
{
    return "net.minecraft.src.EntitySheep";
}

const char *CloneMCJ_EntitySheep_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntitySheep_JavaSourceHash32(void)
{
    return 0xCE4119F8UL;
}
