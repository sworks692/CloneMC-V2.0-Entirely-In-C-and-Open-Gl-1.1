/*
 * CloneMC Java port scaffold: EntityFireball
 *
 * Java source: EntityFireball.java
 * Java type: class EntityFireball
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 9d6efbc251e217997c4e2b13353191e669bb7ea33f9d8185ae3fc46541580dc7
 * Java lines: 270
 * Discovered declared fields: 12
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: Entity, AxisAlignedBB, MathHelper, EntityLiving, World, Vec3D, MovingObjectPosition, NBTTagCompound, d1, d2, rotationYaw, entityliving.posY, entityliving.posZ, entityliving.rotat
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_9402_e
 * - private int field_9401_f
 * - private int field_9400_g
 * - private int field_9399_h
 * - private boolean field_9398_i
 * - public int field_9406_a
 * - public EntityLiving field_9397_j
 * - private int field_9396_k
 * - private int field_9395_l
 * - public double field_9405_b
 * - public double field_9404_c
 * - public double field_9403_d
 *
 * Java method/constructor inventory:
 * - public EntityFireball(World world)
 * - protected void entityInit()
 * - public boolean isInRangeToRenderDist(double d)
 * - public EntityFireball(World world, EntityLiving entityliving, double d, double d1, double d2)
 * - public void onUpdate()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public boolean canBeCollidedWith()
 * - public float getCollisionBorderSize()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public float getShadowSize()
 *
 * This class owns the typed Java constructor/acceleration adapter; collision,
 * explosion and persistence are shared by the bounded projectile runtime.
 */
#include "clonemc_java_port_20_entity.h"
#include <math.h>

void CloneMCJ_EntityFireball_InitializeNative(CloneMCJ_Projectile *fireball,
    struct CloneMCJ_WorldTag *world,const CloneMCJ_Entity *owner,double x,double y,double z)
{
    double length;CloneMCJ_Projectile_Initialize(fireball,CLONEMC_J_PROJECTILE_FIREBALL,world,owner,1.0F,0.0F);
    length=sqrt(x*x+y*y+z*z);if(length<0.001)length=0.001;
    fireball->accelerationX=x/length*0.1;fireball->accelerationY=y/length*0.1;
    fireball->accelerationZ=z/length*0.1;CloneMCJ_Projectile_SetHeading(fireball,x,y,z,1.0F,0.0F);
}

void CloneMCJ_EntityFireball_Register(void)
{
    /* Runtime dispatch is installed through the bounded projectile table. */
}

const char *CloneMCJ_EntityFireball_JavaName(void)
{
    return "net.minecraft.src.EntityFireball";
}

const char *CloneMCJ_EntityFireball_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityFireball_JavaSourceHash32(void)
{
    return 0x9D6EFBC2UL;
}
