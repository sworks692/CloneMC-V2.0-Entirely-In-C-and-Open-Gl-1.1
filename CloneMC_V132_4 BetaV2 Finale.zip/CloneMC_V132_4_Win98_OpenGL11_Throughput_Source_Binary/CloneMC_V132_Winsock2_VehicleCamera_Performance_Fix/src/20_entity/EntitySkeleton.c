/*
 * CloneMC Java port scaffold: EntitySkeleton
 *
 * Java source: EntitySkeleton.java
 * Java type: class EntitySkeleton
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityMob
 * Implements: (none declared)
 * Source SHA-256: 7bbf9c2c78667c9a71374b023230002758618fb8252b6d49d60ccedfbaad973e
 * Java lines: 115
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: EntityMob, World, MathHelper, Entity, EntityArrow, Item, ItemStack, NBTTagCompound, d1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static final ItemStack defaultHeldItem
 *
 * Java method/constructor inventory:
 * - public EntitySkeleton(World world)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - public void onLivingUpdate()
 * - protected void attackEntity(Entity entity, float f)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected int getDropItemId()
 * - protected void dropFewItems()
 * - public ItemStack getHeldItem()
 *
 * This class now owns typed construction; daylight ignition, 30-tick ranged
 * cadence, arrow aim and drops run through the shared mob/projectile runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntitySkeleton_InitializeNative(CloneMCJ_Mob *skeleton,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(skeleton,CLONEMC_J_MOB_SKELETON,world,x,y,z);
}

void CloneMCJ_EntitySkeleton_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntitySkeleton_JavaName(void)
{
    return "net.minecraft.src.EntitySkeleton";
}

const char *CloneMCJ_EntitySkeleton_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntitySkeleton_JavaSourceHash32(void)
{
    return 0x7BBF9C2CUL;
}
