/*
 * CloneMC Java port scaffold: EntityPig
 *
 * Java source: EntityPig.java
 * Java type: class EntityPig
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityAnimal
 * Implements: (none declared)
 * Source SHA-256: 4edd609f467f4e667aa78ebbd39527d21f3731e110480689d1f1b67f93b3f45e
 * Java lines: 118
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: EntityAnimal, DataWatcher, NBTTagCompound, World, EntityPlayer, Item, EntityPigZombie, AchievementList, EntityLightningBolt
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityPig(World world)
 * - protected void entityInit()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - public boolean interact(EntityPlayer entityplayer)
 * - protected int getDropItemId()
 * - public boolean getSaddled()
 * - public void setSaddled(boolean flag)
 * - public void onStruckByLightning(EntityLightningBolt entitylightningbolt)
 * - protected void fall(float f)
 *
 * Direct conversion: saddle state, ItemSaddle application, player mount and
 * dismount behavior are connected to the native entity interaction path.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_EntityPig_IsSaddledNative(const CloneMCJ_Mob *pig)
{
    return pig&&pig->type==CLONEMC_J_MOB_PIG&&pig->saddled;
}

int CloneMCJ_EntityPig_InteractNative(CloneMCJ_Mob *pig,CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_ItemStack *held;
    if(!pig||pig->type!=CLONEMC_J_MOB_PIG||!player)return 0;
    if(pig->saddled){
        if(player->ridingEntityId==pig->entity.entityId){
            player->ridingEntityId=0;pig->riderEntityId=0;
            player->entity.entityRiderYawDelta=0.0;
            player->entity.entityRiderPitchDelta=0.0;
            CloneMCJ_Entity_SetPosition(&player->entity,pig->entity.posX+1.0,
                pig->entity.posY,pig->entity.posZ);
            return 1;
        }
        if(pig->riderEntityId!=0)return 0;
        player->ridingEntityId=pig->entity.entityId;
        player->entity.entityRiderYawDelta=0.0;
        player->entity.entityRiderPitchDelta=0.0;
        pig->riderEntityId=player->entity.entityId;
        CloneMCJ_Entity_SetPosition(&player->entity,pig->entity.posX,
            pig->entity.posY+(double)pig->entity.height,pig->entity.posZ);
        return 1;
    }
    held=CloneMCJ_InventoryPlayer_GetCurrent(&player->inventory);
    if(!CloneMCJ_ItemSaddle_UseOnMob(held,pig))return 0;
    player->inventory.inventoryChanged=1;
    return 1;
}

void CloneMCJ_EntityPig_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityPig_JavaName(void)
{
    return "net.minecraft.src.EntityPig";
}

const char *CloneMCJ_EntityPig_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityPig_JavaSourceHash32(void)
{
    return 0x4EDD609FUL;
}
