/*
 * CloneMC Java port scaffold: EntityBoat
 *
 * Java source: EntityBoat.java
 * Java type: class EntityBoat
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 2d0e9486292a67ece9b2e23a460e3d95a9c8f663b927c53de56520d092d17409
 * Java lines: 384
 * Discovered declared fields: 12
 * Discovered declared methods/constructors: 18
 * Referenced Java classes: Entity, World, Block, Item, AxisAlignedBB, Material, MathHelper, EntityPlayer, NBTTagCompound
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int boatCurrentDamage
 * - public int boatTimeSinceHit
 * - public int boatRockDirection
 * - private int field_9394_d
 * - private double field_9393_e
 * - private double field_9392_f
 * - private double field_9391_g
 * - private double field_9390_h
 * - private double field_9389_i
 * - private double field_9388_j
 * - private double field_9387_k
 * - private double field_9386_l
 *
 * Java method/constructor inventory:
 * - public EntityBoat(World world)
 * - protected boolean canTriggerWalking()
 * - protected void entityInit()
 * - public AxisAlignedBB getCollisionBox(Entity entity)
 * - public AxisAlignedBB getBoundingBox()
 * - public boolean canBePushed()
 * - public EntityBoat(World world, double d, double d1, double d2)
 * - public double getMountedYOffset()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public void performHurtAnimation()
 * - public boolean canBeCollidedWith()
 * - public void setVelocity(double d, double d1, double d2)
 * - public void onUpdate()
 * - public void updateRiderPosition()
 * - protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public float getShadowSize()
 * - public boolean interact(EntityPlayer entityplayer)
 *
 * This class now owns the bounded shared vehicle runtime: boat buoyancy,
 * minecart rails/subtypes, TNT/falling blocks, paintings, lightning and NBT.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>
#include <string.h>

static const int g_CloneMCJ_RailMatrix[10][2][3]={
    {{0,0,-1},{0,0,1}},{{-1,0,0},{1,0,0}},{{-1,-1,0},{1,0,0}},
    {{-1,0,0},{1,-1,0}},{{0,0,-1},{0,-1,1}},{{0,-1,-1},{0,0,1}},
    {{0,0,1},{1,0,0}},{{0,0,1},{-1,0,0}},{{0,0,-1},{-1,0,0}},
    {{0,0,-1},{1,0,0}}
};

static const char *CloneMCJ_Vehicle_Name(CloneMCJ_VehicleType type)
{
    if(type==CLONEMC_J_VEHICLE_BOAT)return "Boat";
    if(type==CLONEMC_J_VEHICLE_MINECART)return "Minecart";
    if(type==CLONEMC_J_VEHICLE_PRIMED_TNT)return "PrimedTnt";
    if(type==CLONEMC_J_VEHICLE_FALLING_BLOCK)return "FallingSand";
    if(type==CLONEMC_J_VEHICLE_PAINTING)return "Painting";
    return "LightningBolt";
}

void CloneMCJ_Vehicle_Initialize(CloneMCJ_Vehicle *vehicle,CloneMCJ_VehicleType type,
    CloneMCJ_World *world,double x,double y,double z,int data)
{
    float angle;
    int i;
    if(!vehicle)return;
    memset(vehicle,0,sizeof(*vehicle));CloneMCJ_Entity_Initialize(&vehicle->entity,world);
    vehicle->type=type;vehicle->active=1;vehicle->rockDirection=1;vehicle->dropContentsWhenDead=1;
    for(i=0;i<27;++i)CloneMCJ_ItemStack_Clear(&vehicle->cargo[i]);
    if(type==CLONEMC_J_VEHICLE_BOAT)CloneMCJ_Entity_SetSize(&vehicle->entity,1.5F,0.6F);
    else if(type==CLONEMC_J_VEHICLE_MINECART){
        CloneMCJ_Entity_SetSize(&vehicle->entity,0.98F,0.7F);
        vehicle->entity.yOffset=vehicle->entity.height/2.0F;
        vehicle->minecartType=data;
    }
    else if(type==CLONEMC_J_VEHICLE_PRIMED_TNT){CloneMCJ_Entity_SetSize(&vehicle->entity,0.98F,0.98F);vehicle->fuse=80;
        angle=CloneMCJavaRandom_NextFloat(&vehicle->entity.rand)*6.283185307F;vehicle->entity.motionX=-(double)sin(angle)*0.02;
        vehicle->entity.motionY=0.2;vehicle->entity.motionZ=-(double)cos(angle)*0.02;}
    else if(type==CLONEMC_J_VEHICLE_FALLING_BLOCK){CloneMCJ_Entity_SetSize(&vehicle->entity,0.98F,0.98F);vehicle->blockID=data&255;}
    else if(type==CLONEMC_J_VEHICLE_LIGHTNING){vehicle->lightningState=2;vehicle->boltLivingTime=CloneMCJavaRandom_NextIntBound(&vehicle->entity.rand,3)+1;}
    else{CloneMCJ_Entity_SetSize(&vehicle->entity,0.5F,0.5F);strcpy(vehicle->art,"Kebab");}
    CloneMCJ_Entity_SetPosition(&vehicle->entity,x,
        type==CLONEMC_J_VEHICLE_MINECART?y+(double)vehicle->entity.yOffset:y,z);
}

static void CloneMCJ_Vehicle_Drop(CloneMCJ_GameplayState *state,CloneMCJ_Vehicle *vehicle,
    int itemID,int count,int damage)
{
    CloneMCJ_ItemStack stack;int i;
    if(!state)return;
    for(i=0;i<count;++i){CloneMCJ_ItemStack_Initialize(&stack,itemID,1,damage);
        CloneMCJ_Gameplay_SpawnDrop(state,vehicle->entity.posX,vehicle->entity.posY,
            vehicle->entity.posZ,&stack,10,0);}
}

static void CloneMCJ_Vehicle_Explode(CloneMCJ_Vehicle *vehicle,CloneMCJ_GameplayState *state,float radius)
{
    CloneMCJ_World *world;CloneMCJ_Mob *mob;
    int x,y,z,cx,cy,cz,i,damage;double dx,dy,dz,distance;
    world=vehicle->entity.worldObj;if(!world)return;cx=CloneMCJava_FloorDouble(vehicle->entity.posX);
    cy=CloneMCJava_FloorDouble(vehicle->entity.posY);cz=CloneMCJava_FloorDouble(vehicle->entity.posZ);
    for(x=cx-(int)radius;x<=cx+(int)radius;++x)for(y=cy-(int)radius;y<=cy+(int)radius;++y)
        for(z=cz-(int)radius;z<=cz+(int)radius;++z){dx=(double)x-vehicle->entity.posX;
            dy=(double)y-vehicle->entity.posY;dz=(double)z-vehicle->entity.posZ;
            if(dx*dx+dy*dy+dz*dz<=(double)radius*(double)radius&&CloneMCJ_World_GetBlockId(world,x,y,z)!=7)
                CloneMCJ_World_SetBlockNotify(world,x,y,z,0);}
    if(!state)return;
    dx=state->player.entity.posX-vehicle->entity.posX;dy=state->player.entity.posY-vehicle->entity.posY;
    dz=state->player.entity.posZ-vehicle->entity.posZ;distance=sqrt(dx*dx+dy*dy+dz*dz);
    if(distance<(double)radius*2.0){damage=(int)(((double)radius*2.0-distance)*4.0);
        if(damage>0)CloneMCJ_EntityPlayer_AttackFrom(&state->player,&vehicle->entity,damage);}
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i){mob=&state->mobs[i];if(!mob->active)continue;
        dx=mob->entity.posX-vehicle->entity.posX;dy=mob->entity.posY-vehicle->entity.posY;dz=mob->entity.posZ-vehicle->entity.posZ;
        distance=sqrt(dx*dx+dy*dy+dz*dz);if(distance<(double)radius*2.0){damage=(int)(((double)radius*2.0-distance)*4.0);
            CloneMCJ_EntityLiving_AttackMobFrom(mob,&vehicle->entity,damage);}}
}

int CloneMCJ_Vehicle_Attack(CloneMCJ_Vehicle *vehicle,CloneMCJ_GameplayState *state,int damage)
{
    int i;
    if(!vehicle||!vehicle->active||damage<=0)return 0;
    vehicle->rockDirection=-vehicle->rockDirection;
    vehicle->timeSinceHit=10;vehicle->damageTaken+=damage*10;
    if(vehicle->damageTaken<=40)return 1;
    if(vehicle->type==CLONEMC_J_VEHICLE_BOAT){CloneMCJ_Vehicle_Drop(state,vehicle,5,3,0);CloneMCJ_Vehicle_Drop(state,vehicle,280,2,0);}
    else if(vehicle->type==CLONEMC_J_VEHICLE_MINECART){CloneMCJ_Vehicle_Drop(state,vehicle,328,1,0);
        if(vehicle->minecartType==1)CloneMCJ_Vehicle_Drop(state,vehicle,54,1,0);else if(vehicle->minecartType==2)CloneMCJ_Vehicle_Drop(state,vehicle,61,1,0);
        for(i=0;i<27;++i)if(!CloneMCJ_ItemStack_IsEmpty(&vehicle->cargo[i]))CloneMCJ_Gameplay_SpawnDrop(state,
            vehicle->entity.posX,vehicle->entity.posY,vehicle->entity.posZ,&vehicle->cargo[i],10,0);}
    vehicle->active=0;
    if(state&&state->player.ridingEntityId==vehicle->entity.entityId){
        state->player.ridingEntityId=0;
        state->player.entity.entityRiderYawDelta=0.0;
        state->player.entity.entityRiderPitchDelta=0.0;
    }
    return 1;
}

void CloneMCJ_Vehicle_ApplyCollision(CloneMCJ_Vehicle *first,CloneMCJ_Vehicle *second)
{
    double dx,dz,distance,impulse,averageX,averageZ;
    if(!first||!second||first==second||!first->active||!second->active)return;
    if((first->type!=CLONEMC_J_VEHICLE_BOAT&&first->type!=CLONEMC_J_VEHICLE_MINECART)||
       (second->type!=CLONEMC_J_VEHICLE_BOAT&&second->type!=CLONEMC_J_VEHICLE_MINECART))return;
    dx=second->entity.posX-first->entity.posX;dz=second->entity.posZ-first->entity.posZ;
    distance=sqrt(dx*dx+dz*dz);if(distance<0.0001||distance>1.8)return;
    dx/=distance;dz/=distance;impulse=(1.0-distance/1.8)*0.1;if(impulse<0.0)impulse=0.0;
    if(first->type==CLONEMC_J_VEHICLE_MINECART&&second->type==CLONEMC_J_VEHICLE_MINECART){
        if(first->minecartType==2&&second->minecartType!=2){
            second->entity.motionX=first->entity.motionX*0.8+dx*impulse;
            second->entity.motionZ=first->entity.motionZ*0.8+dz*impulse;
            first->entity.motionX*=0.7;first->entity.motionZ*=0.7;
        }else if(second->minecartType==2&&first->minecartType!=2){
            first->entity.motionX=second->entity.motionX*0.8-dx*impulse;
            first->entity.motionZ=second->entity.motionZ*0.8-dz*impulse;
            second->entity.motionX*=0.7;second->entity.motionZ*=0.7;
        }else{
            averageX=(first->entity.motionX+second->entity.motionX)*0.5;
            averageZ=(first->entity.motionZ+second->entity.motionZ)*0.5;
            first->entity.motionX=averageX-dx*impulse;first->entity.motionZ=averageZ-dz*impulse;
            second->entity.motionX=averageX+dx*impulse;second->entity.motionZ=averageZ+dz*impulse;
        }
    }else{
        first->entity.motionX-=dx*impulse;first->entity.motionZ-=dz*impulse;
        second->entity.motionX+=dx*impulse;second->entity.motionZ+=dz*impulse;
    }
}

static int CloneMCJ_Vehicle_PaintingFits(CloneMCJ_Vehicle *vehicle,
    const CloneMCJ_ArtDefinition *art,int direction,int tileX,int tileY,int tileZ)
{
    CloneMCJ_World *world;int width,height,ax,ay,frontX,frontZ,supportX,supportZ;
    const CloneMCJ_BlockDefinition *block;
    if(!vehicle||!art||direction<0||direction>3)return 0;
    world=vehicle->entity.worldObj;if(!world)return 0;width=art->sizeX/16;height=art->sizeY/16;
    for(ax=0;ax<width;++ax)for(ay=0;ay<height;++ay){
        frontX=tileX;frontZ=tileZ;supportX=tileX;supportZ=tileZ;
        if(direction==0){++supportZ;frontX+=ax-width/2;supportX=frontX;}
        else if(direction==2){--supportZ;frontX+=ax-width/2;supportX=frontX;}
        else if(direction==1){++supportX;frontZ+=ax-width/2;supportZ=frontZ;}
        else{--supportX;frontZ+=ax-width/2;supportZ=frontZ;}
        if(CloneMCJ_World_GetBlockId(world,frontX,tileY+ay-height/2,frontZ)!=0)return 0;
        block=CloneMCJ_BlockRegistry_Get(CloneMCJ_World_GetBlockId(world,supportX,
            tileY+ay-height/2,supportZ));if(!block||!block->solid)return 0;
    }
    return 1;
}

int CloneMCJ_Vehicle_ConfigurePainting(CloneMCJ_Vehicle *vehicle,int direction,
    int tileX,int tileY,int tileZ)
{
    int count,index,candidateCount,candidates[32];const CloneMCJ_ArtDefinition *art;
    if(!vehicle||vehicle->type!=CLONEMC_J_VEHICLE_PAINTING||!vehicle->active)return 0;
    candidateCount=0;count=CloneMCJ_EnumArt_Count();if(count>32)count=32;
    for(index=0;index<count;++index){art=CloneMCJ_EnumArt_At(index);
        if(CloneMCJ_Vehicle_PaintingFits(vehicle,art,direction,tileX,tileY,tileZ))
            candidates[candidateCount++]=index;}
    if(candidateCount<=0)return 0;
    index=candidates[CloneMCJavaRandom_NextIntBound(&vehicle->entity.rand,candidateCount)];
    art=CloneMCJ_EnumArt_At(index);strncpy(vehicle->art,art->title,sizeof(vehicle->art)-1U);
    vehicle->art[sizeof(vehicle->art)-1U]='\0';vehicle->direction=direction;
    vehicle->tileX=tileX;vehicle->tileY=tileY;vehicle->tileZ=tileZ;return 1;
}

static double CloneMCJ_Vehicle_WaterFraction(CloneMCJ_Vehicle *vehicle)
{
    CloneMCJ_World *world;int i,y,id,wet;world=vehicle->entity.worldObj;if(!world)return 0.0;wet=0;
    for(i=0;i<5;++i){y=CloneMCJava_FloorDouble(vehicle->entity.boundingBox.minY+
        (vehicle->entity.boundingBox.maxY-vehicle->entity.boundingBox.minY)*(double)i/5.0-0.125);
        id=CloneMCJ_World_GetBlockId(world,CloneMCJava_FloorDouble(vehicle->entity.posX),y,
            CloneMCJava_FloorDouble(vehicle->entity.posZ));if(id==8||id==9)++wet;}
    return (double)wet/5.0;
}

static void CloneMCJ_Vehicle_TickBoat(CloneMCJ_Vehicle *vehicle,CloneMCJ_GameplayState *state)
{
    double water,vertical,speed,limit,desiredYaw,yawDelta;CloneMCJ_EntityPlayer *player;
    int corner,x,y,z;
    water=CloneMCJ_Vehicle_WaterFraction(vehicle);vertical=water*2.0-1.0;
    if(water<1.0)vehicle->entity.motionY+=0.04*vertical;
    else{if(vehicle->entity.motionY<0.0)vehicle->entity.motionY*=0.5;vehicle->entity.motionY+=0.007;}
    player=state&&state->player.ridingEntityId==vehicle->entity.entityId?&state->player:(CloneMCJ_EntityPlayer *)0;
    if(player){vehicle->entity.motionX+=player->entity.motionX*0.2;vehicle->entity.motionZ+=player->entity.motionZ*0.2;
        if(player->movementInput.moveForward!=0.0F){vehicle->entity.motionX+=-(double)sin(player->entity.rotationYaw*0.0174532925199433F)*0.04*player->movementInput.moveForward;
            vehicle->entity.motionZ+=(double)cos(player->entity.rotationYaw*0.0174532925199433F)*0.04*player->movementInput.moveForward;}}
    limit=0.4;if(vehicle->entity.motionX<-limit)vehicle->entity.motionX=-limit;if(vehicle->entity.motionX>limit)vehicle->entity.motionX=limit;
    if(vehicle->entity.motionZ<-limit)vehicle->entity.motionZ=-limit;
    if(vehicle->entity.motionZ>limit)vehicle->entity.motionZ=limit;
    CloneMCJ_Entity_Move(&vehicle->entity,vehicle->entity.motionX,vehicle->entity.motionY,vehicle->entity.motionZ);
    if(vehicle->entity.onGround){vehicle->entity.motionX*=0.5;vehicle->entity.motionY*=0.5;vehicle->entity.motionZ*=0.5;}
    speed=sqrt(vehicle->entity.motionX*vehicle->entity.motionX+vehicle->entity.motionZ*vehicle->entity.motionZ);
    if(vehicle->entity.collidedHorizontally&&speed>0.15){CloneMCJ_Vehicle_Attack(vehicle,state,5);return;}
    if(speed>0.001){desiredYaw=atan2(vehicle->entity.prevPosZ-vehicle->entity.posZ,
            vehicle->entity.prevPosX-vehicle->entity.posX)*180.0/3.14159265358979323846;
        yawDelta=desiredYaw-(double)vehicle->entity.rotationYaw;
        while(yawDelta>=180.0)yawDelta-=360.0;
        while(yawDelta<-180.0)yawDelta+=360.0;
        if(yawDelta>20.0)yawDelta=20.0;
        if(yawDelta<-20.0)yawDelta=-20.0;
        vehicle->entity.rotationYaw+=(float)yawDelta;}
    for(corner=0;corner<4;++corner){x=CloneMCJava_FloorDouble(vehicle->entity.posX+
            ((double)(corner%2)-0.5)*0.8);y=CloneMCJava_FloorDouble(vehicle->entity.posY);
        z=CloneMCJava_FloorDouble(vehicle->entity.posZ+((double)(corner/2)-0.5)*0.8);
        if(CloneMCJ_World_GetBlockId(vehicle->entity.worldObj,x,y,z)==78)
            CloneMCJ_World_SetBlockNotify(vehicle->entity.worldObj,x,y,z,0);}
    vehicle->entity.motionX*=0.99;vehicle->entity.motionY*=0.95;vehicle->entity.motionZ*=0.99;
}

static int CloneMCJ_Vehicle_IsRail(int id)
{
    return id==66||id==27||id==28;
}

static int CloneMCJ_Vehicle_IsNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return id!=0&&block&&block->solid&&block->opaque;
}

int CloneMCJ_EntityMinecart_RailPositionNative(CloneMCJ_World *world,
    double px,double py,
    double pz,CloneMCVec3D *result)
{
    int x,y,z,id,metadata,index;const int (*matrix)[3];
    double factor,startX,startY,startZ,endX,endY,endZ,deltaX,deltaY,deltaZ;
    if(!world||!result)return 0;
    x=CloneMCJava_FloorDouble(px);y=CloneMCJava_FloorDouble(py);
    z=CloneMCJava_FloorDouble(pz);
    id=CloneMCJ_World_GetBlockId(world,x,y-1,z);
    if(CloneMCJ_Vehicle_IsRail(id))--y;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(!CloneMCJ_Vehicle_IsRail(id))return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    index=(id==27||id==28)?metadata&7:metadata;
    if(index<0||index>9)index=0;
    matrix=g_CloneMCJ_RailMatrix[index];
    startX=(double)x+0.5+(double)matrix[0][0]*0.5;
    startY=(double)y+0.5+(double)matrix[0][1]*0.5;
    startZ=(double)z+0.5+(double)matrix[0][2]*0.5;
    endX=(double)x+0.5+(double)matrix[1][0]*0.5;
    endY=(double)y+0.5+(double)matrix[1][1]*0.5;
    endZ=(double)z+0.5+(double)matrix[1][2]*0.5;
    deltaX=endX-startX;deltaY=(endY-startY)*2.0;deltaZ=endZ-startZ;
    if(deltaX==0.0){px=(double)x+0.5;factor=pz-(double)z;}
    else if(deltaZ==0.0){pz=(double)z+0.5;factor=px-(double)x;}
    else factor=((px-startX)*deltaX+(pz-startZ)*deltaZ)*2.0;
    result->xCoord=startX+deltaX*factor;
    result->yCoord=startY+deltaY*factor;
    result->zCoord=startZ+deltaZ*factor;
    if(deltaY<0.0)result->yCoord+=1.0;
    if(deltaY>0.0)result->yCoord+=0.5;
    return 1;
}

int CloneMCJ_EntityMinecart_RailPositionOffsetNative(CloneMCJ_World *world,
    double px,double py,double pz,double offset,CloneMCVec3D *result)
{
    int x,y,z,id,metadata,index;
    const int (*matrix)[3];
    double dx,dz,length;
    if(!world||!result)return 0;
    x=CloneMCJava_FloorDouble(px);y=CloneMCJava_FloorDouble(py);
    z=CloneMCJava_FloorDouble(pz);
    id=CloneMCJ_World_GetBlockId(world,x,y-1,z);
    if(CloneMCJ_Vehicle_IsRail(id))--y;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(!CloneMCJ_Vehicle_IsRail(id))return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    index=(id==27||id==28)?metadata&7:metadata;
    if(index<0||index>9)index=0;
    matrix=g_CloneMCJ_RailMatrix[index];
    py=(double)y;
    if(index>=2&&index<=5)py=(double)y+1.0;
    dx=(double)(matrix[1][0]-matrix[0][0]);
    dz=(double)(matrix[1][2]-matrix[0][2]);
    length=sqrt(dx*dx+dz*dz);
    if(length<=0.0)return 0;
    px+=dx/length*offset;pz+=dz/length*offset;
    if(matrix[0][1]!=0&&CloneMCJava_FloorDouble(px)-x==matrix[0][0]&&
       CloneMCJava_FloorDouble(pz)-z==matrix[0][2])
        py+=(double)matrix[0][1];
    else if(matrix[1][1]!=0&&CloneMCJava_FloorDouble(px)-x==matrix[1][0]&&
       CloneMCJava_FloorDouble(pz)-z==matrix[1][2])
        py+=(double)matrix[1][1];
    return CloneMCJ_EntityMinecart_RailPositionNative(world,px,py,pz,result);
}

static void CloneMCJ_Vehicle_TickMinecart(CloneMCJ_Vehicle *vehicle,CloneMCJ_GameplayState *state)
{
    CloneMCJ_World *world;CloneMCVec3D beforeRail,afterRail;
    const int (*matrix)[3];
    int x,y,z,id,metadata,index,powered,braking,newX,newZ;
    double dx,dz,directionLength,speed,limit,pushLength,moveX,moveZ;
    double startX,startZ,endX,endZ,factor,heightDelta,yawDelta;
    world=vehicle->entity.worldObj;if(!world)return;
    vehicle->entity.motionY-=0.0399999991;
    x=CloneMCJava_FloorDouble(vehicle->entity.posX);
    y=CloneMCJava_FloorDouble(vehicle->entity.posY);
    z=CloneMCJava_FloorDouble(vehicle->entity.posZ);
    id=CloneMCJ_World_GetBlockId(world,x,y-1,z);
    if(CloneMCJ_Vehicle_IsRail(id))--y;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(CloneMCJ_Vehicle_IsRail(id)){
        beforeRail.xCoord=vehicle->entity.posX;beforeRail.yCoord=vehicle->entity.posY;
        beforeRail.zCoord=vehicle->entity.posZ;
        (void)CloneMCJ_EntityMinecart_RailPositionNative(world,vehicle->entity.posX,
            vehicle->entity.posY,vehicle->entity.posZ,&beforeRail);
        metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
        if(id==28)CloneMCJ_BlockDetectorRail_MinecartCollisionNative(world,x,y,z);
        powered=id==27&&(metadata&8)!=0;braking=id==27&&!powered;
        index=(id==27||id==28)?metadata&7:metadata;
        if(index<0||index>9)index=0;matrix=g_CloneMCJ_RailMatrix[index];
        /* EntityMinecart.onUpdate establishes the rail block's base Y before
         * horizontal projection.  The previous native port snapped through
         * func_514_g before moveEntity, placing the 0.7-high collision box
         * inside the upper support block at slope boundaries. */
        vehicle->entity.posY=(double)y;
        if(index>=2&&index<=5)vehicle->entity.posY=(double)y+1.0;
        if(index==2)vehicle->entity.motionX-=0.0078125;
        else if(index==3)vehicle->entity.motionX+=0.0078125;
        else if(index==4)vehicle->entity.motionZ+=0.0078125;
        else if(index==5)vehicle->entity.motionZ-=0.0078125;
        if(state&&state->player.ridingEntityId==vehicle->entity.entityId&&
           state->player.movementInput.moveForward!=0.0F&&
           vehicle->entity.motionX*vehicle->entity.motionX+
           vehicle->entity.motionZ*vehicle->entity.motionZ<0.0004){
            double riderYaw;
            riderYaw=(double)state->player.entity.rotationYaw*0.0174532925199433;
            vehicle->entity.motionX-=sin(riderYaw)*0.02*
                (double)state->player.movementInput.moveForward;
            vehicle->entity.motionZ+=cos(riderYaw)*0.02*
                (double)state->player.movementInput.moveForward;
        }
        dx=(double)(matrix[1][0]-matrix[0][0]);
        dz=(double)(matrix[1][2]-matrix[0][2]);
        directionLength=sqrt(dx*dx+dz*dz);
        if(directionLength>0.0){
            if(vehicle->entity.motionX*dx+vehicle->entity.motionZ*dz<0.0){
                dx=-dx;dz=-dz;
            }
            speed=sqrt(vehicle->entity.motionX*vehicle->entity.motionX+
                vehicle->entity.motionZ*vehicle->entity.motionZ);
            vehicle->entity.motionX=speed*dx/directionLength;
            vehicle->entity.motionZ=speed*dz/directionLength;
        }
        if(braking){
            speed=sqrt(vehicle->entity.motionX*vehicle->entity.motionX+
                vehicle->entity.motionZ*vehicle->entity.motionZ);
            if(speed<0.03){vehicle->entity.motionX=0.0;vehicle->entity.motionY=0.0;
                vehicle->entity.motionZ=0.0;}
            else{vehicle->entity.motionX*=0.5;vehicle->entity.motionY=0.0;
                vehicle->entity.motionZ*=0.5;}
        }
        startX=(double)x+0.5+(double)matrix[0][0]*0.5;
        startZ=(double)z+0.5+(double)matrix[0][2]*0.5;
        endX=(double)x+0.5+(double)matrix[1][0]*0.5;
        endZ=(double)z+0.5+(double)matrix[1][2]*0.5;
        dx=endX-startX;dz=endZ-startZ;
        if(dx==0.0){vehicle->entity.posX=(double)x+0.5;
            factor=vehicle->entity.posZ-(double)z;}
        else if(dz==0.0){vehicle->entity.posZ=(double)z+0.5;
            factor=vehicle->entity.posX-(double)x;}
        else factor=((vehicle->entity.posX-startX)*dx+
            (vehicle->entity.posZ-startZ)*dz)*2.0;
        vehicle->entity.posX=startX+dx*factor;
        vehicle->entity.posZ=startZ+dz*factor;
        CloneMCJ_Entity_SetPosition(&vehicle->entity,vehicle->entity.posX,
            vehicle->entity.posY+(double)vehicle->entity.yOffset,
            vehicle->entity.posZ);
        limit=0.4;moveX=vehicle->entity.motionX;moveZ=vehicle->entity.motionZ;
        if(vehicle->riderEntityId){moveX*=0.75;moveZ*=0.75;}
        if(moveX>limit)moveX=limit;if(moveX<-limit)moveX=-limit;
        if(moveZ>limit)moveZ=limit;if(moveZ<-limit)moveZ=-limit;
        CloneMCJ_Entity_Move(&vehicle->entity,moveX,0.0,moveZ);
        if(matrix[0][1]!=0&&CloneMCJava_FloorDouble(vehicle->entity.posX)-x==matrix[0][0]&&
           CloneMCJava_FloorDouble(vehicle->entity.posZ)-z==matrix[0][2])
            CloneMCJ_Entity_SetPosition(&vehicle->entity,vehicle->entity.posX,
                vehicle->entity.posY+(double)matrix[0][1],vehicle->entity.posZ);
        else if(matrix[1][1]!=0&&CloneMCJava_FloorDouble(vehicle->entity.posX)-x==matrix[1][0]&&
           CloneMCJava_FloorDouble(vehicle->entity.posZ)-z==matrix[1][2])
            CloneMCJ_Entity_SetPosition(&vehicle->entity,vehicle->entity.posX,
                vehicle->entity.posY+(double)matrix[1][1],vehicle->entity.posZ);
        pushLength=0.0;
        if(vehicle->riderEntityId){vehicle->entity.motionX*=0.996999979;
            vehicle->entity.motionY=0.0;vehicle->entity.motionZ*=0.996999979;}
        else{
            if(vehicle->minecartType==2){
                pushLength=sqrt(vehicle->pushX*vehicle->pushX+vehicle->pushZ*vehicle->pushZ);
                if(vehicle->fuel>0&&pushLength>0.01){
                    vehicle->pushX/=pushLength;vehicle->pushZ/=pushLength;
                    vehicle->entity.motionX=vehicle->entity.motionX*0.800000012+
                        vehicle->pushX*0.04;
                    vehicle->entity.motionZ=vehicle->entity.motionZ*0.800000012+
                        vehicle->pushZ*0.04;
                }else{vehicle->entity.motionX*=0.899999976;
                    vehicle->entity.motionZ*=0.899999976;}
            }
            vehicle->entity.motionX*=0.959999979;vehicle->entity.motionY=0.0;
            vehicle->entity.motionZ*=0.959999979;
        }
        afterRail=beforeRail;
        if(CloneMCJ_EntityMinecart_RailPositionNative(world,vehicle->entity.posX,
            vehicle->entity.posY,vehicle->entity.posZ,&afterRail)){
            heightDelta=(beforeRail.yCoord-afterRail.yCoord)*0.05;
            speed=sqrt(vehicle->entity.motionX*vehicle->entity.motionX+
                vehicle->entity.motionZ*vehicle->entity.motionZ);
            if(speed>0.0){vehicle->entity.motionX=vehicle->entity.motionX/speed*
                    (speed+heightDelta);
                vehicle->entity.motionZ=vehicle->entity.motionZ/speed*
                    (speed+heightDelta);}
            CloneMCJ_Entity_SetPosition(&vehicle->entity,vehicle->entity.posX,
                afterRail.yCoord,vehicle->entity.posZ);
        }
        newX=CloneMCJava_FloorDouble(vehicle->entity.posX);
        newZ=CloneMCJava_FloorDouble(vehicle->entity.posZ);
        if(newX!=x||newZ!=z){
            speed=sqrt(vehicle->entity.motionX*vehicle->entity.motionX+
                vehicle->entity.motionZ*vehicle->entity.motionZ);
            vehicle->entity.motionX=speed*(double)(newX-x);
            vehicle->entity.motionZ=speed*(double)(newZ-z);
        }
        if(vehicle->minecartType==2&&pushLength>0.01&&
           vehicle->entity.motionX*vehicle->entity.motionX+
           vehicle->entity.motionZ*vehicle->entity.motionZ>0.001){
            if(vehicle->pushX*vehicle->entity.motionX+
               vehicle->pushZ*vehicle->entity.motionZ<0.0)
                vehicle->pushX=vehicle->pushZ=0.0;
            else{vehicle->pushX=vehicle->entity.motionX;
                vehicle->pushZ=vehicle->entity.motionZ;}
        }
        if(powered){
            speed=sqrt(vehicle->entity.motionX*vehicle->entity.motionX+
                vehicle->entity.motionZ*vehicle->entity.motionZ);
            if(speed>0.01){vehicle->entity.motionX+=vehicle->entity.motionX/speed*0.06;
                vehicle->entity.motionZ+=vehicle->entity.motionZ/speed*0.06;}
            else if(index==1){
                if(CloneMCJ_Vehicle_IsNormalCube(world,x-1,y,z))
                    vehicle->entity.motionX=0.02;
                else if(CloneMCJ_Vehicle_IsNormalCube(world,x+1,y,z))
                    vehicle->entity.motionX=-0.02;
            }else if(index==0){
                if(CloneMCJ_Vehicle_IsNormalCube(world,x,y,z-1))
                    vehicle->entity.motionZ=0.02;
                else if(CloneMCJ_Vehicle_IsNormalCube(world,x,y,z+1))
                    vehicle->entity.motionZ=-0.02;
            }
        }
        if(vehicle->minecartType==2){
            if(vehicle->fuel>0&&pushLength>0.01&&
               CloneMCJavaRandom_NextIntBound(&vehicle->entity.rand,4)==0)--vehicle->fuel;
            if(vehicle->fuel<=0){vehicle->fuel=0;vehicle->pushX=vehicle->pushZ=0.0;}
        }
    }else{
        limit=0.4;
        if(vehicle->entity.motionX>limit)vehicle->entity.motionX=limit;
        if(vehicle->entity.motionX<-limit)vehicle->entity.motionX=-limit;
        if(vehicle->entity.motionZ>limit)vehicle->entity.motionZ=limit;
        if(vehicle->entity.motionZ<-limit)vehicle->entity.motionZ=-limit;
        if(vehicle->entity.onGround){vehicle->entity.motionX*=0.5;
            vehicle->entity.motionY*=0.5;vehicle->entity.motionZ*=0.5;}
        CloneMCJ_Entity_Move(&vehicle->entity,vehicle->entity.motionX,
            vehicle->entity.motionY,vehicle->entity.motionZ);
        if(!vehicle->entity.onGround){vehicle->entity.motionX*=0.949999988;
            vehicle->entity.motionY*=0.949999988;vehicle->entity.motionZ*=0.949999988;}
    }
    vehicle->entity.rotationPitch=0.0F;
    dx=vehicle->entity.prevPosX-vehicle->entity.posX;
    dz=vehicle->entity.prevPosZ-vehicle->entity.posZ;
    if(dx*dx+dz*dz>0.001){
        vehicle->entity.rotationYaw=(float)(atan2(dz,dx)*180.0/
            3.14159265358979323846);
        if(vehicle->reversedDirection)vehicle->entity.rotationYaw+=180.0F;
    }
    yawDelta=(double)vehicle->entity.rotationYaw-
        (double)vehicle->entity.prevRotationYaw;
    while(yawDelta>=180.0)yawDelta-=360.0;
    while(yawDelta<-180.0)yawDelta+=360.0;
    if(yawDelta<-170.0||yawDelta>=170.0){
        vehicle->entity.rotationYaw+=180.0F;
        vehicle->reversedDirection=(unsigned char)(vehicle->reversedDirection?0:1);
    }
}

void CloneMCJ_Vehicle_Tick(CloneMCJ_Vehicle *vehicle,CloneMCJ_GameplayState *state)
{
    int x,y,z,id,i;CloneMCJ_ItemStack stack;
    if(!vehicle||!vehicle->active)return;
    vehicle->entity.prevPosX=vehicle->entity.posX;vehicle->entity.prevPosY=vehicle->entity.posY;
    vehicle->entity.prevPosZ=vehicle->entity.posZ;vehicle->entity.prevRotationYaw=vehicle->entity.rotationYaw;++vehicle->age;++vehicle->entity.ticksExisted;
    if(vehicle->timeSinceHit>0)--vehicle->timeSinceHit;
    if(vehicle->damageTaken>0)--vehicle->damageTaken;
    if(vehicle->interpolationTicks>0){
        double fraction;float yawDelta;fraction=1.0/(double)vehicle->interpolationTicks;
        vehicle->entity.posX+=(vehicle->targetX-vehicle->entity.posX)*fraction;
        vehicle->entity.posY+=(vehicle->targetY-vehicle->entity.posY)*fraction;
        vehicle->entity.posZ+=(vehicle->targetZ-vehicle->entity.posZ)*fraction;
        yawDelta=vehicle->targetYaw-vehicle->entity.rotationYaw;
        while(yawDelta<-180.0F)yawDelta+=360.0F;while(yawDelta>=180.0F)yawDelta-=360.0F;
        vehicle->entity.rotationYaw+=yawDelta/(float)vehicle->interpolationTicks;
        vehicle->entity.rotationPitch+=(vehicle->targetPitch-vehicle->entity.rotationPitch)/(float)vehicle->interpolationTicks;
        --vehicle->interpolationTicks;CloneMCJ_Entity_SetPosition(&vehicle->entity,vehicle->entity.posX,vehicle->entity.posY,vehicle->entity.posZ);
        return;
    }
    if(vehicle->type==CLONEMC_J_VEHICLE_BOAT)CloneMCJ_Vehicle_TickBoat(vehicle,state);
    else if(vehicle->type==CLONEMC_J_VEHICLE_MINECART)CloneMCJ_Vehicle_TickMinecart(vehicle,state);
    else if(vehicle->type==CLONEMC_J_VEHICLE_PRIMED_TNT){vehicle->entity.motionY-=0.04;CloneMCJ_Entity_Move(&vehicle->entity,vehicle->entity.motionX,vehicle->entity.motionY,vehicle->entity.motionZ);
        vehicle->entity.motionX*=0.98;vehicle->entity.motionY*=0.98;vehicle->entity.motionZ*=0.98;if(vehicle->entity.onGround){vehicle->entity.motionX*=0.7;vehicle->entity.motionZ*=0.7;vehicle->entity.motionY*=-0.5;}
        if(vehicle->fuse--<=0){CloneMCJ_Vehicle_Explode(vehicle,state,4.0F);vehicle->active=0;}}
    else if(vehicle->type==CLONEMC_J_VEHICLE_FALLING_BLOCK){if(vehicle->blockID==0){vehicle->active=0;return;}++vehicle->fuse;vehicle->entity.motionY-=0.04;
        CloneMCJ_Entity_Move(&vehicle->entity,vehicle->entity.motionX,vehicle->entity.motionY,vehicle->entity.motionZ);vehicle->entity.motionX*=0.98;vehicle->entity.motionY*=0.98;vehicle->entity.motionZ*=0.98;
        x=CloneMCJava_FloorDouble(vehicle->entity.posX);y=CloneMCJava_FloorDouble(vehicle->entity.posY);z=CloneMCJava_FloorDouble(vehicle->entity.posZ);
        if(CloneMCJ_World_GetBlockId(vehicle->entity.worldObj,x,y,z)==vehicle->blockID)CloneMCJ_World_SetBlockNotify(vehicle->entity.worldObj,x,y,z,0);
        if(vehicle->entity.onGround||vehicle->fuse>100){vehicle->active=0;id=CloneMCJ_World_GetBlockId(vehicle->entity.worldObj,x,y,z);
            if(id==0&&CloneMCJ_World_GetBlockId(vehicle->entity.worldObj,x,y-1,z)!=0)CloneMCJ_World_SetBlockWithMetadataNotify(vehicle->entity.worldObj,x,y,z,vehicle->blockID,vehicle->blockData);
            else if(state){CloneMCJ_ItemStack_Initialize(&stack,vehicle->blockID,1,vehicle->blockData);CloneMCJ_Gameplay_SpawnDrop(state,vehicle->entity.posX,vehicle->entity.posY,vehicle->entity.posZ,&stack,10,0);}}}
    else if(vehicle->type==CLONEMC_J_VEHICLE_PAINTING&&(vehicle->age%100)==0){
        if(!CloneMCJ_Vehicle_PaintingFits(vehicle,CloneMCJ_EnumArt_Find(vehicle->art),
            vehicle->direction,vehicle->tileX,vehicle->tileY,vehicle->tileZ)){
            if(state){CloneMCJ_ItemStack_Initialize(&stack,321,1,0);
                CloneMCJ_Gameplay_SpawnDrop(state,vehicle->entity.posX,vehicle->entity.posY,vehicle->entity.posZ,&stack,10,0);}
            vehicle->active=0;}}
    else if(vehicle->type==CLONEMC_J_VEHICLE_LIGHTNING){--vehicle->lightningState;if(vehicle->lightningState<0){if(vehicle->boltLivingTime==0)vehicle->active=0;
        else if(vehicle->lightningState<-CloneMCJavaRandom_NextIntBound(&vehicle->entity.rand,10)){--vehicle->boltLivingTime;vehicle->lightningState=1;}}
        if(vehicle->lightningState>=0&&state){x=CloneMCJava_FloorDouble(vehicle->entity.posX);y=CloneMCJava_FloorDouble(vehicle->entity.posY);z=CloneMCJava_FloorDouble(vehicle->entity.posZ);
            if(CloneMCJ_World_GetBlockId(vehicle->entity.worldObj,x,y,z)==0&&CloneMCJ_BlockRegistry_Get(CloneMCJ_World_GetBlockId(vehicle->entity.worldObj,x,y-1,z))->solid)
                CloneMCJ_World_SetBlockNotify(vehicle->entity.worldObj,x,y,z,51);
            {double dx,dy,dz;dx=state->player.entity.posX-vehicle->entity.posX;dy=state->player.entity.posY-vehicle->entity.posY;
                dz=state->player.entity.posZ-vehicle->entity.posZ;if(dx*dx+dy*dy+dz*dz<9.0){state->player.entity.fire=160;
                    CloneMCJ_EntityPlayer_AttackFrom(&state->player,&vehicle->entity,5);}}
            for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active){double dx,dy,dz;dx=state->mobs[i].entity.posX-vehicle->entity.posX;
                dy=state->mobs[i].entity.posY-vehicle->entity.posY;dz=state->mobs[i].entity.posZ-vehicle->entity.posZ;if(dx*dx+dy*dy+dz*dz<9.0){state->mobs[i].entity.fire=160;
                    if(state->mobs[i].type==CLONEMC_J_MOB_CREEPER)state->mobs[i].angry=1;
                    CloneMCJ_EntityLiving_AttackMobFrom(&state->mobs[i],&vehicle->entity,5);}}}}
    if(vehicle->entity.posY<-64.0)vehicle->active=0;
}

int CloneMCJ_Vehicle_WriteNBT(const CloneMCJ_Vehicle *vehicle,CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagList *items;CloneMCJ_NBTTagCompound *tag;int i;
    if(!vehicle||!compound||!vehicle->active)return 0;
    if(!CloneMCJ_Entity_WriteNBT(&vehicle->entity,compound,CloneMCJ_Vehicle_Name(vehicle->type)))return 0;
    CloneMCJ_NBTTagCompound_SetInteger(compound,"EntityId",vehicle->entity.entityId);
    if(vehicle->type==CLONEMC_J_VEHICLE_PRIMED_TNT)CloneMCJ_NBTTagCompound_SetByte(compound,"Fuse",(CloneMCJByte)vehicle->fuse);
    else if(vehicle->type==CLONEMC_J_VEHICLE_FALLING_BLOCK){CloneMCJ_NBTTagCompound_SetByte(compound,"Tile",(CloneMCJByte)vehicle->blockID);CloneMCJ_NBTTagCompound_SetByte(compound,"Data",(CloneMCJByte)vehicle->blockData);}
    else if(vehicle->type==CLONEMC_J_VEHICLE_MINECART){CloneMCJ_NBTTagCompound_SetInteger(compound,"Type",vehicle->minecartType);
        if(vehicle->minecartType==2){CloneMCJ_NBTTagCompound_SetDouble(compound,"PushX",vehicle->pushX);
            CloneMCJ_NBTTagCompound_SetDouble(compound,"PushZ",vehicle->pushZ);CloneMCJ_NBTTagCompound_SetShort(compound,"Fuel",(CloneMCJShort)vehicle->fuel);}
        else if(vehicle->minecartType==1){items=CloneMCJ_NBTTagList_Create();if(!items)return 0;for(i=0;i<27;++i)if(!CloneMCJ_ItemStack_IsEmpty(&vehicle->cargo[i])){tag=CloneMCJ_NBTTagCompound_Create();if(tag){CloneMCJ_NBTTagCompound_SetByte(tag,"Slot",(CloneMCJByte)i);CloneMCJ_ItemStack_WriteNBT(&vehicle->cargo[i],tag);CloneMCJ_NBTTagList_Append(items,(CloneMCJ_NBTBase *)tag);}}CloneMCJ_NBTTagCompound_SetTag(compound,"Items",(CloneMCJ_NBTBase *)items);}}
    else if(vehicle->type==CLONEMC_J_VEHICLE_PAINTING){CloneMCJ_NBTTagCompound_SetString(compound,"Motive",vehicle->art);
        CloneMCJ_NBTTagCompound_SetByte(compound,"Dir",(CloneMCJByte)vehicle->direction);CloneMCJ_NBTTagCompound_SetInteger(compound,"TileX",vehicle->tileX);CloneMCJ_NBTTagCompound_SetInteger(compound,"TileY",vehicle->tileY);CloneMCJ_NBTTagCompound_SetInteger(compound,"TileZ",vehicle->tileZ);}
    return 1;
}

int CloneMCJ_Vehicle_ReadNBT(CloneMCJ_Vehicle *vehicle,const CloneMCJ_NBTTagCompound *compound,CloneMCJ_World *world)
{
    const char *id;CloneMCJ_VehicleType type;int data,i,slot;CloneMCJ_NBTTagList *items;CloneMCJ_NBTTagCompound *tag;
    if(!vehicle||!compound)return 0;
    id=CloneMCJ_NBTTagCompound_GetString(compound,"id");data=0;
    if(!strcmp(id,"Boat"))type=CLONEMC_J_VEHICLE_BOAT;else if(!strcmp(id,"Minecart")){type=CLONEMC_J_VEHICLE_MINECART;data=CloneMCJ_NBTTagCompound_GetInteger(compound,"Type");if(data<0||data>2)data=0;}
    else if(!strcmp(id,"PrimedTnt"))type=CLONEMC_J_VEHICLE_PRIMED_TNT;else if(!strcmp(id,"FallingSand")){type=CLONEMC_J_VEHICLE_FALLING_BLOCK;data=CloneMCJ_NBTTagCompound_GetByte(compound,"Tile")&255;}
    else if(!strcmp(id,"Painting"))type=CLONEMC_J_VEHICLE_PAINTING;else return 0;
    CloneMCJ_Vehicle_Initialize(vehicle,type,world,0.0,0.0,0.0,data);if(!CloneMCJ_Entity_ReadNBT(&vehicle->entity,compound))return 0;
    i=CloneMCJ_NBTTagCompound_GetInteger(compound,"EntityId");if(i>0){vehicle->entity.entityId=i;CloneMCJ_Entity_ReserveID(i);}
    if(type==CLONEMC_J_VEHICLE_PRIMED_TNT)vehicle->fuse=CloneMCJ_NBTTagCompound_GetByte(compound,"Fuse");
    else if(type==CLONEMC_J_VEHICLE_FALLING_BLOCK)vehicle->blockData=CloneMCJ_NBTTagCompound_GetByte(compound,"Data")&255;
    else if(type==CLONEMC_J_VEHICLE_MINECART){if(vehicle->minecartType==2){vehicle->pushX=CloneMCJ_NBTTagCompound_GetDouble(compound,"PushX");
            vehicle->pushZ=CloneMCJ_NBTTagCompound_GetDouble(compound,"PushZ");vehicle->fuel=CloneMCJ_NBTTagCompound_GetShort(compound,"Fuel");}
        else if(vehicle->minecartType==1){items=CloneMCJ_NBTTagCompound_GetTagList(compound,"Items");if(items)for(i=0;i<CloneMCJ_NBTTagList_Count(items);++i){tag=(CloneMCJ_NBTTagCompound *)CloneMCJ_NBTTagList_Get(items,i);if(tag&&tag->type==10){slot=CloneMCJ_NBTTagCompound_GetByte(tag,"Slot")&255;if(slot<27)CloneMCJ_ItemStack_ReadNBT(&vehicle->cargo[slot],tag);}}}}
    else if(type==CLONEMC_J_VEHICLE_PAINTING){id=CloneMCJ_NBTTagCompound_GetString(compound,"Motive");if(id&&id[0]&&CloneMCJ_EnumArt_Find(id)){strncpy(vehicle->art,id,sizeof(vehicle->art)-1U);vehicle->art[sizeof(vehicle->art)-1U]='\0';}
        vehicle->direction=CloneMCJ_NBTTagCompound_GetByte(compound,"Dir")&3;vehicle->tileX=CloneMCJ_NBTTagCompound_GetInteger(compound,"TileX");vehicle->tileY=CloneMCJ_NBTTagCompound_GetInteger(compound,"TileY");vehicle->tileZ=CloneMCJ_NBTTagCompound_GetInteger(compound,"TileZ");}
    vehicle->active=1;return 1;
}

int CloneMCJ_Gameplay_SpawnVehicle(CloneMCJ_GameplayState *state,CloneMCJ_VehicleType type,
    double x,double y,double z,int data)
{
    int i;if(!state||!state->world)return 0;for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(!state->vehicles[i].active)break;
    if(i>=CLONEMC_J_MAX_VEHICLES)return 0;
    CloneMCJ_Vehicle_Initialize(&state->vehicles[i],type,state->world,x,y,z,data);
    if(state->nextEntityId<=state->vehicles[i].entity.entityId)state->nextEntityId=state->vehicles[i].entity.entityId+1;
    if(i>=state->vehicleCount)state->vehicleCount=i+1;
    return 1;
}

void CloneMCJ_EntityBoat_Register(void)
{
    /* Runtime state is initialized on demand by gameplay spawn dispatch. */
}

const char *CloneMCJ_EntityBoat_JavaName(void)
{
    return "net.minecraft.src.EntityBoat";
}

const char *CloneMCJ_EntityBoat_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityBoat_JavaSourceHash32(void)
{
    return 0x2D0E9486UL;
}
