/*
 * CloneMC Java port scaffold: EntityArrow
 *
 * Java source: EntityArrow.java
 * Java type: class EntityArrow
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: e4e1df75f4a2c22be206421b110366cb731e4a503649a18e238c1f9fd0fa1905
 * Java lines: 325
 * Discovered declared fields: 11
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: Entity, EntityPlayer, EntityLiving, MathHelper, World, Block, Vec3D, AxisAlignedBB, MovingObjectPosition, NBTTagCompound, ItemStack, Item, InventoryPlayer, d1, entityliving.posZ, entityliving.rotationYaw, posY
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int xTile
 * - private int yTile
 * - private int zTile
 * - private int inTile
 * - private int field_28019_h
 * - private boolean inGround
 * - public boolean doesArrowBelongToPlayer
 * - public int arrowShake
 * - public EntityLiving owner
 * - private int ticksInGround
 * - private int ticksInAir
 *
 * Java method/constructor inventory:
 * - public EntityArrow(World world)
 * - public EntityArrow(World world, double d, double d1, double d2)
 * - public EntityArrow(World world, EntityLiving entityliving)
 * - protected void entityInit()
 * - public void setVelocity(double d, double d1, double d2)
 * - public void onUpdate()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void onCollideWithPlayer(EntityPlayer entityplayer)
 * - public float getShadowSize()
 *
 * This class now owns the bounded shared projectile runtime: Java heading RNG,
 * collision, drag/gravity, pickup, impact behavior and projectile NBT.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>
#include <string.h>

static const char *CloneMCJ_Projectile_Name(CloneMCJ_ProjectileType type)
{
    if(type==CLONEMC_J_PROJECTILE_ARROW)return "Arrow";
    if(type==CLONEMC_J_PROJECTILE_SNOWBALL)return "Snowball";
    if(type==CLONEMC_J_PROJECTILE_EGG)return "Egg";
    if(type==CLONEMC_J_PROJECTILE_FIREBALL)return "Fireball";
    return "FishingHook";
}

void CloneMCJ_Projectile_SetHeading(CloneMCJ_Projectile *projectile,
    double x,double y,double z,float speed,float inaccuracy)
{
    double length;
    length=sqrt(x*x+y*y+z*z);if(length<0.000001)return;
    x/=length;y/=length;z/=length;
    x+=CloneMCJavaRandom_NextGaussian(&projectile->entity.rand)*0.0074999998323619366*(double)inaccuracy;
    y+=CloneMCJavaRandom_NextGaussian(&projectile->entity.rand)*0.0074999998323619366*(double)inaccuracy;
    z+=CloneMCJavaRandom_NextGaussian(&projectile->entity.rand)*0.0074999998323619366*(double)inaccuracy;
    projectile->entity.motionX=x*(double)speed;projectile->entity.motionY=y*(double)speed;
    projectile->entity.motionZ=z*(double)speed;
    projectile->entity.rotationYaw=(float)(atan2(projectile->entity.motionX,projectile->entity.motionZ)*180.0/3.14159265358979323846);
    projectile->entity.rotationPitch=(float)(atan2(projectile->entity.motionY,
        sqrt(projectile->entity.motionX*projectile->entity.motionX+projectile->entity.motionZ*projectile->entity.motionZ))*180.0/3.14159265358979323846);
    projectile->entity.prevRotationYaw=projectile->entity.rotationYaw;
    projectile->entity.prevRotationPitch=projectile->entity.rotationPitch;
}

void CloneMCJ_Projectile_Initialize(CloneMCJ_Projectile *projectile,
    CloneMCJ_ProjectileType type,CloneMCJ_World *world,const CloneMCJ_Entity *owner,
    float speed,float inaccuracy)
{
    double yaw,pitch,x,y,z;
    if(!projectile)return;
    memset(projectile,0,sizeof(*projectile));
    CloneMCJ_Entity_Initialize(&projectile->entity,world);projectile->type=type;
    projectile->active=1;projectile->xTile=projectile->yTile=projectile->zTile=-1;
    projectile->ownerEntityId=owner?owner->entityId:0;projectile->belongsToPlayer=(unsigned char)(owner!=0);
    projectile->damage=type==CLONEMC_J_PROJECTILE_ARROW?4:0;
    CloneMCJ_Entity_SetSize(&projectile->entity,type==CLONEMC_J_PROJECTILE_FIREBALL?1.0F:
        (type==CLONEMC_J_PROJECTILE_ARROW?0.5F:0.25F),
        type==CLONEMC_J_PROJECTILE_FIREBALL?1.0F:(type==CLONEMC_J_PROJECTILE_ARROW?0.5F:0.25F));
    if(owner){
        yaw=(double)owner->rotationYaw*3.14159265358979323846/180.0;
        pitch=(double)owner->rotationPitch*3.14159265358979323846/180.0;
        x=owner->posX-cos(yaw)*0.16;y=owner->posY+(double)owner->height*0.85-0.1;
        z=owner->posZ-sin(yaw)*0.16;CloneMCJ_Entity_SetPosition(&projectile->entity,x,y,z);
        x=-sin(yaw)*cos(pitch);y=-sin(pitch);z=cos(yaw)*cos(pitch);
        CloneMCJ_Projectile_SetHeading(projectile,x,y,z,speed,inaccuracy);
        if(type==CLONEMC_J_PROJECTILE_FIREBALL){projectile->accelerationX=x*0.1;
            projectile->accelerationY=y*0.1;projectile->accelerationZ=z*0.1;}
    }
}

static CloneMCJ_Mob *CloneMCJ_Projectile_FindMobByEntityId(
    CloneMCJ_GameplayState *state,int entityId)
{
    int index;
    if(!state||entityId==0)return (CloneMCJ_Mob *)0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
        if(state->mobs[index].active&&
            state->mobs[index].entity.entityId==entityId)return &state->mobs[index];
    return (CloneMCJ_Mob *)0;
}

static void CloneMCJ_Projectile_PropagatePlayerAttack(
    CloneMCJ_GameplayState *state,CloneMCJ_Mob *mob)
{
    int index;
    double dx,dy,dz;
    if(!state||!mob)return;
    if(mob->type==CLONEMC_J_MOB_WOLF&&!mob->tamed){
        for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
            if(state->mobs[index].active&&state->mobs[index].health>0&&
                state->mobs[index].type==CLONEMC_J_MOB_WOLF&&!state->mobs[index].tamed){
                dx=state->mobs[index].entity.posX-mob->entity.posX;
                dy=state->mobs[index].entity.posY-mob->entity.posY;
                dz=state->mobs[index].entity.posZ-mob->entity.posZ;
                if(dx*dx+dy*dy+dz*dz<=256.0){
                    state->mobs[index].angry=1;state->mobs[index].hostile=1;
                    state->mobs[index].targetMemoryTicks=200;
                }
            }
    }else if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE){
        for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
            if(state->mobs[index].active&&state->mobs[index].health>0&&
                state->mobs[index].type==CLONEMC_J_MOB_PIG_ZOMBIE){
                dx=state->mobs[index].entity.posX-mob->entity.posX;
                dy=state->mobs[index].entity.posY-mob->entity.posY;
                dz=state->mobs[index].entity.posZ-mob->entity.posZ;
                if(dx*dx+dy*dy+dz*dz<=1024.0)
                    CloneMCJ_EntityLiving_AngerPigZombie(&state->mobs[index]);
            }
    }
}

static int CloneMCJ_Projectile_HitEntity(CloneMCJ_Projectile *projectile,
    CloneMCJ_GameplayState *state,double x,double y,double z)
{
    CloneMCJ_Mob *mob;
    double dx,dy,dz,radius;
    int i,immuneTicks,accepted;
    if(!state)return 0;
    immuneTicks=projectile->type==CLONEMC_J_PROJECTILE_FIREBALL?25:5;
    if(projectile->type!=CLONEMC_J_PROJECTILE_FISHING&&state->player.health>0&&
       !(projectile->ownerEntityId==state->player.entity.entityId&&projectile->ticksInAir<immuneTicks)){
        dx=state->player.entity.posX-x;dy=state->player.entity.posY+0.9-y;
        dz=state->player.entity.posZ-z;radius=0.65;
        if(dx*dx+dy*dy+dz*dz<=radius*radius){
            accepted=projectile->damage>0?CloneMCJ_EntityPlayer_AttackFrom(&state->player,
                &projectile->entity,projectile->damage):1;
            if(accepted){
                CloneMCJ_Mob *ownerMob;
                ownerMob=CloneMCJ_Projectile_FindMobByEntityId(state,
                    projectile->ownerEntityId);
                if(ownerMob)state->player.lastAttackerEntityId=ownerMob->entity.entityId;
            }
            return accepted?1:2;
        }
    }
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i){mob=&state->mobs[i];if(!mob->active||mob->health<=0)continue;
        if(projectile->ownerEntityId==mob->entity.entityId&&projectile->ticksInAir<immuneTicks)continue;
        dx=mob->entity.posX-x;dy=mob->entity.posY+(double)mob->entity.height*0.5-y;dz=mob->entity.posZ-z;
        radius=(double)mob->entity.width*0.5+0.35;
        if(dx*dx+dy*dy+dz*dz<=radius*radius){
            if(projectile->type==CLONEMC_J_PROJECTILE_FISHING){projectile->hookedEntityId=mob->entity.entityId;return 1;}
            accepted=projectile->damage>0?CloneMCJ_EntityLiving_AttackMobFrom(mob,
                &projectile->entity,projectile->damage):1;
            if(accepted&&projectile->ownerEntityId==state->player.entity.entityId){
                state->player.lastAttackTargetEntityId=mob->entity.entityId;
                CloneMCJ_Projectile_PropagatePlayerAttack(state,mob);
            }
            if(accepted&&mob->type==CLONEMC_J_MOB_CREEPER&&mob->health<=0&&
                projectile->type==CLONEMC_J_PROJECTILE_ARROW){
                int ownerIndex;
                for(ownerIndex=0;ownerIndex<CLONEMC_J_MAX_MOBS;++ownerIndex)
                    if(state->mobs[ownerIndex].active&&
                        state->mobs[ownerIndex].entity.entityId==projectile->ownerEntityId&&
                        state->mobs[ownerIndex].type==CLONEMC_J_MOB_SKELETON){
                        mob->killedBySkeleton=1;break;}
            }
            return accepted?1:2;
        }
    }
    return 0;
}

static void CloneMCJ_Projectile_Explode(CloneMCJ_Projectile *projectile,
    CloneMCJ_GameplayState *state,double x,double y,double z)
{
    if(!projectile||!state||!state->world)return;
    CloneMCJ_Explosion_Execute(state->world,&projectile->entity,x,y,z,1.0F,1);
}

static void CloneMCJ_Projectile_EggHatch(CloneMCJ_Projectile *projectile,
    CloneMCJ_GameplayState *state)
{
    int count,i,slot;
    if(!state||CloneMCJavaRandom_NextIntBound(&projectile->entity.rand,8)!=0)return;
    count=CloneMCJavaRandom_NextIntBound(&projectile->entity.rand,32)==0?4:1;
    for(i=0;i<count;++i){for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)if(!state->mobs[slot].active)break;
        if(slot>=CLONEMC_J_MAX_MOBS)return;
        CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],CLONEMC_J_MOB_CHICKEN,
            state->world,projectile->entity.posX,projectile->entity.posY,projectile->entity.posZ);
        if(state->nextEntityId<=state->mobs[slot].entity.entityId)
            state->nextEntityId=state->mobs[slot].entity.entityId+1;
        state->mobs[slot].persistenceRequired=0;
    }
}

void CloneMCJ_Projectile_Tick(CloneMCJ_Projectile *projectile,CloneMCJ_GameplayState *state)
{
    CloneMCJ_World *world;
    int blockID,bx,by,bz,i,water,step,steps,hit;
    double nextX,nextY,nextZ,horizontal,sampleX,sampleY,sampleZ,maxMotion;
    float drag,gravity;
    CloneMCJ_ItemStack arrow;
    if(!projectile||!projectile->active)return;
    world=projectile->entity.worldObj;if(!world){projectile->active=0;return;}
    projectile->entity.prevPosX=projectile->entity.posX;projectile->entity.prevPosY=projectile->entity.posY;
    projectile->entity.prevPosZ=projectile->entity.posZ;projectile->entity.prevRotationYaw=projectile->entity.rotationYaw;
    projectile->entity.prevRotationPitch=projectile->entity.rotationPitch;++projectile->age;++projectile->entity.ticksExisted;
    if(projectile->shake>0)--projectile->shake;
    if(projectile->type==CLONEMC_J_PROJECTILE_FISHING&&state){
        CloneMCJ_ItemStack *held;double anglerX,anglerY,anglerZ;
        held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
        anglerX=state->player.entity.posX-projectile->entity.posX;
        anglerY=state->player.entity.posY-projectile->entity.posY;
        anglerZ=state->player.entity.posZ-projectile->entity.posZ;
        if(state->player.health<=0||projectile->ownerEntityId!=state->player.entity.entityId||
            !held||CloneMCJ_ItemStack_IsEmpty(held)||held->itemID!=346||
            anglerX*anglerX+anglerY*anglerY+anglerZ*anglerZ>1024.0){projectile->active=0;return;}}
    if(projectile->type==CLONEMC_J_PROJECTILE_FISHING&&projectile->hookedEntityId&&state){
        for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&
            state->mobs[i].entity.entityId==projectile->hookedEntityId)break;
        if(i<CLONEMC_J_MAX_MOBS){CloneMCJ_Entity_SetPosition(&projectile->entity,state->mobs[i].entity.posX,
            state->mobs[i].entity.boundingBox.minY+(double)state->mobs[i].entity.height*0.8,
            state->mobs[i].entity.posZ);return;}projectile->hookedEntityId=0;
    }
    if(projectile->inGround){
        blockID=CloneMCJ_World_GetBlockId(world,projectile->xTile,projectile->yTile,projectile->zTile);
        if(blockID!=projectile->inTile){projectile->inGround=0;projectile->ticksInGround=0;
            projectile->entity.motionX*=CloneMCJavaRandom_NextFloat(&projectile->entity.rand)*0.2F;
            projectile->entity.motionY*=CloneMCJavaRandom_NextFloat(&projectile->entity.rand)*0.2F;
            projectile->entity.motionZ*=CloneMCJavaRandom_NextFloat(&projectile->entity.rand)*0.2F;
        }else{
            ++projectile->ticksInGround;
            if(projectile->type==CLONEMC_J_PROJECTILE_ARROW&&projectile->belongsToPlayer&&state&&
                projectile->shake<=0){
                double dx,dy,dz;dx=state->player.entity.posX-projectile->entity.posX;
                dy=state->player.entity.posY-projectile->entity.posY;dz=state->player.entity.posZ-projectile->entity.posZ;
                if(dx*dx+dy*dy+dz*dz<2.25){CloneMCJ_ItemStack_Initialize(&arrow,262,1,0);
                    if(CloneMCJ_InventoryPlayer_AddItemStack(&state->player.inventory,&arrow)){projectile->active=0;return;}}
            }
            if(projectile->ticksInGround>=1200)projectile->active=0;
            return;
        }
    }
    ++projectile->ticksInAir;
    maxMotion=fabs(projectile->entity.motionX);if(fabs(projectile->entity.motionY)>maxMotion)maxMotion=fabs(projectile->entity.motionY);
    if(fabs(projectile->entity.motionZ)>maxMotion)maxMotion=fabs(projectile->entity.motionZ);
    steps=(int)ceil(maxMotion/0.2);if(steps<1)steps=1;if(steps>128)steps=128;
    nextX=projectile->entity.posX+projectile->entity.motionX;nextY=projectile->entity.posY+projectile->entity.motionY;
    nextZ=projectile->entity.posZ+projectile->entity.motionZ;
    for(step=1;step<=steps;++step){sampleX=projectile->entity.posX+projectile->entity.motionX*(double)step/(double)steps;
        sampleY=projectile->entity.posY+projectile->entity.motionY*(double)step/(double)steps;
        sampleZ=projectile->entity.posZ+projectile->entity.motionZ*(double)step/(double)steps;
        hit=CloneMCJ_Projectile_HitEntity(projectile,state,sampleX,sampleY,sampleZ);
        if(hit){if(projectile->type==CLONEMC_J_PROJECTILE_FISHING)return;
            if(hit==2&&projectile->type==CLONEMC_J_PROJECTILE_ARROW){projectile->entity.motionX*=-0.1;
                projectile->entity.motionY*=-0.1;projectile->entity.motionZ*=-0.1;projectile->ticksInAir=0;return;}
            if(projectile->type==CLONEMC_J_PROJECTILE_FIREBALL)CloneMCJ_Projectile_Explode(projectile,state,sampleX,sampleY,sampleZ);
            if(projectile->type==CLONEMC_J_PROJECTILE_EGG)CloneMCJ_Projectile_EggHatch(projectile,state);
            projectile->active=0;return;}
        bx=CloneMCJava_FloorDouble(sampleX);by=CloneMCJava_FloorDouble(sampleY);bz=CloneMCJava_FloorDouble(sampleZ);
        blockID=CloneMCJ_World_GetBlockId(world,bx,by,bz);
        if(blockID!=0&&CloneMCJ_BlockRegistry_Get(blockID)->collidable){
            CloneMCJ_Entity_SetPosition(&projectile->entity,sampleX,sampleY,sampleZ);
            if(projectile->type==CLONEMC_J_PROJECTILE_ARROW||projectile->type==CLONEMC_J_PROJECTILE_FISHING){
                projectile->xTile=bx;projectile->yTile=by;projectile->zTile=bz;projectile->inTile=blockID;
                projectile->inData=CloneMCJ_World_GetBlockMetadata(world,bx,by,bz);projectile->inGround=1;
                projectile->shake=7;projectile->entity.motionX=projectile->entity.motionY=projectile->entity.motionZ=0.0;
            }else{if(projectile->type==CLONEMC_J_PROJECTILE_FIREBALL)CloneMCJ_Projectile_Explode(projectile,state,sampleX,sampleY,sampleZ);
                if(projectile->type==CLONEMC_J_PROJECTILE_EGG)
                    CloneMCJ_Projectile_EggHatch(projectile,state);
                projectile->active=0;}
            return;}
    }
    CloneMCJ_Entity_SetPosition(&projectile->entity,nextX,nextY,nextZ);
    horizontal=sqrt(projectile->entity.motionX*projectile->entity.motionX+projectile->entity.motionZ*projectile->entity.motionZ);
    projectile->entity.rotationYaw=(float)(atan2(projectile->entity.motionX,projectile->entity.motionZ)*180.0/3.14159265358979323846);
    projectile->entity.rotationPitch=(float)(atan2(projectile->entity.motionY,horizontal)*180.0/3.14159265358979323846);
    if(projectile->type==CLONEMC_J_PROJECTILE_FIREBALL){projectile->entity.motionX+=projectile->accelerationX;
        projectile->entity.motionY+=projectile->accelerationY;projectile->entity.motionZ+=projectile->accelerationZ;drag=0.95F;gravity=0.0F;
    }else if(projectile->type==CLONEMC_J_PROJECTILE_FISHING){water=CloneMCJ_Entity_IsInsideMaterial(&projectile->entity,CLONEMC_J_MATERIAL_WATER);
        if(water){if(projectile->ticksCatchable>0)--projectile->ticksCatchable;
            else if(CloneMCJavaRandom_NextIntBound(&projectile->entity.rand,500)==0)
                projectile->ticksCatchable=10+CloneMCJavaRandom_NextIntBound(&projectile->entity.rand,30);
            if(projectile->ticksCatchable>0)projectile->entity.motionY-=
                CloneMCJavaRandom_NextFloat(&projectile->entity.rand)*CloneMCJavaRandom_NextFloat(&projectile->entity.rand)*
                CloneMCJavaRandom_NextFloat(&projectile->entity.rand)*0.2;projectile->entity.motionY+=0.04;drag=0.828F;
        }else{projectile->entity.motionY-=0.04;drag=0.92F;}gravity=0.0F;
    }else{drag=CloneMCJ_Entity_IsInsideMaterial(&projectile->entity,CLONEMC_J_MATERIAL_WATER)?0.8F:0.99F;gravity=0.03F;}
    projectile->entity.motionX*=drag;projectile->entity.motionY=projectile->entity.motionY*drag-gravity;
    projectile->entity.motionZ*=drag;
    if(projectile->age>6000||projectile->entity.posY<-64.0)projectile->active=0;
}

int CloneMCJ_Projectile_WriteNBT(const CloneMCJ_Projectile *projectile,CloneMCJ_NBTTagCompound *compound)
{
    if(!projectile||!compound||!projectile->active)return 0;
    if(!CloneMCJ_Entity_WriteNBT(&projectile->entity,compound,CloneMCJ_Projectile_Name(projectile->type)))return 0;
    CloneMCJ_NBTTagCompound_SetShort(compound,"xTile",(CloneMCJShort)projectile->xTile);
    CloneMCJ_NBTTagCompound_SetShort(compound,"yTile",(CloneMCJShort)projectile->yTile);
    CloneMCJ_NBTTagCompound_SetShort(compound,"zTile",(CloneMCJShort)projectile->zTile);
    CloneMCJ_NBTTagCompound_SetByte(compound,"inTile",(CloneMCJByte)projectile->inTile);
    CloneMCJ_NBTTagCompound_SetByte(compound,"inData",(CloneMCJByte)projectile->inData);
    CloneMCJ_NBTTagCompound_SetByte(compound,"shake",(CloneMCJByte)projectile->shake);
    CloneMCJ_NBTTagCompound_SetByte(compound,"inGround",(CloneMCJByte)projectile->inGround);
    CloneMCJ_NBTTagCompound_SetBoolean(compound,"player",projectile->belongsToPlayer);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"Owner",projectile->ownerEntityId);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"EntityId",projectile->entity.entityId);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"Age",projectile->age);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"CloneMCTicksInGround",projectile->ticksInGround);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"CloneMCTicksInAir",projectile->ticksInAir);
    if(projectile->type==CLONEMC_J_PROJECTILE_FIREBALL){
        CloneMCJ_NBTTagCompound_SetDouble(compound,"CloneMCAccelerationX",projectile->accelerationX);
        CloneMCJ_NBTTagCompound_SetDouble(compound,"CloneMCAccelerationY",projectile->accelerationY);
        CloneMCJ_NBTTagCompound_SetDouble(compound,"CloneMCAccelerationZ",projectile->accelerationZ);}
    return 1;
}

int CloneMCJ_Projectile_ReadNBT(CloneMCJ_Projectile *projectile,const CloneMCJ_NBTTagCompound *compound,CloneMCJ_World *world)
{
    const char *id;CloneMCJ_ProjectileType type;int storedID;
    if(!projectile||!compound)return 0;
    id=CloneMCJ_NBTTagCompound_GetString(compound,"id");
    if(!strcmp(id,"Arrow"))type=CLONEMC_J_PROJECTILE_ARROW;else if(!strcmp(id,"Snowball"))type=CLONEMC_J_PROJECTILE_SNOWBALL;
    else if(!strcmp(id,"Egg"))type=CLONEMC_J_PROJECTILE_EGG;else if(!strcmp(id,"Fireball"))type=CLONEMC_J_PROJECTILE_FIREBALL;else return 0;
    CloneMCJ_Projectile_Initialize(projectile,type,world,(const CloneMCJ_Entity *)0,1.0F,0.0F);
    if(!CloneMCJ_Entity_ReadNBT(&projectile->entity,compound))return 0;
    projectile->xTile=CloneMCJ_NBTTagCompound_GetShort(compound,"xTile");projectile->yTile=CloneMCJ_NBTTagCompound_GetShort(compound,"yTile");
    projectile->zTile=CloneMCJ_NBTTagCompound_GetShort(compound,"zTile");projectile->inTile=CloneMCJ_NBTTagCompound_GetByte(compound,"inTile")&255;
    projectile->inData=CloneMCJ_NBTTagCompound_GetByte(compound,"inData")&255;projectile->shake=CloneMCJ_NBTTagCompound_GetByte(compound,"shake")&255;
    projectile->inGround=(unsigned char)(CloneMCJ_NBTTagCompound_GetByte(compound,"inGround")==1);
    projectile->belongsToPlayer=(unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound,"player");
    projectile->ownerEntityId=CloneMCJ_NBTTagCompound_GetInteger(compound,"Owner");projectile->age=CloneMCJ_NBTTagCompound_GetInteger(compound,"Age");
    if(projectile->age<0)projectile->age=0;
    projectile->ticksInGround=CloneMCJ_NBTTagCompound_GetInteger(compound,"CloneMCTicksInGround");
    projectile->ticksInAir=CloneMCJ_NBTTagCompound_GetInteger(compound,"CloneMCTicksInAir");
    if(projectile->ticksInGround<0)projectile->ticksInGround=0;
    if(projectile->ticksInAir<0)projectile->ticksInAir=0;
    if(type==CLONEMC_J_PROJECTILE_FIREBALL){projectile->accelerationX=CloneMCJ_NBTTagCompound_GetDouble(compound,"CloneMCAccelerationX");
        projectile->accelerationY=CloneMCJ_NBTTagCompound_GetDouble(compound,"CloneMCAccelerationY");
        projectile->accelerationZ=CloneMCJ_NBTTagCompound_GetDouble(compound,"CloneMCAccelerationZ");
        if(projectile->accelerationX!=projectile->accelerationX||fabs(projectile->accelerationX)>1.0)projectile->accelerationX=0.0;
        if(projectile->accelerationY!=projectile->accelerationY||fabs(projectile->accelerationY)>1.0)projectile->accelerationY=0.0;
        if(projectile->accelerationZ!=projectile->accelerationZ||fabs(projectile->accelerationZ)>1.0)projectile->accelerationZ=0.0;}
    storedID=CloneMCJ_NBTTagCompound_GetInteger(compound,"EntityId");if(storedID>0){projectile->entity.entityId=storedID;CloneMCJ_Entity_ReserveID(storedID);}
    projectile->active=1;return 1;
}

int CloneMCJ_Gameplay_SpawnProjectile(CloneMCJ_GameplayState *state,CloneMCJ_ProjectileType type,
    const CloneMCJ_Entity *owner,float speed,float inaccuracy)
{
    int i;if(!state||!state->world)return 0;
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(!state->projectiles[i].active)break;
    if(i>=CLONEMC_J_MAX_PROJECTILES)return 0;
    CloneMCJ_Projectile_Initialize(&state->projectiles[i],type,state->world,owner,speed,inaccuracy);
    if(state->nextEntityId<=state->projectiles[i].entity.entityId)
        state->nextEntityId=state->projectiles[i].entity.entityId+1;
    if(i>=state->projectileCount)state->projectileCount=i+1;
    return 1;
}

void CloneMCJ_EntityArrow_Register(void)
{
    /* Runtime state is initialized on demand by gameplay spawn dispatch. */
}

const char *CloneMCJ_EntityArrow_JavaName(void)
{
    return "net.minecraft.src.EntityArrow";
}

const char *CloneMCJ_EntityArrow_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityArrow_JavaSourceHash32(void)
{
    return 0xE4E1DF75UL;
}
