/*
 * CloneMC Java port scaffold: EntitySnowball
 *
 * Java source: EntitySnowball.java
 * Java type: class EntitySnowball
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: bc8dbec6fd60db29fc3993b7d1227ce757394f6ca4778c29c2d65c2a134d2a12
 * Java lines: 281
 * Discovered declared fields: 9
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: Entity, AxisAlignedBB, EntityLiving, MathHelper, World, Vec3D, MovingObjectPosition, NBTTagCompound, EntityPlayer, ItemStack, Item, InventoryPlayer, entityliving.posZ, entityliving.rotationYaw, posY
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int xTileSnowball
 * - private int yTileSnowball
 * - private int zTileSnowball
 * - private int inTileSnowball
 * - private boolean inGroundSnowball
 * - public int shakeSnowball
 * - private EntityLiving thrower
 * - private int ticksInGroundSnowball
 * - private int ticksInAirSnowball
 *
 * Java method/constructor inventory:
 * - public EntitySnowball(World world)
 * - protected void entityInit()
 * - public boolean isInRangeToRenderDist(double d)
 * - public EntitySnowball(World world, EntityLiving entityliving)
 * - public EntitySnowball(World world, double d, double d1, double d2)
 * - public void setVelocity(double d, double d1, double d2)
 * - public void onUpdate()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void onCollideWithPlayer(EntityPlayer entityplayer)
 * - public float getShadowSize()
 *
 * This class owns the typed Java constructor adapter; shared collision and NBT
 * behavior is implemented once by the bounded projectile runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntitySnowball_InitializeNative(CloneMCJ_Projectile *snowball,
    struct CloneMCJ_WorldTag *world,const CloneMCJ_Entity *thrower)
{
    CloneMCJ_Projectile_Initialize(snowball,CLONEMC_J_PROJECTILE_SNOWBALL,world,thrower,1.5F,1.0F);
}

void CloneMCJ_EntitySnowball_Register(void)
{
    /* Runtime dispatch is installed through the bounded projectile table. */
}

const char *CloneMCJ_EntitySnowball_JavaName(void)
{
    return "net.minecraft.src.EntitySnowball";
}

const char *CloneMCJ_EntitySnowball_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntitySnowball_JavaSourceHash32(void)
{
    return 0xBC8DBEC6UL;
}
