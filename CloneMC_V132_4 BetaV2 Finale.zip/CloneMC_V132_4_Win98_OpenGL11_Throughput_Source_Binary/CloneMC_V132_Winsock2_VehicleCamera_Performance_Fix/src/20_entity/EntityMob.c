/*
 * CloneMC Java port scaffold: EntityMob
 *
 * Java source: EntityMob.java
 * Java type: class EntityMob
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityCreature
 * Implements: IMob
 * Source SHA-256: 7746ae3225f61f89fa096cae425ffc2d4ba593a24edc0a8bd41028e5881777c7
 * Java lines: 120
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: EntityCreature, IMob, World, Entity, AxisAlignedBB, MathHelper, EnumSkyBlock, NBTTagCompound, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected int attackStrength
 *
 * Java method/constructor inventory:
 * - public EntityMob(World world)
 * - public void onLivingUpdate()
 * - public void onUpdate()
 * - protected Entity findPlayerToAttack()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - protected void attackEntity(Entity entity, float f)
 * - protected float getBlockPathWeight(int i, int j, int k)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public boolean getCanSpawnHere()
 *
 * This class now owns hostile-player acquisition distance checks; attack timing,
 * light spawning, hurt resistance and movement are shared by EntityLiving.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_EntityMob_CanTargetPlayerNative(const CloneMCJ_Mob *mob,
    const CloneMCJ_EntityPlayer *player,float range)
{
    double x,y,z;if(!mob||!player||!mob->hostile||mob->health<=0)return 0;
    x=mob->entity.posX-player->entity.posX;y=mob->entity.posY-player->entity.posY;
    z=mob->entity.posZ-player->entity.posZ;return x*x+y*y+z*z<(double)range*(double)range;
}

void CloneMCJ_EntityMob_Register(void)
{
    /* Hostile behavior is selected by mob type during construction. */
}

const char *CloneMCJ_EntityMob_JavaName(void)
{
    return "net.minecraft.src.EntityMob";
}

const char *CloneMCJ_EntityMob_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityMob_JavaSourceHash32(void)
{
    return 0x7746AE32UL;
}
