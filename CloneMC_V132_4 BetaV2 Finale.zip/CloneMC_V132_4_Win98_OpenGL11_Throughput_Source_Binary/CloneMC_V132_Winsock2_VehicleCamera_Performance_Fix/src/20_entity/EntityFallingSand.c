/*
 * CloneMC Java port scaffold: EntityFallingSand
 *
 * Java source: EntityFallingSand.java
 * Java type: class EntityFallingSand
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: b4f835d84aeb93316d6aec08e3f5de66a3c3dabc76674241a22be4ddae86dff3
 * Java lines: 117
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: Entity, MathHelper, World, BlockSand, NBTTagCompound, d1, motionY, j, k, i, true
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int blockID
 * - public int fallTime
 *
 * Java method/constructor inventory:
 * - public EntityFallingSand(World world)
 * - protected boolean canTriggerWalking()
 * - protected void entityInit()
 * - public boolean canBeCollidedWith()
 * - public void onUpdate()
 * - protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public float getShadowSize()
 * - public World getWorld()
 *
 * This class now owns falling-block ID/metadata construction; gravity, landing,
 * item fallback and NBT are shared by the bounded vehicle runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityFallingSand_InitializeNative(CloneMCJ_Vehicle *falling,
    struct CloneMCJ_WorldTag *world,double x,double y,double z,int blockID,int metadata)
{
    CloneMCJ_Vehicle_Initialize(falling,CLONEMC_J_VEHICLE_FALLING_BLOCK,world,x,y,z,blockID);
    falling->blockData=metadata&15;
}

void CloneMCJ_EntityFallingSand_Register(void)
{
    /* Runtime dispatch is installed through the bounded vehicle table. */
}

const char *CloneMCJ_EntityFallingSand_JavaName(void)
{
    return "net.minecraft.src.EntityFallingSand";
}

const char *CloneMCJ_EntityFallingSand_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityFallingSand_JavaSourceHash32(void)
{
    return 0xB4F835D8UL;
}
