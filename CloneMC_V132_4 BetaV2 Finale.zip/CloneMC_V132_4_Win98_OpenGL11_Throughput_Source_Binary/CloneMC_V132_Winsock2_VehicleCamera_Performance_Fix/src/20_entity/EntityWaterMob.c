/*
 * CloneMC Java port scaffold: EntityWaterMob
 *
 * Java source: EntityWaterMob.java
 * Java type: class EntityWaterMob
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityCreature
 * Implements: (none declared)
 * Source SHA-256: 7157df955bf95389e7a272fea28aa9a07497efb74c2197d9ef072f0cf9c5c5e1
 * Java lines: 44
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: EntityCreature, World, NBTTagCompound
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityWaterMob(World world)
 * - public boolean canBreatheUnderwater()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public boolean getCanSpawnHere()
 * - public int getTalkInterval()
 *
 * This class now owns the uploaded underwater-breathing contract; water spawning
 * and squid movement use the shared bounded mob runtime.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_EntityWaterMob_CanBreatheUnderwaterNative(void)
{
    return 1;
}

void CloneMCJ_EntityWaterMob_Register(void)
{
    /* Water behavior is selected by mob type during construction. */
}

const char *CloneMCJ_EntityWaterMob_JavaName(void)
{
    return "net.minecraft.src.EntityWaterMob";
}

const char *CloneMCJ_EntityWaterMob_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityWaterMob_JavaSourceHash32(void)
{
    return 0x7157DF95UL;
}
