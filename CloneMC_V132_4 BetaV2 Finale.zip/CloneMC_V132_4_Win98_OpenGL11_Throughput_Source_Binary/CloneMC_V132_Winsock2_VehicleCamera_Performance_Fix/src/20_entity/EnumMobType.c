/*
 * CloneMC Java port scaffold: EnumMobType
 *
 * Java source: EnumMobType.java
 * Java type: enum EnumMobType
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 47b30859bcc4d57fc55a8b0a7699dc0d3407af90f8b3e79c9a0bb1997c0dc068
 * Java lines: 47
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static final EnumMobType field_1340_d[]
 *
 * Java method/constructor inventory:
 * - private EnumMobType(String s, int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EnumMobType_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumMobType_JavaName(void)
{
    return "net.minecraft.src.EnumMobType";
}

const char *CloneMCJ_EnumMobType_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EnumMobType_JavaSourceHash32(void)
{
    return 0x47B30859UL;
}
