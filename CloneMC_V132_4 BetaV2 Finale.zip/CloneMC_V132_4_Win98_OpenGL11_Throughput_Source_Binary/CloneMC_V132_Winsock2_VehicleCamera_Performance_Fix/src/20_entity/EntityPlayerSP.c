/*
 * CloneMC Java port scaffold: EntityPlayerSP
 *
 * Java source: EntityPlayerSP.java
 * Java type: class EntityPlayerSP
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityPlayer
 * Implements: (none declared)
 * Source SHA-256: 5278272540cfbd23155b4dcef4d74e637b0e45158c0f5c6f307d703d51023bc1
 * Java lines: 306
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 25
 * Referenced Java classes: EntityPlayer, MouseFilter, Session, MovementInput, AchievementList, StatFileWriter, GuiAchievement, World, SoundManager, AxisAlignedBB, NBTTagCompound, GuiEditSign, GuiChest, GuiCrafting, GuiFurnace, GuiDispenser, EntityPickupFX, EffectRenderer, InventoryPlayer, GuiIngame, StatBase, Achievement, MathHelper, TileEntitySign, IInventory, TileEntityFurnace, TileEntityDispenser, Entity, d1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public MovementInput movementInput
 * - protected Minecraft mc
 * - private MouseFilter field_21903_bJ
 * - private MouseFilter field_21904_bK
 * - private MouseFilter field_21902_bL
 *
 * Java method/constructor inventory:
 * - public EntityPlayerSP(Minecraft minecraft, World world, Session session, int i)
 * - public void moveEntity(double d, double d1, double d2)
 * - public void updatePlayerActionState()
 * - public void onLivingUpdate()
 * - public void resetPlayerKeyState()
 * - public void handleKeyPress(int i, boolean flag)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public void closeScreen()
 * - public void displayGUIEditSign(TileEntitySign tileentitysign)
 * - public void displayGUIChest(IInventory iinventory)
 * - public void displayWorkbenchGUI(int i, int j, int k)
 * - public void displayGUIFurnace(TileEntityFurnace tileentityfurnace)
 * - public void displayGUIDispenser(TileEntityDispenser tileentitydispenser)
 * - public void onItemPickup(Entity entity, int i)
 * - public int getPlayerArmorValue()
 * - public void sendChatMessage(String s)
 * - public boolean isSneaking()
 * - public void setHealth(int i)
 * - public void respawnPlayer()
 * - public void func_6420_o()
 * - public void addChatMessage(String s)
 * - public void addStat(StatBase statbase, int i)
 * - private boolean isBlockTranslucent(int i, int j, int k)
 * - protected boolean pushOutOfBlocks(double d, double d1, double d2)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <math.h>
#include <string.h>

static int CloneMCJ_Gameplay_SynchronizeChunkEntities(CloneMCJ_GameplayState *,int);
static int CloneMCJ_Gameplay_AddEntityToLoadedChunk(CloneMCJ_World *,void *,
    CloneMCJ_Entity *);
static void CloneMCJ_Gameplay_UpdateDroppedItemChunk(CloneMCJ_GameplayState *,
    CloneMCJ_EntityItem *);

static int CloneMCJ_Gameplay_WriteEntityHook(void *entity, CloneMCJ_NBTTagCompound *compound, void *userData)
{
    CloneMCJ_GameplayState *state;
    int i;
    state=(CloneMCJ_GameplayState *)userData;if(!state||!entity||!compound)return 0;
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(entity==&state->droppedItems[i])
        return CloneMCJ_EntityItem_WriteNBT(&state->droppedItems[i],compound);
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(entity==&state->mobs[i])
        return CloneMCJ_Mob_WriteNBT(&state->mobs[i],compound);
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(entity==&state->projectiles[i]&&
        state->projectiles[i].type!=CLONEMC_J_PROJECTILE_FISHING)
        return CloneMCJ_Projectile_WriteNBT(&state->projectiles[i],compound);
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(entity==&state->vehicles[i])
        return CloneMCJ_Vehicle_WriteNBT(&state->vehicles[i],compound);
    return 0;
}

static void *CloneMCJ_Gameplay_ReadEntityHook(const CloneMCJ_NBTTagCompound *compound, void *userData)
{
    CloneMCJ_GameplayState *state;
    const char *id;
    int i,entityID;
    CloneMCJ_MobType mobType;
    state = (CloneMCJ_GameplayState *)userData;
    if (!state || !compound) return (void *)0;
    id = CloneMCJ_NBTTagCompound_GetString(compound, "id");
    if(!id)return (void *)0;
    entityID=CloneMCJ_NBTTagCompound_GetInteger(compound,"EntityId");
    if(entityID>0){
        for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)
            if(state->droppedItems[i].active&&
               state->droppedItems[i].entity.entityId==entityID){
                CloneMCJ_Entity *entity;
                entity=&state->droppedItems[i].entity;
                entity->chunkCoordX=CloneMCJava_FloorDouble(entity->posX/16.0);
                entity->chunkCoordY=CloneMCJava_FloorDouble(entity->posY/16.0);
                if(entity->chunkCoordY<0)entity->chunkCoordY=0;
                if(entity->chunkCoordY>=CLONEMC_J_CHUNK_ENTITY_SLICES)
                    entity->chunkCoordY=CLONEMC_J_CHUNK_ENTITY_SLICES-1;
                entity->chunkCoordZ=CloneMCJava_FloorDouble(entity->posZ/16.0);
                /* ChunkLoader adds this returned pointer immediately after
                 * the hook. Marking membership now prevents a second copy on
                 * the first resumed item tick. */
                entity->addedToChunk=1;
                return &state->droppedItems[i];
            }
        for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&state->mobs[i].entity.entityId==entityID)return &state->mobs[i];
        for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(state->projectiles[i].active&&state->projectiles[i].entity.entityId==entityID)return &state->projectiles[i];
        for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(state->vehicles[i].active&&state->vehicles[i].entity.entityId==entityID)return &state->vehicles[i];
    }
    if(!strcmp(id,"Item"))for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(!state->droppedItems[i].active){
        if(CloneMCJ_EntityItem_ReadNBT(&state->droppedItems[i],compound,state->world)){if(i>=state->droppedItemCount)state->droppedItemCount=i+1;return &state->droppedItems[i];}return (void *)0;}
    if(CloneMCJ_EntityList_MobTypeForName(id,&mobType))for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(!state->mobs[i].active){
        if(CloneMCJ_Mob_ReadNBT(&state->mobs[i],compound,state->world)){if(i>=state->mobCount)state->mobCount=i+1;return &state->mobs[i];}return (void *)0;}
    if(!strcmp(id,"Arrow")||!strcmp(id,"Snowball")||!strcmp(id,"Egg")||!strcmp(id,"Fireball"))
        for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(!state->projectiles[i].active){if(CloneMCJ_Projectile_ReadNBT(&state->projectiles[i],compound,state->world)){if(i>=state->projectileCount)state->projectileCount=i+1;return &state->projectiles[i];}return (void *)0;}
    if(!strcmp(id,"Boat")||!strcmp(id,"Minecart")||!strcmp(id,"PrimedTnt")||!strcmp(id,"FallingSand")||!strcmp(id,"Painting"))
        for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(!state->vehicles[i].active){if(CloneMCJ_Vehicle_ReadNBT(&state->vehicles[i],compound,state->world)){if(i>=state->vehicleCount)state->vehicleCount=i+1;return &state->vehicles[i];}return (void *)0;}
    return (void *)0;
}

static double CloneMCJ_Gameplay_GetEntityYHook(void *entity, void *userData)
{
    (void)userData;
    return entity ? ((CloneMCJ_Entity *)entity)->posY : 0.0;
}

static int CloneMCJ_Gameplay_WriteTileHook(void *tile, CloneMCJ_NBTTagCompound *compound, void *userData)
{
    (void)userData;
    return CloneMCJ_TileEntity_WriteNBT((CloneMCJ_TileEntity *)tile, compound);
}

static void *CloneMCJ_Gameplay_ReadTileHook(const CloneMCJ_NBTTagCompound *compound, void *userData)
{
    CloneMCJ_GameplayState *state;
    state = (CloneMCJ_GameplayState *)userData;
    return state ? CloneMCJ_TileEntity_ReadNBT(compound, state->world) : (void *)0;
}

void CloneMCJ_Gameplay_QueueBlockBreakEvent(CloneMCJ_GameplayState *state,int blockID,int metadata,int x,int y,int z)
{
    unsigned long sequence;CloneMCJ_BlockBreakEvent *event;
    if(!state||blockID<=0)return;
    sequence=++state->blockBreakEventSequence;
    event=&state->blockBreakEvents[(sequence-1UL)%CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY];
    event->sequence=sequence;event->blockID=blockID;event->metadata=metadata;
    event->x=x;event->y=y;event->z=z;
}

int CloneMCJ_Gameplay_GetBlockBreakEvent(const CloneMCJ_GameplayState *state,
    unsigned long sequence,CloneMCJ_BlockBreakEvent *eventOut)
{
    const CloneMCJ_BlockBreakEvent *event;
    if(!state||!eventOut||sequence==0UL||sequence>state->blockBreakEventSequence)return 0;
    event=&state->blockBreakEvents[(sequence-1UL)%CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY];
    if(event->sequence!=sequence)return 0;*eventOut=*event;return 1;
}

void CloneMCJ_Gameplay_Initialize(CloneMCJ_GameplayState *state, CloneMCJ_World *world, const char *username)
{
    CloneMCJ_McRegionChunkLoader *loader;
    CloneMCJ_Chunk *chunk;
    int slot;
    if (!state) return;
    memset(state, 0, sizeof(*state));
    state->world = world;
    CloneMCJ_BlockRegistry_Initialize();
    CloneMCJ_ItemRegistry_Initialize();
    CloneMCJ_CraftingManager_InitializeNative();
    CloneMCJ_Container_Initialize(&state->openContainer);
    CloneMCJ_InventoryCrafting_Initialize(&state->openCraftMatrix, 2, 2);
    CloneMCJ_InventoryCraftResult_Initialize(&state->openCraftResult);
    CloneMCJ_EntityPlayer_Initialize(&state->player, world, username);
    state->nextEntityId=state->player.entity.entityId+1;
    if (world && world->worldInfo.playerTag)
        CloneMCJ_EntityPlayer_ReadNBT(&state->player, (CloneMCJ_NBTTagCompound *)world->worldInfo.playerTag);
    /* Entity_ReadNBT sets the authoritative current transform.  Synchronize the
     * interpolation endpoints before the first rendered frame and move the
     * chunk streamer from spawn to the saved player location immediately. */
    state->player.entity.prevPosX=state->player.entity.posX;
    state->player.entity.prevPosY=state->player.entity.posY;
    state->player.entity.prevPosZ=state->player.entity.posZ;
    state->player.entity.prevRotationYaw=state->player.entity.rotationYaw;
    state->player.entity.prevRotationPitch=state->player.entity.rotationPitch;
    if(world)CloneMCJ_World_SetPlayerGlobalPosition(world,state->player.entity.posX,
        state->player.entity.posZ);
    CloneMCJ_PlayerControllerSP_Initialize(&state->controller, world, &state->player);
    if (world) {
        CloneMCJ_World_SetGameplayHooks(world, CloneMCJ_Gameplay_Tick, CloneMCJ_Gameplay_PrepareSave, state);
        CloneMCJ_World_SetGameplayDimensionHook(world,CloneMCJ_Gameplay_OnDimensionChanged);
        CloneMCJ_BlockButton_RegisterRuntime(world);
    }
    CloneMCJ_Gameplay_AttachSaveHooks(state);
    /* World construction prepares the spawn window before the player runtime is
     * attached.  Re-read only already-loaded saved chunks after installing the
     * entity factory so their Entities list is not silently discarded. */
    loader=world&&world->saveHandler?CloneMCJ_SaveHandler_GetChunkLoader(
        world->saveHandler,world->worldInfo.dimension):(CloneMCJ_McRegionChunkLoader *)0;
    if(loader)for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot)
        if(world->chunkProvider.slots[slot].used&&world->chunkProvider.slots[slot].chunk){
            chunk=world->chunkProvider.slots[slot].chunk;
            CloneMCJ_McRegionChunkLoader_Load(loader,chunk,chunk->xPosition,chunk->zPosition);
        }
}

void CloneMCJ_Gameplay_Destroy(CloneMCJ_GameplayState *state)
{
    CloneMCJ_ChunkSerializationHooks hooks;
    CloneMCJ_McRegionChunkLoader *loader;
    if (!state) return;
    if (state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    if (state->world) {
        CloneMCJ_World_SetGameplayHooks(state->world, (CloneMCJ_GameplayTickProc)0,
            (CloneMCJ_GameplayPrepareSaveProc)0, (void *)0);
        CloneMCJ_World_SetGameplayDimensionHook(state->world,(CloneMCJ_GameplayDimensionProc)0);
        if (state->world->saveHandler) {
            loader = CloneMCJ_SaveHandler_GetChunkLoader(state->world->saveHandler,
                state->world->worldInfo.dimension);
            if (loader) {
                memset(&hooks, 0, sizeof(hooks));
                CloneMCJ_McRegionChunkLoader_SetHooks(loader, &hooks);
            }
        }
    }
    memset(state, 0, sizeof(*state));
}

void CloneMCJ_Gameplay_SetInput(CloneMCJ_GameplayState *state, float strafe, float forward,
                                int jump, int sneak, int attack, int use)
{
    if (!state) return;
    CloneMCJ_EntityPlayer_SetInput(&state->player, strafe, forward, jump, sneak);
    state->attackInput = (unsigned char)(attack != 0);
    state->useInput = (unsigned char)(use != 0);
}

void CloneMCJ_Gameplay_AddLook(CloneMCJ_GameplayState *state, float yawDelta, float pitchDelta)
{
    float yaw, pitch;
    if (!state) return;
    yaw = state->player.entity.rotationYaw + yawDelta;
    pitch = state->player.entity.rotationPitch + pitchDelta;
    CloneMCJ_Entity_SetRotation(&state->player.entity, yaw, pitch);
}

int CloneMCJ_Gameplay_SpawnDrop(CloneMCJ_GameplayState *state, double x, double y, double z,
                                const CloneMCJ_ItemStack *stack, int pickupDelay, int directed)
{
    CloneMCJ_EntityItem *drop;
    float yaw, pitch;
    double speed;
    int i;
    if (!state || CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    for (i = 0; i < CLONEMC_J_MAX_DROPPED_ITEMS; ++i) if (!state->droppedItems[i].active) break;
    if (i >= CLONEMC_J_MAX_DROPPED_ITEMS) return 0;
    drop = &state->droppedItems[i];
    CloneMCJ_EntityItem_Initialize(drop, state->world, x, y, z, stack);
    drop->delayBeforeCanPickup = pickupDelay;
    if (directed) {
        yaw = state->player.entity.rotationYaw * 3.14159265358979323846F / 180.0F;
        pitch = state->player.entity.rotationPitch * 3.14159265358979323846F / 180.0F;
        speed = 0.3;
        drop->entity.motionX = -(double)sin(yaw) * (double)cos(pitch) * speed;
        drop->entity.motionZ = (double)cos(yaw) * (double)cos(pitch) * speed;
        drop->entity.motionY = -(double)sin(pitch) * speed + 0.1;
        drop->entity.motionX += (CloneMCJavaRandom_NextFloat(&state->player.entity.rand) - 0.5F) * 0.02;
        drop->entity.motionY += (CloneMCJavaRandom_NextFloat(&state->player.entity.rand) - 0.5F) * 0.02;
        drop->entity.motionZ += (CloneMCJavaRandom_NextFloat(&state->player.entity.rand) - 0.5F) * 0.02;
    }
    if (i >= state->droppedItemCount) state->droppedItemCount = i + 1;
    if(state->world&&CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,
            drop,&drop->entity)){
        CloneMCJ_Chunk *chunk;
        chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(state->world,
            drop->entity.chunkCoordX,drop->entity.chunkCoordZ);
        if(chunk)CloneMCJ_Chunk_SetModified(chunk);
    }
    return 1;
}

static int CloneMCJ_Gameplay_SpawnDeathDrop(CloneMCJ_GameplayState *state,
    const CloneMCJ_ItemStack *stack)
{
    CloneMCJ_EntityItem *drop;double speed,angle;int slot;
    if(!state||CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    for(slot=0;slot<CLONEMC_J_MAX_DROPPED_ITEMS;++slot)
        if(!state->droppedItems[slot].active)break;
    if(slot>=CLONEMC_J_MAX_DROPPED_ITEMS)return 0;
    if(!CloneMCJ_Gameplay_SpawnDrop(state,state->player.entity.posX,
        state->player.entity.posY+0.5,state->player.entity.posZ,stack,40,0))return 0;
    /* EntityPlayer.dropPlayerItemWithRandomChoice(stack, true): death loot is
     * scattered around the body instead of fired along the player's look ray. */
    drop=&state->droppedItems[slot];
    speed=(double)CloneMCJavaRandom_NextFloat(&state->player.entity.rand)*0.5;
    angle=(double)CloneMCJavaRandom_NextFloat(&state->player.entity.rand)*
        6.28318530717958647692;
    drop->entity.motionX=-sin(angle)*speed;
    drop->entity.motionZ=cos(angle)*speed;
    drop->entity.motionY=0.2;
    return 1;
}

int CloneMCJ_Gameplay_DropCurrentItem(CloneMCJ_GameplayState *state, int wholeStack)
{
    CloneMCJ_ItemStack *current;
    CloneMCJ_ItemStack dropped;
    if (!state) return 0;
    if(state->world&&state->world->multiplayerWorld&&state->sendDigIntent)
        return state->sendDigIntent(state->multiplayerController,4,0,0,0,0);
    current = CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if (CloneMCJ_ItemStack_IsEmpty(current)) return 0;
    dropped = CloneMCJ_ItemStack_Split(current, wholeStack ? current->stackSize : 1);
    if (!CloneMCJ_Gameplay_SpawnDrop(state, state->player.entity.posX,
        state->player.entity.posY + 1.32, state->player.entity.posZ, &dropped, 40, 1)) {
        CloneMCJ_InventoryPlayer_AddItemStack(&state->player.inventory, &dropped);
        return 0;
    }
    return 1;
}

void CloneMCJ_Gameplay_HandlePlayerDeath(CloneMCJ_GameplayState *state)
{
    CloneMCJ_InventoryPlayer *inventory;
    CloneMCJ_ItemStack dropped;
    int i;
    if(!state||!state->world||state->world->multiplayerWorld||state->deathHandled)return;
    inventory=&state->player.inventory;
    /* EntityPlayer.onDeath -> InventoryPlayer.dropAllItems.  Each complete
     * stack becomes a world entity and the inventory slot is cleared only
     * after the drop was accepted. */
    for(i=0;i<CLONEMC_J_MAIN_INVENTORY_SIZE;++i)
        if(!CloneMCJ_ItemStack_IsEmpty(&inventory->mainInventory[i])){
            dropped=inventory->mainInventory[i];
            if(CloneMCJ_Gameplay_SpawnDeathDrop(state,&dropped))
                CloneMCJ_ItemStack_Clear(&inventory->mainInventory[i]);
        }
    for(i=0;i<CLONEMC_J_ARMOR_INVENTORY_SIZE;++i)
        if(!CloneMCJ_ItemStack_IsEmpty(&inventory->armorInventory[i])){
            dropped=inventory->armorInventory[i];
            if(CloneMCJ_Gameplay_SpawnDeathDrop(state,&dropped))
                CloneMCJ_ItemStack_Clear(&inventory->armorInventory[i]);
        }
    if(!CloneMCJ_ItemStack_IsEmpty(&inventory->carriedStack)){
        dropped=inventory->carriedStack;
        if(CloneMCJ_Gameplay_SpawnDeathDrop(state,&dropped))
            CloneMCJ_ItemStack_Clear(&inventory->carriedStack);
    }
    /* Attach new item entities to their chunks immediately.  This makes the
     * chunk dirty before respawn/recentering or an emergency save can evict it,
     * so the five-minute Java item lifetime is preserved across respawn/save. */
    (void)CloneMCJ_Gameplay_SynchronizeChunkEntities(state,1);
    state->player.ridingEntityId=0;
    state->player.entity.entityRiderYawDelta=0.0;
    state->player.entity.entityRiderPitchDelta=0.0;
    state->player.entity.motionX=0.0;state->player.entity.motionY=0.1;
    state->player.entity.motionZ=0.0;state->deathHandled=1;
}

void CloneMCJ_Gameplay_RespawnPlayer(CloneMCJ_GameplayState *state)
{
    char username[64];
    int score;
    unsigned long picked,mined,placed,activated;
    int minedID,minedMeta,minedX,minedY,minedZ;
    int placedID,placedMeta,placedX,placedY,placedZ;
    int activatedID,activatedMeta,activatedX,activatedY,activatedZ;
    if(!state||!state->world)return;
    strncpy(username,state->player.username,sizeof(username)-1);
    username[sizeof(username)-1]='\0';score=state->player.score;
    picked=state->player.itemsPickedUp;mined=state->player.blocksMined;
    placed=state->player.blocksPlaced;activated=state->player.blocksActivated;
    minedID=state->player.lastMinedBlockID;minedMeta=state->player.lastMinedMetadata;
    minedX=state->player.lastMinedX;minedY=state->player.lastMinedY;minedZ=state->player.lastMinedZ;
    placedID=state->player.lastPlacedBlockID;placedMeta=state->player.lastPlacedMetadata;
    placedX=state->player.lastPlacedX;placedY=state->player.lastPlacedY;placedZ=state->player.lastPlacedZ;
    activatedID=state->player.lastActivatedBlockID;activatedMeta=state->player.lastActivatedMetadata;
    activatedX=state->player.lastActivatedX;activatedY=state->player.lastActivatedY;activatedZ=state->player.lastActivatedZ;
    CloneMCJ_EntityPlayer_Initialize(&state->player,state->world,username);
    state->player.score=score;state->player.itemsPickedUp=picked;
    state->player.blocksMined=mined;state->player.blocksPlaced=placed;
    state->player.blocksActivated=activated;
    state->player.lastMinedBlockID=minedID;state->player.lastMinedMetadata=minedMeta;
    state->player.lastMinedX=minedX;state->player.lastMinedY=minedY;state->player.lastMinedZ=minedZ;
    state->player.lastPlacedBlockID=placedID;state->player.lastPlacedMetadata=placedMeta;
    state->player.lastPlacedX=placedX;state->player.lastPlacedY=placedY;state->player.lastPlacedZ=placedZ;
    state->player.lastActivatedBlockID=activatedID;state->player.lastActivatedMetadata=activatedMeta;
    state->player.lastActivatedX=activatedX;state->player.lastActivatedY=activatedY;state->player.lastActivatedZ=activatedZ;
    CloneMCJ_PlayerControllerSP_Initialize(&state->controller,state->world,&state->player);
    if(state->player.entity.entityId>=state->nextEntityId)
        state->nextEntityId=state->player.entity.entityId+1;
    state->attackInput=state->useInput=state->previousAttack=state->previousUse=0;
    state->intentDigging=0;state->deathHandled=0;
    CloneMCJ_World_SetPlayerGlobalPosition(state->world,state->player.entity.posX,
        state->player.entity.posZ);
}

static int CloneMCJ_Gameplay_BlockRayBox(double ox,double oy,double oz,
    double dx,double dy,double dz,const CloneMCAxisAlignedBB *box,
    double limit,double *hitDistance,int *hitSide)
{
    double minimum,maximum,t1,t2,inverse;
    int axis,nearSide,farSide,entrySide;
    double origins[3],directions[3],mins[3],maxs[3];
    origins[0]=ox;origins[1]=oy;origins[2]=oz;
    directions[0]=dx;directions[1]=dy;directions[2]=dz;
    mins[0]=box->minX;mins[1]=box->minY;mins[2]=box->minZ;
    maxs[0]=box->maxX;maxs[1]=box->maxY;maxs[2]=box->maxZ;
    minimum=0.0;maximum=limit;entrySide=-1;
    for(axis=0;axis<3;++axis){
        if(directions[axis]>-0.0000001&&directions[axis]<0.0000001){
            if(origins[axis]<mins[axis]||origins[axis]>maxs[axis])return 0;
        }else{
            inverse=1.0/directions[axis];
            t1=(mins[axis]-origins[axis])*inverse;
            t2=(maxs[axis]-origins[axis])*inverse;
            nearSide=axis==0?4:(axis==1?0:2);
            farSide=axis==0?5:(axis==1?1:3);
            if(t1>t2){
                double swap;
                int swapSide;
                swap=t1;t1=t2;t2=swap;
                swapSide=nearSide;nearSide=farSide;farSide=swapSide;
            }
            if(t1>minimum){minimum=t1;entrySide=nearSide;}
            if(t2<maximum)maximum=t2;
            if(maximum<minimum)return 0;
        }
    }
    if(minimum<0.0||minimum>limit||maximum<0.0)return 0;
    if(hitDistance)*hitDistance=minimum;
    if(hitSide)*hitSide=entrySide;
    return 1;
}

CloneMCJ_MovingObjectPosition CloneMCJ_Gameplay_RayTrace(const CloneMCJ_EntityPlayer *player, double distance)
{
    CloneMCJ_MovingObjectPosition result;
    CloneMCAxisAlignedBB selection;
    double yaw,pitch,lookX,lookY,lookZ,eyeX,eyeY,eyeZ,hitDistance;
    double endX,endY,endZ,boundary,tMaxX,tMaxY,tMaxZ;
    double tDeltaX,tDeltaY,tDeltaZ;
    int x,y,z,endCellX,endCellY,endCellZ,stepX,stepY,stepZ;
    int blockID,iteration,hitSide;
    memset(&result, 0, sizeof(result));
    result.sideHit = -1;
    if (!player || !player->entity.worldObj || distance <= 0.0) return result;
    yaw = player->entity.rotationYaw * 3.14159265358979323846 / 180.0;
    pitch = player->entity.rotationPitch * 3.14159265358979323846 / 180.0;
    lookX = -sin(yaw) * cos(pitch);
    lookY = -sin(pitch);
    lookZ = cos(yaw) * cos(pitch);
    eyeX = player->entity.posX;
    eyeY = player->entity.posY + 1.62;
    eyeZ = player->entity.posZ;
    endX=eyeX+lookX*distance;
    endY=eyeY+lookY*distance;
    endZ=eyeZ+lookZ*distance;
    x=CloneMCJava_FloorDouble(eyeX);
    y=CloneMCJava_FloorDouble(eyeY);
    z=CloneMCJava_FloorDouble(eyeZ);
    endCellX=CloneMCJava_FloorDouble(endX);
    endCellY=CloneMCJava_FloorDouble(endY);
    endCellZ=CloneMCJava_FloorDouble(endZ);
    stepX=lookX>0.0?1:(lookX<0.0?-1:0);
    stepY=lookY>0.0?1:(lookY<0.0?-1:0);
    stepZ=lookZ>0.0?1:(lookZ<0.0?-1:0);
    if(stepX){boundary=(double)(stepX>0?x+1:x);
        tMaxX=(boundary-eyeX)/lookX;tDeltaX=1.0/fabs(lookX);}
    else tMaxX=tDeltaX=999.0;
    if(stepY){boundary=(double)(stepY>0?y+1:y);
        tMaxY=(boundary-eyeY)/lookY;tDeltaY=1.0/fabs(lookY);}
    else tMaxY=tDeltaY=999.0;
    if(stepZ){boundary=(double)(stepZ>0?z+1:z);
        tMaxZ=(boundary-eyeZ)/lookZ;tDeltaZ=1.0/fabs(lookZ);}
    else tMaxZ=tDeltaZ=999.0;
    /* Direct World.func_28105_a-style cell traversal.  This replaces the
     * former 0.025-block floating-point sampler (up to 201 iterations for a
     * five-block reach) while keeping partial-block selection bounds exact. */
    for(iteration=0;iteration<=200;++iteration){
        blockID = CloneMCJ_World_GetBlockId(player->entity.worldObj, x, y, z);
        /* Block.rayTrace uses selection bounds, not the collision box.
         * Flowers, mushrooms, tall grass, wire, torches and signs deliberately
         * have no collision box but must still be mineable and selectable. */
        if (blockID != 0 && blockID != 8 && blockID != 9 &&
            blockID != 10 && blockID != 11 && blockID != 51 && blockID != 90) {
            if(!CloneMCJ_Block_GetSelectionBox(player->entity.worldObj,x,y,z,
                    &selection)||
               !CloneMCJ_Gameplay_BlockRayBox(eyeX,eyeY,eyeZ,lookX,lookY,lookZ,
                    &selection,distance,&hitDistance,&hitSide)){
                /* The ray crossed this cell but missed its partial bounds. */
            }else{
                result.hit = 1;
                result.blockX = x; result.blockY = y; result.blockZ = z;
                result.sideHit=hitSide;
                result.hitVec.xCoord=eyeX+lookX*hitDistance;
                result.hitVec.yCoord=eyeY+lookY*hitDistance;
                result.hitVec.zCoord=eyeZ+lookZ*hitDistance;
                return result;
            }
        }
        if(x==endCellX&&y==endCellY&&z==endCellZ)break;
        if(tMaxX<tMaxY&&tMaxX<tMaxZ){
            if(tMaxX>distance)break;x+=stepX;tMaxX+=tDeltaX;
        }else if(tMaxY<tMaxZ){
            if(tMaxY>distance)break;y+=stepY;tMaxY+=tDeltaY;
        }else{
            if(tMaxZ>distance)break;z+=stepZ;tMaxZ+=tDeltaZ;
        }
    }
    return result;
}

static int CloneMCJ_Gameplay_RayBox(double ox,double oy,double oz,double dx,double dy,double dz,
    const CloneMCAxisAlignedBB *box,double limit,double *hitDistance)
{
    double minimum,maximum,t1,t2,inverse;
    int axis;
    double origins[3],directions[3],mins[3],maxs[3];
    origins[0]=ox;origins[1]=oy;origins[2]=oz;
    directions[0]=dx;directions[1]=dy;directions[2]=dz;
    mins[0]=box->minX-0.3;mins[1]=box->minY-0.3;mins[2]=box->minZ-0.3;
    maxs[0]=box->maxX+0.3;maxs[1]=box->maxY+0.3;maxs[2]=box->maxZ+0.3;
    minimum=0.0;maximum=limit;
    for(axis=0;axis<3;++axis){
        if(directions[axis]>-0.0000001&&directions[axis]<0.0000001){
            if(origins[axis]<mins[axis]||origins[axis]>maxs[axis])return 0;
        }else{
            inverse=1.0/directions[axis];
            t1=(mins[axis]-origins[axis])*inverse;t2=(maxs[axis]-origins[axis])*inverse;
            if(t1>t2){double swap;swap=t1;t1=t2;t2=swap;}
            if(t1>minimum)minimum=t1;
            if(t2<maximum)maximum=t2;
            if(maximum<minimum)return 0;
        }
    }
    if(hitDistance)*hitDistance=minimum;
    return minimum<=limit&&maximum>=0.0;
}

int CloneMCJ_Gameplay_FindTargetMob(const CloneMCJ_GameplayState *state,double distance,
    double *hitDistance)
{
    const CloneMCJ_EntityPlayer *player;
    double yaw,pitch,lookX,lookY,lookZ,eyeX,eyeY,eyeZ;
    double nearest,hit;
    CloneMCAxisAlignedBB targetBox;
    int index,best;
    if(hitDistance)*hitDistance=distance;
    if(!state||distance<=0.0)return -1;
    player=&state->player;
    yaw=player->entity.rotationYaw*3.14159265358979323846/180.0;
    pitch=player->entity.rotationPitch*3.14159265358979323846/180.0;
    lookX=-sin(yaw)*cos(pitch);lookY=-sin(pitch);lookZ=cos(yaw)*cos(pitch);
    eyeX=player->entity.posX;eyeY=player->entity.posY+1.62;eyeZ=player->entity.posZ;
    nearest=distance;best=-1;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index){
        if(!state->mobs[index].active||state->mobs[index].health<=0)continue;
        targetBox=CloneMCAABB_Expand(&state->mobs[index].entity.boundingBox,0.1,0.1,0.1);
        if(CloneMCJ_Gameplay_RayBox(eyeX,eyeY,eyeZ,lookX,lookY,lookZ,
            &targetBox,nearest,&hit)){
            nearest=hit;best=index;
        }
    }
    if(hitDistance)*hitDistance=nearest;
    return best;
}

static int CloneMCJ_Gameplay_FindTargetVehicle(const CloneMCJ_GameplayState *state,
    double distance,double *hitDistance)
{
    const CloneMCJ_EntityPlayer *player;double yaw,pitch,lookX,lookY,lookZ,eyeX,eyeY,eyeZ;
    double nearest,hit;CloneMCAxisAlignedBB box;int index,best;
    if(hitDistance)*hitDistance=distance;
    if(!state||distance<=0.0)return -1;
    player=&state->player;
    yaw=player->entity.rotationYaw*3.14159265358979323846/180.0;pitch=player->entity.rotationPitch*3.14159265358979323846/180.0;
    lookX=-sin(yaw)*cos(pitch);lookY=-sin(pitch);lookZ=cos(yaw)*cos(pitch);eyeX=player->entity.posX;eyeY=player->entity.posY+1.62;eyeZ=player->entity.posZ;
    nearest=distance;best=-1;for(index=0;index<CLONEMC_J_MAX_VEHICLES;++index){if(!state->vehicles[index].active||
        state->vehicles[index].type==CLONEMC_J_VEHICLE_LIGHTNING)continue;
        box=CloneMCAABB_Expand(&state->vehicles[index].entity.boundingBox,0.1,0.1,0.1);
        if(CloneMCJ_Gameplay_RayBox(eyeX,eyeY,eyeZ,lookX,lookY,lookZ,&box,nearest,&hit)){nearest=hit;best=index;}}
    if(hitDistance)*hitDistance=nearest;
    return best;
}

static int CloneMCJ_Gameplay_ConsumeItem(CloneMCJ_InventoryPlayer *inventory,int itemID)
{
    int i;if(!inventory)return 0;for(i=0;i<CLONEMC_J_MAIN_INVENTORY_SIZE;++i)
        if(!CloneMCJ_ItemStack_IsEmpty(&inventory->mainInventory[i])&&inventory->mainInventory[i].itemID==itemID){
            if(--inventory->mainInventory[i].stackSize<=0)CloneMCJ_ItemStack_Clear(&inventory->mainInventory[i]);
            inventory->inventoryChanged=1;return 1;}
    return 0;
}

static int CloneMCJ_Gameplay_UseEntityItem(CloneMCJ_GameplayState *state,
    const CloneMCJ_MovingObjectPosition *target)
{
    CloneMCJ_ItemStack *held;int x,y,z,id,i,result;
    if(!state)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    if(CloneMCJ_ItemStack_IsEmpty(held))return 0;
    id=held->itemID;
    /* Requested convenience: right-clicking an armor piece equips it into the
     * matching empty SlotArmor destination. The type/slot mapping comes from
     * the uploaded ItemArmor and ContainerPlayer classes. */
    if(CloneMCJ_ItemArmor_EquipRightClickNative(&state->player.inventory,held))
        return 1;
    if(id==325||id==326||id==327){
        if(CloneMCJ_ItemBucket_UseNative(state->world,&state->player,held)){
            state->player.inventory.inventoryChanged=1;return 1;
        }
        return 0;
    }
    if(id==261){if(!CloneMCJ_Gameplay_ConsumeItem(&state->player.inventory,262))return 0;
        CloneMCJ_Gameplay_SpawnProjectile(state,CLONEMC_J_PROJECTILE_ARROW,&state->player.entity,1.5F,1.0F);CloneMCJ_ItemStack_Damage(held,1);return 1;}
    if(id==332||id==344){if(!CloneMCJ_Gameplay_SpawnProjectile(state,id==332?CLONEMC_J_PROJECTILE_SNOWBALL:CLONEMC_J_PROJECTILE_EGG,&state->player.entity,1.5F,1.0F))return 0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        return 1;}
    if(id==346){for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(state->projectiles[i].active&&
            state->projectiles[i].type==CLONEMC_J_PROJECTILE_FISHING&&
            state->projectiles[i].ownerEntityId==state->player.entity.entityId)break;
        if(i<CLONEMC_J_MAX_PROJECTILES){result=CloneMCJ_EntityFish_Catch(&state->projectiles[i],state);
            if(result>0)CloneMCJ_ItemStack_Damage(held,result);
            return 1;}
        return CloneMCJ_Gameplay_SpawnProjectile(state,CLONEMC_J_PROJECTILE_FISHING,
            &state->player.entity,1.5F,1.0F);}
    if(!target||!target->hit)return 0;
    x=target->blockX;y=target->blockY;z=target->blockZ;
    if(id==295){
        if(!CloneMCJ_ItemSeeds_UseNative(state->world,held,x,y,z,target->sideHit))return 0;
        state->player.inventory.inventoryChanged=1;return 1;
    }
    if(id==351){
        if(!CloneMCJ_ItemDye_UseNative(state->world,held,x,y,z,
            target->sideHit))return 0;
        state->player.inventory.inventoryChanged=1;return 1;
    }
    if(id==333){if(target->sideHit==0)--y;else if(target->sideHit==1)++y;else if(target->sideHit==2)--z;else if(target->sideHit==3)++z;else if(target->sideHit==4)--x;else if(target->sideHit==5)++x;
        if(!CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_BOAT,(double)x+0.5,(double)y+1.0,(double)z+0.5,0))return 0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;}
    if((id==328||id==342||id==343)&&
       (CloneMCJ_World_GetBlockId(state->world,x,y,z)==66||
        CloneMCJ_World_GetBlockId(state->world,x,y,z)==27||
        CloneMCJ_World_GetBlockId(state->world,x,y,z)==28)){
        int minecartType;minecartType=id==342?1:(id==343?2:0);
        if(!CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_MINECART,
            (double)x+0.5,(double)y+0.5,(double)z+0.5,minecartType))return 0;
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;}
    if(id==321&&target->sideHit>=2&&target->sideHit<=5){int direction,vehicleSlot;
        direction=target->sideHit==2?0:(target->sideHit==4?1:(target->sideHit==3?2:3));
        if(target->sideHit==2)--z;else if(target->sideHit==3)++z;else if(target->sideHit==4)--x;else ++x;
        if(!CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_PAINTING,(double)x+0.5,(double)y+0.5,(double)z+0.5,0))return 0;
        for(vehicleSlot=0;vehicleSlot<CLONEMC_J_MAX_VEHICLES;++vehicleSlot)if(state->vehicles[vehicleSlot].active&&
            state->vehicles[vehicleSlot].entity.entityId==state->nextEntityId-1)break;
        if(vehicleSlot>=CLONEMC_J_MAX_VEHICLES||!CloneMCJ_Vehicle_ConfigurePainting(
            &state->vehicles[vehicleSlot],direction,x,y,z)){
            if(vehicleSlot<CLONEMC_J_MAX_VEHICLES)state->vehicles[vehicleSlot].active=0;
            return 0;}
        if(--held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
        state->player.inventory.inventoryChanged=1;
        return 1;}
    if(id==259){
        if(CloneMCJ_World_GetBlockId(state->world,x,y,z)==46){CloneMCJ_World_SetBlock(state->world,x,y,z,0);
            CloneMCJ_Gameplay_SpawnVehicle(state,CLONEMC_J_VEHICLE_PRIMED_TNT,(double)x+0.5,(double)y+0.5,(double)z+0.5,0);
            CloneMCJ_ItemStack_Damage(held,1);return 1;}
        return CloneMCJ_ItemFlintAndSteel_UseNative(state->world,held,
            &state->player,x,y,z,target->sideHit);
    }
    return 0;
}

static void CloneMCJ_Gameplay_SpawnMobLoot(CloneMCJ_GameplayState *state,CloneMCJ_Mob *mob)
{
    CloneMCJ_ItemStack stack;
    int item,count,index,metadata,slot,size;
    if(!state||!mob||mob->lootDropped)return;
    mob->lootDropped=1;item=0;count=0;metadata=0;
    switch(mob->type){
    case CLONEMC_J_MOB_PIG:item=mob->entity.fire>0?320:319;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_SHEEP:if(!mob->sheared){item=35;count=1;metadata=mob->woolColor&15;}break;
    case CLONEMC_J_MOB_COW:item=334;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_CHICKEN:item=288;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_ZOMBIE:
    case CLONEMC_J_MOB_GIANT:item=288;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_GHAST:item=289;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_PIG_ZOMBIE:item=320;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_SKELETON:
        count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);
        for(index=0;index<count;++index){CloneMCJ_ItemStack_Initialize(&stack,262,1,0);
            CloneMCJ_Gameplay_SpawnDrop(state,mob->entity.posX,mob->entity.posY,mob->entity.posZ,&stack,10,0);}
        item=352;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_CREEPER:
        if(mob->killedBySkeleton){item=2256+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,2);count=1;}
        else{item=289;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);}
        break;
    case CLONEMC_J_MOB_SPIDER:item=287;count=CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    case CLONEMC_J_MOB_SLIME:
        if(mob->slimeSize==1){item=341;count=1;}
        else{size=mob->slimeSize/2;for(index=0;index<4;++index){for(slot=0;slot<CLONEMC_J_MAX_MOBS;++slot)if(!state->mobs[slot].active)break;
            if(slot>=CLONEMC_J_MAX_MOBS)break;
            CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot],CLONEMC_J_MOB_SLIME,state->world,
                mob->entity.posX+(double)((index&1)?size:-size)*0.25,mob->entity.posY+0.5,
                mob->entity.posZ+(double)((index&2)?size:-size)*0.25);CloneMCJ_EntitySlime_SetSizeNative(&state->mobs[slot],size);}}
        break;
    case CLONEMC_J_MOB_SQUID:item=351;count=1+CloneMCJavaRandom_NextIntBound(&mob->entity.rand,3);break;
    default:break;
    }
    for(index=0;index<count;++index){
        CloneMCJ_ItemStack_Initialize(&stack,item,1,metadata);
        CloneMCJ_Gameplay_SpawnDrop(state,mob->entity.posX,mob->entity.posY,
            mob->entity.posZ,&stack,10,0);
    }
}

int CloneMCJ_Gameplay_AttackMob(CloneMCJ_GameplayState *state,int mobIndex)
{
    CloneMCJ_Mob *mob;
    CloneMCJ_ItemStack *held;
    const CloneMCJ_ItemDefinition *item;
    int damage,i;
    if(!state||mobIndex<0||mobIndex>=CLONEMC_J_MAX_MOBS)return 0;
    mob=&state->mobs[mobIndex];if(!mob->active||mob->health<=0)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
    item=held&&!CloneMCJ_ItemStack_IsEmpty(held)?CloneMCJ_ItemRegistry_Get(held->itemID):0;
    damage=item?item->damageVsEntity:1;if(damage<1)damage=1;
    if(state->player.entity.motionY<0.0)++damage;
    if(mob->type==CLONEMC_J_MOB_WOLF){mob->sitting=0;if(!mob->tamed){mob->angry=1;mob->hostile=1;}}
    if(mob->type==CLONEMC_J_MOB_WOLF&&!mob->tamed){for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_WOLF&&!state->mobs[i].tamed){
            double wx,wy,wz;wx=state->mobs[i].entity.posX-mob->entity.posX;
            wy=state->mobs[i].entity.posY-mob->entity.posY;wz=state->mobs[i].entity.posZ-mob->entity.posZ;
            if(wx*wx+wy*wy+wz*wz<=256.0){state->mobs[i].angry=1;state->mobs[i].hostile=1;
                state->mobs[i].targetMemoryTicks=200;}}}
    if(mob->type==CLONEMC_J_MOB_PIG_ZOMBIE){for(i=0;i<CLONEMC_J_MAX_MOBS;++i)
        if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_PIG_ZOMBIE){
            double dx,dy,dz;dx=state->mobs[i].entity.posX-mob->entity.posX;
            dy=state->mobs[i].entity.posY-mob->entity.posY;dz=state->mobs[i].entity.posZ-mob->entity.posZ;
            if(dx*dx+dy*dy+dz*dz<=1024.0)CloneMCJ_EntityLiving_AngerPigZombie(&state->mobs[i]);}}
    if(!CloneMCJ_EntityLiving_AttackMobFrom(mob,&state->player.entity,damage))return 0;
    state->player.lastAttackTargetEntityId=mob->entity.entityId;
    if(item&&item->maxDamage>0)CloneMCJ_ItemStack_Damage(held,1);
    if(mob->health<=0)CloneMCJ_Gameplay_SpawnMobLoot(state,mob);
    return 1;
}

int CloneMCJ_Gameplay_InteractMob(CloneMCJ_GameplayState *state,int mobIndex)
{
    CloneMCJ_Mob *mob;
    if(!state||mobIndex<0||mobIndex>=CLONEMC_J_MAX_MOBS)return 0;
    mob=&state->mobs[mobIndex];if(!mob->active||mob->health<=0)return 0;
    if(mob->type==CLONEMC_J_MOB_WOLF)return CloneMCJ_EntityWolf_Interact(mob,&state->player);
    if(mob->type==CLONEMC_J_MOB_SHEEP)
        return CloneMCJ_EntitySheep_InteractNative(state,mob,&state->player);
    if(mob->type==CLONEMC_J_MOB_COW)return CloneMCJ_EntityCow_InteractNative(mob,&state->player);
    if(mob->type==CLONEMC_J_MOB_PIG)return CloneMCJ_EntityPig_InteractNative(mob,&state->player);
    return 0;
}

static CloneMCJ_Mob *CloneMCJ_Gameplay_FindRidingMob(CloneMCJ_GameplayState *state)
{
    int index;
    if(!state||state->player.ridingEntityId==0)return (CloneMCJ_Mob *)0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
        if(state->mobs[index].active&&state->mobs[index].health>0&&
            state->mobs[index].entity.entityId==state->player.ridingEntityId)
            return &state->mobs[index];
    return (CloneMCJ_Mob *)0;
}

static CloneMCJ_Vehicle *CloneMCJ_Gameplay_FindRidingVehicle(CloneMCJ_GameplayState *state)
{
    int index;if(!state||state->player.ridingEntityId==0)return (CloneMCJ_Vehicle *)0;
    for(index=0;index<CLONEMC_J_MAX_VEHICLES;++index)if(state->vehicles[index].active&&
        state->vehicles[index].entity.entityId==state->player.ridingEntityId)return &state->vehicles[index];
    return (CloneMCJ_Vehicle *)0;
}

void CloneMCJ_Gameplay_BeginRidingTickNative(CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_Entity *entity;
    if(!player)return;
    entity=&player->entity;
    /* World.updateEntityWithOptionalForce snapshots these values once before
     * Entity.updateRidden.  V131 called the rider-position helper both before
     * and after the vehicle tick, overwriting prevPos twice and producing a
     * zero-length segment followed by a full-tick camera jump. */
    entity->prevPosX=entity->posX;
    entity->prevPosY=entity->posY;
    entity->prevPosZ=entity->posZ;
    entity->prevRotationYaw=entity->rotationYaw;
    entity->prevRotationPitch=entity->rotationPitch;
    entity->motionX=0.0;
    entity->motionY=0.0;
    entity->motionZ=0.0;
    ++entity->ticksExisted;
    if(player->hurtTime>0)--player->hurtTime;
    if(player->hurtResistantTime>0)--player->hurtResistantTime;
    if(player->timeUntilPortal>0)--player->timeUntilPortal;
}

static void CloneMCJ_Gameplay_ApplyRiderRotation(CloneMCJ_EntityPlayer *player,
    const CloneMCJ_Entity *mount)
{
    double yawChange,pitchChange,releasedYaw,releasedPitch;
    const double maximum=10.0;
    if(!player||!mount)return;
    yawChange=(double)mount->rotationYaw-(double)mount->prevRotationYaw;
    pitchChange=(double)mount->rotationPitch-(double)mount->prevRotationPitch;
    player->entity.entityRiderYawDelta+=yawChange;
    player->entity.entityRiderPitchDelta+=pitchChange;
    while(player->entity.entityRiderYawDelta>=180.0)
        player->entity.entityRiderYawDelta-=360.0;
    while(player->entity.entityRiderYawDelta<-180.0)
        player->entity.entityRiderYawDelta+=360.0;
    while(player->entity.entityRiderPitchDelta>=180.0)
        player->entity.entityRiderPitchDelta-=360.0;
    while(player->entity.entityRiderPitchDelta<-180.0)
        player->entity.entityRiderPitchDelta+=360.0;
    releasedYaw=player->entity.entityRiderYawDelta*0.5;
    releasedPitch=player->entity.entityRiderPitchDelta*0.5;
    if(releasedYaw>maximum)releasedYaw=maximum;
    if(releasedYaw<-maximum)releasedYaw=-maximum;
    if(releasedPitch>maximum)releasedPitch=maximum;
    if(releasedPitch<-maximum)releasedPitch=-maximum;
    player->entity.entityRiderYawDelta-=releasedYaw;
    player->entity.entityRiderPitchDelta-=releasedPitch;
    player->entity.rotationYaw+=(float)releasedYaw;
    player->entity.rotationPitch+=(float)releasedPitch;
    if(player->entity.rotationPitch>90.0F)player->entity.rotationPitch=90.0F;
    if(player->entity.rotationPitch<-90.0F)player->entity.rotationPitch=-90.0F;
}

static void CloneMCJ_Gameplay_UpdateRider(CloneMCJ_EntityPlayer *player,
    const CloneMCJ_Mob *mount)
{
    if(!player||!mount)return;
    player->entity.motionX=0.0;player->entity.motionY=0.0;player->entity.motionZ=0.0;
    CloneMCJ_Entity_SetPosition(&player->entity,mount->entity.posX,
        mount->entity.posY+(double)mount->entity.height,mount->entity.posZ);
    CloneMCJ_Gameplay_ApplyRiderRotation(player,&mount->entity);
    if(player->entity.worldObj)CloneMCJ_World_SetPlayerGlobalPosition(
        player->entity.worldObj,player->entity.posX,player->entity.posZ);
}


void CloneMCJ_Gameplay_UpdateVehicleRiderNative(CloneMCJ_EntityPlayer *player,
    const CloneMCJ_Vehicle *vehicle)
{
    double x,y,z,yawRadians;
    if(!player||!vehicle)return;
    x=vehicle->entity.posX;
    z=vehicle->entity.posZ;
    /* EntityBoat.updateRiderPosition places the seat 0.4 blocks forward.
     * Minecart uses Entity.updateRiderPosition and remains centered. */
    if(vehicle->type==CLONEMC_J_VEHICLE_BOAT){
        yawRadians=(double)vehicle->entity.rotationYaw*
            3.14159265358979323846/180.0;
        x+=cos(yawRadians)*0.4;
        z+=sin(yawRadians)*0.4;
        /* C entity.posY is the bounding-box floor.  Converting Java's
         * getMountedYOffset(-0.3)+EntityPlayer.getYOffset(1.12) and the
         * player's 1.62 eye offset yields vehicle floor - 0.5. */
        y=vehicle->entity.posY-0.5;
    }else{
        /* The native minecart retains Java's center-Y convention
         * (floor + height/2), so the equivalent player floor is center-0.8. */
        y=vehicle->entity.posY-0.8;
    }
    player->entity.motionX=0.0;
    player->entity.motionY=0.0;
    player->entity.motionZ=0.0;
    CloneMCJ_Entity_SetPosition(&player->entity,x,y,z);
    CloneMCJ_Gameplay_ApplyRiderRotation(player,&vehicle->entity);
    if(player->entity.worldObj)CloneMCJ_World_SetPlayerGlobalPosition(player->entity.worldObj,
        player->entity.posX,player->entity.posZ);
}


static CloneMCJ_Mob *CloneMCJ_Gameplay_FindLivingMobById(CloneMCJ_GameplayState *state,int entityId)
{
    int index;
    if(!state||entityId<=0)return (CloneMCJ_Mob *)0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index)
        if(state->mobs[index].active&&state->mobs[index].health>0&&
            state->mobs[index].entity.entityId==entityId)return &state->mobs[index];
    return (CloneMCJ_Mob *)0;
}

static void CloneMCJ_Gameplay_AssignTamedWolfTargets(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *attacked,*attacker,*target,*wolf;
    int index;
    if(!state)return;
    attacked=CloneMCJ_Gameplay_FindLivingMobById(state,
        state->player.lastAttackTargetEntityId);
    if(attacked&&attacked->recentlyHit<=0)attacked=(CloneMCJ_Mob *)0;
    attacker=CloneMCJ_Gameplay_FindLivingMobById(state,
        state->player.lastAttackerEntityId);
    if(state->player.hurtTime<=0)attacker=(CloneMCJ_Mob *)0;
    for(index=0;index<CLONEMC_J_MAX_MOBS;++index){
        wolf=&state->mobs[index];if(!wolf->active||wolf->health<=0||
            wolf->type!=CLONEMC_J_MOB_WOLF||!wolf->tamed)continue;
        if(strcmp(wolf->owner,state->player.username)!=0){
            wolf->combatTarget=(CloneMCJ_Mob *)0;continue;
        }
        target=(CloneMCJ_Mob *)0;
        if(!wolf->sitting&&attacked&&attacked!=wolf&&
            attacked->type!=CLONEMC_J_MOB_CREEPER&&attacked->type!=CLONEMC_J_MOB_GHAST)
            target=attacked;
        else if(attacker&&attacker!=wolf&&
            attacker->type!=CLONEMC_J_MOB_CREEPER&&attacker->type!=CLONEMC_J_MOB_GHAST)
            target=attacker;
        if(target){
            double dx,dy,dz;dx=wolf->entity.posX-state->player.entity.posX;
            dy=wolf->entity.posY-state->player.entity.posY;dz=wolf->entity.posZ-state->player.entity.posZ;
            if(dx*dx+dy*dy+dz*dz<=272.0){wolf->combatTarget=target;wolf->sitting=0;}
            else wolf->combatTarget=(CloneMCJ_Mob *)0;
        }else wolf->combatTarget=(CloneMCJ_Mob *)0;
    }
    if(!attacked)state->player.lastAttackTargetEntityId=0;
    if(!attacker)state->player.lastAttackerEntityId=0;
}


static void CloneMCJ_Gameplay_ClearMount(CloneMCJ_GameplayState *state)
{
    CloneMCJ_Mob *mob;CloneMCJ_Vehicle *vehicle;
    if(!state)return;mob=CloneMCJ_Gameplay_FindRidingMob(state);
    vehicle=CloneMCJ_Gameplay_FindRidingVehicle(state);
    if(mob)mob->riderEntityId=0;if(vehicle)vehicle->riderEntityId=0;
    state->player.ridingEntityId=0;
    state->player.entity.entityRiderYawDelta=0.0;
    state->player.entity.entityRiderPitchDelta=0.0;
}

int CloneMCJ_Gameplay_UsePortal(CloneMCJ_GameplayState *state)
{
    CloneMCJ_World *world;int sourceDimension,targetDimension;double targetX,targetZ,targetY;
    double sourceX,sourceY,sourceZ;float sourceYaw,sourcePitch;
    if(!state||!state->world)return 0;world=state->world;
    if(world->multiplayerWorld)return 0;
    sourceDimension=world->worldInfo.dimension;
    sourceX=state->player.entity.posX;sourceY=state->player.entity.posY;sourceZ=state->player.entity.posZ;
    sourceYaw=state->player.entity.rotationYaw;sourcePitch=state->player.entity.rotationPitch;
    if(sourceDimension==-1){targetDimension=0;targetX=state->player.entity.posX*8.0;
        targetZ=state->player.entity.posZ*8.0;}
    else{targetDimension=-1;targetX=state->player.entity.posX/8.0;
        targetZ=state->player.entity.posZ/8.0;}
    if(targetX<-29999872.0)targetX=-29999872.0;if(targetX>29999872.0)targetX=29999872.0;
    if(targetZ<-29999872.0)targetZ=-29999872.0;if(targetZ>29999872.0)targetZ=29999872.0;
    targetY=state->player.entity.posY;if(targetY<10.0)targetY=10.0;if(targetY>118.0)targetY=118.0;
    CloneMCJ_Gameplay_ClearMount(state);
    if(state->openContainerActive)CloneMCJ_Gameplay_CloseOpenContainer(state);
    if(!CloneMCJ_World_SetDimension(world,targetDimension,0))return 0;
    state->player.entity.worldObj=world;state->player.dimension=targetDimension;
    CloneMCJ_Entity_SetPosition(&state->player.entity,targetX,targetY,targetZ);
    state->player.entity.motionX=state->player.entity.motionY=state->player.entity.motionZ=0.0;
    CloneMCJ_World_SetPlayerGlobalPosition(world,targetX,targetZ);
    if(!CloneMCJ_Teleporter_PlaceInPortal(world,&state->player.entity)){
        /* A failed target portal search/build must not strand the player in a
         * half-switched provider.  Return to the saved source dimension and
         * exact transform; source chunks were committed before replacement. */
        if(CloneMCJ_World_SetDimension(world,sourceDimension,0)){
            state->player.entity.worldObj=world;state->player.dimension=sourceDimension;
            CloneMCJ_Entity_SetPosition(&state->player.entity,sourceX,sourceY,sourceZ);
            state->player.entity.rotationYaw=sourceYaw;state->player.entity.prevRotationYaw=sourceYaw;
            state->player.entity.rotationPitch=sourcePitch;state->player.entity.prevRotationPitch=sourcePitch;
            CloneMCJ_World_SetPlayerGlobalPosition(world,sourceX,sourceZ);
        }
        return 0;
    }
    CloneMCJ_World_SetPlayerGlobalPosition(world,state->player.entity.posX,state->player.entity.posZ);
    state->player.timeUntilPortal=10;state->player.timeInPortal=0.0F;
    state->player.prevTimeInPortal=0.0F;state->player.inPortal=0;
    state->player.inventory.inventoryChanged=1;
    return 1;
}

static void CloneMCJ_Gameplay_ExplodeBed(CloneMCJ_GameplayState *state,int x,int y,int z)
{
    int dx,dy,dz,id;double distance;
    if(!state||!state->world)return;
    for(dx=-5;dx<=5;++dx)for(dy=-5;dy<=5;++dy)for(dz=-5;dz<=5;++dz){
        distance=sqrt((double)(dx*dx+dy*dy+dz*dz));if(distance>5.0)continue;
        id=CloneMCJ_World_GetBlockId(state->world,x+dx,y+dy,z+dz);
        if(id!=0&&id!=7&&id!=49&&CloneMCJavaRandom_NextFloat(&state->world->rand)>
            (float)(distance/6.0))CloneMCJ_World_SetBlockNotify(state->world,x+dx,y+dy,z+dz,0);
    }
    CloneMCJ_EntityPlayer_AttackFrom(&state->player,(const CloneMCJ_Entity *)0,10);
}

int CloneMCJ_Gameplay_ActivateBed(CloneMCJ_GameplayState *state,int x,int y,int z)
{
    int i,result,metadata,direction;static const int directionMap[4][2]={{0,1},{-1,0},{0,-1},{1,0}};
    if(!state||!state->world||CloneMCJ_World_GetBlockId(state->world,x,y,z)!=26)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(state->world,x,y,z);direction=metadata&3;
    if(!(metadata&8)){x+=directionMap[direction][0];z+=directionMap[direction][1];
        if(CloneMCJ_World_GetBlockId(state->world,x,y,z)!=26)return 1;}
    if(state->world->worldProvider.isHellWorld){
        CloneMCJ_World_SetBlockNotify(state->world,x,y,z,0);
        CloneMCJ_World_SetBlockNotify(state->world,x-directionMap[direction][0],y,
            z-directionMap[direction][1],0);
        CloneMCJ_Gameplay_ExplodeBed(state,x,y,z);return 1;
    }
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&state->mobs[i].health>0&&
        CloneMCJ_EntityLiving_IsHostileNow(&state->mobs[i])){
        double dx,dy,dz;dx=state->mobs[i].entity.posX-(double)x;
        dy=state->mobs[i].entity.posY-(double)y;dz=state->mobs[i].entity.posZ-(double)z;
        if(dx*dx/64.0+dy*dy/25.0+dz*dz/64.0<=1.0)return 1;
    }
    result=CloneMCJ_EntityPlayer_TrySleep(&state->player,x,y,z);
    return result!=0;
}

void CloneMCJ_Gameplay_Tick(CloneMCJ_World *world, void *userData)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_Mob *mount;
    CloneMCJ_Vehicle *vehicleMount;
    CloneMCJ_MovingObjectPosition target;
    double blockDistance;
    int i,slot,mobIndex,vehicleIndex;
    state = (CloneMCJ_GameplayState *)userData;
    if (!state || world != state->world) return;
    state->player.dimension = world->worldInfo.dimension;
    mount=CloneMCJ_Gameplay_FindRidingMob(state);
    vehicleMount=CloneMCJ_Gameplay_FindRidingVehicle(state);
    if((mount||vehicleMount)&&state->player.movementInput.sneak){
        state->player.ridingEntityId=0;if(mount)mount->riderEntityId=0;if(vehicleMount)vehicleMount->riderEntityId=0;
        state->player.entity.entityRiderYawDelta=0.0;
        state->player.entity.entityRiderPitchDelta=0.0;
        CloneMCJ_Entity_SetPosition(&state->player.entity,mount?mount->entity.posX+1.0:vehicleMount->entity.posX+1.0,
            mount?mount->entity.posY:vehicleMount->entity.posY,mount?mount->entity.posZ:vehicleMount->entity.posZ);
        mount=(CloneMCJ_Mob *)0;vehicleMount=(CloneMCJ_Vehicle *)0;
    }
    if(mount||vehicleMount)CloneMCJ_Gameplay_BeginRidingTickNative(&state->player);
    else CloneMCJ_EntityPlayer_Tick(&state->player);
    if(state->player.inPortal&&(mount||vehicleMount))CloneMCJ_Gameplay_ClearMount(state);
    if(!world->multiplayerWorld&&state->player.timeInPortal>=1.0F&&
       state->player.timeUntilPortal<=0){
        if(CloneMCJ_Gameplay_UsePortal(state)){state->previousAttack=state->attackInput;
            state->previousUse=state->useInput;++state->ticksRun;return;}
    }
    if(state->player.sleeping){
        ++state->player.sleepTimer;
        if(state->player.sleepTimer>=100){
            world->worldTime=((world->worldTime+CLONEMC_J_WORLD_DAY_TICKS-1L)/
                CLONEMC_J_WORLD_DAY_TICKS)*CLONEMC_J_WORLD_DAY_TICKS;
            CloneMCJ_World_StopPrecipitation(world);
            CloneMCJ_EntityPlayer_Wake(&state->player,0,1);
        }
        state->previousAttack=state->attackInput;state->previousUse=state->useInput;
        ++state->ticksRun;return;
    }
    target = CloneMCJ_Gameplay_RayTrace(&state->player, 5.0);
    if(target.hit){
        double ex,ey,ez;
        ex=state->player.entity.posX;ey=state->player.entity.posY+1.62;
        ez=state->player.entity.posZ;
        ex=target.hitVec.xCoord-ex;ey=target.hitVec.yCoord-ey;ez=target.hitVec.zCoord-ez;
        blockDistance=sqrt(ex*ex+ey*ey+ez*ez);
    }else blockDistance=5.0;
    if(blockDistance>3.0)blockDistance=3.0;
    mobIndex=CloneMCJ_Gameplay_FindTargetMob(state,blockDistance,(double *)0);
    vehicleIndex=CloneMCJ_Gameplay_FindTargetVehicle(state,blockDistance,(double *)0);
    if(state->player.gameMode==CLONEMC_J_GAMEMODE_SPECTATOR){
        /* Spectator is an observation-only compatibility mode.  Do not send
         * dig/use packets or mutate local entities/blocks, and cancel any
         * partially accumulated mining overlay when the mode changes. */
        state->attackInput=0;state->useInput=0;state->intentDigging=0;
        state->controller.hittingBlock=0;
        state->controller.currentBlockDamage=0.0F;
        state->controller.previousBlockDamage=0.0F;
        state->controller.currentBlockX=-999999;
        state->controller.currentBlockY=-999999;
        state->controller.currentBlockZ=-999999;
        mobIndex=-1;vehicleIndex=-1;
    }
    if(world->multiplayerWorld&&state->sendDigIntent){
        /* EntityRenderer replaces the block hit with the nearer entity hit in
         * the Java client.  Preserve that ordering here and keep the server
         * authoritative: local mobs/vehicles are not damaged or mounted until
         * their response packets arrive. */
        if(state->attackInput&&!state->previousAttack){
            int targetEntityId;targetEntityId=0;
            if(vehicleIndex>=0)targetEntityId=state->vehicles[vehicleIndex].entity.entityId;
            else if(mobIndex>=0)targetEntityId=state->mobs[mobIndex].entity.entityId;
            if(targetEntityId&&state->sendUseEntityIntent){
                if(state->sendAnimationIntent)state->sendAnimationIntent(state->multiplayerController,
                    state->player.entity.entityId,1);
                state->sendUseEntityIntent(state->multiplayerController,
                    state->player.entity.entityId,targetEntityId,1);
            }else if(target.hit){
                state->intentBlockX=target.blockX;state->intentBlockY=target.blockY;
                state->intentBlockZ=target.blockZ;state->intentFace=target.sideHit;
                state->intentDigging=1;
                state->sendDigIntent(state->multiplayerController,0,target.blockX,target.blockY,
                    target.blockZ,target.sideHit);
            }else if(state->sendAnimationIntent)state->sendAnimationIntent(
                state->multiplayerController,state->player.entity.entityId,1);
        }else if(!state->attackInput&&state->previousAttack&&state->intentDigging){
            state->sendDigIntent(state->multiplayerController,1,state->intentBlockX,
                state->intentBlockY,state->intentBlockZ,state->intentFace);
            state->intentDigging=0;
        }
        if(state->useInput&&!state->previousUse){
            int targetEntityId;targetEntityId=0;
            if(vehicleIndex>=0)targetEntityId=state->vehicles[vehicleIndex].entity.entityId;
            else if(mobIndex>=0)targetEntityId=state->mobs[mobIndex].entity.entityId;
            if(targetEntityId&&state->sendUseEntityIntent)
                state->sendUseEntityIntent(state->multiplayerController,
                    state->player.entity.entityId,targetEntityId,0);
            else if(state->sendPlaceIntent){
                if(target.hit)state->sendPlaceIntent(state->multiplayerController,target.blockX,
                    target.blockY,target.blockZ,target.sideHit,
                    CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory));
                else state->sendPlaceIntent(state->multiplayerController,-1,-1,-1,255,
                    CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory));
            }
        }
    }else{
        if(state->attackInput&&!state->previousAttack&&vehicleIndex>=0)
            CloneMCJ_Vehicle_Attack(&state->vehicles[vehicleIndex],state,1);
        else if(state->attackInput&&!state->previousAttack&&mobIndex>=0)
            CloneMCJ_Gameplay_AttackMob(state,mobIndex);
        else if (state->attackInput && target.hit&&mobIndex<0&&vehicleIndex<0)
            CloneMCJ_PlayerControllerSP_DamageBlock(&state->controller, target.blockX, target.blockY, target.blockZ);
        else if (!state->attackInput) {
            state->controller.hittingBlock = 0;
            state->controller.currentBlockDamage = 0.0F;
            state->controller.previousBlockDamage = 0.0F;
            state->controller.currentBlockX = -999999;
            state->controller.currentBlockY = -999999;
            state->controller.currentBlockZ = -999999;
        }
        if(state->useInput&&!state->previousUse){
            CloneMCJ_ItemStack creativeHeldBefore;CloneMCJ_ItemStack *creativeHeld;
            int creativeRestore,creativeSlot;
            creativeRestore=0;creativeSlot=state->player.inventory.currentItem;
            creativeHeld=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
            if(state->player.gameMode==CLONEMC_J_GAMEMODE_CREATIVE&&creativeHeld&&
               !CloneMCJ_ItemStack_IsEmpty(creativeHeld)){
                creativeHeldBefore=*creativeHeld;creativeRestore=1;
            }
            if(vehicleIndex>=0&&(state->vehicles[vehicleIndex].type==CLONEMC_J_VEHICLE_BOAT||
                state->vehicles[vehicleIndex].type==CLONEMC_J_VEHICLE_MINECART)){
                CloneMCJ_Vehicle *clickedVehicle;CloneMCJ_ItemStack *held;clickedVehicle=&state->vehicles[vehicleIndex];
                held=CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory);
                if(clickedVehicle->type==CLONEMC_J_VEHICLE_MINECART&&clickedVehicle->minecartType==1)
                    state->openVehicleInventoryId=clickedVehicle->entity.entityId;
                else if(clickedVehicle->type==CLONEMC_J_VEHICLE_MINECART&&clickedVehicle->minecartType==2){
                    if(held&&!CloneMCJ_ItemStack_IsEmpty(held)&&held->itemID==263){
                        CloneMCJ_Gameplay_ConsumeItem(&state->player.inventory,263);clickedVehicle->fuel+=1200;}
                    clickedVehicle->pushX=clickedVehicle->entity.posX-state->player.entity.posX;
                    clickedVehicle->pushZ=clickedVehicle->entity.posZ-state->player.entity.posZ;
                }else{state->player.ridingEntityId=clickedVehicle->entity.entityId;
                    state->player.entity.entityRiderYawDelta=0.0;
                    state->player.entity.entityRiderPitchDelta=0.0;
                    clickedVehicle->riderEntityId=state->player.entity.entityId;}
            }else if(mobIndex>=0)CloneMCJ_Gameplay_InteractMob(state,mobIndex);
            else if(target.hit){
                if(!CloneMCJ_Gameplay_ActivateBed(state,target.blockX,target.blockY,target.blockZ)&&
                   !CloneMCJ_Gameplay_OpenBlockContainer(state,target.blockX,
                    target.blockY,target.blockZ)&&
                   !CloneMCJ_Gameplay_UseEntityItem(state,&target)&&
                   !CloneMCJ_PlayerControllerSP_PlaceBlock(&state->controller,
                    target.blockX,target.blockY,target.blockZ,target.sideHit))
                    CloneMCJ_ItemFood_Use(CloneMCJ_InventoryPlayer_GetCurrent(
                        &state->player.inventory),&state->player);
            }
            else if(!CloneMCJ_Gameplay_UseEntityItem(state,(const CloneMCJ_MovingObjectPosition *)0))
                CloneMCJ_ItemFood_Use(CloneMCJ_InventoryPlayer_GetCurrent(&state->player.inventory),&state->player);
            if(creativeRestore&&creativeSlot>=0&&creativeSlot<9){
                state->player.inventory.mainInventory[creativeSlot]=creativeHeldBefore;
                state->player.inventory.inventoryChanged=1;
            }
        }
    }
    if(!world->multiplayerWorld){
        /* Beta pressure plates react through onEntityCollidedWithBlock rather
         * than polling only their scheduled tick.  Refresh the candidate under
         * each entity before motion advances the rest of the world. */
        CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
            CloneMCJava_FloorDouble(state->player.entity.posX),
            CloneMCJava_FloorDouble(state->player.entity.boundingBox.minY),
            CloneMCJava_FloorDouble(state->player.entity.posZ));
        CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
            CloneMCJava_FloorDouble(state->player.entity.posX),
            CloneMCJava_FloorDouble(state->player.entity.boundingBox.minY)-1,
            CloneMCJava_FloorDouble(state->player.entity.posZ));
        for (i = 0; i < state->droppedItemCount; ++i) if (state->droppedItems[i].active) {
            int wasActive;
            if(!CloneMCJ_EntityItem_CanUpdate(&state->droppedItems[i])){
                ++state->droppedItemTicksSuspended;
                continue;
            }
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->droppedItems[i].entity.posX),
                CloneMCJava_FloorDouble(state->droppedItems[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->droppedItems[i].entity.posZ));
            wasActive=state->droppedItems[i].active;
            CloneMCJ_EntityItem_TickLoaded(&state->droppedItems[i]);
            ++state->droppedItemTicks;
            if(state->droppedItems[i].active)
                CloneMCJ_EntityItem_TryPickup(&state->droppedItems[i], &state->player);
            if(wasActive&&!state->droppedItems[i].active)
                ++state->droppedItemsDespawned;
            CloneMCJ_Gameplay_UpdateDroppedItemChunk(state,&state->droppedItems[i]);
        }
        CloneMCJ_Gameplay_AssignTamedWolfTargets(state);
        for (i = 0; i < CLONEMC_J_MAX_MOBS; ++i) if (state->mobs[i].active){
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->mobs[i].entity.posX),
                CloneMCJava_FloorDouble(state->mobs[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->mobs[i].entity.posZ));
            CloneMCJ_EntityLiving_TickMob(&state->mobs[i], &state->player);
            if(state->mobs[i].health<=0&&!state->mobs[i].lootDropped)
                CloneMCJ_Gameplay_SpawnMobLoot(state,&state->mobs[i]);
            if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_CHICKEN&&state->mobs[i].specialTimer<=0){
                CloneMCJ_ItemStack egg;CloneMCJ_ItemStack_Initialize(&egg,344,1,0);CloneMCJ_Gameplay_SpawnDrop(state,
                    state->mobs[i].entity.posX,state->mobs[i].entity.posY,state->mobs[i].entity.posZ,&egg,10,0);
                state->mobs[i].specialTimer=6000+CloneMCJavaRandom_NextIntBound(&state->mobs[i].entity.rand,6000);}
            if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_SKELETON&&state->mobs[i].rangedAttackPending){
                int projectileSlot;double dx,dy,dz,horizontal;
                if(CloneMCJ_Gameplay_SpawnProjectile(state,CLONEMC_J_PROJECTILE_ARROW,&state->mobs[i].entity,0.6F,12.0F)){
                    for(projectileSlot=0;projectileSlot<CLONEMC_J_MAX_PROJECTILES;++projectileSlot)
                        if(state->projectiles[projectileSlot].active&&state->projectiles[projectileSlot].entity.entityId==state->nextEntityId-1)break;
                    if(projectileSlot<CLONEMC_J_MAX_PROJECTILES){state->projectiles[projectileSlot].belongsToPlayer=0;
                        dx=state->player.entity.posX-state->mobs[i].entity.posX;dz=state->player.entity.posZ-state->mobs[i].entity.posZ;
                        horizontal=sqrt(dx*dx+dz*dz);dy=state->player.entity.posY+1.0-state->mobs[i].entity.posY+horizontal*0.2;
                        CloneMCJ_Projectile_SetHeading(&state->projectiles[projectileSlot],dx,dy,dz,0.6F,12.0F);}}
            }
            if(state->mobs[i].active&&state->mobs[i].type==CLONEMC_J_MOB_GHAST&&state->mobs[i].rangedAttackPending){
                int projectileSlot;double dx,dy,dz,length;
                if(CloneMCJ_Gameplay_SpawnProjectile(state,CLONEMC_J_PROJECTILE_FIREBALL,&state->mobs[i].entity,1.0F,0.0F)){
                    for(projectileSlot=0;projectileSlot<CLONEMC_J_MAX_PROJECTILES;++projectileSlot)
                        if(state->projectiles[projectileSlot].active&&state->projectiles[projectileSlot].entity.entityId==state->nextEntityId-1)break;
                    if(projectileSlot<CLONEMC_J_MAX_PROJECTILES){double yawRadians,lookX,lookZ;
                        dx=state->player.entity.posX-state->mobs[i].entity.posX;
                        dy=(state->player.entity.boundingBox.minY+state->player.entity.height*0.5)-
                            (state->mobs[i].entity.posY+state->mobs[i].entity.height*0.5);
                        dz=state->player.entity.posZ-state->mobs[i].entity.posZ;
                        length=sqrt(dx*dx+dy*dy+dz*dz);if(length<0.001)length=0.001;
                        yawRadians=(double)state->mobs[i].entity.rotationYaw*0.017453292519943295;
                        lookX=-sin(yawRadians);lookZ=cos(yawRadians);
                        state->projectiles[projectileSlot].entity.posX=state->mobs[i].entity.posX+lookX*4.0;
                        state->projectiles[projectileSlot].entity.posY=state->mobs[i].entity.posY+
                            state->mobs[i].entity.height*0.5+0.5;
                        state->projectiles[projectileSlot].entity.posZ=state->mobs[i].entity.posZ+lookZ*4.0;
                        CloneMCJ_Entity_SetPosition(&state->projectiles[projectileSlot].entity,
                            state->projectiles[projectileSlot].entity.posX,
                            state->projectiles[projectileSlot].entity.posY,
                            state->projectiles[projectileSlot].entity.posZ);
                        CloneMCJ_Projectile_SetHeading(&state->projectiles[projectileSlot],dx,dy,dz,1.0F,0.0F);
                        state->projectiles[projectileSlot].belongsToPlayer=0;
                        state->projectiles[projectileSlot].accelerationX=dx/length*0.1;
                        state->projectiles[projectileSlot].accelerationY=dy/length*0.1;
                        state->projectiles[projectileSlot].accelerationZ=dz/length*0.1;}}
            }
        }
        for(i=0;i<state->projectileCount;++i)if(state->projectiles[i].active){
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->projectiles[i].entity.posX),
                CloneMCJava_FloorDouble(state->projectiles[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->projectiles[i].entity.posZ));
            CloneMCJ_Projectile_Tick(&state->projectiles[i],state);
        }
        for(i=0;i<state->vehicleCount;++i)if(state->vehicles[i].active){
            CloneMCJ_BlockPressurePlate_EntityCollisionNative(world,
                CloneMCJava_FloorDouble(state->vehicles[i].entity.posX),
                CloneMCJava_FloorDouble(state->vehicles[i].entity.boundingBox.minY),
                CloneMCJava_FloorDouble(state->vehicles[i].entity.posZ));
            CloneMCJ_Vehicle_Tick(&state->vehicles[i],state);
        }
        for(i=0;i<state->vehicleCount;++i)if(state->vehicles[i].active){int otherVehicle;
            for(otherVehicle=i+1;otherVehicle<state->vehicleCount;++otherVehicle)
                if(state->vehicles[otherVehicle].active)CloneMCJ_Vehicle_ApplyCollision(
                    &state->vehicles[i],&state->vehicles[otherVehicle]);}
        if((state->ticksRun%20UL)==0UL)(void)CloneMCJ_Gameplay_SynchronizeChunkEntities(state,0);
        CloneMCJ_SpawnerAnimals_Tick(state);
        for (slot = 0; slot < CLONEMC_J_CHUNK_CACHE_CAPACITY; ++slot) {
            CloneMCJ_Chunk *chunk;
            int tileIndex;
            if (!world->chunkProvider.slots[slot].used) continue;
            chunk = world->chunkProvider.slots[slot].chunk;
            if (!chunk) continue;
            for (tileIndex = 0; tileIndex < chunk->tileEntityCount; ++tileIndex)
                CloneMCJ_TileEntity_Update((CloneMCJ_TileEntity *)chunk->tileEntities[tileIndex]);
        }
    }
    /* Packet-driven multiplayer vehicles skip the local entity-physics branch,
     * but Entity.updateRidden still applies their latest authoritative mount
     * transform.  Finish the rider update here for both local and remote
     * mounts so the camera follows continuously in either mode. */
    mount=CloneMCJ_Gameplay_FindRidingMob(state);
    if(mount)CloneMCJ_Gameplay_UpdateRider(&state->player,mount);
    else{
        vehicleMount=CloneMCJ_Gameplay_FindRidingVehicle(state);
        if(vehicleMount)
            CloneMCJ_Gameplay_UpdateVehicleRiderNative(&state->player,
                vehicleMount);
        else if(state->player.ridingEntityId!=0){
            state->player.ridingEntityId=0;
            state->player.entity.entityRiderYawDelta=0.0;
            state->player.entity.entityRiderPitchDelta=0.0;
        }
    }
    state->previousAttack = state->attackInput;
    state->previousUse = state->useInput;
    ++state->ticksRun;
}

void CloneMCJ_Gameplay_SetMultiplayerIntentHooks(CloneMCJ_GameplayState *state,void *controller,
    int (*dig)(void *,int,int,int,int,int),
    int (*place)(void *,int,int,int,int,const CloneMCJ_ItemStack *))
{
    if(!state)return;
    state->multiplayerController=controller;state->sendDigIntent=dig;state->sendPlaceIntent=place;
}

void CloneMCJ_Gameplay_AttachSaveHooks(CloneMCJ_GameplayState *state)
{
    CloneMCJ_McRegionChunkLoader *loader;
    CloneMCJ_ChunkSerializationHooks hooks;
    if (!state || !state->world || !state->world->saveHandler) return;
    loader = CloneMCJ_SaveHandler_GetChunkLoader(state->world->saveHandler,
        state->world->worldInfo.dimension);
    if (!loader) return;
    memset(&hooks, 0, sizeof(hooks));
    hooks.writeEntity = CloneMCJ_Gameplay_WriteEntityHook;
    hooks.readEntity = CloneMCJ_Gameplay_ReadEntityHook;
    hooks.getEntityY = CloneMCJ_Gameplay_GetEntityYHook;
    hooks.writeTileEntity = CloneMCJ_Gameplay_WriteTileHook;
    hooks.readTileEntity = CloneMCJ_Gameplay_ReadTileHook;
    hooks.userData = state;
    CloneMCJ_McRegionChunkLoader_SetHooks(loader, &hooks);
}

static int CloneMCJ_Gameplay_AddEntityToLoadedChunk(CloneMCJ_World *world,void *object,
    CloneMCJ_Entity *entity)
{
    CloneMCJ_Chunk *chunk;int chunkX,chunkY,chunkZ;
    if(!world||!object||!entity)return 0;
    chunkX=CloneMCJava_FloorDouble(entity->posX/16.0);
    chunkY=CloneMCJava_FloorDouble(entity->posY/16.0);
    if(chunkY<0)chunkY=0;
    if(chunkY>=CLONEMC_J_CHUNK_ENTITY_SLICES)
        chunkY=CLONEMC_J_CHUNK_ENTITY_SLICES-1;
    chunkZ=CloneMCJava_FloorDouble(entity->posZ/16.0);
    chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(world,chunkX,chunkZ);
    if(!chunk||!CloneMCJ_Chunk_AddEntity(chunk,object,entity->posY)){
        entity->addedToChunk=0;
        return 0;
    }
    entity->addedToChunk=1;
    entity->chunkCoordX=chunkX;
    entity->chunkCoordY=chunkY;
    entity->chunkCoordZ=chunkZ;
    return 1;
}

static void CloneMCJ_Gameplay_UpdateDroppedItemChunk(CloneMCJ_GameplayState *state,
    CloneMCJ_EntityItem *item)
{
    CloneMCJ_Entity *entity;
    CloneMCJ_Chunk *chunk;
    int chunkX,chunkY,chunkZ;
    if(!state||!state->world||!item)return;
    entity=&item->entity;
    chunkX=CloneMCJava_FloorDouble(entity->posX/16.0);
    chunkY=CloneMCJava_FloorDouble(entity->posY/16.0);
    if(chunkY<0)chunkY=0;
    if(chunkY>=CLONEMC_J_CHUNK_ENTITY_SLICES)
        chunkY=CLONEMC_J_CHUNK_ENTITY_SLICES-1;
    chunkZ=CloneMCJava_FloorDouble(entity->posZ/16.0);
    if(entity->addedToChunk&&(!item->active||
       entity->chunkCoordX!=chunkX||entity->chunkCoordY!=chunkY||
       entity->chunkCoordZ!=chunkZ)){
        chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(state->world,
            entity->chunkCoordX,entity->chunkCoordZ);
        if(chunk){
            CloneMCJ_Chunk_RemoveEntity(chunk,item,entity->chunkCoordY);
            CloneMCJ_Chunk_SetModified(chunk);
        }
        entity->addedToChunk=0;
    }
    if(item->active&&!entity->addedToChunk&&
       CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,item,entity)){
        chunk=CloneMCJ_World_GetLoadedChunkFromChunkCoords(state->world,
            entity->chunkCoordX,entity->chunkCoordZ);
        if(chunk)CloneMCJ_Chunk_SetModified(chunk);
    }
}

static int CloneMCJ_Gameplay_SynchronizeChunkEntities(CloneMCJ_GameplayState *state,int markModified)
{
    CloneMCJ_Chunk *chunk;int slot,slice,i,success;
    unsigned char hadEntities[CLONEMC_J_CHUNK_CACHE_CAPACITY];
    if(!state||!state->world)return 0;
    memset(hadEntities,0,sizeof(hadEntities));success=1;
    for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot)
        if(state->world->chunkProvider.slots[slot].used){
            chunk=state->world->chunkProvider.slots[slot].chunk;if(!chunk)continue;
            hadEntities[slot]=chunk->hasEntities;
            for(slice=0;slice<CLONEMC_J_CHUNK_ENTITY_SLICES;++slice)
                chunk->entityCount[slice]=0;
            chunk->hasEntities=0;
        }
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)
        state->droppedItems[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)state->mobs[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)
        state->projectiles[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)
        state->vehicles[i].entity.addedToChunk=0;
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(state->droppedItems[i].active&&
        !CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->droppedItems[i],&state->droppedItems[i].entity))success=0;
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&
        !CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->mobs[i],&state->mobs[i].entity))success=0;
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(state->projectiles[i].active&&
        state->projectiles[i].type!=CLONEMC_J_PROJECTILE_FISHING)
        if(!CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->projectiles[i],&state->projectiles[i].entity))success=0;
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(state->vehicles[i].active&&
        state->vehicles[i].type!=CLONEMC_J_VEHICLE_LIGHTNING)
        if(!CloneMCJ_Gameplay_AddEntityToLoadedChunk(state->world,&state->vehicles[i],&state->vehicles[i].entity))success=0;
    if(markModified)for(slot=0;slot<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slot)
        if(state->world->chunkProvider.slots[slot].used){
            chunk=state->world->chunkProvider.slots[slot].chunk;
            if(chunk&&(hadEntities[slot]||chunk->hasEntities))
                CloneMCJ_Chunk_SetModified(chunk);
        }
    if(!success)++state->entitySyncFailures;
    return success;
}

void CloneMCJ_Gameplay_OnDimensionChanged(CloneMCJ_World *world,void *userData,int dimension)
{
    CloneMCJ_GameplayState *state;state=(CloneMCJ_GameplayState *)userData;
    if(!state||state->world!=world)return;
    if(state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    memset(state->droppedItems,0,sizeof(state->droppedItems));
    memset(state->mobs,0,sizeof(state->mobs));memset(state->projectiles,0,sizeof(state->projectiles));
    memset(state->vehicles,0,sizeof(state->vehicles));state->droppedItemCount=0;state->mobCount=0;
    state->projectileCount=0;state->vehicleCount=0;state->player.ridingEntityId=0;
    state->player.entity.entityRiderYawDelta=0.0;
    state->player.entity.entityRiderPitchDelta=0.0;
    state->openVehicleInventoryId=0;
    state->player.dimension=dimension;CloneMCJ_Gameplay_AttachSaveHooks(state);
}

static CloneMCJ_TileEntity *CloneMCJ_Gameplay_GetBlockTile(
    CloneMCJ_GameplayState *state, int x, int y, int z,
    CloneMCJ_TileEntityType requiredType, int createMissing)
{
    CloneMCJ_Chunk *chunk;
    CloneMCJ_TileEntity *tile;
    if (!state || !state->world || y < 0 || y >= CLONEMC_J_CHUNK_HEIGHT)
        return (CloneMCJ_TileEntity *)0;
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(state->world, x, z);
    if (!chunk) return (CloneMCJ_TileEntity *)0;
    tile = (CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(chunk,
        x & 15, y, z & 15);
    if (tile && (tile->invalid || tile->type != requiredType)) {
        if (!createMissing) return (CloneMCJ_TileEntity *)0;
        CloneMCJ_Chunk_RemoveTileEntity(chunk, x & 15, y, z & 15);
        CloneMCJ_TileEntity_Destroy(tile);
        tile = (CloneMCJ_TileEntity *)0;
    }
    if (!tile && createMissing) {
        tile = CloneMCJ_TileEntity_Create(requiredType, state->world, x, y, z);
        if (!tile) return (CloneMCJ_TileEntity *)0;
        if (!CloneMCJ_Chunk_SetTileEntity(chunk, x & 15, y, z & 15, tile)) {
            CloneMCJ_TileEntity_Destroy(tile);
            return (CloneMCJ_TileEntity *)0;
        }
        chunk->isModified = 1;
    }
    return tile;
}

static int CloneMCJ_Gameplay_IsOpaqueAbove(CloneMCJ_GameplayState *state,
    int x, int y, int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if (!state || !state->world) return 1;
    id = CloneMCJ_World_GetBlockId(state->world, x, y + 1, z);
    block = CloneMCJ_BlockRegistry_Get(id);
    return block && block->solid && block->opaque;
}

int CloneMCJ_Gameplay_CloseOpenContainer(CloneMCJ_GameplayState *state)
{
    CloneMCJ_ItemStack leftovers[CLONEMC_J_MAX_RECIPE_CELLS];
    int count;
    int i;
    if (!state || !state->openContainerActive) return 0;
    for (i = 0; i < CLONEMC_J_MAX_RECIPE_CELLS; ++i)
        CloneMCJ_ItemStack_Clear(&leftovers[i]);
    if (state->openContainer.type == CLONEMC_J_CONTAINER_CHEST) {
        if (state->openContainer.tileEntity &&
            state->openContainer.tileEntity->numUsingPlayers > 0)
            --state->openContainer.tileEntity->numUsingPlayers;
        if (state->openContainer.secondTileEntity &&
            state->openContainer.secondTileEntity->numUsingPlayers > 0)
            --state->openContainer.secondTileEntity->numUsingPlayers;
    }
    count = CloneMCJ_Container_Close(&state->openContainer,
        &state->player.inventory, leftovers, CLONEMC_J_MAX_RECIPE_CELLS);
    for (i = 0; i < count; ++i) {
        if (!CloneMCJ_ItemStack_IsEmpty(&leftovers[i]))
            CloneMCJ_Gameplay_SpawnDrop(state, state->player.entity.posX,
                state->player.entity.posY + 1.32,
                state->player.entity.posZ, &leftovers[i], 40, 0);
    }
    CloneMCJ_Container_Initialize(&state->openContainer);
    CloneMCJ_InventoryCrafting_Initialize(&state->openCraftMatrix, 2, 2);
    CloneMCJ_InventoryCraftResult_Initialize(&state->openCraftResult);
    state->openContainerActive = 0;
    state->openContainerIsBlock = 0;
    state->openContainerX = 0;
    state->openContainerY = 0;
    state->openContainerZ = 0;
    return 1;
}

int CloneMCJ_Gameplay_OpenPlayerContainer(CloneMCJ_GameplayState *state)
{
    if (!state) return 0;
    if (state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    state->openVehicleInventoryId = 0;
    CloneMCJ_ContainerPlayer_InitializeNative(&state->openContainer,
        &state->player.inventory, &state->openCraftMatrix,
        &state->openCraftResult);
    state->openContainerActive = 1;
    state->openContainerIsBlock = 0;
    return 1;
}

int CloneMCJ_Gameplay_OpenBlockContainer(CloneMCJ_GameplayState *state,
    int x, int y, int z)
{
    CloneMCJ_TileEntity *tile;
    CloneMCJ_TileEntity *neighbor;
    CloneMCJ_TileEntity *first;
    CloneMCJ_TileEntity *second;
    int id;
    int neighborX;
    int neighborZ;
    if (!state || !state->world) return 0;
    id = CloneMCJ_World_GetBlockId(state->world, x, y, z);
    if (id != 58 && id != 54 && id != 61 && id != 62 && id != 23)
        return 0;
    if (state->openContainerActive)
        CloneMCJ_Gameplay_CloseOpenContainer(state);
    state->openVehicleInventoryId = 0;
    if (id == 58) {
        CloneMCJ_ContainerWorkbench_InitializeNative(&state->openContainer,
            &state->player.inventory, &state->openCraftMatrix,
            &state->openCraftResult, x, y, z);
    } else if (id == 54) {
        if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x, y, z)) return 0;
        tile = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z,
            CLONEMC_J_TILE_CHEST, 1);
        if (!tile) return 0;
        first = tile;
        second = (CloneMCJ_TileEntity *)0;
        neighborX = x - 1;
        neighborZ = z;
        if (CloneMCJ_World_GetBlockId(state->world, neighborX, y,
            neighborZ) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, neighborX, y,
                neighborZ)) return 0;
            neighbor = CloneMCJ_Gameplay_GetBlockTile(state, neighborX, y,
                neighborZ, CLONEMC_J_TILE_CHEST, 1);
            first = neighbor;
            second = tile;
        } else if (CloneMCJ_World_GetBlockId(state->world, x + 1, y, z) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x + 1, y, z)) return 0;
            second = CloneMCJ_Gameplay_GetBlockTile(state, x + 1, y, z,
                CLONEMC_J_TILE_CHEST, 1);
        } else if (CloneMCJ_World_GetBlockId(state->world, x, y, z - 1) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x, y, z - 1)) return 0;
            neighbor = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z - 1,
                CLONEMC_J_TILE_CHEST, 1);
            first = neighbor;
            second = tile;
        } else if (CloneMCJ_World_GetBlockId(state->world, x, y, z + 1) == 54) {
            if (CloneMCJ_Gameplay_IsOpaqueAbove(state, x, y, z + 1)) return 0;
            second = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z + 1,
                CLONEMC_J_TILE_CHEST, 1);
        }
        if (!first || (second && second == first)) return 0;
        CloneMCJ_ContainerChest_InitializeDoubleNative(&state->openContainer,
            &state->player.inventory, first, second);
        ++first->numUsingPlayers;
        if (second) ++second->numUsingPlayers;
    } else if (id == 61 || id == 62) {
        tile = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z,
            CLONEMC_J_TILE_FURNACE, 1);
        if (!tile) return 0;
        CloneMCJ_ContainerFurnace_InitializeNative(&state->openContainer,
            &state->player.inventory, tile);
    } else {
        tile = CloneMCJ_Gameplay_GetBlockTile(state, x, y, z,
            CLONEMC_J_TILE_DISPENSER, 1);
        if (!tile) return 0;
        CloneMCJ_ContainerDispenser_InitializeNative(&state->openContainer,
            &state->player.inventory, tile);
    }
    state->openContainerX = x;
    state->openContainerY = y;
    state->openContainerZ = z;
    state->openContainerActive = 1;
    state->openContainerIsBlock = 1;
    return 1;
}

CloneMCJ_Container *CloneMCJ_Gameplay_GetOpenContainer(
    CloneMCJ_GameplayState *state)
{
    if (!state || !state->openContainerActive)
        return (CloneMCJ_Container *)0;
    return &state->openContainer;
}

int CloneMCJ_Gameplay_IsOpenContainerUsable(
    const CloneMCJ_GameplayState *state)
{
    double dx;
    double dy;
    double dz;
    int id;
    if (!state || !state->openContainerActive) return 0;
    if (!state->openContainerIsBlock) return 1;
    dx = state->player.entity.posX -
        ((double)state->openContainerX + 0.5);
    dy = state->player.entity.posY -
        ((double)state->openContainerY + 0.5);
    dz = state->player.entity.posZ -
        ((double)state->openContainerZ + 0.5);
    if (dx * dx + dy * dy + dz * dz > 64.0) return 0;
    id = CloneMCJ_World_GetBlockId(state->world, state->openContainerX,
        state->openContainerY, state->openContainerZ);
    switch ((CloneMCJ_ContainerType)state->openContainer.type) {
    case CLONEMC_J_CONTAINER_WORKBENCH: return id == 58;
    case CLONEMC_J_CONTAINER_CHEST: return id == 54;
    case CLONEMC_J_CONTAINER_FURNACE: return id == 61 || id == 62;
    case CLONEMC_J_CONTAINER_DISPENSER: return id == 23;
    default: return 1;
    }
}

CloneMCJ_Vehicle *CloneMCJ_Gameplay_GetOpenVehicleInventory(CloneMCJ_GameplayState *state)
{
    int i;if(!state||state->openVehicleInventoryId<=0)return (CloneMCJ_Vehicle *)0;
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(state->vehicles[i].active&&
        state->vehicles[i].type==CLONEMC_J_VEHICLE_MINECART&&state->vehicles[i].minecartType==1&&
        state->vehicles[i].entity.entityId==state->openVehicleInventoryId)return &state->vehicles[i];
    return (CloneMCJ_Vehicle *)0;
}

int CloneMCJ_Gameplay_PrepareSave(CloneMCJ_World *world, void *userData)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_NBTTagCompound *playerTag;
    CloneMCJ_NBTBase *clone;
    int entitySyncOk;
    state = (CloneMCJ_GameplayState *)userData;
    if (!world || !state) return 0;
    state->lastSaveError[0]='\0';
    world->lastSaveError[0]='\0';

    /* Java saves the player independently from the loaded-chunk entity lists.
     * A projectile crossing the resident-chunk boundary must not make Player
     * NBT impossible to capture.  Keep the diagnostic counter, but serialize
     * every entity that still belongs to a loaded chunk and continue. */
    entitySyncOk=CloneMCJ_Gameplay_SynchronizeChunkEntities(state,1);
    if(!entitySyncOk){
        strcpy(state->lastSaveError,
            "Some transient entities were outside the loaded chunk set; player and loaded entities were still captured");
    }
    state->player.dimension = world->worldInfo.dimension;

    /* Preserve unknown Java/mod tags by cloning the last valid Player compound
     * before overwriting the fields owned by EntityPlayer.  Publication is
     * transactional: the current worldInfo.playerTag is untouched until a
     * complete replacement exists. */
    playerTag=(CloneMCJ_NBTTagCompound *)0;
    if(world->worldInfo.playerTag&&world->worldInfo.playerTag->type==10){
        clone=CloneMCJ_NBTBase_Clone(world->worldInfo.playerTag);
        if(clone&&clone->type==10)playerTag=(CloneMCJ_NBTTagCompound *)clone;
        else if(clone)CloneMCJ_NBTBase_Free(clone);
    }
    if(!playerTag)playerTag=CloneMCJ_NBTTagCompound_Create();
    if(!playerTag){
        strcpy(state->lastSaveError,"Could not allocate the Player NBT snapshot");
        strcpy(world->lastSaveError,state->lastSaveError);
        return 0;
    }
    if(!CloneMCJ_EntityPlayer_WriteNBT(&state->player,playerTag)){
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)playerTag);
        /* One bounded retry with a clean compound avoids a partially cloned or
         * malformed legacy Player tag blocking an otherwise valid save. */
        playerTag=CloneMCJ_NBTTagCompound_Create();
        if(!playerTag||!CloneMCJ_EntityPlayer_WriteNBT(&state->player,playerTag)){
            if(playerTag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)playerTag);
            strcpy(state->lastSaveError,"Could not serialize current position, inventory, health, and dimension into Player NBT");
            strcpy(world->lastSaveError,state->lastSaveError);
            return 0;
        }
    }
    if (world->worldInfo.playerTag)
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)world->worldInfo.playerTag);
    world->worldInfo.playerTag = (CloneMCJ_NBTBase *)playerTag;
    world->worldInfo.dimension = state->player.dimension;
    return 1;
}

void CloneMCJ_EntityPlayerSP_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityPlayerSP_JavaName(void)
{
    return "net.minecraft.src.EntityPlayerSP";
}

const char *CloneMCJ_EntityPlayerSP_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityPlayerSP_JavaSourceHash32(void)
{
    return 0x52782725UL;
}
