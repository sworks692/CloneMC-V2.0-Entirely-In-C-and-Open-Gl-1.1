/*
 * CloneMC Java port scaffold: EntityLightningBolt
 *
 * Java source: EntityLightningBolt.java
 * Java type: class EntityLightningBolt
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityWeatherEffect
 * Implements: (none declared)
 * Source SHA-256: a16538f138260664631697c3345f35699fae1b3aa8b50e6c7921e01558e0d6a4
 * Java lines: 116
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: EntityWeatherEffect, World, MathHelper, Block, BlockFire, AxisAlignedBB, Entity, NBTTagCompound, Vec3D, d1, d2, k, i, i1, j1, l, k1, posY, posZ
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_27028_b
 * - public long field_27029_a
 * - private int field_27030_c
 *
 * Java method/constructor inventory:
 * - public EntityLightningBolt(World world, double d, double d1, double d2)
 * - public void onUpdate()
 * - protected void entityInit()
 * - protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public boolean isInRangeToRenderVec3D(Vec3D vec3d)
 *
 * This class now owns lightning lifetime/randomization construction; ignition,
 * entity strikes and rendering use the bounded weather-vehicle runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityLightningBolt_InitializeNative(CloneMCJ_Vehicle *lightning,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_Vehicle_Initialize(lightning,CLONEMC_J_VEHICLE_LIGHTNING,world,x,y,z,0);
}

void CloneMCJ_EntityLightningBolt_Register(void)
{
    /* Runtime dispatch is installed through the bounded vehicle table. */
}

const char *CloneMCJ_EntityLightningBolt_JavaName(void)
{
    return "net.minecraft.src.EntityLightningBolt";
}

const char *CloneMCJ_EntityLightningBolt_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityLightningBolt_JavaSourceHash32(void)
{
    return 0xA16538F1UL;
}
