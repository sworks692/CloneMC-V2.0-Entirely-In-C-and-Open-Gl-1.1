/*
 * CloneMC Java port scaffold: EntityGiantZombie
 *
 * Java source: EntityGiantZombie.java
 * Java type: class EntityGiantZombie
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityMob
 * Implements: (none declared)
 * Source SHA-256: a0de64e66b4d485a29e89fbb1d1cc81fc37f3e6ed69e71aba346b36b597ceb03
 * Java lines: 30
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: EntityMob, World, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityGiantZombie(World world)
 * - protected float getBlockPathWeight(int i, int j, int k)
 *
 * This class now owns its typed constructor adapter. EntityLiving applies the
 * uploaded tenfold health, 50 damage and sixfold dimensions.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityGiantZombie_InitializeNative(CloneMCJ_Mob *giant,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(giant,CLONEMC_J_MOB_GIANT,world,x,y,z);
}

void CloneMCJ_EntityGiantZombie_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntityGiantZombie_JavaName(void)
{
    return "net.minecraft.src.EntityGiantZombie";
}

const char *CloneMCJ_EntityGiantZombie_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityGiantZombie_JavaSourceHash32(void)
{
    return 0xA0DE64E6UL;
}
