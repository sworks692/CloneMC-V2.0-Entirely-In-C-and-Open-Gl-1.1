/*
 * CloneMC Java port scaffold: IMob
 *
 * Java source: IMob.java
 * Java type: interface IMob
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 9cf102147fcc9fe01af9dac865ebfa17787a96e3ec808e1b556b33dd6853bc1c
 * Java lines: 11
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_IMob_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_IMob_JavaName(void)
{
    return "net.minecraft.src.IMob";
}

const char *CloneMCJ_IMob_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_IMob_JavaSourceHash32(void)
{
    return 0x9CF10214UL;
}
