/*
 * CloneMC Java port scaffold: Pathfinder
 *
 * Java source: Pathfinder.java
 * Java type: class Pathfinder
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: ed0cb51dcf92ef06b6064bb1dc649c8b23833fc14333699d8e5d81f99cf7d57e
 * Java lines: 247
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: Path, MCHash, PathPoint, Entity, AxisAlignedBB, MathHelper, IBlockAccess, Block, BlockDoor, Material, PathEntity, entity1.posX, entity1.boundingBox.minY, entity1.posZ, pathpoint, pathpoint1, pathpoint2, pathpoint.distanceToTarget
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private IBlockAccess worldMap
 * - private Path path
 * - private MCHash pointMap
 * - private PathPoint pathOptions[]
 *
 * Java method/constructor inventory:
 * - public Pathfinder(IBlockAccess iblockaccess)
 * - public PathEntity createEntityPathTo(Entity entity, Entity entity1, float f)
 * - public PathEntity createEntityPathTo(Entity entity, int i, int j, int k, float f)
 * - private PathEntity addToPath(Entity entity, PathPoint pathpoint, PathPoint pathpoint1, PathPoint pathpoint2, float f)
 * - private int findPathOptions(Entity entity, PathPoint pathpoint, PathPoint pathpoint1, PathPoint pathpoint2, float f)
 * - private PathPoint getSafePoint(Entity entity, int i, int j, int k, PathPoint pathpoint, int l)
 * - private final PathPoint openPoint(int i, int j, int k)
 * - private int getVerticalOffset(Entity entity, int i, int j, int k, PathPoint pathpoint)
 * - private PathEntity createEntityPath(PathPoint pathpoint, PathPoint pathpoint1)
 *
 * This class now directly owns bounded Java A-star expansion, heap ordering,
 * step/drop/material tests and closest-path fallback.
 */
#include "clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <math.h>
#include <string.h>

typedef struct CloneMCJ_PathSearchTag {
    CloneMCJ_PathPointNative nodes[CLONEMC_J_PATH_SEARCH_NODES];
    int nodeCount;
    int heap[CLONEMC_J_PATH_SEARCH_NODES];
    int heapCount;
} CloneMCJ_PathSearch;

static CloneMCJ_PathSearch g_CloneMCJ_PathSearch;
static int g_CloneMCJ_PathSearchBusy;

static int CloneMCJ_PathOpenPoint(CloneMCJ_PathSearch *search,int x,int y,int z)
{
    int i,hash;
    CloneMCJ_PathPointNative *point;
    hash=CloneMCJ_PathPoint_Hash(x,y,z);
    for(i=0;i<search->nodeCount;++i)if(search->nodes[i].hash==hash&&
        search->nodes[i].xCoord==x&&search->nodes[i].yCoord==y&&search->nodes[i].zCoord==z)return i;
    if(search->nodeCount>=CLONEMC_J_PATH_SEARCH_NODES)return -1;
    i=search->nodeCount++;point=&search->nodes[i];CloneMCJ_PathPoint_InitializeNative(point,x,y,z);
    return i;
}

static int CloneMCJ_PathVerticalOffset(CloneMCJ_World *world,int x,int y,int z,
    int sizeX,int sizeY,int sizeZ)
{
    int bx,by,bz,id,metadata;
    const CloneMCJ_BlockDefinition *block;
    if(y<0||y+sizeY>CLONEMC_J_CHUNK_HEIGHT)return 0;
    for(bx=x;bx<x+sizeX;++bx)for(by=y;by<y+sizeY;++by)for(bz=z;bz<z+sizeZ;++bz){
        id=CloneMCJ_World_GetBlockId(world,bx,by,bz);if(id<=0)continue;
        block=CloneMCJ_BlockRegistry_Get(id);if(!block)continue;
        if(id==64||id==71){metadata=CloneMCJ_World_GetBlockMetadata(world,bx,by,bz);
            if((metadata&4)==0)return 0;
            continue;}
        /* Pathfinder.java tests Material.getIsSolid(), not the render/click
         * collision flag.  Non-solid interactive blocks remain passable. */
        if(block->solid)return 0;
        if(block->material==CLONEMC_J_MATERIAL_WATER)return -1;
        if(block->material==CLONEMC_J_MATERIAL_LAVA)return -2;
    }
    return 1;
}

static int CloneMCJ_PathSafePoint(CloneMCJ_PathSearch *search,CloneMCJ_World *world,
    int x,int y,int z,int sizeX,int sizeY,int sizeZ,int step,int avoidWater,int avoidSun)
{
    int point,below,drops;
    point=-1;below=0;
    if(CloneMCJ_PathVerticalOffset(world,x,y,z,sizeX,sizeY,sizeZ)==1)
        point=CloneMCJ_PathOpenPoint(search,x,y,z);
    if(point<0&&step>0&&CloneMCJ_PathVerticalOffset(world,x,y+step,z,sizeX,sizeY,sizeZ)==1){
        y+=step;point=CloneMCJ_PathOpenPoint(search,x,y,z);
    }
    if(point<0)return -1;
    if(avoidSun&&CloneMCJ_World_CanExistingBlockSeeTheSky(world,x,y,z))return -1;
    if(avoidWater&&CloneMCJ_PathVerticalOffset(world,x,y,z,sizeX,sizeY,sizeZ)==-1)return -1;
    drops=0;
    while(y>0&&(below=CloneMCJ_PathVerticalOffset(world,x,y-1,z,sizeX,sizeY,sizeZ))==1){
        if(++drops>=4)return -1;
        --y;point=CloneMCJ_PathOpenPoint(search,x,y,z);if(point<0)return -1;
    }
    if(below==-2)return -1;
    return point;
}

static int CloneMCJ_PathBuild(CloneMCJ_PathSearch *search,int end,
    CloneMCJ_PathEntityNative *path)
{
    int reverse[CLONEMC_J_MAX_PATH_POINTS];
    int count,index,i;
    count=0;index=end;
    while(index>=0&&count<CLONEMC_J_MAX_PATH_POINTS){reverse[count++]=index;index=search->nodes[index].previousIndex;}
    if(count<=0)return 0;
    memset(path,0,sizeof(*path));path->pathLength=count;
    for(i=0;i<count;++i)path->points[i]=search->nodes[reverse[count-1-i]];
    return 1;
}

int CloneMCJ_Pathfinder_CreatePathEx(CloneMCJ_World *world,const CloneMCJ_Entity *entity,
    double targetX,double targetY,double targetZ,float range,int avoidWater,int avoidSun,
    CloneMCJ_PathEntityNative *path)
{
    CloneMCJ_PathSearch *search;
    CloneMCJ_PathPointNative *current,*goal,*neighbor;
    int startIndex,goalIndex,currentIndex,bestIndex,neighbors[4],count,i,index;
    int sizeX,sizeY,sizeZ,step,success;
    float newDistance,bestDistance,penalty;
    if(!world||!entity||!path||range<=0.0F)return 0;
    if(g_CloneMCJ_PathSearchBusy)return 0;
    g_CloneMCJ_PathSearchBusy=1;success=0;
    search=&g_CloneMCJ_PathSearch;memset(search,0,sizeof(*search));
    sizeX=CloneMCJava_FloorFloat(entity->width+1.0F);
    sizeY=CloneMCJava_FloorFloat(entity->height+1.0F);
    sizeZ=sizeX;if(sizeX<1)sizeX=1;if(sizeY<1)sizeY=1;
    startIndex=CloneMCJ_PathOpenPoint(search,CloneMCJava_FloorDouble(entity->boundingBox.minX),
        CloneMCJava_FloorDouble(entity->boundingBox.minY),CloneMCJava_FloorDouble(entity->boundingBox.minZ));
    goalIndex=CloneMCJ_PathOpenPoint(search,CloneMCJava_FloorDouble(targetX-(double)(entity->width/2.0F)),
        CloneMCJava_FloorDouble(targetY),CloneMCJava_FloorDouble(targetZ-(double)(entity->width/2.0F)));
    if(startIndex<0||goalIndex<0)goto done;
    goal=&search->nodes[goalIndex];search->nodes[startIndex].totalPathDistance=0.0F;
    search->nodes[startIndex].distanceToNext=CloneMCJ_PathPoint_DistanceTo(&search->nodes[startIndex],goal);
    search->nodes[startIndex].distanceToTarget=search->nodes[startIndex].distanceToNext;
    if(!CloneMCJ_Path_AddPoint(search->heap,&search->heapCount,search->nodes,startIndex,
        CLONEMC_J_PATH_SEARCH_NODES))goto done;
    bestIndex=startIndex;bestDistance=search->nodes[startIndex].distanceToNext;
    while(search->heapCount>0){
        currentIndex=CloneMCJ_Path_Dequeue(search->heap,&search->heapCount,search->nodes);if(currentIndex<0)break;
        current=&search->nodes[currentIndex];
        if(current->xCoord==goal->xCoord&&current->yCoord==goal->yCoord&&current->zCoord==goal->zCoord){
            success=CloneMCJ_PathBuild(search,currentIndex,path);goto done;
        }
        if(CloneMCJ_PathPoint_DistanceTo(current,goal)<bestDistance){
            bestDistance=CloneMCJ_PathPoint_DistanceTo(current,goal);bestIndex=currentIndex;
        }
        current->closed=1;step=CloneMCJ_PathVerticalOffset(world,current->xCoord,current->yCoord+1,
            current->zCoord,sizeX,sizeY,sizeZ)==1?1:0;
        count=0;
        index=CloneMCJ_PathSafePoint(search,world,current->xCoord,current->yCoord,current->zCoord+1,
            sizeX,sizeY,sizeZ,step,avoidWater,avoidSun);if(index>=0)neighbors[count++]=index;
        index=CloneMCJ_PathSafePoint(search,world,current->xCoord-1,current->yCoord,current->zCoord,
            sizeX,sizeY,sizeZ,step,avoidWater,avoidSun);if(index>=0)neighbors[count++]=index;
        index=CloneMCJ_PathSafePoint(search,world,current->xCoord+1,current->yCoord,current->zCoord,
            sizeX,sizeY,sizeZ,step,avoidWater,avoidSun);if(index>=0)neighbors[count++]=index;
        index=CloneMCJ_PathSafePoint(search,world,current->xCoord,current->yCoord,current->zCoord-1,
            sizeX,sizeY,sizeZ,step,avoidWater,avoidSun);if(index>=0)neighbors[count++]=index;
        for(i=0;i<count;++i){
            neighbor=&search->nodes[neighbors[i]];
            if(neighbor->closed||CloneMCJ_PathPoint_DistanceTo(neighbor,goal)>=range)continue;
            penalty=0.0F;
            if(!avoidWater&&CloneMCJ_PathVerticalOffset(world,neighbor->xCoord,neighbor->yCoord,
                neighbor->zCoord,sizeX,sizeY,sizeZ)==-1)penalty=4.0F;
            if(!avoidSun&&CloneMCJ_World_CanExistingBlockSeeTheSky(world,neighbor->xCoord,
                neighbor->yCoord,neighbor->zCoord))penalty+=0.25F;
            newDistance=current->totalPathDistance+CloneMCJ_PathPoint_DistanceTo(current,neighbor)+penalty;
            if(!neighbor->opened||newDistance<neighbor->totalPathDistance){
                neighbor->previousIndex=currentIndex;neighbor->totalPathDistance=newDistance;
                neighbor->distanceToNext=CloneMCJ_PathPoint_DistanceTo(neighbor,goal);
                if(neighbor->opened)CloneMCJ_Path_ChangeDistance(search->heap,search->heapCount,
                    search->nodes,neighbors[i],newDistance+neighbor->distanceToNext);
                else{neighbor->distanceToTarget=newDistance+neighbor->distanceToNext;
                    CloneMCJ_Path_AddPoint(search->heap,&search->heapCount,search->nodes,
                        neighbors[i],CLONEMC_J_PATH_SEARCH_NODES);}
            }
        }
    }
    if(bestIndex!=startIndex)success=CloneMCJ_PathBuild(search,bestIndex,path);
done:
    g_CloneMCJ_PathSearchBusy=0;return success;
}

int CloneMCJ_Pathfinder_CreatePath(CloneMCJ_World *world,const CloneMCJ_Entity *entity,
    double targetX,double targetY,double targetZ,float range,CloneMCJ_PathEntityNative *path)
{
    return CloneMCJ_Pathfinder_CreatePathEx(world,entity,targetX,targetY,targetZ,range,1,0,path);
}

void CloneMCJ_Pathfinder_Register(void)
{
    /* The fixed search workspace requires no runtime registration. */
}

const char *CloneMCJ_Pathfinder_JavaName(void)
{
    return "net.minecraft.src.Pathfinder";
}

const char *CloneMCJ_Pathfinder_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_Pathfinder_JavaSourceHash32(void)
{
    return 0xED0CB51DUL;
}
