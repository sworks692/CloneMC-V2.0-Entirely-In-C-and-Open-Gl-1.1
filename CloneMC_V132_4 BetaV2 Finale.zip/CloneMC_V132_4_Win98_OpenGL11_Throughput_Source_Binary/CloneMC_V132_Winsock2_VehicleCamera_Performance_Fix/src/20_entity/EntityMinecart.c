/*
 * CloneMC Java port scaffold: EntityMinecart
 *
 * Java source: EntityMinecart.java
 * Java type: class EntityMinecart
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: IInventory
 * Source SHA-256: ce25d9f878f31b29f8658358cbdba3496d1ce8427a5d9fd38992b63e66bbf377
 * Java lines: 997
 * Discovered declared fields: 18
 * Discovered declared methods/constructors: 28
 * Referenced Java classes: Entity, IInventory, ItemStack, World, Item, EntityItem, Block, MathHelper, BlockRail, Vec3D, AxisAlignedBB, NBTTagCompound, NBTTagList, EntityLiving, EntityPlayer, InventoryPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private ItemStack cargoItems[]
 * - public int minecartCurrentDamage
 * - public int minecartTimeSinceHit
 * - public int minecartRockDirection
 * - private boolean field_856_i
 * - public int minecartType
 * - public int fuel
 * - public double pushX
 * - public double pushZ
 * - private int field_9415_k
 * - private double field_9414_l
 * - private double field_9413_m
 * - private double field_9412_n
 * - private double field_9411_o
 * - private double field_9410_p
 * - private double field_9409_q
 * - private double field_9408_r
 * - private double field_9407_s
 *
 * Java method/constructor inventory:
 * - public EntityMinecart(World world)
 * - protected boolean canTriggerWalking()
 * - protected void entityInit()
 * - public AxisAlignedBB getCollisionBox(Entity entity)
 * - public AxisAlignedBB getBoundingBox()
 * - public boolean canBePushed()
 * - public double getMountedYOffset()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public void performHurtAnimation()
 * - public boolean canBeCollidedWith()
 * - public void setEntityDead()
 * - public void onUpdate()
 * - public Vec3D func_515_a(double d, double d1, double d2, double d3)
 * - public Vec3D func_514_g(double d, double d1, double d2)
 * - protected void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - protected void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public float getShadowSize()
 * - public void applyEntityCollision(Entity entity)
 * - public int getSizeInventory()
 * - public ItemStack getStackInSlot(int i)
 * - public ItemStack decrStackSize(int i, int j)
 * - public void setInventorySlotContents(int i, ItemStack itemstack)
 * - public String getInvName()
 * - public int getInventoryStackLimit()
 * - public void onInventoryChanged()
 * - public boolean interact(EntityPlayer entityplayer)
 * - public void setVelocity(double d, double d1, double d2)
 * - public boolean canInteractWith(EntityPlayer entityplayer)
 *
 * This class now owns the typed minecart constructor; rail movement, damage,
 * subtype inventory/fuel and NBT are shared by the bounded vehicle runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityMinecart_InitializeNative(CloneMCJ_Vehicle *minecart,
    struct CloneMCJ_WorldTag *world,double x,double y,double z,int type)
{
    CloneMCJ_Vehicle_Initialize(minecart,CLONEMC_J_VEHICLE_MINECART,world,x,y,z,type);
}

void CloneMCJ_EntityMinecart_Register(void)
{
    /* Runtime dispatch is installed through the bounded vehicle table. */
}

const char *CloneMCJ_EntityMinecart_JavaName(void)
{
    return "net.minecraft.src.EntityMinecart";
}

const char *CloneMCJ_EntityMinecart_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityMinecart_JavaSourceHash32(void)
{
    return 0xCE25D9F8UL;
}
