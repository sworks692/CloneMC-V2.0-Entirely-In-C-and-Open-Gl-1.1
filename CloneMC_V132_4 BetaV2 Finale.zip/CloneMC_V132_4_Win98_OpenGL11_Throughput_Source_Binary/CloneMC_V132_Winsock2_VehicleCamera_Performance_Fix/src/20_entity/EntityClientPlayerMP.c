/*
 * CloneMC Java port scaffold: EntityClientPlayerMP
 *
 * Java source: EntityClientPlayerMP.java
 * Java type: class EntityClientPlayerMP
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityPlayerSP
 * Implements: (none declared)
 * Source SHA-256: 39f8b360ee432e273794ed91a71ccd2fe52f20fb66ab7f94a9f1d847572849c6
 * Java lines: 222
 * Discovered declared fields: 12
 * Discovered declared methods/constructors: 16
 * Referenced Java classes: EntityPlayerSP, MathHelper, World, Packet19EntityAction, NetClientHandler, AxisAlignedBB, Packet11PlayerPosition, Packet13PlayerLookMove, Packet12PlayerLook, Packet10Flying, Packet14BlockDig, Packet3Chat, Packet18Animation, Packet9Respawn, Packet101CloseWindow, Container, InventoryPlayer, StatBase, Session, Entity, EntityItem, world, session
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public NetClientHandler sendQueue
 * - private int field_9380_bx
 * - private boolean field_21093_bH
 * - private double oldPosX
 * - private double field_9378_bz
 * - private double oldPosY
 * - private double oldPosZ
 * - private float oldRotationYaw
 * - private float oldRotationPitch
 * - private boolean field_9382_bF
 * - private boolean wasSneaking
 * - private int field_12242_bI
 *
 * Java method/constructor inventory:
 * - public EntityClientPlayerMP(Minecraft minecraft, World world, Session session, NetClientHandler netclienthandler)
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public void heal(int i)
 * - public void onUpdate()
 * - public void func_4056_N()
 * - public void dropCurrentItem()
 * - private void sendInventoryChanged()
 * - protected void joinEntityItemWithWorld(EntityItem entityitem)
 * - public void sendChatMessage(String s)
 * - public void swingItem()
 * - public void respawnPlayer()
 * - protected void damageEntity(int i)
 * - public void closeScreen()
 * - public void setHealth(int i)
 * - public void addStat(StatBase statbase, int i)
 * - public void func_27027_b(StatBase statbase, int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityClientPlayerMP_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityClientPlayerMP_JavaName(void)
{
    return "net.minecraft.src.EntityClientPlayerMP";
}

const char *CloneMCJ_EntityClientPlayerMP_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityClientPlayerMP_JavaSourceHash32(void)
{
    return 0x39F8B360UL;
}
