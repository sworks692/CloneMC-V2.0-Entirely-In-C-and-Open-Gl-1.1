/*
 * CloneMC Java port scaffold: EntityAnimal
 *
 * Java source: EntityAnimal.java
 * Java type: class EntityAnimal
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityCreature
 * Implements: (none declared)
 * Source SHA-256: 059c11aa235b684a79806d7980ad2ff36403df37e466464212d9637a492827c3
 * Java lines: 54
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: EntityCreature, World, Block, BlockGrass, MathHelper, AxisAlignedBB, NBTTagCompound, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityAnimal(World world)
 * - protected float getBlockPathWeight(int i, int j, int k)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public boolean getCanSpawnHere()
 * - public int getTalkInterval()
 *
 * This class now owns the Java passive-animal talk interval contract; spawn and
 * wandering behavior are driven by SpawnerAnimals and EntityLiving.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_EntityAnimal_GetTalkIntervalNative(void)
{
    return 120;
}

void CloneMCJ_EntityAnimal_Register(void)
{
    /* Passive behavior is selected by mob type during construction. */
}

const char *CloneMCJ_EntityAnimal_JavaName(void)
{
    return "net.minecraft.src.EntityAnimal";
}

const char *CloneMCJ_EntityAnimal_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityAnimal_JavaSourceHash32(void)
{
    return 0x059C11AAUL;
}
