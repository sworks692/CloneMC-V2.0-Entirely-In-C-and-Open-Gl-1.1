/*
 * CloneMC Java port scaffold: EnumArt
 *
 * Java source: EnumArt.java
 * Java type: enum EnumArt
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 946a80d9f716219a28dd2442dd4d1c54e7a90cd232f6270d140c8fbf17ed516f
 * Java lines: 126
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final String title
 * - public final int sizeX
 * - public final int sizeY
 * - public final int offsetX
 * - public final int offsetY
 * - private static final EnumArt field_1630_D[]
 *
 * Java method/constructor inventory:
 * - private EnumArt(String s, int i, String s1, int j, int k, int l, int i1)
 * - public static final int maxArtTitleLength = "SkullAndRoses".length()
 *
 * This class now directly owns all 25 uploaded Beta painting titles, dimensions
 * and `kz` atlas offsets in Java declaration order.
 */
#include "clonemc_java_port_20_entity.h"
#include <string.h>

static const CloneMCJ_ArtDefinition g_CloneMCJ_Art[] = {
    {"Kebab",16,16,0,0},{"Aztec",16,16,16,0},{"Alban",16,16,32,0},
    {"Aztec2",16,16,48,0},{"Bomb",16,16,64,0},{"Plant",16,16,80,0},
    {"Wasteland",16,16,96,0},{"Pool",32,16,0,32},{"Courbet",32,16,32,32},
    {"Sea",32,16,64,32},{"Sunset",32,16,96,32},{"Creebet",32,16,128,32},
    {"Wanderer",16,32,0,64},{"Graham",16,32,16,64},{"Match",32,32,0,128},
    {"Bust",32,32,32,128},{"Stage",32,32,64,128},{"Void",32,32,96,128},
    {"SkullAndRoses",32,32,128,128},{"Fighters",64,32,0,96},
    {"Pointer",64,64,0,192},{"Pigscene",64,64,64,192},
    {"BurningSkull",64,64,128,192},{"Skeleton",64,48,192,64},
    {"DonkeyKong",64,48,192,112}
};

int CloneMCJ_EnumArt_Count(void)
{
    return (int)(sizeof(g_CloneMCJ_Art)/sizeof(g_CloneMCJ_Art[0]));
}

const CloneMCJ_ArtDefinition *CloneMCJ_EnumArt_At(int index)
{
    return index>=0&&index<CloneMCJ_EnumArt_Count()?&g_CloneMCJ_Art[index]:(const CloneMCJ_ArtDefinition *)0;
}

const CloneMCJ_ArtDefinition *CloneMCJ_EnumArt_Find(const char *title)
{
    int i;if(!title)return (const CloneMCJ_ArtDefinition *)0;
    for(i=0;i<CloneMCJ_EnumArt_Count();++i)if(!strcmp(g_CloneMCJ_Art[i].title,title))return &g_CloneMCJ_Art[i];
    return (const CloneMCJ_ArtDefinition *)0;
}

void CloneMCJ_EnumArt_Register(void)
{
    /* The static Java declaration table requires no runtime registration. */
}

const char *CloneMCJ_EnumArt_JavaName(void)
{
    return "net.minecraft.src.EnumArt";
}

const char *CloneMCJ_EnumArt_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EnumArt_JavaSourceHash32(void)
{
    return 0x946A80D9UL;
}
