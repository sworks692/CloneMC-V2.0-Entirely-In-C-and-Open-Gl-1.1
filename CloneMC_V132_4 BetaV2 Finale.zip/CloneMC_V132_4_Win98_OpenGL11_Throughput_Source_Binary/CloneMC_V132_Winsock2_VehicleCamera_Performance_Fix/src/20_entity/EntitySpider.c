/*
 * CloneMC Java port scaffold: EntitySpider
 *
 * Java source: EntitySpider.java
 * Java type: class EntitySpider
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityMob
 * Implements: (none declared)
 * Source SHA-256: 74e6f68b8043653be6689767aa173243f4af27633866def765bab9388c88e4c1
 * Java lines: 107
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: EntityMob, World, Entity, MathHelper, Item, NBTTagCompound, public
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntitySpider(World world)
 * - public double getMountedYOffset()
 * - protected boolean canTriggerWalking()
 * - protected Entity findPlayerToAttack()
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected void attackEntity(Entity entity, float f)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected int getDropItemId()
 * - public boolean isOnLadder()
 *
 * This class now owns typed construction; daylight temperament, leap attack,
 * wall climbing, jockey creation and drops run through the shared mob runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntitySpider_InitializeNative(CloneMCJ_Mob *spider,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(spider,CLONEMC_J_MOB_SPIDER,world,x,y,z);
}

void CloneMCJ_EntitySpider_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntitySpider_JavaName(void)
{
    return "net.minecraft.src.EntitySpider";
}

const char *CloneMCJ_EntitySpider_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntitySpider_JavaSourceHash32(void)
{
    return 0x74E6F68BUL;
}
