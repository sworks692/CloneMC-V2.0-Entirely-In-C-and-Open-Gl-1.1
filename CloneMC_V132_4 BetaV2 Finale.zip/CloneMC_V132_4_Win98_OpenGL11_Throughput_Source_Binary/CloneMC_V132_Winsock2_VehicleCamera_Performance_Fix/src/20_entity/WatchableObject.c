/*
 * CloneMC Java port scaffold: WatchableObject
 *
 * Java source: WatchableObject.java
 * Java type: class WatchableObject
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 0fd588df6179242b3d662b13b4b47344b607d74b24b7720da1c8e2d463e96274
 * Java lines: 49
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final int objectType
 * - private final int dataValueId
 * - private Object watchedObject
 * - private boolean isWatching
 *
 * Java method/constructor inventory:
 * - public WatchableObject(int i, int j, Object obj)
 * - public int getDataValueId()
 * - public void setObject(Object obj)
 * - public Object getObject()
 * - public int getObjectType()
 * - public void setWatching(boolean flag)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_WatchableObject_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WatchableObject_JavaName(void)
{
    return "net.minecraft.src.WatchableObject";
}

const char *CloneMCJ_WatchableObject_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_WatchableObject_JavaSourceHash32(void)
{
    return 0x0FD588DFUL;
}
