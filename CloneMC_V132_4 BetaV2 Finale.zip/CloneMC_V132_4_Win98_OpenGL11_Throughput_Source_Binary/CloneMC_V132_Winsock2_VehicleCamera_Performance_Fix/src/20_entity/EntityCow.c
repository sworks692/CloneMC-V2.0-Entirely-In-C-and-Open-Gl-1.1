/*
 * CloneMC Java port scaffold: EntityCow
 *
 * Java source: EntityCow.java
 * Java type: class EntityCow
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityAnimal
 * Implements: (none declared)
 * Source SHA-256: 45c047acd313192a6866dbb4095d1dfc39b7c06334fce2e46299c3df23e28fc0
 * Java lines: 70
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: EntityAnimal, Item, EntityPlayer, InventoryPlayer, ItemStack, World, NBTTagCompound
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public EntityCow(World world)
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected float getSoundVolume()
 * - protected int getDropItemId()
 * - public boolean interact(EntityPlayer entityplayer)
 *
 * Direct conversion: using an empty bucket replaces the selected stack with the
 * uploaded Java class's milk-bucket result.
 */
#include "clonemc_java_port_20_entity.h"

int CloneMCJ_EntityCow_InteractNative(CloneMCJ_Mob *cow,CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_ItemStack *held;
    if(!cow||cow->type!=CLONEMC_J_MOB_COW||!player)return 0;
    held=CloneMCJ_InventoryPlayer_GetCurrent(&player->inventory);
    if(!held||held->itemID!=325||held->stackSize<=0)return 0;
    CloneMCJ_ItemStack_Initialize(held,335,1,0);player->inventory.inventoryChanged=1;
    return 1;
}

void CloneMCJ_EntityCow_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityCow_JavaName(void)
{
    return "net.minecraft.src.EntityCow";
}

const char *CloneMCJ_EntityCow_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityCow_JavaSourceHash32(void)
{
    return 0x45C047ACUL;
}
