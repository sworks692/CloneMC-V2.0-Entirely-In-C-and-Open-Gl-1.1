/*
 * CloneMC Java port scaffold: EntityGhast
 *
 * Java source: EntityGhast.java
 * Java type: class EntityGhast
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityFlying
 * Implements: IMob
 * Source SHA-256: cf748ca4dd36f269afb8f3ddcb8fd37c92289c4b9d4d2490606b371e57e6a3f7
 * Java lines: 202
 * Discovered declared fields: 8
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: EntityFlying, IMob, DataWatcher, World, MathHelper, Entity, AxisAlignedBB, EntityFireball, Vec3D, Item, waypointY, waypointZ
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int courseChangeCooldown
 * - public double waypointX
 * - public double waypointY
 * - public double waypointZ
 * - private Entity targetedEntity
 * - private int aggroCooldown
 * - public int prevAttackCounter
 * - public int attackCounter
 *
 * Java method/constructor inventory:
 * - public EntityGhast(World world)
 * - protected void entityInit()
 * - public void onUpdate()
 * - protected void updatePlayerActionState()
 * - private boolean isCourseTraversable(double d, double d1, double d2, double d3)
 * - protected String getLivingSound()
 * - protected String getHurtSound()
 * - protected String getDeathSound()
 * - protected int getDropItemId()
 * - protected float getSoundVolume()
 * - public boolean getCanSpawnHere()
 * - public int getMaxSpawnedInChunk()
 *
 * This class now owns its typed constructor adapter. EntityLiving applies the
 * uploaded waypoint, course-change and charge counter AI; EntityPlayerSP emits
 * the charged fireball through the shared projectile runtime.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityGhast_InitializeNative(CloneMCJ_Mob *ghast,
    struct CloneMCJ_WorldTag *world,double x,double y,double z)
{
    CloneMCJ_EntityLiving_InitializeMob(ghast,CLONEMC_J_MOB_GHAST,world,x,y,z);
}

void CloneMCJ_EntityGhast_Register(void)
{
    /* Runtime dispatch is installed through the living-entity table. */
}

const char *CloneMCJ_EntityGhast_JavaName(void)
{
    return "net.minecraft.src.EntityGhast";
}

const char *CloneMCJ_EntityGhast_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityGhast_JavaSourceHash32(void)
{
    return 0xCF748CA4UL;
}
