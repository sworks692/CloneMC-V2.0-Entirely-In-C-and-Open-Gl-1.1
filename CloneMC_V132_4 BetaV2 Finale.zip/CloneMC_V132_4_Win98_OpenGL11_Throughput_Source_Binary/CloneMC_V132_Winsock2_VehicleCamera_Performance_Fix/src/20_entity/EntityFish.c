/*
 * CloneMC Java port scaffold: EntityFish
 *
 * Java source: EntityFish.java
 * Java type: class EntityFish
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: Entity
 * Implements: (none declared)
 * Source SHA-256: 934acf0a47fd13b0daf63dbf7be8c53aa0977e94a23c38bf3b975d441956c28b
 * Java lines: 413
 * Discovered declared fields: 20
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: Entity, EntityPlayer, MathHelper, AxisAlignedBB, World, ItemStack, Item, Vec3D, MovingObjectPosition, Material, NBTTagCompound, EntityItem, StatList, d1, entityplayer.posZ, entityplayer.rotationYaw, posY
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int xTile
 * - private int yTile
 * - private int zTile
 * - private int inTile
 * - private boolean inGround
 * - public int shake
 * - public EntityPlayer angler
 * - private int ticksInGround
 * - private int ticksInAir
 * - private int ticksCatchable
 * - public Entity bobber
 * - private int field_6388_l
 * - private double field_6387_m
 * - private double field_6386_n
 * - private double field_6385_o
 * - private double field_6384_p
 * - private double field_6383_q
 * - private double velocityX
 * - private double velocityY
 * - private double velocityZ
 *
 * Java method/constructor inventory:
 * - public EntityFish(World world)
 * - public EntityFish(World world, double d, double d1, double d2)
 * - public EntityFish(World world, EntityPlayer entityplayer)
 * - protected void entityInit()
 * - public boolean isInRangeToRenderDist(double d)
 * - public void setVelocity(double d, double d1, double d2)
 * - public void onUpdate()
 * - public void writeEntityToNBT(NBTTagCompound nbttagcompound)
 * - public void readEntityFromNBT(NBTTagCompound nbttagcompound)
 * - public float getShadowSize()
 * - public int catchFish()
 *
 * This class now owns the fishing-bobber adapter and Java catch/retraction
 * result semantics; shared projectile flight remains in EntityArrow.c.
 */
#include "clonemc_java_port_20_entity.h"
#include <math.h>

void CloneMCJ_EntityFish_InitializeNative(CloneMCJ_Projectile *fish,
    struct CloneMCJ_WorldTag *world,const CloneMCJ_Entity *angler)
{
    CloneMCJ_Projectile_Initialize(fish,CLONEMC_J_PROJECTILE_FISHING,world,angler,1.5F,1.0F);
}

int CloneMCJ_EntityFish_Catch(CloneMCJ_Projectile *fish,CloneMCJ_GameplayState *state)
{
    CloneMCJ_ItemStack caught;CloneMCJ_Mob *mob;double dx,dy,dz,distance;int i,result;
    if(!fish||!fish->active||fish->type!=CLONEMC_J_PROJECTILE_FISHING||!state)return 0;
    result=0;
    if(fish->hookedEntityId){for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(state->mobs[i].active&&
            state->mobs[i].entity.entityId==fish->hookedEntityId)break;
        if(i<CLONEMC_J_MAX_MOBS){mob=&state->mobs[i];dx=state->player.entity.posX-mob->entity.posX;
            dy=state->player.entity.posY-mob->entity.posY;dz=state->player.entity.posZ-mob->entity.posZ;
            distance=sqrt(dx*dx+dy*dy+dz*dz);mob->entity.motionX+=dx*0.1;
            mob->entity.motionY+=dy*0.1+sqrt(distance)*0.08;mob->entity.motionZ+=dz*0.1;result=3;}}
    else if(fish->ticksCatchable>0){CloneMCJ_EntityItem *drop;CloneMCJ_ItemStack_Initialize(&caught,349,1,0);
        if(CloneMCJ_Gameplay_SpawnDrop(state,fish->entity.posX,fish->entity.posY,fish->entity.posZ,&caught,10,0)){
            drop=(CloneMCJ_EntityItem *)0;for(i=0;i<state->droppedItemCount;++i)if(state->droppedItems[i].active&&
                state->droppedItems[i].age==0&&state->droppedItems[i].item.itemID==349){drop=&state->droppedItems[i];break;}
            if(drop){dx=state->player.entity.posX-fish->entity.posX;dy=state->player.entity.posY-fish->entity.posY;
                dz=state->player.entity.posZ-fish->entity.posZ;distance=sqrt(dx*dx+dy*dy+dz*dz);
                drop->entity.motionX=dx*0.1;drop->entity.motionY=dy*0.1+sqrt(distance)*0.08;
                drop->entity.motionZ=dz*0.1;}
            result=1;
        }}
    if(fish->inGround)result=2;
    fish->active=0;return result;
}

void CloneMCJ_EntityFish_Register(void)
{
    /* Runtime dispatch is installed through the bounded projectile table. */
}

const char *CloneMCJ_EntityFish_JavaName(void)
{
    return "net.minecraft.src.EntityFish";
}

const char *CloneMCJ_EntityFish_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityFish_JavaSourceHash32(void)
{
    return 0x934ACF0AUL;
}
