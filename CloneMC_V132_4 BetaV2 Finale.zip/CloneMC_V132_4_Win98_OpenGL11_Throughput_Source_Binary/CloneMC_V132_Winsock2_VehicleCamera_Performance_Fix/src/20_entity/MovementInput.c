/*
 * CloneMC Java port scaffold: MovementInput
 *
 * Java source: MovementInput.java
 * Java type: class MovementInput
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 66de6764dda3a38e987f8c05dbbfbfa05b078bc9b2a103b5bb19f6ddaf0bc6af
 * Java lines: 41
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: EntityPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public float moveStrafe
 * - public float moveForward
 * - public boolean field_1177_c
 * - public boolean jump
 * - public boolean sneak
 *
 * Java method/constructor inventory:
 * - public MovementInput()
 * - public void updatePlayerMoveState(EntityPlayer entityplayer)
 * - public void resetKeyState()
 * - public void checkKeyForMovementInput(int i, boolean flag)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_MovementInput_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MovementInput_JavaName(void)
{
    return "net.minecraft.src.MovementInput";
}

const char *CloneMCJ_MovementInput_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_MovementInput_JavaSourceHash32(void)
{
    return 0x66DE6764UL;
}
