/*
 * CloneMC Java port scaffold: EntityOtherPlayerMP
 *
 * Java source: EntityOtherPlayerMP.java
 * Java type: class EntityOtherPlayerMP
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: EntityPlayer
 * Implements: (none declared)
 * Source SHA-256: 4bfef93b87bb62c447d8e0631e00ad0f32ebb97ca3a002550244ad8f1e27f338
 * Java lines: 137
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: EntityPlayer, MathHelper, ItemStack, InventoryPlayer, World, Entity
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_785_bg
 * - private double field_784_bh
 * - private double field_783_bi
 * - private double field_782_bj
 * - private double field_780_bk
 * - private double field_786_bl
 *
 * Java method/constructor inventory:
 * - public EntityOtherPlayerMP(World world, String s)
 * - protected void resetHeight()
 * - public boolean attackEntityFrom(Entity entity, int i)
 * - public void onUpdate()
 * - public float getShadowSize()
 * - public void onLivingUpdate()
 * - public void outfitWithItem(int i, int j, int k)
 * - public void func_6420_o()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_EntityOtherPlayerMP_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EntityOtherPlayerMP_JavaName(void)
{
    return "net.minecraft.src.EntityOtherPlayerMP";
}

const char *CloneMCJ_EntityOtherPlayerMP_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_EntityOtherPlayerMP_JavaSourceHash32(void)
{
    return 0x4BFEF93BUL;
}
