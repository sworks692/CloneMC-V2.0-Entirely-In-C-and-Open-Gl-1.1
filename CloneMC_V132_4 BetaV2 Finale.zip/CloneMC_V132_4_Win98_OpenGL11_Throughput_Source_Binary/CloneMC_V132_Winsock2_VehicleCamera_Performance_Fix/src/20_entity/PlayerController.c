/*
 * CloneMC Java port scaffold: PlayerController
 *
 * Java source: PlayerController.java
 * Java type: class PlayerController
 * Package: net.minecraft.src
 * Assigned subsystem: src/20_entity
 * Mapping reason: entity, player controller, movement, collision result, or pathfinding class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: ed5ddf5587ce13361416ab0b62bdd178e8d35d11b7ae78c8b16a11368df5b7ea
 * Java lines: 144
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 19
 * Referenced Java classes: World, Block, ItemStack, EntityPlayer, InventoryPlayer, EntityPlayerSP, WorldProvider, Container, Entity, i, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected final Minecraft mc
 * - public boolean field_1064_b
 *
 * Java method/constructor inventory:
 * - public PlayerController(Minecraft minecraft)
 * - public void func_717_a(World world)
 * - public void clickBlock(int i, int j, int k, int l)
 * - public boolean sendBlockRemoved(int i, int j, int k, int l)
 * - public void sendBlockRemoving(int i, int j, int k, int l)
 * - public void resetBlockRemoving()
 * - public void setPartialTime(float f)
 * - public float getBlockReachDistance()
 * - public boolean sendUseItem(EntityPlayer entityplayer, World world, ItemStack itemstack)
 * - public void flipPlayer(EntityPlayer entityplayer)
 * - public void updateController()
 * - public boolean shouldDrawHUD()
 * - public void func_6473_b(EntityPlayer entityplayer)
 * - public boolean sendPlaceBlock(EntityPlayer entityplayer, World world, ItemStack itemstack, int i, int j, int k, int l)
 * - public EntityPlayer createPlayer(World world)
 * - public void interactWithEntity(EntityPlayer entityplayer, Entity entity)
 * - public void attackEntity(EntityPlayer entityplayer, Entity entity)
 * - public ItemStack func_27174_a(int i, int j, int k, boolean flag, EntityPlayer entityplayer)
 * - public void func_20086_a(int i, EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_20_entity.h"

void CloneMCJ_PlayerController_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_PlayerController_JavaName(void)
{
    return "net.minecraft.src.PlayerController";
}

const char *CloneMCJ_PlayerController_AssignedFolder(void)
{
    return "src/20_entity";
}

unsigned long CloneMCJ_PlayerController_JavaSourceHash32(void)
{
    return 0xED5DDF55UL;
}
