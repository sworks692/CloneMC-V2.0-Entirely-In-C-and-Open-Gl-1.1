/* Direct C89 achievement dependency and persistence behavior. */
#include "clonemc_java_port_60_ui.h"

int CloneMCJ_Achievement_IsUnlockedNative(const CloneMCJ_StatFileState *state,int index)
{
    const CloneMCJ_AchievementDefinition *achievement;
    achievement=CloneMCJ_AchievementList_GetNative(index);
    if(!state||!achievement)return 0;
    return CloneMCJ_StatFileWriter_GetNative(state,achievement->statId)>0;
}

int CloneMCJ_Achievement_CanUnlockNative(const CloneMCJ_StatFileState *state,int index)
{
    const CloneMCJ_AchievementDefinition *achievement;
    achievement=CloneMCJ_AchievementList_GetNative(index);
    if(!state||!achievement)return 0;
    if(achievement->parentIndex<0)return 1;
    return CloneMCJ_Achievement_IsUnlockedNative(state,achievement->parentIndex);
}

int CloneMCJ_Achievement_UnlockNative(CloneMCJ_StatFileState *state,int index)
{
    const CloneMCJ_AchievementDefinition *achievement;
    if(!state||CloneMCJ_Achievement_IsUnlockedNative(state,index))return 0;
    if(!CloneMCJ_Achievement_CanUnlockNative(state,index))return 0;
    achievement=CloneMCJ_AchievementList_GetNative(index);
    return achievement&&CloneMCJ_StatFileWriter_SetNative(state,achievement->statId,1);
}

void CloneMCJ_Achievement_Register(void){}
const char *CloneMCJ_Achievement_JavaName(void){return "net.minecraft.src.Achievement";}
const char *CloneMCJ_Achievement_AssignedFolder(void){return "src/60_ui";}
unsigned long CloneMCJ_Achievement_JavaSourceHash32(void){return 0xBF66F17AUL;}
