/*
 * CloneMC Java port scaffold: GuiIngameMenu
 *
 * Java source: GuiIngameMenu.java
 * Java type: class GuiIngameMenu
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: b6f7bcfd3b1b54529e1ca8b5ec6f282225ecb5b15cb5d7417fafe8c405dd094b
 * Java lines: 95
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: GuiScreen, GuiButton, StatCollector, GuiOptions, StatList, StatFileWriter, World, GuiMainMenu, GuiAchievements, GuiStats, MathHelper
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int updateCounter2
 * - private int updateCounter
 *
 * Java method/constructor inventory:
 * - public GuiIngameMenu()
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void updateScreen()
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiIngameMenu_InitNative(CloneMCJ_GuiScreenState *screen,int multiplayer)
{
    int width,height,scale,center,top;if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_OPTIONS,
        CLONEMC_GUI_SCREEN_NONE,scale);screen->width=width;screen->height=height;
    center=width/2;top=height/4+8;strcpy(screen->title,"Game menu");
    CloneMCJ_GuiScreen_AddButtonNative(screen,4,center-100,top,200,20,"Back to game");
    CloneMCJ_GuiScreen_AddButtonNative(screen,5,center-101,top+24,98,20,"Achievements");
    CloneMCJ_GuiScreen_AddButtonNative(screen,6,center+3,top+24,98,20,"Statistics");
    CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-100,top+72,200,20,"Options...");
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,top+96,200,20,
        multiplayer?"Disconnect":"Save and quit to title");
}

void CloneMCJ_GuiIngameMenu_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiIngameMenu_JavaName(void)
{
    return "net.minecraft.src.GuiIngameMenu";
}

const char *CloneMCJ_GuiIngameMenu_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiIngameMenu_JavaSourceHash32(void)
{
    return 0xB6F7BCFDUL;
}
