/*
 * CloneMC Java port scaffold: GuiIngame
 *
 * Java source: GuiIngame.java
 * Java type: class GuiIngame
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: Gui
 * Implements: (none declared)
 * Source SHA-256: 0d72071a0b49fd365e171cdcb99ba626e42e82b1ead562df74d959cebb5f6af7
 * Java lines: 444
 * Discovered declared fields: 9
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: Gui, ScaledResolution, EntityRenderer, EntityPlayerSP, InventoryPlayer, GameSettings, ItemStack, Block, RenderEngine, PlayerController, Material, RenderHelper, FontRenderer, MathHelper, GuiChat, ChatLine, Tessellator, BlockPortal, RenderItem, StringTranslate, mc.displayWidth, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private java.util.List chatMessageList
 * - private Random rand
 * - private Minecraft mc
 * - public String field_933_a
 * - private int updateCounter
 * - private String recordPlaying
 * - private int recordPlayingUpFor
 * - private boolean field_22065_l
 * - public float damageGuiPartialTime
 *
 * Java method/constructor inventory:
 * - public GuiIngame(Minecraft minecraft)
 * - public void renderGameOverlay(float f, boolean flag, int i, int j)
 * - private void renderPumpkinBlur(int i, int j)
 * - private void renderVignette(float f, int i, int j)
 * - private void renderPortalOverlay(float f, int i, int j)
 * - private void renderInventorySlot(int i, int j, int k, float f)
 * - public void updateTick()
 * - public void clearChatMessages()
 * - public void addChatMessage(String s)
 * - public void setRecordPlayingMessage(String s)
 * - public void addChatMessageTranslate(String s)
 * - private static RenderItem itemRenderer = new RenderItem()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiIngame_Initialize(CloneMCJ_GuiIngameState *gui)
{
    if(!gui)return;
    memset(gui,0,sizeof(*gui));
    gui->scaleFactor=1;
    gui->hoveredSlot=-1;
    gui->lastSelectedSlot=-1;
    gui->lastSelectedItemId=-1;
    gui->lastSelectedDamage=-1;
}

void CloneMCJ_GuiIngame_UpdateResolution(CloneMCJ_GuiIngameState *gui,int width,int height)
{
    int scale;
    if(!gui)return;
    if(width<1)width=1;
    if(height<1)height=1;
    scale=1;
    while(scale<4&&width/(scale+1)>=320&&height/(scale+1)>=240)++scale;
    gui->scaleFactor=scale;
    gui->scaledWidth=(width+scale-1)/scale;
    gui->scaledHeight=(height+scale-1)/scale;
}

void CloneMCJ_GuiIngame_UpdateResolutionWithScale(CloneMCJ_GuiIngameState *gui,
    int width,int height,int requestedScale)
{
    if(!gui)return;
    if(requestedScale<=0){CloneMCJ_GuiIngame_UpdateResolution(gui,width,height);return;}
    if(width<1)width=1;
    if(height<1)height=1;
    if(requestedScale>4)requestedScale=4;
    gui->scaleFactor=requestedScale;
    gui->scaledWidth=(width+requestedScale-1)/requestedScale;
    gui->scaledHeight=(height+requestedScale-1)/requestedScale;
}

void CloneMCJ_GuiIngame_UpdateTick(CloneMCJ_GuiIngameState *gui)
{
    int i;
    if(!gui)return;
    ++gui->updateCounter;
    if(gui->recordPlayingUpFor>0)--gui->recordPlayingUpFor;
    if(gui->selectedItemUpFor>0)--gui->selectedItemUpFor;
    for(i=0;i<gui->chatCount;++i)if(gui->chatAge[i]<65535U)++gui->chatAge[i];
}

void CloneMCJ_GuiIngame_AddChatMessage(CloneMCJ_GuiIngameState *gui,const char *message)
{
    int i;
    if(!gui||!message)return;
    for(i=CLONEMC_GUI_CHAT_LINES-1;i>0;--i){
        strcpy(gui->chat[i],gui->chat[i-1]);gui->chatAge[i]=gui->chatAge[i-1];
    }
    strncpy(gui->chat[0],message,sizeof(gui->chat[0])-1);
    gui->chat[0][sizeof(gui->chat[0])-1]='\0';gui->chatAge[0]=0;
    if(gui->chatCount<CLONEMC_GUI_CHAT_LINES)++gui->chatCount;
}

void CloneMCJ_GuiIngame_UpdateSelectedItem(CloneMCJ_GuiIngameState *gui,
    int selectedSlot,int itemId,int damage,const char *displayName)
{
    if(!gui)return;
    if(selectedSlot!=gui->lastSelectedSlot||itemId!=gui->lastSelectedItemId||
       damage!=gui->lastSelectedDamage){
        gui->lastSelectedSlot=selectedSlot;
        gui->lastSelectedItemId=itemId;
        gui->lastSelectedDamage=damage;
        if(!displayName)displayName="";
        strncpy(gui->selectedItemName,displayName,
            sizeof(gui->selectedItemName)-1);
        gui->selectedItemName[sizeof(gui->selectedItemName)-1]='\0';
        gui->selectedItemUpFor=*displayName?40:0;
    }
}

void CloneMCJ_GuiIngame_SetRecordPlaying(CloneMCJ_GuiIngameState *gui,const char *message)
{
    if(!gui)return;
    if(!message)message="";
    strncpy(gui->recordPlaying,message,sizeof(gui->recordPlaying)-1);
    gui->recordPlaying[sizeof(gui->recordPlaying)-1]='\0';
    gui->recordPlayingUpFor=60;
}

void CloneMCJ_GuiIngame_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiIngame_JavaName(void)
{
    return "net.minecraft.src.GuiIngame";
}

const char *CloneMCJ_GuiIngame_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiIngame_JavaSourceHash32(void)
{
    return 0x0D72071AUL;
}
