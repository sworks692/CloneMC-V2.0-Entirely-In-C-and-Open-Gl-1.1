/*
 * CloneMC Java port scaffold: StatFileWriter
 *
 * Java source: StatFileWriter.java
 * Java type: class StatFileWriter
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 0e39cc32aeb1d68fb062710932da3894f64a9330074ca97d2a74f5a5fadb7046
 * Java lines: 242
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: StatsSyncher, StatBase, J_InvalidSyntaxException, J_JdomParser, J_JsonRootNode, J_JsonNode, J_JsonStringNode, StatList, MD5String, Achievement, Session, this, statbase
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Map field_25102_a
 * - private Map field_25101_b
 * - private boolean field_27189_c
 * - private StatsSyncher statsSyncher
 *
 * Java method/constructor inventory:
 * - public StatFileWriter(Session session, File file)
 * - public void readStat(StatBase statbase, int i)
 * - private void writeStatToMap(Map map, StatBase statbase, int i)
 * - public Map func_27176_a()
 * - public void func_27179_a(Map map)
 * - public void func_27180_b(Map map)
 * - public void func_27187_c(Map map)
 * - public static Map func_27177_a(String s)
 * - public static String func_27185_a(String s, String s1, Map map)
 * - public boolean hasAchievementUnlocked(Achievement achievement)
 * - public boolean func_27181_b(Achievement achievement)
 * - public int writeStat(StatBase statbase)
 * - public void func_27175_b()
 * - public void syncStats()
 * - public void func_27178_d()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"
#include "../00_core/clonemc_java_port_00_core.h"
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int CloneMCJ_StatFileWriter_Find(const CloneMCJ_StatFileState *state,int statId)
{int i;if(!state)return -1;for(i=0;i<state->count;++i)if(state->entries[i].statId==statId)return i;return -1;}

void CloneMCJ_StatFileWriter_InitializeNative(CloneMCJ_StatFileState *state)
{if(state)memset(state,0,sizeof(*state));}

int CloneMCJ_StatFileWriter_SetNative(CloneMCJ_StatFileState *state,int statId,int value)
{int i;if(!state)return 0;i=CloneMCJ_StatFileWriter_Find(state,statId);if(i<0){if(state->count>=CLONEMC_STAT_CAPACITY)return 0;i=state->count++;memset(&state->entries[i],0,sizeof(state->entries[i]));state->entries[i].statId=statId;}state->entries[i].value=value;state->dirty=1;return 1;}

int CloneMCJ_StatFileWriter_AddNative(CloneMCJ_StatFileState *state,int statId,int amount)
{int i,value;i=CloneMCJ_StatFileWriter_Find(state,statId);value=i>=0?state->entries[i].value:0;return CloneMCJ_StatFileWriter_SetNative(state,statId,(int)((unsigned int)value+(unsigned int)amount));}

int CloneMCJ_StatFileWriter_GetNative(const CloneMCJ_StatFileState *state,int statId)
{int i;i=CloneMCJ_StatFileWriter_Find(state,statId);return i>=0?state->entries[i].value:0;}

static const char *CloneMCJ_StatFileWriter_SkipSpace(const char *p)
{while(p&&*p&&isspace((unsigned char)*p))++p;return p;}

static int CloneMCJ_StatFileWriter_Hex(int c)
{if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}

static int CloneMCJ_StatFileWriter_String(const char **cursor,char *out,unsigned long capacity)
{
    const char *p;unsigned long n;int c,h0,h1,h2,h3;
    if(!cursor||!out||capacity==0)return 0;
    p=CloneMCJ_StatFileWriter_SkipSpace(*cursor);if(*p!='\"')return 0;++p;n=0;
    while(*p&&*p!='\"'){c=(unsigned char)*p++;if(c=='\\'){c=(unsigned char)*p++;switch(c){case '\"':case '\\':case '/':break;case 'b':c='\b';break;case 'f':c='\f';break;case 'n':c='\n';break;case 'r':c='\r';break;case 't':c='\t';break;case 'u':h0=CloneMCJ_StatFileWriter_Hex(p[0]);h1=CloneMCJ_StatFileWriter_Hex(p[1]);h2=CloneMCJ_StatFileWriter_Hex(p[2]);h3=CloneMCJ_StatFileWriter_Hex(p[3]);if(h0<0||h1<0||h2<0||h3<0)return 0;c=(h0<<12)|(h1<<8)|(h2<<4)|h3;p+=4;if(c>127)c='?';break;default:return 0;}}if(n+1>=capacity)return 0;out[n++]=(char)c;}
    if(*p!='\"')return 0;
    out[n]='\0';*cursor=p+1;return 1;
}

int CloneMCJ_StatFileWriter_ParseJsonNative(CloneMCJ_StatFileState *state,const char *json)
{
    const char *p,*end;char key[48];char *numberEnd;long id,value;int parsed;
    if(!state||!json)return 0;
    p=strstr(json,"\"stats-change\"");if(!p){++state->jsonErrors;return 0;}p=strchr(p,':');if(!p){++state->jsonErrors;return 0;}p=CloneMCJ_StatFileWriter_SkipSpace(p+1);if(*p!='['){++state->jsonErrors;return 0;}++p;parsed=0;
    while(1){p=CloneMCJ_StatFileWriter_SkipSpace(p);if(*p==']'){++p;break;}if(*p!='{'){++state->jsonErrors;return 0;}++p;if(!CloneMCJ_StatFileWriter_String(&p,key,sizeof(key))){++state->jsonErrors;return 0;}p=CloneMCJ_StatFileWriter_SkipSpace(p);if(*p!=':'){++state->jsonErrors;return 0;}errno=0;id=strtol(key,&numberEnd,10);if(!*key||*numberEnd||errno==ERANGE){++state->jsonErrors;return 0;}p=CloneMCJ_StatFileWriter_SkipSpace(p+1);errno=0;value=strtol(p,&numberEnd,10);if(numberEnd==p||errno==ERANGE){++state->jsonErrors;return 0;}p=CloneMCJ_StatFileWriter_SkipSpace(numberEnd);if(*p!='}'){++state->jsonErrors;return 0;}if(!CloneMCJ_StatFileWriter_SetNative(state,(int)id,(int)value)){++state->jsonErrors;return 0;}++parsed;p=CloneMCJ_StatFileWriter_SkipSpace(p+1);if(*p==','){++p;continue;}if(*p==']'){++p;break;}++state->jsonErrors;return 0;}
    end=strstr(p,"\"checksum\"");if(end){end=strchr(end,':');if(end){++end;if(!CloneMCJ_StatFileWriter_String(&end,state->checksum,sizeof(state->checksum))){++state->jsonErrors;return 0;}}}state->dirty=0;return parsed;
}

int CloneMCJ_StatFileWriter_LoadGuidsNative(CloneMCJ_StatFileState *state,const char *path)
{
    FILE *file;char line[128],*comma,*end;long id;int index,loaded;if(!state||!path)return 0;file=fopen(path,"rt");if(!file)return 0;loaded=0;while(fgets(line,sizeof(line),file)){comma=strchr(line,',');if(!comma)continue;*comma='\0';id=strtol(line,&end,10);if(*end)continue;index=CloneMCJ_StatFileWriter_Find(state,(int)id);if(index<0)continue;++comma;end=strpbrk(comma,"\r\n");if(end)*end='\0';if(strlen(comma)>32)continue;strcpy(state->entries[index].guid,comma);++loaded;}fclose(file);return loaded;
}

static int CloneMCJ_StatFileWriter_Append(char *out,unsigned long capacity,unsigned long *used,const char *text)
{unsigned long length;if(!out||!used||!text)return 0;length=(unsigned long)strlen(text);if(*used+length>=capacity)return 0;memcpy(out+*used,text,length);*used+=length;out[*used]='\0';return 1;}

typedef struct CloneMCJ_MD5ContextTag {CloneMCJUInt state[4];CloneMCJUInt byteCount;unsigned char block[64];unsigned int blockLength;} CloneMCJ_MD5Context;

static CloneMCJUInt CloneMCJ_MD5_Rotate(CloneMCJUInt value,int amount)
{return (CloneMCJUInt)((value<<amount)|(value>>(32-amount)));}

static void CloneMCJ_MD5_Transform(CloneMCJ_MD5Context *context,const unsigned char *block)
{
    static const CloneMCJUInt constants[64]={0xd76aa478UL,0xe8c7b756UL,0x242070dbUL,0xc1bdceeeUL,0xf57c0fafUL,0x4787c62aUL,0xa8304613UL,0xfd469501UL,0x698098d8UL,0x8b44f7afUL,0xffff5bb1UL,0x895cd7beUL,0x6b901122UL,0xfd987193UL,0xa679438eUL,0x49b40821UL,0xf61e2562UL,0xc040b340UL,0x265e5a51UL,0xe9b6c7aaUL,0xd62f105dUL,0x02441453UL,0xd8a1e681UL,0xe7d3fbc8UL,0x21e1cde6UL,0xc33707d6UL,0xf4d50d87UL,0x455a14edUL,0xa9e3e905UL,0xfcefa3f8UL,0x676f02d9UL,0x8d2a4c8aUL,0xfffa3942UL,0x8771f681UL,0x6d9d6122UL,0xfde5380cUL,0xa4beea44UL,0x4bdecfa9UL,0xf6bb4b60UL,0xbebfbc70UL,0x289b7ec6UL,0xeaa127faUL,0xd4ef3085UL,0x04881d05UL,0xd9d4d039UL,0xe6db99e5UL,0x1fa27cf8UL,0xc4ac5665UL,0xf4292244UL,0x432aff97UL,0xab9423a7UL,0xfc93a039UL,0x655b59c3UL,0x8f0ccc92UL,0xffeff47dUL,0x85845dd1UL,0x6fa87e4fUL,0xfe2ce6e0UL,0xa3014314UL,0x4e0811a1UL,0xf7537e82UL,0xbd3af235UL,0x2ad7d2bbUL,0xeb86d391UL};
    static const unsigned char shifts[64]={7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21};
    CloneMCJUInt words[16],a,b,c,d,f,temp;int i,g;for(i=0;i<16;++i)words[i]=(CloneMCJUInt)block[i*4]|((CloneMCJUInt)block[i*4+1]<<8)|((CloneMCJUInt)block[i*4+2]<<16)|((CloneMCJUInt)block[i*4+3]<<24);a=context->state[0];b=context->state[1];c=context->state[2];d=context->state[3];for(i=0;i<64;++i){if(i<16){f=(b&c)|((~b)&d);g=i;}else if(i<32){f=(d&b)|((~d)&c);g=(5*i+1)&15;}else if(i<48){f=b^c^d;g=(3*i+5)&15;}else{f=c^(b|(~d));g=(7*i)&15;}temp=d;d=c;c=b;b=(CloneMCJUInt)(b+CloneMCJ_MD5_Rotate((CloneMCJUInt)(a+f+constants[i]+words[g]),shifts[i]));a=temp;}context->state[0]=(CloneMCJUInt)(context->state[0]+a);context->state[1]=(CloneMCJUInt)(context->state[1]+b);context->state[2]=(CloneMCJUInt)(context->state[2]+c);context->state[3]=(CloneMCJUInt)(context->state[3]+d);
}

static void CloneMCJ_MD5_Initialize(CloneMCJ_MD5Context *context)
{memset(context,0,sizeof(*context));context->state[0]=0x67452301UL;context->state[1]=0xefcdab89UL;context->state[2]=0x98badcfeUL;context->state[3]=0x10325476UL;}

static void CloneMCJ_MD5_Update(CloneMCJ_MD5Context *context,const unsigned char *data,unsigned long length)
{unsigned long i;for(i=0;i<length;++i){context->block[context->blockLength++]=data[i];++context->byteCount;if(context->blockLength==64U){CloneMCJ_MD5_Transform(context,context->block);context->blockLength=0;}}}

static void CloneMCJ_MD5_Final(CloneMCJ_MD5Context *context,unsigned char digest[16])
{CloneMCJUInt lowBits,highBits;int i;lowBits=(CloneMCJUInt)(context->byteCount<<3);highBits=(CloneMCJUInt)(context->byteCount>>29);context->block[context->blockLength++]=0x80;while(context->blockLength!=56U){if(context->blockLength==64U){CloneMCJ_MD5_Transform(context,context->block);context->blockLength=0;}context->block[context->blockLength++]=0;}for(i=0;i<4;++i)context->block[context->blockLength++]=(unsigned char)(lowBits>>(i*8));for(i=0;i<4;++i)context->block[context->blockLength++]=(unsigned char)(highBits>>(i*8));CloneMCJ_MD5_Transform(context,context->block);for(i=0;i<4;++i){digest[i*4]=(unsigned char)context->state[i];digest[i*4+1]=(unsigned char)(context->state[i]>>8);digest[i*4+2]=(unsigned char)(context->state[i]>>16);digest[i*4+3]=(unsigned char)(context->state[i]>>24);}}

int CloneMCJ_StatFileWriter_ComputeChecksumNative(const CloneMCJ_StatFileState *state,const char *session,char *out,unsigned long capacity)
{
    CloneMCJ_MD5Context context;unsigned char digest[16];char value[48],hex[33];int i,first;if(!state||!session||!out||capacity<2)return 0;CloneMCJ_MD5_Initialize(&context);CloneMCJ_MD5_Update(&context,(const unsigned char*)session,(unsigned long)strlen(session));for(i=0;i<state->count;++i){if(!state->entries[i].guid[0])return 0;CloneMCJ_MD5_Update(&context,(const unsigned char*)state->entries[i].guid,(unsigned long)strlen(state->entries[i].guid));CloneMCJ_MD5_Update(&context,(const unsigned char*)",",1);sprintf(value,"%d,",state->entries[i].value);CloneMCJ_MD5_Update(&context,(const unsigned char*)value,(unsigned long)strlen(value));}CloneMCJ_MD5_Final(&context,digest);for(i=0;i<16;++i)sprintf(hex+i*2,"%02x",(unsigned int)digest[i]);hex[32]='\0';first=0;while(first<31&&hex[first]=='0')++first;if(strlen(hex+first)+1>capacity)return 0;strcpy(out,hex+first);return 1;
}

int CloneMCJ_StatFileWriter_ValidateChecksumNative(const CloneMCJ_StatFileState *state,const char *session)
{char checksum[33];if(!state||!state->checksum[0])return 0;return CloneMCJ_StatFileWriter_ComputeChecksumNative(state,session,checksum,sizeof(checksum))&&strcmp(checksum,state->checksum)==0;}

static int CloneMCJ_StatFileWriter_AppendQuoted(char *out,unsigned long capacity,unsigned long *used,const char *text)
{
    unsigned char c;char encoded[8];if(!CloneMCJ_StatFileWriter_Append(out,capacity,used,"\""))return 0;if(!text)text="";while(*text){c=(unsigned char)*text++;encoded[0]='\0';switch(c){case '\"':strcpy(encoded,"\\\"");break;case '\\':strcpy(encoded,"\\\\");break;case '\b':strcpy(encoded,"\\b");break;case '\f':strcpy(encoded,"\\f");break;case '\n':strcpy(encoded,"\\n");break;case '\r':strcpy(encoded,"\\r");break;case '\t':strcpy(encoded,"\\t");break;default:if(c<32)sprintf(encoded,"\\u%04x",(unsigned int)c);else{encoded[0]=(char)c;encoded[1]='\0';}break;}if(!CloneMCJ_StatFileWriter_Append(out,capacity,used,encoded))return 0;}return CloneMCJ_StatFileWriter_Append(out,capacity,used,"\"");
}

int CloneMCJ_StatFileWriter_WriteJsonNative(const CloneMCJ_StatFileState *state,const char *user,const char *session,const char *checksum,char *out,unsigned long capacity)
{
    int i;unsigned long used;char line[128],computed[33];const char*selected;if(!state||!out||capacity==0)return 0;selected=checksum;if(!selected&&session&&CloneMCJ_StatFileWriter_ComputeChecksumNative(state,session,computed,sizeof(computed)))selected=computed;if(!selected)selected=state->checksum;used=0;out[0]='\0';if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,"{\r\n"))return 0;if(user&&session){if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,"  \"user\":{\r\n    \"name\":"))return 0;if(!CloneMCJ_StatFileWriter_AppendQuoted(out,capacity,&used,user))return 0;if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,",\r\n    \"sessionid\":"))return 0;if(!CloneMCJ_StatFileWriter_AppendQuoted(out,capacity,&used,session))return 0;if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,"\r\n  },\r\n"))return 0;}if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,"  \"stats-change\":["))return 0;for(i=0;i<state->count;++i){sprintf(line,"%s\r\n    {\"%d\":%d}",i?",":"",state->entries[i].statId,state->entries[i].value);if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,line))return 0;}if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,"\r\n  ],\r\n  \"checksum\":"))return 0;if(!CloneMCJ_StatFileWriter_AppendQuoted(out,capacity,&used,selected))return 0;if(!CloneMCJ_StatFileWriter_Append(out,capacity,&used,"\r\n}"))return 0;return (int)used;}

int CloneMCJ_StatFileWriter_LoadJsonFileNative(CloneMCJ_StatFileState *state,const char *path,const char *guidPath,const char *session)
{
    FILE*file;char*json;long length;int parsed;if(!state||!path||!guidPath||!session)return 0;file=fopen(path,"rb");if(!file)return 0;if(fseek(file,0,SEEK_END)!=0){fclose(file);return 0;}length=ftell(file);if(length<0||length>1048576L||fseek(file,0,SEEK_SET)!=0){fclose(file);return 0;}json=(char*)malloc((unsigned long)length+1UL);if(!json){fclose(file);return 0;}if(length>0&&fread(json,1,(unsigned long)length,file)!=(unsigned long)length){free(json);fclose(file);return 0;}fclose(file);json[length]='\0';CloneMCJ_StatFileWriter_InitializeNative(state);parsed=CloneMCJ_StatFileWriter_ParseJsonNative(state,json);free(json);if(parsed<0)return 0;CloneMCJ_StatFileWriter_LoadGuidsNative(state,guidPath);if(state->checksum[0]&&!CloneMCJ_StatFileWriter_ValidateChecksumNative(state,session)){CloneMCJ_StatFileWriter_InitializeNative(state);state->jsonErrors=1;return -1;}state->dirty=0;return parsed;
}

int CloneMCJ_StatFileWriter_SaveJsonFileNative(CloneMCJ_StatFileState *state,const char *path,const char *guidPath,const char *user,const char *session)
{
    FILE*file;char*json;char temporary[512],backup[512];unsigned long capacity;int length,hadOld;if(!state||!path||!guidPath||!session||strlen(path)+5>=sizeof(temporary))return 0;CloneMCJ_StatFileWriter_LoadGuidsNative(state,guidPath);capacity=(unsigned long)state->count*96UL+1024UL;json=(char*)malloc(capacity);if(!json)return 0;length=CloneMCJ_StatFileWriter_WriteJsonNative(state,user,session,0,json,capacity);if(length<=0){free(json);return 0;}strcpy(temporary,path);strcat(temporary,".tmp");strcpy(backup,path);strcat(backup,".bak");file=fopen(temporary,"wb");if(!file){free(json);return 0;}if(fwrite(json,1,(unsigned long)length,file)!=(unsigned long)length||fflush(file)!=0){fclose(file);remove(temporary);free(json);return 0;}if(fclose(file)!=0){remove(temporary);free(json);return 0;}free(json);file=fopen(path,"rb");hadOld=file?1:0;if(file)fclose(file);remove(backup);if(hadOld&&rename(path,backup)!=0){remove(temporary);return 0;}if(rename(temporary,path)!=0){if(hadOld)rename(backup,path);remove(temporary);return 0;}if(hadOld)remove(backup);state->dirty=0;return 1;
}

void CloneMCJ_StatFileWriter_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_StatFileWriter_JavaName(void)
{
    return "net.minecraft.src.StatFileWriter";
}

const char *CloneMCJ_StatFileWriter_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_StatFileWriter_JavaSourceHash32(void)
{
    return 0x0E39CC32UL;
}
