/*
 * CloneMC Java port scaffold: GuiSlider
 *
 * Java source: GuiSlider.java
 * Java type: class GuiSlider
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiButton
 * Implements: (none declared)
 * Source SHA-256: ca396b469373ccb1209fe972a10620a583fd3c8fdcd89926fb6872332f886a82
 * Java lines: 88
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: GuiButton, GameSettings, EnumOptions, j, k, yPosition, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public float sliderValue
 * - public boolean dragging
 * - private EnumOptions idFloat
 *
 * Java method/constructor inventory:
 * - public GuiSlider(int i, int j, int k, EnumOptions enumoptions, String s, float f)
 * - protected int getHoverState(boolean flag)
 * - protected void mouseDragged(Minecraft minecraft, int i, int j)
 * - public boolean mousePressed(Minecraft minecraft, int i, int j)
 * - public void mouseReleased(int i, int j)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>

void CloneMCJ_GuiSlider_SetNative(CloneMCJ_GuiButtonNative *button,float *value,float normalized)
{
    if(!button||!value)return;
    if(normalized<0.0F)normalized=0.0F;
    if(normalized>1.0F)normalized=1.0F;
    *value=normalized;
    sprintf(button->displayString,"%d%%",(int)(normalized*100.0F+0.5F));
}

void CloneMCJ_GuiSlider_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiSlider_JavaName(void)
{
    return "net.minecraft.src.GuiSlider";
}

const char *CloneMCJ_GuiSlider_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiSlider_JavaSourceHash32(void)
{
    return 0xCA396B46UL;
}
