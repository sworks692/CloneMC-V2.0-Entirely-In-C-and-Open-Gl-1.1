/*
 * CloneMC Java port scaffold: SoundManager
 *
 * Java source: SoundManager.java
 * Java type: class SoundManager
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 432dcac836fdcb87bbde5d0ffcf00f628888268efaf732606adc6ea34a439da1
 * Java lines: 253
 * Discovered declared fields: 9
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: SoundPool, GameSettings, CodecMus, SoundPoolEntry, EntityLiving, MathHelper, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static SoundSystem sndSystem
 * - private SoundPool soundPoolSounds
 * - private SoundPool soundPoolStreaming
 * - private SoundPool soundPoolMusic
 * - private int field_587_e
 * - private GameSettings options
 * - private static boolean loaded = false
 * - private Random rand
 * - private int ticksBeforeMusic
 *
 * Java method/constructor inventory:
 * - public SoundManager()
 * - public void loadSoundSettings(GameSettings gamesettings)
 * - private void tryToSetLibraryAndCodecs()
 * - public void onSoundOptionsChanged()
 * - public void closeMinecraft()
 * - public void addSound(String s, File file)
 * - public void addStreaming(String s, File file)
 * - public void addMusic(String s, File file)
 * - public void playRandomMusicIfReady()
 * - public void func_338_a(EntityLiving entityliving, float f)
 * - public void playStreaming(String s, float f, float f1, float f2, float f3, float f4)
 * - public void playSound(String s, float f, float f1, float f2, float f3, float f4)
 * - public void playSoundFX(String s, float f, float f1)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../30_item/clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../NETWORK/clonemc_java_port_network.h"
#include <windows.h>
#include <mmsystem.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static float CloneMCJ_SoundManager_Clamp(float value,float minimum,float maximum)
{
    if(value<minimum)return minimum;
    if(value>maximum)return maximum;
    return value;
}

static void CloneMCJ_SoundManager_EffectAlias(int channel,char *alias)
{
    sprintf(alias,"clonemceffect%d",channel);
}

/* Win95/98 ships with a dependable PCM wave path but cannot be assumed to
 * have an MP3 MCI codec.  More importantly, old third-party MCI drivers run
 * inside the caller and some fault instead of returning an MCI error.  The
 * legacy backend therefore sends only known PCM files through PlaySound and
 * never enters an installed MCI codec. */
static const char *CloneMCJ_SoundManager_LegacyWavePath(const char *logicalName,
    const char *path)
{
    unsigned long length;
    if(logicalName&&strcmp(logicalName,"random.click")==0)
        return "assets/sounds/ui_click.wav";
    if(!path)return 0;
    length=(unsigned long)strlen(path);
    if(length>=4UL&&path[length-4]=='.'&&
       (path[length-3]=='w'||path[length-3]=='W')&&
       (path[length-2]=='a'||path[length-2]=='A')&&
       (path[length-1]=='v'||path[length-1]=='V'))return path;
    return 0;
}

static int CloneMCJ_SoundManager_PlayLegacyWave(CloneMCJ_SoundManagerState *manager,
    const char *logicalName,const char *path)
{
    const char *wavePath;
    if(!manager||!manager->soundAvailable)return 0;
    wavePath=CloneMCJ_SoundManager_LegacyWavePath(logicalName,path);
    /* MP3/other compressed effects are intentionally silent in this backend;
     * passing them to MCI would reintroduce the phase-10 crash. */
    if(!wavePath){++manager->soundsCulled;return 0;}
    if(!PlaySoundA(wavePath,(HMODULE)0,
        SND_ASYNC|SND_FILENAME|SND_NODEFAULT)){
        ++manager->soundFailures;
        /* A missing/broken wave driver must not be retried on every game event. */
        if(manager->soundFailures>=3UL)manager->soundAvailable=0;
        return 0;
    }
    ++manager->soundsPlayed;
    return 1;
}

static int CloneMCJ_SoundManager_OpenMusic(CloneMCJ_SoundManagerState *manager,const char *path)
{
    char command[320];
    MCIERROR result;
    if(!manager||!path||manager->musicVolume<=0.0F||!manager->soundAvailable)return 0;
    if(manager->legacySafeMode)return 0;
    mciSendStringA("close clonemcmusic",0,0,0);
    sprintf(command,"open \"%s\" alias clonemcmusic",path);
    result=mciSendStringA(command,0,0,0);
    if(result){++manager->soundFailures;manager->musicOpen=0;return 0;}
    sprintf(command,"setaudio clonemcmusic volume to %d",(int)(manager->musicVolume*1000.0F));
    result=mciSendStringA(command,0,0,0);
    if(result)++manager->soundFailures;
    result=mciSendStringA("play clonemcmusic from 0",0,0,0);
    if(result){mciSendStringA("close clonemcmusic",0,0,0);++manager->soundFailures;return 0;}
    manager->musicOpen=1;
    return 1;
}

static int CloneMCJ_SoundManager_PriorityForName(const char *name)
{
    if(!name)return 64;
    if(strncmp(name,"records.",8)==0)return 255;
    if(strstr(name,"explode")||strstr(name,"hurt")||strstr(name,"death")||
       strstr(name,"bow")||strstr(name,"fizz"))return 220;
    if(strncmp(name,"random.chest",12)==0||strstr(name,"door_")||
       strstr(name,"piston")||strstr(name,"click"))return 180;
    if(strncmp(name,"dig.",4)==0||strncmp(name,"mob.",4)==0)return 140;
    if(strncmp(name,"step.",5)==0||strstr(name,"splash")||
       strstr(name,"swim"))return 80;
    if(strncmp(name,"ambient.",8)==0||strncmp(name,"fire.",5)==0)return 40;
    return 100;
}

static int CloneMCJ_SoundManager_SelectChannel(CloneMCJ_SoundManagerState *manager,
    const char *name,float audible,int priority)
{
    int index,freeChannel,best,bestPriority;
    float bestAudible;
    unsigned long bestAge,age;
    if(!manager)return -1;
    freeChannel=-1;best=-1;bestPriority=1000;bestAudible=2.0F;bestAge=0UL;
    for(index=0;index<CLONEMC_SOUND_EFFECT_CHANNELS;++index){
        if(!manager->effectChannels[index]){
            if(freeChannel<0)freeChannel=index;
            continue;
        }
        age=manager->tickCount-manager->effectStartedTick[index];
        if(name&&manager->effectNames[index][0]&&
           strcmp(name,manager->effectNames[index])==0&&age<=2UL&&
           manager->effectAudible[index]>=audible*0.75F){
            ++manager->soundsDuplicateSuppressed;return -2;
        }
        if((int)manager->effectPriority[index]<bestPriority||
           ((int)manager->effectPriority[index]==bestPriority&&
            (manager->effectAudible[index]<bestAudible||
             (manager->effectAudible[index]==bestAudible&&age>bestAge)))){
            best=index;bestPriority=(int)manager->effectPriority[index];
            bestAudible=manager->effectAudible[index];bestAge=age;
        }
    }
    if(freeChannel>=0)return freeChannel;
    if(best<0)return -1;
    if(priority<bestPriority||(priority==bestPriority&&audible<=bestAudible*1.10F)){
        ++manager->soundsPriorityRejected;return -2;
    }
    return best;
}

static int CloneMCJ_SoundManager_OpenEffect(CloneMCJ_SoundManagerState *manager,
    const char *logicalName,const char *path,float volume,float pitch,float pan,int priority)
{
    char command[320],alias[32];
    MCIERROR result;
    int channel,speed,wholeVolume,leftVolume,rightVolume;
    if(!manager||!path||!*path||!manager->soundAvailable)return -1;
    if(manager->legacySafeMode)
        return CloneMCJ_SoundManager_PlayLegacyWave(manager,logicalName,path)?0:-1;
    volume=CloneMCJ_SoundManager_Clamp(volume,0.0F,1.0F);
    pan=CloneMCJ_SoundManager_Clamp(pan,-1.0F,1.0F);
    channel=CloneMCJ_SoundManager_SelectChannel(manager,logicalName,volume,priority);
    if(channel<0)return channel;
    CloneMCJ_SoundManager_EffectAlias(channel,alias);
    sprintf(command,"close %s",alias);mciSendStringA(command,0,0,0);
    if(manager->effectChannels[channel]&&manager->effectOpen>0)--manager->effectOpen;
    manager->effectChannels[channel]=0;
    manager->effectPriority[channel]=0;
    manager->effectAudible[channel]=0.0F;
    manager->effectNames[channel][0]='\0';
    sprintf(command,"open \"%s\" alias %s",path,alias);
    result=mciSendStringA(command,0,0,0);
    if(result){++manager->soundFailures;return -1;}
    wholeVolume=(int)(volume*1000.0F);
    leftVolume=(int)((float)wholeVolume*(pan>0.0F?1.0F-pan:1.0F));
    rightVolume=(int)((float)wholeVolume*(pan<0.0F?1.0F+pan:1.0F));
    sprintf(command,"setaudio %s volume to %d",alias,wholeVolume);
    mciSendStringA(command,0,0,0);
    /* These channel-specific controls are optional on old MCI drivers.  The
     * overall volume remains valid when a codec does not expose them. */
    sprintf(command,"setaudio %s left volume to %d",alias,leftVolume);
    mciSendStringA(command,0,0,0);
    sprintf(command,"setaudio %s right volume to %d",alias,rightVolume);
    mciSendStringA(command,0,0,0);
    speed=(int)(CloneMCJ_SoundManager_Clamp(pitch,0.5F,2.0F)*1000.0F);
    sprintf(command,"set %s speed %d",alias,speed);
    mciSendStringA(command,0,0,0); /* optional on older MCI codecs */
    sprintf(command,"play %s from 0",alias);result=mciSendStringA(command,0,0,0);
    if(result){sprintf(command,"close %s",alias);mciSendStringA(command,0,0,0);
        ++manager->soundFailures;return -1;}
    manager->effectChannels[channel]=1;
    manager->effectPriority[channel]=(unsigned char)(priority<0?0:(priority>255?255:priority));
    manager->effectStartedTick[channel]=manager->tickCount;
    manager->effectAudible[channel]=volume;
    if(logicalName){strncpy(manager->effectNames[channel],logicalName,
        sizeof(manager->effectNames[channel])-1U);
        manager->effectNames[channel][sizeof(manager->effectNames[channel])-1U]='\0';}
    ++manager->effectOpen;++manager->soundsPlayed;
    manager->effectNext=(channel+1)%CLONEMC_SOUND_EFFECT_CHANNELS;
    return channel;
}

static void CloneMCJ_SoundManager_AddNumbered(CloneMCJ_SoundManagerState *manager,
    const char *name,const char *prefix,int first,int last,const char *suffix,int streaming)
{
    int number;char path[160];
    for(number=first;number<=last;++number){
        sprintf(path,"%s%d%s",prefix,number,suffix);
        CloneMCJ_SoundPool_AddNative(manager,name,path,streaming);
    }
}

static void CloneMCJ_SoundManager_AddAssets(CloneMCJ_SoundManagerState *manager)
{
    static const char *music[]={
        "calm1","calm2","calm3","flake","game_aria_math","game_haggstrom",
        "game_track3","game_track4","game_track5","game_track6","game_track7",
        "game_track8","hal1","hal2","hal3","hal4","menu_oxygene","piano1"};
    int index;char path[160];
    CloneMCJ_SoundManager_AddNumbered(manager,"ambient.cave","assets/sounds/ambient/cave/cave",1,3,".wav",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"ambient.lava","assets/sounds/ambient/lava/lava",1,2,".wav",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"ambient.water","assets/sounds/ambient/water/water",1,2,".wav",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"step.cloth","assets/sounds/player/step_cloth",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"step.grass","assets/sounds/player/step_grass",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"step.gravel","assets/sounds/player/step_gravel",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"step.sand","assets/sounds/player/step_sand",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"step.snow","assets/sounds/player/step_snow",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"step.stone","assets/sounds/player/step_stone",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"step.wood","assets/sounds/player/step_wood",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.cloth","assets/sounds/dig/dig_cloth",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.glass","assets/sounds/dig/dig_glass",1,3,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.grass","assets/sounds/dig/dig_grass",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.gravel","assets/sounds/dig/dig_gravel",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.sand","assets/sounds/dig/dig_sand",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.snow","assets/sounds/dig/dig_snow",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.stone","assets/sounds/dig/dig_stone",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"dig.wood","assets/sounds/dig/dig_wood",1,4,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.chicken","assets/sounds/mob/chicken/say",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.chickenhurt","assets/sounds/mob/chicken/hurt",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.chickenstep","assets/sounds/mob/chicken/step",1,2,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.cow","assets/sounds/mob/cow/say",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.cowhurt","assets/sounds/mob/cow/hurt",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.cowstep","assets/sounds/mob/cow/step",1,3,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.pig","assets/sounds/mob/pig/say",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.pigstep","assets/sounds/mob/pig/step",1,3,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.sheep","assets/sounds/mob/sheep/say",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.sheepstep","assets/sounds/mob/sheep/step",1,3,".mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.sheep.shear","assets/sounds/mob/sheep/shear.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.creeper","assets/sounds/mob/creeper/say1.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.creeperdeath","assets/sounds/mob/creeper/death.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.slime","assets/sounds/mob/slime/small1.mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.skeleton","assets/sounds/mob/skeleton/say",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.skeletonhurt","assets/sounds/mob/skeleton/hurt",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.skeletonstep","assets/sounds/mob/skeleton/step",1,3,".mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.spider","assets/sounds/mob/spider/say1.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.spiderdeath","assets/sounds/mob/spider/death.mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.spiderstep","assets/sounds/mob/spider/step",1,3,".mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.wolf","assets/sounds/mob/wolf/bark1.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.wolfgrowl","assets/sounds/mob/wolf/growl1.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"mob.wolfhurt","assets/sounds/mob/wolf/hurt1.mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.wolfstep","assets/sounds/mob/wolf/step",1,3,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.zombie","assets/sounds/mob/zombie/say",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.zombiehurt","assets/sounds/mob/zombie/hurt",1,1,".mp3",0);
    CloneMCJ_SoundManager_AddNumbered(manager,"mob.zombiestep","assets/sounds/mob/zombie/step",1,3,".mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.bow","assets/sounds/random/bow.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.break","assets/sounds/random/break.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.chestopen","assets/sounds/random/chestopen.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.chestclosed","assets/sounds/random/chestclosed.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.door_open","assets/sounds/random/door_open.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.door_close","assets/sounds/random/door_close.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.eat","assets/sounds/random/eat.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.explode","assets/sounds/random/explode.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.fizz","assets/sounds/random/fizz.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.pop","assets/sounds/random/pop.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.hurt","assets/sounds/player_hit.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"random.click","assets/sounds/ui_click.mp3",0);
    CloneMCJ_SoundPool_AddNative(manager,"fire.fire","assets/sounds/fire/fire.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"records.13","assets/records/13.wav",0);
    CloneMCJ_SoundPool_AddNative(manager,"records.cat","assets/records/cat.wav",0);
    for(index=0;index<(int)(sizeof(music)/sizeof(music[0]));++index){
        sprintf(path,"assets/music/%s.wav",music[index]);
        CloneMCJ_SoundPool_AddNative(manager,"music",path,1);
    }
}

void CloneMCJ_SoundManager_InitializeNative(CloneMCJ_SoundManagerState *manager,
    const CloneMCGameSettings *settings)
{
    if(!manager)return;
    memset(manager,0,sizeof(*manager));
    manager->soundVolume=settings?settings->soundVolume:1.0F;
    manager->musicVolume=settings?settings->musicVolume:1.0F;
    CloneMCJavaRandom_SetSeed(&manager->random,(CloneMCJLong)(timeGetTime()^0x432dcac8UL));
    manager->ticksBeforeMusic=(int)CloneMCJavaRandom_NextIntBound(&manager->random,12000);
    manager->recordChannel=-1;
    manager->currentMusic=-1;
    CloneMCJ_SoundManager_AddAssets(manager);
    manager->initialized=1;manager->soundAvailable=1;
}

void CloneMCJ_SoundManager_SetLegacySafeMode(CloneMCJ_SoundManagerState *manager,
    int enabled)
{
    if(!manager)return;
    manager->legacySafeMode=enabled?1:0;
    if(enabled){
        /* This is normally called immediately after initialization.  Clearing
         * channel bookkeeping also makes a diagnostic runtime switch benign. */
        memset(manager->effectChannels,0,sizeof(manager->effectChannels));
        manager->effectOpen=0;manager->musicOpen=0;manager->recordChannel=-1;
        manager->soundAvailable=1;
    }
}

int CloneMCJ_SoundManager_PlaySound(CloneMCJ_SoundManagerState *manager,const char *name)
{
    const CloneMCJ_SoundPoolEntryNative *entry;
    if(manager&&manager->initialized&&name&&strcmp(name,"music")==0){
        if(manager->musicVolume<=0.0F)return 0;
        {
            unsigned long salt;int attempt,entryIndex;
            salt=(unsigned long)(CloneMCJUInt)CloneMCJavaRandom_NextInt(&manager->random);
            entry=0;entryIndex=-1;
            for(attempt=0;attempt<8;++attempt){
                entry=CloneMCJ_SoundPool_GetNative(manager,name,salt+(unsigned long)attempt);
                if(!entry)break;
                entryIndex=(int)(entry-manager->entries);
                if(entryIndex!=manager->currentMusic||attempt==7)break;
            }
            if(!entry)return 0;
            if(CloneMCJ_SoundManager_OpenMusic(manager,entry->path)){
                manager->currentMusic=entryIndex;return 1;
            }
            return 0;
        }
    }
    return CloneMCJ_SoundManager_PlaySoundFX(manager,name,1.0F,1.0F);
}

int CloneMCJ_SoundManager_PlaySoundFX(CloneMCJ_SoundManagerState *manager,
    const char *name,float volume,float pitch)
{
    const CloneMCJ_SoundPoolEntryNative *entry;
    if(!manager||!manager->initialized||!manager->soundAvailable||
       manager->soundVolume<=0.0F||!name)return 0;
    entry=CloneMCJ_SoundPool_GetNative(manager,name,
        (unsigned long)(CloneMCJUInt)CloneMCJavaRandom_NextInt(&manager->random));
    if(!entry)return 0;
    if(entry->streaming)return CloneMCJ_SoundManager_OpenMusic(manager,entry->path);
    volume=CloneMCJ_SoundManager_Clamp(volume,0.0F,1.0F)*0.25F*manager->soundVolume;
    /* GUI buttons are the one effect every frontend necessarily invokes.  Keep
     * that path PCM-only on every OS, even if an AppCompat shim does not expose
     * its legacy version, so no button can enter an MP3 MCI codec. */
    if(strcmp(name,"random.click")==0)
        return CloneMCJ_SoundManager_PlayLegacyWave(manager,name,entry->path);
    return CloneMCJ_SoundManager_OpenEffect(manager,name,entry->path,volume,pitch,0.0F,
        CloneMCJ_SoundManager_PriorityForName(name))>=0;
}

int CloneMCJ_SoundManager_PlaySoundAt(CloneMCJ_SoundManagerState *manager,
    const char *name,float x,float y,float z,float volume,float pitch)
{
    const CloneMCJ_SoundPoolEntryNative *entry;double dx,dy,dz,distance,radius;
    float audible,pan,yawRadians,rightX,rightZ;
    if(!manager||!manager->initialized||!manager->soundAvailable||
       manager->soundVolume<=0.0F||!name)return 0;
    radius=volume>1.0F?16.0*(double)volume:16.0;
    dx=(double)x-manager->listenerX;dy=(double)y-manager->listenerY;
    dz=(double)z-manager->listenerZ;distance=sqrt(dx*dx+dy*dy+dz*dz);
    if(distance>=radius){++manager->soundsCulled;return 0;}
    audible=(float)(1.0-distance/radius)*CloneMCJ_SoundManager_Clamp(volume,0.0F,1.0F)*
        manager->soundVolume;
    entry=CloneMCJ_SoundPool_GetNative(manager,name,
        (unsigned long)(CloneMCJUInt)CloneMCJavaRandom_NextInt(&manager->random));
    if(!entry)return 0;
    pan=0.0F;
    if(distance>0.001){
        yawRadians=manager->listenerYaw*0.017453292519943295F;
        rightX=(float)cos((double)yawRadians);rightZ=(float)sin((double)yawRadians);
        pan=(float)((dx*(double)rightX+dz*(double)rightZ)/distance);
    }
    return CloneMCJ_SoundManager_OpenEffect(manager,name,entry->path,audible,pitch,pan,
        CloneMCJ_SoundManager_PriorityForName(name))>=0;
}

int CloneMCJ_SoundManager_PlayStreaming(CloneMCJ_SoundManagerState *manager,
    const char *name,float x,float y,float z,float volume,float pitch)
{
    char logical[64],command[64],alias[32];int channel;
    if(!manager||!manager->initialized||!manager->soundAvailable)return 0;
    if(manager->legacySafeMode){
        const CloneMCJ_SoundPoolEntryNative *safeEntry;
        if(!name||!*name){PlaySoundA((LPCSTR)0,(HMODULE)0,0);return 1;}
        sprintf(logical,"records.%s",name);
        safeEntry=CloneMCJ_SoundPool_GetNative(manager,logical,
            (unsigned long)(CloneMCJUInt)CloneMCJavaRandom_NextInt(&manager->random));
        return safeEntry?CloneMCJ_SoundManager_PlayLegacyWave(manager,logical,
            safeEntry->path):0;
    }
    if(manager->recordChannel>=0){CloneMCJ_SoundManager_EffectAlias(manager->recordChannel,alias);
        sprintf(command,"close %s",alias);mciSendStringA(command,0,0,0);
        if(manager->effectChannels[manager->recordChannel]){manager->effectChannels[manager->recordChannel]=0;
            if(manager->effectOpen>0)--manager->effectOpen;}manager->recordChannel=-1;}
    if(!name||!*name)return 1;
    if(manager->musicOpen){mciSendStringA("close clonemcmusic",0,0,0);manager->musicOpen=0;}
    sprintf(logical,"records.%s",name);
    {
        const CloneMCJ_SoundPoolEntryNative *entry;
        double dx,dy,dz,distance,radius;float audible,pan,yawRadians,rightX,rightZ;
        entry=CloneMCJ_SoundPool_GetNative(manager,logical,
            (unsigned long)(CloneMCJUInt)CloneMCJavaRandom_NextInt(&manager->random));
        if(!entry)return 0;
        dx=(double)x-manager->listenerX;dy=(double)y-manager->listenerY;
        dz=(double)z-manager->listenerZ;distance=sqrt(dx*dx+dy*dy+dz*dz);
        radius=64.0;if(distance>=radius)return 0;
        audible=(float)(1.0-distance/radius)*CloneMCJ_SoundManager_Clamp(volume,0.0F,1.0F)*
            manager->soundVolume;pan=0.0F;
        if(distance>0.001){yawRadians=manager->listenerYaw*0.017453292519943295F;
            rightX=(float)cos((double)yawRadians);rightZ=(float)sin((double)yawRadians);
            pan=(float)((dx*(double)rightX+dz*(double)rightZ)/distance);}
        channel=CloneMCJ_SoundManager_OpenEffect(manager,logical,entry->path,audible,pitch,pan,255);
    }
    manager->recordChannel=channel;return channel>=0;
}

static const char *CloneMCJ_SoundManager_DigForBlock(int blockID)
{const CloneMCJ_BlockDefinition*b;if(blockID==20||blockID==79||blockID==89)return "dig.glass";if(blockID==13)return "dig.gravel";if(blockID==78||blockID==80)return "dig.snow";b=CloneMCJ_BlockRegistry_Get(blockID);if(!b)return "dig.stone";if(b->material==CLONEMC_J_MATERIAL_WOOD)return "dig.wood";if(b->material==CLONEMC_J_MATERIAL_SAND)return "dig.sand";if(b->material==CLONEMC_J_MATERIAL_CLOTH)return "dig.cloth";if(b->material==CLONEMC_J_MATERIAL_EARTH||b->material==CLONEMC_J_MATERIAL_PLANT)return "dig.grass";return "dig.stone";}

static float CloneMCJ_SoundManager_PitchForBlock(int blockID)
{
    switch(blockID){
    case 27: case 28: case 41: case 42:
    case 52: case 57: case 66: case 71:
        return 1.5F;
    default:
        return 1.0F;
    }
}

static const char *CloneMCJ_SoundManager_StepForBlock(int blockID)
{
    const CloneMCJ_BlockDefinition *block;
    if(blockID==13)return "step.gravel";
    if(blockID==78||blockID==80)return "step.snow";
    block=CloneMCJ_BlockRegistry_Get(blockID);
    if(!block)return "step.stone";
    if(block->material==CLONEMC_J_MATERIAL_WOOD)return "step.wood";
    if(block->material==CLONEMC_J_MATERIAL_SAND)return "step.sand";
    if(block->material==CLONEMC_J_MATERIAL_CLOTH)return "step.cloth";
    if(block->material==CLONEMC_J_MATERIAL_EARTH||
       block->material==CLONEMC_J_MATERIAL_PLANT)return "step.grass";
    return "step.stone";
}

void CloneMCJ_SoundManager_TickNative(CloneMCJ_SoundManagerState *manager,
    const CloneMCJ_EntityPlayer *player)
{
    double dx,dz;
    char status[32],command[64],alias[32];int index,blockID;
    if(!manager||!manager->initialized)return;
    ++manager->tickCount;
    if(manager->musicOpen&&manager->musicVolume<=0.0F){
        mciSendStringA("close clonemcmusic",0,0,0);manager->musicOpen=0;
    }else if(manager->musicOpen&&(manager->tickCount%20UL)==0UL){
        sprintf(command,"setaudio clonemcmusic volume to %d",
            (int)(CloneMCJ_SoundManager_Clamp(manager->musicVolume,0.0F,1.0F)*1000.0F));
        mciSendStringA(command,0,0,0);
    }
    if(player){
        dx=player->entity.posX-manager->previousPlayerX;
        dz=player->entity.posZ-manager->previousPlayerZ;
        if(manager->tickCount>1)manager->walkDistance+=sqrt(dx*dx+dz*dz);
        manager->previousPlayerX=player->entity.posX;manager->previousPlayerZ=player->entity.posZ;
        manager->listenerX=player->entity.posX;manager->listenerY=player->entity.posY;
        manager->listenerZ=player->entity.posZ;
        manager->listenerYaw=player->entity.rotationYaw;
        if(manager->walkDistance>=1.8){
            manager->walkDistance=0.0;
            blockID=CloneMCJ_World_GetBlockId(player->entity.worldObj,
                CloneMCJava_FloorDouble(player->entity.posX),
                CloneMCJava_FloorDouble(player->entity.boundingBox.minY)-1,
                CloneMCJava_FloorDouble(player->entity.posZ));
            if(blockID==51)CloneMCJ_SoundManager_PlaySoundAt(manager,"fire.fire",
                (float)player->entity.posX,(float)player->entity.posY,
                (float)player->entity.posZ,1.0F,1.0F);
            else CloneMCJ_SoundManager_PlaySoundAt(manager,
                CloneMCJ_SoundManager_StepForBlock(blockID),(float)player->entity.posX,
                (float)player->entity.posY,(float)player->entity.posZ,0.15F,
                CloneMCJ_SoundManager_PitchForBlock(blockID));
        }
        if(player->itemsPickedUp!=manager->previousItemsPickedUp){
            manager->previousItemsPickedUp=player->itemsPickedUp;
            CloneMCJ_SoundManager_PlaySoundAt(manager,"random.pop",(float)player->entity.posX,
                (float)player->entity.posY,(float)player->entity.posZ,0.2F,2.0F);
        }
        if(manager->playerHealthKnown&&player->health<manager->previousPlayerHealth)
            CloneMCJ_SoundManager_PlaySoundAt(manager,"random.hurt",(float)player->entity.posX,
                (float)player->entity.posY,(float)player->entity.posZ,1.0F,1.0F);
        manager->previousPlayerHealth=player->health;manager->playerHealthKnown=1;
    }
    if(manager->legacySafeMode)return;
    if(manager->effectOpen){
        for(index=0;index<CLONEMC_SOUND_EFFECT_CHANNELS;++index){
            if(!manager->effectChannels[index])continue;
            CloneMCJ_SoundManager_EffectAlias(index,alias);status[0]='\0';
            sprintf(command,"status %s mode",alias);
            if(mciSendStringA(command,status,sizeof(status),0)!=0||strcmp(status,"playing")!=0){
                sprintf(command,"close %s",alias);mciSendStringA(command,0,0,0);
                manager->effectChannels[index]=0;manager->effectPriority[index]=0;
                manager->effectAudible[index]=0.0F;manager->effectNames[index][0]='\0';
                if(manager->effectOpen>0)--manager->effectOpen;
                if(manager->recordChannel==index)manager->recordChannel=-1;
            }
        }
    }
    if(manager->musicOpen){
        status[0]='\0';
        if(mciSendStringA("status clonemcmusic mode",status,sizeof(status),0)!=0||strcmp(status,"playing")!=0){
            mciSendStringA("close clonemcmusic",0,0,0);manager->musicOpen=0;
            manager->ticksBeforeMusic=12000+(int)CloneMCJavaRandom_NextIntBound(
                &manager->random,12000);
        }
    }else if(manager->recordChannel<0&&manager->musicVolume>0.0F){
        if(manager->ticksBeforeMusic>0)--manager->ticksBeforeMusic;
        else CloneMCJ_SoundManager_PlaySound(manager,"music");
    }
}

static const char *CloneMCJ_SoundManager_MobLiving(CloneMCJ_MobType type)
{
    switch(type){
    case CLONEMC_J_MOB_PIG:return "mob.pig";
    case CLONEMC_J_MOB_SHEEP:return "mob.sheep";
    case CLONEMC_J_MOB_COW:return "mob.cow";
    case CLONEMC_J_MOB_CHICKEN:return "mob.chicken";
    case CLONEMC_J_MOB_ZOMBIE:case CLONEMC_J_MOB_GIANT:
    case CLONEMC_J_MOB_PIG_ZOMBIE:return "mob.zombie";
    case CLONEMC_J_MOB_SKELETON:return "mob.skeleton";
    case CLONEMC_J_MOB_CREEPER:return "mob.creeper";
    case CLONEMC_J_MOB_SPIDER:return "mob.spider";
    case CLONEMC_J_MOB_SLIME:return "mob.slime";
    case CLONEMC_J_MOB_WOLF:return "mob.wolf";
    default:return 0;}
}

static const char *CloneMCJ_SoundManager_MobHurt(CloneMCJ_MobType type,int dead)
{
    if(type==CLONEMC_J_MOB_CHICKEN)return "mob.chickenhurt";
    if(type==CLONEMC_J_MOB_COW)return "mob.cowhurt";
    if(type==CLONEMC_J_MOB_SKELETON)return "mob.skeletonhurt";
    if(type==CLONEMC_J_MOB_WOLF)return "mob.wolfhurt";
    if(type==CLONEMC_J_MOB_ZOMBIE||type==CLONEMC_J_MOB_GIANT||
       type==CLONEMC_J_MOB_PIG_ZOMBIE)return "mob.zombiehurt";
    if(type==CLONEMC_J_MOB_CREEPER&&dead)return "mob.creeperdeath";
    if(type==CLONEMC_J_MOB_SPIDER&&dead)return "mob.spiderdeath";
    return CloneMCJ_SoundManager_MobLiving(type);
}

void CloneMCJ_SoundManager_TickGameplayNative(CloneMCJ_SoundManagerState *manager,
    const CloneMCJ_GameplayState *gameplay)
{
    int index;const CloneMCJ_Mob *mob;const char *sound;float pitch;
    if(!manager||!gameplay)return;
    CloneMCJ_SoundManager_TickNative(manager,&gameplay->player);
    if(manager->lastBlockBreakEventSequence<gameplay->blockBreakEventSequence){
        unsigned long first;unsigned long sequence;CloneMCJ_BlockBreakEvent event;
        first=manager->lastBlockBreakEventSequence+1UL;
        if(gameplay->blockBreakEventSequence-first>=CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY)
            first=gameplay->blockBreakEventSequence-CLONEMC_J_BLOCK_BREAK_EVENT_CAPACITY+1UL;
        for(sequence=first;sequence<=gameplay->blockBreakEventSequence;++sequence)
            if(CloneMCJ_Gameplay_GetBlockBreakEvent(gameplay,sequence,&event))
                CloneMCJ_SoundManager_PlaySoundAt(manager,
                    CloneMCJ_SoundManager_DigForBlock(event.blockID),
                    (float)event.x+0.5F,(float)event.y+0.5F,(float)event.z+0.5F,1.0F,
                    CloneMCJ_SoundManager_PitchForBlock(event.blockID)*0.8F);
        manager->lastBlockBreakEventSequence=gameplay->blockBreakEventSequence;
        manager->previousBlocksMined=gameplay->player.blocksMined;
    }
    if(manager->lastExplosionEventSequence<gameplay->explosionEventSequence){
        unsigned long first;unsigned long sequence;CloneMCJ_ExplosionEvent event;
        first=manager->lastExplosionEventSequence+1UL;
        if(gameplay->explosionEventSequence-first>=CLONEMC_J_EXPLOSION_EVENT_CAPACITY)
            first=gameplay->explosionEventSequence-CLONEMC_J_EXPLOSION_EVENT_CAPACITY+1UL;
        for(sequence=first;sequence<=gameplay->explosionEventSequence;++sequence)
            if(CloneMCJ_Gameplay_GetExplosionEvent(gameplay,sequence,&event))
                CloneMCJ_SoundManager_PlaySoundAt(manager,"random.explode",
                    (float)event.x,(float)event.y,(float)event.z,4.0F,
                    (1.0F+(CloneMCJavaRandom_NextFloat(&manager->random)-
                    CloneMCJavaRandom_NextFloat(&manager->random))*0.2F)*0.7F);
        manager->lastExplosionEventSequence=gameplay->explosionEventSequence;
    }
    if(gameplay->player.blocksPlaced!=manager->previousBlocksPlaced){
        manager->previousBlocksPlaced=gameplay->player.blocksPlaced;
        CloneMCJ_SoundManager_PlaySoundAt(manager,CloneMCJ_SoundManager_StepForBlock(gameplay->player.lastPlacedBlockID),
            (float)gameplay->player.lastPlacedX+0.5F,(float)gameplay->player.lastPlacedY+0.5F,
            (float)gameplay->player.lastPlacedZ+0.5F,1.0F,
            CloneMCJ_SoundManager_PitchForBlock(gameplay->player.lastPlacedBlockID)*0.8F);
    }
    if(gameplay->openContainerActive &&
       gameplay->openContainer.type==CLONEMC_J_CONTAINER_CHEST &&
       (!manager->previousContainerActive ||
        manager->previousContainerType!=CLONEMC_J_CONTAINER_CHEST)) {
        CloneMCJ_SoundManager_PlaySoundAt(manager,"random.chestopen",
            (float)gameplay->openContainerX+0.5F,
            (float)gameplay->openContainerY+0.5F,
            (float)gameplay->openContainerZ+0.5F,0.5F,
            CloneMCJavaRandom_NextFloat(&manager->random)*0.1F+0.9F);
    } else if(!gameplay->openContainerActive && manager->previousContainerActive &&
              manager->previousContainerType==CLONEMC_J_CONTAINER_CHEST) {
        CloneMCJ_SoundManager_PlaySoundAt(manager,"random.chestclosed",
            (float)manager->previousContainerX+0.5F,
            (float)manager->previousContainerY+0.5F,
            (float)manager->previousContainerZ+0.5F,0.5F,
            CloneMCJavaRandom_NextFloat(&manager->random)*0.1F+0.9F);
    }
    manager->previousContainerActive=gameplay->openContainerActive;
    if(gameplay->openContainerActive){
        manager->previousContainerType=gameplay->openContainer.type;
        manager->previousContainerX=gameplay->openContainerX;
        manager->previousContainerY=gameplay->openContainerY;
        manager->previousContainerZ=gameplay->openContainerZ;
    }
    if(gameplay->player.blocksActivated!=manager->previousBlocksActivated){
        int activatedId,activatedMeta;
        manager->previousBlocksActivated=gameplay->player.blocksActivated;
        activatedId=gameplay->player.lastActivatedBlockID;
        activatedMeta=gameplay->player.lastActivatedMetadata;
        if(activatedId==64||activatedId==96)
            CloneMCJ_SoundManager_PlaySoundAt(manager,
                (activatedMeta&4)?"random.door_open":"random.door_close",
                (float)gameplay->player.lastActivatedX+0.5F,
                (float)gameplay->player.lastActivatedY+0.5F,
                (float)gameplay->player.lastActivatedZ+0.5F,1.0F,1.0F);
        else if(activatedId==60)
            CloneMCJ_SoundManager_PlaySoundAt(manager,
                CloneMCJ_SoundManager_StepForBlock(60),
                (float)gameplay->player.lastActivatedX+0.5F,
                (float)gameplay->player.lastActivatedY+0.5F,
                (float)gameplay->player.lastActivatedZ+0.5F,1.0F,
                CloneMCJ_SoundManager_PitchForBlock(60)*0.8F);
        else if(activatedId==69||activatedId==77||activatedId==93||activatedId==94)
            CloneMCJ_SoundManager_PlaySoundAt(manager,"random.click",
                (float)gameplay->player.lastActivatedX+0.5F,
                (float)gameplay->player.lastActivatedY+0.5F,
                (float)gameplay->player.lastActivatedZ+0.5F,0.3F,
                (activatedMeta&8)?0.6F:0.5F);
    }
    for(index=0;index<CLONEMC_SOUND_MOB_SLOTS&&index<CLONEMC_J_MAX_MOBS;++index){
        mob=&gameplay->mobs[index];
        if(!mob->active){manager->previousMobActive[index]=0;manager->mobTalkCounter[index]=0;continue;}
        if(!manager->previousMobActive[index]){
            manager->previousMobActive[index]=1;manager->previousMobHealth[index]=mob->health;
            manager->mobTalkCounter[index]=0;continue;
        }
        pitch=(CloneMCJavaRandom_NextFloat(&manager->random)-
            CloneMCJavaRandom_NextFloat(&manager->random))*0.2F+1.0F;
        if(mob->type==CLONEMC_J_MOB_GHAST){
            if(manager->previousGhastAttackCounter[index]<10&&mob->attackCounter>=10)
                CloneMCJ_SoundManager_PlaySoundAt(manager,"mob.ghast.charge",
                    (float)mob->entity.posX,(float)mob->entity.posY,(float)mob->entity.posZ,10.0F,pitch);
            if(manager->previousGhastAttackCounter[index]<20&&mob->attackCounter>=20)
                CloneMCJ_SoundManager_PlaySoundAt(manager,"mob.ghast.fireball",
                    (float)mob->entity.posX,(float)mob->entity.posY,(float)mob->entity.posZ,10.0F,pitch);
            manager->previousGhastAttackCounter[index]=mob->attackCounter;
        }
        if(mob->health<manager->previousMobHealth[index]){
            sound=CloneMCJ_SoundManager_MobHurt(mob->type,mob->health<=0);
            if(sound)CloneMCJ_SoundManager_PlaySoundAt(manager,sound,(float)mob->entity.posX,
                (float)mob->entity.posY,(float)mob->entity.posZ,1.0F,pitch);
        }else if(CloneMCJavaRandom_NextIntBound(&manager->random,1000)<
                 manager->mobTalkCounter[index]++){
            manager->mobTalkCounter[index]=-80;sound=CloneMCJ_SoundManager_MobLiving(mob->type);
            if(sound)CloneMCJ_SoundManager_PlaySoundAt(manager,sound,(float)mob->entity.posX,
                (float)mob->entity.posY,(float)mob->entity.posZ,1.0F,pitch);
        }
        manager->previousMobHealth[index]=mob->health;
    }
}

void CloneMCJ_SoundManager_ShutdownNative(CloneMCJ_SoundManagerState *manager)
{
    int index;char command[64],alias[32];
    if(!manager)return;
    if(manager->legacySafeMode){
        PlaySoundA((LPCSTR)0,(HMODULE)0,0);
        manager->musicOpen=0;manager->effectOpen=0;manager->initialized=0;
        return;
    }
    if(manager->musicOpen){mciSendStringA("stop clonemcmusic",0,0,0);mciSendStringA("close clonemcmusic",0,0,0);}
    for(index=0;index<CLONEMC_SOUND_EFFECT_CHANNELS;++index){
        CloneMCJ_SoundManager_EffectAlias(index,alias);sprintf(command,"close %s",alias);
        mciSendStringA(command,0,0,0);manager->effectChannels[index]=0;
    }
    manager->musicOpen=0;manager->effectOpen=0;manager->initialized=0;
}

static int CloneMCJ_SoundManager_NetworkSound(void *context,const char *name,
    float x,float y,float z,float volume,float pitch)
{
    return CloneMCJ_SoundManager_PlaySoundAt((CloneMCJ_SoundManagerState*)context,
        name,x,y,z,volume,pitch);
}

static int CloneMCJ_SoundManager_NetworkStreaming(void *context,const char *name,
    float x,float y,float z,float volume,float pitch)
{
    return CloneMCJ_SoundManager_PlayStreaming((CloneMCJ_SoundManagerState*)context,
        name,x,y,z,volume,pitch);
}

void CloneMCNetClientHandler_BindSound(CloneMCNetClientHandler *handler,
    CloneMCJ_SoundManagerState *manager)
{
    if(!handler)return;
    handler->soundContext=manager;
    handler->playSoundAt=manager?CloneMCJ_SoundManager_NetworkSound:0;
    handler->playStreaming=manager?CloneMCJ_SoundManager_NetworkStreaming:0;
}

void CloneMCJ_SoundManager_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_SoundManager_JavaName(void)
{
    return "net.minecraft.src.SoundManager";
}

const char *CloneMCJ_SoundManager_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_SoundManager_JavaSourceHash32(void)
{
    return 0x432DCAC8UL;
}
