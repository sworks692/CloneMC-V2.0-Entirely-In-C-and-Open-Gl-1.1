/*
 * CloneMC Java port scaffold: Gui
 *
 * Java source: Gui.java
 * Java type: class Gui
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 946e3c87c39b342149d0679e79b1f23299ae5c775cf86abd421c0af289349705
 * Java lines: 130
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: Tessellator, FontRenderer, k, f2, f3, l, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected float zLevel
 *
 * Java method/constructor inventory:
 * - public Gui()
 * - protected void func_27100_a(int i, int j, int k, int l)
 * - protected void func_27099_b(int i, int j, int k, int l)
 * - protected void drawRect(int i, int j, int k, int l, int i1)
 * - protected void drawGradientRect(int i, int j, int k, int l, int i1, int j1)
 * - public void drawCenteredString(FontRenderer fontrenderer, String s, int i, int j, int k)
 * - public void drawString(FontRenderer fontrenderer, String s, int i, int j, int k)
 * - public void drawTexturedModalRect(int i, int j, int k, int l, int i1, int j1)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_Gui_ColorNative(unsigned long color,float *red,float *green,float *blue,float *alpha)
{
    if(alpha)*alpha=(float)((color>>24)&255UL)/255.0F;
    if(red)*red=(float)((color>>16)&255UL)/255.0F;
    if(green)*green=(float)((color>>8)&255UL)/255.0F;
    if(blue)*blue=(float)(color&255UL)/255.0F;
}

void CloneMCJ_Gui_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Gui_JavaName(void)
{
    return "net.minecraft.src.Gui";
}

const char *CloneMCJ_Gui_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_Gui_JavaSourceHash32(void)
{
    return 0x946E3C87UL;
}
