/*
 * CloneMC Java port scaffold: GuiOptions
 *
 * Java source: GuiOptions.java
 * Java type: class GuiOptions
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: f9003b3aaae587cc82f328b64738e70c1d3ed2fc2c1dbf4a045f58c6df7742be
 * Java lines: 97
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: GuiScreen, StringTranslate, EnumOptions, GuiSmallButton, GameSettings, GuiSlider, GuiButton, GuiVideoSettings, GuiControls, enumoptions
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private GuiScreen parentScreen
 * - protected String screenTitle
 * - private GameSettings options
 * - private static EnumOptions field_22135_k[]
 *
 * Java method/constructor inventory:
 * - public GuiOptions(GuiScreen guiscreen, GameSettings gamesettings)
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

static const int CloneMCJ_GuiOptions_Ordinals[5] = {
    CLONEMC_OPTION_MUSIC, CLONEMC_OPTION_SOUND,
    CLONEMC_OPTION_INVERT_MOUSE, CLONEMC_OPTION_SENSITIVITY,
    CLONEMC_OPTION_DIFFICULTY
};

static CloneMCJ_GuiButtonNative *CloneMCJ_GuiOptions_AddOption(
    CloneMCJ_GuiScreenState *screen,const CloneMCGameSettings *settings,
    int option,int x,int y)
{
    char label[72];
    const CloneMCJ_EnumOptionDefinition *definition;
    CloneMCJ_GuiButtonNative *button;
    CloneMCGameSettings_FormatOption(settings,option,label,sizeof(label));
    button=CloneMCJ_GuiScreen_AddButtonNative(screen,option,x,y,150,20,label);
    definition=CloneMCJ_EnumOptions_GetNative(option);
    if(button){
        button->optionOrdinal=option;
        button->slider=definition&&definition->isFloat;
        button->sliderValue=CloneMCGameSettings_GetOptionFloat(settings,option);
    }
    return button;
}

static void CloneMCJ_GuiOptions_Refresh(CloneMCJ_GuiScreenState *screen,
    const CloneMCGameSettings *settings)
{
    int center,top,index,option;
    screen->buttonCount=0;screen->selectedButton=-1;
    center=screen->width/2;top=screen->height/6;
    for(index=0;index<5;++index){
        option=CloneMCJ_GuiOptions_Ordinals[index];
        CloneMCJ_GuiOptions_AddOption(screen,settings,option,
            (center-155)+(index%2)*160,top+24*(index>>1));
    }
    CloneMCJ_GuiScreen_AddButtonNative(screen,101,center-100,top+108,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("options.video"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,100,center-100,top+132,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("options.controls"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,200,center-100,top+168,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("gui.done"));
}

void CloneMCJ_GuiOptions_InitNative(CloneMCJ_GuiScreenState *screen,const CloneMCGameSettings *settings)
{
    int width,height,scale,parent;
    if(!screen||!settings)return;
    width=screen->width;height=screen->height;
    scale=screen->scaleFactor;parent=screen->screenType==CLONEMC_GUI_SCREEN_MAIN_MENU?
        CLONEMC_GUI_SCREEN_MAIN_MENU:screen->parentType;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_OPTIONS,parent,scale);
    screen->width=width;screen->height=height;
    strncpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative("options.title"),
        sizeof(screen->title)-1);
    CloneMCJ_GuiOptions_Refresh(screen,settings);
}

int CloneMCJ_GuiOptions_ActivateNative(CloneMCJ_GuiScreenState *screen,
    CloneMCGameSettings *settings,int id)
{
    const CloneMCJ_EnumOptionDefinition *definition;
    int index;
    float value;
    CloneMCJ_GuiButtonNative *button;
    if(!screen||!settings)return 0;
    definition=CloneMCJ_EnumOptions_GetNative(id);
    if(!definition)return 0;
    if(definition->isFloat){
        button=(CloneMCJ_GuiButtonNative *)0;
        for(index=0;index<screen->buttonCount;++index)
            if(screen->buttons[index].id==id&&screen->buttons[index].slider){
                button=&screen->buttons[index];break;
            }
        if(!button||button->width<=8)return 0;
        value=(float)(screen->mouseX-(button->xPosition+4))/(float)(button->width-8);
        CloneMCGameSettings_SetOptionFloat(settings,id,value);
        button->sliderValue=CloneMCGameSettings_GetOptionFloat(settings,id);
        CloneMCGameSettings_FormatOption(settings,id,button->displayString,
            sizeof(button->displayString));
        return 1;
    }else CloneMCGameSettings_SetOptionValue(settings,id,1);
    CloneMCJ_GuiOptions_Refresh(screen,settings);return 1;
}

int CloneMCJ_GuiOptions_DragSliderNative(CloneMCJ_GuiScreenState *screen,
    CloneMCGameSettings *settings)
{
    int index;
    float value;
    CloneMCJ_GuiButtonNative *button;
    char label[72];
    if(!screen||!settings)return 0;
    for(index=0;index<screen->buttonCount;++index){
        button=&screen->buttons[index];
        if(!button->slider||!button->dragging)continue;
        if(button->width<=8||
           !CloneMCJ_EnumOptions_GetNative(button->optionOrdinal)){
            button->dragging=0;continue;
        }
        value=(float)(screen->mouseX-(button->xPosition+4))/(float)(button->width-8);
        if(!CloneMCGameSettings_SetOptionFloat(settings,button->optionOrdinal,value))return 0;
        button->sliderValue=CloneMCGameSettings_GetOptionFloat(settings,button->optionOrdinal);
        CloneMCGameSettings_FormatOption(settings,button->optionOrdinal,label,sizeof(label));
        strncpy(button->displayString,label,sizeof(button->displayString)-1);
        button->displayString[sizeof(button->displayString)-1]='\0';
        return 1;
    }
    return 0;
}

void CloneMCJ_GuiOptions_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiOptions_JavaName(void)
{
    return "net.minecraft.src.GuiOptions";
}

const char *CloneMCJ_GuiOptions_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiOptions_JavaSourceHash32(void)
{
    return 0xF9003B3AUL;
}
