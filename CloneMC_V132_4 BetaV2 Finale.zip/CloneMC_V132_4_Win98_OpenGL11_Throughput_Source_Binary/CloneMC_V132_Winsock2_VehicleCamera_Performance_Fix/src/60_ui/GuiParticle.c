/*
 * CloneMC Java port scaffold: GuiParticle
 *
 * Java source: GuiParticle.java
 * Java type: class GuiParticle
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: Gui
 * Implements: (none declared)
 * Source SHA-256: d66cb0bab9dec41415a69fdcbba4b49a47238bd74d96854e6144a4c66a2b12d1
 * Java lines: 60
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Gui, Particle, RenderEngine, f3, f4, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private List field_25090_a
 * - private Minecraft field_25089_b
 *
 * Java method/constructor inventory:
 * - public GuiParticle(Minecraft minecraft)
 * - public void func_25088_a()
 * - public void func_25087_a(float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

unsigned long CloneMCJ_GuiParticle_UpdateNative(unsigned long seed,float *x,float *y)
{
    seed=seed*1664525UL+1013904223UL;if(x)*x+=(float)((int)((seed>>24)&15UL)-7)*0.02F;
    seed=seed*1664525UL+1013904223UL;if(y)*y+=0.05F+(float)((seed>>28)&3UL)*0.01F;
    return seed;
}

void CloneMCJ_GuiParticle_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiParticle_JavaName(void)
{
    return "net.minecraft.src.GuiParticle";
}

const char *CloneMCJ_GuiParticle_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiParticle_JavaSourceHash32(void)
{
    return 0xD66CB0BAUL;
}
