/*
 * CloneMC Java port scaffold: GuiConnectFailed
 *
 * Java source: GuiConnectFailed.java
 * Java type: class GuiConnectFailed
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 3a4f642c6657a504b6e6abb98867dd8b8c3f1801f9933f7c786d04db2679bbd4
 * Java lines: 63
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: GuiScreen, StringTranslate, GuiButton, GuiMainMenu, errorMessage, errorDetail, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private String errorMessage
 * - private String errorDetail
 *
 * Java method/constructor inventory:
 * - public GuiConnectFailed(String s, String s1, Object aobj[])
 * - public void updateScreen()
 * - protected void keyTyped(char c, int i)
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_GuiConnectFailed_InitNative(CloneMCJ_GuiScreenState *screen,const char *reason)
{CloneMCJ_GuiErrorScreen_InitNative(screen,"Failed to connect to the server",reason);}

void CloneMCJ_GuiConnectFailed_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiConnectFailed_JavaName(void)
{
    return "net.minecraft.src.GuiConnectFailed";
}

const char *CloneMCJ_GuiConnectFailed_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiConnectFailed_JavaSourceHash32(void)
{
    return 0x3A4F642CUL;
}
