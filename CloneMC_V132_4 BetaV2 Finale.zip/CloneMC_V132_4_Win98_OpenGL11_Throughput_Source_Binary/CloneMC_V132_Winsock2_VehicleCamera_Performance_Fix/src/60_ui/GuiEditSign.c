/*
 * CloneMC Java port scaffold: GuiEditSign
 *
 * Java source: GuiEditSign.java
 * Java type: class GuiEditSign
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 73bc6926926d8474086fa8c7d64281ce984bb4eb7df116b35dc4fe0239cf1a79
 * Java lines: 136
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: GuiScreen, GuiButton, World, Packet130UpdateSign, TileEntitySign, NetClientHandler, Block, TileEntityRenderer, ChatAllowedCharacters, entitySign.yCoord, entitySign.zCoord, int
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected String screenTitle
 * - private TileEntitySign entitySign
 * - private int updateCounter
 * - private int editLine
 * - private static final String allowedCharacters
 *
 * Java method/constructor inventory:
 * - public GuiEditSign(TileEntitySign tileentitysign)
 * - public void initGui()
 * - public void onGuiClosed()
 * - public void updateScreen()
 * - protected void actionPerformed(GuiButton guibutton)
 * - protected void keyTyped(char c, int i)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include "../30_item/clonemc_java_port_30_item.h"
#include <string.h>

int CloneMCJ_GuiEditSign_KeyNative(char lines[4][16],int *editLine,int key,int character)
{
    unsigned long length;if(!lines||!editLine)return 0;
    if(key==200){*editLine=(*editLine-1)&3;return 1;}
    if(key==208||key==28){*editLine=(*editLine+1)&3;return 1;}
    length=(unsigned long)strlen(lines[*editLine]);
    if((key==14||character==8)&&length){lines[*editLine][length-1]='\0';return 1;}
    if(character>=32&&character<=126&&length<15){lines[*editLine][length]=(char)character;
        lines[*editLine][length+1]='\0';return 1;}return 0;
}

int CloneMCJ_GuiEditSign_KeyTileNative(CloneMCJ_TileEntity *tile,int *editLine,
    int key,int character)
{
    unsigned long length;
    char *line;
    if(!tile||tile->type!=CLONEMC_J_TILE_SIGN||!editLine)return 0;
    if(key==200){*editLine=(*editLine-1)&3;return 1;}
    if(key==208||key==28||character==13||character==10){
        *editLine=(*editLine+1)&3;return 1;
    }
    line=tile->signText[*editLine];
    length=(unsigned long)strlen(line);
    if((key==14||character==8)&&length){line[length-1]='\0';return 1;}
    if(character>=32&&character<=126&&length<15&&
       CloneMCJ_ChatAllowedCharacters_IsAllowedNative(character)){
        line[length]=(char)character;line[length+1]='\0';return 1;
    }
    return 0;
}

void CloneMCJ_GuiEditSign_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiEditSign_JavaName(void)
{
    return "net.minecraft.src.GuiEditSign";
}

const char *CloneMCJ_GuiEditSign_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiEditSign_JavaSourceHash32(void)
{
    return 0x73BC6926UL;
}
