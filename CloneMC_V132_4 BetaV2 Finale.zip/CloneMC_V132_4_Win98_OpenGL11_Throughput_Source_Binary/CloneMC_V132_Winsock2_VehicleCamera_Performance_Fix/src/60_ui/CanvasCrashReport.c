/*
 * CloneMC Java port scaffold: CanvasCrashReport
 *
 * Java source: CanvasCrashReport.java
 * Java type: class CanvasCrashReport
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 6f1322f93a772986c192c5af021cfaf01564372f01849ee455ee6320f9e4d23a
 * Java lines: 19
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public CanvasCrashReport(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_CanvasCrashReport_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_CanvasCrashReport_JavaName(void)
{
    return "net.minecraft.src.CanvasCrashReport";
}

const char *CloneMCJ_CanvasCrashReport_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_CanvasCrashReport_JavaSourceHash32(void)
{
    return 0x6F1322F9UL;
}
