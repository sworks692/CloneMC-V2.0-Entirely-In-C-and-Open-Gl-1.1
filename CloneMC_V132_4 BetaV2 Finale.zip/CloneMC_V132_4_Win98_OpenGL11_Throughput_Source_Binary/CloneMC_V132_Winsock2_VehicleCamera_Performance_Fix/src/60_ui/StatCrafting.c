/*
 * CloneMC Java port scaffold: StatCrafting
 *
 * Java source: StatCrafting.java
 * Java type: class StatCrafting
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: StatBase
 * Implements: (none declared)
 * Source SHA-256: c4a39870da0319c86fcaa76e5b14df41cb36ded27800d8b46d0fc53273708046
 * Java lines: 27
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: StatBase
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final int field_25073_a
 *
 * Java method/constructor inventory:
 * - public StatCrafting(int i, String s, int j)
 * - public int func_25072_b()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_StatCrafting_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_StatCrafting_JavaName(void)
{
    return "net.minecraft.src.StatCrafting";
}

const char *CloneMCJ_StatCrafting_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_StatCrafting_JavaSourceHash32(void)
{
    return 0xC4A39870UL;
}
