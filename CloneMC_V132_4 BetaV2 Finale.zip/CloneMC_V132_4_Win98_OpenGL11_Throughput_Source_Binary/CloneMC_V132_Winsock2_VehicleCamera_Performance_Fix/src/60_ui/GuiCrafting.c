/*
 * CloneMC Java port scaffold: GuiCrafting
 *
 * Java source: GuiCrafting.java
 * Java type: class GuiCrafting
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiContainer
 * Implements: (none declared)
 * Source SHA-256: 2e22ccecfb889db5f80e68357619a6381c01a111a71b29f92a3755f6c210c2ae
 * Java lines: 44
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: GuiContainer, ContainerWorkbench, Container, FontRenderer, RenderEngine, InventoryPlayer, World, world, i, j, k, xSize
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GuiCrafting(InventoryPlayer inventoryplayer, World world, int i, int j, int k)
 * - public void onGuiClosed()
 * - protected void drawGuiContainerForegroundLayer()
 * - protected void drawGuiContainerBackgroundLayer(float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiCrafting_LayoutNative(CloneMCJ_GuiContainerLayout *layout)
{
    if(!layout)return;
    memset(layout,0,sizeof(*layout));strcpy(layout->title,"Crafting");
    layout->xSize=176;layout->ySize=166;layout->rows=3;layout->columns=3;layout->textureKind=2;
}

void CloneMCJ_GuiCrafting_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiCrafting_JavaName(void)
{
    return "net.minecraft.src.GuiCrafting";
}

const char *CloneMCJ_GuiCrafting_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiCrafting_JavaSourceHash32(void)
{
    return 0x2E22CCECUL;
}
