/*
 * CloneMC Java port scaffold: GuiRenameWorld
 *
 * Java source: GuiRenameWorld.java
 * Java type: class GuiRenameWorld
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 9826bb3449a5ee1ce7fed46b6aec68e44ff5e81ca19d4a694cbce4c353204c0e
 * Java lines: 97
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: GuiScreen, GuiTextField, StringTranslate, GuiButton, ISaveFormat, WorldInfo, fontRenderer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private GuiScreen field_22112_a
 * - private GuiTextField field_22114_h
 * - private final String field_22113_i
 *
 * Java method/constructor inventory:
 * - public GuiRenameWorld(GuiScreen guiscreen, String s)
 * - public void updateScreen()
 * - public void initGui()
 * - public void onGuiClosed()
 * - protected void actionPerformed(GuiButton guibutton)
 * - protected void keyTyped(char c, int i)
 * - protected void mouseClicked(int i, int j, int k)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiRenameWorld_InitNative(CloneMCJ_GuiScreenState *screen,const char *name)
{
    int width,height,scale,center;if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_RENAME_WORLD,
        CLONEMC_GUI_SCREEN_SELECT_WORLD,scale);screen->width=width;screen->height=height;
    center=width/2;strcpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative(
        "selectWorld.renameTitle"));
    strcpy(screen->message,CloneMCJ_StringTranslate_TranslateKeyNative(
        "selectWorld.enterName"));
    if(!name)name="World";
    strncpy(screen->textField,name,sizeof(screen->textField)-1);
    screen->textField[sizeof(screen->textField)-1]='\0';screen->textFocused=1;
    CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-100,height/4+108,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.renameButton"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,height/4+132,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("gui.cancel"));
}

void CloneMCJ_GuiRenameWorld_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiRenameWorld_JavaName(void)
{
    return "net.minecraft.src.GuiRenameWorld";
}

const char *CloneMCJ_GuiRenameWorld_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiRenameWorld_JavaSourceHash32(void)
{
    return 0x9826BB34UL;
}
