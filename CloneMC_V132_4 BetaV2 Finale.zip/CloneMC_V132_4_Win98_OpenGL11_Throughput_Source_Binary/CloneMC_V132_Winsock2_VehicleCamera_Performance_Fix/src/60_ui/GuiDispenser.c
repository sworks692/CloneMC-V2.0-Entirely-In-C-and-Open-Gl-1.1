/*
 * CloneMC Java port scaffold: GuiDispenser
 *
 * Java source: GuiDispenser.java
 * Java type: class GuiDispenser
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiContainer
 * Implements: (none declared)
 * Source SHA-256: 1ad73a0195fb704cdf4dc7f0c0c22a2c4b5cdd5d856efb5cc65384d3db8c9839
 * Java lines: 38
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: GuiContainer, ContainerDispenser, FontRenderer, RenderEngine, InventoryPlayer, TileEntityDispenser, k, xSize
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GuiDispenser(InventoryPlayer inventoryplayer, TileEntityDispenser tileentitydispenser)
 * - protected void drawGuiContainerForegroundLayer()
 * - protected void drawGuiContainerBackgroundLayer(float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiDispenser_LayoutNative(CloneMCJ_GuiContainerLayout *layout)
{
    if(!layout)return;
    memset(layout,0,sizeof(*layout));strcpy(layout->title,"Dispenser");
    layout->xSize=176;layout->ySize=166;layout->rows=3;layout->columns=3;layout->textureKind=3;
}

void CloneMCJ_GuiDispenser_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiDispenser_JavaName(void)
{
    return "net.minecraft.src.GuiDispenser";
}

const char *CloneMCJ_GuiDispenser_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiDispenser_JavaSourceHash32(void)
{
    return 0x1AD73A01UL;
}
