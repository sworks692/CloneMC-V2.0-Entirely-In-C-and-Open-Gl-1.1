/*
 * CloneMC Java port scaffold: GuiTexturePackSlot
 *
 * Java source: GuiTexturePackSlot.java
 * Java type: class GuiTexturePackSlot
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: aea4502e845c1e87368f8f3a87133b1a65382506b2ed9049ab7de7872f23821f
 * Java lines: 72
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: GuiSlot, GuiTexturePacks, TexturePackList, TexturePackBase, RenderEngine, Tessellator, guitexturepacks.width, guitexturepacks.height, tessellator.startDrawingQu
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GuiTexturePackSlot(GuiTexturePacks guitexturepacks)
 * - protected int getSize()
 * - protected void elementClicked(int i, boolean flag)
 * - protected boolean isSelected(int i)
 * - protected int getContentHeight()
 * - protected void drawBackground()
 * - protected void drawSlot(int i, int j, int k, int l, Tessellator tessellator)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_GuiTexturePackSlot_InitializeNative(CloneMCJ_GuiButtonNative *button,
    int index,int centerX,int y,const char *name)
{CloneMCJ_GuiButton_InitializeNative(button,index,centerX-110,y,220,36,name);}

void CloneMCJ_GuiTexturePackSlot_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiTexturePackSlot_JavaName(void)
{
    return "net.minecraft.src.GuiTexturePackSlot";
}

const char *CloneMCJ_GuiTexturePackSlot_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiTexturePackSlot_JavaSourceHash32(void)
{
    return 0xAEA4502EUL;
}
