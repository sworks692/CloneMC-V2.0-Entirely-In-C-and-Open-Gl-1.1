/*
 * CloneMC Java port scaffold: GuiMainMenu
 *
 * Java source: GuiMainMenu.java
 * Java type: class GuiMainMenu
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 3ece4b631bbad53aa55c28863bc1309ed78943a28372a1f52e32bd40a8f4eb41
 * Java lines: 153
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: GuiScreen, StringTranslate, GuiButton, GuiOptions, GuiSelectWorld, GuiMultiplayer, GuiTexturePacks, Tessellator, RenderEngine, MathHelper, FontRenderer, try, do
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private float updateCounter
 * - private String splashText
 * - private GuiButton multiplayerButton
 *
 * Java method/constructor inventory:
 * - public GuiMainMenu()
 * - public void updateScreen()
 * - protected void keyTyped(char c, int i)
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 * - private static final Random rand = new Random()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static void CloneMCJ_GuiMainMenu_LoadSplash(char *destination,unsigned long capacity)
{
    FILE *file;
    char line[192];
    unsigned long count,choice,state;
    size_t length,start;
    time_t now;
    if(!destination||capacity==0)return;
    strcpy(destination,"missingno");
    file=fopen("assets/title/splashes.txt","rb");
    if(!file)return;
    now=time(0);state=(unsigned long)now^0x3ECE4B63UL;count=0;
    while(fgets(line,sizeof(line),file)){
        length=strlen(line);start=0;
        while(start<length&&(line[start]==' '||line[start]=='\t'))++start;
        while(length>start&&(line[length-1]=='\r'||line[length-1]=='\n'||
              line[length-1]==' '||line[length-1]=='\t'))--length;
        if(length==start)continue;
        ++count;state=state*1664525UL+1013904223UL;choice=state%count;
        if(choice==0){
            unsigned long copyLength;
            copyLength=(unsigned long)(length-start);
            if(copyLength>=capacity)copyLength=capacity-1;
            memcpy(destination,line+start,(size_t)copyLength);
            destination[copyLength]='\0';
        }
    }
    fclose(file);
}

static void CloneMCJ_GuiMainMenu_ApplyCalendarSplash(char *destination,
    unsigned long capacity)
{
    time_t now;
    struct tm *calendar;
    const char *special;
    special=0;now=time(0);calendar=localtime(&now);
    if(calendar){
        if(calendar->tm_mon==10&&calendar->tm_mday==9)special="Happy birthday, ez!";
        else if(calendar->tm_mon==5&&calendar->tm_mday==1)special="Happy birthday, Notch!";
        else if(calendar->tm_mon==11&&calendar->tm_mday==24)special="Merry X-mas!";
        else if(calendar->tm_mon==0&&calendar->tm_mday==1)special="Happy new year!";
    }
    if(special&&capacity){strncpy(destination,special,(size_t)(capacity-1));
        destination[capacity-1]='\0';}
}

void CloneMCJ_GuiMainMenu_InitNative(CloneMCJ_GuiScreenState *screen)
{
    int center,top,width,height,scale;
    if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_MAIN_MENU,
        CLONEMC_GUI_SCREEN_NONE,scale);
    screen->width=width;screen->height=height;
    center=width/2;top=height/4+48;
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,top,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("menu.singleplayer"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,2,center-100,top+24,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("menu.multiplayer"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,3,center-100,top+48,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("menu.mods"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-100,top+84,98,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("menu.options"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,4,center+2,top+84,98,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("menu.quit"));
    strcpy(screen->title,"Minecraft Beta 1.7.3");
    CloneMCJ_GuiMainMenu_LoadSplash(screen->message,sizeof(screen->message));
    CloneMCJ_GuiMainMenu_ApplyCalendarSplash(screen->message,sizeof(screen->message));
}

void CloneMCJ_GuiMainMenu_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiMainMenu_JavaName(void)
{
    return "net.minecraft.src.GuiMainMenu";
}

const char *CloneMCJ_GuiMainMenu_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiMainMenu_JavaSourceHash32(void)
{
    return 0x3ECE4B63UL;
}
