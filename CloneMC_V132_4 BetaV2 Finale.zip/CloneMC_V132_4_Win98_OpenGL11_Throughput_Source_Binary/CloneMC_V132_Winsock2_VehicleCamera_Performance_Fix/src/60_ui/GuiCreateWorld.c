/*
 * CloneMC Java port scaffold: GuiCreateWorld
 *
 * Java source: GuiCreateWorld.java
 * Java type: class GuiCreateWorld
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: a98cb9827e56d533581716b5789c41f12becabb24bd012d02b426be2ee54781b
 * Java lines: 171
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: GuiScreen, GuiTextField, StringTranslate, GuiButton, ChatAllowedCharacters, MathHelper, ISaveFormat, PlayerControllerSP, fontRenderer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private GuiScreen field_22131_a
 * - private GuiTextField textboxWorldName
 * - private GuiTextField textboxSeed
 * - private String folderName
 * - private boolean createClicked
 *
 * Java method/constructor inventory:
 * - public GuiCreateWorld(GuiScreen guiscreen)
 * - public void updateScreen()
 * - public void initGui()
 * - private void func_22129_j()
 * - public static String generateUnusedFolderName(ISaveFormat isaveformat, String s)
 * - public void onGuiClosed()
 * - protected void actionPerformed(GuiButton guibutton)
 * - protected void keyTyped(char c, int i)
 * - protected void mouseClicked(int i, int j, int k)
 * - public void drawScreen(int i, int j, float f)
 * - public void selectNextField()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int CloneMCJ_GuiCreateWorld_IsReservedWindowsName(const char *name)
{
    char stem[16];
    unsigned long length;
    unsigned long index;
    if(!name)return 0;
    length=0;
    while(name[length]&&name[length]!='.'&&length+1<sizeof(stem)){
        stem[length]=(char)toupper((unsigned char)name[length]);++length;
    }
    stem[length]='\0';
    if(!strcmp(stem,"CON")||!strcmp(stem,"PRN")||!strcmp(stem,"AUX")||
       !strcmp(stem,"NUL")||!strcmp(stem,"CLOCK$"))return 1;
    if(length==4&&(stem[3]>='1'&&stem[3]<='9')){
        char prefix[4];
        for(index=0;index<3;++index)prefix[index]=stem[index];
        prefix[3]='\0';
        if(!strcmp(prefix,"COM")||!strcmp(prefix,"LPT"))return 1;
    }
    return 0;
}

void CloneMCJ_GuiCreateWorld_InitNative(CloneMCJ_GuiScreenState *screen,
    int strictReference)
{
    int width,height,scale,center;if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_CREATE_WORLD,
        CLONEMC_GUI_SCREEN_SELECT_WORLD,scale);screen->width=width;screen->height=height;
    center=width/2;
    strncpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.create"),
        sizeof(screen->title)-1);
    strcpy(screen->textField,CloneMCJ_StringTranslate_TranslateKeyNative(
        "selectWorld.newWorld"));
    screen->textFieldSecondary[0]='\0';screen->textFocused=1;screen->createClicked=0;
    screen->createGameMode=CLONEMC_J_GAMEMODE_SURVIVAL;screen->createAllowCheats=0;
    if(!strictReference){
        CloneMCJ_GuiScreen_AddButtonNative(screen,2,center-100,height/4+84,200,20,
            "Game Mode: Survival");
        CloneMCJ_GuiScreen_AddButtonNative(screen,3,center-100,height/4+108,200,20,
            "Allow Cheats: OFF");
        CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-100,height/4+132,200,20,
            CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.create"));
        CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,height/4+156,200,20,
            CloneMCJ_StringTranslate_TranslateKeyNative("gui.cancel"));
    }else{
        /* Uploaded GuiCreateWorld.java exposes only Create and Cancel. */
        CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-100,height/4+108,200,20,
            CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.create"));
        CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,height/4+132,200,20,
            CloneMCJ_StringTranslate_TranslateKeyNative("gui.cancel"));
    }
    CloneMCJ_GuiCreateWorld_UpdateFolderNative(screen,"saves");
}

int CloneMCJ_GuiCreateWorld_UpdateFolderNative(CloneMCJ_GuiScreenState *screen,
    const char *baseDirectory)
{
    char candidate[128];
    const char *source;
    unsigned long first,last,used,length;
    CloneMCJ_WorldInfo info;
    if(!screen)return 0;
    source=screen->textField;length=(unsigned long)strlen(source);first=0;last=length;
    while(first<last&&isspace((unsigned char)source[first]))++first;
    while(last>first&&isspace((unsigned char)source[last-1]))--last;
    used=0;
    while(first<last&&used+1<sizeof(candidate)){
        int character;
        character=(unsigned char)source[first++];
        candidate[used++]=CloneMCJ_ChatAllowedCharacters_IsIllegalFilenameNative(
            character)?'_':(char)character;
    }
    candidate[used]='\0';if(!candidate[0])strcpy(candidate,"World");
    /* Win32 rejects device names and silently strips trailing dots/spaces.
     * Normalize them before SaveHandler creates the directory, instead of
     * letting Create World fall through to a generic load failure. */
    while(used>0&&(candidate[used-1]=='.'||candidate[used-1]==' '))
        candidate[--used]='\0';
    if(!candidate[0]){strcpy(candidate,"World");used=5;}
    if(CloneMCJ_GuiCreateWorld_IsReservedWindowsName(candidate)&&
       used+1<sizeof(candidate)){candidate[used++]='_';candidate[used]='\0';}
    if(!baseDirectory)baseDirectory="saves";
    for(;;){
        memset(&info,0,sizeof(info));
        if(!CloneMCJ_SaveFormatOld_LoadWorldInfo(baseDirectory,candidate,&info))break;
        CloneMCJ_WorldInfo_Destroy(&info);
        if(strlen(candidate)+1>=sizeof(candidate))return 0;
        strcat(candidate,"-");
    }
    strncpy(screen->folderName,candidate,sizeof(screen->folderName)-1);
    screen->folderName[sizeof(screen->folderName)-1]='\0';
    if(screen->buttonCount>0)screen->buttons[0].enabled=screen->textField[0]!='\0';
    return 1;
}

void CloneMCJ_GuiCreateWorld_SelectNextFieldNative(CloneMCJ_GuiScreenState *screen)
{
    if(!screen)return;
    screen->textFocused=screen->textFocused==1?2:1;
}

static void CloneMCJ_GuiCreateWorld_SetButtonLabel(
    CloneMCJ_GuiScreenState *screen,int id,const char *label)
{
    int index;
    if(!screen||!label)return;
    for(index=0;index<screen->buttonCount;++index)
        if(screen->buttons[index].id==id){
            strncpy(screen->buttons[index].displayString,label,
                sizeof(screen->buttons[index].displayString)-1);
            screen->buttons[index].displayString[
                sizeof(screen->buttons[index].displayString)-1]='\0';
            return;
        }
}

int CloneMCJ_GuiCreateWorld_CycleGameModeNative(CloneMCJ_GuiScreenState *screen)
{
    char label[72];
    const char *name;
    if(!screen||screen->screenType!=CLONEMC_GUI_SCREEN_CREATE_WORLD)return 0;
    if(screen->createGameMode==CLONEMC_J_GAMEMODE_SURVIVAL){
        screen->createGameMode=CLONEMC_J_GAMEMODE_CREATIVE;name="Creative";
    }else if(screen->createGameMode==CLONEMC_J_GAMEMODE_CREATIVE){
        screen->createGameMode=CLONEMC_J_GAMEMODE_SPECTATOR;name="Spectator";
    }else{
        screen->createGameMode=CLONEMC_J_GAMEMODE_SURVIVAL;name="Survival";
    }
    sprintf(label,"Game Mode: %s",name);
    CloneMCJ_GuiCreateWorld_SetButtonLabel(screen,2,label);
    return 1;
}

int CloneMCJ_GuiCreateWorld_ToggleCheatsNative(CloneMCJ_GuiScreenState *screen)
{
    if(!screen||screen->screenType!=CLONEMC_GUI_SCREEN_CREATE_WORLD)return 0;
    screen->createAllowCheats=!screen->createAllowCheats;
    CloneMCJ_GuiCreateWorld_SetButtonLabel(screen,3,
        screen->createAllowCheats?"Allow Cheats: ON":"Allow Cheats: OFF");
    return 1;
}

static int CloneMCJ_GuiCreateWorld_ParseLong(const char *text,CloneMCJLong *result)
{
    CloneMCJULong value,limit;int negative,digit,count;
    if(!text||!result)return 0;
    while(*text&&isspace((unsigned char)*text))++text;
    negative=*text=='-';if(*text=='-'||*text=='+')++text;
    limit=((CloneMCJULong)(negative?0x80000000UL:0x7fffffffUL)<<32)|
        (CloneMCJULong)0xffffffffUL;value=0;count=0;
    while(*text>='0'&&*text<='9'){
        digit=*text++-'0';if(value>(limit-(CloneMCJULong)digit)/(CloneMCJULong)10)return 0;
        value=value*(CloneMCJULong)10+(CloneMCJULong)digit;++count;
    }
    while(*text&&isspace((unsigned char)*text))++text;
    if(!count||*text)return 0;
    if(negative){if(value==((CloneMCJULong)0x80000000UL<<32))*result=(CloneMCJLong)value;
        else *result=-(CloneMCJLong)value;}else *result=(CloneMCJLong)value;
    return 1;
}

CloneMCJLong CloneMCJ_GuiCreateWorld_ResolveSeedNative(
    const CloneMCJ_GuiScreenState *screen,CloneMCJLong randomSeed)
{
    const unsigned char *text;CloneMCJLong parsed;unsigned long hash;
    if(!screen||!screen->textFieldSecondary[0])return randomSeed;
    if(CloneMCJ_GuiCreateWorld_ParseLong(screen->textFieldSecondary,&parsed))
        return parsed!=(CloneMCJLong)0?parsed:randomSeed;
    hash=0;text=(const unsigned char*)screen->textFieldSecondary;
    while(*text)hash=hash*31UL+(unsigned long)*text++;
    return (CloneMCJLong)(signed long)hash;
}

void CloneMCJ_GuiCreateWorld_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiCreateWorld_JavaName(void)
{
    return "net.minecraft.src.GuiCreateWorld";
}

const char *CloneMCJ_GuiCreateWorld_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiCreateWorld_JavaSourceHash32(void)
{
    return 0xA98CB982UL;
}
