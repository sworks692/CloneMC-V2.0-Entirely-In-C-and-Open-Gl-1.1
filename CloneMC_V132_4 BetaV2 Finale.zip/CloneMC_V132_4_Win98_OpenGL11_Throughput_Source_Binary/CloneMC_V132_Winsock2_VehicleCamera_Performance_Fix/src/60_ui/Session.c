/*
 * CloneMC Java port scaffold: Session
 *
 * Java source: Session.java
 * Java type: class Session
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 0842288e7cb4b0c9e44a4d06f96f5ae58308e0a2661ebf54024181b0a8719654
 * Java lines: 60
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: Block, static
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static List registeredBlocksList
 * - public String username
 * - public String sessionId
 * - public String mpPassParameter
 *
 * Java method/constructor inventory:
 * - public Session(String s, String s1)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

static const int CloneMCJ_Session_RegisteredBlocks[28]={
    1,4,45,3,5,17,18,50,44,20,48,6,37,38,39,40,12,13,19,35,
    16,15,14,42,41,47,46,49
};

void CloneMCJ_Session_InitializeNative(CloneMCJ_SessionNative *session,
    const char *username,const char *sessionId)
{
    if(!session)return;
    memset(session,0,sizeof(*session));
    if(!username)username="";
    if(!sessionId)sessionId="";
    strncpy(session->username,username,sizeof(session->username)-1);
    strncpy(session->sessionId,sessionId,sizeof(session->sessionId)-1);
}

const int *CloneMCJ_Session_GetRegisteredBlocksNative(int *countOut)
{
    if(countOut)*countOut=(int)(sizeof(CloneMCJ_Session_RegisteredBlocks)/
        sizeof(CloneMCJ_Session_RegisteredBlocks[0]));
    return CloneMCJ_Session_RegisteredBlocks;
}

void CloneMCJ_Session_Register(void)
{
    /* Constructor and registeredBlocksList behavior are implemented above. */
}

const char *CloneMCJ_Session_JavaName(void)
{
    return "net.minecraft.src.Session";
}

const char *CloneMCJ_Session_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_Session_JavaSourceHash32(void)
{
    return 0x0842288EUL;
}
