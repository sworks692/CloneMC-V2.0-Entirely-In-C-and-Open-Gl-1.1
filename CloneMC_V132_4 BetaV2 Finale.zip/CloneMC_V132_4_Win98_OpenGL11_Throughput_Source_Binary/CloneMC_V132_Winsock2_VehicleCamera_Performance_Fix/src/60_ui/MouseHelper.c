/*
 * CloneMC Java port scaffold: MouseHelper
 *
 * Java source: MouseHelper.java
 * Java type: class MouseHelper
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 0dda1aa8d421501139775bb597d276254c4fac008080b96771a6fe169299a58f
 * Java lines: 62
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: GLAllocation, try, intbuffer1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Component field_1117_c
 * - private Cursor cursor
 * - public int deltaX
 * - public int deltaY
 * - private int field_1115_e
 *
 * Java method/constructor inventory:
 * - public MouseHelper(Component component)
 * - public void grabMouseCursor()
 * - public void ungrabMouseCursor()
 * - public void mouseXYChange()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"
#include <windows.h>
#include <string.h>

static void CloneMCMouseHelper_UpdateCenter(CloneMCMouseHelperState *mouse)
{
    HWND window;
    RECT client;
    POINT center;
    if (!mouse || !mouse->windowHandle) { return; }
    window = (HWND)mouse->windowHandle;
    if (!GetClientRect(window, &client)) { return; }
    center.x = (client.right - client.left) / 2;
    center.y = (client.bottom - client.top) / 2;
    if (!ClientToScreen(window, &center)) { return; }
    mouse->centerX = center.x;
    mouse->centerY = center.y;
}

void CloneMCJ_MouseHelper_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MouseHelper_JavaName(void)
{
    return "net.minecraft.src.MouseHelper";
}

const char *CloneMCJ_MouseHelper_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_MouseHelper_JavaSourceHash32(void)
{
    return 0x0DDA1AA8UL;
}

void CloneMCMouseHelper_Initialize(CloneMCMouseHelperState *mouse, void *windowHandle)
{
    if (!mouse) { return; }
    memset(mouse, 0, sizeof(*mouse));
    mouse->windowHandle = windowHandle;
    CloneMCMouseHelper_UpdateCenter(mouse);
}

void CloneMCMouseHelper_SetGrabbed(CloneMCMouseHelperState *mouse, int grabbed)
{
    HWND window;
    RECT client;
    POINT topLeft;
    POINT bottomRight;
    RECT clip;

    if (!mouse || !mouse->windowHandle) { return; }
    window = (HWND)mouse->windowHandle;
    grabbed = grabbed ? 1 : 0;
    if (mouse->grabbed == grabbed) { return; }
    mouse->grabbed = grabbed;
    mouse->deltaX = 0;
    mouse->deltaY = 0;

    if (grabbed) {
        SetCapture(window);
        if (GetClientRect(window, &client)) {
            topLeft.x = client.left; topLeft.y = client.top;
            bottomRight.x = client.right; bottomRight.y = client.bottom;
            ClientToScreen(window, &topLeft);
            ClientToScreen(window, &bottomRight);
            clip.left = topLeft.x; clip.top = topLeft.y;
            clip.right = bottomRight.x; clip.bottom = bottomRight.y;
            ClipCursor(&clip);
        }
        CloneMCMouseHelper_UpdateCenter(mouse);
        SetCursorPos(mouse->centerX, mouse->centerY);
        ShowCursor(FALSE);
    } else {
        ClipCursor((const RECT *)0);
        ReleaseCapture();
        ShowCursor(TRUE);
    }
}

void CloneMCMouseHelper_Update(CloneMCMouseHelperState *mouse, int active)
{
    POINT point;
    if (!mouse || !mouse->grabbed) { return; }
    if (!active) {
        CloneMCMouseHelper_SetGrabbed(mouse, 0);
        return;
    }
    CloneMCMouseHelper_UpdateCenter(mouse);
    if (!GetCursorPos(&point)) { return; }
    mouse->deltaX += point.x - mouse->centerX;
    mouse->deltaY += point.y - mouse->centerY;
    if (point.x != mouse->centerX || point.y != mouse->centerY) {
        SetCursorPos(mouse->centerX, mouse->centerY);
    }
}

void CloneMCMouseHelper_ConsumeDelta(CloneMCMouseHelperState *mouse, int *deltaX, int *deltaY)
{
    if (!mouse) { return; }
    if (deltaX) { *deltaX = mouse->deltaX; }
    if (deltaY) { *deltaY = mouse->deltaY; }
    mouse->deltaX = 0;
    mouse->deltaY = 0;
}

int CloneMCMouseHelper_GetClientPosition(const CloneMCMouseHelperState *mouse, int *x, int *y)
{
    HWND window;
    POINT point;
    if (!mouse || !mouse->windowHandle) { return 0; }
    window = (HWND)mouse->windowHandle;
    if (!GetCursorPos(&point) || !ScreenToClient(window, &point)) { return 0; }
    if (x) { *x = point.x; }
    if (y) { *y = point.y; }
    return 1;
}
