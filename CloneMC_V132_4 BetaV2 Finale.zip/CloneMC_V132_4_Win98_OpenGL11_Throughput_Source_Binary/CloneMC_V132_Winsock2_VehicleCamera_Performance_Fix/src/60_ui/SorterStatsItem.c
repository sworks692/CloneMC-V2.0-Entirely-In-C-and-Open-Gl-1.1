/*
 * CloneMC Java port scaffold: SorterStatsItem
 *
 * Java source: SorterStatsItem.java
 * Java type: class SorterStatsItem
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: bc01c1e0b9e787534bc356ce429109ea568516fcf31c260ead936e27d4bbda15
 * Java lines: 73
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: StatCrafting, GuiSlotStatsItem, StatList, GuiStats, StatFileWriter
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public int func_27371_a(StatCrafting statcrafting, StatCrafting statcrafting1)
 * - public int compare(Object obj, Object obj1)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_SorterStatsItem_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_SorterStatsItem_JavaName(void)
{
    return "net.minecraft.src.SorterStatsItem";
}

const char *CloneMCJ_SorterStatsItem_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_SorterStatsItem_JavaSourceHash32(void)
{
    return 0xBC01C1E0UL;
}
