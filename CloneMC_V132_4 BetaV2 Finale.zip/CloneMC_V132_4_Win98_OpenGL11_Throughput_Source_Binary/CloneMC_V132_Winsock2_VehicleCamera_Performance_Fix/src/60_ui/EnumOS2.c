/*
 * CloneMC Java port scaffold: EnumOS2
 *
 * Java source: EnumOS2.java
 * Java type: enum EnumOS2
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: d990de43a451be66dd593e8b1f6d96fb1fbd80e608813d777b79e18fcebafd08
 * Java lines: 53
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static final EnumOS2 field_6511_f[]
 *
 * Java method/constructor inventory:
 * - private EnumOS2(String s, int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_EnumOS2_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumOS2_JavaName(void)
{
    return "net.minecraft.src.EnumOS2";
}

const char *CloneMCJ_EnumOS2_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_EnumOS2_JavaSourceHash32(void)
{
    return 0xD990DE43UL;
}
