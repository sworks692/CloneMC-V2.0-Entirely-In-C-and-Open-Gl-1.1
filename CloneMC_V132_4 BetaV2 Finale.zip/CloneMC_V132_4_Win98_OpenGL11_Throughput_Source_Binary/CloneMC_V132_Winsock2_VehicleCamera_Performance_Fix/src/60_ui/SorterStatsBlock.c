/*
 * CloneMC Java port scaffold: SorterStatsBlock
 *
 * Java source: SorterStatsBlock.java
 * Java type: class SorterStatsBlock
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 3dfb2f21be887ba4c4508db3d26daf317e23f007aa4769e1d72d3a50d71b29ba
 * Java lines: 73
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: StatCrafting, GuiSlotStatsBlock, StatList, GuiStats, StatFileWriter
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public int func_27297_a(StatCrafting statcrafting, StatCrafting statcrafting1)
 * - public int compare(Object obj, Object obj1)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_SorterStatsBlock_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_SorterStatsBlock_JavaName(void)
{
    return "net.minecraft.src.SorterStatsBlock";
}

const char *CloneMCJ_SorterStatsBlock_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_SorterStatsBlock_JavaSourceHash32(void)
{
    return 0x3DFB2F21UL;
}
