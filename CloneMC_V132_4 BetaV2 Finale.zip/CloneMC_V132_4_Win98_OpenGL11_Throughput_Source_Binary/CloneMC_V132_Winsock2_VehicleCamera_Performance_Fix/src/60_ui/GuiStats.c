/* Native Beta statistics tabs, filtering, scrolling and stable sorting. */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

static int CloneMCJ_GuiStats_IsInTab(int statId,int tab)
{
    if(tab==0)return statId>=1000&&statId<3000;
    if(tab==1)return statId>=CLONEMC_J_STAT_MINE_BLOCK_BASE&&statId<CLONEMC_J_STAT_MINE_BLOCK_BASE+256;
    return (statId>=CLONEMC_J_STAT_CRAFT_ITEM_BASE&&statId<CLONEMC_J_STAT_CRAFT_ITEM_BASE+32000)||
        (statId>=CLONEMC_J_STAT_USE_ITEM_BASE&&statId<CLONEMC_J_STAT_USE_ITEM_BASE+32000)||
        (statId>=CLONEMC_J_STAT_BREAK_ITEM_BASE&&statId<CLONEMC_J_STAT_BREAK_ITEM_BASE+32000);
}

static int CloneMCJ_GuiStats_ComesBefore(CloneMCJ_GuiScreenState *screen,int idA,int valueA,int idB,int valueB)
{
    if(screen->statsSortColumn==1){if(valueA!=valueB)return screen->statsSortDescending?valueA>valueB:valueA<valueB;}
    return screen->statsSortDescending?idA>idB:idA<idB;
}

static void CloneMCJ_GuiStats_Sort(CloneMCJ_GuiScreenState *screen)
{
    int i,j,id,value;if(!screen)return;
    for(i=1;i<screen->statsCount;++i){id=screen->statsIds[i];value=screen->statsValues[i];j=i-1;
        while(j>=0&&!CloneMCJ_GuiStats_ComesBefore(screen,screen->statsIds[j],screen->statsValues[j],id,value)){
            screen->statsIds[j+1]=screen->statsIds[j];screen->statsValues[j+1]=screen->statsValues[j];--j;}
        screen->statsIds[j+1]=id;screen->statsValues[j+1]=value;
    }
}

void CloneMCJ_GuiStats_InitNative(CloneMCJ_GuiScreenState *screen)
{
    int width,height,scale,center;if(!screen)return;width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_STATS,CLONEMC_GUI_SCREEN_OPTIONS,scale);
    screen->width=width;screen->height=height;center=width/2;strcpy(screen->title,"Statistics");screen->message[0]='\0';
    screen->statsTab=0;screen->statsScroll=0;screen->statsSortColumn=1;screen->statsSortDescending=1;
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-154,44,100,20,"General");
    CloneMCJ_GuiScreen_AddButtonNative(screen,2,center-50,44,100,20,"Blocks");
    CloneMCJ_GuiScreen_AddButtonNative(screen,3,center+54,44,100,20,"Items");
    CloneMCJ_GuiScreen_AddButtonNative(screen,200,center-100,height-28,200,20,"Done");
}

void CloneMCJ_GuiStats_SetStatsNative(CloneMCJ_GuiScreenState *screen,const CloneMCJ_StatFileState *stats)
{
    int i,count,id,value;const CloneMCJ_StatDefinition *definition;
    if(!screen)return;count=0;
    if(screen->statsTab==0){
        for(i=0;i<CloneMCJ_StatList_GeneralCountNative()&&count<CLONEMC_GUI_STATS_CAPACITY;++i){
            definition=CloneMCJ_StatList_GetGeneralNative(i);if(!definition)continue;
            id=definition->statId;value=stats?CloneMCJ_StatFileWriter_GetNative(stats,id):0;
            screen->statsIds[count]=id;screen->statsValues[count]=value;++count;
        }
    }else if(stats){
        for(i=0;i<stats->count&&count<CLONEMC_GUI_STATS_CAPACITY;++i){id=stats->entries[i].statId;value=stats->entries[i].value;
            if(value!=0&&CloneMCJ_GuiStats_IsInTab(id,screen->statsTab)){screen->statsIds[count]=id;screen->statsValues[count]=value;++count;}}
    }
    screen->statsCount=count;CloneMCJ_GuiStats_Sort(screen);
    if(screen->statsScroll<0)screen->statsScroll=0;
    if(screen->statsScroll>screen->statsCount-CLONEMC_GUI_STATS_VISIBLE_ROWS)screen->statsScroll=screen->statsCount-CLONEMC_GUI_STATS_VISIBLE_ROWS;
    if(screen->statsScroll<0)screen->statsScroll=0;
}

void CloneMCJ_GuiStats_SelectTabNative(CloneMCJ_GuiScreenState *screen,int tab)
{if(!screen)return;if(tab<0)tab=0;if(tab>2)tab=2;screen->statsTab=tab;screen->statsScroll=0;}

void CloneMCJ_GuiStats_ScrollNative(CloneMCJ_GuiScreenState *screen,int amount)
{
    int maximum;if(!screen)return;maximum=screen->statsCount-CLONEMC_GUI_STATS_VISIBLE_ROWS;if(maximum<0)maximum=0;
    screen->statsScroll+=amount;if(screen->statsScroll<0)screen->statsScroll=0;if(screen->statsScroll>maximum)screen->statsScroll=maximum;
}

void CloneMCJ_GuiStats_Register(void){}
const char *CloneMCJ_GuiStats_JavaName(void){return "net.minecraft.src.GuiStats";}
const char *CloneMCJ_GuiStats_AssignedFolder(void){return "src/60_ui";}
unsigned long CloneMCJ_GuiStats_JavaSourceHash32(void){return 0x5154C202UL;}
