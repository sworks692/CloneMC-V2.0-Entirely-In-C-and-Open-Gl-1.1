/*
 * CloneMC Java port scaffold: GuiYesNo
 *
 * Java source: GuiYesNo.java
 * Java type: class GuiYesNo
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: b4bb073697287a6a1d83b87284e6a2fce1f9112c6c1e903ff60b20e1e45807a7
 * Java lines: 51
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: GuiScreen, GuiSmallButton, GuiButton, message1, message2, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private GuiScreen parentScreen
 * - private String message1
 * - private String message2
 * - private String field_22106_k
 * - private String field_22105_l
 * - private int worldNumber
 *
 * Java method/constructor inventory:
 * - public GuiYesNo(GuiScreen guiscreen, String s, String s1, String s2, String s3, int i)
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiYesNo_InitNative(CloneMCJ_GuiScreenState *screen,const char *title,const char *message)
{
    int width,height,scale,center;if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_YES_NO,
        CLONEMC_GUI_SCREEN_SELECT_WORLD,scale);screen->width=width;screen->height=height;
    center=width/2;if(!title)title="Are you sure?";if(!message)message="This cannot be undone.";
    strncpy(screen->title,title,sizeof(screen->title)-1);screen->title[sizeof(screen->title)-1]='\0';
    strncpy(screen->message,message,sizeof(screen->message)-1);screen->message[sizeof(screen->message)-1]='\0';
    CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-155,height/6+96,150,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.deleteButton"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center+5,height/6+96,150,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("gui.cancel"));
}

void CloneMCJ_GuiYesNo_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiYesNo_JavaName(void)
{
    return "net.minecraft.src.GuiYesNo";
}

const char *CloneMCJ_GuiYesNo_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiYesNo_JavaSourceHash32(void)
{
    return 0xB4BB0736UL;
}
