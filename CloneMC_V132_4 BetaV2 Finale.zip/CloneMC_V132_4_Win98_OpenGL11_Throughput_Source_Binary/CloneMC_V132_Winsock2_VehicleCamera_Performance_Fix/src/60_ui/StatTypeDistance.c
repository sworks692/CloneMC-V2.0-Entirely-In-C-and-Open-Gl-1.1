/*
 * CloneMC Java port scaffold: StatTypeDistance
 *
 * Java source: StatTypeDistance.java
 * Java type: class StatTypeDistance
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 4d25b51e726a3d3993f4ce0a8353ab63dd89936e70a93a8ddc9db04cf2d51e14
 * Java lines: 38
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: IStatType, StatBase
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public String func_27192_a(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_StatTypeDistance_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_StatTypeDistance_JavaName(void)
{
    return "net.minecraft.src.StatTypeDistance";
}

const char *CloneMCJ_StatTypeDistance_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_StatTypeDistance_JavaSourceHash32(void)
{
    return 0x4D25B51EUL;
}
