/*
 * CloneMC Java port scaffold: GuiGameOver
 *
 * Java source: GuiGameOver.java
 * Java type: class GuiGameOver
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 033bac623a6d585b19dba22dcc9724e1d69e430df496992190ec429551dfda57
 * Java lines: 67
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: GuiScreen, GuiButton, EntityPlayerSP, GuiMainMenu, width, height, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GuiGameOver()
 * - public void initGui()
 * - protected void keyTyped(char c, int i)
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 * - public boolean doesGuiPauseGame()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <string.h>

void CloneMCJ_GuiGameOver_InitNative(CloneMCJ_GuiScreenState *screen,int score)
{
    int width,height,scale,center;if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_GAME_OVER,
        CLONEMC_GUI_SCREEN_NONE,scale);screen->width=width;screen->height=height;
    center=width/2;strcpy(screen->title,"Game over!");sprintf(screen->message,"Score: %d",score);
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,height/4+72,200,20,"Respawn");
    CloneMCJ_GuiScreen_AddButtonNative(screen,2,center-100,height/4+96,200,20,"Title menu");
}

void CloneMCJ_GuiGameOver_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiGameOver_JavaName(void)
{
    return "net.minecraft.src.GuiGameOver";
}

const char *CloneMCJ_GuiGameOver_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiGameOver_JavaSourceHash32(void)
{
    return 0x033BAC62UL;
}
