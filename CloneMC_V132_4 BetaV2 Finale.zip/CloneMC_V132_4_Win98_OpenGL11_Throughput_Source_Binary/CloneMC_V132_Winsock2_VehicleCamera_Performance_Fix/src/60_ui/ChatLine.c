/*
 * CloneMC Java port scaffold: ChatLine
 *
 * Java source: ChatLine.java
 * Java type: class ChatLine
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: fb5a2f64dff94ac4b1d5aacc4b16aac4007e24b62c449e44fa8c7c7b28333523
 * Java lines: 20
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public String message
 * - public int updateCounter
 *
 * Java method/constructor inventory:
 * - public ChatLine(String s)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_ChatLine_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChatLine_JavaName(void)
{
    return "net.minecraft.src.ChatLine";
}

const char *CloneMCJ_ChatLine_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_ChatLine_JavaSourceHash32(void)
{
    return 0xFB5A2F64UL;
}
