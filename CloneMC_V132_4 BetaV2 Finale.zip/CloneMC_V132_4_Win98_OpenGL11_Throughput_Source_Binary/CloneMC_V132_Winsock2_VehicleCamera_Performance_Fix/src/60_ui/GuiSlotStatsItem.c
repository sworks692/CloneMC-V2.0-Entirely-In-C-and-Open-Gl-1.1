/*
 * CloneMC Java port scaffold: GuiSlotStatsItem
 *
 * Java source: GuiSlotStatsItem.java
 * Java type: class GuiSlotStatsItem
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 3026373d88786e7a88fb546d51786459e6dd122b1803bc6434928e844f742a17
 * Java lines: 104
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: GuiSlotStats, StatList, StatCrafting, GuiStats, StatFileWriter, SorterStatsItem, Tessellator, do, j, GuiS
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GuiSlotStatsItem(GuiStats guistats)
 * - protected void func_27260_a(int i, int j, Tessellator tessellator)
 * - protected void drawSlot(int i, int j, int k, int l, Tessellator tessellator)
 * - protected String func_27263_a(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

const char *CloneMCJ_GuiSlotStatsItem_LabelNative(int column)
{return column==1?"Crafted":column==2?"Used":"Depleted";}

void CloneMCJ_GuiSlotStatsItem_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiSlotStatsItem_JavaName(void)
{
    return "net.minecraft.src.GuiSlotStatsItem";
}

const char *CloneMCJ_GuiSlotStatsItem_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiSlotStatsItem_JavaSourceHash32(void)
{
    return 0x3026373DUL;
}
