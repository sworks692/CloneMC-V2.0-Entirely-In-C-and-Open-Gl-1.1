/*
 * CloneMC Java port scaffold: CanvasMojangLogo
 *
 * Java source: CanvasMojangLogo.java
 * Java type: class CanvasMojangLogo
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: e46f62af6f60a916379968a5e0747c45040e44360b4bda60f8eaeaf13c0c0c18
 * Java lines: 38
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: PanelCrashReport, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private BufferedImage logo
 *
 * Java method/constructor inventory:
 * - public CanvasMojangLogo()
 * - public void paint(Graphics g)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_CanvasMojangLogo_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_CanvasMojangLogo_JavaName(void)
{
    return "net.minecraft.src.CanvasMojangLogo";
}

const char *CloneMCJ_CanvasMojangLogo_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_CanvasMojangLogo_JavaSourceHash32(void)
{
    return 0xE46F62AFUL;
}
