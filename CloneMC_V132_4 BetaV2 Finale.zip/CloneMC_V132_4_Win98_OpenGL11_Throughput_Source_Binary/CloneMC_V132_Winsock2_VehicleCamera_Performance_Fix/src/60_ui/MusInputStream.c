/*
 * CloneMC Java port scaffold: MusInputStream
 *
 * Java source: MusInputStream.java
 * Java type: class MusInputStream
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 0a6718dbdb505b35fd7dfa5fbe3758e3ab999825bfc6a6da84cd8f1aa1b52920
 * Java lines: 62
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: CodecMus, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int hash
 * - private InputStream inputStream
 *
 * Java method/constructor inventory:
 * - public MusInputStream(CodecMus codecmus, URL url, InputStream inputstream)
 * - public int read()
 * - public int read(byte abyte0[], int i, int j)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_MusInputStream_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MusInputStream_JavaName(void)
{
    return "net.minecraft.src.MusInputStream";
}

const char *CloneMCJ_MusInputStream_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_MusInputStream_JavaSourceHash32(void)
{
    return 0x0A6718DBUL;
}
