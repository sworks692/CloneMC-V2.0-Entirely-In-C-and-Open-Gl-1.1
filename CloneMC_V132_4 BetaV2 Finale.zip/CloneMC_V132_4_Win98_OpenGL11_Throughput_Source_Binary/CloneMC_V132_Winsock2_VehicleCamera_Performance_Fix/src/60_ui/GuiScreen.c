/*
 * CloneMC Java port scaffold: GuiScreen
 *
 * Java source: GuiScreen.java
 * Java type: class GuiScreen
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: Gui
 * Implements: (none declared)
 * Source SHA-256: b5cbe4e22902f61ae4c5b44b130e0db2d9d6011c52bd5ee6f12f42e53ca9627a
 * Java lines: 205
 * Discovered declared fields: 8
 * Discovered declared methods/constructors: 20
 * Referenced Java classes: Gui, GuiButton, SoundManager, GuiParticle, Tessellator, RenderEngine, FontRenderer, i, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected Minecraft mc
 * - public int width
 * - public int height
 * - protected List controlList
 * - public boolean field_948_f
 * - protected FontRenderer fontRenderer
 * - public GuiParticle field_25091_h
 * - private GuiButton selectedButton
 *
 * Java method/constructor inventory:
 * - public GuiScreen()
 * - public void drawScreen(int i, int j, float f)
 * - protected void keyTyped(char c, int i)
 * - public static String getClipboardString()
 * - protected void mouseClicked(int i, int j, int k)
 * - protected void mouseMovedOrUp(int i, int j, int k)
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void setWorldAndResolution(Minecraft minecraft, int i, int j)
 * - public void initGui()
 * - public void handleInput()
 * - public void handleMouseInput()
 * - public void handleKeyboardInput()
 * - public void updateScreen()
 * - public void onGuiClosed()
 * - public void drawDefaultBackground()
 * - public void drawWorldBackground(int i)
 * - public void drawBackground(int i)
 * - public boolean doesGuiPauseGame()
 * - public void deleteWorld(boolean flag, int i)
 * - public void selectNextField()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiScreen_InitializeNative(CloneMCJ_GuiScreenState *screen,
    int screenType,int parentType,int scaleFactor)
{
    if(!screen)return;
    memset(screen,0,sizeof(*screen));
    screen->screenType=screenType;screen->parentType=parentType;
    screen->scaleFactor=scaleFactor>0?scaleFactor:1;
    screen->selectedButton=-1;screen->selectedWorld=-1;
    screen->keyBindingCapture=-1;screen->loadingProgress=-1;
}

void CloneMCJ_GuiScreen_SetResolutionNative(CloneMCJ_GuiScreenState *screen,
    int width,int height,int scaleFactor)
{
    if(!screen)return;
    if(scaleFactor<1)scaleFactor=1;
    if(width<1)width=1;
    if(height<1)height=1;
    screen->scaleFactor=scaleFactor;
    screen->width=(width+scaleFactor-1)/scaleFactor;
    screen->height=(height+scaleFactor-1)/scaleFactor;
}

CloneMCJ_GuiButtonNative *CloneMCJ_GuiScreen_AddButtonNative(CloneMCJ_GuiScreenState *screen,
    int id,int x,int y,int width,int height,const char *label)
{
    CloneMCJ_GuiButtonNative *button;
    if(!screen||screen->buttonCount>=CLONEMC_GUI_MAX_BUTTONS)return 0;
    button=&screen->buttons[screen->buttonCount++];
    CloneMCJ_GuiButton_InitializeNative(button,id,x,y,width,height,label);
    return button;
}

int CloneMCJ_GuiScreen_MouseClickedNative(CloneMCJ_GuiScreenState *screen,int mouseX,int mouseY)
{
    int i;
    if(!screen)return -1;
    screen->mouseX=mouseX;screen->mouseY=mouseY;screen->selectedButton=-1;
    for(i=0;i<screen->buttonCount;++i){
        if(CloneMCJ_GuiButton_MousePressedNative(&screen->buttons[i],mouseX,mouseY)){
            screen->selectedButton=i;
            screen->buttons[i].dragging=screen->buttons[i].slider;
            return screen->buttons[i].id;
        }
    }
    if(screen->screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD){
        if(mouseX>=screen->width/2-100&&mouseX<screen->width/2+100){
            if(mouseY>=60&&mouseY<80)screen->textFocused=1;
            else if(mouseY>=116&&mouseY<136)screen->textFocused=2;
        }
    }else if(screen->screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER){
        int usernameY;
        int serverY;
        usernameY=screen->height/4+28;
        serverY=screen->height/4+58;
        if(mouseX>=screen->width/2-100&&mouseX<screen->width/2+100){
            if(mouseY>=usernameY&&mouseY<usernameY+20)screen->textFocused=1;
            else if(mouseY>=serverY&&mouseY<serverY+20)screen->textFocused=2;
        }
    }
    return -1;
}

void CloneMCJ_GuiScreen_ReleaseMouseNative(CloneMCJ_GuiScreenState *screen)
{
    int index;
    if(!screen)return;
    for(index=0;index<screen->buttonCount&&index<CLONEMC_GUI_MAX_BUTTONS;++index){
        screen->buttons[index].dragging=0;
        screen->buttons[index].hovered=0;
    }
    screen->selectedButton=-1;
}

int CloneMCJ_GuiScreen_KeyTypedNative(CloneMCJ_GuiScreenState *screen,int character)
{
    char *field;
    unsigned long maximum;
    unsigned long length;
    if(!screen||!screen->textFocused)return 0;
    if(character==9&&(screen->screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD||
       screen->screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER)){
        screen->textFocused=screen->textFocused==1?2:1;return 1;
    }
    field=screen->textFocused==2?screen->textFieldSecondary:screen->textField;
    maximum=sizeof(screen->textField)-1;
    if(screen->screenType==CLONEMC_GUI_SCREEN_CREATE_WORLD&&screen->textFocused==1)
        maximum=32;
    else if(screen->screenType==CLONEMC_GUI_SCREEN_RENAME_WORLD)maximum=32;
    else if(screen->screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER&&
            screen->textFocused==1)maximum=16;
    length=(unsigned long)strlen(field);
    if(character==8){if(length)field[length-1]='\0';return 1;}
    if(screen->screenType==CLONEMC_GUI_SCREEN_MULTIPLAYER&&
       screen->textFocused==1&&!((character>='0'&&character<='9')||
       (character>='A'&&character<='Z')||(character>='a'&&character<='z')||
       character=='_'))return 0;
    if(character>=32&&character<=126&&length<maximum){
        field[length]=(char)character;field[length+1]='\0';return 1;
    }
    return 0;
}

/*
 * Native GUI state is long-lived across WM_SIZE, world selection and the
 * return-to-title transition.  Java's ArrayList/String objects enforce these
 * bounds implicitly; the C port has fixed arrays, so validate them at the same
 * boundary at which Minecraft.displayGuiScreen installs a screen.  Besides
 * making malformed save labels harmless, this prevents a damaged button count
 * from walking beyond the screen object during the phase-10 title loop.
 */
int CloneMCJ_GuiScreen_ValidateNative(CloneMCJ_GuiScreenState *screen)
{
    int valid;
    int index;
    if(!screen)return 0;
    valid=1;
    if(screen->width<1){screen->width=1;valid=0;}
    if(screen->height<1){screen->height=1;valid=0;}
    if(screen->scaleFactor<1){screen->scaleFactor=1;valid=0;}
    if(screen->screenType<CLONEMC_GUI_SCREEN_NONE||
       screen->screenType>CLONEMC_GUI_SCREEN_CONFLICT){
        screen->screenType=CLONEMC_GUI_SCREEN_MAIN_MENU;valid=0;
    }
    if(screen->buttonCount<0){screen->buttonCount=0;valid=0;}
    if(screen->buttonCount>CLONEMC_GUI_MAX_BUTTONS){
        screen->buttonCount=CLONEMC_GUI_MAX_BUTTONS;valid=0;
    }
    if(screen->worldCount<0){screen->worldCount=0;valid=0;}
    if(screen->worldCount>CLONEMC_GUI_MAX_WORLDS){
        screen->worldCount=CLONEMC_GUI_MAX_WORLDS;valid=0;
    }
    if(screen->selectedButton>=screen->buttonCount){screen->selectedButton=-1;valid=0;}
    if(screen->selectedWorld>=screen->worldCount){screen->selectedWorld=-1;valid=0;}
    screen->title[sizeof(screen->title)-1]='\0';
    screen->message[sizeof(screen->message)-1]='\0';
    screen->textField[sizeof(screen->textField)-1]='\0';
    screen->textFieldSecondary[sizeof(screen->textFieldSecondary)-1]='\0';
    screen->folderName[sizeof(screen->folderName)-1]='\0';
    for(index=0;index<screen->buttonCount;++index){
        CloneMCJ_GuiButtonNative *button;
        button=&screen->buttons[index];
        button->displayString[sizeof(button->displayString)-1]='\0';
        if(button->width<1){button->width=1;valid=0;}
        if(button->height<1){button->height=1;valid=0;}
        if(button->sliderValue<0.0F){button->sliderValue=0.0F;valid=0;}
        if(button->sliderValue>1.0F){button->sliderValue=1.0F;valid=0;}
    }
    for(index=0;index<screen->worldCount;++index){
        screen->worlds[index].fileName[sizeof(screen->worlds[index].fileName)-1]='\0';
        screen->worlds[index].displayName[sizeof(screen->worlds[index].displayName)-1]='\0';
    }
    return valid;
}

void CloneMCJ_GuiScreen_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiScreen_JavaName(void)
{
    return "net.minecraft.src.GuiScreen";
}

const char *CloneMCJ_GuiScreen_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiScreen_JavaSourceHash32(void)
{
    return 0xB5CBE4E2UL;
}
