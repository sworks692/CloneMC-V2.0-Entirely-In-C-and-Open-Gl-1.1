/*
 * CloneMC Java port scaffold: GuiConnecting
 *
 * Java source: GuiConnecting.java
 * Java type: class GuiConnecting
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 52d7b198e6b83ea86e807056a7b8193779202911e9f07e9a883ee5f48618988b
 * Java lines: 92
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: GuiScreen, ThreadConnectToServer, NetClientHandler, StringTranslate, GuiButton, GuiMainMenu, minecraft, s, drawCe
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private NetClientHandler clientHandler
 * - private boolean cancelled
 *
 * Java method/constructor inventory:
 * - public GuiConnecting(Minecraft minecraft, String s, int i)
 * - public void updateScreen()
 * - protected void keyTyped(char c, int i)
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiConnecting_InitNative(CloneMCJ_GuiScreenState *screen,const char *server)
{
    int width,height,scale;if(!screen)return;width=screen->width;height=screen->height;
    scale=screen->scaleFactor;CloneMCJ_GuiScreen_InitializeNative(screen,
        CLONEMC_GUI_SCREEN_CONNECTING,CLONEMC_GUI_SCREEN_MULTIPLAYER,scale);
    screen->width=width;screen->height=height;strcpy(screen->title,"Connecting to the server...");
    if(!server)server="";
    strncpy(screen->message,server,sizeof(screen->message)-1);
    screen->message[sizeof(screen->message)-1]='\0';
}

void CloneMCJ_GuiConnecting_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiConnecting_JavaName(void)
{
    return "net.minecraft.src.GuiConnecting";
}

const char *CloneMCJ_GuiConnecting_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiConnecting_JavaSourceHash32(void)
{
    return 0x52D7B198UL;
}
