/*
 * CloneMC Java port scaffold: IProgressUpdate
 *
 * Java source: IProgressUpdate.java
 * Java type: interface IProgressUpdate
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 9bbb4ad9dd4baf421d9c8d0bd7af90c976d012694f7019201adf8b665f2bf36e
 * Java lines: 17
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract void func_594_b(String s)
 * - public abstract void displayLoadingString(String s)
 * - public abstract void setLoadingProgress(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_IProgressUpdate_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_IProgressUpdate_JavaName(void)
{
    return "net.minecraft.src.IProgressUpdate";
}

const char *CloneMCJ_IProgressUpdate_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_IProgressUpdate_JavaSourceHash32(void)
{
    return 0x9BBB4AD9UL;
}
