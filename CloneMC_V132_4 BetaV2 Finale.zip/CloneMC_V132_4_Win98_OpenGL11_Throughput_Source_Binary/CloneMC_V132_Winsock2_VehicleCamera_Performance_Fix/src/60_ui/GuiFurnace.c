/*
 * CloneMC Java port scaffold: GuiFurnace
 *
 * Java source: GuiFurnace.java
 * Java type: class GuiFurnace
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiContainer
 * Implements: (none declared)
 * Source SHA-256: 3bf110248a939c0467daf7b150c0619ea1c13fce608ac41a1f4bc0a5132ff25f
 * Java lines: 48
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: GuiContainer, ContainerFurnace, FontRenderer, RenderEngine, TileEntityFurnace, InventoryPlayer, k, xSize
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private TileEntityFurnace furnaceInventory
 *
 * Java method/constructor inventory:
 * - public GuiFurnace(InventoryPlayer inventoryplayer, TileEntityFurnace tileentityfurnace)
 * - protected void drawGuiContainerForegroundLayer()
 * - protected void drawGuiContainerBackgroundLayer(float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiFurnace_LayoutNative(CloneMCJ_GuiContainerLayout *layout)
{
    if(!layout)return;
    memset(layout,0,sizeof(*layout));strcpy(layout->title,"Furnace");
    layout->xSize=176;layout->ySize=166;layout->rows=1;layout->columns=3;layout->textureKind=4;
}

void CloneMCJ_GuiFurnace_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiFurnace_JavaName(void)
{
    return "net.minecraft.src.GuiFurnace";
}

const char *CloneMCJ_GuiFurnace_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiFurnace_JavaSourceHash32(void)
{
    return 0x3BF11024UL;
}
