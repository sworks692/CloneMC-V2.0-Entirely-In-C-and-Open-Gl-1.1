/*
 * CloneMC Java port scaffold: ThreadDownloadResources
 *
 * Java source: ThreadDownloadResources.java
 * Java type: class ThreadDownloadResources
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: Thread
 * Implements: (none declared)
 * Source SHA-256: 32e0b2573624e5b90a25f77f8778a9595021173a7d589fc2696374f2b8d602ba
 * Java lines: 166
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public File resourcesFolder
 * - private Minecraft mc
 * - private boolean closing
 *
 * Java method/constructor inventory:
 * - public ThreadDownloadResources(File file, Minecraft minecraft)
 * - public void run()
 * - public void reloadResources()
 * - private void loadResource(File file, String s)
 * - private void downloadAndInstallResource(URL url, String s, long l, int i)
 * - private void downloadResource(URL url, File file, long l)
 * - public void closeMinecraft()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_ThreadDownloadResources_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ThreadDownloadResources_JavaName(void)
{
    return "net.minecraft.src.ThreadDownloadResources";
}

const char *CloneMCJ_ThreadDownloadResources_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_ThreadDownloadResources_JavaSourceHash32(void)
{
    return 0x32E0B257UL;
}
