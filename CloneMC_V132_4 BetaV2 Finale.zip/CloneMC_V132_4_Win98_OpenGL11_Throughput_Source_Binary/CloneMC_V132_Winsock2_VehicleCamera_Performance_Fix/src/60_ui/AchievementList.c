/* Direct C89 port of Beta AchievementList.java. */
#include "clonemc_java_port_60_ui.h"

static const CloneMCJ_AchievementDefinition g_cloneMCAchievements[CLONEMC_J_ACHIEVEMENT_COUNT] = {
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+0,"openInventory","Taking Inventory","Press 'E' to open your inventory.",0,0,-1,340,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+1,"mineWood","Getting Wood","Attack a tree until a block of wood pops out",2,1,0,17,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+2,"buildWorkBench","Benchmarking","Craft a workbench with four blocks of planks",4,-1,1,58,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+3,"buildPickaxe","Time to Mine!","Use planks and sticks to make a pickaxe",4,2,2,270,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+4,"buildFurnace","Hot Topic","Construct a furnace out of eight stone blocks",3,4,3,62,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+5,"acquireIron","Acquire Hardware","Smelt an iron ingot",1,4,4,265,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+6,"buildHoe","Time to Farm!","Use planks and sticks to make a hoe",2,-3,2,290,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+7,"makeBread","Bake Bread","Turn wheat into bread",-1,-3,6,297,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+8,"bakeCake","The Lie","Wheat, sugar, milk and eggs!",0,-5,6,354,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+9,"buildBetterPickaxe","Getting an Upgrade","Construct a better pickaxe",6,2,3,274,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+10,"cookFish","Delicious Fish","Catch and cook fish!",2,6,4,350,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+11,"onARail","On A Rail","Travel by minecart at least 1 km from where you started",2,3,5,66,1},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+12,"buildSword","Time to Strike!","Use planks and sticks to make a sword",6,-1,2,268,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+13,"killEnemy","Monster Hunter","Attack and destroy a monster",8,-1,12,352,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+14,"killCow","Cow Tipper","Harvest some leather",7,-3,12,334,0},
    {CLONEMC_J_ACHIEVEMENT_STAT_BASE+15,"flyPig","When Pigs Fly","Fly a pig off a cliff",8,-4,14,329,1}
};

const CloneMCJ_AchievementDefinition *CloneMCJ_AchievementList_GetNative(int index)
{
    if(index<0||index>=CLONEMC_J_ACHIEVEMENT_COUNT)return 0;
    return &g_cloneMCAchievements[index];
}

int CloneMCJ_AchievementList_CountNative(void)
{return CLONEMC_J_ACHIEVEMENT_COUNT;}

void CloneMCJ_AchievementList_Register(void){}
const char *CloneMCJ_AchievementList_JavaName(void){return "net.minecraft.src.AchievementList";}
const char *CloneMCJ_AchievementList_AssignedFolder(void){return "src/60_ui";}
unsigned long CloneMCJ_AchievementList_JavaSourceHash32(void){return 0x95D5556DUL;}
