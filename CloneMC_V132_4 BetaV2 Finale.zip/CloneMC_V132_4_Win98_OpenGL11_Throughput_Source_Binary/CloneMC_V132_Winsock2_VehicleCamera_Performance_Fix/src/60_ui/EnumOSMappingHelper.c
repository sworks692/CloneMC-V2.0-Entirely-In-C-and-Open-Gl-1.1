/*
 * CloneMC Java port scaffold: EnumOSMappingHelper
 *
 * Java source: EnumOSMappingHelper.java
 * Java type: class EnumOSMappingHelper
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 82b4a2f438fcb6b2d69585fecd151a1122202bea7f2e9fd4e4111a82c6c2441c
 * Java lines: 41
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: EnumOS2, static, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static final int enumOSMappingArray[]
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_EnumOSMappingHelper_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumOSMappingHelper_JavaName(void)
{
    return "net.minecraft.src.EnumOSMappingHelper";
}

const char *CloneMCJ_EnumOSMappingHelper_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_EnumOSMappingHelper_JavaSourceHash32(void)
{
    return 0x82B4A2F4UL;
}
