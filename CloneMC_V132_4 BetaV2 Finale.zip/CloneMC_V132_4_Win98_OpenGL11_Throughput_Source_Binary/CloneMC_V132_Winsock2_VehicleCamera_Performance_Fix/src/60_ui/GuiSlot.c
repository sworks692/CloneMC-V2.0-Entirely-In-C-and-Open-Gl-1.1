/*
 * CloneMC Java port scaffold: GuiSlot
 *
 * Java source: GuiSlot.java
 * Java type: class GuiSlot
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 937726b3e5611ea117503e78ccf8251483f6706a9850c65a2f0cf9c08df0629f
 * Java lines: 362
 * Discovered declared fields: 18
 * Discovered declared methods/constructors: 18
 * Referenced Java classes: GuiButton, Tessellator, RenderEngine
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final Minecraft mc
 * - private final int width
 * - private final int height
 * - protected final int top
 * - protected final int bottom
 * - private final int right
 * - private final int left = 0
 * - protected final int posZ
 * - private int scrollUpButtonID
 * - private int scrollDownButtonID
 * - private float initialClickY
 * - private float scrollMultiplier
 * - private float amountScrolled
 * - private int selectedElement
 * - private long lastClicked
 * - private boolean field_25123_p
 * - private boolean field_27262_q
 * - private int field_27261_r
 *
 * Java method/constructor inventory:
 * - public GuiSlot(Minecraft minecraft, int i, int j, int k, int l, int i1)
 * - public void func_27258_a(boolean flag)
 * - protected void func_27259_a(boolean flag, int i)
 * - protected abstract int getSize()
 * - protected abstract void elementClicked(int i, boolean flag)
 * - protected abstract boolean isSelected(int i)
 * - protected int getContentHeight()
 * - protected abstract void drawBackground()
 * - protected abstract void drawSlot(int i, int j, int k, int l, Tessellator tessellator)
 * - protected void func_27260_a(int i, int j, Tessellator tessellator)
 * - protected void func_27255_a(int i, int j)
 * - protected void func_27257_b(int i, int j)
 * - public int func_27256_c(int i, int j)
 * - public void registerScrollButtons(List list, int i, int j)
 * - private void bindAmountScrolled()
 * - public void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 * - private void overlayBackground(int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiSlot_InitializeNative(CloneMCJ_GuiSlotState *slot,int width,int height,
    int top,int bottom,int slotHeight,int count)
{if(!slot)return;memset(slot,0,sizeof(*slot));slot->width=width;slot->height=height;
 slot->top=top;slot->bottom=bottom;slot->slotHeight=slotHeight;slot->itemCount=count;slot->selectedIndex=-1;}

void CloneMCJ_GuiSlot_ScrollNative(CloneMCJ_GuiSlotState *slot,int amount)
{
    int maximum;if(!slot)return;maximum=slot->itemCount*slot->slotHeight-(slot->bottom-slot->top-4);
    if(maximum<0)maximum=0;
    slot->amountScrolled+=(float)amount;
    if(slot->amountScrolled<0)slot->amountScrolled=0;
    if(slot->amountScrolled>(float)maximum)slot->amountScrolled=(float)maximum;
}

int CloneMCJ_GuiSlot_IndexAtNative(const CloneMCJ_GuiSlotState *slot,int mouseX,int mouseY)
{
    int left,index;if(!slot||mouseY<slot->top||mouseY>slot->bottom)return -1;
    left=slot->width/2-110;if(mouseX<left||mouseX>left+220)return -1;
    index=(mouseY-slot->top+(int)slot->amountScrolled-4)/slot->slotHeight;
    return index>=0&&index<slot->itemCount?index:-1;
}

void CloneMCJ_GuiSlot_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiSlot_JavaName(void)
{
    return "net.minecraft.src.GuiSlot";
}

const char *CloneMCJ_GuiSlot_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiSlot_JavaSourceHash32(void)
{
    return 0x937726B3UL;
}
