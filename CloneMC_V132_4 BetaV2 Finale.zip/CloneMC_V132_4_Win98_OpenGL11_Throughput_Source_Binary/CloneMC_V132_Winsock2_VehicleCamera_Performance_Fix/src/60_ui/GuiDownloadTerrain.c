/*
 * CloneMC Java port scaffold: GuiDownloadTerrain
 *
 * Java source: GuiDownloadTerrain.java
 * Java type: class GuiDownloadTerrain
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 092825720667b44c199390a492f19fa0ff77442fbf1605ac0956aae8f2e01881
 * Java lines: 59
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: GuiScreen, Packet0KeepAlive, NetClientHandler, StringTranslate, GuiButton, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private NetClientHandler netHandler
 * - private int updateCounter
 *
 * Java method/constructor inventory:
 * - public GuiDownloadTerrain(NetClientHandler netclienthandler)
 * - protected void keyTyped(char c, int i)
 * - public void initGui()
 * - public void updateScreen()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiDownloadTerrain_InitNative(CloneMCJ_GuiScreenState *screen)
{
    int width,height,scale;if(!screen)return;width=screen->width;height=screen->height;
    scale=screen->scaleFactor;CloneMCJ_GuiScreen_InitializeNative(screen,
        CLONEMC_GUI_SCREEN_DOWNLOAD_TERRAIN,CLONEMC_GUI_SCREEN_NONE,scale);
    screen->width=width;screen->height=height;strcpy(screen->title,"Downloading terrain");
    strcpy(screen->message,"Building terrain...");
}

void CloneMCJ_GuiDownloadTerrain_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiDownloadTerrain_JavaName(void)
{
    return "net.minecraft.src.GuiDownloadTerrain";
}

const char *CloneMCJ_GuiDownloadTerrain_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiDownloadTerrain_JavaSourceHash32(void)
{
    return 0x09282572UL;
}
