/*
 * CloneMC Java port scaffold: StringTranslate
 *
 * Java source: StringTranslate.java
 * Java type: class StringTranslate
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: e0f2d0192c303a789cdf1a06c16b13d90144177966c6e89a59bf4368da09967a
 * Java lines: 52
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Properties translateTable
 *
 * Java method/constructor inventory:
 * - private StringTranslate()
 * - public static StringTranslate getInstance()
 * - public String translateKey(String s)
 * - public String translateKeyFormat(String s, Object aobj[])
 * - public String translateNamedKey(String s)
 * - private static StringTranslate instance = new StringTranslate()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <string.h>

#define CLONEMC_TRANSLATION_CAPACITY 768
typedef struct CloneMCJ_TranslationEntryTag {
    char key[96];
    char value[256];
} CloneMCJ_TranslationEntry;

static CloneMCJ_TranslationEntry CloneMCJ_Translations[CLONEMC_TRANSLATION_CAPACITY];
static int CloneMCJ_TranslationCount;

static char *CloneMCJ_StringTranslate_TrimLine(char *text)
{
    char *end;
    while (*text == ' ' || *text == '\t') ++text;
    end = text + strlen(text);
    while (end > text && (end[-1] == '\r' || end[-1] == '\n' ||
        end[-1] == ' ' || end[-1] == '\t')) --end;
    *end = '\0';
    return text;
}

static int CloneMCJ_StringTranslate_Find(const char *key)
{
    int index;
    if (!key) return -1;
    for (index = 0; index < CloneMCJ_TranslationCount; ++index) {
        if (!strcmp(CloneMCJ_Translations[index].key, key)) return index;
    }
    return -1;
}

static int CloneMCJ_StringTranslate_LoadFile(const char *path)
{
    FILE *file;
    char line[512];
    char *key;
    char *value;
    char *equals;
    int index;
    if (!path) return 0;
    file = fopen(path, "rt");
    if (!file) return 0;
    while (fgets(line, sizeof(line), file)) {
        key = CloneMCJ_StringTranslate_TrimLine(line);
        if (!*key || *key == '#' || *key == '!') continue;
        equals = strchr(key, '=');
        if (!equals) continue;
        *equals = '\0';
        value = CloneMCJ_StringTranslate_TrimLine(equals + 1);
        key = CloneMCJ_StringTranslate_TrimLine(key);
        index = CloneMCJ_StringTranslate_Find(key);
        if (index < 0) {
            if (CloneMCJ_TranslationCount >= CLONEMC_TRANSLATION_CAPACITY) continue;
            index = CloneMCJ_TranslationCount++;
        }
        strncpy(CloneMCJ_Translations[index].key, key,
            sizeof(CloneMCJ_Translations[index].key) - 1);
        CloneMCJ_Translations[index].key[
            sizeof(CloneMCJ_Translations[index].key) - 1] = '\0';
        strncpy(CloneMCJ_Translations[index].value, value,
            sizeof(CloneMCJ_Translations[index].value) - 1);
        CloneMCJ_Translations[index].value[
            sizeof(CloneMCJ_Translations[index].value) - 1] = '\0';
    }
    fclose(file);
    return 1;
}

int CloneMCJ_StringTranslate_InitializeNative(const char *languagePath,
    const char *statisticsPath)
{
    int languageLoaded;
    int statisticsLoaded;
    memset(CloneMCJ_Translations, 0, sizeof(CloneMCJ_Translations));
    CloneMCJ_TranslationCount = 0;
    languageLoaded = CloneMCJ_StringTranslate_LoadFile(languagePath);
    statisticsLoaded = CloneMCJ_StringTranslate_LoadFile(statisticsPath);
    return languageLoaded && statisticsLoaded;
}

const char *CloneMCJ_StringTranslate_TranslateKeyNative(const char *key)
{
    int index;
    if (!key) return "";
    index = CloneMCJ_StringTranslate_Find(key);
    return index >= 0 ? CloneMCJ_Translations[index].value : key;
}

const char *CloneMCJ_StringTranslate_TranslateNamedKeyNative(const char *key)
{
    char namedKey[128];
    int index;
    unsigned long length;
    if (!key) return "";
    length = (unsigned long)strlen(key);
    if (length + 6 >= sizeof(namedKey)) return "";
    strcpy(namedKey, key);
    strcat(namedKey, ".name");
    index = CloneMCJ_StringTranslate_Find(namedKey);
    return index >= 0 ? CloneMCJ_Translations[index].value : "";
}

void CloneMCJ_StringTranslate_Register(void)
{
    /* The runtime table is loaded after the asset working directory is known. */
}

const char *CloneMCJ_StringTranslate_JavaName(void)
{
    return "net.minecraft.src.StringTranslate";
}

const char *CloneMCJ_StringTranslate_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_StringTranslate_JavaSourceHash32(void)
{
    return 0xE0F2D019UL;
}
