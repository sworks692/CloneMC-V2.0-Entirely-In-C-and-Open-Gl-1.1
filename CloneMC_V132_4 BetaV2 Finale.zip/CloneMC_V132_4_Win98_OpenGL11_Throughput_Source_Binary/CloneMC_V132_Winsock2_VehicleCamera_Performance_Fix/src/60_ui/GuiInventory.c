/*
 * CloneMC Java port scaffold: GuiInventory
 *
 * Java source: GuiInventory.java
 * Java type: class GuiInventory
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiContainer
 * Implements: (none declared)
 * Source SHA-256: 1842ce287bc5d33c2f9f656cf749cceed0716e94b577bd9a3a3c6ff3888187f0
 * Java lines: 98
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: GuiContainer, EntityPlayer, AchievementList, FontRenderer, RenderEngine, EntityPlayerSP, RenderHelper, RenderManager, GuiButton, GuiAchievements, GuiStats, j, k, xSize, f1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private float xSize_lo
 * - private float ySize_lo
 *
 * Java method/constructor inventory:
 * - public GuiInventory(EntityPlayer entityplayer)
 * - public void initGui()
 * - protected void drawGuiContainerForegroundLayer()
 * - public void drawScreen(int i, int j, float f)
 * - protected void drawGuiContainerBackgroundLayer(float f)
 * - protected void actionPerformed(GuiButton guibutton)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_GuiInventory_SetOpenNative(CloneMCJ_GuiIngameState *gui,int open)
{
    if(!gui)return;
    gui->inventoryOpen=open?1:0;
    if(!open)gui->hoveredSlot=-1;
}

void CloneMCJ_GuiInventory_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiInventory_JavaName(void)
{
    return "net.minecraft.src.GuiInventory";
}

const char *CloneMCJ_GuiInventory_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiInventory_JavaSourceHash32(void)
{
    return 0x1842CE28UL;
}
