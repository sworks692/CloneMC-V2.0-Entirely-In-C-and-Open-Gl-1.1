/*
 * CloneMC Java port scaffold: ScaledResolution
 *
 * Java source: ScaledResolution.java
 * Java type: class ScaledResolution
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 70d120c5c75a06052270cd3b2b3af2b5da33ede9fd5a082597d9fe6a4fa2e4b7
 * Java lines: 47
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: GameSettings
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int scaledWidth
 * - private int scaledHeight
 * - public double field_25121_a
 * - public double field_25120_b
 * - public int scaleFactor
 *
 * Java method/constructor inventory:
 * - public ScaledResolution(GameSettings gamesettings, int i, int j)
 * - public int getScaledWidth()
 * - public int getScaledHeight()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_ScaledResolution_CalculateNative(const CloneMCGameSettings *settings,
    int displayWidth,int displayHeight,CloneMCJ_ScaledResolutionNative *result)
{
    int requested;
    if(!result)return;
    if(displayWidth<1)displayWidth=1;
    if(displayHeight<1)displayHeight=1;
    requested=settings?settings->guiScale:0;
    if(requested==0)requested=1000;
    result->scaleFactor=1;
    while(result->scaleFactor<requested&&
          displayWidth/(result->scaleFactor+1)>=320&&
          displayHeight/(result->scaleFactor+1)>=240)
        ++result->scaleFactor;
    result->scaledWidthExact=(double)displayWidth/(double)result->scaleFactor;
    result->scaledHeightExact=(double)displayHeight/(double)result->scaleFactor;
    result->scaledWidth=(displayWidth+result->scaleFactor-1)/result->scaleFactor;
    result->scaledHeight=(displayHeight+result->scaleFactor-1)/result->scaleFactor;
}

void CloneMCJ_ScaledResolution_Register(void)
{
    /* Constructor/getter behavior is exposed by CalculateNative above. */
}

const char *CloneMCJ_ScaledResolution_JavaName(void)
{
    return "net.minecraft.src.ScaledResolution";
}

const char *CloneMCJ_ScaledResolution_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_ScaledResolution_JavaSourceHash32(void)
{
    return 0x70D120C5UL;
}
