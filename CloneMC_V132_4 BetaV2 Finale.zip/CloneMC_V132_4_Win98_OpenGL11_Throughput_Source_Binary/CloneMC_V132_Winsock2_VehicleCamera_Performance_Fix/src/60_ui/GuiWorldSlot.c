/*
 * CloneMC Java port scaffold: GuiWorldSlot
 *
 * Java source: GuiWorldSlot.java
 * Java type: class GuiWorldSlot
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: c469902174f3f34c57db215d9abe35440c490db524e89d87034b6edf5a2273a1
 * Java lines: 81
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: GuiSlot, GuiSelectWorld, GuiButton, SaveFormatComparator, MathHelper, Tessellator, guiselectworld.width, guiselectworld.height
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GuiWorldSlot(GuiSelectWorld guiselectworld)
 * - protected int getSize()
 * - protected void elementClicked(int i, boolean flag)
 * - protected boolean isSelected(int i)
 * - protected int getContentHeight()
 * - protected void drawBackground()
 * - protected void drawSlot(int i, int j, int k, int l, Tessellator tessellator)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_GuiWorldSlot_InitializeNative(CloneMCJ_GuiButtonNative *button,
    int index,int centerX,int y,int selected,const char *name)
{
    CloneMCJ_GuiButton_InitializeNative(button,11+index,centerX-100,y,200,20,name);
    button->hovered=selected?1:0;
}

void CloneMCJ_GuiWorldSlot_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiWorldSlot_JavaName(void)
{
    return "net.minecraft.src.GuiWorldSlot";
}

const char *CloneMCJ_GuiWorldSlot_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiWorldSlot_JavaSourceHash32(void)
{
    return 0xC4699021UL;
}
