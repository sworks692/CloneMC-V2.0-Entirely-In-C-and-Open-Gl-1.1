/*
 * CloneMC Java port scaffold: GuiSleepMP
 *
 * Java source: GuiSleepMP.java
 * Java type: class GuiSleepMP
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiChat
 * Implements: (none declared)
 * Source SHA-256: 08eb2d7f9ca99ea6f87efc677925851cf85d9e37c32235a4b562af222e9907df
 * Java lines: 79
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: GuiChat, StringTranslate, GuiButton, EntityPlayerSP, EntityClientPlayerMP, Packet19EntityAction, NetClientHandler, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GuiSleepMP()
 * - public void initGui()
 * - public void onGuiClosed()
 * - protected void keyTyped(char c, int i)
 * - public void drawScreen(int i, int j, float f)
 * - protected void actionPerformed(GuiButton guibutton)
 * - private void func_22115_j()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiSleepMP_InitNative(CloneMCJ_GuiScreenState *screen)
{
    int width,height,scale,center;if(!screen)return;width=screen->width;height=screen->height;
    scale=screen->scaleFactor;CloneMCJ_GuiScreen_InitializeNative(screen,
        CLONEMC_GUI_SCREEN_SLEEP,CLONEMC_GUI_SCREEN_NONE,scale);screen->width=width;screen->height=height;
    center=width/2;strcpy(screen->title,"Sleeping");strcpy(screen->message,"Leave Bed");
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,height-40,200,20,"Leave Bed");
}

void CloneMCJ_GuiSleepMP_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiSleepMP_JavaName(void)
{
    return "net.minecraft.src.GuiSleepMP";
}

const char *CloneMCJ_GuiSleepMP_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiSleepMP_JavaSourceHash32(void)
{
    return 0x08EB2D7FUL;
}
