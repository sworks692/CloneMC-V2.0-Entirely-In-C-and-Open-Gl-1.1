/*
 * CloneMC Java port scaffold: GuiChat
 *
 * Java source: GuiChat.java
 * Java type: class GuiChat
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 65f102bee93f766216b69cd59215578d2219daab914c8c71b970f9a80d1c01ad
 * Java lines: 107
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: GuiScreen, EntityPlayerSP, GuiIngame, ChatAllowedCharacters, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected String message
 * - private int updateCounter
 * - private static final String field_20082_i
 *
 * Java method/constructor inventory:
 * - public GuiChat()
 * - public void initGui()
 * - public void onGuiClosed()
 * - public void updateScreen()
 * - protected void keyTyped(char c, int i)
 * - public void drawScreen(int i, int j, float f)
 * - protected void mouseClicked(int i, int j, int k)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

int CloneMCJ_GuiChat_EditNative(char *text,unsigned long capacity,int character)
{
    unsigned long length;if(!text||capacity<1)return 0;length=(unsigned long)strlen(text);
    if(character==8){if(length)text[length-1]='\0';return 1;}
    if(character>=32&&character<=126&&length+1<capacity){text[length]=(char)character;
        text[length+1]='\0';return 1;}return 0;
}

void CloneMCJ_GuiChat_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiChat_JavaName(void)
{
    return "net.minecraft.src.GuiChat";
}

const char *CloneMCJ_GuiChat_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiChat_JavaSourceHash32(void)
{
    return 0x65F102BEUL;
}
