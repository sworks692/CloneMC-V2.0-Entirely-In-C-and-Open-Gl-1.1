/*
 * CloneMC Java port scaffold: KeyBinding
 *
 * Java source: KeyBinding.java
 * Java type: class KeyBinding
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: ff1607f271524841ebdfcec4fb215220c1bd36f9f7c79795ccfd0980b980fea1
 * Java lines: 20
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public String keyDescription
 * - public int keyCode
 *
 * Java method/constructor inventory:
 * - public KeyBinding(String s, int i)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_KeyBinding_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_KeyBinding_JavaName(void)
{
    return "net.minecraft.src.KeyBinding";
}

const char *CloneMCJ_KeyBinding_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_KeyBinding_JavaSourceHash32(void)
{
    return 0xFF1607F2UL;
}

void CloneMCInput_Initialize(CloneMCInputState *input)
{
    if (!input) { return; }
    memset(input, 0, sizeof(*input));
}

void CloneMCInput_SetKey(CloneMCInputState *input, int virtualKey, int down)
{
    if (!input || virtualKey < 0 || virtualKey >= CLONEMC_PLATFORM_KEY_COUNT) { return; }
    if (down && !input->keyDown[virtualKey]) { input->keyPressed[virtualKey] = 1; }
    input->keyDown[virtualKey] = down ? 1 : 0;
}

int CloneMCInput_IsKeyDown(const CloneMCInputState *input, int virtualKey)
{
    if (!input || virtualKey < 0 || virtualKey >= CLONEMC_PLATFORM_KEY_COUNT) { return 0; }
    return input->keyDown[virtualKey] ? 1 : 0;
}

int CloneMCInput_ConsumeKeyPress(CloneMCInputState *input, int virtualKey)
{
    int pressed;
    if (!input || virtualKey < 0 || virtualKey >= CLONEMC_PLATFORM_KEY_COUNT) { return 0; }
    pressed = input->keyPressed[virtualKey] ? 1 : 0;
    input->keyPressed[virtualKey] = 0;
    return pressed;
}

int CloneMCInput_ConsumeAnyKeyPress(CloneMCInputState *input)
{
    int virtualKey;
    if (!input) { return -1; }
    for (virtualKey = 0; virtualKey < CLONEMC_PLATFORM_KEY_COUNT; ++virtualKey) {
        if (input->keyPressed[virtualKey]) {
            input->keyPressed[virtualKey] = 0;
            return virtualKey;
        }
    }
    return -1;
}

void CloneMCInput_SetMouseButton(CloneMCInputState *input, int button, int down)
{
    if (!input || button < 0 || button >= CLONEMC_PLATFORM_MOUSE_BUTTON_COUNT) { return; }
    if (down && !input->mouseDown[button]) { input->mousePressed[button] = 1; }
    input->mouseDown[button] = down ? 1 : 0;
}

int CloneMCInput_ConsumeMousePress(CloneMCInputState *input, int button)
{
    int pressed;
    if (!input || button < 0 || button >= CLONEMC_PLATFORM_MOUSE_BUTTON_COUNT) { return 0; }
    pressed = input->mousePressed[button] ? 1 : 0;
    input->mousePressed[button] = 0;
    return pressed;
}

void CloneMCInput_AddWheel(CloneMCInputState *input, int amount)
{
    if (!input) { return; }
    input->mouseWheel += amount;
}

int CloneMCInput_ConsumeWheel(CloneMCInputState *input)
{
    int value;
    if (!input) { return 0; }
    value = input->mouseWheel;
    input->mouseWheel = 0;
    return value;
}

void CloneMCInput_AddCharacter(CloneMCInputState *input,int character)
{
    if(!input||character<0||character>255||
        input->typedCharacterCount>=(int)sizeof(input->typedCharacters))return;
    input->typedCharacters[input->typedCharacterCount++]=(char)character;
}

int CloneMCInput_ConsumeCharacter(CloneMCInputState *input)
{
    int character;
    if(!input||input->typedCharacterCount<=0)return -1;
    character=(unsigned char)input->typedCharacters[0];
    --input->typedCharacterCount;
    if(input->typedCharacterCount>0)memmove(input->typedCharacters,
        input->typedCharacters+1,(unsigned long)input->typedCharacterCount);
    return character;
}

void CloneMCInput_Clear(CloneMCInputState *input)
{
    if (!input) { return; }
    memset(input->keyDown, 0, sizeof(input->keyDown));
    memset(input->keyPressed, 0, sizeof(input->keyPressed));
    memset(input->mouseDown, 0, sizeof(input->mouseDown));
    memset(input->mousePressed, 0, sizeof(input->mousePressed));
    input->mouseWheel = 0;
    input->typedCharacterCount = 0;
}

void CloneMCKeyBinding_Initialize(CloneMCKeyBindingState *binding, const char *description, int virtualKey)
{
    if (!binding) { return; }
    memset(binding, 0, sizeof(*binding));
    if (description) {
        strncpy(binding->description, description, sizeof(binding->description) - 1);
        binding->description[sizeof(binding->description) - 1] = '\0';
    }
    binding->virtualKey = virtualKey;
}

void CloneMCKeyBinding_Update(CloneMCKeyBindingState *binding, const CloneMCInputState *input)
{
    int nowPressed;
    if (!binding || !input) { return; }
    nowPressed = CloneMCInput_IsKeyDown(input, binding->virtualKey);
    if (nowPressed && !binding->pressed) { binding->pressCount++; }
    binding->pressed = nowPressed;
}

int CloneMCKeyBinding_ConsumePress(CloneMCKeyBindingState *binding)
{
    if (!binding || binding->pressCount <= 0) { return 0; }
    binding->pressCount--;
    return 1;
}
