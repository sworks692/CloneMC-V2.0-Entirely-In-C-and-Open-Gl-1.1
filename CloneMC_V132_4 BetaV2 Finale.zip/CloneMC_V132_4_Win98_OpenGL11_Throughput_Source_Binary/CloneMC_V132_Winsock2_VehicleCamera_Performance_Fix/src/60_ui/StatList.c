/* Direct C89 port of Beta StatList identifiers and value formatting. */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <string.h>

static const CloneMCJ_StatDefinition g_cloneMCGeneralStats[] = {
    {1000,"Times played",0,0,0},{1001,"Worlds played",0,0,0},
    {1002,"Saves loaded",0,0,0},{1003,"Multiplayer joins",0,0,0},
    {1004,"Games quit",0,0,0},{1100,"Time played",0,0,1},
    {2000,"Distance Walked",0,1,0},{2001,"Distance Swum",0,1,0},
    {2002,"Distance Fallen",0,1,0},{2003,"Distance Climbed",0,1,0},
    {2004,"Distance Flown",0,1,0},{2005,"Distance Dove",0,1,0},
    {2006,"Distance by Minecart",0,1,0},{2007,"Distance by Boat",0,1,0},
    {2008,"Distance by Pig",0,1,0},{2010,"Jumps",0,0,0},
    {2011,"Items Dropped",0,0,0},{2020,"Damage Dealt",0,0,0},
    {2021,"Damage Taken",0,0,0},{2022,"Number of Deaths",0,0,0},
    {2023,"Mob Kills",0,0,0},{2024,"Player Kills",0,0,0},
    {2025,"Fish Caught",0,0,0}
};

const CloneMCJ_StatDefinition *CloneMCJ_StatList_GetGeneralNative(int index)
{
    if(index<0||index>=(int)(sizeof(g_cloneMCGeneralStats)/sizeof(g_cloneMCGeneralStats[0])))return 0;
    return &g_cloneMCGeneralStats[index];
}

int CloneMCJ_StatList_GeneralCountNative(void)
{return (int)(sizeof(g_cloneMCGeneralStats)/sizeof(g_cloneMCGeneralStats[0]));}

static const char *CloneMCJ_StatList_ItemName(int itemID,char *buffer,unsigned long capacity)
{
    CloneMCJ_ItemStack stack;
    const char *key,*name;
    if(!buffer||capacity==0)return "";
    CloneMCJ_ItemStack_Initialize(&stack,itemID,1,0);
    key=CloneMCJ_ItemStack_GetNameKey(&stack);
    name=CloneMCJ_StringTranslate_TranslateNamedKeyNative(key);
    if(!name||!*name||name==key){sprintf(buffer,"Item %d",itemID);return buffer;}
    strncpy(buffer,name,capacity-1);buffer[capacity-1]='\0';return buffer;
}

const char *CloneMCJ_StatList_NameNative(int statId,char *buffer,unsigned long capacity)
{
    int i,itemID;const CloneMCJ_StatDefinition *definition;char itemName[96];
    if(!buffer||capacity==0)return "";
    for(i=0;i<CloneMCJ_StatList_GeneralCountNative();++i){
        definition=CloneMCJ_StatList_GetGeneralNative(i);
        if(definition&&definition->statId==statId){strncpy(buffer,definition->name,capacity-1);buffer[capacity-1]='\0';return buffer;}
    }
    if(statId>=CLONEMC_J_ACHIEVEMENT_STAT_BASE&&statId<CLONEMC_J_ACHIEVEMENT_STAT_BASE+CLONEMC_J_ACHIEVEMENT_COUNT){
        const CloneMCJ_AchievementDefinition *achievement;
        achievement=CloneMCJ_AchievementList_GetNative(statId-CLONEMC_J_ACHIEVEMENT_STAT_BASE);
        strncpy(buffer,achievement?achievement->title:"Achievement",capacity-1);buffer[capacity-1]='\0';return buffer;
    }
    if(statId>=CLONEMC_J_STAT_MINE_BLOCK_BASE&&statId<CLONEMC_J_STAT_MINE_BLOCK_BASE+256){itemID=statId-CLONEMC_J_STAT_MINE_BLOCK_BASE;sprintf(buffer,"%s Mined",CloneMCJ_StatList_ItemName(itemID,itemName,sizeof(itemName)));return buffer;}
    if(statId>=CLONEMC_J_STAT_CRAFT_ITEM_BASE&&statId<CLONEMC_J_STAT_CRAFT_ITEM_BASE+32000){itemID=statId-CLONEMC_J_STAT_CRAFT_ITEM_BASE;sprintf(buffer,"%s Crafted",CloneMCJ_StatList_ItemName(itemID,itemName,sizeof(itemName)));return buffer;}
    if(statId>=CLONEMC_J_STAT_USE_ITEM_BASE&&statId<CLONEMC_J_STAT_USE_ITEM_BASE+32000){itemID=statId-CLONEMC_J_STAT_USE_ITEM_BASE;sprintf(buffer,"%s Used",CloneMCJ_StatList_ItemName(itemID,itemName,sizeof(itemName)));return buffer;}
    if(statId>=CLONEMC_J_STAT_BREAK_ITEM_BASE&&statId<CLONEMC_J_STAT_BREAK_ITEM_BASE+32000){itemID=statId-CLONEMC_J_STAT_BREAK_ITEM_BASE;sprintf(buffer,"%s Depleted",CloneMCJ_StatList_ItemName(itemID,itemName,sizeof(itemName)));return buffer;}
    sprintf(buffer,"Statistic %d",statId);return buffer;
}

static void CloneMCJ_StatList_FormatDistance(int centimeters,char *buffer)
{
    double meters;meters=(double)centimeters/100.0;
    if(meters>=1000.0)sprintf(buffer,"%.2f km",meters/1000.0);
    else if(meters>=1.0)sprintf(buffer,"%.2f m",meters);
    else if(centimeters>0)sprintf(buffer,"%d cm",centimeters);
    else strcpy(buffer,"0 cm");
}

static void CloneMCJ_StatList_FormatTime(int ticks,char *buffer)
{
    double seconds,minutes,hours,days;seconds=(double)ticks/20.0;minutes=seconds/60.0;hours=minutes/60.0;days=hours/24.0;
    if(days>=0.5)sprintf(buffer,"%.2f d",days);
    else if(hours>=0.5)sprintf(buffer,"%.2f h",hours);
    else if(minutes>=0.5)sprintf(buffer,"%.2f m",minutes);
    else sprintf(buffer,"%.2f s",seconds);
}

void CloneMCJ_StatList_FormatValueNative(int statId,int value,char *buffer,unsigned long capacity)
{
    int i;const CloneMCJ_StatDefinition *definition;char temporary[64];
    if(!buffer||capacity==0)return;
    temporary[0]='\0';
    for(i=0;i<CloneMCJ_StatList_GeneralCountNative();++i){definition=CloneMCJ_StatList_GetGeneralNative(i);if(definition&&definition->statId==statId){if(definition->distanceValue)CloneMCJ_StatList_FormatDistance(value,temporary);else if(definition->timeValue)CloneMCJ_StatList_FormatTime(value,temporary);break;}}
    if(!temporary[0])sprintf(temporary,"%d",value);
    strncpy(buffer,temporary,capacity-1);buffer[capacity-1]='\0';
}

void CloneMCJ_StatList_Register(void){}
const char *CloneMCJ_StatList_JavaName(void){return "net.minecraft.src.StatList";}
const char *CloneMCJ_StatList_AssignedFolder(void){return "src/60_ui";}
unsigned long CloneMCJ_StatList_JavaSourceHash32(void){return 0x352A655FUL;}
