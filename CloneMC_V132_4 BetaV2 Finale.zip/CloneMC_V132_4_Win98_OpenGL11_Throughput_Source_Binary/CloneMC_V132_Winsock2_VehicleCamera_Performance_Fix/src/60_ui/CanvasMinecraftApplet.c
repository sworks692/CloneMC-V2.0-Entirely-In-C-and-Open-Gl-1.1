/*
 * CloneMC Java port scaffold: CanvasMinecraftApplet
 *
 * Java source: CanvasMinecraftApplet.java
 * Java type: class CanvasMinecraftApplet
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: Canvas
 * Implements: (none declared)
 * Source SHA-256: 68f92253db2e1c72c33fe8ac694319616feed291fb61ccc1a319a3cfbbf37980
 * Java lines: 33
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public CanvasMinecraftApplet(MinecraftApplet minecraftapplet)
 * - public synchronized void addNotify()
 * - public synchronized void removeNotify()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_CanvasMinecraftApplet_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_CanvasMinecraftApplet_JavaName(void)
{
    return "net.minecraft.src.CanvasMinecraftApplet";
}

const char *CloneMCJ_CanvasMinecraftApplet_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_CanvasMinecraftApplet_JavaSourceHash32(void)
{
    return 0x68F92253UL;
}
