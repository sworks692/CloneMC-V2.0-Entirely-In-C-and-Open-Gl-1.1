/*
 * CloneMC Java port scaffold: GuiSelectWorld
 *
 * Java source: GuiSelectWorld.java
 * Java type: class GuiSelectWorld
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 9fec5388a20d0935a4ee5edd2c2a728348244c670199ee117f21cf01e2b8af98
 * Java lines: 219
 * Discovered declared fields: 12
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: GuiScreen, StringTranslate, GuiWorldSlot, ISaveFormat, SaveFormatComparator, MathHelper, GuiButton, GuiYesNo, GuiCreateWorld, GuiRenameWorld, PlayerControllerSP
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected GuiScreen parentScreen
 * - protected String screenTitle
 * - private boolean selected
 * - private int selectedWorld
 * - private List saveList
 * - private GuiWorldSlot worldSlotContainer
 * - private String field_22098_o
 * - private String field_22097_p
 * - private boolean deleting
 * - private GuiButton buttonRename
 * - private GuiButton buttonSelect
 * - private GuiButton buttonDelete
 *
 * Java method/constructor inventory:
 * - public GuiSelectWorld(GuiScreen guiscreen)
 * - public void initGui()
 * - private void loadSaves()
 * - protected String getSaveFileName(int i)
 * - protected String getSaveName(int i)
 * - public void initButtons()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void selectWorld(int i)
 * - public void deleteWorld(boolean flag, int i)
 * - public void drawScreen(int i, int j, float f)
 * - private final DateFormat dateFormatter = new SimpleDateFormat()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

static int CloneMCJ_GuiSelectWorld_Compare(const void *left,const void *right)
{
    return CloneMCJ_SaveFormatComparator_Compare(
        (const CloneMCJ_SaveFormatComparator*)left,
        (const CloneMCJ_SaveFormatComparator*)right);
}

static void CloneMCJ_GuiSelectWorld_AddActions(CloneMCJ_GuiScreenState *screen)
{
    int center;CloneMCJ_GuiButtonNative *button;
    center=screen->width/2;
    button=CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-154,screen->height-52,
        150,20,CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.select"));
    if(button)button->enabled=0;
    button=CloneMCJ_GuiScreen_AddButtonNative(screen,6,center-154,screen->height-28,
        70,20,CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.rename"));
    if(button)button->enabled=0;
    button=CloneMCJ_GuiScreen_AddButtonNative(screen,2,center-74,screen->height-28,
        70,20,CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.delete"));
    if(button)button->enabled=0;
    CloneMCJ_GuiScreen_AddButtonNative(screen,3,center+4,screen->height-52,150,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.create"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,0,center+4,screen->height-28,150,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("gui.cancel"));
}

static void CloneMCJ_GuiSelectWorld_RebuildButtons(CloneMCJ_GuiScreenState *screen)
{
    int visible,index,worldIndex;char label[72];CloneMCJ_GuiButtonNative *button;
    if(!screen)return;
    screen->buttonCount=0;
    visible=(screen->height-96)/36;if(visible<1)visible=1;
    if(screen->worldScroll<0)screen->worldScroll=0;
    if(screen->worldScroll>screen->worldCount-visible)
        screen->worldScroll=screen->worldCount-visible;
    if(screen->worldScroll<0)screen->worldScroll=0;
    for(index=0;index<visible;++index){worldIndex=screen->worldScroll+index;
        if(worldIndex>=screen->worldCount)break;
        if(screen->worlds[worldIndex].displayName[0])strncpy(label,
            screen->worlds[worldIndex].displayName,sizeof(label)-1);
        else sprintf(label,"%s %d",CloneMCJ_StringTranslate_TranslateKeyNative(
            "selectWorld.world"),worldIndex+1);
        label[sizeof(label)-1]='\0';
        CloneMCJ_GuiScreen_AddButtonNative(screen,1000+worldIndex,
            screen->width/2-110,32+index*36,220,32,label);
    }
    CloneMCJ_GuiSelectWorld_AddActions(screen);
    if(screen->selectedWorld>=0){
        for(index=0;index<screen->buttonCount;++index){button=&screen->buttons[index];
            if(button->id==1||button->id==2||button->id==6)button->enabled=1;}
    }
}

void CloneMCJ_GuiSelectWorld_InitNative(CloneMCJ_GuiScreenState *screen)
{
    int width,height,scale;
    if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_SELECT_WORLD,
        CLONEMC_GUI_SCREEN_MAIN_MENU,scale);
    screen->width=width;screen->height=height;
    strncpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.title"),
        sizeof(screen->title)-1);CloneMCJ_GuiSelectWorld_AddActions(screen);
}

int CloneMCJ_GuiSelectWorld_LoadNative(CloneMCJ_GuiScreenState *screen,
    const char *baseDirectory)
{
    CloneMCJ_SaveFormatComparator *entries;
    int count,index,copyCount,width,height,scale,parent;
    if(!screen)return 0;
    if(!baseDirectory)baseDirectory="saves";
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    parent=screen->parentType;entries=0;count=0;
    /* World selection is directory-only and therefore does not instantiate
     * SaveConverterMcRegion's 64-entry region cache at all.  This restores the
     * V127.6 crash boundary and removes roughly half a MiB from the click-path
     * stack/heap working set on Win9x. */
    if(!CloneMCJ_SaveConverterMcRegion_ListWorldsAt(baseDirectory,
        &entries,&count)){entries=0;count=0;}
    if(count>1)qsort(entries,(size_t)count,sizeof(*entries),CloneMCJ_GuiSelectWorld_Compare);
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_SELECT_WORLD,parent,scale);
    screen->width=width;screen->height=height;
    strncpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative("selectWorld.title"),
        sizeof(screen->title)-1);
    copyCount=count<CLONEMC_GUI_MAX_WORLDS?count:CLONEMC_GUI_MAX_WORLDS;
    screen->worldCount=copyCount;
    for(index=0;index<copyCount;++index){
        strncpy(screen->worlds[index].fileName,entries[index].fileName,
            sizeof(screen->worlds[index].fileName)-1);
        screen->worlds[index].fileName[sizeof(screen->worlds[index].fileName)-1]='\0';
        strncpy(screen->worlds[index].displayName,entries[index].displayName,
            sizeof(screen->worlds[index].displayName)-1);
        screen->worlds[index].displayName[sizeof(screen->worlds[index].displayName)-1]='\0';
        screen->worlds[index].lastPlayed=entries[index].lastPlayed;
        screen->worlds[index].sizeOnDisk=entries[index].sizeOnDisk;
        screen->worlds[index].requiresConversion=entries[index].requiresConversion;
    }
    free(entries);CloneMCJ_GuiSelectWorld_RebuildButtons(screen);return 1;
}

int CloneMCJ_GuiSelectWorld_ScrollNative(CloneMCJ_GuiScreenState *screen,int delta)
{
    int previous;
    if(!screen||!delta)return 0;
    previous=screen->worldScroll;
    screen->worldScroll+=delta;CloneMCJ_GuiSelectWorld_RebuildButtons(screen);
    return previous!=screen->worldScroll;
}

int CloneMCJ_GuiSelectWorld_SelectNative(CloneMCJ_GuiScreenState *screen,int index)
{
    int buttonIndex,doubleClick;
    if(!screen||index<0||index>=screen->worldCount)return 0;
    doubleClick=screen->selectedWorld==index&&
        screen->updateCounter-screen->lastWorldClickCounter<10UL;
    screen->selectedWorld=index;screen->lastWorldClickCounter=screen->updateCounter;
    for(buttonIndex=0;buttonIndex<screen->buttonCount;++buttonIndex){
        if(screen->buttons[buttonIndex].id==1||screen->buttons[buttonIndex].id==2||
            screen->buttons[buttonIndex].id==6)screen->buttons[buttonIndex].enabled=1;
    }
    return doubleClick?2:1;
}

void CloneMCJ_GuiSelectWorld_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiSelectWorld_JavaName(void)
{
    return "net.minecraft.src.GuiSelectWorld";
}

const char *CloneMCJ_GuiSelectWorld_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiSelectWorld_JavaSourceHash32(void)
{
    return 0x9FEC5388UL;
}
