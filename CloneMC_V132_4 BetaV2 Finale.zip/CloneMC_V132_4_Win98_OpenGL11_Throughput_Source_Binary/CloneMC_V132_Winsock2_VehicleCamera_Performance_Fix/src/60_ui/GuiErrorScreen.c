/*
 * CloneMC Java port scaffold: GuiErrorScreen
 *
 * Java source: GuiErrorScreen.java
 * Java type: class GuiErrorScreen
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 1b9df9c568e11b6731991951e36537f1a301ebda69092ab8c144ca7e54460aae
 * Java lines: 52
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: GuiScreen, GuiButton, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_28098_a
 *
 * Java method/constructor inventory:
 * - public GuiErrorScreen()
 * - public void updateScreen()
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - protected void keyTyped(char c, int i)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiErrorScreen_InitNative(CloneMCJ_GuiScreenState *screen,
    const char *title,const char *message)
{
    int width,height,scale,center;if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_ERROR,
        CLONEMC_GUI_SCREEN_MAIN_MENU,scale);screen->width=width;screen->height=height;
    if(!title)title="Connection lost";
    if(!message)message="Unknown error";
    strncpy(screen->title,title,sizeof(screen->title)-1);screen->title[sizeof(screen->title)-1]='\0';
    strncpy(screen->message,message,sizeof(screen->message)-1);screen->message[sizeof(screen->message)-1]='\0';
    center=width/2;CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-100,height/2+48,200,20,"Back to title screen");
}

void CloneMCJ_GuiErrorScreen_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiErrorScreen_JavaName(void)
{
    return "net.minecraft.src.GuiErrorScreen";
}

const char *CloneMCJ_GuiErrorScreen_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiErrorScreen_JavaSourceHash32(void)
{
    return 0x1B9DF9C5UL;
}
