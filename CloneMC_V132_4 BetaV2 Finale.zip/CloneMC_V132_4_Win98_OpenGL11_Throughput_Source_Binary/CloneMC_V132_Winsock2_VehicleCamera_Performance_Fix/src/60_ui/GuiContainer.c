/*
 * CloneMC Java port scaffold: GuiContainer
 *
 * Java source: GuiContainer.java
 * Java type: class GuiContainer
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 405e083a9c3a37ea19d09b6dccae08d73633b061c690a60cda5783a414bfc543
 * Java lines: 217
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: GuiScreen, EntityPlayerSP, RenderHelper, Container, Slot, InventoryPlayer, RenderItem, StringTranslate, ItemStack, FontRenderer, RenderEngine, PlayerController, GameSettings, KeyBinding, l, i, l1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected int xSize
 * - protected int ySize
 * - public Container inventorySlots
 *
 * Java method/constructor inventory:
 * - public GuiContainer(Container container)
 * - public void initGui()
 * - public void drawScreen(int i, int j, float f)
 * - protected void drawGuiContainerForegroundLayer()
 * - protected abstract void drawGuiContainerBackgroundLayer(float f)
 * - private void drawSlotInventory(Slot slot)
 * - private Slot getSlotAtPosition(int i, int j)
 * - private boolean getIsMouseOverSlot(Slot slot, int i, int j)
 * - protected void mouseClicked(int i, int j, int k)
 * - protected void mouseMovedOrUp(int i, int j, int k)
 * - protected void keyTyped(char c, int i)
 * - public void onGuiClosed()
 * - public boolean doesGuiPauseGame()
 * - public void updateScreen()
 * - private static RenderItem itemRenderer = new RenderItem()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

int CloneMCJ_GuiContainer_SlotAtNative(int mouseX,int mouseY,int left,int top,
    int columns,int rows,int slotSize)
{
    int x,y;if(columns<1||rows<1||slotSize<1)return -1;
    x=mouseX-left;y=mouseY-top;if(x<0||y<0)return -1;
    x/=slotSize;y/=slotSize;if(x>=columns||y>=rows)return -1;
    return y*columns+x;
}

void CloneMCJ_GuiContainer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiContainer_JavaName(void)
{
    return "net.minecraft.src.GuiContainer";
}

const char *CloneMCJ_GuiContainer_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiContainer_JavaSourceHash32(void)
{
    return 0x405E083AUL;
}
