/*
 * CloneMC Java port scaffold: GuiButton
 *
 * Java source: GuiButton.java
 * Java type: class GuiButton
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: Gui
 * Implements: (none declared)
 * Source SHA-256: dc0e4b21af2a4f579e5e72ccbcf3fcd6b4a561c4e0cb57e26f64cab534b69050
 * Java lines: 98
 * Discovered declared fields: 8
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: Gui, RenderEngine, j, k, yPosition, i, displayString
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected int width
 * - protected int height
 * - public int xPosition
 * - public int yPosition
 * - public String displayString
 * - public int id
 * - public boolean enabled
 * - public boolean enabled2
 *
 * Java method/constructor inventory:
 * - public GuiButton(int i, int j, int k, String s)
 * - public GuiButton(int i, int j, int k, int l, int i1, String s)
 * - protected int getHoverState(boolean flag)
 * - public void drawButton(Minecraft minecraft, int i, int j)
 * - protected void mouseDragged(Minecraft minecraft, int i, int j)
 * - public void mouseReleased(int i, int j)
 * - public boolean mousePressed(Minecraft minecraft, int i, int j)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiButton_InitializeNative(CloneMCJ_GuiButtonNative *button,
    int id,int x,int y,int width,int height,const char *label)
{
    if(!button)return;
    memset(button,0,sizeof(*button));
    button->id=id;button->xPosition=x;button->yPosition=y;
    button->width=width;button->height=height;button->enabled=1;button->visible=1;
    if(!label)label="";
    strncpy(button->displayString,label,sizeof(button->displayString)-1);
    button->displayString[sizeof(button->displayString)-1]='\0';
}

int CloneMCJ_GuiButton_MousePressedNative(CloneMCJ_GuiButtonNative *button,int mouseX,int mouseY)
{
    if(!button||!button->visible)return 0;
    button->hovered=mouseX>=button->xPosition&&mouseX<button->xPosition+button->width&&
        mouseY>=button->yPosition&&mouseY<button->yPosition+button->height;
    return button->enabled&&button->hovered;
}

void CloneMCJ_GuiButton_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiButton_JavaName(void)
{
    return "net.minecraft.src.GuiButton";
}

const char *CloneMCJ_GuiButton_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiButton_JavaSourceHash32(void)
{
    return 0xDC0E4B21UL;
}
