/*
 * CloneMC Java port scaffold: GuiSmallButton
 *
 * Java source: GuiSmallButton.java
 * Java type: class GuiSmallButton
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiButton
 * Implements: (none declared)
 * Source SHA-256: 3bc2eb75662bf61b14a3466542df9491a2b3f7de8f01d2a707d136c62783c73f
 * Java lines: 38
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: GuiButton, EnumOptions, j, k, null, l, i1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final EnumOptions enumOptions
 *
 * Java method/constructor inventory:
 * - public GuiSmallButton(int i, int j, int k, String s)
 * - public GuiSmallButton(int i, int j, int k, int l, int i1, String s)
 * - public GuiSmallButton(int i, int j, int k, EnumOptions enumoptions, String s)
 * - public EnumOptions returnEnumOptions()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_GuiSmallButton_InitializeNative(CloneMCJ_GuiButtonNative *button,
    int id,int x,int y,const char *label)
{CloneMCJ_GuiButton_InitializeNative(button,id,x,y,150,20,label);}

void CloneMCJ_GuiSmallButton_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiSmallButton_JavaName(void)
{
    return "net.minecraft.src.GuiSmallButton";
}

const char *CloneMCJ_GuiSmallButton_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiSmallButton_JavaSourceHash32(void)
{
    return 0x3BC2EB75UL;
}
