/* Native Beta achievement graph state and input behavior. */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

#define CLONEMC_ACHIEVEMENT_MIN_X (-136.0)
#define CLONEMC_ACHIEVEMENT_MIN_Y (-232.0)
#define CLONEMC_ACHIEVEMENT_MAX_X (115.0)
#define CLONEMC_ACHIEVEMENT_MAX_Y (67.0)

static double CloneMCJ_GuiAchievements_Clamp(double value,double minimum,double maximum)
{if(value<minimum)return minimum;if(value>=maximum)return maximum-1.0;return value;}

void CloneMCJ_GuiAchievements_InitNative(CloneMCJ_GuiScreenState *screen)
{
    int width,height,scale,center;
    if(!screen)return;width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_ACHIEVEMENTS,CLONEMC_GUI_SCREEN_OPTIONS,scale);
    screen->width=width;screen->height=height;center=width/2;
    strcpy(screen->title,"Achievements");screen->message[0]='\0';
    screen->achievementScrollX=screen->achievementPreviousX=screen->achievementTargetX=-82.0;
    screen->achievementScrollY=screen->achievementPreviousY=screen->achievementTargetY=-70.0;
    CloneMCJ_GuiScreen_AddButtonNative(screen,200,center+24,height/2+74,80,20,"Done");
}

void CloneMCJ_GuiAchievements_SetStatsNative(CloneMCJ_GuiScreenState *screen,const CloneMCJ_StatFileState *stats)
{
    int i;if(!screen)return;screen->achievementUnlockedMask=0;screen->achievementAvailableMask=0;
    for(i=0;i<CLONEMC_J_ACHIEVEMENT_COUNT;++i){
        if(CloneMCJ_Achievement_IsUnlockedNative(stats,i))screen->achievementUnlockedMask|=(1UL<<i);
        if(CloneMCJ_Achievement_CanUnlockNative(stats,i))screen->achievementAvailableMask|=(1UL<<i);
    }
}

void CloneMCJ_GuiAchievements_UpdateNative(CloneMCJ_GuiScreenState *screen)
{
    double dx,dy;if(!screen)return;
    screen->achievementPreviousX=screen->achievementScrollX;
    screen->achievementPreviousY=screen->achievementScrollY;
    dx=screen->achievementTargetX-screen->achievementScrollX;
    dy=screen->achievementTargetY-screen->achievementScrollY;
    if(dx*dx+dy*dy<4.0){screen->achievementScrollX+=dx;screen->achievementScrollY+=dy;}
    else{screen->achievementScrollX+=dx*0.85;screen->achievementScrollY+=dy*0.85;}
}

void CloneMCJ_GuiAchievements_DragNative(CloneMCJ_GuiScreenState *screen,int mouseX,int mouseY,int buttonDown)
{
    int left,top;
    if(!screen)return;left=(screen->width-256)/2+8;top=(screen->height-202)/2+17;
    if(buttonDown&&mouseX>=left&&mouseX<left+224&&mouseY>=top&&mouseY<top+155){
        if(!screen->achievementDragging){screen->achievementDragging=1;screen->achievementLastMouseX=mouseX;screen->achievementLastMouseY=mouseY;}
        else{
            screen->achievementTargetX-=mouseX-screen->achievementLastMouseX;
            screen->achievementTargetY-=mouseY-screen->achievementLastMouseY;
            screen->achievementScrollX=screen->achievementPreviousX=screen->achievementTargetX;
            screen->achievementScrollY=screen->achievementPreviousY=screen->achievementTargetY;
            screen->achievementLastMouseX=mouseX;screen->achievementLastMouseY=mouseY;
        }
        screen->achievementTargetX=CloneMCJ_GuiAchievements_Clamp(screen->achievementTargetX,CLONEMC_ACHIEVEMENT_MIN_X,CLONEMC_ACHIEVEMENT_MAX_X);
        screen->achievementTargetY=CloneMCJ_GuiAchievements_Clamp(screen->achievementTargetY,CLONEMC_ACHIEVEMENT_MIN_Y,CLONEMC_ACHIEVEMENT_MAX_Y);
    }else screen->achievementDragging=0;
}

void CloneMCJ_GuiAchievements_Register(void){}
const char *CloneMCJ_GuiAchievements_JavaName(void){return "net.minecraft.src.GuiAchievements";}
const char *CloneMCJ_GuiAchievements_AssignedFolder(void){return "src/60_ui";}
unsigned long CloneMCJ_GuiAchievements_JavaSourceHash32(void){return 0x1A7629B7UL;}
