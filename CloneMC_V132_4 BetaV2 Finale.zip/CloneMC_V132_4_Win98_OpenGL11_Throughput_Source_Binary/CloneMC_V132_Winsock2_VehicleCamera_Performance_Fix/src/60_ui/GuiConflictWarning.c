/*
 * CloneMC Java port scaffold: GuiConflictWarning
 *
 * Java source: GuiConflictWarning.java
 * Java type: class GuiConflictWarning
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 1cc081dbb2c2f85530a476aa3490d20b28c24863aeff034dfc99e339581f7bb0
 * Java lines: 57
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: GuiScreen, GuiButton, GuiMainMenu, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int updateCounter
 *
 * Java method/constructor inventory:
 * - public GuiConflictWarning()
 * - public void updateScreen()
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiConflictWarning_InitNative(CloneMCJ_GuiScreenState *screen,const char *message)
{
    int width,height,scale,center;if(!screen)return;width=screen->width;height=screen->height;
    scale=screen->scaleFactor;CloneMCJ_GuiScreen_InitializeNative(screen,
        CLONEMC_GUI_SCREEN_CONFLICT,CLONEMC_GUI_SCREEN_MAIN_MENU,scale);
    screen->width=width;screen->height=height;center=width/2;strcpy(screen->title,"Warning!");
    if(!message)message="A save or resource conflict was detected.";
    strncpy(screen->message,message,sizeof(screen->message)-1);screen->message[sizeof(screen->message)-1]='\0';
    CloneMCJ_GuiScreen_AddButtonNative(screen,200,center-100,height/2+48,200,20,"Done");
}

void CloneMCJ_GuiConflictWarning_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiConflictWarning_JavaName(void)
{
    return "net.minecraft.src.GuiConflictWarning";
}

const char *CloneMCJ_GuiConflictWarning_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiConflictWarning_JavaSourceHash32(void)
{
    return 0x1CC081DBUL;
}
