/*
 * CloneMC Java port scaffold: GuiChest
 *
 * Java source: GuiChest.java
 * Java type: class GuiChest
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiContainer
 * Implements: (none declared)
 * Source SHA-256: 76664ce0f7ba1be7765b36282aad1441d05fb7c7ddaeb6f2b300984f9bd852a8
 * Java lines: 51
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: GuiContainer, ContainerChest, IInventory, FontRenderer, RenderEngine, k, xSize
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private IInventory upperChestInventory
 * - private IInventory lowerChestInventory
 * - private int inventoryRows
 *
 * Java method/constructor inventory:
 * - public GuiChest(IInventory iinventory, IInventory iinventory1)
 * - protected void drawGuiContainerForegroundLayer()
 * - protected void drawGuiContainerBackgroundLayer(float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiChest_LayoutNative(CloneMCJ_GuiContainerLayout *layout,int rows)
{
    if(!layout)return;
    if(rows<1)rows=1;
    if(rows>6)rows=6;
    memset(layout,0,sizeof(*layout));
    strcpy(layout->title,"Chest");layout->xSize=176;layout->rows=rows;layout->columns=9;
    layout->ySize=114+rows*18;layout->textureKind=1;
}

void CloneMCJ_GuiChest_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiChest_JavaName(void)
{
    return "net.minecraft.src.GuiChest";
}

const char *CloneMCJ_GuiChest_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiChest_JavaSourceHash32(void)
{
    return 0x76664CE0UL;
}
