/*
 * CloneMC Java port scaffold: GuiMultiplayer
 *
 * Java source: GuiMultiplayer.java
 * Java type: class GuiMultiplayer
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 93709e73ca968548a09d0030043f69a043e3d4fa2b103940652552c59815b579
 * Java lines: 135
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: GuiScreen, GuiTextField, StringTranslate, GuiButton, GameSettings, GuiConnecting, fontRenderer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private GuiScreen parentScreen
 * - private GuiTextField field_22111_h
 *
 * Java method/constructor inventory:
 * - public GuiMultiplayer(GuiScreen guiscreen)
 * - public void updateScreen()
 * - public void initGui()
 * - public void onGuiClosed()
 * - protected void actionPerformed(GuiButton guibutton)
 * - private int parseIntWithDefault(String s, int i)
 * - protected void keyTyped(char c, int i)
 * - protected void mouseClicked(int i, int j, int k)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <string.h>

void CloneMCJ_GuiMultiplayer_InitNative(CloneMCJ_GuiScreenState *screen,
    const char *lastServer,const char *username)
{
    int center,width,height,scale;
    if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_MULTIPLAYER,
        CLONEMC_GUI_SCREEN_MAIN_MENU,scale);
    screen->width=width;screen->height=height;center=width/2;
    strcpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative(
        "multiplayer.title"));
    strcpy(screen->message,
        "Username is sent to the server; the address is never your visible name.");
    if(!lastServer||!*lastServer)lastServer="localhost:25565";
    if(!username||!*username)username="Player";
    strncpy(screen->textField,username,16);
    screen->textField[16]='\0';
    strncpy(screen->textFieldSecondary,lastServer,
        sizeof(screen->textFieldSecondary)-1);
    screen->textFieldSecondary[sizeof(screen->textFieldSecondary)-1]='\0';
    screen->textFocused=1;
    CloneMCJ_GuiScreen_AddButtonNative(screen,0,center-100,height/4+108,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("multiplayer.connect"));
    CloneMCJ_GuiScreen_AddButtonNative(screen,1,center-100,height/4+132,200,20,
        CloneMCJ_StringTranslate_TranslateKeyNative("gui.cancel"));
}

void CloneMCJ_GuiMultiplayer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiMultiplayer_JavaName(void)
{
    return "net.minecraft.src.GuiMultiplayer";
}

const char *CloneMCJ_GuiMultiplayer_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiMultiplayer_JavaSourceHash32(void)
{
    return 0x93709E73UL;
}
