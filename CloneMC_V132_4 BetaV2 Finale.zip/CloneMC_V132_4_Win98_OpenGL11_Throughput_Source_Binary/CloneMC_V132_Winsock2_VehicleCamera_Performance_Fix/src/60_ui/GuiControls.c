/*
 * CloneMC Java port scaffold: GuiControls
 *
 * Java source: GuiControls.java
 * Java type: class GuiControls
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 5e12fa30b64e6a840b453c9ac6f86ccbb16e4d0bb1c60692b2b387fc7ed953e2
 * Java lines: 91
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: GuiScreen, StringTranslate, GameSettings, GuiSmallButton, GuiButton
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private GuiScreen parentScreen
 * - protected String screenTitle
 * - private GameSettings options
 * - private int buttonId
 *
 * Java method/constructor inventory:
 * - public GuiControls(GuiScreen guiscreen, GameSettings gamesettings)
 * - private int func_20080_j()
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - protected void keyTyped(char c, int i)
 * - public void drawScreen(int i, int j, float f)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <string.h>

static void CloneMCJ_GuiControls_Refresh(CloneMCJ_GuiScreenState *screen,
    const CloneMCGameSettings *settings)
{
    int index,left,top;
    char keyName[32];
    char sprintLabel[48];
    screen->buttonCount=0;left=screen->width/2-155;top=screen->height/6;
    for(index=0;index<CLONEMC_GAME_KEY_BINDING_COUNT;++index){
        CloneMCGameSettings_FormatKeyName(settings->keyCodes[index],keyName,sizeof(keyName));
        CloneMCJ_GuiScreen_AddButtonNative(screen,index,left+(index%2)*160,
            top+24*(index>>1),70,20,keyName);
    }
    sprintf(sprintLabel,"Double-tap Sprint: %s",
        settings->doubleTapSprint?"ON":"OFF");
    CloneMCJ_GuiScreen_AddButtonNative(screen,201,screen->width/2-100,top+126,
        200,20,sprintLabel);
    CloneMCJ_GuiScreen_AddButtonNative(screen,200,screen->width/2-100,top+168,
        200,20,CloneMCJ_StringTranslate_TranslateKeyNative("gui.done"));
}

void CloneMCJ_GuiControls_InitNative(CloneMCJ_GuiScreenState *screen,
    const CloneMCGameSettings *settings)
{
    int width,height,scale;
    if(!screen||!settings)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_CONTROLS,
        CLONEMC_GUI_SCREEN_OPTIONS,scale);screen->width=width;screen->height=height;
    strncpy(screen->title,CloneMCJ_StringTranslate_TranslateKeyNative("controls.title"),
        sizeof(screen->title)-1);screen->keyBindingCapture=-1;
    CloneMCJ_GuiControls_Refresh(screen,settings);
}

int CloneMCJ_GuiControls_ActivateNative(CloneMCJ_GuiScreenState *screen,
    CloneMCGameSettings *settings,int id)
{
    char keyName[32];
    if(!screen||!settings)return 0;
    if(id==201){
        settings->doubleTapSprint=settings->doubleTapSprint?0:1;
        screen->keyBindingCapture=-1;
        CloneMCJ_GuiControls_Refresh(screen,settings);
        return 1;
    }
    if(id<0||id>=CLONEMC_GAME_KEY_BINDING_COUNT)return 0;
    CloneMCJ_GuiControls_Refresh(screen,settings);screen->keyBindingCapture=id;
    CloneMCGameSettings_FormatKeyName(settings->keyCodes[id],keyName,sizeof(keyName));
    sprintf(screen->buttons[id].displayString,"> %s <",keyName);return 1;
}

int CloneMCJ_GuiControls_KeyNative(CloneMCJ_GuiScreenState *screen,
    CloneMCGameSettings *settings,int keyCode)
{
    int index;
    if(!screen||!settings||screen->keyBindingCapture<0)return 0;
    index=screen->keyBindingCapture;
    if(!CloneMCGameSettings_SetKeyBinding(settings,index,keyCode))return 0;
    screen->keyBindingCapture=-1;CloneMCJ_GuiControls_Refresh(screen,settings);return 1;
}

void CloneMCJ_GuiControls_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiControls_JavaName(void)
{
    return "net.minecraft.src.GuiControls";
}

const char *CloneMCJ_GuiControls_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiControls_JavaSourceHash32(void)
{
    return 0x5E12FA30UL;
}
