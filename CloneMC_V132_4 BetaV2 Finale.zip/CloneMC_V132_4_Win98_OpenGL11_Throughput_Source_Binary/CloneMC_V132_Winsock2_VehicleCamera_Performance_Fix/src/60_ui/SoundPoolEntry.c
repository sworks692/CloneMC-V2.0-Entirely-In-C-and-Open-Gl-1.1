/*
 * CloneMC Java port scaffold: SoundPoolEntry
 *
 * Java source: SoundPoolEntry.java
 * Java type: class SoundPoolEntry
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 30e05931439dd8b0d3553aef85ffde1c700c72960427834259f8d8ee0e067a98
 * Java lines: 21
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public String soundName
 * - public URL soundUrl
 *
 * Java method/constructor inventory:
 * - public SoundPoolEntry(String s, URL url)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_SoundPoolEntry_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_SoundPoolEntry_JavaName(void)
{
    return "net.minecraft.src.SoundPoolEntry";
}

const char *CloneMCJ_SoundPoolEntry_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_SoundPoolEntry_JavaSourceHash32(void)
{
    return 0x30E05931UL;
}
