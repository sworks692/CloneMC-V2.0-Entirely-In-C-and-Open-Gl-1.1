/*
 * CloneMC Java port scaffold: PanelCrashReport
 *
 * Java source: PanelCrashReport.java
 * Java type: class PanelCrashReport
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: Panel
 * Implements: (none declared)
 * Source SHA-256: 685bd2278d0c7d85c464c2371fde6fd6f1f05ffff145941a37ef0a37f396d267
 * Java lines: 97
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: UnexpectedThrowable, CanvasMojangLogo, CanvasCrashReport, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public PanelCrashReport(UnexpectedThrowable unexpectedthrowable)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_PanelCrashReport_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_PanelCrashReport_JavaName(void)
{
    return "net.minecraft.src.PanelCrashReport";
}

const char *CloneMCJ_PanelCrashReport_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_PanelCrashReport_JavaSourceHash32(void)
{
    return 0x685BD227UL;
}
