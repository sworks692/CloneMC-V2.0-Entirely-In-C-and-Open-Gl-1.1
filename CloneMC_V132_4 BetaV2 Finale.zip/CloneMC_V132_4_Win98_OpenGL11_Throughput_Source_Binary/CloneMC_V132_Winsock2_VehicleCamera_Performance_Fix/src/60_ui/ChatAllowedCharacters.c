/*
 * CloneMC Java port scaffold: ChatAllowedCharacters
 *
 * Java source: ChatAllowedCharacters.java
 * Java type: class ChatAllowedCharacters
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 55bccb02240a0c8d7064c9c5b7c2fc47b96fab2f95695b3c91580dac46c703c1
 * Java lines: 49
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ChatAllowedCharacters()
 * - private static String getAllowedCharacters()
 * - public static final String allowedCharacters = getAllowedCharacters()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

int CloneMCJ_ChatAllowedCharacters_IsIllegalFilenameNative(int character)
{
    static const unsigned char illegal[]={
        '/', '\n', '\r', '\t', 0, '\f', '`', '?', '*', '\\',
        '<', '>', '|', '"', ':'
    };
    int index;
    for(index=0;index<(int)sizeof(illegal);++index)
        if(character==(int)illegal[index])return 1;
    return 0;
}

int CloneMCJ_ChatAllowedCharacters_IsAllowedNative(int character)
{
    /* The uploaded asset set has no /font.txt resource.  Its default.png atlas
     * contains the legacy 0..255 cells, so preserve the usable printable byte
     * range while rejecting control characters exactly as GuiTextField does. */
    return character>=32&&character<=255&&character!=0x7f;
}

void CloneMCJ_ChatAllowedCharacters_Register(void)
{
    /* Character and filename membership is implemented above. */
}

const char *CloneMCJ_ChatAllowedCharacters_JavaName(void)
{
    return "net.minecraft.src.ChatAllowedCharacters";
}

const char *CloneMCJ_ChatAllowedCharacters_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_ChatAllowedCharacters_JavaSourceHash32(void)
{
    return 0x55BCCB02UL;
}
