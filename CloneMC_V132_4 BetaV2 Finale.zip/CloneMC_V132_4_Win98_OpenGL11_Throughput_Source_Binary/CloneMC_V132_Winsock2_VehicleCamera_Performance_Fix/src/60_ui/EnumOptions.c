/*
 * CloneMC Java port scaffold: EnumOptions
 *
 * Java source: EnumOptions.java
 * Java type: enum EnumOptions
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: eb310bfe063c2e2843f32ce8c7ad55c91f457583b6875e087bd035f902689c9f
 * Java lines: 120
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final boolean enumFloat
 * - private final boolean enumBoolean
 * - private final String enumString
 * - private static final EnumOptions field_20141_n[]
 *
 * Java method/constructor inventory:
 * - public static EnumOptions getEnumOptions(int i)
 * - private EnumOptions(String s, int i, String s1, boolean flag, boolean flag1)
 * - public boolean getEnumFloat()
 * - public boolean getEnumBoolean()
 * - public int returnEnumOrdinal()
 * - public String getEnumString()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

static const CloneMCJ_EnumOptionDefinition CloneMCJ_EnumOptions_Table[
    CLONEMC_OPTION_COUNT] = {
    {CLONEMC_OPTION_MUSIC,"options.music",1,0},
    {CLONEMC_OPTION_SOUND,"options.sound",1,0},
    {CLONEMC_OPTION_INVERT_MOUSE,"options.invertMouse",0,1},
    {CLONEMC_OPTION_SENSITIVITY,"options.sensitivity",1,0},
    {CLONEMC_OPTION_RENDER_DISTANCE,"options.renderDistance",1,0},
    {CLONEMC_OPTION_VIEW_BOBBING,"options.viewBobbing",0,1},
    {CLONEMC_OPTION_ANAGLYPH,"options.anaglyph",0,1},
    {CLONEMC_OPTION_ADVANCED_OPENGL,"options.advancedOpengl",0,1},
    {CLONEMC_OPTION_FRAMERATE_LIMIT,"options.framerateLimit",0,0},
    {CLONEMC_OPTION_DIFFICULTY,"options.difficulty",0,0},
    {CLONEMC_OPTION_GRAPHICS,"options.graphics",0,0},
    {CLONEMC_OPTION_AMBIENT_OCCLUSION,"options.ao",0,1},
    {CLONEMC_OPTION_GUI_SCALE,"options.guiScale",0,0}
};

const CloneMCJ_EnumOptionDefinition *CloneMCJ_EnumOptions_GetNative(int ordinal)
{
    if (ordinal < 0 || ordinal >= CLONEMC_OPTION_COUNT) return 0;
    return &CloneMCJ_EnumOptions_Table[ordinal];
}

void CloneMCJ_EnumOptions_Register(void)
{
    /* The Java enum is represented by CloneMCJ_EnumOptions_Table. */
}

const char *CloneMCJ_EnumOptions_JavaName(void)
{
    return "net.minecraft.src.EnumOptions";
}

const char *CloneMCJ_EnumOptions_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_EnumOptions_JavaSourceHash32(void)
{
    return 0xEB310BFEUL;
}
