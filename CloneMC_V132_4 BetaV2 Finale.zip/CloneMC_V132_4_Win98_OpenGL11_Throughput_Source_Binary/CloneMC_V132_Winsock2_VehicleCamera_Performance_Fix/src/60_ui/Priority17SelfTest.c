/* Deterministic Priority 17 regressions: region rollback, achievement graph,
 * stat persistence and bounded GUI state.  This remains C89/Open Watcom safe. */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int CloneMCJ_P17_CompareRead(CloneMCJ_RegionFile *region,int x,int z,
    const unsigned char *expected,unsigned long expectedSize)
{
    unsigned char *readData;unsigned long readSize;int ok;
    readData=0;readSize=0;
    if(!CloneMCJ_RegionFile_ReadChunk(region,x,z,&readData,&readSize))return 0;
    ok=readSize==expectedSize&&memcmp(readData,expected,expectedSize)==0;
    if(readData)free(readData);return ok;
}

static int CloneMCJ_P17_TestRegion(char *message,unsigned int capacity)
{
    const char *path="clonemc_priority17_region_test.mcr";
    CloneMCJ_RegionFile region;
    unsigned char first[7000],second[9000],replacement[7500];
    unsigned long i,oldOffset,oldSectors;
    int ok;
    remove(path);
    for(i=0;i<sizeof(first);++i)first[i]=(unsigned char)((i*17UL+3UL)&255UL);
    for(i=0;i<sizeof(second);++i)second[i]=(unsigned char)((i*29UL+11UL)&255UL);
    for(i=0;i<sizeof(replacement);++i)replacement[i]=(unsigned char)((i*43UL+7UL)&255UL);
    memset(&region,0,sizeof(region));
    if(!CloneMCJ_RegionFile_Open(&region,path)){sprintf(message,"Priority 17 region open failed: %s",CloneMCJ_RegionFile_ErrorText(region.lastError));return 0;}
    if(!CloneMCJ_RegionFile_WriteChunkEx(&region,0,0,first,sizeof(first),1)){
        sprintf(message,"Priority 17 initial region write failed: %s",CloneMCJ_RegionFile_ErrorText(region.lastError));CloneMCJ_RegionFile_Close(&region);remove(path);return 0;}
    oldOffset=region.offsets[0];oldSectors=region.sectorCount;
    region.testFailStage=2;
    if(CloneMCJ_RegionFile_WriteChunkEx(&region,1,0,second,sizeof(second),1)||
       region.offsets[1]!=0||region.sectorCount!=oldSectors){
        strcpy(message,"Priority 17 appended payload failure did not roll back the region allocation");CloneMCJ_RegionFile_Close(&region);remove(path);return 0;}
    region.testFailStage=6;
    if(CloneMCJ_RegionFile_WriteChunkEx(&region,0,0,replacement,sizeof(replacement),1)||
       region.offsets[0]!=oldOffset||!CloneMCJ_P17_CompareRead(&region,0,0,first,sizeof(first))){
        strcpy(message,"Priority 17 location-header failure did not preserve the old chunk");CloneMCJ_RegionFile_Close(&region);remove(path);return 0;}
    region.testFailStage=0;
    /* Forced world saving writes all dirty chunks, but Java's force flag is not
     * a per-chunk device sync.  Verify buffered writes remain dirty until one
     * final region commit and that the committed data reopens byte-for-byte. */
    ok=CloneMCJ_RegionFile_WriteChunkEx(&region,1,0,second,sizeof(second),0)&&
       CloneMCJ_RegionFile_WriteChunkEx(&region,0,0,replacement,sizeof(replacement),0)&&
       region.dirty&&
       CloneMCJ_P17_CompareRead(&region,0,0,replacement,sizeof(replacement))&&
       CloneMCJ_P17_CompareRead(&region,1,0,second,sizeof(second))&&
       CloneMCJ_RegionFile_Flush(&region,1)&&!region.dirty;
    CloneMCJ_RegionFile_Close(&region);
    if(ok){memset(&region,0,sizeof(region));ok=CloneMCJ_RegionFile_Open(&region,path)&&
        CloneMCJ_P17_CompareRead(&region,0,0,replacement,sizeof(replacement))&&
        CloneMCJ_P17_CompareRead(&region,1,0,second,sizeof(second));CloneMCJ_RegionFile_Close(&region);}
    remove(path);
    if(!ok){strcpy(message,"Priority 17 durable region reopen verification failed");return 0;}
    return 1;
}

static int CloneMCJ_P17_TestProgression(char *message,unsigned int capacity)
{
    CloneMCJ_StatFileState stats,loaded;
    CloneMCJ_GuiScreenState screen;
    const char *statsPath="clonemc_priority17_stats_test.json";
    const char *mapPath="clonemc_priority17_stats_map.txt";
    FILE *map;
    int i,loadedResult;
    char formatted[64];
    (void)capacity;
    CloneMCJ_StatFileWriter_InitializeNative(&stats);
    if(CloneMCJ_Achievement_UnlockNative(&stats,1)||
       !CloneMCJ_Achievement_UnlockNative(&stats,0)||
       !CloneMCJ_Achievement_UnlockNative(&stats,1)||
       !CloneMCJ_Achievement_UnlockNative(&stats,2)||
       CloneMCJ_Achievement_UnlockNative(&stats,4)){
        strcpy(message,"Priority 17 achievement parent dependencies failed");return 0;}
    CloneMCJ_StatFileWriter_SetNative(&stats,2000,123456);
    CloneMCJ_StatFileWriter_SetNative(&stats,1100,72000);
    CloneMCJ_StatList_FormatValueNative(2000,123456,formatted,sizeof(formatted));
    if(!strstr(formatted,"km")){strcpy(message,"Priority 17 distance statistic formatting failed");return 0;}
    memset(&screen,0,sizeof(screen));screen.width=854;screen.height=480;screen.scaleFactor=1;
    CloneMCJ_GuiAchievements_InitNative(&screen);CloneMCJ_GuiAchievements_SetStatsNative(&screen,&stats);
    if((screen.achievementUnlockedMask&7UL)!=7UL||!(screen.achievementAvailableMask&(1UL<<3))){
        strcpy(message,"Priority 17 achievement graph masks failed");return 0;}
    CloneMCJ_GuiStats_InitNative(&screen);CloneMCJ_GuiStats_SetStatsNative(&screen,&stats);
    if(screen.statsCount<CloneMCJ_StatList_GeneralCountNative()){
        strcpy(message,"Priority 17 general statistics list is incomplete");return 0;}
    map=fopen(mapPath,"wt");if(!map){strcpy(message,"Priority 17 could not create checksum map");return 0;}
    for(i=0;i<stats.count;++i)fprintf(map,"%d,%08x%08x%08x%08x\n",stats.entries[i].statId,
        (unsigned int)stats.entries[i].statId,0x13572468U,0x24681357U,(unsigned int)i);
    fclose(map);remove(statsPath);
    if(!CloneMCJ_StatFileWriter_SaveJsonFileNative(&stats,statsPath,mapPath,"Player","local")){
        remove(mapPath);strcpy(message,"Priority 17 transactional statistics save failed");return 0;}
    CloneMCJ_StatFileWriter_InitializeNative(&loaded);
    loadedResult=CloneMCJ_StatFileWriter_LoadJsonFileNative(&loaded,statsPath,mapPath,"local");
    remove(statsPath);remove(mapPath);
    if(loadedResult<=0||CloneMCJ_StatFileWriter_GetNative(&loaded,2000)!=123456||
       !CloneMCJ_Achievement_IsUnlockedNative(&loaded,2)){
        strcpy(message,"Priority 17 statistics JSON round trip failed");return 0;}
    return 1;
}



static int CloneMCJ_P17_TestMetadataSnapshot(char *message,unsigned int capacity)
{
    CloneMCJ_World world;
    CloneMCJ_GameplayState gameplay;
    CloneMCJ_NBTTagCompound *legacyPlayer;
    CloneMCJ_NBTTagCompound *savedPlayer;
    CloneMCJ_ItemStack item;
    const char *marker;
    (void)capacity;
    memset(&world,0,sizeof(world));
    memset(&gameplay,0,sizeof(gameplay));
    CloneMCJ_World_InitializeDeferred(&world,(CloneMCJLong)987654321,2);
    CloneMCJ_Gameplay_Initialize(&gameplay,&world,"SnapshotTest");
    CloneMCJ_Entity_SetPosition(&gameplay.player.entity,123.25,71.0,-456.75);
    gameplay.player.entity.rotationYaw=137.5F;
    gameplay.player.entity.rotationPitch=-22.0F;
    gameplay.player.health=13;
    gameplay.player.dimension=0;
    CloneMCJ_ItemStack_Initialize(&gameplay.player.inventory.mainInventory[4],264,7,0);
    gameplay.player.inventory.currentItem=4;
    legacyPlayer=CloneMCJ_NBTTagCompound_Create();
    if(!legacyPlayer){
        CloneMCJ_Gameplay_Destroy(&gameplay);CloneMCJ_World_Destroy(&world);
        strcpy(message,"V122 metadata snapshot could not allocate the legacy Player tag");return 0;
    }
    CloneMCJ_NBTTagCompound_SetString(legacyPlayer,"CloneMCUnknownTag","preserve-me");
    if(world.worldInfo.playerTag)CloneMCJ_NBTBase_Free(world.worldInfo.playerTag);
    world.worldInfo.playerTag=(CloneMCJ_NBTBase *)legacyPlayer;
    /* A live item outside the resident set makes entity-list synchronization
     * incomplete, but Java still saves the player and every resident chunk. */
    CloneMCJ_ItemStack_Initialize(&item,4,1,0);
    CloneMCJ_EntityItem_Initialize(&gameplay.droppedItems[0],&world,8192.5,70.0,8192.5,&item);
    gameplay.droppedItems[0].active=1;gameplay.droppedItemCount=1;
    if(!CloneMCJ_Gameplay_PrepareSave(&world,&gameplay)){
        CloneMCJ_Gameplay_Destroy(&gameplay);CloneMCJ_World_Destroy(&world);
        strcpy(message,"V122 recoverable entity-sync condition blocked Player/world metadata capture");return 0;
    }
    savedPlayer=(CloneMCJ_NBTTagCompound *)world.worldInfo.playerTag;
    marker=savedPlayer?CloneMCJ_NBTTagCompound_GetString(savedPlayer,"CloneMCUnknownTag"):0;
    if(!savedPlayer||!marker||strcmp(marker,"preserve-me")!=0||
       CloneMCJ_NBTTagCompound_GetShort(savedPlayer,"Health")!=13||
       CloneMCJ_NBTTagCompound_GetInteger(savedPlayer,"Dimension")!=0||
       gameplay.entitySyncFailures!=1UL){
        CloneMCJ_Gameplay_Destroy(&gameplay);CloneMCJ_World_Destroy(&world);
        strcpy(message,"V122 Player snapshot lost current state, unknown tags, or recoverable entity diagnostics");return 0;
    }
    CloneMCJ_Gameplay_Destroy(&gameplay);CloneMCJ_World_Destroy(&world);
    return 1;
}

static int CloneMCJ_P17_TestTileAnimation(char *message,unsigned int capacity)
{
    CloneMCJ_World world;
    CloneMCJ_GameplayState gameplay;
    CloneMCJ_TileEntity *chest,*spawner,*sign,*loadedSign;
    CloneMCJ_NBTTagCompound *signTag;
    double yaw;
    int index;
    (void)capacity;
    memset(&world,0,sizeof(world));memset(&gameplay,0,sizeof(gameplay));
    CloneMCJavaRandom_SetSeed(&world.rand,(CloneMCJLong)918273645);
    world.gameplayUserData=&gameplay;gameplay.world=&world;
    gameplay.player.entity.posX=0.5;gameplay.player.entity.posY=64.5;
    gameplay.player.entity.posZ=0.5;
    chest=CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_CHEST,&world,0,64,0);
    spawner=CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_MOB_SPAWNER,&world,0,64,0);
    sign=CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_SIGN,&world,1,64,0);
    if(!chest||!spawner||!sign){if(chest)CloneMCJ_TileEntity_Destroy(chest);
        if(spawner)CloneMCJ_TileEntity_Destroy(spawner);
        if(sign)CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"Priority 17 tile animation allocation failed");return 0;}
    chest->numUsingPlayers=1;
    for(index=0;index<5;++index)CloneMCJ_TileEntity_Update(chest);
    if(chest->lidAngle<0.49F||chest->lidAngle>0.51F||
       chest->previousLidAngle>=chest->lidAngle){
        CloneMCJ_TileEntity_Destroy(chest);CloneMCJ_TileEntity_Destroy(spawner);
        CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"Priority 17 chest lid did not interpolate from fixed ticks");return 0;}
    chest->numUsingPlayers=0;
    for(index=0;index<5;++index)CloneMCJ_TileEntity_Update(chest);
    if(chest->lidAngle>0.001F){CloneMCJ_TileEntity_Destroy(chest);
        CloneMCJ_TileEntity_Destroy(spawner);CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"Priority 17 chest lid did not close deterministically");return 0;}
    spawner->spawnDelay=20;yaw=spawner->spawnerYaw;
    CloneMCJ_TileEntity_Update(spawner);
    if(spawner->spawnDelay!=19||spawner->spawnerYaw<=yaw){
        CloneMCJ_TileEntity_Destroy(chest);CloneMCJ_TileEntity_Destroy(spawner);
        CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"Priority 17 spawner range/delay/yaw update failed");return 0;}
    gameplay.player.entity.posX=100.0;gameplay.player.entity.posY=64.5;
    gameplay.player.entity.posZ=100.0;yaw=spawner->spawnerYaw;
    CloneMCJ_TileEntity_Update(spawner);
    if(spawner->spawnDelay!=19||spawner->spawnerYaw!=yaw){
        CloneMCJ_TileEntity_Destroy(chest);CloneMCJ_TileEntity_Destroy(spawner);
        CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"Priority 17 inactive spawner advanced outside 16 blocks");return 0;}

    memset(sign->signText,0,sizeof(sign->signText));index=0;
    if(!CloneMCJ_GuiEditSign_KeyTileNative(sign,&index,0,'B')||
       !CloneMCJ_GuiEditSign_KeyTileNative(sign,&index,0,'e')||
       !CloneMCJ_GuiEditSign_KeyTileNative(sign,&index,0,'t')||
       !CloneMCJ_GuiEditSign_KeyTileNative(sign,&index,0,'a')||
       strcmp(sign->signText[0],"Beta")!=0||
       !CloneMCJ_GuiEditSign_KeyTileNative(sign,&index,208,0)||index!=1||
       !CloneMCJ_GuiEditSign_KeyTileNative(sign,&index,0,'1')||
       !CloneMCJ_GuiEditSign_KeyTileNative(sign,&index,14,0)||
       sign->signText[1][0]!='\0'){
        CloneMCJ_TileEntity_Destroy(chest);CloneMCJ_TileEntity_Destroy(spawner);
        CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"V126 Java sign editor typing/navigation/backspace failed");return 0;}

    strcpy(sign->signText[0],"Priority 17");
    strcpy(sign->signText[1],"NBT round trip");
    strcpy(sign->signText[2],"Beta sign");
    strcpy(sign->signText[3],"persists");
    signTag=CloneMCJ_NBTTagCompound_Create();
    if(!signTag||!CloneMCJ_TileEntity_WriteNBT(sign,signTag)){
        if(signTag)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)signTag);
        CloneMCJ_TileEntity_Destroy(chest);CloneMCJ_TileEntity_Destroy(spawner);
        CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"Priority 17 sign NBT write failed");return 0;}
    loadedSign=CloneMCJ_TileEntity_ReadNBT(signTag,&world);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)signTag);
    if(!loadedSign||strcmp(loadedSign->signText[0],"Priority 17")!=0||
       strcmp(loadedSign->signText[1],"NBT round trip")!=0||
       strcmp(loadedSign->signText[2],"Beta sign")!=0||
       strcmp(loadedSign->signText[3],"persists")!=0){
        if(loadedSign)CloneMCJ_TileEntity_Destroy(loadedSign);
        CloneMCJ_TileEntity_Destroy(chest);CloneMCJ_TileEntity_Destroy(spawner);
        CloneMCJ_TileEntity_Destroy(sign);
        strcpy(message,"Priority 17 sign text did not survive NBT round trip");return 0;}
    CloneMCJ_TileEntity_Destroy(loadedSign);
    CloneMCJ_TileEntity_Destroy(chest);CloneMCJ_TileEntity_Destroy(spawner);
    CloneMCJ_TileEntity_Destroy(sign);
    return 1;
}

static int CloneMCJ_P17_TestInputAndAudioPolicy(char *message,unsigned int capacity)
{
    CloneMCInputState input;
    CloneMCJ_SoundManagerState sound;
    int index,selected;
    (void)capacity;
    CloneMCInput_Initialize(&input);
    CloneMCInput_SetKey(&input,'E',1);
    CloneMCInput_SetKey(&input,'E',1);
    if(!CloneMCInput_ConsumeKeyPress(&input,'E')||
       CloneMCInput_ConsumeKeyPress(&input,'E')){
        strcpy(message,"Priority 17 key transition was delivered more than once");return 0;}
    CloneMCInput_SetKey(&input,'E',0);
    CloneMCInput_SetKey(&input,'E',1);
    if(!CloneMCInput_ConsumeKeyPress(&input,'E')){
        strcpy(message,"Priority 17 second key transition was lost");return 0;}
    CloneMCInput_SetMouseButton(&input,0,1);
    CloneMCInput_SetMouseButton(&input,0,1);
    if(!CloneMCInput_ConsumeMousePress(&input,0)||
       CloneMCInput_ConsumeMousePress(&input,0)){
        strcpy(message,"Priority 17 mouse transition was delivered more than once");return 0;}
    CloneMCInput_AddWheel(&input,120);CloneMCInput_AddWheel(&input,-40);
    if(CloneMCInput_ConsumeWheel(&input)!=80||CloneMCInput_ConsumeWheel(&input)!=0){
        strcpy(message,"Priority 17 wheel queue did not consume atomically");return 0;}

    memset(&sound,0,sizeof(sound));sound.tickCount=100UL;
    for(index=0;index<CLONEMC_SOUND_EFFECT_CHANNELS;++index){
        sound.effectChannels[index]=1;sound.effectPriority[index]=220;
        sound.effectAudible[index]=1.0F;sound.effectStartedTick[index]=99UL;
        strcpy(sound.effectNames[index],"random.hurt");
    }
    sound.effectPriority[3]=40;sound.effectAudible[3]=0.10F;
    sound.effectStartedTick[3]=20UL;strcpy(sound.effectNames[3],"ambient.cave");
    selected=CloneMCJ_SoundManager_SelectChannel(&sound,"random.explode",0.8F,220);
    if(selected!=3){
        strcpy(message,"Priority 17 audio priority did not replace the quiet ambient channel");return 0;}
    strcpy(sound.effectNames[3],"random.explode");sound.effectPriority[3]=220;
    sound.effectAudible[3]=0.9F;sound.effectStartedTick[3]=99UL;
    selected=CloneMCJ_SoundManager_SelectChannel(&sound,"random.explode",0.5F,220);
    if(selected!=-2||sound.soundsDuplicateSuppressed!=1UL){
        strcpy(message,"Priority 17 duplicate sound suppression failed");return 0;}
    return 1;
}

int CloneMCJ_Priority17_RunSelfTests(char *message,unsigned int capacity)
{
    if(!message||capacity==0)return 0;message[0]='\0';
    if(!CloneMCJ_P17_TestRegion(message,capacity))return 0;
    if(!CloneMCJ_P17_TestProgression(message,capacity))return 0;
    if(!CloneMCJ_P17_TestMetadataSnapshot(message,capacity))return 0;
    if(!CloneMCJ_P17_TestTileAnimation(message,capacity))return 0;
    if(!CloneMCJ_P17_TestInputAndAudioPolicy(message,capacity))return 0;
    sprintf(message,"Priority 17/V122 region retry, metadata snapshot, achievements, statistics, tile animation, input and audio policy tests passed");
    return 1;
}
