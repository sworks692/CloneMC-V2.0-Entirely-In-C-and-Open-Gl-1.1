/*
 * CloneMC Java port scaffold: GameWindowListener
 *
 * Java source: GameWindowListener.java
 * Java type: class GameWindowListener
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: WindowAdapter
 * Implements: (none declared)
 * Source SHA-256: 8079a07ccc49a82b5cdde31da5fa09ce5a7f20cd177ffbb99e226b492ad831b7
 * Java lines: 38
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public GameWindowListener(Minecraft minecraft, Thread thread)
 * - public void windowClosing(WindowEvent windowevent)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_GameWindowListener_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GameWindowListener_JavaName(void)
{
    return "net.minecraft.src.GameWindowListener";
}

const char *CloneMCJ_GameWindowListener_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GameWindowListener_JavaSourceHash32(void)
{
    return 0x8079A07CUL;
}

void CloneMCWindowListener_Initialize(CloneMCWindowListenerState *state, int width, int height)
{
    if (!state) { return; }
    state->closeRequested = 0;
    state->active = 1;
    state->focused = 1;
    state->minimized = 0;
    state->width = width;
    state->height = height;
}

void CloneMCWindowListener_OnFocus(CloneMCWindowListenerState *state, int active, int focused)
{
    if (!state) { return; }
    state->active = active ? 1 : 0;
    state->focused = focused ? 1 : 0;
}

void CloneMCWindowListener_OnResize(CloneMCWindowListenerState *state, int width, int height, int minimized)
{
    if (!state) { return; }
    if (width > 0) { state->width = width; }
    if (height > 0) { state->height = height; }
    state->minimized = minimized ? 1 : 0;
}

void CloneMCWindowListener_RequestClose(CloneMCWindowListenerState *state)
{
    if (!state) { return; }
    state->closeRequested = 1;
}
