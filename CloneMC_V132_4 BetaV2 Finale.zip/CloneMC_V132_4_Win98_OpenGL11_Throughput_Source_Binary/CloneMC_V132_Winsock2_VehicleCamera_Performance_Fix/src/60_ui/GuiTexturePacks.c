/*
 * CloneMC Java port scaffold: GuiTexturePacks
 *
 * Java source: GuiTexturePacks.java
 * Java type: class GuiTexturePacks
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: GuiScreen
 * Implements: (none declared)
 * Source SHA-256: 00291b3db6a18a84646d206362c5d88a7d1fde927dd0036bf2b910b2306b8c01
 * Java lines: 152
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: GuiScreen, StringTranslate, GuiSmallButton, TexturePackList, GuiTexturePackSlot, GuiButton, RenderEngine, FontRenderer, j, mc.textureP
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected GuiScreen guiScreen
 * - private int field_6454_o
 * - private String fileLocation
 * - private GuiTexturePackSlot guiTexturePackSlot
 *
 * Java method/constructor inventory:
 * - public GuiTexturePacks(GuiScreen guiscreen)
 * - public void initGui()
 * - protected void actionPerformed(GuiButton guibutton)
 * - protected void mouseClicked(int i, int j, int k)
 * - protected void mouseMovedOrUp(int i, int j, int k)
 * - public void drawScreen(int i, int j, float f)
 * - public void updateScreen()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"
#include <stdio.h>
#include <string.h>

void CloneMCJ_GuiTexturePacks_InitNative(CloneMCJ_GuiScreenState *screen)
{
    int width,height,scale,center,index,count,visible,y;
    char label[128];
    if(!screen)return;
    width=screen->width;height=screen->height;scale=screen->scaleFactor;
    CloneMCJ_GuiScreen_InitializeNative(screen,CLONEMC_GUI_SCREEN_TEXTURE_PACKS,
        CLONEMC_GUI_SCREEN_MAIN_MENU,scale);screen->width=width;screen->height=height;
    center=width/2;strcpy(screen->title,"Select Texture Pack");
    CloneMCTexturePacks_Refresh();count=CloneMCTexturePacks_GetCount();
    sprintf(screen->message,"Selected: %s",
        CloneMCTexturePacks_GetSelectedName());
    visible=(height-82)/22;if(visible<1)visible=1;
    if(visible>CLONEMC_GUI_MAX_BUTTONS-1)
        visible=CLONEMC_GUI_MAX_BUTTONS-1;
    if(visible>count)visible=count;y=42;
    for(index=0;index<visible;++index){
        sprintf(label,"%s%s - %.58s",
            strcmp(CloneMCTexturePacks_GetSelectedName(),
                CloneMCTexturePacks_GetName(index))==0?"[x] ":"",
            CloneMCTexturePacks_GetName(index),
            CloneMCTexturePacks_GetDescription(index));
        CloneMCJ_GuiScreen_AddButtonNative(screen,1000+index,
            center-140,y,280,20,label);
        y+=22;
    }
    CloneMCJ_GuiScreen_AddButtonNative(screen,200,center-100,height-28,200,20,"Done");
}

void CloneMCJ_GuiTexturePacks_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_GuiTexturePacks_JavaName(void)
{
    return "net.minecraft.src.GuiTexturePacks";
}

const char *CloneMCJ_GuiTexturePacks_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_GuiTexturePacks_JavaSourceHash32(void)
{
    return 0x00291B3DUL;
}
