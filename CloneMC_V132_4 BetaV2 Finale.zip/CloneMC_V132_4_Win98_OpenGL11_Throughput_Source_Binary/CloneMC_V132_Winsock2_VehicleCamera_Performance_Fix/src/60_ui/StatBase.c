/*
 * CloneMC Java port scaffold: StatBase
 *
 * Java source: StatBase.java
 * Java type: class StatBase
 * Package: net.minecraft.src
 * Assigned subsystem: src/60_ui
 * Mapping reason: client shell, GUI, input option, localization, statistic, or sound class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 243156e3d4b95d6fb386229187900251439a841b9a31d529a327ceb943e87e96
 * Java lines: 92
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: StatList, AchievementMap, IStatType, StatTypeSimple, StatTypeTime, StatTypeDistance, s
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final int statId
 * - public final String statName
 * - public boolean field_27088_g
 * - public String statGuid
 * - private final IStatType field_26902_a
 * - private static NumberFormat field_26903_b
 *
 * Java method/constructor inventory:
 * - public StatBase(int i, String s, IStatType istattype)
 * - public StatBase(int i, String s)
 * - public StatBase func_27082_h()
 * - public StatBase registerStat()
 * - public boolean func_25067_a()
 * - public String func_27084_a(int i)
 * - public String toString()
 * - public static IStatType field_27087_i = new StatTypeSimple()
 * - private static DecimalFormat field_26904_c = new DecimalFormat("########0.00")
 * - public static IStatType field_27086_j = new StatTypeTime()
 * - public static IStatType field_27085_k = new StatTypeDistance()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_60_ui.h"

void CloneMCJ_StatBase_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_StatBase_JavaName(void)
{
    return "net.minecraft.src.StatBase";
}

const char *CloneMCJ_StatBase_AssignedFolder(void)
{
    return "src/60_ui";
}

unsigned long CloneMCJ_StatBase_JavaSourceHash32(void)
{
    return 0x243156E3UL;
}
