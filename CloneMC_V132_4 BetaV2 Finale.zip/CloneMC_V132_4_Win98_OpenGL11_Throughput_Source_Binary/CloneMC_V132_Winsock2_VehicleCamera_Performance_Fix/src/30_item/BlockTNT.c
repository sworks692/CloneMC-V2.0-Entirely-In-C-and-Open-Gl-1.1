/*
 * CloneMC Java port scaffold: BlockTNT
 *
 * Java source: BlockTNT.java
 * Java type: class BlockTNT
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 7a3dbc9f4b65d6d56e8bbc25d65b25966b64444e1f5493afb02c674b90791eed
 * Java lines: 98
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: Block, Material, World, EntityTNTPrimed, ItemStack, EntityPlayer, Item, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockTNT(int i, int j)
 * - public int getBlockTextureFromSide(int i)
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public int quantityDropped(Random random)
 * - public void onBlockDestroyedByExplosion(World world, int i, int j, int k)
 * - public void onBlockDestroyedByPlayer(World world, int i, int j, int k, int l)
 * - public void onBlockClicked(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockTNT_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockTNT_JavaName(void)
{
    return "net.minecraft.src.BlockTNT";
}

const char *CloneMCJ_BlockTNT_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockTNT_JavaSourceHash32(void)
{
    return 0x7A3DBC9FUL;
}
