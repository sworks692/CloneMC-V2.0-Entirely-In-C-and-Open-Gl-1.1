/*
 * CloneMC Java port scaffold: ItemFood
 *
 * Java source: ItemFood.java
 * Java type: class ItemFood
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: d00ab65ae5730a070d45a7a041d863d485bd3c3c55ad2430f14604177e0fba49
 * Java lines: 42
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: Item, ItemStack, EntityPlayer, World
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int healAmount
 * - private boolean isWolfsFavoriteMeat
 *
 * Java method/constructor inventory:
 * - public ItemFood(int i, int j, boolean flag)
 * - public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
 * - public int getHealAmount()
 * - public boolean getIsWolfsFavoriteMeat()
 *
 * Direct conversion: the uploaded Java onItemRightClick/getHealAmount/
 * getIsWolfsFavoriteMeat behavior is represented by the item registry and this
 * bounded native use operation.
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"

int CloneMCJ_ItemFood_Use(CloneMCJ_ItemStack *stack,CloneMCJ_EntityPlayer *player)
{
    const CloneMCJ_ItemDefinition *item;
    int oldHealth;
    if(!stack||!player||CloneMCJ_ItemStack_IsEmpty(stack))return 0;
    item=CloneMCJ_ItemRegistry_Get(stack->itemID);
    if(!item||item->healAmount<=0)return 0;
    oldHealth=player->health;
    player->health+=item->healAmount;
    if(player->health>20)player->health=20;
    --stack->stackSize;
    if(stack->stackSize<=0){
        if(stack->itemID==282)CloneMCJ_ItemStack_Initialize(stack,281,1,0);
        else CloneMCJ_ItemStack_Clear(stack);
    }
    player->inventory.inventoryChanged=1;
    return player->health-oldHealth;
}

void CloneMCJ_ItemFood_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemFood_JavaName(void)
{
    return "net.minecraft.src.ItemFood";
}

const char *CloneMCJ_ItemFood_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemFood_JavaSourceHash32(void)
{
    return 0xD00AB65AUL;
}
