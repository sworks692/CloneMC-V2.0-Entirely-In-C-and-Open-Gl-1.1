/*
 * CloneMC Java port scaffold: BlockLeaves
 *
 * Java source: BlockLeaves.java
 * Java type: class BlockLeaves
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockLeavesBase
 * Implements: (none declared)
 * Source SHA-256: 614bada6f87be264736829866732caba0360e1f0614275b3a9c09ea43c8a59bb
 * Java lines: 250
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 14
 * Referenced Java classes: BlockLeavesBase, Material, ColorizerFoliage, IBlockAccess, WorldChunkManager, World, Block, EntityPlayer, ItemStack, Item, ItemShears, StatList, Entity, j, Material.leaves, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int baseIndexInPNG
 *
 * Java method/constructor inventory:
 * - protected BlockLeaves(int i, int j)
 * - public int getRenderColor(int i)
 * - public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
 * - public void onBlockRemoval(World world, int i, int j, int k)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - private void removeLeaves(World world, int i, int j, int k)
 * - public int quantityDropped(Random random)
 * - public int idDropped(int i, Random random)
 * - public void harvestBlock(World world, EntityPlayer entityplayer, int i, int j, int k, int l)
 * - protected int damageDropped(int i)
 * - public boolean isOpaqueCube()
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public void setGraphicsLevel(boolean flag)
 * - public void onEntityWalking(World world, int i, int j, int k, Entity entity)
 *
 * Priority 11 directly implements Java log-removal marking and four-block leaf
 * connectivity/decay below with a fixed, bounded native queue.
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_BlockLeaves_Removed(CloneMCJ_World *world, int x, int y, int z)
{
    int dx;
    int dy;
    int dz;
    int metadata;
    if (!world) return;
    for (dx = -1; dx <= 1; ++dx) for (dy = -1; dy <= 1; ++dy)
        for (dz = -1; dz <= 1; ++dz)
            if (CloneMCJ_World_GetBlockId(world, x + dx, y + dy, z + dz) == 18) {
                metadata = CloneMCJ_World_GetBlockMetadata(world, x + dx, y + dy, z + dz);
                CloneMCJ_World_SetBlockMetadata(world, x + dx, y + dy, z + dz,
                    metadata | 8);
            }
}

static void CloneMCJ_BlockLog_Removed(CloneMCJ_World *world, int x, int y, int z)
{
    int dx;
    int dy;
    int dz;
    int metadata;
    if (!world) return;
    for (dx = -4; dx <= 4; ++dx) for (dy = -4; dy <= 4; ++dy)
        for (dz = -4; dz <= 4; ++dz)
            if (CloneMCJ_World_GetBlockId(world, x + dx, y + dy, z + dz) == 18) {
                metadata = CloneMCJ_World_GetBlockMetadata(world, x + dx, y + dy, z + dz);
                if ((metadata & 8) == 0) CloneMCJ_World_SetBlockMetadata(world,
                    x + dx, y + dy, z + dz, metadata | 8);
            }
}

static int CloneMCJ_BlockLeaves_ConnectedToWood(CloneMCJ_World *world, int x,
    int y, int z)
{
    int qx[729], qy[729], qz[729], distance[729];
    int head;
    int tail;
    int i;
    int nx;
    int ny;
    int nz;
    int direction;
    int duplicate;
    qx[0] = x; qy[0] = y; qz[0] = z; distance[0] = 0;
    head = 0; tail = 1;
    while (head < tail) {
        if (CloneMCJ_World_GetBlockId(world, qx[head], qy[head], qz[head]) == 17) return 1;
        if (distance[head] < 4) for (direction = 0; direction < 6; ++direction) {
            nx = qx[head] + (direction == 0 ? -1 : direction == 1 ? 1 : 0);
            ny = qy[head] + (direction == 2 ? -1 : direction == 3 ? 1 : 0);
            nz = qz[head] + (direction == 4 ? -1 : direction == 5 ? 1 : 0);
            if (CloneMCJ_World_GetBlockId(world, nx, ny, nz) != 17 &&
                CloneMCJ_World_GetBlockId(world, nx, ny, nz) != 18) continue;
            duplicate = 0;
            for (i = 0; i < tail; ++i) if (qx[i] == nx && qy[i] == ny && qz[i] == nz) {
                duplicate = 1; break;
            }
            if (!duplicate && tail < 729) {
                qx[tail] = nx; qy[tail] = ny; qz[tail] = nz;
                distance[tail] = distance[head] + 1; ++tail;
            }
        }
        ++head;
    }
    return 0;
}

static void CloneMCJ_BlockLeaves_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int metadata;
    CloneMCJ_GameplayState *gameplay;
    CloneMCJ_ItemStack drop;
    (void)blockID; (void)userData;
    if (!world || world->multiplayerWorld) return;
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if ((metadata & 8) == 0) return;
    if (CloneMCJ_BlockLeaves_ConnectedToWood(world, x, y, z))
        CloneMCJ_World_SetBlockMetadata(world, x, y, z, metadata & ~8);
    else {
        /* BlockLeaves.removeLeaves calls dropBlockAsItem before removing the
         * leaf.  Keep the Beta sapling roll and the later independent oak
         * apple roll in that order. */
        gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
        if(gameplay&&random){
            if(CloneMCJ_Block_GetDroppedStack(18,metadata,random,&drop))
                (void)CloneMCJ_Gameplay_SpawnDrop(gameplay,(double)x+0.5,
                    (double)y+0.5,(double)z+0.5,&drop,10,0);
            if(CloneMCJ_Block_GetAdditionalDroppedStack(18,metadata,random,
                &drop))
                (void)CloneMCJ_Gameplay_SpawnDrop(gameplay,(double)x+0.5,
                    (double)y+0.5,(double)z+0.5,&drop,10,0);
        }
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
    }
}

void CloneMCJ_BlockLeaves_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(18);
    if (block) { block->tickRandomly = 1; block->onBlockRemoved = CloneMCJ_BlockLeaves_Removed; }
    block = CloneMCJ_BlockRegistry_GetMutable(17);
    if (block) block->onBlockRemoved = CloneMCJ_BlockLog_Removed;
    CloneMCJ_World_RegisterBlockTick(world, 18, 1, CloneMCJ_BlockLeaves_UpdateTick, 0);
}

void CloneMCJ_BlockLeaves_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockLeaves_JavaName(void)
{
    return "net.minecraft.src.BlockLeaves";
}

const char *CloneMCJ_BlockLeaves_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockLeaves_JavaSourceHash32(void)
{
    return 0x614BADA6UL;
}
