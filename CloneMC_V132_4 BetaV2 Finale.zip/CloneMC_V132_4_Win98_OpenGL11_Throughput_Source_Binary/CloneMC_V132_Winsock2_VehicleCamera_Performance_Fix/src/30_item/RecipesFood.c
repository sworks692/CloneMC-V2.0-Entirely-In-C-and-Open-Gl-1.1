/*
 * Direct C89 recipe registrations ported from RecipesFood.java.
 */
#include "clonemc_java_port_30_item.h"

static const short g_cloneMCRecipesFoodRecipeData[][25] = {
    {1, 282, 0, 1, 1, 3, 3, 40, -1, 39, -1, 281, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 282, 0, 1, 1, 3, 3, 39, -1, 40, -1, 281, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 357, 0, 8, 3, 1, 3, 296, 0, 351, 3, 296, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void CloneMCJ_RecipesFood_AddNative(void)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int recipeIndex;
    int ingredientIndex;
    const short *data;
    for (recipeIndex = 0; recipeIndex < (int)(sizeof(g_cloneMCRecipesFoodRecipeData) /
        sizeof(g_cloneMCRecipesFoodRecipeData[0])); ++recipeIndex) {
        data = g_cloneMCRecipesFoodRecipeData[recipeIndex];
        CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
        for (ingredientIndex = 0;
             ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
             ++ingredientIndex) {
            ingredients[ingredientIndex].itemID =
                data[7 + ingredientIndex * 2];
            ingredients[ingredientIndex].itemDamage =
                data[8 + ingredientIndex * 2];
        }
        if (data[0])
            CloneMCJ_CraftingManager_AddShapedNative(&output,
                data[4], data[5], ingredients);
        else
            CloneMCJ_CraftingManager_AddShapelessNative(&output,
                data[6], ingredients);
    }
}

void CloneMCJ_RecipesFood_Register(void) { }
const char *CloneMCJ_RecipesFood_JavaName(void)
{ return "net.minecraft.src.RecipesFood"; }
const char *CloneMCJ_RecipesFood_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipesFood_JavaSourceHash32(void)
{ return 0x2600FAEEUL; }
