/*
 * CloneMC Java port scaffold: BlockFence
 *
 * Java source: BlockFence.java
 * Java type: class BlockFence
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 52c65732ec8fd6b76653888e175fe253da0d054d0507060fbe2ff833a3cb1602
 * Java lines: 54
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: Block, Material, World, AxisAlignedBB, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockFence(int i, int j)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public int getRenderType()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockFence_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockFence_JavaName(void)
{
    return "net.minecraft.src.BlockFence";
}

const char *CloneMCJ_BlockFence_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockFence_JavaSourceHash32(void)
{
    return 0x52C65732UL;
}
