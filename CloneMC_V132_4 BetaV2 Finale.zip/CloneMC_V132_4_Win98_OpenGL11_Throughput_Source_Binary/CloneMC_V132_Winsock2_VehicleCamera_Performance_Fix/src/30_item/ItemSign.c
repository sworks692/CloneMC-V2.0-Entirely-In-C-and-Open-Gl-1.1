/*
 * CloneMC Java port scaffold: ItemSign
 *
 * Java source: ItemSign.java
 * Java type: class ItemSign
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: a769caf5f90c71ab89339d1ebd78fd698e624acef4096480197aefef7d0310c6
 * Java lines: 71
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, World, Material, Block, EntityPlayer, MathHelper, ItemStack, TileEntitySign, j, i, k, Block.signPost.blockID, Block.signWall.blockID
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemSign(int i)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemSign_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemSign_JavaName(void)
{
    return "net.minecraft.src.ItemSign";
}

const char *CloneMCJ_ItemSign_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemSign_JavaSourceHash32(void)
{
    return 0xA769CAF5UL;
}
