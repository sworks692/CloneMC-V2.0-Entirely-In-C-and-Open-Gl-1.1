/*
 * CloneMC Java port scaffold: ItemCookie
 *
 * Java source: ItemCookie.java
 * Java type: class ItemCookie
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemFood
 * Implements: (none declared)
 * Source SHA-256: c1ed98fbbcfa1587ccb6369c66772d458500b9c458e79d2b8c4cf24847359c78
 * Java lines: 20
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: ItemFood, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemCookie(int i, int j, boolean flag, int k)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemCookie_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemCookie_JavaName(void)
{
    return "net.minecraft.src.ItemCookie";
}

const char *CloneMCJ_ItemCookie_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemCookie_JavaSourceHash32(void)
{
    return 0xC1ED98FBUL;
}
