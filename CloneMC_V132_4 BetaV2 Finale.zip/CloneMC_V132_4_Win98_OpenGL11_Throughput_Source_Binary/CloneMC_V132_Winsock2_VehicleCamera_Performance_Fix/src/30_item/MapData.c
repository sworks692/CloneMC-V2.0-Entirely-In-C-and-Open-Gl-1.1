/*
 * CloneMC Java port scaffold: MapData
 *
 * Java source: MapData.java
 * Java type: class MapData
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: MapDataBase
 * Implements: (none declared)
 * Source SHA-256: 4e59df166d407267cbfc0eac306f03b7889ef8fc925ca1754c1ce81f8f296593
 * Java lines: 181
 * Discovered declared fields: 9
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: MapDataBase, NBTTagCompound, MapInfo, EntityPlayer, InventoryPlayer, MapCoord, ItemStack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int field_28180_b
 * - public int field_28179_c
 * - public byte field_28178_d
 * - public byte field_28177_e
 * - public byte field_28176_f[]
 * - public int field_28175_g
 * - public List field_28174_h
 * - private Map field_28172_j
 * - public List field_28173_i
 *
 * Java method/constructor inventory:
 * - public MapData(String s)
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 * - public void func_28169_a(EntityPlayer entityplayer, ItemStack itemstack)
 * - public void func_28170_a(int i, int j, int k)
 * - public void func_28171_a(byte abyte0[])
 *
 * Native implementation preserves the 128x128 color store, NBT schema,
 * per-player dirty ranges/decorations and packet update formats.
 */
#include "clonemc_java_port_30_item.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include <stdlib.h>
#include <string.h>

static void CloneMCJ_MapData_ReadBase(CloneMCJ_MapDataBase *base,
    const CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_MapData *map;
    const unsigned char *source;
    CloneMCJInt sourceLength;
    int width,height,offsetX,offsetY,x,y,sourceIndex,destinationIndex;
    if(!base||!compound)return;
    map=(CloneMCJ_MapData *)base;
    map->dimension=CloneMCJ_NBTTagCompound_GetByte(compound,"dimension");
    map->xCenter=CloneMCJ_NBTTagCompound_GetInteger(compound,"xCenter");
    map->zCenter=CloneMCJ_NBTTagCompound_GetInteger(compound,"zCenter");
    map->scale=CloneMCJ_NBTTagCompound_GetByte(compound,"scale");
    if(map->scale<0)map->scale=0;if(map->scale>4)map->scale=4;
    width=CloneMCJ_NBTTagCompound_GetShort(compound,"width");
    height=CloneMCJ_NBTTagCompound_GetShort(compound,"height");
    source=CloneMCJ_NBTTagCompound_GetByteArray(compound,"colors",
        &sourceLength);
    memset(map->colors,0,sizeof(map->colors));
    if(!source||sourceLength<=0)return;
    if(width==128&&height==128){
        if(sourceLength>CLONEMC_J_MAP_PIXELS)
            sourceLength=CLONEMC_J_MAP_PIXELS;
        memcpy(map->colors,source,(size_t)sourceLength);
        return;
    }
    if(width<1||height<1||width>512||height>512)return;
    offsetX=(128-width)/2;offsetY=(128-height)/2;
    for(y=0;y<height;++y)for(x=0;x<width;++x){
        sourceIndex=x+y*width;
        if(sourceIndex>=sourceLength)break;
        destinationIndex=x+offsetX+(y+offsetY)*128;
        if(x+offsetX>=0&&x+offsetX<128&&y+offsetY>=0&&
           y+offsetY<128)
            map->colors[destinationIndex]=source[sourceIndex];
    }
}

static void CloneMCJ_MapData_WriteBase(const CloneMCJ_MapDataBase *base,
    CloneMCJ_NBTTagCompound *compound)
{
    const CloneMCJ_MapData *map;
    if(!base||!compound)return;
    map=(const CloneMCJ_MapData *)base;
    CloneMCJ_NBTTagCompound_SetByte(compound,"dimension",map->dimension);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"xCenter",map->xCenter);
    CloneMCJ_NBTTagCompound_SetInteger(compound,"zCenter",map->zCenter);
    CloneMCJ_NBTTagCompound_SetByte(compound,"scale",map->scale);
    CloneMCJ_NBTTagCompound_SetShort(compound,"width",128);
    CloneMCJ_NBTTagCompound_SetShort(compound,"height",128);
    CloneMCJ_NBTTagCompound_SetByteArray(compound,"colors",map->colors,
        CLONEMC_J_MAP_PIXELS);
}

static void CloneMCJ_MapData_DestroyBase(CloneMCJ_MapDataBase *base)
{
    free(base);
}

CloneMCJ_MapData *CloneMCJ_MapData_Create(const char *name)
{
    CloneMCJ_MapData *map;
    map=(CloneMCJ_MapData *)calloc(1,sizeof(*map));
    if(!map)return 0;
    CloneMCJ_MapDataBase_Initialize(&map->base,name,
        CloneMCJ_MapData_ReadBase,CloneMCJ_MapData_WriteBase,
        CloneMCJ_MapData_DestroyBase);
    return map;
}

CloneMCJ_MapDataBase *CloneMCJ_MapData_Factory(const char *name,
    void *userData)
{
    (void)userData;
    return (CloneMCJ_MapDataBase *)CloneMCJ_MapData_Create(name);
}

static int CloneMCJ_MapData_PlayerCarries(const CloneMCJ_EntityPlayer *player,
    const CloneMCJ_ItemStack *mapStack)
{
    int index;
    if(!player||!mapStack)return 0;
    for(index=0;index<CLONEMC_J_MAIN_INVENTORY_SIZE;++index)
        if(player->inventory.mainInventory[index].itemID==mapStack->itemID&&
           player->inventory.mainInventory[index].itemDamage==
            mapStack->itemDamage&&
           player->inventory.mainInventory[index].stackSize>0)return 1;
    return 0;
}

void CloneMCJ_MapData_UpdatePlayer(CloneMCJ_MapData *map,
    CloneMCJ_EntityPlayer *player,const CloneMCJ_ItemStack *mapStack)
{
    CloneMCJ_MapInfo *info;
    CloneMCJ_EntityPlayer *tracked;
    float relativeX,relativeZ;
    int index,writeIndex,scale,rotation,tick;
    CloneMCJByte markerX,markerZ,markerRotation;
    if(!map||!player||!mapStack)return;
    info=0;
    for(index=0;index<map->observerCount;++index)
        if(map->observers[index].player==player)info=&map->observers[index];
    if(!info&&map->observerCount<CLONEMC_J_MAP_MAX_TRACKED_PLAYERS){
        info=&map->observers[map->observerCount++];
        CloneMCJ_MapInfo_Initialize(info,player);
    }
    map->decorationCount=0;writeIndex=0;
    for(index=0;index<map->observerCount;++index){
        tracked=map->observers[index].player;
        if(!tracked||tracked->entity.isDead||
           !CloneMCJ_MapData_PlayerCarries(tracked,mapStack))continue;
        if(writeIndex!=index)map->observers[writeIndex]=map->observers[index];
        info=&map->observers[writeIndex++];
        scale=1<<map->scale;
        relativeX=(float)(tracked->entity.posX-(double)map->xCenter)/
            (float)scale;
        relativeZ=(float)(tracked->entity.posZ-(double)map->zCenter)/
            (float)scale;
        if(relativeX<-64.0F||relativeZ<-64.0F||relativeX>64.0F||
           relativeZ>64.0F||tracked->dimension!=map->dimension||
           map->decorationCount>=CLONEMC_J_MAP_MAX_DECORATIONS)continue;
        markerX=CloneMCJava_CastByte((CloneMCJInt)
            ((double)(relativeX*2.0F)+0.5));
        markerZ=CloneMCJava_CastByte((CloneMCJInt)
            ((double)(relativeZ*2.0F)+0.5));
        rotation=(int)((double)((tracked->entity.rotationYaw*16.0F)/
            360.0F)+0.5);
        if(map->dimension<0){
            tick=map->updateCounter/10;
            rotation=(CloneMCJava_AddInt(
                CloneMCJava_MulInt(CloneMCJava_MulInt(tick,tick),
                    (CloneMCJInt)0x0209A771L),
                CloneMCJava_MulInt(tick,121))>>15)&15;
        }
        markerRotation=CloneMCJava_CastByte((CloneMCJInt)rotation);
        CloneMCJ_MapCoord_Initialize(
            &map->decorations[map->decorationCount++],0,markerX,markerZ,
            markerRotation);
    }
    map->observerCount=writeIndex;
}

void CloneMCJ_MapData_MarkDirtyColumn(CloneMCJ_MapData *map,int column,
    int minimum,int maximum)
{
    int index;
    if(!map||column<0||column>=128)return;
    if(minimum<0)minimum=0;if(maximum>127)maximum=127;
    if(minimum>maximum)return;
    CloneMCJ_MapDataBase_MarkDirty(&map->base);
    for(index=0;index<map->observerCount;++index){
        if(map->observers[index].minDirty[column]<0||
           map->observers[index].minDirty[column]>minimum)
            map->observers[index].minDirty[column]=minimum;
        if(map->observers[index].maxDirty[column]<0||
           map->observers[index].maxDirty[column]<maximum)
            map->observers[index].maxDirty[column]=maximum;
    }
}

int CloneMCJ_MapData_ApplyPacket(CloneMCJ_MapData *map,
    const unsigned char *data,int length)
{
    int column,start,count,index,packed;
    if(!map||!data||length<1)return 0;
    if(data[0]==0){
        if(length<3)return 0;
        column=data[1];start=data[2];count=length-3;
        if(column>=128||start>=128||count>128-start)return 0;
        for(index=0;index<count;++index)
            map->colors[(start+index)*128+column]=data[index+3];
        CloneMCJ_MapData_MarkDirtyColumn(map,column,start,start+count-1);
        return 1;
    }
    if(data[0]==1){
        if((length-1)%3!=0)return 0;
        map->decorationCount=0;
        for(index=0;index<(length-1)/3&&
            map->decorationCount<CLONEMC_J_MAP_MAX_DECORATIONS;++index){
            packed=data[index*3+1];
            CloneMCJ_MapCoord_Initialize(
                &map->decorations[map->decorationCount++],
                CloneMCJava_CastByte(packed%16),
                CloneMCJava_CastByte(data[index*3+2]),
                CloneMCJava_CastByte(data[index*3+3]),
                CloneMCJava_CastByte(packed/16));
        }
        return 1;
    }
    return 0;
}

int CloneMCJ_MapPipeline_RunSelfTests(char *message,unsigned int capacity)
{
    CloneMCJ_MapData *source,*decoded;
    CloneMCJ_NBTTagCompound *compound;
    unsigned char update[7];
    int ok;
    source=CloneMCJ_MapData_Create("map_7");
    decoded=CloneMCJ_MapData_Create("map_7");
    compound=CloneMCJ_NBTTagCompound_Create();
    ok=source&&decoded&&compound;
    if(ok){
        source->dimension=-1;source->xCenter=-320;source->zCenter=704;
        source->scale=3;source->colors[5+9*128]=47;
        source->base.writeToNBT(&source->base,compound);
        decoded->base.readFromNBT(&decoded->base,compound);
        ok=decoded->dimension==-1&&decoded->xCenter==-320&&
            decoded->zCenter==704&&decoded->scale==3&&
            decoded->colors[5+9*128]==47;
    }
    update[0]=0;update[1]=5;update[2]=9;
    update[3]=12;update[4]=13;update[5]=14;update[6]=15;
    if(ok)ok=CloneMCJ_MapData_ApplyPacket(decoded,update,7)&&
        decoded->colors[5+9*128]==12&&
        decoded->colors[5+12*128]==15&&decoded->base.dirty;
    if(compound)CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)compound);
    if(source)source->base.destroy(&source->base);
    if(decoded)decoded->base.destroy(&decoded->base);
    if(message&&capacity){
        const char *text;
        text=ok?"Map NBT and packet parity tests passed":
            "Map parity test failed";
        strncpy(message,text,(size_t)capacity-1U);
        message[capacity-1U]='\0';
    }
    return ok;
}

void CloneMCJ_MapData_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MapData_JavaName(void)
{
    return "net.minecraft.src.MapData";
}

const char *CloneMCJ_MapData_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_MapData_JavaSourceHash32(void)
{
    return 0x4E59DF16UL;
}
