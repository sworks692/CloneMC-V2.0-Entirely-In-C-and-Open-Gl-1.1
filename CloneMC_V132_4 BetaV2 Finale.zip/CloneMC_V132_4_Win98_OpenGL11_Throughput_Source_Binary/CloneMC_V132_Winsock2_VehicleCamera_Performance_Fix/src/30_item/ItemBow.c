/*
 * CloneMC Java port scaffold: ItemBow
 *
 * Java source: ItemBow.java
 * Java type: class ItemBow
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: f0f9e1344bf61aff7e17eaf616f6fc9a81063760fe17a752a2d356fdb6b8eaf6
 * Java lines: 35
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, EntityPlayer, InventoryPlayer, World, EntityArrow, ItemStack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemBow(int i)
 * - public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemBow_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemBow_JavaName(void)
{
    return "net.minecraft.src.ItemBow";
}

const char *CloneMCJ_ItemBow_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemBow_JavaSourceHash32(void)
{
    return 0xF0F9E134UL;
}
