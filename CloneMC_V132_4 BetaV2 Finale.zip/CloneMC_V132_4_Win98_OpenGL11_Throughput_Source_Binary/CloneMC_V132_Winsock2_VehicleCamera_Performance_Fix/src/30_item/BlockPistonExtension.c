/*
 * CloneMC Java port scaffold: BlockPistonExtension
 *
 * Java source: BlockPistonExtension.java
 * Java type: class BlockPistonExtension
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 159d46b5036908f6b22ca6bdd31f1fdf247ac185b5b449b81e9cb15515967786
 * Java lines: 206
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: Block, Material, World, PistonBlockTextures, BlockPistonBase, IBlockAccess, AxisAlignedBB, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_31053_a
 *
 * Java method/constructor inventory:
 * - public BlockPistonExtension(int i, int j)
 * - public void func_31052_a_(int i)
 * - public void func_31051_a()
 * - public void onBlockRemoval(World world, int i, int j, int k)
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public int getRenderType()
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public boolean canPlaceBlockOnSide(World world, int i, int j, int k, int l)
 * - public int quantityDropped(Random random)
 * - public void getCollidingBoundingBoxes(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, ArrayList arraylist)
 * - public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public static int func_31050_c(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockPistonExtension_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockPistonExtension_JavaName(void)
{
    return "net.minecraft.src.BlockPistonExtension";
}

const char *CloneMCJ_BlockPistonExtension_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockPistonExtension_JavaSourceHash32(void)
{
    return 0x159D46B5UL;
}
