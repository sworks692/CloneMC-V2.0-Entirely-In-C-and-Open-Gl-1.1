/*
 * CloneMC Java port scaffold: Slot
 *
 * Java source: Slot.java
 * Java type: class Slot
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 4e74afa297167b4bba2a795962f389f941e7c5bd37afb7fda04b066ad4d76b3e
 * Java lines: 74
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: IInventory, ItemStack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final int slotIndex
 * - private final IInventory inventory
 * - public int slotNumber
 * - public int xDisplayPosition
 * - public int yDisplayPosition
 *
 * Java method/constructor inventory:
 * - public Slot(IInventory iinventory, int i, int j, int k)
 * - public void onPickupFromSlot(ItemStack itemstack)
 * - public boolean isItemValid(ItemStack itemstack)
 * - public ItemStack getStack()
 * - public boolean getHasStack()
 * - public void putStack(ItemStack itemstack)
 * - public void onSlotChanged()
 * - public int getSlotStackLimit()
 * - public int getBackgroundIconIndex()
 * - public ItemStack decrStackSize(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_Slot_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Slot_JavaName(void)
{
    return "net.minecraft.src.Slot";
}

const char *CloneMCJ_Slot_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_Slot_JavaSourceHash32(void)
{
    return 0x4E74AFA2UL;
}
