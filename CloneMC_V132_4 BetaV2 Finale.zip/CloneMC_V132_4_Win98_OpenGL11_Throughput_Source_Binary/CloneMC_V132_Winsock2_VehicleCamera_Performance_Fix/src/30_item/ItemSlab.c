/*
 * CloneMC Java port scaffold: ItemSlab
 *
 * Java source: ItemSlab.java
 * Java type: class ItemSlab
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemBlock
 * Implements: (none declared)
 * Source SHA-256: 70250597080cc008a513d207e8da832ade57bd190afcc914a51c398818e65d5e
 * Java lines: 36
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: ItemBlock, Block, BlockStep, ItemStack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemSlab(int i)
 * - public int getIconFromDamage(int i)
 * - public int getPlacedBlockMetadata(int i)
 * - public String getItemNameIS(ItemStack itemstack)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemSlab_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemSlab_JavaName(void)
{
    return "net.minecraft.src.ItemSlab";
}

const char *CloneMCJ_ItemSlab_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemSlab_JavaSourceHash32(void)
{
    return 0x70250597UL;
}
