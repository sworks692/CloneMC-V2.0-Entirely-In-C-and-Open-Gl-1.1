/*
 * CloneMC Java port scaffold: ItemBlock
 *
 * Java source: ItemBlock.java
 * Java type: class ItemBlock
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 37cf0072956819e9d661fc8f21fb8a06870d0c8b5d41e97ace0146027a156310
 * Java lines: 91
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: Item, Block, World, ItemStack, Material, StepSound, EntityPlayer, j, i, k, false, blockID
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int blockID
 *
 * Java method/constructor inventory:
 * - public ItemBlock(int i)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 * - public String getItemNameIS(ItemStack itemstack)
 * - public String getItemName()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemBlock_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemBlock_JavaName(void)
{
    return "net.minecraft.src.ItemBlock";
}

const char *CloneMCJ_ItemBlock_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemBlock_JavaSourceHash32(void)
{
    return 0x37CF0072UL;
}
