/* Direct bounded C89 port of Beta BlockPistonBase.java.
 * Blocks move through block 36 + TileEntityPiston instead of teleporting. */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static const signed char g_pistonDX[6]={0,0,0,0,-1,1};
static const signed char g_pistonDY[6]={-1,1,0,0,0,0};
static const signed char g_pistonDZ[6]={0,0,-1,1,0,0};
static unsigned char g_pistonUpdating;

static CloneMCJ_TileEntity *CloneMCJ_PistonTileAt(CloneMCJ_World *world,
    int x,int y,int z,CloneMCJ_Chunk **chunkOut)
{
    CloneMCJ_Chunk *chunk;
    chunk=CloneMCJ_World_GetChunkFromBlockCoords(world,x,z);
    if(chunkOut)*chunkOut=chunk;
    if(!chunk)return (CloneMCJ_TileEntity *)0;
    return (CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(chunk,x&15,y,z&15);
}

static int CloneMCJ_PistonInstallMoving(CloneMCJ_World *world,int x,int y,int z,
    int storedID,int storedMeta,int facing,int extending,int renderHead)
{
    CloneMCJ_Chunk *chunk;CloneMCJ_TileEntity *tile,*old;
    chunk=CloneMCJ_World_GetChunkFromBlockCoords(world,x,z);
    if(!chunk)return 0;
    old=(CloneMCJ_TileEntity *)CloneMCJ_Chunk_GetTileEntity(chunk,x&15,y,z&15);
    if(old){CloneMCJ_Chunk_RemoveTileEntity(chunk,x&15,y,z&15);CloneMCJ_TileEntity_Destroy(old);}
    if(!CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,36,storedMeta))return 0;
    tile=CloneMCJ_TileEntityPiston_Create(world,x,y,z,storedID,storedMeta,
        facing,extending,renderHead);
    if(!tile||!CloneMCJ_Chunk_SetTileEntity(chunk,x&15,y,z&15,tile)){
        if(tile)CloneMCJ_TileEntity_Destroy(tile);
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);return 0;
    }
    return 1;
}

static void CloneMCJ_PistonFinishMoving(CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_Chunk *chunk;CloneMCJ_TileEntity *tile;
    tile=CloneMCJ_PistonTileAt(world,x,y,z,&chunk);
    if(!tile||tile->type!=CLONEMC_J_TILE_PISTON)return;
    CloneMCJ_Chunk_RemoveTileEntity(chunk,x&15,y,z&15);
    CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,
        tile->pistonStoredBlockID,tile->pistonStoredMetadata);
    CloneMCJ_TileEntity_Destroy(tile);
}

static int CloneMCJ_PistonMobilityFlag(int id,const CloneMCJ_BlockDefinition *block)
{
    if(!block)return 2;
    /* Material.getMaterialMobility plus the Java block overrides. */
    if(id==26||id==64||id==71||id==70||id==72)return 1;
    if(id==27||id==28||id==66||id==79)return 0;
    if(id==90||id==34||id==36)return 2;
    if(id==18||id==30||id==51||id==78||id==81||id==83||
       id==86||id==91||id==92||id==96)return 1;
    if(block->material==CLONEMC_J_MATERIAL_WATER||
       block->material==CLONEMC_J_MATERIAL_LAVA||
       block->material==CLONEMC_J_MATERIAL_PLANT||
       block->material==CLONEMC_J_MATERIAL_CIRCUITS)return 1;
    return 0;
}

static int CloneMCJ_PistonCanMove(CloneMCJ_World *world,int x,int y,int z,
    int allowDestroy)
{
    const CloneMCJ_BlockDefinition *block;int id,meta,mobility;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);if(id==0)return 1;
    if(id==7||id==49||id==34||id==36)return 0;
    block=CloneMCJ_BlockRegistry_Get(id);
    if(!block||block->hardness<0.0F||block->hasTileEntity)return 0;
    meta=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if((id==29||id==33)&&(meta&8))return 0;
    mobility=CloneMCJ_PistonMobilityFlag(id,block);
    if(mobility==2)return 0;
    if(mobility==1&&!allowDestroy)return 0;
    return 1;
}

static int CloneMCJ_PistonPowered(CloneMCJ_World *world,int x,int y,int z,int facing)
{
    if(facing!=0&&CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y-1,z,0))return 1;
    if(facing!=1&&CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y+1,z,1))return 1;
    if(facing!=2&&CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y,z-1,2))return 1;
    if(facing!=3&&CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y,z+1,3))return 1;
    if(facing!=5&&CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x+1,y,z,5))return 1;
    if(facing!=4&&CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x-1,y,z,4))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y,z,0))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y+2,z,1))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y+1,z-1,2))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x,y+1,z+1,3))return 1;
    if(CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x-1,y+1,z,4))return 1;
    return CloneMCJ_World_IsBlockIndirectlyProvidingPowerTo(world,x+1,y+1,z,5);
}

static int CloneMCJ_PistonExtend(CloneMCJ_World *world,int x,int y,int z,
    int pistonID,int facing)
{
    int ids[12],metas[12],count,step,px,py,pz,id,headMeta;
    count=0;
    for(step=1;step<=13;++step){
        px=x+g_pistonDX[facing]*step;py=y+g_pistonDY[facing]*step;
        pz=z+g_pistonDZ[facing]*step;
        if(py<0||py>=CLONEMC_J_CHUNK_HEIGHT)return 0;
        id=CloneMCJ_World_GetBlockId(world,px,py,pz);
        if(id==0)break;
        if(!CloneMCJ_PistonCanMove(world,px,py,pz,1))return 0;
        if(CloneMCJ_PistonMobilityFlag(id,CloneMCJ_BlockRegistry_Get(id))==1){
            CloneMCJ_World_SetBlockNotify(world,px,py,pz,0);break;
        }
        if(count>=12)return 0;
        ids[count]=id;metas[count]=CloneMCJ_World_GetBlockMetadata(world,px,py,pz);++count;
    }
    if(step>13)return 0;
    for(step=1;step<=count;++step){
        px=x+g_pistonDX[facing]*step;py=y+g_pistonDY[facing]*step;
        pz=z+g_pistonDZ[facing]*step;CloneMCJ_World_SetBlockNotify(world,px,py,pz,0);
    }
    for(step=count;step>=1;--step){
        px=x+g_pistonDX[facing]*(step+1);py=y+g_pistonDY[facing]*(step+1);
        pz=z+g_pistonDZ[facing]*(step+1);
        if(!CloneMCJ_PistonInstallMoving(world,px,py,pz,ids[step-1],metas[step-1],facing,1,0))return 0;
    }
    px=x+g_pistonDX[facing];py=y+g_pistonDY[facing];pz=z+g_pistonDZ[facing];
    headMeta=facing|(pistonID==29?8:0);
    if(!CloneMCJ_PistonInstallMoving(world,px,py,pz,34,headMeta,facing,1,1))return 0;
    CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,facing|8);return 1;
}

static int CloneMCJ_PistonRetract(CloneMCJ_World *world,int x,int y,int z,
    int pistonID,int facing)
{
    int hx,hy,hz,sx,sy,sz,pullID,pullMeta;
    hx=x+g_pistonDX[facing];hy=y+g_pistonDY[facing];hz=z+g_pistonDZ[facing];
    if(CloneMCJ_World_GetBlockId(world,hx,hy,hz)==36)CloneMCJ_PistonFinishMoving(world,hx,hy,hz);
    CloneMCJ_World_SetBlockNotify(world,hx,hy,hz,0);
    if(!CloneMCJ_PistonInstallMoving(world,x,y,z,pistonID,facing,facing,0,1))return 0;
    if(pistonID==29){
        sx=x+g_pistonDX[facing]*2;sy=y+g_pistonDY[facing]*2;sz=z+g_pistonDZ[facing]*2;
        if(CloneMCJ_World_GetBlockId(world,sx,sy,sz)==36)CloneMCJ_PistonFinishMoving(world,sx,sy,sz);
        pullID=CloneMCJ_World_GetBlockId(world,sx,sy,sz);
        pullMeta=CloneMCJ_World_GetBlockMetadata(world,sx,sy,sz);
        if(pullID>0&&CloneMCJ_PistonCanMove(world,sx,sy,sz,0)){
            CloneMCJ_World_SetBlockNotify(world,sx,sy,sz,0);
            CloneMCJ_PistonInstallMoving(world,hx,hy,hz,pullID,pullMeta,facing,0,0);
        }
    }
    return 1;
}

static void CloneMCJ_PistonUpdate(CloneMCJ_World *world,int x,int y,int z)
{
    int id,metadata,facing,powered,extended;
    if(!world||world->multiplayerWorld||g_pistonUpdating)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);if(id!=29&&id!=33)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);facing=metadata&7;
    if(facing>5||facing==7)return;
    powered=CloneMCJ_PistonPowered(world,x,y,z,facing);extended=(metadata&8)!=0;
    g_pistonUpdating=1;
    if(powered&&!extended)CloneMCJ_PistonExtend(world,x,y,z,id,facing);
    else if(!powered&&extended)CloneMCJ_PistonRetract(world,x,y,z,id,facing);
    g_pistonUpdating=0;
}
static void CloneMCJ_PistonNeighbor(CloneMCJ_World *world,int x,int y,int z,int neighbor)
{(void)neighbor;CloneMCJ_PistonUpdate(world,x,y,z);}
static void CloneMCJ_PistonAdded(CloneMCJ_World *world,int x,int y,int z)
{CloneMCJ_PistonUpdate(world,x,y,z);}
void CloneMCJ_BlockPistonBase_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;int id;(void)world;
    for(id=29;id<=33;id+=4){block=CloneMCJ_BlockRegistry_GetMutable(id);
        if(block){block->neighborChanged=CloneMCJ_PistonNeighbor;block->onBlockAdded=CloneMCJ_PistonAdded;}}
}
void CloneMCJ_BlockPistonBase_Register(void){}
const char *CloneMCJ_BlockPistonBase_JavaName(void){return "net.minecraft.src.BlockPistonBase";}
const char *CloneMCJ_BlockPistonBase_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockPistonBase_JavaSourceHash32(void){return 0x9628766FUL;}
