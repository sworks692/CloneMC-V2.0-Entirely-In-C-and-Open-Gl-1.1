/*
 * CloneMC Java port scaffold: TileEntity
 *
 * Java source: TileEntity.java
 * Java type: class TileEntity
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: e774b8723b40baa17e81ec444a3ff2d38775cbb43e42fa708dbfac167484ab41
 * Java lines: 161
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: NBTTagCompound, World, Block, TileEntityFurnace, TileEntityChest, TileEntityRecordPlayer, TileEntityDispenser, TileEntitySign, TileEntityMobSpawner, TileEntityNote, TileEntityPiston, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public World worldObj
 * - public int xCoord
 * - public int yCoord
 * - public int zCoord
 * - protected boolean field_31007_h
 *
 * Java method/constructor inventory:
 * - public TileEntity()
 * - private static void addMapping(Class class1, String s)
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 * - public void updateEntity()
 * - public static TileEntity createAndLoadEntity(NBTTagCompound nbttagcompound)
 * - public int getBlockMetadata()
 * - public void onInventoryChanged()
 * - public double getDistanceFrom(double d, double d1, double d2)
 * - public Block getBlockType()
 * - public boolean func_31006_g()
 * - public void func_31005_i()
 * - public void func_31004_j()
 * - private static Map nameToClassMap = new HashMap()
 * - private static Map classToNameMap = new HashMap()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_30_item.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

static int CloneMCJ_Furnace_FuelTime(const CloneMCJ_ItemStack *stack)
{
    return CloneMCJ_FurnaceRecipes_GetFuelTimeNative(stack);
}

static int CloneMCJ_Furnace_CanSmelt(const CloneMCJ_TileEntity *tile,
    CloneMCJ_ItemStack *result)
{
    return CloneMCJ_FurnaceRecipes_CanSmeltNative(tile, result);
}

static void CloneMCJ_Furnace_Smelt(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_FurnaceRecipes_SmeltOneNative(tile);
}

static CloneMCJ_GameplayState *CloneMCJ_TileEntity_Gameplay(CloneMCJ_TileEntity *tile)
{
    if (!tile || !tile->worldObj || !tile->worldObj->gameplayUserData)
        return (CloneMCJ_GameplayState *)0;
    return (CloneMCJ_GameplayState *)tile->worldObj->gameplayUserData;
}

static int CloneMCJ_TileEntity_PlayerInSpawnerRange(CloneMCJ_TileEntity *tile,
    CloneMCJ_GameplayState **stateOut)
{
    CloneMCJ_GameplayState *state;
    double dx, dy, dz;
    state = CloneMCJ_TileEntity_Gameplay(tile);
    if (stateOut) *stateOut = state;
    if (!state) return 0;
    dx = state->player.entity.posX - ((double)tile->xCoord + 0.5);
    dy = state->player.entity.posY - ((double)tile->yCoord + 0.5);
    dz = state->player.entity.posZ - ((double)tile->zCoord + 0.5);
    return dx * dx + dy * dy + dz * dz <= 256.0;
}

static int CloneMCJ_TileEntity_FindMobSlot(CloneMCJ_GameplayState *state)
{
    int index;
    if (!state) return -1;
    for (index = 0; index < CLONEMC_J_MAX_MOBS; ++index)
        if (!state->mobs[index].active) return index;
    return -1;
}

static int CloneMCJ_TileEntity_CountSpawnerMobs(const CloneMCJ_GameplayState *state,
    CloneMCJ_MobType type, int x, int y, int z)
{
    int index, count;
    double dx, dy, dz;
    count = 0;
    if (!state) return 0;
    for (index = 0; index < CLONEMC_J_MAX_MOBS; ++index) {
        if (!state->mobs[index].active || state->mobs[index].type != type) continue;
        dx = state->mobs[index].entity.posX - ((double)x + 0.5);
        dy = state->mobs[index].entity.posY - ((double)y + 0.5);
        dz = state->mobs[index].entity.posZ - ((double)z + 0.5);
        if (dx >= -8.0 && dx <= 8.0 && dy >= -4.0 && dy <= 4.0 &&
            dz >= -8.0 && dz <= 8.0) ++count;
    }
    return count;
}

static int CloneMCJ_TileEntity_CanSpawnerMobStand(CloneMCJ_World *world,
    CloneMCJ_MobType type, int x, int y, int z)
{
    const CloneMCJ_BlockDefinition *below;
    int block, above, belowID, light;
    if (!world || y < 1 || y >= CLONEMC_J_CHUNK_HEIGHT - 3) return 0;
    block = CloneMCJ_World_GetBlockId(world, x, y, z);
    above = CloneMCJ_World_GetBlockId(world, x, y + 1, z);
    belowID = CloneMCJ_World_GetBlockId(world, x, y - 1, z);
    if (type == CLONEMC_J_MOB_SQUID)
        return (block == 8 || block == 9) &&
            (above == 0 || above == 8 || above == 9);
    if (type == CLONEMC_J_MOB_GHAST)
        return block == 0 && above == 0 &&
            CloneMCJ_World_GetBlockId(world, x, y + 2, z) == 0 &&
            CloneMCJ_World_GetBlockId(world, x, y + 3, z) == 0;
    below = CloneMCJ_BlockRegistry_Get(belowID);
    if (!below || !below->solid || block != 0 || above != 0) return 0;
    if (!CloneMCJ_EntityLiving_IsHostileType(type)) {
        light = CloneMCJ_World_GetFullBlockLightValue(world, x, y, z);
        return belowID == 2 && light > 8;
    }
    light = CloneMCJ_World_GetBlockLightValue(world, x, y, z);
    return light <= 7;
}

static void CloneMCJ_TileEntity_ResetSpawnerDelay(CloneMCJ_TileEntity *tile)
{
    if (!tile || !tile->worldObj) return;
    tile->spawnDelay = 200 + CloneMCJavaRandom_NextIntBound(
        &tile->worldObj->rand, 600);
}

static void CloneMCJ_TileEntity_UpdateSpawner(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_GameplayState *state;
    CloneMCJ_MobType type;
    CloneMCJ_World *world;
    int attempt, slot, x, y, z, spawned;
    double spawnX, spawnY, spawnZ;
    tile->previousSpawnerYaw = tile->spawnerYaw;
    if (!CloneMCJ_TileEntity_PlayerInSpawnerRange(tile, &state)) return;
    world = tile->worldObj;
    tile->spawnerYaw += 1000.0 / ((double)tile->spawnDelay + 200.0);
    while (tile->spawnerYaw > 360.0) {
        tile->spawnerYaw -= 360.0;
        tile->previousSpawnerYaw -= 360.0;
    }
    if (!world || world->multiplayerWorld) return;
    if (tile->spawnDelay == -1) CloneMCJ_TileEntity_ResetSpawnerDelay(tile);
    if (tile->spawnDelay > 0) { --tile->spawnDelay; return; }
    if (!CloneMCJ_EntityList_MobTypeForName(tile->mobID, &type)) return;
    if (CloneMCJ_TileEntity_CountSpawnerMobs(state, type, tile->xCoord,
        tile->yCoord, tile->zCoord) >= 6) {
        CloneMCJ_TileEntity_ResetSpawnerDelay(tile);
        return;
    }
    spawned = 0;
    for (attempt = 0; attempt < 4; ++attempt) {
        spawnX = (double)tile->xCoord +
            (CloneMCJavaRandom_NextDouble(&world->rand) -
             CloneMCJavaRandom_NextDouble(&world->rand)) * 4.0;
        spawnY = (double)(tile->yCoord +
            CloneMCJavaRandom_NextIntBound(&world->rand, 3) - 1);
        spawnZ = (double)tile->zCoord +
            (CloneMCJavaRandom_NextDouble(&world->rand) -
             CloneMCJavaRandom_NextDouble(&world->rand)) * 4.0;
        x = CloneMCJava_FloorDouble(spawnX);
        y = CloneMCJava_FloorDouble(spawnY);
        z = CloneMCJava_FloorDouble(spawnZ);
        if (!CloneMCJ_TileEntity_CanSpawnerMobStand(world, type, x, y, z))
            continue;
        slot = CloneMCJ_TileEntity_FindMobSlot(state);
        if (slot < 0) break;
        CloneMCJ_EntityLiving_InitializeMob(&state->mobs[slot], type, world,
            spawnX, spawnY, spawnZ);
        state->mobs[slot].persistenceRequired = 0;
        state->mobs[slot].entity.rotationYaw =
            CloneMCJavaRandom_NextFloat(&world->rand) * 360.0F;
        state->mobs[slot].entity.prevRotationYaw =
            state->mobs[slot].entity.rotationYaw;
        if (state->nextEntityId <= state->mobs[slot].entity.entityId)
            state->nextEntityId = state->mobs[slot].entity.entityId + 1;
        ++spawned;
        if (CloneMCJ_TileEntity_CountSpawnerMobs(state, type, tile->xCoord,
            tile->yCoord, tile->zCoord) >= 6) break;
    }
    if (spawned || tile->spawnDelay <= 0)
        CloneMCJ_TileEntity_ResetSpawnerDelay(tile);
}

CloneMCJ_TileEntity *CloneMCJ_TileEntity_Create(CloneMCJ_TileEntityType type, CloneMCJ_World *world, int x, int y, int z)
{
    CloneMCJ_TileEntity *tile;
    int i;
    tile = (CloneMCJ_TileEntity *)malloc(sizeof(*tile));
    if (!tile) return (CloneMCJ_TileEntity *)0;
    memset(tile, 0, sizeof(*tile));
    tile->type = type;
    tile->worldObj = world;
    tile->xCoord = x;
    tile->yCoord = y;
    tile->zCoord = z;
    tile->itemCount = type == CLONEMC_J_TILE_FURNACE ? 3 :
                      type == CLONEMC_J_TILE_CHEST ? CLONEMC_J_CHEST_INVENTORY_SIZE :
                      type == CLONEMC_J_TILE_MOB_SPAWNER ? 0 : 9;
    tile->signLineBeingEdited = -1;
    if (type == CLONEMC_J_TILE_MOB_SPAWNER) {
        strcpy(tile->mobID, "Pig");
        tile->spawnDelay = 20;
        tile->spawnerYaw = 0.0;
        tile->previousSpawnerYaw = 0.0;
    }
    for (i = 0; i < CLONEMC_J_CHEST_INVENTORY_SIZE; ++i) CloneMCJ_ItemStack_Clear(&tile->items[i]);
    return tile;
}

void CloneMCJ_TileEntity_Destroy(CloneMCJ_TileEntity *tile)
{
    if (tile) free(tile);
}

static int CloneMCJ_TileEntityPiston_EntityIntersects(const CloneMCJ_Entity *entity,
    double minX,double minY,double minZ,double maxX,double maxY,double maxZ)
{
    CloneMCAxisAlignedBB movingBox;
    if(!entity||entity->isDead)return 0;
    movingBox=CloneMCAABB_Create(minX,minY,minZ,maxX,maxY,maxZ);
    return CloneMCAABB_Intersects(&entity->boundingBox,&movingBox);
}

static void CloneMCJ_TileEntityPiston_MoveEntityIfIntersecting(
    CloneMCJ_TileEntity *tile,CloneMCJ_Entity *entity,float progress,float amount)
{
    static const signed char dx[6]={0,0,0,0,-1,1};
    static const signed char dy[6]={-1,1,0,0,0,0};
    static const signed char dz[6]={0,0,-1,1,0,0};
    double multiplier,minX,minY,minZ,maxX,maxY,maxZ;
    int facing;
    if(!tile||!entity||!tile->pistonExtending||amount<=0.0F)return;
    facing=tile->pistonFacing;if(facing<0||facing>5)return;
    multiplier=(double)progress-1.0;
    minX=(double)tile->xCoord+multiplier*(double)dx[facing];
    minY=(double)tile->yCoord+multiplier*(double)dy[facing];
    minZ=(double)tile->zCoord+multiplier*(double)dz[facing];
    maxX=minX+1.0;maxY=minY+1.0;maxZ=minZ+1.0;
    if(CloneMCJ_TileEntityPiston_EntityIntersects(entity,minX,minY,minZ,maxX,maxY,maxZ))
        CloneMCJ_Entity_Move(entity,(double)amount*dx[facing],
            (double)amount*dy[facing],(double)amount*dz[facing]);
}

static void CloneMCJ_TileEntityPiston_PushEntities(CloneMCJ_TileEntity *tile,
    float progress,float amount)
{
    CloneMCJ_GameplayState *gameplay;int i;
    if(!tile||!tile->worldObj||!tile->pistonExtending)return;
    gameplay=(CloneMCJ_GameplayState *)tile->worldObj->gameplayUserData;
    if(!gameplay)return;
    CloneMCJ_TileEntityPiston_MoveEntityIfIntersecting(tile,&gameplay->player.entity,
        progress,amount);
    for(i=0;i<CLONEMC_J_MAX_MOBS;++i)if(gameplay->mobs[i].active)
        CloneMCJ_TileEntityPiston_MoveEntityIfIntersecting(tile,&gameplay->mobs[i].entity,
            progress,amount);
    for(i=0;i<CLONEMC_J_MAX_DROPPED_ITEMS;++i)if(gameplay->droppedItems[i].active)
        CloneMCJ_TileEntityPiston_MoveEntityIfIntersecting(tile,&gameplay->droppedItems[i].entity,
            progress,amount);
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(gameplay->vehicles[i].active)
        CloneMCJ_TileEntityPiston_MoveEntityIfIntersecting(tile,&gameplay->vehicles[i].entity,
            progress,amount);
    for(i=0;i<CLONEMC_J_MAX_PROJECTILES;++i)if(gameplay->projectiles[i].active)
        CloneMCJ_TileEntityPiston_MoveEntityIfIntersecting(tile,&gameplay->projectiles[i].entity,
            progress,amount);
}

void CloneMCJ_TileEntity_Update(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_ItemStack result;
    int wasBurning;
    if (!tile || tile->invalid) return;
    if (tile->type == CLONEMC_J_TILE_CHEST) {
        tile->previousLidAngle = tile->lidAngle;
        if (tile->numUsingPlayers > 0 && tile->lidAngle < 1.0F) {
            tile->lidAngle += 0.1F;
            if (tile->lidAngle > 1.0F) tile->lidAngle = 1.0F;
        } else if (tile->numUsingPlayers <= 0 && tile->lidAngle > 0.0F) {
            tile->lidAngle -= 0.1F;
            if (tile->lidAngle < 0.0F) tile->lidAngle = 0.0F;
        }
        return;
    }
    if (tile->type == CLONEMC_J_TILE_MOB_SPAWNER) {
        CloneMCJ_TileEntity_UpdateSpawner(tile);
        return;
    }
    if(tile->type==CLONEMC_J_TILE_PISTON){
        CloneMCJ_Chunk *chunk;
        float movement;
        tile->pistonPreviousProgress=tile->pistonProgress;
        if(tile->pistonProgress>=1.0F){
            CloneMCJ_TileEntityPiston_PushEntities(tile,1.0F,0.25F);
            chunk=CloneMCJ_World_GetChunkFromBlockCoords(tile->worldObj,tile->xCoord,tile->zCoord);
            if(chunk)CloneMCJ_Chunk_RemoveTileEntity(chunk,tile->xCoord&15,tile->yCoord,tile->zCoord&15);
            if(CloneMCJ_World_GetBlockId(tile->worldObj,tile->xCoord,tile->yCoord,tile->zCoord)==36)
                CloneMCJ_World_SetBlockWithMetadataNotify(tile->worldObj,tile->xCoord,tile->yCoord,tile->zCoord,
                    tile->pistonStoredBlockID,tile->pistonStoredMetadata);
            tile->invalid=1;
            CloneMCJ_TileEntity_Destroy(tile);
            return;
        }
        tile->pistonProgress+=0.5F;
        if(tile->pistonProgress>1.0F)tile->pistonProgress=1.0F;
        movement=(tile->pistonProgress-tile->pistonPreviousProgress)+0.0625F;
        CloneMCJ_TileEntityPiston_PushEntities(tile,tile->pistonProgress,movement);
        return;
    }
    if (tile->type != CLONEMC_J_TILE_FURNACE) return;
    wasBurning = tile->furnaceBurnTime > 0;
    if (tile->furnaceBurnTime > 0) --tile->furnaceBurnTime;
    if (tile->furnaceBurnTime == 0 && CloneMCJ_Furnace_CanSmelt(tile, &result)) {
        tile->currentItemBurnTime = CloneMCJ_Furnace_FuelTime(&tile->items[1]);
        tile->furnaceBurnTime = tile->currentItemBurnTime;
        if (tile->furnaceBurnTime > 0) {
            if (tile->items[1].itemID == 327 && tile->items[1].stackSize == 1) {
                CloneMCJ_ItemStack_Initialize(&tile->items[1], 325, 1, 0);
            } else {
                --tile->items[1].stackSize;
                if (tile->items[1].stackSize <= 0)
                    CloneMCJ_ItemStack_Clear(&tile->items[1]);
            }
        }
    }
    if (tile->furnaceBurnTime > 0 && CloneMCJ_Furnace_CanSmelt(tile, &result)) {
        ++tile->furnaceCookTime;
        if (tile->furnaceCookTime >= 200) {
            tile->furnaceCookTime = 0;
            CloneMCJ_Furnace_Smelt(tile);
        }
    } else tile->furnaceCookTime = 0;
    if ((wasBurning != 0) != (tile->furnaceBurnTime > 0)) {
        if (tile->worldObj) {
            int blockID;
            int metadata;
            blockID = CloneMCJ_World_GetBlockId(tile->worldObj,
                tile->xCoord, tile->yCoord, tile->zCoord);
            metadata = CloneMCJ_World_GetBlockMetadata(tile->worldObj,
                tile->xCoord, tile->yCoord, tile->zCoord);
            if (tile->furnaceBurnTime > 0 && blockID == 61)
                CloneMCJ_World_SetBlockWithMetadata(tile->worldObj,
                    tile->xCoord, tile->yCoord, tile->zCoord, 62, metadata);
            else if (tile->furnaceBurnTime <= 0 && blockID == 62)
                CloneMCJ_World_SetBlockWithMetadata(tile->worldObj,
                    tile->xCoord, tile->yCoord, tile->zCoord, 61, metadata);
        }
    }
}

int CloneMCJ_TileEntity_WriteNBT(const CloneMCJ_TileEntity *tile, CloneMCJ_NBTTagCompound *compound)
{
    CloneMCJ_NBTTagList *items;
    const char *id;
    int i;
    if (!tile || !compound) return 0;
    id = tile->type == CLONEMC_J_TILE_CHEST ? "Chest" :
         tile->type == CLONEMC_J_TILE_FURNACE ? "Furnace" :
         tile->type == CLONEMC_J_TILE_DISPENSER ? "Trap" :
         tile->type == CLONEMC_J_TILE_MOB_SPAWNER ? "MobSpawner" :
         tile->type == CLONEMC_J_TILE_PISTON ? "Piston" : "Sign";
    CloneMCJ_NBTTagCompound_SetString(compound, "id", id);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "x", tile->xCoord);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "y", tile->yCoord);
    CloneMCJ_NBTTagCompound_SetInteger(compound, "z", tile->zCoord);
    items = CloneMCJ_NBTTagList_Create();
    if (!items) return 0;
    for (i = 0; i < tile->itemCount; ++i) {
        CloneMCJ_NBTTagCompound *entry;
        if (CloneMCJ_ItemStack_IsEmpty(&tile->items[i])) continue;
        entry = CloneMCJ_NBTTagCompound_Create();
        if (!entry) continue;
        CloneMCJ_NBTTagCompound_SetByte(entry, "Slot", (CloneMCJByte)i);
        CloneMCJ_ItemStack_WriteNBT(&tile->items[i], entry);
        CloneMCJ_NBTTagList_Append(items, (CloneMCJ_NBTBase *)entry);
    }
    CloneMCJ_NBTTagCompound_SetTag(compound, "Items", (CloneMCJ_NBTBase *)items);
    if (tile->type == CLONEMC_J_TILE_FURNACE) {
        CloneMCJ_NBTTagCompound_SetShort(compound, "BurnTime", (CloneMCJShort)tile->furnaceBurnTime);
        CloneMCJ_NBTTagCompound_SetShort(compound, "CookTime", (CloneMCJShort)tile->furnaceCookTime);
    }
    if (tile->type == CLONEMC_J_TILE_SIGN) {
        for (i = 0; i < 4; ++i) {
            char key[16];
            sprintf(key, "Text%d", i + 1);
            CloneMCJ_NBTTagCompound_SetString(compound, key, tile->signText[i]);
        }
    }
    if (tile->type == CLONEMC_J_TILE_MOB_SPAWNER) {
        CloneMCJ_NBTTagCompound_SetString(compound, "EntityId", tile->mobID);
        CloneMCJ_NBTTagCompound_SetShort(compound, "Delay", (CloneMCJShort)tile->spawnDelay);
    }
    if(tile->type==CLONEMC_J_TILE_PISTON){
        CloneMCJ_NBTTagCompound_SetInteger(compound,"blockId",tile->pistonStoredBlockID);
        CloneMCJ_NBTTagCompound_SetInteger(compound,"blockData",tile->pistonStoredMetadata);
        CloneMCJ_NBTTagCompound_SetInteger(compound,"facing",tile->pistonFacing);
        CloneMCJ_NBTTagCompound_SetFloat(compound,"progress",tile->pistonPreviousProgress);
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"extending",tile->pistonExtending);
        CloneMCJ_NBTTagCompound_SetBoolean(compound,"renderHead",tile->pistonRenderHead);
    }
    return 1;
}

CloneMCJ_TileEntity *CloneMCJ_TileEntity_ReadNBT(const CloneMCJ_NBTTagCompound *compound, CloneMCJ_World *world)
{
    const char *id;
    CloneMCJ_TileEntityType type;
    CloneMCJ_TileEntity *tile;
    CloneMCJ_NBTTagList *items;
    CloneMCJInt count, i;
    if (!compound) return (CloneMCJ_TileEntity *)0;
    id = CloneMCJ_NBTTagCompound_GetString(compound, "id");
    type = id && strcmp(id, "Chest") == 0 ? CLONEMC_J_TILE_CHEST :
           id && strcmp(id, "Furnace") == 0 ? CLONEMC_J_TILE_FURNACE :
           id && strcmp(id, "Trap") == 0 ? CLONEMC_J_TILE_DISPENSER :
           id && strcmp(id, "MobSpawner") == 0 ? CLONEMC_J_TILE_MOB_SPAWNER :
           id && strcmp(id, "Piston") == 0 ? CLONEMC_J_TILE_PISTON : CLONEMC_J_TILE_SIGN;
    tile = CloneMCJ_TileEntity_Create(type, world,
        CloneMCJ_NBTTagCompound_GetInteger(compound, "x"),
        CloneMCJ_NBTTagCompound_GetInteger(compound, "y"),
        CloneMCJ_NBTTagCompound_GetInteger(compound, "z"));
    if (!tile) return tile;
    items = CloneMCJ_NBTTagCompound_GetTagList(compound, "Items");
    count = CloneMCJ_NBTTagList_Count(items);
    for (i = 0; i < count; ++i) {
        CloneMCJ_NBTTagCompound *entry;
        int slot;
        entry = (CloneMCJ_NBTTagCompound *)CloneMCJ_NBTTagList_Get(items, i);
        slot = entry ? (int)(unsigned char)CloneMCJ_NBTTagCompound_GetByte(entry, "Slot") : -1;
        if (slot >= 0 && slot < tile->itemCount) CloneMCJ_ItemStack_ReadNBT(&tile->items[slot], entry);
    }
    tile->furnaceBurnTime = CloneMCJ_NBTTagCompound_GetShort(compound, "BurnTime");
    tile->furnaceCookTime = CloneMCJ_NBTTagCompound_GetShort(compound, "CookTime");
    tile->currentItemBurnTime = CloneMCJ_Furnace_FuelTime(&tile->items[1]);
    if (type == CLONEMC_J_TILE_SIGN) {
        for (i = 0; i < 4; ++i) {
            char key[16];
            const char *text;
            sprintf(key, "Text%d", (int)i + 1);
            text = CloneMCJ_NBTTagCompound_GetString(compound, key);
            if (!text) text = "";
            strncpy(tile->signText[i], text, sizeof(tile->signText[i]) - 1U);
            tile->signText[i][sizeof(tile->signText[i]) - 1U] = '\0';
        }
    }
    if (type == CLONEMC_J_TILE_MOB_SPAWNER) {
        const char *mob;
        mob = CloneMCJ_NBTTagCompound_GetString(compound, "EntityId");
        if (mob) { strncpy(tile->mobID, mob, sizeof(tile->mobID) - 1U); tile->mobID[sizeof(tile->mobID) - 1U] = '\0'; }
        tile->spawnDelay = CloneMCJ_NBTTagCompound_GetShort(compound, "Delay");
    }
    if (type == CLONEMC_J_TILE_PISTON) {
        tile->pistonStoredBlockID = CloneMCJ_NBTTagCompound_GetInteger(compound, "blockId");
        tile->pistonStoredMetadata = CloneMCJ_NBTTagCompound_GetInteger(compound, "blockData");
        tile->pistonFacing = CloneMCJ_NBTTagCompound_GetInteger(compound, "facing");
        tile->pistonProgress = CloneMCJ_NBTTagCompound_GetFloat(compound, "progress");
        if (tile->pistonProgress < 0.0F) tile->pistonProgress = 0.0F;
        if (tile->pistonProgress > 1.0F) tile->pistonProgress = 1.0F;
        tile->pistonPreviousProgress = tile->pistonProgress;
        tile->pistonExtending = (unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound, "extending");
        tile->pistonRenderHead = (unsigned char)CloneMCJ_NBTTagCompound_GetBoolean(compound, "renderHead");
    }
    return tile;
}

int CloneMCJ_TileEntity_DecrStack(CloneMCJ_TileEntity *tile, int slot, int amount, CloneMCJ_ItemStack *out)
{
    if (!tile || !out || slot < 0 || slot >= tile->itemCount || amount <= 0) return 0;
    *out = CloneMCJ_ItemStack_Split(&tile->items[slot], amount);
    return !CloneMCJ_ItemStack_IsEmpty(out);
}

int CloneMCJ_TileEntity_SetStack(CloneMCJ_TileEntity *tile, int slot, const CloneMCJ_ItemStack *stack)
{
    if (!tile || !stack || slot < 0 || slot >= tile->itemCount) return 0;
    tile->items[slot] = *stack;
    if (tile->items[slot].stackSize > 64) tile->items[slot].stackSize = 64;
    return 1;
}

void CloneMCJ_TileEntity_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_TileEntity_JavaName(void)
{
    return "net.minecraft.src.TileEntity";
}

const char *CloneMCJ_TileEntity_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_TileEntity_JavaSourceHash32(void)
{
    return 0xE774B872UL;
}
