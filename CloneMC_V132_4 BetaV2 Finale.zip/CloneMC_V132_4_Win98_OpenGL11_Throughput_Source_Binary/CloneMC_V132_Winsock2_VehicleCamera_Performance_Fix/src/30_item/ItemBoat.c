/*
 * CloneMC Java port scaffold: ItemBoat
 *
 * Java source: ItemBoat.java
 * Java type: class ItemBoat
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 9b9312dee3f3f73422c47bb6fbeae6914cea39962a3f78f4089f242061684143
 * Java lines: 63
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, EntityPlayer, Vec3D, MathHelper, World, MovingObjectPosition, EnumMovingObjectType, Block, EntityBoat, ItemStack, d1, vec3d1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemBoat(int i)
 * - public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemBoat_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemBoat_JavaName(void)
{
    return "net.minecraft.src.ItemBoat";
}

const char *CloneMCJ_ItemBoat_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemBoat_JavaSourceHash32(void)
{
    return 0x9B9312DEUL;
}
