/* Java source: MapDataBase.java; Source SHA-256: ea3ac7b8939355881b644eb99a192b91b233d831be014287f150a1f61b40c67f; Java lines: 40. */
/* Direct C89 port of MapDataBase.java. */
#include "clonemc_java_port_30_item.h"
#include <string.h>
void CloneMCJ_MapDataBase_Initialize(CloneMCJ_MapDataBase*d,const char*n,
 void(*r)(CloneMCJ_MapDataBase*,const CloneMCJ_NBTTagCompound*),
 void(*w)(const CloneMCJ_MapDataBase*,CloneMCJ_NBTTagCompound*),
 void(*x)(CloneMCJ_MapDataBase*)){
 if(!d)return;
 memset(d,0,sizeof(*d));
 if(n)strncpy(d->name,n,sizeof(d->name)-1);
 d->readFromNBT=r;d->writeToNBT=w;d->destroy=x;
}
void CloneMCJ_MapDataBase_MarkDirty(CloneMCJ_MapDataBase*d){CloneMCJ_MapDataBase_SetDirty(d,1);}
void CloneMCJ_MapDataBase_SetDirty(CloneMCJ_MapDataBase*d,int v){if(d)d->dirty=(unsigned char)(v?1:0);}
int CloneMCJ_MapDataBase_IsDirty(const CloneMCJ_MapDataBase*d){return d&&d->dirty;}
void CloneMCJ_MapDataBase_Register(void){}
const char *CloneMCJ_MapDataBase_JavaName(void){return "net.minecraft.src.MapDataBase";}
const char *CloneMCJ_MapDataBase_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_MapDataBase_JavaSourceHash32(void){return 0xEA3AC7B8UL;}
