/*
 * CloneMC Java port scaffold: ItemPiston
 *
 * Java source: ItemPiston.java
 * Java type: class ItemPiston
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemBlock
 * Implements: (none declared)
 * Source SHA-256: 1a95fab36a1a935ae624f93b191e13483588ca92e6ce8d5b4a95675f5e2e0618
 * Java lines: 24
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: ItemBlock
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemPiston(int i)
 * - public int getPlacedBlockMetadata(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemPiston_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemPiston_JavaName(void)
{
    return "net.minecraft.src.ItemPiston";
}

const char *CloneMCJ_ItemPiston_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemPiston_JavaSourceHash32(void)
{
    return 0x1A95FAB3UL;
}
