/*
 * CloneMC Java port scaffold: BlockSponge
 *
 * Java source: BlockSponge.java
 * Java type: class BlockSponge
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 90e403f4dd5340734dc0db2dd02a8b87a712359cd919866be49f60ac7c3dbadd
 * Java lines: 56
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Block, Material, World, i1, j1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockSponge(int i)
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onBlockRemoval(World world, int i, int j, int k)
 *
 * V127.4 restores the bounded classic sponge transaction implied by the uploaded
 * Java radius-two loops.  The uploaded Beta decompilation contains an empty water
 * test, but retains the matching radius-two removal notification pass.  This port
 * completes that intended behavior without an unbounded flood fill.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

#define CLONEMC_J_SPONGE_RADIUS 2

int CloneMCJ_BlockSponge_IsWaterProtectedNative(CloneMCJ_World *world,
    int x,int y,int z)
{
    int sx,sy,sz;
    if(!world)return 0;
    for(sx=x-CLONEMC_J_SPONGE_RADIUS;sx<=x+CLONEMC_J_SPONGE_RADIUS;++sx)
        for(sy=y-CLONEMC_J_SPONGE_RADIUS;sy<=y+CLONEMC_J_SPONGE_RADIUS;++sy)
            for(sz=z-CLONEMC_J_SPONGE_RADIUS;sz<=z+CLONEMC_J_SPONGE_RADIUS;++sz)
                if(CloneMCJ_World_GetLoadedBlockId(world,sx,sy,sz)==19)return 1;
    return 0;
}

int CloneMCJ_BlockSponge_AbsorbNative(CloneMCJ_World *world,int x,int y,int z)
{
    int wx,wy,wz,id,removed;
    if(!world||world->multiplayerWorld)return 0;
    removed=0;
    /* Exactly the Java coordinates: [center-2, center+2] on every axis.  Both
     * flowing (8) and still (9) water are material-water and are removed. */
    for(wx=x-CLONEMC_J_SPONGE_RADIUS;wx<=x+CLONEMC_J_SPONGE_RADIUS;++wx)
        for(wy=y-CLONEMC_J_SPONGE_RADIUS;wy<=y+CLONEMC_J_SPONGE_RADIUS;++wy)
            for(wz=z-CLONEMC_J_SPONGE_RADIUS;wz<=z+CLONEMC_J_SPONGE_RADIUS;++wz){
                id=CloneMCJ_World_GetLoadedBlockId(world,wx,wy,wz);
                if((id==8||id==9)&&
                   CloneMCJ_World_SetBlockWithMetadata(world,wx,wy,wz,0,0))++removed;
            }
    return removed;
}

static void CloneMCJ_BlockSponge_Added(CloneMCJ_World *world,int x,int y,int z)
{
    (void)CloneMCJ_BlockSponge_AbsorbNative(world,x,y,z);
}

static void CloneMCJ_BlockSponge_Removed(CloneMCJ_World *world,int x,int y,int z)
{
    int wx,wy,wz,id;
    if(!world||world->multiplayerWorld)return;
    /* This is the uploaded Java onBlockRemoval loop.  It wakes fluid cells only
     * after the sponge has gone, allowing normal bounded refill simulation. */
    for(wx=x-CLONEMC_J_SPONGE_RADIUS;wx<=x+CLONEMC_J_SPONGE_RADIUS;++wx)
        for(wy=y-CLONEMC_J_SPONGE_RADIUS;wy<=y+CLONEMC_J_SPONGE_RADIUS;++wy)
            for(wz=z-CLONEMC_J_SPONGE_RADIUS;wz<=z+CLONEMC_J_SPONGE_RADIUS;++wz){
                id=CloneMCJ_World_GetLoadedBlockId(world,wx,wy,wz);
                CloneMCJ_World_NotifyBlocksOfNeighborChange(world,wx,wy,wz,id);
            }
}

void CloneMCJ_BlockSponge_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    if(!world)return;
    block=CloneMCJ_BlockRegistry_GetMutable(19);
    if(block){block->onBlockAdded=CloneMCJ_BlockSponge_Added;
        block->onBlockRemoved=CloneMCJ_BlockSponge_Removed;}
}

void CloneMCJ_BlockSponge_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockSponge_JavaName(void)
{
    return "net.minecraft.src.BlockSponge";
}

const char *CloneMCJ_BlockSponge_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockSponge_JavaSourceHash32(void)
{
    return 0x90E403F4UL;
}
