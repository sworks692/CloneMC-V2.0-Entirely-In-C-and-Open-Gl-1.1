/*
 * CloneMC Java port scaffold: MaterialTransparent
 *
 * Java source: MaterialTransparent.java
 * Java type: class MaterialTransparent
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: Material
 * Implements: (none declared)
 * Source SHA-256: 72df8b22294d7a95fc5e879454f830bd612b4f9b669a0e9aac88ed1ada35b3d1
 * Java lines: 35
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: Material, MapColor
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public MaterialTransparent(MapColor mapcolor)
 * - public boolean isSolid()
 * - public boolean getCanBlockGrass()
 * - public boolean getIsSolid()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_MaterialTransparent_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MaterialTransparent_JavaName(void)
{
    return "net.minecraft.src.MaterialTransparent";
}

const char *CloneMCJ_MaterialTransparent_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_MaterialTransparent_JavaSourceHash32(void)
{
    return 0x72DF8B22UL;
}
