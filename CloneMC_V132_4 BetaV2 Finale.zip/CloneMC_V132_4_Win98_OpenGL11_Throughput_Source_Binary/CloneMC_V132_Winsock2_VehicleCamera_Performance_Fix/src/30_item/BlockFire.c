/*
 * CloneMC Java port scaffold: BlockFire
 *
 * Java source: BlockFire.java
 * Java type: class BlockFire
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 6987bbc2a533e0336a112f2f6cad61bc50a1a69c809fdc37e3bfb5ab011c88d9
 * Java lines: 352
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 20
 * Referenced Java classes: Block, Material, BlockLeaves, BlockTallGrass, World, IBlockAccess, BlockPortal, AxisAlignedBB, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int chanceToEncourageFire[]
 * - private int abilityToCatchFire[]
 *
 * Java method/constructor inventory:
 * - protected BlockFire(int i, int j)
 * - public void initializeBlock()
 * - private void setBurnRate(int i, int j, int k)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public int getRenderType()
 * - public int quantityDropped(Random random)
 * - public int tickRate()
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - private void tryToCatchBlockOnFire(World world, int i, int j, int k, int l, Random random, int i1)
 * - private boolean func_263_h(World world, int i, int j, int k)
 * - private int getChanceOfNeighborsEncouragingFire(World world, int i, int j, int k)
 * - public boolean isCollidable()
 * - public boolean canBlockCatchFire(IBlockAccess iblockaccess, int i, int j, int k)
 * - public int getChanceToEncourageFire(World world, int i, int j, int k, int l)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void randomDisplayTick(World world, int i, int j, int k, Random random)
 *
 * Priority 11 directly implements the Java burn tables, fire aging, rain checks,
 * rescheduling, consumption and air-cell spread behavior below.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <string.h>

static unsigned char g_cloneMCFireEncouragement[256];
static unsigned char g_cloneMCFireCatch[256];
static int g_cloneMCFireRatesInitialized;

static void CloneMCJ_BlockFire_SetRate(int id, int encouragement, int catchChance)
{
    if (id < 0 || id > 255) return;
    g_cloneMCFireEncouragement[id] = (unsigned char)encouragement;
    g_cloneMCFireCatch[id] = (unsigned char)catchChance;
}

static void CloneMCJ_BlockFire_InitializeRates(void)
{
    if (g_cloneMCFireRatesInitialized) return;
    memset(g_cloneMCFireEncouragement, 0, sizeof(g_cloneMCFireEncouragement));
    memset(g_cloneMCFireCatch, 0, sizeof(g_cloneMCFireCatch));
    CloneMCJ_BlockFire_SetRate(5, 5, 20);
    CloneMCJ_BlockFire_SetRate(85, 5, 20);
    CloneMCJ_BlockFire_SetRate(53, 5, 20);
    CloneMCJ_BlockFire_SetRate(17, 5, 5);
    CloneMCJ_BlockFire_SetRate(18, 30, 60);
    CloneMCJ_BlockFire_SetRate(47, 30, 20);
    CloneMCJ_BlockFire_SetRate(46, 15, 100);
    CloneMCJ_BlockFire_SetRate(31, 60, 100);
    CloneMCJ_BlockFire_SetRate(35, 30, 60);
    g_cloneMCFireRatesInitialized = 1;
}

static int CloneMCJ_BlockFire_CanCatch(CloneMCJ_World *world, int x, int y, int z)
{
    int id;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    return id >= 0 && id < 256 && g_cloneMCFireEncouragement[id] > 0;
}

static int CloneMCJ_BlockFire_HasBurnableNeighbor(CloneMCJ_World *world, int x,
    int y, int z)
{
    return CloneMCJ_BlockFire_CanCatch(world, x - 1, y, z) ||
        CloneMCJ_BlockFire_CanCatch(world, x + 1, y, z) ||
        CloneMCJ_BlockFire_CanCatch(world, x, y - 1, z) ||
        CloneMCJ_BlockFire_CanCatch(world, x, y + 1, z) ||
        CloneMCJ_BlockFire_CanCatch(world, x, y, z - 1) ||
        CloneMCJ_BlockFire_CanCatch(world, x, y, z + 1);
}

static int CloneMCJ_BlockFire_CanPlace(CloneMCJ_World *world, int x, int y, int z)
{
    return CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world, x, y - 1, z)) ||
        CloneMCJ_BlockFire_HasBurnableNeighbor(world, x, y, z);
}

static int CloneMCJ_BlockFire_RainedOn(CloneMCJ_World *world, int x, int y, int z)
{
    return world && world->worldInfo.raining && !world->worldProvider.hasNoSky &&
        CloneMCJ_World_CanExistingBlockSeeTheSky(world, x, y, z);
}

static int CloneMCJ_BlockFire_NeighborEncouragement(CloneMCJ_World *world, int x,
    int y, int z)
{
    int ids[6];
    int i;
    int best;
    if (!CloneMCJ_World_IsAirBlock(world, x, y, z)) return 0;
    ids[0] = CloneMCJ_World_GetBlockId(world, x - 1, y, z);
    ids[1] = CloneMCJ_World_GetBlockId(world, x + 1, y, z);
    ids[2] = CloneMCJ_World_GetBlockId(world, x, y - 1, z);
    ids[3] = CloneMCJ_World_GetBlockId(world, x, y + 1, z);
    ids[4] = CloneMCJ_World_GetBlockId(world, x, y, z - 1);
    ids[5] = CloneMCJ_World_GetBlockId(world, x, y, z + 1);
    best = 0;
    for (i = 0; i < 6; ++i) if (g_cloneMCFireEncouragement[ids[i] & 255] > best)
        best = g_cloneMCFireEncouragement[ids[i] & 255];
    return best;
}

static void CloneMCJ_BlockFire_TryCatch(CloneMCJ_World *world, int x, int y, int z,
    int bound, CloneMCJavaRandom *random, int age)
{
    int id;
    int newAge;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (CloneMCJavaRandom_NextIntBound(random, bound) >= g_cloneMCFireCatch[id & 255]) return;
    if (CloneMCJavaRandom_NextIntBound(random, age + 10) < 5 &&
        !CloneMCJ_BlockFire_RainedOn(world, x, y, z)) {
        newAge = age + CloneMCJavaRandom_NextIntBound(random, 5) / 4;
        if (newAge > 15) newAge = 15;
        CloneMCJ_World_SetBlockWithMetadataNotify(world, x, y, z, 51, newAge);
    } else CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
}

static void CloneMCJ_BlockFire_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int eternal;
    int age;
    int xx;
    int yy;
    int zz;
    int bound;
    int encouragement;
    int chance;
    int newAge;
    (void)blockID; (void)userData;
    if (!world || !random) return;
    eternal = CloneMCJ_World_GetBlockId(world, x, y - 1, z) == 87;
    if (!CloneMCJ_BlockFire_CanPlace(world, x, y, z)) {
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0); return;
    }
    if (!eternal && world->worldInfo.raining &&
        (CloneMCJ_BlockFire_RainedOn(world, x, y, z) ||
         CloneMCJ_BlockFire_RainedOn(world, x - 1, y, z) ||
         CloneMCJ_BlockFire_RainedOn(world, x + 1, y, z) ||
         CloneMCJ_BlockFire_RainedOn(world, x, y, z - 1) ||
         CloneMCJ_BlockFire_RainedOn(world, x, y, z + 1))) {
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0); return;
    }
    age = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (age < 15) CloneMCJ_World_SetBlockMetadata(world, x, y, z,
        age + CloneMCJavaRandom_NextIntBound(random, 3) / 2);
    CloneMCJ_World_ScheduleBlockUpdate(world, x, y, z, 51, 40);
    if (!eternal && !CloneMCJ_BlockFire_HasBurnableNeighbor(world, x, y, z)) {
        if (!CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world, x, y - 1, z)) || age > 3)
            CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
        return;
    }
    if (!eternal && !CloneMCJ_BlockFire_CanCatch(world, x, y - 1, z) && age == 15 &&
        CloneMCJavaRandom_NextIntBound(random, 4) == 0) {
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0); return;
    }
    CloneMCJ_BlockFire_TryCatch(world, x + 1, y, z, 300, random, age);
    CloneMCJ_BlockFire_TryCatch(world, x - 1, y, z, 300, random, age);
    CloneMCJ_BlockFire_TryCatch(world, x, y - 1, z, 250, random, age);
    CloneMCJ_BlockFire_TryCatch(world, x, y + 1, z, 250, random, age);
    CloneMCJ_BlockFire_TryCatch(world, x, y, z - 1, 300, random, age);
    CloneMCJ_BlockFire_TryCatch(world, x, y, z + 1, 300, random, age);
    for (xx = x - 1; xx <= x + 1; ++xx) for (zz = z - 1; zz <= z + 1; ++zz)
        for (yy = y - 1; yy <= y + 4; ++yy) {
            if (xx == x && yy == y && zz == z) continue;
            bound = 100 + (yy > y + 1 ? (yy - (y + 1)) * 100 : 0);
            encouragement = CloneMCJ_BlockFire_NeighborEncouragement(world, xx, yy, zz);
            if (encouragement <= 0) continue;
            chance = (encouragement + 40) / (age + 30);
            if (chance > 0 && CloneMCJavaRandom_NextIntBound(random, bound) <= chance &&
                !CloneMCJ_BlockFire_RainedOn(world, xx, yy, zz)) {
                newAge = age + CloneMCJavaRandom_NextIntBound(random, 5) / 4;
                if (newAge > 15) newAge = 15;
                CloneMCJ_World_SetBlockWithMetadataNotify(world, xx, yy, zz, 51, newAge);
            }
        }
}

static void CloneMCJ_BlockFire_Added(CloneMCJ_World *world, int x, int y, int z)
{
    /* BlockFire.onBlockAdded is the authoritative portal trigger in Beta.
     * Keeping portal creation only in one input path meant fires loaded from
     * packets or placed by another valid caller could never open a frame. */
    if(CloneMCJ_World_GetBlockId(world,x,y-1,z)==49&&
       CloneMCJ_BlockPortal_TryCreate(world,x,y,z))return;
    if (!CloneMCJ_BlockFire_CanPlace(world, x, y, z))
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
    else CloneMCJ_World_ScheduleBlockUpdate(world, x, y, z, 51, 40);
}

static void CloneMCJ_BlockFire_Neighbor(CloneMCJ_World *world, int x, int y, int z,
    int neighborID)
{
    (void)neighborID;
    if (!CloneMCJ_BlockFire_CanPlace(world, x, y, z))
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
}

void CloneMCJ_BlockFire_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    CloneMCJ_BlockFire_InitializeRates();
    block = CloneMCJ_BlockRegistry_GetMutable(51);
    if (block) {
        block->tickRandomly = 1;
        block->onBlockAdded = CloneMCJ_BlockFire_Added;
        block->neighborChanged = CloneMCJ_BlockFire_Neighbor;
    }
    CloneMCJ_World_RegisterBlockTick(world, 51, 1, CloneMCJ_BlockFire_UpdateTick, 0);
}

void CloneMCJ_BlockFire_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockFire_JavaName(void)
{
    return "net.minecraft.src.BlockFire";
}

const char *CloneMCJ_BlockFire_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockFire_JavaSourceHash32(void)
{
    return 0x6987BBC2UL;
}
