/*
 * Direct C89 recipe registrations ported from RecipesDyes.java.
 */
#include "clonemc_java_port_30_item.h"

static const short g_cloneMCRecipesDyesRecipeData[][25] = {
    {0, 35, 15, 1, 0, 0, 2, 351, 0, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 14, 1, 0, 0, 2, 351, 1, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 13, 1, 0, 0, 2, 351, 2, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 12, 1, 0, 0, 2, 351, 3, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 11, 1, 0, 0, 2, 351, 4, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 10, 1, 0, 0, 2, 351, 5, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 9, 1, 0, 0, 2, 351, 6, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 8, 1, 0, 0, 2, 351, 7, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 7, 1, 0, 0, 2, 351, 8, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 6, 1, 0, 0, 2, 351, 9, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 5, 1, 0, 0, 2, 351, 10, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 4, 1, 0, 0, 2, 351, 11, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 3, 1, 0, 0, 2, 351, 12, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 2, 1, 0, 0, 2, 351, 13, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 1, 1, 0, 0, 2, 351, 14, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 35, 0, 1, 0, 0, 2, 351, 15, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 11, 2, 0, 0, 1, 37, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 1, 2, 0, 0, 1, 38, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 15, 3, 0, 0, 1, 352, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 9, 2, 0, 0, 2, 351, 1, 351, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 14, 2, 0, 0, 2, 351, 1, 351, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 10, 2, 0, 0, 2, 351, 2, 351, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 8, 2, 0, 0, 2, 351, 0, 351, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 7, 2, 0, 0, 2, 351, 8, 351, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 7, 3, 0, 0, 3, 351, 0, 351, 15, 351, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 12, 2, 0, 0, 2, 351, 4, 351, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 6, 2, 0, 0, 2, 351, 4, 351, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 5, 2, 0, 0, 2, 351, 4, 351, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 13, 2, 0, 0, 2, 351, 5, 351, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 13, 3, 0, 0, 3, 351, 4, 351, 1, 351, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 351, 13, 4, 0, 0, 4, 351, 4, 351, 1, 351, 1, 351, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void CloneMCJ_RecipesDyes_AddNative(void)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int recipeIndex;
    int ingredientIndex;
    const short *data;
    for (recipeIndex = 0; recipeIndex < (int)(sizeof(g_cloneMCRecipesDyesRecipeData) /
        sizeof(g_cloneMCRecipesDyesRecipeData[0])); ++recipeIndex) {
        data = g_cloneMCRecipesDyesRecipeData[recipeIndex];
        CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
        for (ingredientIndex = 0;
             ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
             ++ingredientIndex) {
            ingredients[ingredientIndex].itemID =
                data[7 + ingredientIndex * 2];
            ingredients[ingredientIndex].itemDamage =
                data[8 + ingredientIndex * 2];
        }
        if (data[0])
            CloneMCJ_CraftingManager_AddShapedNative(&output,
                data[4], data[5], ingredients);
        else
            CloneMCJ_CraftingManager_AddShapelessNative(&output,
                data[6], ingredients);
    }
}

void CloneMCJ_RecipesDyes_Register(void) { }
const char *CloneMCJ_RecipesDyes_JavaName(void)
{ return "net.minecraft.src.RecipesDyes"; }
const char *CloneMCJ_RecipesDyes_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipesDyes_JavaSourceHash32(void)
{ return 0x20BFC9E0UL; }
