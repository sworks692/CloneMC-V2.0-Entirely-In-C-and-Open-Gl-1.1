/*
 * CloneMC Java port scaffold: BlockMushroom
 *
 * Java source: BlockMushroom.java
 * Java type: class BlockMushroom
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockFlower
 * Implements: (none declared)
 * Source SHA-256: e6402e17cca6918cf845c1296f592f8ade4e8bb0a7e283f89a4e103317dab166
 * Java lines: 58
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: BlockFlower, World, Block, i1, l, j1, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockMushroom(int i, int j)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - protected boolean canThisPlantGrowOnThisBlockID(int i)
 * - public boolean canBlockStay(World world, int i, int j, int k)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockMushroom_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockMushroom_JavaName(void)
{
    return "net.minecraft.src.BlockMushroom";
}

const char *CloneMCJ_BlockMushroom_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockMushroom_JavaSourceHash32(void)
{
    return 0xE6402E17UL;
}
