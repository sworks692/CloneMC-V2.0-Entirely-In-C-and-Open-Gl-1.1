/* Direct C89 conversion of Beta TileEntityPiston.java. */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <stdlib.h>

static const signed char g_tilePistonDX[6]={0,0,0,0,-1,1};
static const signed char g_tilePistonDY[6]={-1,1,0,0,0,0};
static const signed char g_tilePistonDZ[6]={0,0,-1,1,0,0};

CloneMCJ_TileEntity *CloneMCJ_TileEntityPiston_Create(CloneMCJ_World *world,
    int x,int y,int z,int storedID,int storedMetadata,int facing,
    int extending,int renderHead)
{
    CloneMCJ_TileEntity *tile;
    tile=CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_PISTON,world,x,y,z);
    if(!tile)return (CloneMCJ_TileEntity *)0;
    tile->pistonStoredBlockID=storedID;
    tile->pistonStoredMetadata=storedMetadata;
    tile->pistonFacing=facing;
    tile->pistonExtending=(unsigned char)(extending?1:0);
    tile->pistonRenderHead=(unsigned char)(renderHead?1:0);
    tile->pistonProgress=0.0F;
    tile->pistonPreviousProgress=0.0F;
    return tile;
}

float CloneMCJ_TileEntityPiston_GetProgress(const CloneMCJ_TileEntity *tile,float partial)
{
    if(!tile)return 0.0F;
    if(partial>1.0F)partial=1.0F;
    if(partial<0.0F)partial=0.0F;
    return tile->pistonPreviousProgress+
        (tile->pistonProgress-tile->pistonPreviousProgress)*partial;
}

static float CloneMCJ_TileEntityPiston_Offset(const CloneMCJ_TileEntity *tile,
    float partial,int axis)
{
    float progress,multiplier;
    int facing;
    if(!tile)return 0.0F;
    progress=CloneMCJ_TileEntityPiston_GetProgress(tile,partial);
    multiplier=tile->pistonExtending?progress-1.0F:1.0F-progress;
    facing=tile->pistonFacing;
    if(facing<0||facing>5)return 0.0F;
    if(axis==0)return multiplier*(float)g_tilePistonDX[facing];
    if(axis==1)return multiplier*(float)g_tilePistonDY[facing];
    return multiplier*(float)g_tilePistonDZ[facing];
}

float CloneMCJ_TileEntityPiston_OffsetX(const CloneMCJ_TileEntity *tile,float partial)
{return CloneMCJ_TileEntityPiston_Offset(tile,partial,0);}
float CloneMCJ_TileEntityPiston_OffsetY(const CloneMCJ_TileEntity *tile,float partial)
{return CloneMCJ_TileEntityPiston_Offset(tile,partial,1);}
float CloneMCJ_TileEntityPiston_OffsetZ(const CloneMCJ_TileEntity *tile,float partial)
{return CloneMCJ_TileEntityPiston_Offset(tile,partial,2);}

void CloneMCJ_TileEntityPiston_Register(void){}
const char *CloneMCJ_TileEntityPiston_JavaName(void){return "net.minecraft.src.TileEntityPiston";}
const char *CloneMCJ_TileEntityPiston_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_TileEntityPiston_JavaSourceHash32(void){return 0xC924DB59UL;}
