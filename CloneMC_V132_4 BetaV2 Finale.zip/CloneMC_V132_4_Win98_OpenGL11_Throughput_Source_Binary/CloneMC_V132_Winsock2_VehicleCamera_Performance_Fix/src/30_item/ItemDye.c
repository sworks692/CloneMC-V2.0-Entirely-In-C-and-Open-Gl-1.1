/*
 * CloneMC Java port scaffold: ItemDye
 *
 * Java source: ItemDye.java
 * Java type: class ItemDye
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 752bb8aa5c3a4e0ca2db816af73d5c3a8a7a58df2adf8cc1864f692dafbd5068
 * Java lines: 130
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: Item, ItemStack, World, Block, BlockSapling, BlockCrops, BlockGrass, BlockTallGrass, BlockFlower, EntitySheep, BlockCloth, EntityPlayer, EntityLiving, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemDye(int i)
 * - public int getIconFromDamage(int i)
 * - public String getItemNameIS(ItemStack itemstack)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 * - public void saddleEntity(ItemStack itemstack, EntityLiving entityliving)
 *
 * V131 directly converts ItemDye.onItemUse for white dye/bone meal.  The Java
 * sapling, crops, and grass branches retain their return and consumption rules,
 * random-walk order, flower odds, and singleplayer authority boundary.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static CloneMCJavaRandom g_cloneMCItemDyeRandom;
static int g_cloneMCItemDyeRandomInitialized;

static CloneMCJavaRandom *CloneMCJ_ItemDye_Random(CloneMCJ_World *world)
{
    CloneMCJLong seed;
    if(!g_cloneMCItemDyeRandomInitialized){
        seed=world?world->randomSeed:(CloneMCJLong)1;
        CloneMCJavaRandom_SetSeed(&g_cloneMCItemDyeRandom,
            seed^(((CloneMCJLong)0x00000005UL<<32)|
                (CloneMCJLong)0xdeece66dUL));
        g_cloneMCItemDyeRandomInitialized=1;
    }
    return &g_cloneMCItemDyeRandom;
}

static void CloneMCJ_ItemDye_Consume(CloneMCJ_ItemStack *stack)
{
    if(!stack)return;
    --stack->stackSize;
    if(stack->stackSize<=0)CloneMCJ_ItemStack_Clear(stack);
}

static int CloneMCJ_ItemDye_IsNormalCube(CloneMCJ_World *world,
    int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *definition;
    int id;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    definition=CloneMCJ_BlockRegistry_Get(id);
    return definition&&definition->opaque&&definition->collidable;
}

static void CloneMCJ_ItemDye_GrowGrass(CloneMCJ_World *world,
    int originX,int originY,int originZ)
{
    CloneMCJavaRandom *random;
    int attempt,step,x,y,z;
    random=CloneMCJ_ItemDye_Random(world);
    for(attempt=0;attempt<128;++attempt){
        x=originX;y=originY+1;z=originZ;
        for(step=0;step<attempt/16;++step){
            x+=CloneMCJavaRandom_NextIntBound(random,3)-1;
            y+=((CloneMCJavaRandom_NextIntBound(random,3)-1)*
                CloneMCJavaRandom_NextIntBound(random,3))/2;
            z+=CloneMCJavaRandom_NextIntBound(random,3)-1;
            if(CloneMCJ_World_GetBlockId(world,x,y-1,z)!=2||
               CloneMCJ_ItemDye_IsNormalCube(world,x,y,z))break;
        }
        if(step<attempt/16||CloneMCJ_World_GetBlockId(world,x,y,z)!=0)
            continue;
        if(CloneMCJavaRandom_NextIntBound(random,10)!=0)
            CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,31,1);
        else if(CloneMCJavaRandom_NextIntBound(random,3)!=0)
            CloneMCJ_World_SetBlockNotify(world,x,y,z,37);
        else CloneMCJ_World_SetBlockNotify(world,x,y,z,38);
    }
}

int CloneMCJ_ItemDye_UseNative(CloneMCJ_World *world,
    CloneMCJ_ItemStack *stack,int x,int y,int z,int side)
{
    int blockID;
    (void)side;
    if(!world||!stack||CloneMCJ_ItemStack_IsEmpty(stack)||
       stack->itemID!=351||(stack->itemDamage&15)!=15)return 0;
    blockID=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(blockID!=6&&blockID!=59&&blockID!=2)return 0;
    /* Multiplayer ItemDye returns true but leaves mutation to the server. */
    if(world->multiplayerWorld)return 1;
    if(blockID==6)
        CloneMCJ_BlockSapling_GrowTree(world,x,y,z,&world->rand);
    else if(blockID==59)
        CloneMCJ_BlockCrops_Fertilize(world,x,y,z);
    else CloneMCJ_ItemDye_GrowGrass(world,x,y,z);
    CloneMCJ_ItemDye_Consume(stack);
    return 1;
}

void CloneMCJ_ItemDye_Register(void)
{
    /* Item use is dispatched by the singleplayer gameplay controller. */
}

const char *CloneMCJ_ItemDye_JavaName(void)
{
    return "net.minecraft.src.ItemDye";
}

const char *CloneMCJ_ItemDye_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemDye_JavaSourceHash32(void)
{
    return 0x752BB8AAUL;
}
