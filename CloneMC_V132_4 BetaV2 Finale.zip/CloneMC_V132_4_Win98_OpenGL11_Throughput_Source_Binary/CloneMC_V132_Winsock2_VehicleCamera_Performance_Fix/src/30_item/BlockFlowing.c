/*
 * CloneMC Java port scaffold: BlockFlowing
 *
 * Java source: BlockFlowing.java
 * Java type: class BlockFlowing
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockFluid
 * Implements: (none declared)
 * Source SHA-256: 28c5e09d7c29840a2e809157d659a4c0524edf121ea72ef15b66daa94eb0cbc7
 * Java lines: 328
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: BlockFluid, World, Material, WorldProvider, Block, j, k, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockFlowing(int i, Material material)
 * - private void func_30003_j(World world, int i, int j, int k)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - private void flowIntoBlock(World world, int i, int j, int k, int l)
 * - private int calculateFlowCost(World world, int i, int j, int k, int l, int i1)
 * - private boolean[] getOptimalFlowDirections(World world, int i, int j, int k)
 * - private boolean blockBlocksFlow(World world, int i, int j, int k)
 * - protected int getSmallestFlowDecay(World world, int i, int j, int k, int l)
 * - private boolean liquidCanDisplaceBlock(World world, int i, int j, int k)
 * - public void onBlockAdded(World world, int i, int j, int k)
 *
 * Priority 11 directly implements Java moving-liquid decay, source renewal,
 * downward flow and recursive optimal side-flow selection below.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockFlowing_IsWater(int id)
{
    return id == CLONEMC_J_BLOCK_WATER_MOVING || id == CLONEMC_J_BLOCK_WATER_STILL;
}

static int CloneMCJ_BlockFlowing_IsLava(int id)
{
    return id == CLONEMC_J_BLOCK_LAVA_MOVING || id == CLONEMC_J_BLOCK_LAVA_STILL;
}

static int CloneMCJ_BlockFlowing_SameMaterial(int movingID, int id)
{
    return CloneMCJ_BlockFlowing_IsWater(movingID) ? CloneMCJ_BlockFlowing_IsWater(id) :
        CloneMCJ_BlockFlowing_IsLava(id);
}

static int CloneMCJ_BlockFlowing_BlocksFlow(CloneMCJ_World *world, int x, int y, int z)
{
    int id;
    const CloneMCJ_BlockDefinition *block;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (id == 64 || id == 71 || id == 63 || id == 68 || id == 65 || id == 83) return 1;
    if (id == 0) return 0;
    block = CloneMCJ_BlockRegistry_Get(id);
    return block ? block->solid != 0 : 1;
}

static int CloneMCJ_BlockFlowing_CanDisplace(CloneMCJ_World *world, int x, int y,
    int z, int movingID)
{
    int id;
    /* Classic's radius-two sponge volume must remain dry until removal.  The
     * paired removal callback wakes surrounding water after protection ends. */
    if(CloneMCJ_BlockFlowing_IsWater(movingID)&&
       CloneMCJ_BlockSponge_IsWaterProtectedNative(world,x,y,z))return 0;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (CloneMCJ_BlockFlowing_SameMaterial(movingID, id)) return 0;
    if (CloneMCJ_BlockFlowing_IsLava(id)) return 0;
    return !CloneMCJ_BlockFlowing_BlocksFlow(world, x, y, z);
}

static int CloneMCJ_BlockFlowing_SmallestDecay(CloneMCJ_World *world, int x, int y,
    int z, int movingID, int current, int *sourceCount)
{
    int decay;
    decay = CloneMCJ_BlockFluid_GetFlowDecay(world, x, y, z, movingID);
    if (decay < 0) return current;
    if (decay == 0 && sourceCount) ++*sourceCount;
    if (decay >= 8) decay = 0;
    return current >= 0 && decay >= current ? current : decay;
}

static int CloneMCJ_BlockFlowing_FlowCost(CloneMCJ_World *world, int x, int y,
    int z, int depth, int previousDirection, int movingID)
{
    int direction;
    int best;
    int nx;
    int nz;
    int cost;
    best = 1000;
    for (direction = 0; direction < 4; ++direction) {
        if ((direction == 0 && previousDirection == 1) ||
            (direction == 1 && previousDirection == 0) ||
            (direction == 2 && previousDirection == 3) ||
            (direction == 3 && previousDirection == 2)) continue;
        nx = x + (direction == 0 ? -1 : direction == 1 ? 1 : 0);
        nz = z + (direction == 2 ? -1 : direction == 3 ? 1 : 0);
        if (CloneMCJ_BlockFlowing_BlocksFlow(world, nx, y, nz) ||
            (CloneMCJ_BlockFlowing_SameMaterial(movingID,
                CloneMCJ_World_GetBlockId(world, nx, y, nz)) &&
             CloneMCJ_World_GetBlockMetadata(world, nx, y, nz) == 0)) continue;
        if (!CloneMCJ_BlockFlowing_BlocksFlow(world, nx, y - 1, nz)) return depth;
        if (depth >= 4) continue;
        cost = CloneMCJ_BlockFlowing_FlowCost(world, nx, y, nz, depth + 1,
            direction, movingID);
        if (cost < best) best = cost;
    }
    return best;
}

static void CloneMCJ_BlockFlowing_OptimalDirections(CloneMCJ_World *world, int x,
    int y, int z, int movingID, int optimal[4])
{
    int costs[4];
    int direction;
    int nx;
    int nz;
    int best;
    best = 1000;
    for (direction = 0; direction < 4; ++direction) {
        nx = x + (direction == 0 ? -1 : direction == 1 ? 1 : 0);
        nz = z + (direction == 2 ? -1 : direction == 3 ? 1 : 0);
        costs[direction] = 1000;
        if (!CloneMCJ_BlockFlowing_BlocksFlow(world, nx, y, nz) &&
            !(CloneMCJ_BlockFlowing_SameMaterial(movingID,
                CloneMCJ_World_GetBlockId(world, nx, y, nz)) &&
              CloneMCJ_World_GetBlockMetadata(world, nx, y, nz) == 0)) {
            costs[direction] = !CloneMCJ_BlockFlowing_BlocksFlow(world, nx, y - 1, nz) ?
                0 : CloneMCJ_BlockFlowing_FlowCost(world, nx, y, nz, 1, direction, movingID);
        }
        if (costs[direction] < best) best = costs[direction];
    }
    for (direction = 0; direction < 4; ++direction)
        optimal[direction] = costs[direction] == best;
}

static void CloneMCJ_BlockFlowing_FlowInto(CloneMCJ_World *world, int x, int y,
    int z, int movingID, int decay)
{
    if (!CloneMCJ_BlockFlowing_CanDisplace(world, x, y, z, movingID)) return;
    CloneMCJ_World_SetBlockWithMetadataNotify(world, x, y, z, movingID, decay);
}

void CloneMCJ_BlockFlowing_UpdateTick(CloneMCJ_World *world, int x, int y, int z,
    int blockID, CloneMCJavaRandom *random, void *userData)
{
    int decay;
    int step;
    int smallest;
    int newDecay;
    int sourceCount;
    int stable;
    int above;
    int optimal[4];
    int direction;
    int sideDecay;
    (void)userData;
    if (!world || !random || (blockID != 8 && blockID != 10)) return;
    decay = CloneMCJ_BlockFluid_GetFlowDecay(world, x, y, z, blockID);
    step = blockID == 10 && !world->worldProvider.isHellWorld ? 2 : 1;
    stable = 1;
    if (decay > 0) {
        smallest = -100;
        sourceCount = 0;
        smallest = CloneMCJ_BlockFlowing_SmallestDecay(world, x - 1, y, z, blockID, smallest, &sourceCount);
        smallest = CloneMCJ_BlockFlowing_SmallestDecay(world, x + 1, y, z, blockID, smallest, &sourceCount);
        smallest = CloneMCJ_BlockFlowing_SmallestDecay(world, x, y, z - 1, blockID, smallest, &sourceCount);
        smallest = CloneMCJ_BlockFlowing_SmallestDecay(world, x, y, z + 1, blockID, smallest, &sourceCount);
        newDecay = smallest + step;
        if (newDecay >= 8 || smallest < 0) newDecay = -1;
        above = CloneMCJ_BlockFluid_GetFlowDecay(world, x, y + 1, z, blockID);
        if (above >= 0) newDecay = above >= 8 ? above : above + 8;
        if (sourceCount >= 2 && blockID == 8) {
            if (CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world, x, y - 1, z)) ||
                (CloneMCJ_BlockFlowing_SameMaterial(blockID,
                    CloneMCJ_World_GetBlockId(world, x, y - 1, z)) &&
                 CloneMCJ_World_GetBlockMetadata(world, x, y, z) == 0)) newDecay = 0;
        }
        if (blockID == 10 && decay < 8 && newDecay < 8 && newDecay > decay &&
            CloneMCJavaRandom_NextIntBound(random, 4) != 0) {
            newDecay = decay;
            stable = 0;
        }
        if (newDecay != decay) {
            decay = newDecay;
            if (decay < 0) CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
            else {
                CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, decay);
                CloneMCJ_World_ScheduleBlockUpdate(world, x, y, z, blockID,
                    CloneMCJ_BlockFluid_TickRate(blockID));
            }
        } else if (stable) CloneMCJ_World_SetBlockWithMetadata(world, x, y, z,
            blockID + 1, decay);
    } else CloneMCJ_World_SetBlockWithMetadata(world, x, y, z, blockID + 1, decay);

    if (CloneMCJ_BlockFlowing_CanDisplace(world, x, y - 1, z, blockID)) {
        CloneMCJ_BlockFlowing_FlowInto(world, x, y - 1, z, blockID,
            decay >= 8 ? decay : decay + 8);
    } else if (decay >= 0 && (decay == 0 ||
        CloneMCJ_BlockFlowing_BlocksFlow(world, x, y - 1, z))) {
        CloneMCJ_BlockFlowing_OptimalDirections(world, x, y, z, blockID, optimal);
        sideDecay = decay >= 8 ? 1 : decay + step;
        if (sideDecay >= 8) return;
        for (direction = 0; direction < 4; ++direction) if (optimal[direction])
            CloneMCJ_BlockFlowing_FlowInto(world,
                x + (direction == 0 ? -1 : direction == 1 ? 1 : 0), y,
                z + (direction == 2 ? -1 : direction == 3 ? 1 : 0), blockID,
                sideDecay);
    }
}

void CloneMCJ_BlockFlowing_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockFlowing_JavaName(void)
{
    return "net.minecraft.src.BlockFlowing";
}

const char *CloneMCJ_BlockFlowing_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockFlowing_JavaSourceHash32(void)
{
    return 0x28C5E09DUL;
}
