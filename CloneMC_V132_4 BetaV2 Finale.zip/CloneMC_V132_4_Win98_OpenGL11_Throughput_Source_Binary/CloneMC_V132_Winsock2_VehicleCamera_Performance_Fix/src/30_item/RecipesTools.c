/*
 * Direct C89 recipe registrations ported from RecipesTools.java.
 */
#include "clonemc_java_port_30_item.h"

static const short g_cloneMCRecipesToolsRecipeData[][25] = {
    {1, 270, 0, 1, 3, 3, 9, 5, -1, 5, -1, 5, -1, 0, 0, 280, 0, 0, 0, 0, 0, 280, 0, 0, 0},
    {1, 269, 0, 1, 1, 3, 3, 5, -1, 280, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 271, 0, 1, 2, 3, 6, 5, -1, 5, -1, 5, -1, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 290, 0, 1, 2, 3, 6, 5, -1, 5, -1, 0, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 274, 0, 1, 3, 3, 9, 4, -1, 4, -1, 4, -1, 0, 0, 280, 0, 0, 0, 0, 0, 280, 0, 0, 0},
    {1, 273, 0, 1, 1, 3, 3, 4, -1, 280, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 275, 0, 1, 2, 3, 6, 4, -1, 4, -1, 4, -1, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 291, 0, 1, 2, 3, 6, 4, -1, 4, -1, 0, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 257, 0, 1, 3, 3, 9, 265, 0, 265, 0, 265, 0, 0, 0, 280, 0, 0, 0, 0, 0, 280, 0, 0, 0},
    {1, 256, 0, 1, 1, 3, 3, 265, 0, 280, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 258, 0, 1, 2, 3, 6, 265, 0, 265, 0, 265, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 292, 0, 1, 2, 3, 6, 265, 0, 265, 0, 0, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 278, 0, 1, 3, 3, 9, 264, 0, 264, 0, 264, 0, 0, 0, 280, 0, 0, 0, 0, 0, 280, 0, 0, 0},
    {1, 277, 0, 1, 1, 3, 3, 264, 0, 280, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 279, 0, 1, 2, 3, 6, 264, 0, 264, 0, 264, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 293, 0, 1, 2, 3, 6, 264, 0, 264, 0, 0, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 285, 0, 1, 3, 3, 9, 266, 0, 266, 0, 266, 0, 0, 0, 280, 0, 0, 0, 0, 0, 280, 0, 0, 0},
    {1, 284, 0, 1, 1, 3, 3, 266, 0, 280, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 286, 0, 1, 2, 3, 6, 266, 0, 266, 0, 266, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 294, 0, 1, 2, 3, 6, 266, 0, 266, 0, 0, 0, 280, 0, 0, 0, 280, 0, 0, 0, 0, 0, 0, 0},
    {1, 359, 0, 1, 2, 2, 4, 0, 0, 265, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void CloneMCJ_RecipesTools_AddNative(void)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int recipeIndex;
    int ingredientIndex;
    const short *data;
    for (recipeIndex = 0; recipeIndex < (int)(sizeof(g_cloneMCRecipesToolsRecipeData) /
        sizeof(g_cloneMCRecipesToolsRecipeData[0])); ++recipeIndex) {
        data = g_cloneMCRecipesToolsRecipeData[recipeIndex];
        CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
        for (ingredientIndex = 0;
             ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
             ++ingredientIndex) {
            ingredients[ingredientIndex].itemID =
                data[7 + ingredientIndex * 2];
            ingredients[ingredientIndex].itemDamage =
                data[8 + ingredientIndex * 2];
        }
        if (data[0])
            CloneMCJ_CraftingManager_AddShapedNative(&output,
                data[4], data[5], ingredients);
        else
            CloneMCJ_CraftingManager_AddShapelessNative(&output,
                data[6], ingredients);
    }
}

void CloneMCJ_RecipesTools_Register(void) { }
const char *CloneMCJ_RecipesTools_JavaName(void)
{ return "net.minecraft.src.RecipesTools"; }
const char *CloneMCJ_RecipesTools_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipesTools_JavaSourceHash32(void)
{ return 0x52FFB3BEUL; }
