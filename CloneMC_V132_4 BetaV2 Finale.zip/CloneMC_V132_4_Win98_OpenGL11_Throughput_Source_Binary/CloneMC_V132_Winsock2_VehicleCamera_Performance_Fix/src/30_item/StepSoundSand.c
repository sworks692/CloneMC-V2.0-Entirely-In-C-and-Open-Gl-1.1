/*
 * CloneMC Java port scaffold: StepSoundSand
 *
 * Java source: StepSoundSand.java
 * Java type: class StepSoundSand
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: e0262e4ffe60ad3e594ad6d83d61b8148400579e883aa03b7d78e744e0aa612a
 * Java lines: 24
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: StepSound, f
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public String stepSoundDir()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_StepSoundSand_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_StepSoundSand_JavaName(void)
{
    return "net.minecraft.src.StepSoundSand";
}

const char *CloneMCJ_StepSoundSand_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_StepSoundSand_JavaSourceHash32(void)
{
    return 0xE0262E4FUL;
}
