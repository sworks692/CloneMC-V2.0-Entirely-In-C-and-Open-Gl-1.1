/*
 * Direct C89 recipe registrations ported from RecipesWeapons.java.
 */
#include "clonemc_java_port_30_item.h"

static const short g_cloneMCRecipesWeaponsRecipeData[][25] = {
    {1, 268, 0, 1, 1, 3, 3, 5, -1, 5, -1, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 272, 0, 1, 1, 3, 3, 4, -1, 4, -1, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 267, 0, 1, 1, 3, 3, 265, 0, 265, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 276, 0, 1, 1, 3, 3, 264, 0, 264, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 283, 0, 1, 1, 3, 3, 266, 0, 266, 0, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 261, 0, 1, 3, 3, 9, 0, 0, 280, 0, 287, 0, 280, 0, 0, 0, 287, 0, 0, 0, 280, 0, 287, 0},
    {1, 262, 0, 4, 1, 3, 3, 318, 0, 280, 0, 288, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void CloneMCJ_RecipesWeapons_AddNative(void)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int recipeIndex;
    int ingredientIndex;
    const short *data;
    for (recipeIndex = 0; recipeIndex < (int)(sizeof(g_cloneMCRecipesWeaponsRecipeData) /
        sizeof(g_cloneMCRecipesWeaponsRecipeData[0])); ++recipeIndex) {
        data = g_cloneMCRecipesWeaponsRecipeData[recipeIndex];
        CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
        for (ingredientIndex = 0;
             ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
             ++ingredientIndex) {
            ingredients[ingredientIndex].itemID =
                data[7 + ingredientIndex * 2];
            ingredients[ingredientIndex].itemDamage =
                data[8 + ingredientIndex * 2];
        }
        if (data[0])
            CloneMCJ_CraftingManager_AddShapedNative(&output,
                data[4], data[5], ingredients);
        else
            CloneMCJ_CraftingManager_AddShapelessNative(&output,
                data[6], ingredients);
    }
}

void CloneMCJ_RecipesWeapons_Register(void) { }
const char *CloneMCJ_RecipesWeapons_JavaName(void)
{ return "net.minecraft.src.RecipesWeapons"; }
const char *CloneMCJ_RecipesWeapons_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipesWeapons_JavaSourceHash32(void)
{ return 0xD87FF5E0UL; }
