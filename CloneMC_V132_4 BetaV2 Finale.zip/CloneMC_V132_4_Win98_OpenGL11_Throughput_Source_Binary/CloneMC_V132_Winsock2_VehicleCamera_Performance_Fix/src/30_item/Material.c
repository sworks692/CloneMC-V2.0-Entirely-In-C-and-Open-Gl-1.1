/*
 * CloneMC Java port scaffold: Material
 *
 * Java source: Material.java
 * Java type: class Material
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: e4516a6a34842c6f57ca7ff157ed9b480cb6c1ad745b0ac4b7bd62b480954197
 * Java lines: 175
 * Discovered declared fields: 34
 * Discovered declared methods/constructors: 16
 * Referenced Java classes: MaterialTransparent, MapColor, MaterialLiquid, MaterialLogic, MaterialPortal
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static final Material air
 * - public static final Material grassMaterial
 * - public static final Material ground
 * - public static final Material wood
 * - public static final Material rock
 * - public static final Material iron
 * - public static final Material water
 * - public static final Material lava
 * - public static final Material leaves
 * - public static final Material plants
 * - public static final Material sponge
 * - public static final Material cloth
 * - public static final Material fire
 * - public static final Material sand
 * - public static final Material circuits
 * - public static final Material glass
 * - public static final Material tnt
 * - public static final Material field_4262_q
 * - public static final Material ice
 * - public static final Material snow
 * - public static final Material builtSnow
 * - public static final Material cactus
 * - public static final Material clay
 * - public static final Material pumpkin
 * - public static final Material portal
 * - public static final Material cakeMaterial
 * - public static final Material field_31068_A
 * - public static final Material field_31067_B
 * - private boolean canBurn
 * - private boolean groundCover
 * - private boolean isOpaque
 * - public final MapColor materialMapColor
 * - private boolean canHarvest
 * - private int mobilityFlag
 *
 * Java method/constructor inventory:
 * - public Material(MapColor mapcolor)
 * - public boolean getIsLiquid()
 * - public boolean isSolid()
 * - public boolean getCanBlockGrass()
 * - public boolean getIsSolid()
 * - private Material setIsTranslucent()
 * - private Material setNoHarvest()
 * - private Material setBurning()
 * - public boolean getBurning()
 * - public Material setIsGroundCover()
 * - public boolean getIsGroundCover()
 * - public boolean getIsTranslucent()
 * - public boolean getIsHarvestable()
 * - public int getMaterialMobility()
 * - protected Material setNoPushMobility()
 * - protected Material setImmovableMobility()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_Material_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Material_JavaName(void)
{
    return "net.minecraft.src.Material";
}

const char *CloneMCJ_Material_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_Material_JavaSourceHash32(void)
{
    return 0xE4516A6AUL;
}
