/*
 * CloneMC Java port scaffold: ItemBed
 *
 * Java source: ItemBed.java
 * Java type: class ItemBed
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 58b527773e4cd6908cb796d1654e5b932c23baa7bd4ed1957ea0211e4e32f5e5
 * Java lines: 59
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, Block, BlockBed, EntityPlayer, MathHelper, World, ItemStack, j, k, blockbed.blockID
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemBed(int i)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemBed_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemBed_JavaName(void)
{
    return "net.minecraft.src.ItemBed";
}

const char *CloneMCJ_ItemBed_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemBed_JavaSourceHash32(void)
{
    return 0x58B52777UL;
}
