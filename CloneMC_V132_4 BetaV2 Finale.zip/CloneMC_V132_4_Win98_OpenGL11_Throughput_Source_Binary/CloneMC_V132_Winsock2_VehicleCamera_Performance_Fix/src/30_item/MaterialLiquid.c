/*
 * CloneMC Java port scaffold: MaterialLiquid
 *
 * Java source: MaterialLiquid.java
 * Java type: class MaterialLiquid
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: Material
 * Implements: (none declared)
 * Source SHA-256: ce5cb9796752e95100f3fc1a0232a5b2f8db331228b001720af4108675dfdbbb
 * Java lines: 36
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: Material, MapColor
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public MaterialLiquid(MapColor mapcolor)
 * - public boolean getIsLiquid()
 * - public boolean getIsSolid()
 * - public boolean isSolid()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_MaterialLiquid_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MaterialLiquid_JavaName(void)
{
    return "net.minecraft.src.MaterialLiquid";
}

const char *CloneMCJ_MaterialLiquid_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_MaterialLiquid_JavaSourceHash32(void)
{
    return 0xCE5CB979UL;
}
