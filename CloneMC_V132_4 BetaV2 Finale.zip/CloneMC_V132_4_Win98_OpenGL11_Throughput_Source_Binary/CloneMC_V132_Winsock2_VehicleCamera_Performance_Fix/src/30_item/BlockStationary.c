/*
 * CloneMC Java port scaffold: BlockStationary
 *
 * Java source: BlockStationary.java
 * Java type: class BlockStationary
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockFluid
 * Implements: (none declared)
 * Source SHA-256: 5e4f942d43a2289be467c7d8101d9e6449eeb86a1b2d866d604ef1f722e55a73
 * Java lines: 79
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: BlockFluid, Material, World, Block, BlockFire, i, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockStationary(int i, Material material)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - private void func_30004_j(World world, int i, int j, int k)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - private boolean func_301_k(World world, int i, int j, int k)
 *
 * Priority 11 directly implements still-to-moving neighbor transitions and the
 * uploaded Java stationary-lava fire tick below.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockStationary_Burns(int id)
{
    return id == 5 || id == 17 || id == 18 || id == 30 || id == 31 ||
        id == 35 || id == 47 || id == 53 || id == 85;
}

static void CloneMCJ_BlockStationary_LavaTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int count;
    int i;
    int id;
    (void)blockID; (void)userData;
    if (!world || !random) return;
    count = CloneMCJavaRandom_NextIntBound(random, 3);
    for (i = 0; i < count; ++i) {
        x += CloneMCJavaRandom_NextIntBound(random, 3) - 1;
        ++y;
        z += CloneMCJavaRandom_NextIntBound(random, 3) - 1;
        id = CloneMCJ_World_GetBlockId(world, x, y, z);
        if (id == 0) {
            if (CloneMCJ_BlockStationary_Burns(CloneMCJ_World_GetBlockId(world, x - 1, y, z)) ||
                CloneMCJ_BlockStationary_Burns(CloneMCJ_World_GetBlockId(world, x + 1, y, z)) ||
                CloneMCJ_BlockStationary_Burns(CloneMCJ_World_GetBlockId(world, x, y - 1, z)) ||
                CloneMCJ_BlockStationary_Burns(CloneMCJ_World_GetBlockId(world, x, y + 1, z)) ||
                CloneMCJ_BlockStationary_Burns(CloneMCJ_World_GetBlockId(world, x, y, z - 1)) ||
                CloneMCJ_BlockStationary_Burns(CloneMCJ_World_GetBlockId(world, x, y, z + 1))) {
                CloneMCJ_World_SetBlockNotify(world, x, y, z, 51);
                return;
            }
        } else if (CloneMCJ_World_IsSolidBlockID(id)) return;
    }
}

static void CloneMCJ_BlockFluid_Added(CloneMCJ_World *world, int x, int y, int z)
{
    int id;
    if (!world) return;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (CloneMCJ_BlockFluid_CheckForHarden(world, x, y, z)) return;
    if (id == 8 || id == 10)
        CloneMCJ_World_ScheduleBlockUpdate(world, x, y, z, id,
            CloneMCJ_BlockFluid_TickRate(id));
}

static void CloneMCJ_BlockFluid_Neighbor(CloneMCJ_World *world, int x, int y, int z,
    int neighborID)
{
    int id;
    int metadata;
    (void)neighborID;
    if (!world) return;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (CloneMCJ_BlockFluid_CheckForHarden(world, x, y, z)) return;
    if (id == 9 || id == 11) {
        metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
        world->editingBlocks = 1;
        CloneMCJ_World_SetBlockWithMetadata(world, x, y, z, id - 1, metadata);
        world->editingBlocks = 0;
        CloneMCJ_World_ScheduleBlockUpdate(world, x, y, z, id - 1,
            CloneMCJ_BlockFluid_TickRate(id));
    }
}

void CloneMCJ_BlockFluid_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    int id;
    if (!world) return;
    for (id = 8; id <= 11; ++id) {
        block = CloneMCJ_BlockRegistry_GetMutable(id);
        block->neighborChanged = CloneMCJ_BlockFluid_Neighbor;
        block->onBlockAdded = CloneMCJ_BlockFluid_Added;
    }
    CloneMCJ_World_RegisterBlockTick(world, 8, 1, CloneMCJ_BlockFlowing_UpdateTick, 0);
    CloneMCJ_World_RegisterBlockTick(world, 9, 0, 0, 0);
    CloneMCJ_World_RegisterBlockTick(world, 10, 1, CloneMCJ_BlockFlowing_UpdateTick, 0);
    CloneMCJ_World_RegisterBlockTick(world, 11, 1, CloneMCJ_BlockStationary_LavaTick, 0);
}

void CloneMCJ_BlockStationary_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockStationary_JavaName(void)
{
    return "net.minecraft.src.BlockStationary";
}

const char *CloneMCJ_BlockStationary_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockStationary_JavaSourceHash32(void)
{
    return 0x5E4F942DUL;
}
