/*
 * Direct C89 recipe registrations ported from RecipesIngots.java.
 */
#include "clonemc_java_port_30_item.h"

static const short g_cloneMCRecipesIngotsRecipeData[][25] = {
    {1, 41, 0, 1, 3, 3, 9, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0},
    {1, 266, 0, 9, 1, 1, 1, 41, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 42, 0, 1, 3, 3, 9, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0},
    {1, 265, 0, 9, 1, 1, 1, 42, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 57, 0, 1, 3, 3, 9, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0},
    {1, 264, 0, 9, 1, 1, 1, 57, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 22, 0, 1, 3, 3, 9, 351, 4, 351, 4, 351, 4, 351, 4, 351, 4, 351, 4, 351, 4, 351, 4, 351, 4},
    {1, 351, 4, 9, 1, 1, 1, 22, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void CloneMCJ_RecipesIngots_AddNative(void)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int recipeIndex;
    int ingredientIndex;
    const short *data;
    for (recipeIndex = 0; recipeIndex < (int)(sizeof(g_cloneMCRecipesIngotsRecipeData) /
        sizeof(g_cloneMCRecipesIngotsRecipeData[0])); ++recipeIndex) {
        data = g_cloneMCRecipesIngotsRecipeData[recipeIndex];
        CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
        for (ingredientIndex = 0;
             ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
             ++ingredientIndex) {
            ingredients[ingredientIndex].itemID =
                data[7 + ingredientIndex * 2];
            ingredients[ingredientIndex].itemDamage =
                data[8 + ingredientIndex * 2];
        }
        if (data[0])
            CloneMCJ_CraftingManager_AddShapedNative(&output,
                data[4], data[5], ingredients);
        else
            CloneMCJ_CraftingManager_AddShapelessNative(&output,
                data[6], ingredients);
    }
}

void CloneMCJ_RecipesIngots_Register(void) { }
const char *CloneMCJ_RecipesIngots_JavaName(void)
{ return "net.minecraft.src.RecipesIngots"; }
const char *CloneMCJ_RecipesIngots_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipesIngots_JavaSourceHash32(void)
{ return 0x64141060UL; }
