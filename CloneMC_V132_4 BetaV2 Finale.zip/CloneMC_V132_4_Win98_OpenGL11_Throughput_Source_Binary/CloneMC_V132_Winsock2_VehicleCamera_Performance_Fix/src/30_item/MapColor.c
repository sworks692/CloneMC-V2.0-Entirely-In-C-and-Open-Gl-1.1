/*
 * CloneMC Java port scaffold: MapColor
 *
 * Java source: MapColor.java
 * Java type: class MapColor
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 62ee31e47954757c582fb185351479e982b92503cf14abdb63e7d5ace43ca9cb
 * Java lines: 37
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static final MapColor mapColorArray[] = new MapColor[16]
 * - public final int colorValue
 * - public final int colorIndex
 *
 * Java method/constructor inventory:
 * - private MapColor(int i, int j)
 * - public static final MapColor airColor = new MapColor(0, 0)
 * - public static final MapColor grassColor = new MapColor(1, 0x7fb238)
 * - public static final MapColor sandColor = new MapColor(2, 0xf7e9a3)
 * - public static final MapColor clothColor = new MapColor(3, 0xa7a7a7)
 * - public static final MapColor tntColor = new MapColor(4, 0xff0000)
 * - public static final MapColor iceColor = new MapColor(5, 0xa0a0ff)
 * - public static final MapColor ironColor = new MapColor(6, 0xa7a7a7)
 * - public static final MapColor foliageColor = new MapColor(7, 31744)
 * - public static final MapColor snowColor = new MapColor(8, 0xffffff)
 * - public static final MapColor clayColor = new MapColor(9, 0xa4a8b8)
 * - public static final MapColor dirtColor = new MapColor(10, 0xb76a2f)
 * - public static final MapColor stoneColor = new MapColor(11, 0x707070)
 * - public static final MapColor waterColor = new MapColor(12, 0x4040ff)
 * - public static final MapColor woodColor = new MapColor(13, 0x685332)
 *
 * Native implementation preserves the Java mapColorArray indices and exact
 * 24-bit RGB values used by MapItemRenderer.
 */
#include "clonemc_java_port_30_item.h"

static const unsigned long g_cloneMCMapColors[16]={
    0x000000UL,0x7FB238UL,0xF7E9A3UL,0xA7A7A7UL,
    0xFF0000UL,0xA0A0FFUL,0xA7A7A7UL,0x007C00UL,
    0xFFFFFFUL,0xA4A8B8UL,0xB76A2FUL,0x707070UL,
    0x4040FFUL,0x685332UL,0x000000UL,0x000000UL
};

unsigned long CloneMCJ_MapColor_GetValue(int colorIndex)
{
    if(colorIndex<0||colorIndex>=16)return 0UL;
    return g_cloneMCMapColors[colorIndex];
}

void CloneMCJ_MapColor_Register(void)
{
    /* The immutable Java table is materialized above at native load time. */
}

const char *CloneMCJ_MapColor_JavaName(void)
{
    return "net.minecraft.src.MapColor";
}

const char *CloneMCJ_MapColor_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_MapColor_JavaSourceHash32(void)
{
    return 0x62EE31E4UL;
}
