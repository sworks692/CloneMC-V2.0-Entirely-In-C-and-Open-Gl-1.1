/*
 * CloneMC Java port scaffold: BlockGlowStone
 *
 * Java source: BlockGlowStone.java
 * Java type: class BlockGlowStone
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 4540f4f7998615a1c43fd9edd2f4c0654aa9ff5b90af4002292ba38d3cfb8ee9
 * Java lines: 30
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Block, Item, Material, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockGlowStone(int i, int j, Material material)
 * - public int quantityDropped(Random random)
 * - public int idDropped(int i, Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockGlowStone_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockGlowStone_JavaName(void)
{
    return "net.minecraft.src.BlockGlowStone";
}

const char *CloneMCJ_BlockGlowStone_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockGlowStone_JavaSourceHash32(void)
{
    return 0x4540F4F7UL;
}
