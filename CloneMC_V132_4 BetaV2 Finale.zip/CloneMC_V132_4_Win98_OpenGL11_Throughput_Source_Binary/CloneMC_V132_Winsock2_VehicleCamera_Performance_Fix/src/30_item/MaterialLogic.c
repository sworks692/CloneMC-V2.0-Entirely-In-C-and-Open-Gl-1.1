/*
 * CloneMC Java port scaffold: MaterialLogic
 *
 * Java source: MaterialLogic.java
 * Java type: class MaterialLogic
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: Material
 * Implements: (none declared)
 * Source SHA-256: 8b0cdf15224efc7bab435af9a6011ca375f661fc9e043bbc09a79e32dadb5eb2
 * Java lines: 34
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: Material, MapColor
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public MaterialLogic(MapColor mapcolor)
 * - public boolean isSolid()
 * - public boolean getCanBlockGrass()
 * - public boolean getIsSolid()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_MaterialLogic_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MaterialLogic_JavaName(void)
{
    return "net.minecraft.src.MaterialLogic";
}

const char *CloneMCJ_MaterialLogic_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_MaterialLogic_JavaSourceHash32(void)
{
    return 0x8B0CDF15UL;
}
