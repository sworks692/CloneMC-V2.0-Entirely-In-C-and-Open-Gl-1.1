/*
 * CloneMC Java port scaffold: ItemCoal
 *
 * Java source: ItemCoal.java
 * Java type: class ItemCoal
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: f84adf3ae19d2425ff63ec2056b3cd622ddaeff51163ba4bb0e902a833028fe7
 * Java lines: 32
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, ItemStack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemCoal(int i)
 * - public String getItemNameIS(ItemStack itemstack)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemCoal_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemCoal_JavaName(void)
{
    return "net.minecraft.src.ItemCoal";
}

const char *CloneMCJ_ItemCoal_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemCoal_JavaSourceHash32(void)
{
    return 0xF84ADF3AUL;
}
