/*
 * CloneMC Java port scaffold: BlockFarmland
 *
 * Java source: BlockFarmland.java
 * Java type: class BlockFarmland
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: bb617f2dfe892b8463b73b5908518f8b10cdd1f75292293f207594178525504a
 * Java lines: 139
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: Block, Material, AxisAlignedBB, World, Entity, i, j, k, world.setBlockWithNo
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockFarmland(int i)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public void onEntityWalking(World world, int i, int j, int k, Entity entity)
 * - private boolean isCropsNearby(World world, int i, int j, int k)
 * - private boolean isWaterNearby(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public int idDropped(int i, Random random)
 *
 * Priority 11 directly ports Java moisture decay, four-block water search,
 * rain hydration, crop protection and solid-above neighbor conversion.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockFarmland_WaterNearby(CloneMCJ_World *world, int x, int y, int z)
{
    int xx;
    int yy;
    int zz;
    for (xx = x - 4; xx <= x + 4; ++xx)
        for (yy = y; yy <= y + 1; ++yy)
            for (zz = z - 4; zz <= z + 4; ++zz)
                if (CloneMCJ_World_IsWaterBlock(CloneMCJ_World_GetBlockId(world, xx, yy, zz)))
                    return 1;
    return 0;
}

static void CloneMCJ_BlockFarmland_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int metadata;
    (void)blockID; (void)userData;
    if (!world || !random || CloneMCJavaRandom_NextIntBound(random, 5) != 0) return;
    if (CloneMCJ_BlockFarmland_WaterNearby(world, x, y, z) ||
        CloneMCJ_World_CanBlockBeRainedOn(world, x, y + 1, z)) {
        CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, 7);
        return;
    }
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (metadata > 0) CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, metadata - 1);
    else if (CloneMCJ_World_GetBlockId(world, x, y + 1, z) != 59)
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 3);
}

static void CloneMCJ_BlockFarmland_Neighbor(CloneMCJ_World *world, int x, int y,
    int z, int neighborID)
{
    int above;
    const CloneMCJ_BlockDefinition *block;
    (void)neighborID;
    above = CloneMCJ_World_GetBlockId(world, x, y + 1, z);
    block = CloneMCJ_BlockRegistry_Get(above);
    if (block && block->solid) CloneMCJ_World_SetBlockNotify(world, x, y, z, 3);
}

void CloneMCJ_BlockFarmland_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(60);
    if (block) { block->tickRandomly = 1; block->neighborChanged = CloneMCJ_BlockFarmland_Neighbor; }
    CloneMCJ_World_RegisterBlockTick(world, 60, 1, CloneMCJ_BlockFarmland_UpdateTick, 0);
}

void CloneMCJ_BlockFarmland_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockFarmland_JavaName(void)
{
    return "net.minecraft.src.BlockFarmland";
}

const char *CloneMCJ_BlockFarmland_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockFarmland_JavaSourceHash32(void)
{
    return 0xBB617F2DUL;
}
