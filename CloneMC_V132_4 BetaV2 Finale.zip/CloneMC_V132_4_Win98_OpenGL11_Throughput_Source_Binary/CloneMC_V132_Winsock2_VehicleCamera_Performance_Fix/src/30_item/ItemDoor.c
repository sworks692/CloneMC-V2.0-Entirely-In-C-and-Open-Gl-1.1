/*
 * CloneMC Java port scaffold: ItemDoor
 *
 * Java source: ItemDoor.java
 * Java type: class ItemDoor
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: b2245a0ceffedd0b94e5b5f15313634e4f5818dc2d9454aa92f4f98ed1a63a32
 * Java lines: 90
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, Material, Block, EntityPlayer, MathHelper, World, ItemStack, i, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Material doorMaterial
 *
 * Java method/constructor inventory:
 * - public ItemDoor(int i, Material material)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemDoor_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemDoor_JavaName(void)
{
    return "net.minecraft.src.ItemDoor";
}

const char *CloneMCJ_ItemDoor_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemDoor_JavaSourceHash32(void)
{
    return 0xB2245A0CUL;
}
