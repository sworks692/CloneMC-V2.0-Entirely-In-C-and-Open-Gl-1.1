/*
 * CloneMC Java port scaffold: IInventory
 *
 * Java source: IInventory.java
 * Java type: interface IInventory
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 9148ea175ad4cddba31cffa9bf27e25dd76c98d4b3cfc08dbcff64c546aca5d3
 * Java lines: 30
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: ItemStack, EntityPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract int getSizeInventory()
 * - public abstract ItemStack getStackInSlot(int i)
 * - public abstract ItemStack decrStackSize(int i, int j)
 * - public abstract void setInventorySlotContents(int i, ItemStack itemstack)
 * - public abstract String getInvName()
 * - public abstract int getInventoryStackLimit()
 * - public abstract void onInventoryChanged()
 * - public abstract boolean canInteractWith(EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_IInventory_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_IInventory_JavaName(void)
{
    return "net.minecraft.src.IInventory";
}

const char *CloneMCJ_IInventory_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_IInventory_JavaSourceHash32(void)
{
    return 0x9148EA17UL;
}
