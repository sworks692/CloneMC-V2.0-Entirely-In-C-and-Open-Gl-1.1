/*
 * CloneMC Java port scaffold: BlockSand
 *
 * Java source: BlockSand.java
 * Java type: class BlockSand
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 9f7d7fa1ff9caa559170216a8798a004be35a887ef3c81c911cc27bbdf316ba8
 * Java lines: 87
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: Block, Material, World, EntityFallingSand, BlockFire, j, k, blockID, i, l
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static boolean fallInstantly = false
 *
 * Java method/constructor inventory:
 * - public BlockSand(int i, int j)
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - private void tryToFall(World world, int i, int j, int k)
 * - public int tickRate()
 * - public static boolean canFallBelow(World world, int i, int j, int k)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"

static int CloneMCJ_BlockSand_CanFallBelow(CloneMCJ_World *world,int x,int y,int z)
{
    int id;const CloneMCJ_BlockDefinition *block;
    if(!world||y<0)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id==0||id==51)return 1;
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&(block->material==CLONEMC_J_MATERIAL_WATER||block->material==CLONEMC_J_MATERIAL_LAVA);
}

static int CloneMCJ_BlockSand_AreaLoaded(CloneMCJ_World *world,int x,int z)
{
    int minX,maxX,minZ,maxZ,cx,cz;
    minX=CloneMCJ_World_GlobalToChunk(x-32);maxX=CloneMCJ_World_GlobalToChunk(x+32);
    minZ=CloneMCJ_World_GlobalToChunk(z-32);maxZ=CloneMCJ_World_GlobalToChunk(z+32);
    for(cx=minX;cx<=maxX;++cx)for(cz=minZ;cz<=maxZ;++cz)
        if(!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,cx,cz))return 0;
    return 1;
}

static void CloneMCJ_BlockSand_Schedule(CloneMCJ_World *world,int x,int y,int z)
{
    int id;if(!world)return;id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id==12||id==13)CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,id,3);
}

static void CloneMCJ_BlockSand_Neighbor(CloneMCJ_World *world,int x,int y,int z,int neighbor)
{(void)neighbor;CloneMCJ_BlockSand_Schedule(world,x,y,z);}

static void CloneMCJ_BlockSand_Update(CloneMCJ_World *world,int x,int y,int z,int id,CloneMCJavaRandom *random,void *user)
{
    CloneMCJ_GameplayState *gameplay;int metadata,landing,i;
    (void)random;(void)user;
    if(!world||world->multiplayerWorld||y<=0||CloneMCJ_World_GetBlockId(world,x,y,z)!=id||
       !CloneMCJ_BlockSand_CanFallBelow(world,x,y-1,z))return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(gameplay&&CloneMCJ_BlockSand_AreaLoaded(world,x,z)){
        if(!CloneMCJ_World_SetBlockNotify(world,x,y,z,0))return;
        if(CloneMCJ_Gameplay_SpawnVehicle(gameplay,CLONEMC_J_VEHICLE_FALLING_BLOCK,
                (double)x+0.5,(double)y+0.5,(double)z+0.5,id)){
            for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i)if(gameplay->vehicles[i].active&&
                gameplay->vehicles[i].type==CLONEMC_J_VEHICLE_FALLING_BLOCK&&
                gameplay->vehicles[i].blockID==id&&gameplay->vehicles[i].entity.posX==(double)x+0.5&&
                gameplay->vehicles[i].entity.posZ==(double)z+0.5){gameplay->vehicles[i].blockData=metadata;break;}
            return;
        }
        CloneMCJ_World_SetBlockWithMetadataNotify(world,x,y,z,id,metadata);
        return;
    }
    /* Java's fallInstantly/unloaded-neighborhood fallback moves the block in
     * one bounded operation without forcing chunk generation. */
    if(!CloneMCJ_World_SetBlockNotify(world,x,y,z,0))return;
    landing=y;
    while(landing>0&&CloneMCJ_BlockSand_CanFallBelow(world,x,landing-1,z))--landing;
    if(landing>0)CloneMCJ_World_SetBlockWithMetadataNotify(world,x,landing,z,id,metadata);
}

void CloneMCJ_BlockSand_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;int id;
    if(!world)return;
    for(id=12;id<=13;++id){
        block=CloneMCJ_BlockRegistry_GetMutable(id);
        if(block){block->onBlockAdded=CloneMCJ_BlockSand_Schedule;block->neighborChanged=CloneMCJ_BlockSand_Neighbor;}
        CloneMCJ_World_RegisterBlockTick(world,id,1,CloneMCJ_BlockSand_Update,0);
    }
}

void CloneMCJ_BlockSand_Register(void) { }
const char *CloneMCJ_BlockSand_JavaName(void){return "net.minecraft.src.BlockSand";}
const char *CloneMCJ_BlockSand_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockSand_JavaSourceHash32(void){return 0x9F7D7FA1UL;}
