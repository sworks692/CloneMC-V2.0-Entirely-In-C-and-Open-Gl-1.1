/*
 * CloneMC Java port scaffold: TileEntitySign
 *
 * Java source: TileEntitySign.java
 * Java type: class TileEntitySign
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: TileEntity
 * Implements: (none declared)
 * Source SHA-256: bfefe4253520992ef8f963be3657bdac1dbd233f774622b559b5263265f01722
 * Java lines: 50
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: TileEntity, NBTTagCompound
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int lineBeingEdited
 * - private boolean field_25062_c
 *
 * Java method/constructor inventory:
 * - public TileEntitySign()
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_TileEntitySign_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_TileEntitySign_JavaName(void)
{
    return "net.minecraft.src.TileEntitySign";
}

const char *CloneMCJ_TileEntitySign_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_TileEntitySign_JavaSourceHash32(void)
{
    return 0xBFEFE425UL;
}
