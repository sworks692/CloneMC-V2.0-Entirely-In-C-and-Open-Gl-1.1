/*
 * CloneMC Java port scaffold: ItemStack
 *
 * Java source: ItemStack.java
 * Java type: class ItemStack
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: a7cec3eb0c46e52202e251ad12c111a6bf4ee2816c90311e24ec85e1f7bb2c45
 * Java lines: 292
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 42
 * Referenced Java classes: Block, Item, StatList, EntityPlayer, NBTTagCompound, World, Entity, EntityLiving, i, entityplayer, world, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int stackSize
 * - public int animationsToGo
 * - public int itemID
 * - private int itemDamage
 *
 * Java method/constructor inventory:
 * - public ItemStack(Block block)
 * - public ItemStack(Block block, int i)
 * - public ItemStack(Block block, int i, int j)
 * - public ItemStack(Item item)
 * - public ItemStack(Item item, int i)
 * - public ItemStack(Item item, int i, int j)
 * - public ItemStack(int i, int j, int k)
 * - public ItemStack(NBTTagCompound nbttagcompound)
 * - public ItemStack splitStack(int i)
 * - public Item getItem()
 * - public int getIconIndex()
 * - public boolean useItem(EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 * - public float getStrVsBlock(Block block)
 * - public ItemStack useItemRightClick(World world, EntityPlayer entityplayer)
 * - public NBTTagCompound writeToNBT(NBTTagCompound nbttagcompound)
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - public int getMaxStackSize()
 * - public boolean isStackable()
 * - public boolean isItemStackDamageable()
 * - public boolean getHasSubtypes()
 * - public boolean isItemDamaged()
 * - public int getItemDamageForDisplay()
 * - public int getItemDamage()
 * - public void setItemDamage(int i)
 * - public int getMaxDamage()
 * - public void damageItem(int i, Entity entity)
 * - public void hitEntity(EntityLiving entityliving, EntityPlayer entityplayer)
 * - public void onDestroyBlock(int i, int j, int k, int l, EntityPlayer entityplayer)
 * - public int getDamageVsEntity(Entity entity)
 * - public boolean canHarvestBlock(Block block)
 * - public void func_1097_a(EntityPlayer entityplayer)
 * - public void useItemOnEntity(EntityLiving entityliving)
 * - public ItemStack copy()
 * - public static boolean areItemStacksEqual(ItemStack itemstack, ItemStack itemstack1)
 * - private boolean isItemStackEqual(ItemStack itemstack)
 * - public boolean isItemEqual(ItemStack itemstack)
 * - public String getItemName()
 * - public static ItemStack copyItemStack(ItemStack itemstack)
 * - public String toString()
 * - public void updateAnimation(World world, Entity entity, int i, boolean flag)
 * - public void onCrafting(World world, EntityPlayer entityplayer)
 * - public boolean isStackEqual(ItemStack itemstack)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_30_item.h"
#include "../10_save/clonemc_java_port_10_save.h"

void CloneMCJ_ItemStack_Clear(CloneMCJ_ItemStack *stack)
{
    if (!stack) return;
    stack->itemID = -1;
    stack->stackSize = 0;
    stack->itemDamage = 0;
    stack->animationsToGo = 0;
}

void CloneMCJ_ItemStack_Initialize(CloneMCJ_ItemStack *stack, int itemID, int count, int damage)
{
    if (!stack) return;
    stack->itemID = itemID;
    stack->stackSize = count > 0 ? count : 0;
    stack->itemDamage = damage > 0 ? damage : 0;
    stack->animationsToGo = 0;
    if (stack->stackSize == 0) CloneMCJ_ItemStack_Clear(stack);
}

int CloneMCJ_ItemStack_IsEmpty(const CloneMCJ_ItemStack *stack)
{
    return !stack || stack->itemID < 0 || stack->stackSize <= 0;
}

int CloneMCJ_ItemStack_GetMaxStackSize(const CloneMCJ_ItemStack *stack)
{
    const CloneMCJ_ItemDefinition *item;
    if (CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    item = CloneMCJ_ItemRegistry_Get(stack->itemID);
    return item && item->maxStackSize > 0 ? item->maxStackSize : 64;
}

int CloneMCJ_ItemStack_IsStackableWith(const CloneMCJ_ItemStack *a, const CloneMCJ_ItemStack *b)
{
    if (CloneMCJ_ItemStack_IsEmpty(a) || CloneMCJ_ItemStack_IsEmpty(b)) return 0;
    return a->itemID == b->itemID && a->itemDamage == b->itemDamage;
}

CloneMCJ_ItemStack CloneMCJ_ItemStack_Split(CloneMCJ_ItemStack *stack, int amount)
{
    CloneMCJ_ItemStack result;
    CloneMCJ_ItemStack_Clear(&result);
    if (CloneMCJ_ItemStack_IsEmpty(stack) || amount <= 0) return result;
    if (amount > stack->stackSize) amount = stack->stackSize;
    CloneMCJ_ItemStack_Initialize(&result, stack->itemID, amount, stack->itemDamage);
    stack->stackSize -= amount;
    if (stack->stackSize <= 0) CloneMCJ_ItemStack_Clear(stack);
    return result;
}

void CloneMCJ_ItemStack_Damage(CloneMCJ_ItemStack *stack, int amount)
{
    const CloneMCJ_ItemDefinition *item;
    if (CloneMCJ_ItemStack_IsEmpty(stack) || amount <= 0) return;
    item = CloneMCJ_ItemRegistry_Get(stack->itemID);
    if (!item || item->maxDamage <= 0) return;
    stack->itemDamage += amount;
    if (stack->itemDamage > item->maxDamage) {
        --stack->stackSize;
        stack->itemDamage = 0;
        if (stack->stackSize <= 0) CloneMCJ_ItemStack_Clear(stack);
    }
}

int CloneMCJ_ItemStack_WriteNBT(const CloneMCJ_ItemStack *stack, CloneMCJ_NBTTagCompound *compound)
{
    if (!stack || !compound || CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    CloneMCJ_NBTTagCompound_SetShort(compound, "id", (CloneMCJShort)stack->itemID);
    CloneMCJ_NBTTagCompound_SetByte(compound, "Count", (CloneMCJByte)stack->stackSize);
    CloneMCJ_NBTTagCompound_SetShort(compound, "Damage", (CloneMCJShort)stack->itemDamage);
    return 1;
}

int CloneMCJ_ItemStack_ReadNBT(CloneMCJ_ItemStack *stack, const CloneMCJ_NBTTagCompound *compound)
{
    if (!stack || !compound) return 0;
    CloneMCJ_ItemStack_Initialize(stack,
        (int)CloneMCJ_NBTTagCompound_GetShort(compound, "id"),
        (int)(unsigned char)CloneMCJ_NBTTagCompound_GetByte(compound, "Count"),
        (int)CloneMCJ_NBTTagCompound_GetShort(compound, "Damage"));
    return !CloneMCJ_ItemStack_IsEmpty(stack);
}


const char *CloneMCJ_ItemStack_GetNameKey(const CloneMCJ_ItemStack *stack)
{
    static const char *woolNames[16] = {
        "tile.cloth.white","tile.cloth.orange","tile.cloth.magenta",
        "tile.cloth.lightBlue","tile.cloth.yellow","tile.cloth.lime",
        "tile.cloth.pink","tile.cloth.gray","tile.cloth.silver",
        "tile.cloth.cyan","tile.cloth.purple","tile.cloth.blue",
        "tile.cloth.brown","tile.cloth.green","tile.cloth.red",
        "tile.cloth.black"
    };
    static const char *dyeNames[16] = {
        "item.dyePowder.black","item.dyePowder.red","item.dyePowder.green",
        "item.dyePowder.brown","item.dyePowder.blue","item.dyePowder.purple",
        "item.dyePowder.cyan","item.dyePowder.silver","item.dyePowder.gray",
        "item.dyePowder.pink","item.dyePowder.lime","item.dyePowder.yellow",
        "item.dyePowder.lightBlue","item.dyePowder.magenta",
        "item.dyePowder.orange","item.dyePowder.white"
    };
    static const char *slabNames[4] = {
        "tile.stoneSlab.stone","tile.stoneSlab.sand",
        "tile.stoneSlab.wood","tile.stoneSlab.cobble"
    };
    const CloneMCJ_BlockDefinition *block;
    const CloneMCJ_ItemDefinition *item;
    int damage;
    if (CloneMCJ_ItemStack_IsEmpty(stack)) return "";
    damage = stack->itemDamage;
    if (stack->itemID == 35) return woolNames[damage & 15];
    if (stack->itemID == 31 || stack->itemID == 32) return "tile.plant";
    if (stack->itemID == 34) return "tile.pistonExtension";
    if (stack->itemID == 36) return "tile.pistonMoving";
    if (stack->itemID == 93 || stack->itemID == 94) return "item.diode";
    if (stack->itemID == 43 || stack->itemID == 44)
        return slabNames[(damage & 7) < 4 ? (damage & 7) : 0];
    if (stack->itemID == 263 && (damage & 1)) return "item.charcoal";
    if (stack->itemID == 2256) return "item.record13";
    if (stack->itemID == 2257) return "item.recordCat";
    if (stack->itemID == 351) return dyeNames[damage & 15];
    if (stack->itemID < CLONEMC_J_BLOCK_REGISTRY_SIZE) {
        block = CloneMCJ_BlockRegistry_Get(stack->itemID);
        return block && block->name ? block->name : "tile.unknown";
    }
    item = CloneMCJ_ItemRegistry_Get(stack->itemID);
    return item && item->name ? item->name : "item";
}

void CloneMCJ_ItemStack_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemStack_JavaName(void)
{
    return "net.minecraft.src.ItemStack";
}

const char *CloneMCJ_ItemStack_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemStack_JavaSourceHash32(void)
{
    return 0xA7CEC3EBUL;
}
