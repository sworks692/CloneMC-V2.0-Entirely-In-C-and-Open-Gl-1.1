/*
 * CloneMC Java port scaffold: EnumToolMaterial
 *
 * Java source: EnumToolMaterial.java
 * Java type: enum EnumToolMaterial
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: a6eb2cf3cbaacbfaa1d5c28b9c8e1e0eeca36d8533367a047e709d392b4ad9ac
 * Java lines: 81
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final int harvestLevel
 * - private final int maxUses
 * - private final float efficiencyOnProperMaterial
 * - private final int damageVsEntity
 * - private static final EnumToolMaterial field_21209_j[]
 *
 * Java method/constructor inventory:
 * - private EnumToolMaterial(String s, int i, int j, int k, float f, int l)
 * - public int getMaxUses()
 * - public float getEfficiencyOnProperMaterial()
 * - public int getDamageVsEntity()
 * - public int getHarvestLevel()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_EnumToolMaterial_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumToolMaterial_JavaName(void)
{
    return "net.minecraft.src.EnumToolMaterial";
}

const char *CloneMCJ_EnumToolMaterial_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_EnumToolMaterial_JavaSourceHash32(void)
{
    return 0xA6EB2CF3UL;
}
