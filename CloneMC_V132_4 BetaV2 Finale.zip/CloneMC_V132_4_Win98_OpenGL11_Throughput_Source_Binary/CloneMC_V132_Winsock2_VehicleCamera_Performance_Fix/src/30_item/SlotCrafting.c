/*
 * CloneMC Java port scaffold: SlotCrafting
 *
 * Java source: SlotCrafting.java
 * Java type: class SlotCrafting
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Slot
 * Implements: (none declared)
 * Source SHA-256: 7051b61610869e7cb18b39cae141e9e83843f9a5f25da2a8ef3a134cc4c954c2
 * Java lines: 81
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Slot, EntityPlayer, ItemStack, Block, AchievementList, Item, IInventory, i, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final IInventory craftMatrix
 * - private EntityPlayer thePlayer
 *
 * Java method/constructor inventory:
 * - public SlotCrafting(EntityPlayer entityplayer, IInventory iinventory, IInventory iinventory1, int i, int j, int k)
 * - public boolean isItemValid(ItemStack itemstack)
 * - public void onPickupFromSlot(ItemStack itemstack)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_SlotCrafting_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_SlotCrafting_JavaName(void)
{
    return "net.minecraft.src.SlotCrafting";
}

const char *CloneMCJ_SlotCrafting_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_SlotCrafting_JavaSourceHash32(void)
{
    return 0x7051B616UL;
}
