/*
 * Direct C89 recipe registrations ported from RecipesCrafting.java.
 */
#include "clonemc_java_port_30_item.h"

static const short g_cloneMCRecipesCraftingRecipeData[][25] = {
    {1, 54, 0, 1, 3, 3, 9, 5, -1, 5, -1, 5, -1, 5, -1, 0, 0, 5, -1, 5, -1, 5, -1, 5, -1},
    {1, 61, 0, 1, 3, 3, 9, 4, -1, 4, -1, 4, -1, 4, -1, 0, 0, 4, -1, 4, -1, 4, -1, 4, -1},
    {1, 58, 0, 1, 2, 2, 4, 5, -1, 5, -1, 5, -1, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 24, 0, 1, 2, 2, 4, 12, -1, 12, -1, 12, -1, 12, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void CloneMCJ_RecipesCrafting_AddNative(void)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int recipeIndex;
    int ingredientIndex;
    const short *data;
    for (recipeIndex = 0; recipeIndex < (int)(sizeof(g_cloneMCRecipesCraftingRecipeData) /
        sizeof(g_cloneMCRecipesCraftingRecipeData[0])); ++recipeIndex) {
        data = g_cloneMCRecipesCraftingRecipeData[recipeIndex];
        CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
        for (ingredientIndex = 0;
             ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
             ++ingredientIndex) {
            ingredients[ingredientIndex].itemID =
                data[7 + ingredientIndex * 2];
            ingredients[ingredientIndex].itemDamage =
                data[8 + ingredientIndex * 2];
        }
        if (data[0])
            CloneMCJ_CraftingManager_AddShapedNative(&output,
                data[4], data[5], ingredients);
        else
            CloneMCJ_CraftingManager_AddShapelessNative(&output,
                data[6], ingredients);
    }
}

void CloneMCJ_RecipesCrafting_Register(void) { }
const char *CloneMCJ_RecipesCrafting_JavaName(void)
{ return "net.minecraft.src.RecipesCrafting"; }
const char *CloneMCJ_RecipesCrafting_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipesCrafting_JavaSourceHash32(void)
{ return 0x6BD1BC06UL; }
