/*
 * CloneMC Java port scaffold: IInvBasic
 *
 * Java source: IInvBasic.java
 * Java type: interface IInvBasic
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: a6dcff943c5a45077be4b51f7e92109237fb86da0d3f0d7fdb9fed6e162fcda2
 * Java lines: 16
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: InventoryBasic
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract void func_20134_a(InventoryBasic inventorybasic)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_IInvBasic_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_IInvBasic_JavaName(void)
{
    return "net.minecraft.src.IInvBasic";
}

const char *CloneMCJ_IInvBasic_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_IInvBasic_JavaSourceHash32(void)
{
    return 0xA6DCFF94UL;
}
