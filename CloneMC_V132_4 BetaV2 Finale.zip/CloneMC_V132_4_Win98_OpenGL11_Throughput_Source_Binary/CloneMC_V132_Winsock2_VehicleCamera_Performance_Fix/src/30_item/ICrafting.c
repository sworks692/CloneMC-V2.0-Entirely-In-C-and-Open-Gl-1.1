/*
 * CloneMC Java port scaffold: ICrafting
 *
 * Java source: ICrafting.java
 * Java type: interface ICrafting
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: d0aca86722897110cfcdae064d68f6b97bce02f3ca9f5e2b925194933e45383f
 * Java lines: 18
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Container, ItemStack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract void func_20159_a(Container container, int i, ItemStack itemstack)
 * - public abstract void func_20158_a(Container container, int i, int j)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ICrafting_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ICrafting_JavaName(void)
{
    return "net.minecraft.src.ICrafting";
}

const char *CloneMCJ_ICrafting_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ICrafting_JavaSourceHash32(void)
{
    return 0xD0ACA867UL;
}
