/* Direct C89 runtime for Beta BlockPistonMoving.java. */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

void CloneMCJ_BlockPistonMoving_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(36);
    if(!block)return;
    block->solid=0;block->opaque=0;block->collidable=1;block->hasTileEntity=1;
    block->minX=0.0;block->minY=0.0;block->minZ=0.0;
    block->maxX=1.0;block->maxY=1.0;block->maxZ=1.0;
}
void CloneMCJ_BlockPistonMoving_Register(void){}
const char *CloneMCJ_BlockPistonMoving_JavaName(void){return "net.minecraft.src.BlockPistonMoving";}
const char *CloneMCJ_BlockPistonMoving_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockPistonMoving_JavaSourceHash32(void){return 0x25C5E942UL;}
