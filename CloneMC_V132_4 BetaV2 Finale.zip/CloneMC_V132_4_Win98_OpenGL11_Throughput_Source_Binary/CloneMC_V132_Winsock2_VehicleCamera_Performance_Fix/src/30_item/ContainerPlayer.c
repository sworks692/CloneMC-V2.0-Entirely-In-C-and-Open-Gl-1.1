/*
 * Direct C89 port of ContainerPlayer.java.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ContainerPlayer_InitializeNative(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_InventoryCrafting *matrix,
    CloneMCJ_InventoryCraftResult *result)
{
    int row;
    int column;
    int index;
    if (!container || !inventory || !matrix || !result) return;
    CloneMCJ_Container_Initialize(container);
    CloneMCJ_InventoryCrafting_Initialize(matrix, 2, 2);
    CloneMCJ_InventoryCraftResult_Initialize(result);
    container->type = CLONEMC_J_CONTAINER_PLAYER;
    container->playerInventory = inventory;
    container->craftMatrix = matrix;
    container->craftResult = result;
    container->resultSlot = CloneMCJ_Container_AddTypedSlot(container,
        &result->result, 64, CLONEMC_J_SLOT_CRAFT_RESULT, -1, -1, 144, 36);
    for (row = 0; row < 2; ++row)
        for (column = 0; column < 2; ++column) {
            index = column + row * 2;
            CloneMCJ_Container_AddTypedSlot(container,
                &matrix->stackList[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 88 + column * 18, 26 + row * 18);
        }
    for (row = 0; row < 4; ++row) {
        index = 3 - row;
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->armorInventory[index], 1, CLONEMC_J_SLOT_ARMOR,
            row, 36 + index, 8, 8 + row * 18);
    }
    container->playerSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 9; ++column) {
            index = column + (row + 1) * 9;
            CloneMCJ_Container_AddTypedSlot(container,
                &inventory->mainInventory[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 8 + column * 18, 84 + row * 18);
        }
    container->hotbarSlotStart = container->slotCount;
    for (column = 0; column < 9; ++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column], 64, CLONEMC_J_SLOT_NORMAL,
            -1, column, 8 + column * 18, 142);
    container->hotbarSlotEnd = container->slotCount - 1;
    container->playerSlotEnd = container->hotbarSlotEnd;
    CloneMCJ_Container_UpdateCraftResult(container);
}

void CloneMCJ_ContainerPlayer_Register(void) { }
const char *CloneMCJ_ContainerPlayer_JavaName(void)
{ return "net.minecraft.src.ContainerPlayer"; }
const char *CloneMCJ_ContainerPlayer_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_ContainerPlayer_JavaSourceHash32(void)
{ return 0x73014363UL; }
