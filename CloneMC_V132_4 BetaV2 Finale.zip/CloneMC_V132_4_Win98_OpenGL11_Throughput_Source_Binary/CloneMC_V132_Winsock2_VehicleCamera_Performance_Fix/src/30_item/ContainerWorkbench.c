/*
 * Direct C89 port of ContainerWorkbench.java.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ContainerWorkbench_InitializeNative(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_InventoryCrafting *matrix,
    CloneMCJ_InventoryCraftResult *result, int x, int y, int z)
{
    int row;
    int column;
    int index;
    if (!container || !inventory || !matrix || !result) return;
    CloneMCJ_Container_Initialize(container);
    CloneMCJ_InventoryCrafting_Initialize(matrix, 3, 3);
    CloneMCJ_InventoryCraftResult_Initialize(result);
    container->type = CLONEMC_J_CONTAINER_WORKBENCH;
    container->playerInventory = inventory;
    container->craftMatrix = matrix;
    container->craftResult = result;
    container->workbenchX = x;
    container->workbenchY = y;
    container->workbenchZ = z;
    container->resultSlot = CloneMCJ_Container_AddTypedSlot(container,
        &result->result, 64, CLONEMC_J_SLOT_CRAFT_RESULT, -1, -1, 124, 35);
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 3; ++column) {
            index = column + row * 3;
            CloneMCJ_Container_AddTypedSlot(container,
                &matrix->stackList[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 30 + column * 18, 17 + row * 18);
        }
    container->playerSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 9; ++column) {
            index = column + (row + 1) * 9;
            CloneMCJ_Container_AddTypedSlot(container,
                &inventory->mainInventory[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 8 + column * 18, 84 + row * 18);
        }
    container->hotbarSlotStart = container->slotCount;
    for (column = 0; column < 9; ++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column], 64, CLONEMC_J_SLOT_NORMAL,
            -1, column, 8 + column * 18, 142);
    container->hotbarSlotEnd = container->slotCount - 1;
    container->playerSlotEnd = container->hotbarSlotEnd;
    CloneMCJ_Container_UpdateCraftResult(container);
}

void CloneMCJ_ContainerWorkbench_Register(void) { }
const char *CloneMCJ_ContainerWorkbench_JavaName(void)
{ return "net.minecraft.src.ContainerWorkbench"; }
const char *CloneMCJ_ContainerWorkbench_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_ContainerWorkbench_JavaSourceHash32(void)
{ return 0x8C2EDA32UL; }
