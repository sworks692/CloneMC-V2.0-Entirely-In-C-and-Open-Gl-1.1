/*
 * CloneMC Java port scaffold: IRecipe
 *
 * Java source: IRecipe.java
 * Java type: interface IRecipe
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 594954ffbc7d474396a6cda0265c0ef735b8ff6e4e2c206e2ef6c9cb52f1daf4
 * Java lines: 22
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: InventoryCrafting, ItemStack
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract boolean matches(InventoryCrafting inventorycrafting)
 * - public abstract ItemStack getCraftingResult(InventoryCrafting inventorycrafting)
 * - public abstract int getRecipeSize()
 * - public abstract ItemStack getRecipeOutput()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_IRecipe_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_IRecipe_JavaName(void)
{
    return "net.minecraft.src.IRecipe";
}

const char *CloneMCJ_IRecipe_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_IRecipe_JavaSourceHash32(void)
{
    return 0x594954FFUL;
}
