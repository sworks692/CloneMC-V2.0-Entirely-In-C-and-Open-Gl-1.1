/*
 * Direct C89 implementation of ShapedRecipes.java matching.
 */
#include "clonemc_java_port_30_item.h"

static int CloneMCJ_ShapedRecipes_IngredientMatches(
    const CloneMCJ_RecipeIngredient *ingredient, const CloneMCJ_ItemStack *stack)
{
    if (!ingredient) return 0;
    if (ingredient->itemID == 0)
        return !stack || CloneMCJ_ItemStack_IsEmpty(stack);
    if (!stack || CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    if (stack->itemID != ingredient->itemID) return 0;
    return ingredient->itemDamage == CLONEMC_J_ITEM_DAMAGE_WILDCARD ||
        stack->itemDamage == ingredient->itemDamage;
}

static int CloneMCJ_ShapedRecipes_MatchesAt(const CloneMCJ_Recipe *recipe,
    const CloneMCJ_InventoryCrafting *inventory, int offsetX, int offsetY,
    int mirrored)
{
    int x;
    int y;
    int recipeX;
    int recipeY;
    int recipeIndex;
    int inventoryIndex;
    CloneMCJ_RecipeIngredient empty;
    const CloneMCJ_RecipeIngredient *ingredient;
    const CloneMCJ_ItemStack *stack;
    empty.itemID = 0;
    empty.itemDamage = 0;
    for (y = 0; y < inventory->height; ++y) {
        for (x = 0; x < inventory->width; ++x) {
            recipeX = x - offsetX;
            recipeY = y - offsetY;
            ingredient = &empty;
            if (recipeX >= 0 && recipeY >= 0 &&
                recipeX < recipe->width && recipeY < recipe->height) {
                if (mirrored) recipeX = recipe->width - recipeX - 1;
                recipeIndex = recipeX + recipeY * recipe->width;
                ingredient = &recipe->ingredients[recipeIndex];
            }
            inventoryIndex = x + y * inventory->width;
            stack = CloneMCJ_InventoryCrafting_GetSlotConst(inventory, inventoryIndex);
            if (!CloneMCJ_ShapedRecipes_IngredientMatches(ingredient, stack)) return 0;
        }
    }
    return 1;
}

int CloneMCJ_ShapedRecipes_MatchesNative(const CloneMCJ_Recipe *recipe,
    const CloneMCJ_InventoryCrafting *inventory)
{
    int x;
    int y;
    if (!recipe || !inventory || !recipe->shaped) return 0;
    if (recipe->width > inventory->width || recipe->height > inventory->height)
        return 0;
    for (y = 0; y <= inventory->height - recipe->height; ++y) {
        for (x = 0; x <= inventory->width - recipe->width; ++x) {
            if (CloneMCJ_ShapedRecipes_MatchesAt(recipe, inventory, x, y, 1))
                return 1;
            if (CloneMCJ_ShapedRecipes_MatchesAt(recipe, inventory, x, y, 0))
                return 1;
        }
    }
    return 0;
}

void CloneMCJ_ShapedRecipes_Register(void) { }
const char *CloneMCJ_ShapedRecipes_JavaName(void)
{ return "net.minecraft.src.ShapedRecipes"; }
const char *CloneMCJ_ShapedRecipes_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_ShapedRecipes_JavaSourceHash32(void)
{ return 0xCDDA171EUL; }
