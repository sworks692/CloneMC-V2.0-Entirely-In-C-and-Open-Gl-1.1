/*
 * CloneMC Java port scaffold: Block
 *
 * Java source: Block.java
 * Java type: class Block
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: ea85e84bc5537959cee1973b7a4e5392ddd375cdc9cb40ef770a08d2aca2f89d
 * Java lines: 875
 * Discovered declared fields: 130
 * Discovered declared methods/constructors: 73
 * Referenced Java classes: Material, IBlockAccess, AxisAlignedBB, EntityPlayer, World, ItemStack, EntityItem, Vec3D, MovingObjectPosition, StatList, StatCollector, StepSound, StepSoundStone, StepSoundSand, BlockStone, BlockGrass, BlockDirt, BlockSapling, BlockFlowing, BlockStationary, BlockSand, BlockGravel, BlockOre, BlockLog, BlockLeaves, BlockSponge, BlockGlass, BlockDispenser, BlockSandStone, BlockNote, BlockBed, BlockRail, BlockDetectorRail, BlockPistonBase, BlockWeb, BlockTallGrass, BlockDeadBush, BlockPistonExtension, BlockCloth, BlockPistonMoving, BlockFlower, BlockMushroom, BlockOreStorage, BlockStep, BlockTNT, BlockBookshelf, BlockObsidian, BlockTorch, BlockFire, BlockMobSpawner, BlockStairs, BlockChest, BlockRedstoneWire, BlockWorkbench, BlockCrops, BlockFarmland, BlockFurnace, BlockSign, TileEntitySign, BlockDoor, BlockLadder, BlockLever, BlockPressurePlate, EnumMobType, BlockRedstoneOre, BlockRedstoneTorch, BlockButton, BlockSnow, BlockIce, BlockSnowBlock, BlockCactus, BlockClay, BlockReed, BlockJukeBox, BlockFence, BlockPumpkin, BlockNetherrack, BlockSoulSand, BlockGlowStone, BlockPortal, BlockCake, BlockRedstoneRepeater, BlockLockedChest, BlockTrapDoor, Item, ItemCloth, ItemLog, ItemSlab, ItemSapling, ItemLeaves, ItemPiston, ItemBlock, Entity, EntityLiving
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static final StepSound soundPowderFootstep
 * - public static final StepSound soundWoodFootstep
 * - public static final StepSound soundGravelFootstep
 * - public static final StepSound soundGrassFootstep
 * - public static final StepSound soundStoneFootstep
 * - public static final StepSound soundMetalFootstep
 * - public static final StepSound soundGlassFootstep
 * - public static final StepSound soundClothFootstep
 * - public static final StepSound soundSandFootstep
 * - public static final Block blocksList[]
 * - public static final boolean tickOnLoad[] = new boolean[256]
 * - public static final boolean opaqueCubeLookup[] = new boolean[256]
 * - public static final boolean isBlockContainer[] = new boolean[256]
 * - public static final int lightOpacity[] = new int[256]
 * - public static final boolean canBlockGrass[]
 * - public static final int lightValue[] = new int[256]
 * - public static final boolean field_28032_t[] = new boolean[256]
 * - public static final Block stone
 * - public static final BlockGrass grass
 * - public static final Block dirt
 * - public static final Block cobblestone
 * - public static final Block planks
 * - public static final Block sapling
 * - public static final Block bedrock
 * - public static final Block waterMoving
 * - public static final Block waterStill
 * - public static final Block lavaMoving
 * - public static final Block lavaStill
 * - public static final Block sand
 * - public static final Block gravel
 * - public static final Block oreGold
 * - public static final Block oreIron
 * - public static final Block oreCoal
 * - public static final Block wood
 * - public static final BlockLeaves leaves
 * - public static final Block sponge
 * - public static final Block glass
 * - public static final Block oreLapis
 * - public static final Block blockLapis
 * - public static final Block dispenser
 * - public static final Block sandStone
 * - public static final Block musicBlock
 * - public static final Block blockBed
 * - public static final Block railPowered
 * - public static final Block railDetector
 * - public static final Block pistonStickyBase
 * - public static final Block web
 * - public static final BlockTallGrass tallGrass
 * - public static final BlockDeadBush deadBush
 * - public static final Block pistonBase
 * - public static final BlockPistonExtension pistonExtension
 * - public static final Block cloth
 * - public static final BlockPistonMoving pistonMoving
 * - public static final BlockFlower plantYellow
 * - public static final BlockFlower plantRed
 * - public static final BlockFlower mushroomBrown
 * - public static final BlockFlower mushroomRed
 * - public static final Block blockGold
 * - public static final Block blockSteel
 * - public static final Block stairDouble
 * - public static final Block stairSingle
 * - public static final Block brick
 * - public static final Block tnt
 * - public static final Block bookShelf
 * - public static final Block cobblestoneMossy
 * - public static final Block obsidian
 * - public static final Block torchWood
 * - public static final BlockFire fire
 * - public static final Block mobSpawner
 * - public static final Block stairCompactPlanks
 * - public static final Block chest
 * - public static final Block redstoneWire
 * - public static final Block oreDiamond
 * - public static final Block blockDiamond
 * - public static final Block workbench
 * - public static final Block crops
 * - public static final Block tilledField
 * - public static final Block stoneOvenIdle
 * - public static final Block stoneOvenActive
 * - public static final Block signPost
 * - public static final Block doorWood
 * - public static final Block ladder
 * - public static final Block rail
 * - public static final Block stairCompactCobblestone
 * - public static final Block signWall
 * - public static final Block lever
 * - public static final Block pressurePlateStone
 * - public static final Block doorSteel
 * - public static final Block pressurePlatePlanks
 * - public static final Block oreRedstone
 * - public static final Block oreRedstoneGlowing
 * - public static final Block torchRedstoneIdle
 * - public static final Block torchRedstoneActive
 * - public static final Block button
 * - public static final Block snow
 * - public static final Block ice
 * - public static final Block blockSnow
 * - public static final Block cactus
 * - public static final Block blockClay
 * - public static final Block reed
 * - public static final Block jukebox
 * - public static final Block fence
 * - public static final Block pumpkin
 * - public static final Block netherrack
 * - public static final Block slowSand
 * - public static final Block glowStone
 * - public static final BlockPortal portal
 * - public static final Block pumpkinLantern
 * - public static final Block cake
 * - public static final Block redstoneRepeaterIdle
 * - public static final Block redstoneRepeaterActive
 * - public static final Block lockedChest
 * - public static final Block trapdoor
 * - public int blockIndexInTexture
 * - public final int blockID
 * - protected float blockHardness
 * - protected float blockResistance
 * - protected boolean blockConstructorCalled
 * - protected boolean enableStats
 * - public double minX
 * - public double minY
 * - public double minZ
 * - public double maxX
 * - public double maxY
 * - public double maxZ
 * - public StepSound stepSound
 * - public float blockParticleGravity
 * - public final Material blockMaterial
 * - public float slipperiness
 * - private String blockName
 *
 * Java method/constructor inventory:
 * - protected Block(int i, Material material)
 * - protected Block disableNeighborNotifyOnMetadataChange()
 * - protected void initializeBlock()
 * - protected Block(int i, int j, Material material)
 * - protected Block setStepSound(StepSound stepsound)
 * - protected Block setLightOpacity(int i)
 * - protected Block setLightValue(float f)
 * - protected Block setResistance(float f)
 * - public boolean renderAsNormalBlock()
 * - public int getRenderType()
 * - protected Block setHardness(float f)
 * - protected Block setBlockUnbreakable()
 * - public float getHardness()
 * - protected Block setTickOnLoad(boolean flag)
 * - public void setBlockBounds(float f, float f1, float f2, float f3, float f4, float f5)
 * - public float getBlockBrightness(IBlockAccess iblockaccess, int i, int j, int k)
 * - public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public boolean getIsBlockSolid(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public int getBlockTextureFromSide(int i)
 * - public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k)
 * - public void getCollidingBoundingBoxes(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, ArrayList arraylist)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean canCollideCheck(int i, boolean flag)
 * - public boolean isCollidable()
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public void randomDisplayTick(World world, int i, int j, int k, Random random)
 * - public void onBlockDestroyedByPlayer(World world, int i, int j, int k, int l)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public int tickRate()
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onBlockRemoval(World world, int i, int j, int k)
 * - public int quantityDropped(Random random)
 * - public int idDropped(int i, Random random)
 * - public float blockStrength(EntityPlayer entityplayer)
 * - public final void dropBlockAsItem(World world, int i, int j, int k, int l)
 * - public void dropBlockAsItemWithChance(World world, int i, int j, int k, int l, float f)
 * - protected void dropBlockAsItem_do(World world, int i, int j, int k, ItemStack itemstack)
 * - protected int damageDropped(int i)
 * - public float getExplosionResistance(Entity entity)
 * - public MovingObjectPosition collisionRayTrace(World world, int i, int j, int k, Vec3D vec3d, Vec3D vec3d1)
 * - private boolean isVecInsideYZBounds(Vec3D vec3d)
 * - private boolean isVecInsideXZBounds(Vec3D vec3d)
 * - private boolean isVecInsideXYBounds(Vec3D vec3d)
 * - public void onBlockDestroyedByExplosion(World world, int i, int j, int k)
 * - public int getRenderBlockPass()
 * - public boolean canPlaceBlockOnSide(World world, int i, int j, int k, int l)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - public void onEntityWalking(World world, int i, int j, int k, Entity entity)
 * - public void onBlockPlaced(World world, int i, int j, int k, int l)
 * - public void onBlockClicked(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - public void velocityToAddToEntity(World world, int i, int j, int k, Entity entity, Vec3D vec3d)
 * - public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int i, int j, int k)
 * - public int getRenderColor(int i)
 * - public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
 * - public boolean isPoweringTo(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public boolean canProvidePower()
 * - public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
 * - public boolean isIndirectlyPoweringTo(World world, int i, int j, int k, int l)
 * - public void setBlockBoundsForItemRender()
 * - public void harvestBlock(World world, EntityPlayer entityplayer, int i, int j, int k, int l)
 * - public boolean canBlockStay(World world, int i, int j, int k)
 * - public void onBlockPlacedBy(World world, int i, int j, int k, EntityLiving entityliving)
 * - public Block setBlockName(String s)
 * - public String translateBlockName()
 * - public String getBlockName()
 * - public void playBlock(World world, int i, int j, int k, int l, int i1)
 * - public boolean getEnableStats()
 * - protected Block disableStats()
 * - public int getMobilityFlag()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <string.h>

void CloneMCJ_Block_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Block_JavaName(void)
{
    return "net.minecraft.src.Block";
}

const char *CloneMCJ_Block_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_Block_JavaSourceHash32(void)
{
    return 0xEA85E84BUL;
}

static CloneMCJ_BlockDefinition g_cloneMCBlockRegistry[CLONEMC_J_BLOCK_REGISTRY_SIZE];
static int g_cloneMCBlockRegistryInitialized = 0;

static void CloneMCJ_Block_Set(int id, const char *name, CloneMCJ_MaterialKind material,
    float hardness, int solid, int opaque, int collidable)
{
    CloneMCJ_BlockDefinition *block;
    int opacity;
    if (id < 0 || id >= CLONEMC_J_BLOCK_REGISTRY_SIZE) { return; }
    block = &g_cloneMCBlockRegistry[id];
    block->blockID = id; block->name = name; block->material = material;
    block->hardness = hardness; block->resistance = hardness < 0.0F ? 6000000.0F : hardness * 5.0F;
    block->slipperiness = 0.6F;
    opacity = CloneMCJ_World_GetBlockLightOpacity(id);
    block->lightOpacity = (unsigned char)(opacity > 15 ? 15 : opacity);
    block->lightEmission = (unsigned char)CloneMCJ_World_GetBlockLightEmission(id);
    block->solid = (unsigned char)(solid ? 1 : 0); block->opaque = (unsigned char)(opaque ? 1 : 0);
    block->collidable = (unsigned char)(collidable ? 1 : 0); block->replaceable = (unsigned char)(id == 0);
    block->droppedItemID = id; block->droppedCount = id == 0 ? 0 : 1;
    block->minX = 0.0; block->minY = 0.0; block->minZ = 0.0;
    block->maxX = 1.0; block->maxY = 1.0; block->maxZ = 1.0;
}

void CloneMCJ_BlockRegistry_Initialize(void)
{
    int id;
    CloneMCJ_BlockDefinition *block;
    if (g_cloneMCBlockRegistryInitialized) { return; }
    memset(g_cloneMCBlockRegistry, 0, sizeof(g_cloneMCBlockRegistry));
    for (id = 0; id < CLONEMC_J_BLOCK_REGISTRY_SIZE; ++id) CloneMCJ_Block_Set(id, "tile.unknown", CLONEMC_J_MATERIAL_ROCK, 1.5F, id != 0, id != 0, id != 0);
    CloneMCJ_Block_Set(0,"tile.air",CLONEMC_J_MATERIAL_AIR,0.0F,0,0,0);
    CloneMCJ_Block_Set(1,"tile.stone",CLONEMC_J_MATERIAL_ROCK,1.5F,1,1,1);g_cloneMCBlockRegistry[1].droppedItemID=4;
    CloneMCJ_Block_Set(2,"tile.grass",CLONEMC_J_MATERIAL_EARTH,0.6F,1,1,1); g_cloneMCBlockRegistry[2].droppedItemID=3;
    CloneMCJ_Block_Set(3,"tile.dirt",CLONEMC_J_MATERIAL_EARTH,0.5F,1,1,1);
    CloneMCJ_Block_Set(4,"tile.stonebrick",CLONEMC_J_MATERIAL_ROCK,2.0F,1,1,1);
    CloneMCJ_Block_Set(5,"tile.wood",CLONEMC_J_MATERIAL_WOOD,2.0F,1,1,1);
    CloneMCJ_Block_Set(6,"tile.sapling",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0); g_cloneMCBlockRegistry[6].replaceable=1;
    CloneMCJ_Block_Set(7,"tile.bedrock",CLONEMC_J_MATERIAL_ROCK,-1.0F,1,1,1); g_cloneMCBlockRegistry[7].droppedCount=0;
    CloneMCJ_Block_Set(8,"tile.water",CLONEMC_J_MATERIAL_WATER,100.0F,0,0,0); g_cloneMCBlockRegistry[8].replaceable=1;
    CloneMCJ_Block_Set(9,"tile.water",CLONEMC_J_MATERIAL_WATER,100.0F,0,0,0); g_cloneMCBlockRegistry[9].replaceable=1;
    CloneMCJ_Block_Set(10,"tile.lava",CLONEMC_J_MATERIAL_LAVA,0.0F,0,0,0); g_cloneMCBlockRegistry[10].replaceable=1;
    CloneMCJ_Block_Set(11,"tile.lava",CLONEMC_J_MATERIAL_LAVA,100.0F,0,0,0); g_cloneMCBlockRegistry[11].replaceable=1;
    CloneMCJ_Block_Set(12,"tile.sand",CLONEMC_J_MATERIAL_SAND,0.5F,1,1,1);
    CloneMCJ_Block_Set(13,"tile.gravel",CLONEMC_J_MATERIAL_SAND,0.6F,1,1,1);
    CloneMCJ_Block_Set(17,"tile.log",CLONEMC_J_MATERIAL_WOOD,2.0F,1,1,1);
    CloneMCJ_Block_Set(18,"tile.leaves",CLONEMC_J_MATERIAL_PLANT,0.2F,1,0,1);
    CloneMCJ_Block_Set(20,"tile.glass",CLONEMC_J_MATERIAL_GLASS,0.3F,1,0,1); g_cloneMCBlockRegistry[20].droppedCount=0;
    CloneMCJ_Block_Set(23,"tile.dispenser",CLONEMC_J_MATERIAL_ROCK,3.5F,1,1,1);g_cloneMCBlockRegistry[23].hasTileEntity=1;
    /* BlockBed and all rail variants are non-normal shapes.  Leaving these IDs
     * on the registry's generic full-cube defaults made beds occlude a complete
     * block and made rails physically one block tall even when their mesh was
     * drawn close to the floor. */
    CloneMCJ_Block_Set(26,"tile.bed",CLONEMC_J_MATERIAL_CLOTH,0.2F,1,0,1);
    g_cloneMCBlockRegistry[26].minY=0.0;g_cloneMCBlockRegistry[26].maxY=0.5625;
    g_cloneMCBlockRegistry[26].droppedItemID=355;
    CloneMCJ_Block_Set(27,"tile.goldenRail",CLONEMC_J_MATERIAL_CIRCUITS,0.7F,0,0,0);
    CloneMCJ_Block_Set(28,"tile.detectorRail",CLONEMC_J_MATERIAL_CIRCUITS,0.7F,0,0,0);
    CloneMCJ_Block_Set(29,"tile.pistonStickyBase",CLONEMC_J_MATERIAL_ROCK,0.5F,1,1,1);
    CloneMCJ_Block_Set(30,"tile.web",CLONEMC_J_MATERIAL_PLANT,4.0F,0,0,0);
    /* Beta does not use one contiguous 31..40 plant family.  ID 35 is
     * BlockCloth: a solid, opaque, collidable full cube.  Treating it as a
     * crossed plant made wool disappear, accept clicks through it, and poison
     * culling/lighting around neighboring blocks. */
    CloneMCJ_Block_Set(31,"tile.plant",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[31].replaceable=1;
    CloneMCJ_Block_Set(32,"tile.plant",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[32].replaceable=1;
    CloneMCJ_Block_Set(35,"tile.cloth",CLONEMC_J_MATERIAL_CLOTH,0.8F,1,1,1);
    CloneMCJ_Block_Set(37,"tile.flower",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[37].replaceable=1;
    CloneMCJ_Block_Set(38,"tile.rose",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[38].replaceable=1;
    CloneMCJ_Block_Set(39,"tile.mushroom",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[39].replaceable=1;
    CloneMCJ_Block_Set(40,"tile.mushroom",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[40].replaceable=1;
    g_cloneMCBlockRegistry[31].droppedCount=0; /* 1/8 seed handled below */
    g_cloneMCBlockRegistry[32].droppedCount=0; /* dead shrub */
    CloneMCJ_Block_Set(33,"tile.pistonBase",CLONEMC_J_MATERIAL_ROCK,0.5F,1,1,1);
    CloneMCJ_Block_Set(34,"tile.pistonExtension",CLONEMC_J_MATERIAL_ROCK,-1.0F,0,0,1);g_cloneMCBlockRegistry[34].droppedCount=0;
    CloneMCJ_Block_Set(36,"tile.pistonMoving",CLONEMC_J_MATERIAL_ROCK,-1.0F,0,0,1);g_cloneMCBlockRegistry[36].droppedCount=0;
    CloneMCJ_Block_Set(43,"tile.stoneSlab",CLONEMC_J_MATERIAL_ROCK,2.0F,1,1,1);
    CloneMCJ_Block_Set(44,"tile.stoneSlab",CLONEMC_J_MATERIAL_ROCK,2.0F,1,0,1);
    CloneMCJ_Block_Set(50,"tile.torch",CLONEMC_J_MATERIAL_CIRCUITS,0.0F,0,0,0);
    CloneMCJ_Block_Set(51,"tile.fire",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[51].replaceable=1;g_cloneMCBlockRegistry[51].droppedCount=0;
    CloneMCJ_Block_Set(52,"tile.mobSpawner",CLONEMC_J_MATERIAL_ROCK,5.0F,1,0,1);g_cloneMCBlockRegistry[52].hasTileEntity=1;g_cloneMCBlockRegistry[52].droppedCount=0;
    CloneMCJ_Block_Set(53,"tile.stairsWood",CLONEMC_J_MATERIAL_WOOD,2.0F,1,0,1);
    CloneMCJ_Block_Set(54,"tile.chest",CLONEMC_J_MATERIAL_WOOD,2.5F,1,0,1);g_cloneMCBlockRegistry[54].hasTileEntity=1;
    CloneMCJ_Block_Set(55,"tile.redstoneDust",CLONEMC_J_MATERIAL_CIRCUITS,0.0F,0,0,0);g_cloneMCBlockRegistry[55].droppedItemID=331;
    CloneMCJ_Block_Set(58,"tile.workbench",CLONEMC_J_MATERIAL_WOOD,2.5F,1,1,1);
    CloneMCJ_Block_Set(59,"tile.crops",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[59].replaceable=1;g_cloneMCBlockRegistry[59].droppedItemID=295;
    CloneMCJ_Block_Set(60,"tile.farmland",CLONEMC_J_MATERIAL_EARTH,0.6F,1,0,1);
    CloneMCJ_Block_Set(61,"tile.furnace",CLONEMC_J_MATERIAL_ROCK,3.5F,1,1,1);g_cloneMCBlockRegistry[61].hasTileEntity=1;
    CloneMCJ_Block_Set(62,"tile.furnace",CLONEMC_J_MATERIAL_ROCK,3.5F,1,1,1);g_cloneMCBlockRegistry[62].hasTileEntity=1;g_cloneMCBlockRegistry[62].droppedItemID=61;
    CloneMCJ_Block_Set(63,"tile.sign",CLONEMC_J_MATERIAL_WOOD,1.0F,0,0,0);
    g_cloneMCBlockRegistry[63].hasTileEntity=1;
    g_cloneMCBlockRegistry[63].droppedItemID=323;
    CloneMCJ_Block_Set(64,"tile.doorWood",CLONEMC_J_MATERIAL_WOOD,3.0F,1,0,1);g_cloneMCBlockRegistry[64].droppedItemID=324;
    CloneMCJ_Block_Set(65,"tile.ladder",CLONEMC_J_MATERIAL_WOOD,0.4F,0,0,1);
    CloneMCJ_Block_Set(66,"tile.rail",CLONEMC_J_MATERIAL_CIRCUITS,0.7F,0,0,0);
    CloneMCJ_Block_Set(67,"tile.stairsStone",CLONEMC_J_MATERIAL_ROCK,2.0F,1,0,1);
    CloneMCJ_Block_Set(68,"tile.sign",CLONEMC_J_MATERIAL_WOOD,1.0F,0,0,0);
    g_cloneMCBlockRegistry[68].hasTileEntity=1;
    g_cloneMCBlockRegistry[68].droppedItemID=323;
    CloneMCJ_Block_Set(69,"tile.lever",CLONEMC_J_MATERIAL_CIRCUITS,0.5F,0,0,0);
    CloneMCJ_Block_Set(70,"tile.pressurePlate",CLONEMC_J_MATERIAL_ROCK,0.5F,0,0,0);
    CloneMCJ_Block_Set(71,"tile.doorIron",CLONEMC_J_MATERIAL_METAL,5.0F,1,0,1);g_cloneMCBlockRegistry[71].droppedItemID=330;
    CloneMCJ_Block_Set(72,"tile.pressurePlate",CLONEMC_J_MATERIAL_WOOD,0.5F,0,0,0);
    CloneMCJ_Block_Set(75,"tile.notGate",CLONEMC_J_MATERIAL_CIRCUITS,0.0F,0,0,0);
    CloneMCJ_Block_Set(76,"tile.notGate",CLONEMC_J_MATERIAL_CIRCUITS,0.0F,0,0,0);
    CloneMCJ_Block_Set(77,"tile.button",CLONEMC_J_MATERIAL_CIRCUITS,0.5F,0,0,0);
    CloneMCJ_Block_Set(78,"tile.snow",CLONEMC_J_MATERIAL_PLANT,0.1F,0,0,1);g_cloneMCBlockRegistry[78].replaceable=1;
    CloneMCJ_Block_Set(79,"tile.ice",CLONEMC_J_MATERIAL_ICE,0.5F,1,0,1);g_cloneMCBlockRegistry[79].slipperiness=0.98F;
    CloneMCJ_Block_Set(81,"tile.cactus",CLONEMC_J_MATERIAL_PLANT,0.4F,1,0,1);
    CloneMCJ_Block_Set(83,"tile.reeds",CLONEMC_J_MATERIAL_PLANT,0.0F,0,0,0);g_cloneMCBlockRegistry[83].replaceable=1;
    CloneMCJ_Block_Set(85,"tile.fence",CLONEMC_J_MATERIAL_WOOD,2.0F,1,0,1);
    CloneMCJ_Block_Set(87,"tile.hellrock",CLONEMC_J_MATERIAL_ROCK,0.4F,1,1,1);
    CloneMCJ_Block_Set(88,"tile.hellsand",CLONEMC_J_MATERIAL_SAND,0.5F,1,1,1);
    CloneMCJ_Block_Set(89,"tile.lightgem",CLONEMC_J_MATERIAL_GLASS,0.3F,1,1,1);
    CloneMCJ_Block_Set(90,"tile.portal",CLONEMC_J_MATERIAL_CIRCUITS,-1.0F,0,0,0);g_cloneMCBlockRegistry[90].droppedCount=0;
    CloneMCJ_Block_Set(92,"tile.cake",CLONEMC_J_MATERIAL_CLOTH,0.5F,1,0,1);
    g_cloneMCBlockRegistry[92].droppedCount=0;
    CloneMCJ_Block_Set(93,"tile.diode",CLONEMC_J_MATERIAL_CIRCUITS,0.0F,0,0,0);g_cloneMCBlockRegistry[93].droppedItemID=356;
    CloneMCJ_Block_Set(94,"tile.diode",CLONEMC_J_MATERIAL_CIRCUITS,0.0F,0,0,0);g_cloneMCBlockRegistry[94].droppedItemID=356;
    CloneMCJ_Block_Set(96,"tile.trapdoor",CLONEMC_J_MATERIAL_WOOD,3.0F,1,0,1);
    g_cloneMCBlockRegistry[60].lightOpacity=255;
    g_cloneMCBlockRegistry[79].lightOpacity=3;
    block=&g_cloneMCBlockRegistry[1];block->requiredTool=CLONEMC_J_TOOL_PICKAXE;
    block=&g_cloneMCBlockRegistry[4];block->requiredTool=CLONEMC_J_TOOL_PICKAXE;
    for(id=14;id<=16;++id)g_cloneMCBlockRegistry[id].requiredTool=CLONEMC_J_TOOL_PICKAXE;
    g_cloneMCBlockRegistry[14].requiredHarvestLevel=2;g_cloneMCBlockRegistry[15].requiredHarvestLevel=1;
    g_cloneMCBlockRegistry[21].requiredTool=CLONEMC_J_TOOL_PICKAXE;g_cloneMCBlockRegistry[21].requiredHarvestLevel=1;
    g_cloneMCBlockRegistry[56].requiredTool=CLONEMC_J_TOOL_PICKAXE;g_cloneMCBlockRegistry[56].requiredHarvestLevel=2;g_cloneMCBlockRegistry[56].droppedItemID=264;
    g_cloneMCBlockRegistry[73].requiredTool=CLONEMC_J_TOOL_PICKAXE;g_cloneMCBlockRegistry[73].requiredHarvestLevel=2;g_cloneMCBlockRegistry[73].droppedItemID=331;g_cloneMCBlockRegistry[73].droppedCount=4;
    g_cloneMCBlockRegistry[49].requiredTool=CLONEMC_J_TOOL_PICKAXE;g_cloneMCBlockRegistry[49].requiredHarvestLevel=3;
    /* Complete Beta block localization keys.  Several simulation entries are
     * intentionally generic, but inventory labels must never expose
     * tile.unknown for a valid block ID. */
    g_cloneMCBlockRegistry[0].name="tile.air";
    g_cloneMCBlockRegistry[1].name="tile.stone";
    g_cloneMCBlockRegistry[2].name="tile.grass";
    g_cloneMCBlockRegistry[3].name="tile.dirt";
    g_cloneMCBlockRegistry[4].name="tile.stonebrick";
    g_cloneMCBlockRegistry[5].name="tile.wood";
    g_cloneMCBlockRegistry[6].name="tile.sapling";
    g_cloneMCBlockRegistry[7].name="tile.bedrock";
    g_cloneMCBlockRegistry[8].name="tile.water";
    g_cloneMCBlockRegistry[9].name="tile.water";
    g_cloneMCBlockRegistry[10].name="tile.lava";
    g_cloneMCBlockRegistry[11].name="tile.lava";
    g_cloneMCBlockRegistry[12].name="tile.sand";
    g_cloneMCBlockRegistry[13].name="tile.gravel";
    g_cloneMCBlockRegistry[14].name="tile.oreGold";
    g_cloneMCBlockRegistry[15].name="tile.oreIron";
    g_cloneMCBlockRegistry[16].name="tile.oreCoal";
    g_cloneMCBlockRegistry[17].name="tile.log";
    g_cloneMCBlockRegistry[18].name="tile.leaves";
    g_cloneMCBlockRegistry[19].name="tile.sponge";
    g_cloneMCBlockRegistry[20].name="tile.glass";
    g_cloneMCBlockRegistry[21].name="tile.oreLapis";
    g_cloneMCBlockRegistry[22].name="tile.blockLapis";
    g_cloneMCBlockRegistry[23].name="tile.dispenser";
    g_cloneMCBlockRegistry[24].name="tile.sandStone";
    g_cloneMCBlockRegistry[25].name="tile.musicBlock";
    g_cloneMCBlockRegistry[26].name="tile.bed";
    g_cloneMCBlockRegistry[27].name="tile.goldenRail";
    g_cloneMCBlockRegistry[28].name="tile.detectorRail";
    g_cloneMCBlockRegistry[29].name="tile.pistonStickyBase";
    g_cloneMCBlockRegistry[30].name="tile.web";
    g_cloneMCBlockRegistry[31].name="tile.plant";
    g_cloneMCBlockRegistry[32].name="tile.plant";
    g_cloneMCBlockRegistry[33].name="tile.pistonBase";
    g_cloneMCBlockRegistry[34].name="tile.pistonExtension";
    g_cloneMCBlockRegistry[35].name="tile.cloth";
    g_cloneMCBlockRegistry[36].name="tile.pistonMoving";
    g_cloneMCBlockRegistry[37].name="tile.flower";
    g_cloneMCBlockRegistry[38].name="tile.rose";
    g_cloneMCBlockRegistry[39].name="tile.mushroom";
    g_cloneMCBlockRegistry[40].name="tile.mushroom";
    g_cloneMCBlockRegistry[41].name="tile.blockGold";
    g_cloneMCBlockRegistry[42].name="tile.blockIron";
    g_cloneMCBlockRegistry[43].name="tile.stoneSlab";
    g_cloneMCBlockRegistry[44].name="tile.stoneSlab";
    g_cloneMCBlockRegistry[45].name="tile.brick";
    g_cloneMCBlockRegistry[46].name="tile.tnt";
    g_cloneMCBlockRegistry[47].name="tile.bookshelf";
    g_cloneMCBlockRegistry[48].name="tile.stoneMoss";
    g_cloneMCBlockRegistry[49].name="tile.obsidian";
    g_cloneMCBlockRegistry[50].name="tile.torch";
    g_cloneMCBlockRegistry[51].name="tile.fire";
    g_cloneMCBlockRegistry[52].name="tile.mobSpawner";
    g_cloneMCBlockRegistry[53].name="tile.stairsWood";
    g_cloneMCBlockRegistry[54].name="tile.chest";
    g_cloneMCBlockRegistry[55].name="tile.redstoneDust";
    g_cloneMCBlockRegistry[56].name="tile.oreDiamond";
    g_cloneMCBlockRegistry[57].name="tile.blockDiamond";
    g_cloneMCBlockRegistry[58].name="tile.workbench";
    g_cloneMCBlockRegistry[59].name="tile.crops";
    g_cloneMCBlockRegistry[60].name="tile.farmland";
    g_cloneMCBlockRegistry[61].name="tile.furnace";
    g_cloneMCBlockRegistry[62].name="tile.furnace";
    g_cloneMCBlockRegistry[63].name="tile.sign";
    g_cloneMCBlockRegistry[64].name="tile.doorWood";
    g_cloneMCBlockRegistry[65].name="tile.ladder";
    g_cloneMCBlockRegistry[66].name="tile.rail";
    g_cloneMCBlockRegistry[67].name="tile.stairsStone";
    g_cloneMCBlockRegistry[68].name="tile.sign";
    g_cloneMCBlockRegistry[69].name="tile.lever";
    g_cloneMCBlockRegistry[70].name="tile.pressurePlate";
    g_cloneMCBlockRegistry[71].name="tile.doorIron";
    g_cloneMCBlockRegistry[72].name="tile.pressurePlate";
    g_cloneMCBlockRegistry[73].name="tile.oreRedstone";
    g_cloneMCBlockRegistry[74].name="tile.oreRedstone";
    g_cloneMCBlockRegistry[75].name="tile.notGate";
    g_cloneMCBlockRegistry[76].name="tile.notGate";
    g_cloneMCBlockRegistry[77].name="tile.button";
    g_cloneMCBlockRegistry[78].name="tile.snow";
    g_cloneMCBlockRegistry[79].name="tile.ice";
    g_cloneMCBlockRegistry[80].name="tile.snow";
    g_cloneMCBlockRegistry[81].name="tile.cactus";
    g_cloneMCBlockRegistry[82].name="tile.clay";
    g_cloneMCBlockRegistry[83].name="tile.reeds";
    g_cloneMCBlockRegistry[84].name="tile.jukebox";
    g_cloneMCBlockRegistry[85].name="tile.fence";
    g_cloneMCBlockRegistry[86].name="tile.pumpkin";
    g_cloneMCBlockRegistry[87].name="tile.hellrock";
    g_cloneMCBlockRegistry[88].name="tile.hellsand";
    g_cloneMCBlockRegistry[89].name="tile.lightgem";
    g_cloneMCBlockRegistry[90].name="tile.portal";
    g_cloneMCBlockRegistry[91].name="tile.litpumpkin";
    g_cloneMCBlockRegistry[92].name="tile.cake";
    g_cloneMCBlockRegistry[93].name="tile.diode";
    g_cloneMCBlockRegistry[94].name="tile.diode";
    g_cloneMCBlockRegistry[95].name="tile.lockedchest";
    g_cloneMCBlockRegistry[96].name="tile.trapdoor";
    g_cloneMCBlockRegistryInitialized=1;
}

const CloneMCJ_BlockDefinition *CloneMCJ_BlockRegistry_Get(int id){CloneMCJ_BlockRegistry_Initialize();if(id<0||id>=256)id=0;return &g_cloneMCBlockRegistry[id];}
CloneMCJ_BlockDefinition *CloneMCJ_BlockRegistry_GetMutable(int id){CloneMCJ_BlockRegistry_Initialize();if(id<0||id>=256)return 0;return &g_cloneMCBlockRegistry[id];}

void CloneMCJ_BlockSimulation_RegisterWorld(CloneMCJ_World *world)
{
    CloneMCJ_BlockRegistry_Initialize();
    if (!world) return;
    CloneMCJ_BlockFluid_RegisterRuntime(world);
    CloneMCJ_BlockSponge_RegisterRuntime(world);
    CloneMCJ_BlockFire_RegisterRuntime(world);
    CloneMCJ_BlockCrops_RegisterRuntime(world);
    CloneMCJ_BlockSapling_RegisterRuntime(world);
    CloneMCJ_BlockLeaves_RegisterRuntime(world);
    CloneMCJ_BlockRedstoneWire_RegisterRuntime(world);
    CloneMCJ_BlockRedstoneTorch_RegisterRuntime(world);
    CloneMCJ_BlockLever_RegisterRuntime(world);
    CloneMCJ_BlockButton_RegisterRuntime(world);
    CloneMCJ_BlockPressurePlate_RegisterRuntime(world);
    CloneMCJ_BlockRedstoneRepeater_RegisterRuntime(world);
    CloneMCJ_BlockRail_RegisterRuntime(world);
    CloneMCJ_BlockPistonBase_RegisterRuntime(world);
    CloneMCJ_BlockPistonMoving_RegisterRuntime(world);
    CloneMCJ_BlockDoor_RegisterRuntime(world);
    CloneMCJ_BlockTrapDoor_RegisterRuntime(world);
    CloneMCJ_BlockPortal_RegisterRuntime(world);
    CloneMCJ_BlockSign_RegisterRuntime(world);
    CloneMCJ_BlockCake_RegisterRuntime(world);
    CloneMCJ_BlockBed_RegisterRuntime(world);
    CloneMCJ_BlockFarmland_RegisterRuntime(world);
    CloneMCJ_BlockGrass_RegisterRuntime(world);
    CloneMCJ_BlockCactus_RegisterRuntime(world);
    CloneMCJ_BlockReed_RegisterRuntime(world);
    CloneMCJ_BlockIce_RegisterRuntime(world);
    CloneMCJ_BlockSnow_RegisterRuntime(world);
    CloneMCJ_BlockSand_RegisterRuntime(world);
}

int CloneMCJ_Block_GetCollisionBoxes(CloneMCJ_World *world,int x,int y,int z,CloneMCAxisAlignedBB *boxes,int capacity)
{
    const CloneMCJ_BlockDefinition *block;int id,meta;double h;
    if(!world||!boxes||capacity<=0)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    if(!block->collidable)return 0;
    meta=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(id==92){
        double eaten;
        eaten=(double)(1+(meta&7)*2)/16.0;
        boxes[0]=CloneMCAABB_Create(x+eaten,y,z+0.0625,
            x+0.9375,y+0.4375,z+0.9375);
        return 1;
    }
    if(id==44){boxes[0]=CloneMCAABB_Create(x,y+((meta&8)?0.5:0.0),z,x+1.0,y+((meta&8)?1.0:0.5),z+1.0);return 1;}
    if(id==53||id==67){boxes[0]=CloneMCAABB_Create(x,y,z,x+1.0,y+0.5,z+1.0);if(capacity<2)return 1;if((meta&3)==0)boxes[1]=CloneMCAABB_Create(x+0.5,y+0.5,z,x+1.0,y+1.0,z+1.0);else if((meta&3)==1)boxes[1]=CloneMCAABB_Create(x,y+0.5,z,x+0.5,y+1.0,z+1.0);else if((meta&3)==2)boxes[1]=CloneMCAABB_Create(x,y+0.5,z+0.5,x+1.0,y+1.0,z+1.0);else boxes[1]=CloneMCAABB_Create(x,y+0.5,z,x+1.0,y+1.0,z+0.5);return 2;}
    if((id==29||id==33)&&(meta&8)){
        int facing;facing=meta&7;
        if(facing==0)boxes[0]=CloneMCAABB_Create(x,y+0.25,z,x+1.0,y+1.0,z+1.0);
        else if(facing==1)boxes[0]=CloneMCAABB_Create(x,y,z,x+1.0,y+0.75,z+1.0);
        else if(facing==2)boxes[0]=CloneMCAABB_Create(x,y,z+0.25,x+1.0,y+1.0,z+1.0);
        else if(facing==3)boxes[0]=CloneMCAABB_Create(x,y,z,x+1.0,y+1.0,z+0.75);
        else if(facing==4)boxes[0]=CloneMCAABB_Create(x+0.25,y,z,x+1.0,y+1.0,z+1.0);
        else boxes[0]=CloneMCAABB_Create(x,y,z,x+0.75,y+1.0,z+1.0);
        return 1;
    }
    if(id==34){
        int facing;facing=meta&7;
        if(facing==0||facing==1){
            boxes[0]=CloneMCAABB_Create(x,y+(facing==0?0.0:0.75),z,x+1.0,y+(facing==0?0.25:1.0),z+1.0);
            if(capacity<2)return 1;
            boxes[1]=CloneMCAABB_Create(x+0.375,y+(facing==0?0.25:0.0),z+0.375,x+0.625,y+(facing==0?1.0:0.75),z+0.625);
        }else if(facing==2||facing==3){
            boxes[0]=CloneMCAABB_Create(x,y,z+(facing==2?0.0:0.75),x+1.0,y+1.0,z+(facing==2?0.25:1.0));
            if(capacity<2)return 1;
            boxes[1]=CloneMCAABB_Create(x+0.25,y+0.375,z+(facing==2?0.25:0.0),x+0.75,y+0.625,z+(facing==2?1.0:0.75));
        }else{
            boxes[0]=CloneMCAABB_Create(x+(facing==4?0.0:0.75),y,z,x+(facing==4?0.25:1.0),y+1.0,z+1.0);
            if(capacity<2)return 1;
            boxes[1]=CloneMCAABB_Create(x+(facing==4?0.375:0.0),y+0.25,z+0.25,x+(facing==4?0.625:0.75),y+0.75,z+1.0);
        }
        return 2;
    }
    if(id==96){
        double thickness;thickness=0.1875;
        if(meta&4){
            if((meta&3)==0)boxes[0]=CloneMCAABB_Create(x,y,z+1.0-thickness,x+1.0,y+1.0,z+1.0);
            else if((meta&3)==1)boxes[0]=CloneMCAABB_Create(x,y,z,x+1.0,y+1.0,z+thickness);
            else if((meta&3)==2)boxes[0]=CloneMCAABB_Create(x+1.0-thickness,y,z,x+1.0,y+1.0,z+1.0);
            else boxes[0]=CloneMCAABB_Create(x,y,z,x+thickness,y+1.0,z+1.0);
        }else boxes[0]=CloneMCAABB_Create(x,y,z,x+1.0,y+thickness,z+1.0);
        return 1;
    }
    if(id==60)h=0.9375;else if(id==78)h=(double)((meta&7)+1)/8.0;else if(id==85)h=1.5;else if(id==88)h=0.875;else h=block->maxY;
    boxes[0]=CloneMCAABB_Create(x+block->minX,y+block->minY,z+block->minZ,x+block->maxX,y+h,z+block->maxZ);
    if(id==81)boxes[0]=CloneMCAABB_Create(x+0.0625,y,z+0.0625,x+0.9375,y+1.0,z+0.9375);
    if(id==65){if(meta==2)boxes[0]=CloneMCAABB_Create(x,y,z+0.875,x+1.0,y+1.0,z+1.0);else if(meta==3)boxes[0]=CloneMCAABB_Create(x,y,z,x+1.0,y+1.0,z+0.125);else if(meta==4)boxes[0]=CloneMCAABB_Create(x+0.875,y,z,x+1.0,y+1.0,z+1.0);else boxes[0]=CloneMCAABB_Create(x,y,z,x+0.125,y+1.0,z+1.0);}
    if(id==64||id==71){
        int state,lowerMeta;
        lowerMeta=meta;
        if(meta&8){int belowID;belowID=CloneMCJ_World_GetBlockId(world,x,y-1,z);
            if(belowID==id)lowerMeta=CloneMCJ_World_GetBlockMetadata(world,x,y-1,z);}
        state=(lowerMeta&4)?(lowerMeta&3):((lowerMeta-1)&3);
        if(state==0)boxes[0]=CloneMCAABB_Create(x,y,z,x+1.0,y+1.0,z+0.1875);
        else if(state==1)boxes[0]=CloneMCAABB_Create(x+0.8125,y,z,x+1.0,y+1.0,z+1.0);
        else if(state==2)boxes[0]=CloneMCAABB_Create(x,y,z+0.8125,x+1.0,y+1.0,z+1.0);
        else boxes[0]=CloneMCAABB_Create(x,y,z,x+0.1875,y+1.0,z+1.0);
    }
    return 1;
}

int CloneMCJ_Block_GetSelectionBox(CloneMCJ_World *world,int x,int y,int z,
    CloneMCAxisAlignedBB *box)
{
    const CloneMCJ_BlockDefinition *block;
    int id,meta;
    double minX,minY,minZ,maxX,maxY,maxZ;
    if(!world||!box)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(id<=0)return 0;
    meta=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    minX=block->minX;minY=block->minY;minZ=block->minZ;
    maxX=block->maxX;maxY=block->maxY;maxZ=block->maxZ;
    if(id==68){
        minX=minY=minZ=0.0;maxX=maxY=maxZ=1.0;
        minY=0.28125;maxY=0.78125;
        if(meta==2)minZ=0.875;
        else if(meta==3)maxZ=0.125;
        else if(meta==4)minX=0.875;
        else if(meta==5)maxX=0.125;
    }else if(id==92){
        minX=(double)(1+(meta&7)*2)/16.0;
        minY=0.0;minZ=0.0625;
        maxX=0.9375;maxY=0.5;maxZ=0.9375;
    }else if(id==78){
        maxY=(double)((meta&7)+1)/8.0;
    }else if(id==60)maxY=0.9375;
    *box=CloneMCAABB_Create((double)x+minX,(double)y+minY,(double)z+minZ,
        (double)x+maxX,(double)y+maxY,(double)z+maxZ);
    return 1;
}

int CloneMCJ_Block_CanPlaceAt(CloneMCJ_World *world,int blockID,int x,int y,int z,const CloneMCAxisAlignedBB *avoid)
{
    int oldID,oldMeta,count,i;CloneMCAxisAlignedBB boxes[3];const CloneMCJ_BlockDefinition *old;
    if(!world||y<0||y>=128||blockID<=0||blockID>=256)return 0;
    oldID=CloneMCJ_World_GetBlockId(world,x,y,z);
    oldMeta=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    old=CloneMCJ_BlockRegistry_Get(oldID);
    if(oldID!=0&&!old->replaceable)return 0;
    if(!CloneMCJ_World_SetBlockWithMetadata(world,x,y,z,blockID,0))return 0;
    count=CloneMCJ_Block_GetCollisionBoxes(world,x,y,z,boxes,3);
    /* Placement validation must be side-effect free.  The temporary block is
       needed only so metadata-sensitive collision boxes can query the world. */
    CloneMCJ_World_SetBlockWithMetadata(world,x,y,z,oldID,oldMeta);
    for(i=0;avoid&&i<count;++i)if(CloneMCAABB_Intersects(&boxes[i],avoid))return 0;
    return 1;
}

int CloneMCJ_Block_GetDroppedStack(int blockID,int metadata,CloneMCJavaRandom *random,CloneMCJ_ItemStack *out)
{
    const CloneMCJ_BlockDefinition *block;int item,count;
    if(!out)return 0;
    block=CloneMCJ_BlockRegistry_Get(blockID);item=block->droppedItemID;count=block->droppedCount;
    /* Exact Beta idDropped/quantityDropped/damageDropped overrides.  Random
     * calls remain in the same order as the uploaded Java classes. */
    if(blockID==1){item=4;count=1;metadata=0;} /* stone -> cobblestone */
    else if(blockID==13){item=(random&&CloneMCJavaRandom_NextIntBound(random,10)==0)?318:13;count=1;metadata=0;}
    else if(blockID==16){item=263;count=1;metadata=0;} /* coal ore */
    else if(blockID==21){item=351;count=random?4+CloneMCJavaRandom_NextIntBound(random,5):4;metadata=4;}
    else if(blockID==56){item=264;count=1;metadata=0;}
    else if(blockID==73||blockID==74){item=331;count=random?4+CloneMCJavaRandom_NextIntBound(random,2):4;metadata=0;}
    else if(blockID==75||blockID==76){item=76;count=1;metadata=0;} /* both redstone torch states drop active torch */
    else if(blockID==18){if(!random||CloneMCJavaRandom_NextIntBound(random,20)!=0)count=0;else{item=6;count=1;metadata&=3;}}
    else if(blockID==31){if(!random||CloneMCJavaRandom_NextIntBound(random,8)!=0)count=0;else{item=295;count=1;metadata=0;}}
    else if(blockID==32)count=0;
    else if(blockID==35){item=35;count=1;metadata=CloneMCJ_BlockCloth_DamageDroppedNative(metadata);}
    else if((blockID>=8&&blockID<=11)||blockID==20||blockID==34||blockID==36||
            blockID==47||blockID==51||blockID==52||blockID==79||blockID==90||
            blockID==92)count=0;
    else if(blockID==26){item=355;count=(metadata&8)?0:1;metadata=0;}
    else if(blockID==30){item=287;count=1;metadata=0;}
    else if(blockID==43){item=44;count=2;}
    else if(blockID==44){item=44;count=1;}
    /* Later stair behavior: a stair returns the stair item itself.  The
     * uploaded Beta BlockStairs delegated to its model block (planks or
     * cobblestone), which is the older behavior the user asked to replace. */
    else if(blockID==53){item=53;count=1;metadata=0;}
    else if(blockID==59){item=296;count=metadata>=7?1:0;metadata=0;}
    else if(blockID==60){item=3;count=1;metadata=0;}
    else if(blockID==63||blockID==68){item=323;count=1;metadata=0;}
    else if((blockID==64||blockID==71)){item=blockID==64?324:330;count=(metadata&8)?0:1;metadata=0;}
    else if(blockID==67){item=67;count=1;metadata=0;}
    else if(blockID==78){item=332;count=0;metadata=0;} /* Java snow layer quantity is zero */
    else if(blockID==80){item=332;count=4;metadata=0;}
    else if(blockID==82){item=337;count=4;metadata=0;}
    else if(blockID==83){item=338;count=1;metadata=0;}
    else if(blockID==89){item=348;count=random?2+CloneMCJavaRandom_NextIntBound(random,3):2;metadata=0;}
    else if(blockID==93||blockID==94){item=356;count=1;metadata=0;}
    if(count<=0){CloneMCJ_ItemStack_Clear(out);return 0;}
    CloneMCJ_ItemStack_Initialize(out,item,count,metadata);return 1;
}

int CloneMCJ_Block_GetAdditionalDroppedStack(int blockID,int metadata,
    CloneMCJavaRandom *random,CloneMCJ_ItemStack *out)
{
    if(!out)return 0;
    CloneMCJ_ItemStack_Clear(out);
    /* The uploaded Beta BlockLeaves has only its independent 1-in-20 sapling
     * roll.  Later oak leaves add an independent 1-in-200 apple roll.  Beta
     * metadata 0 is oak; spruce (1) and birch (2) do not produce apples. */
    if(blockID!=18||(metadata&3)!=0||!random||
       CloneMCJavaRandom_NextIntBound(random,200)!=0)return 0;
    CloneMCJ_ItemStack_Initialize(out,260,1,0);
    return 1;
}

int CloneMCJ_Block_Activate(CloneMCJ_World *world,int x,int y,int z,
    struct CloneMCJ_EntityPlayerTag *player)
{
    int id;
    const CloneMCJ_BlockDefinition *block;
    if(!world)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    if(block&&block->activate)return block->activate(world,x,y,z,player);
    if(id==64)return CloneMCJ_BlockDoor_ActivateNative(world,x,y,z);
    if(id==71)return 1;
    if(id==96)return CloneMCJ_BlockTrapDoor_ActivateNative(world,x,y,z);
    if(id==69)return CloneMCJ_BlockLever_ActivateNative(world,x,y,z);
    if(id==77)return CloneMCJ_BlockButton_ActivateNative(world,x,y,z);
    if(id==93||id==94)return CloneMCJ_BlockRedstoneRepeater_ActivateNative(world,x,y,z);
    return 0;
}
