/*
 * Direct Open Watcom C89 port of FurnaceRecipes.java and furnace fuel rules.
 */
#include "clonemc_java_port_30_item.h"

typedef struct CloneMCJ_FurnaceRecipeNativeTag {
    short inputID;
    short outputID;
    short outputDamage;
} CloneMCJ_FurnaceRecipeNative;

static const CloneMCJ_FurnaceRecipeNative g_cloneMCFurnaceRecipes[] = {
    {15, 265, 0}, {14, 266, 0}, {56, 264, 0}, {12, 20, 0},
    {319, 320, 0}, {349, 350, 0}, {4, 1, 0}, {337, 336, 0},
    {81, 351, 2}, {17, 263, 1}
};

int CloneMCJ_FurnaceRecipes_GetResultNative(const CloneMCJ_ItemStack *input,
    CloneMCJ_ItemStack *result)
{
    int i;
    if (result) CloneMCJ_ItemStack_Clear(result);
    if (!input || !result || CloneMCJ_ItemStack_IsEmpty(input)) return 0;
    for (i = 0; i < (int)(sizeof(g_cloneMCFurnaceRecipes) /
        sizeof(g_cloneMCFurnaceRecipes[0])); ++i) {
        if (g_cloneMCFurnaceRecipes[i].inputID == input->itemID) {
            CloneMCJ_ItemStack_Initialize(result,
                g_cloneMCFurnaceRecipes[i].outputID, 1,
                g_cloneMCFurnaceRecipes[i].outputDamage);
            return 1;
        }
    }
    return 0;
}

int CloneMCJ_FurnaceRecipes_GetFuelTimeNative(const CloneMCJ_ItemStack *stack)
{
    const CloneMCJ_BlockDefinition *block;
    if (!stack || CloneMCJ_ItemStack_IsEmpty(stack)) return 0;
    if (stack->itemID == 280) return 100;
    if (stack->itemID == 263) return 1600;
    if (stack->itemID == 327) return 20000;
    if (stack->itemID == 6) return 100;
    if (stack->itemID >= 0 && stack->itemID < CLONEMC_J_BLOCK_REGISTRY_SIZE) {
        block = CloneMCJ_BlockRegistry_Get(stack->itemID);
        if (block && block->material == CLONEMC_J_MATERIAL_WOOD) return 300;
    }
    return 0;
}

int CloneMCJ_FurnaceRecipes_CanSmeltNative(const CloneMCJ_TileEntity *tile,
    CloneMCJ_ItemStack *result)
{
    const CloneMCJ_ItemStack *output;
    int maximum;
    if (!tile || tile->type != CLONEMC_J_TILE_FURNACE ||
        tile->itemCount < CLONEMC_J_FURNACE_INVENTORY_SIZE ||
        !CloneMCJ_FurnaceRecipes_GetResultNative(&tile->items[0], result))
        return 0;
    output = &tile->items[2];
    if (CloneMCJ_ItemStack_IsEmpty(output)) return 1;
    if (!CloneMCJ_ItemStack_IsStackableWith(output, result)) return 0;
    maximum = CloneMCJ_ItemStack_GetMaxStackSize(output);
    if (maximum > 64) maximum = 64;
    return output->stackSize + result->stackSize <= maximum;
}

int CloneMCJ_FurnaceRecipes_SmeltOneNative(CloneMCJ_TileEntity *tile)
{
    CloneMCJ_ItemStack result;
    if (!CloneMCJ_FurnaceRecipes_CanSmeltNative(tile, &result)) return 0;
    if (CloneMCJ_ItemStack_IsEmpty(&tile->items[2])) tile->items[2] = result;
    else tile->items[2].stackSize += result.stackSize;
    --tile->items[0].stackSize;
    if (tile->items[0].stackSize <= 0) CloneMCJ_ItemStack_Clear(&tile->items[0]);
    return 1;
}

void CloneMCJ_FurnaceRecipes_Register(void) { }
const char *CloneMCJ_FurnaceRecipes_JavaName(void)
{ return "net.minecraft.src.FurnaceRecipes"; }
const char *CloneMCJ_FurnaceRecipes_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_FurnaceRecipes_JavaSourceHash32(void)
{ return 0xF7066546UL; }
