/*
 * CloneMC Java port scaffold: ItemMapBase
 *
 * Java source: ItemMapBase.java
 * Java type: class ItemMapBase
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: fc9e4f99323fdd60a46374360ca8237c7e4221a1d5617dc451c78b6e04b0edc1
 * Java lines: 19
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: Item
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected ItemMapBase(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemMapBase_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemMapBase_JavaName(void)
{
    return "net.minecraft.src.ItemMapBase";
}

const char *CloneMCJ_ItemMapBase_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemMapBase_JavaSourceHash32(void)
{
    return 0xFC9E4F99UL;
}
