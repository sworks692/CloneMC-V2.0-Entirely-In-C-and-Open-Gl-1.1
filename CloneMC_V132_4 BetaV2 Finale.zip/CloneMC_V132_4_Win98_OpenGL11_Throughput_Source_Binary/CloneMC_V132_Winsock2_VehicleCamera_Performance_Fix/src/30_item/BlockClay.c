/*
 * CloneMC Java port scaffold: BlockClay
 *
 * Java source: BlockClay.java
 * Java type: class BlockClay
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: a197697aa2a3d059d2bbfde2915cf270127a6277c332496e1e85471682d49f1e
 * Java lines: 30
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Block, Material, Item, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockClay(int i, int j)
 * - public int idDropped(int i, Random random)
 * - public int quantityDropped(Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockClay_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockClay_JavaName(void)
{
    return "net.minecraft.src.BlockClay";
}

const char *CloneMCJ_BlockClay_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockClay_JavaSourceHash32(void)
{
    return 0xA197697AUL;
}
