/*
 * Direct C89 port of ContainerDispenser.java.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ContainerDispenser_InitializeNative(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_TileEntity *tile)
{
    int row;
    int column;
    int index;
    if (!container || !inventory || !tile ||
        tile->type != CLONEMC_J_TILE_DISPENSER) return;
    CloneMCJ_Container_Initialize(container);
    container->type = CLONEMC_J_CONTAINER_DISPENSER;
    container->playerInventory = inventory;
    container->tileEntity = tile;
    container->tileSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 3; ++column) {
            index = column + row * 3;
            CloneMCJ_Container_AddTypedSlot(container, &tile->items[index], 64,
                CLONEMC_J_SLOT_NORMAL, -1, index,
                62 + column * 18, 17 + row * 18);
        }
    container->tileSlotEnd = container->slotCount - 1;
    container->playerSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 9; ++column) {
            index = column + (row + 1) * 9;
            CloneMCJ_Container_AddTypedSlot(container,
                &inventory->mainInventory[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 8 + column * 18, 84 + row * 18);
        }
    container->hotbarSlotStart = container->slotCount;
    for (column = 0; column < 9; ++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column], 64, CLONEMC_J_SLOT_NORMAL,
            -1, column, 8 + column * 18, 142);
    container->hotbarSlotEnd = container->slotCount - 1;
    container->playerSlotEnd = container->hotbarSlotEnd;
}

void CloneMCJ_ContainerDispenser_Register(void) { }
const char *CloneMCJ_ContainerDispenser_JavaName(void)
{ return "net.minecraft.src.ContainerDispenser"; }
const char *CloneMCJ_ContainerDispenser_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_ContainerDispenser_JavaSourceHash32(void)
{ return 0x7D40775DUL; }
