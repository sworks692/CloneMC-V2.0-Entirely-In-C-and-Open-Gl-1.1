/*
 * CloneMC Java port scaffold: ItemAxe
 *
 * Java source: ItemAxe.java
 * Java type: class ItemAxe
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemTool
 * Implements: (none declared)
 * Source SHA-256: 6c5e841ca1d8263d6c5c1e91dd04a1e78b899fe6da07a6be42f7bef13f9b85ee
 * Java lines: 28
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: ItemTool, Block, EnumToolMaterial, enumtoolmaterial, static, Block.planks, Block.bookShelf, Block.wood, Block.chest
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static Block blocksEffectiveAgainst[]
 *
 * Java method/constructor inventory:
 * - protected ItemAxe(int i, EnumToolMaterial enumtoolmaterial)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemAxe_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemAxe_JavaName(void)
{
    return "net.minecraft.src.ItemAxe";
}

const char *CloneMCJ_ItemAxe_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemAxe_JavaSourceHash32(void)
{
    return 0x6C5E841CUL;
}
