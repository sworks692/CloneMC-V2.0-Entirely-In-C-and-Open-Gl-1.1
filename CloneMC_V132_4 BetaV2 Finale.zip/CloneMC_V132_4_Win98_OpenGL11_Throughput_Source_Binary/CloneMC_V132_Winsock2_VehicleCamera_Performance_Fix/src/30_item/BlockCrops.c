/*
 * CloneMC Java port scaffold: BlockCrops
 *
 * Java source: BlockCrops.java
 * Java type: class BlockCrops
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockFlower
 * Implements: (none declared)
 * Source SHA-256: 87a8bc90b8bf8e9bee2a316e5502d15a15461e0aff15aa3ba65d0fb333a2cf8e
 * Java lines: 150
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: BlockFlower, Block, World, EntityItem, ItemStack, Item, i, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockCrops(int i, int j)
 * - protected boolean canThisPlantGrowOnThisBlockID(int i)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public void fertilize(World world, int i, int j, int k)
 * - private float getGrowthRate(World world, int i, int j, int k)
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public int getRenderType()
 * - public void dropBlockAsItemWithChance(World world, int i, int j, int k, int l, float f)
 * - public int idDropped(int i, Random random)
 * - public int quantityDropped(Random random)
 *
 * Priority 11 directly implements the Java farmland growth-rate equation,
 * light/random growth gate and fertilization stage below.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static float CloneMCJ_BlockCrops_GrowthRate(CloneMCJ_World *world, int x, int y, int z)
{
    float rate;
    float soil;
    int sx;
    int sz;
    int northSouth;
    int eastWest;
    int diagonal;
    rate = 1.0F;
    eastWest = CloneMCJ_World_GetBlockId(world, x - 1, y, z) == 59 ||
        CloneMCJ_World_GetBlockId(world, x + 1, y, z) == 59;
    northSouth = CloneMCJ_World_GetBlockId(world, x, y, z - 1) == 59 ||
        CloneMCJ_World_GetBlockId(world, x, y, z + 1) == 59;
    diagonal = CloneMCJ_World_GetBlockId(world, x - 1, y, z - 1) == 59 ||
        CloneMCJ_World_GetBlockId(world, x + 1, y, z - 1) == 59 ||
        CloneMCJ_World_GetBlockId(world, x - 1, y, z + 1) == 59 ||
        CloneMCJ_World_GetBlockId(world, x + 1, y, z + 1) == 59;
    for (sx = x - 1; sx <= x + 1; ++sx) for (sz = z - 1; sz <= z + 1; ++sz) {
        soil = 0.0F;
        if (CloneMCJ_World_GetBlockId(world, sx, y - 1, sz) == 60) {
            soil = CloneMCJ_World_GetBlockMetadata(world, sx, y - 1, sz) > 0 ? 3.0F : 1.0F;
        }
        if (sx != x || sz != z) soil /= 4.0F;
        rate += soil;
    }
    if (diagonal || (eastWest && northSouth)) rate /= 2.0F;
    return rate;
}

static void CloneMCJ_BlockCrops_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int metadata;
    int bound;
    float rate;
    (void)blockID; (void)userData;
    if (!world || !random) return;
    if (CloneMCJ_World_GetBlockId(world, x, y - 1, z) != 60) {
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
        return;
    }
    if (CloneMCJ_World_GetBlockLightValue(world, x, y + 1, z) < 9) return;
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (metadata >= 7) return;
    rate = CloneMCJ_BlockCrops_GrowthRate(world, x, y, z);
    bound = (int)(100.0F / rate);
    if (bound < 1) bound = 1;
    if (CloneMCJavaRandom_NextIntBound(random, bound) == 0)
        CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, metadata + 1);
}

int CloneMCJ_BlockCrops_Fertilize(CloneMCJ_World *world, int x, int y, int z)
{
    if (!world || CloneMCJ_World_GetBlockId(world, x, y, z) != 59) return 0;
    if (CloneMCJ_World_GetBlockMetadata(world, x, y, z) == 7) return 1;
    return CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, 7);
}

void CloneMCJ_BlockCrops_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(59);
    if (block) block->tickRandomly = 1;
    CloneMCJ_World_RegisterBlockTick(world, 59, 1, CloneMCJ_BlockCrops_UpdateTick, 0);
}

void CloneMCJ_BlockCrops_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockCrops_JavaName(void)
{
    return "net.minecraft.src.BlockCrops";
}

const char *CloneMCJ_BlockCrops_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockCrops_JavaSourceHash32(void)
{
    return 0x87A8BC90UL;
}
