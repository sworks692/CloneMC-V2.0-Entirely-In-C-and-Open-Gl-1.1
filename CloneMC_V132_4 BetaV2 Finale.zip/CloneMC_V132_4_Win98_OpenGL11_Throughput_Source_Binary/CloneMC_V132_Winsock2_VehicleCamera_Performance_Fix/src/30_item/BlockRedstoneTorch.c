/*
 * CloneMC Java port scaffold: BlockRedstoneTorch
 *
 * Java source: BlockRedstoneTorch.java
 * Java type: class BlockRedstoneTorch
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockTorch
 * Implements: (none declared)
 * Source SHA-256: 7fb3404240d4662c00cb9b4bbd14491a00725b820c211340618ae856002657a6
 * Java lines: 230
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 15
 * Referenced Java classes: BlockTorch, Block, RedstoneUpdateInfo, World, IBlockAccess, j, k, i, world.notifyBlocksOfNeighborChange
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private boolean torchActive
 *
 * Java method/constructor inventory:
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - private boolean checkForBurnout(World world, int i, int j, int k, boolean flag)
 * - protected BlockRedstoneTorch(int i, int j, boolean flag)
 * - public int tickRate()
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onBlockRemoval(World world, int i, int j, int k)
 * - public boolean isPoweringTo(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - private boolean func_30002_h(World world, int i, int j, int k)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public boolean isIndirectlyPoweringTo(World world, int i, int j, int k, int l)
 * - public int idDropped(int i, Random random)
 * - public boolean canProvidePower()
 * - public void randomDisplayTick(World world, int i, int j, int k, Random random)
 * - private static List torchUpdates = new ArrayList()
 *
 * Priority 11 directly connects redstone-torch neighbor scheduling and active/
 * inactive transitions below.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_BlockRedstoneTorch_UpdateTick(CloneMCJ_World *world, int x,
    int y, int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int powered;
    int metadata;
    int newID;
    (void)random; (void)userData;
    if (!world || (blockID != 75 && blockID != 76)) return;
    powered = CloneMCJ_World_IsBlockIndirectlyGettingPowered(world, x, y, z);
    newID = blockID;
    if (blockID == 76 && powered) newID = 75;
    else if (blockID == 75 && !powered) newID = 76;
    if (newID != blockID) {
        metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
        world->editingBlocks = 1;
        CloneMCJ_World_SetBlockWithMetadata(world, x, y, z, newID, metadata);
        world->editingBlocks = 0;
        CloneMCJ_World_NotifyBlocksOfNeighborChange(world, x, y, z, newID);
    }
}

static void CloneMCJ_BlockRedstoneTorch_Neighbor(CloneMCJ_World *world, int x,
    int y, int z, int neighborID)
{
    int id;
    (void)neighborID;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (id == 75 || id == 76) CloneMCJ_World_ScheduleBlockUpdate(world, x, y, z, id, 2);
}

static void CloneMCJ_BlockRedstoneTorch_Changed(CloneMCJ_World *world, int x,
    int y, int z)
{
    int id;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world, x, y, z, id);
}

void CloneMCJ_BlockRedstoneTorch_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    int id;
    for (id = 75; id <= 76; ++id) {
        block = CloneMCJ_BlockRegistry_GetMutable(id);
        if (block) {
            block->neighborChanged = CloneMCJ_BlockRedstoneTorch_Neighbor;
            block->onBlockAdded = CloneMCJ_BlockRedstoneTorch_Changed;
            block->onBlockRemoved = CloneMCJ_BlockRedstoneTorch_Changed;
        }
        CloneMCJ_World_RegisterBlockTick(world, id, 0,
            CloneMCJ_BlockRedstoneTorch_UpdateTick, 0);
    }
}

void CloneMCJ_BlockRedstoneTorch_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockRedstoneTorch_JavaName(void)
{
    return "net.minecraft.src.BlockRedstoneTorch";
}

const char *CloneMCJ_BlockRedstoneTorch_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockRedstoneTorch_JavaSourceHash32(void)
{
    return 0x7FB34042UL;
}
