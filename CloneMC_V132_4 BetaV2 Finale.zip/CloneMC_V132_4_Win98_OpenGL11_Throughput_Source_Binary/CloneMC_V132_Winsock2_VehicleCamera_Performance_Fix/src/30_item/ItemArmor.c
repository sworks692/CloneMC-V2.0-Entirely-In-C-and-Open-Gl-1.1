/*
 * Direct C89 armor metadata and right-click equip support.
 *
 * The uploaded Beta ItemArmor.java defines four armor types in GUI order:
 * 0 helmet, 1 chestplate, 2 leggings, 3 boots. InventoryPlayer stores armor
 * in the opposite physical array order (boots..helmet), so the native target
 * slot is 3 - armorType, exactly matching ContainerPlayer/SlotArmor.
 */
#include "clonemc_java_port_30_item.h"

static int CloneMCJ_ItemArmor_TypeForItem(int itemID)
{
    /* Leather 298..301, chain 302..305, iron 306..309,
     * diamond 310..313, gold 314..317. */
    if(itemID<298||itemID>317)return -1;
    return (itemID-298)&3;
}

int CloneMCJ_ItemArmor_IsArmorNative(int itemID,int *armorType)
{
    int type;
    type=CloneMCJ_ItemArmor_TypeForItem(itemID);
    if(armorType)*armorType=type;
    return type>=0;
}

int CloneMCJ_ItemArmor_EquipRightClickNative(CloneMCJ_InventoryPlayer *inventory,
    CloneMCJ_ItemStack *held)
{
    CloneMCJ_ItemStack equipped;
    int armorType;
    int armorSlot;
    if(!inventory||!held||CloneMCJ_ItemStack_IsEmpty(held))return 0;
    if(!CloneMCJ_ItemArmor_IsArmorNative(held->itemID,&armorType))return 0;
    armorSlot=3-armorType;
    if(armorSlot<0||armorSlot>=CLONEMC_J_ARMOR_INVENTORY_SIZE)return 0;
    if(!CloneMCJ_ItemStack_IsEmpty(&inventory->armorInventory[armorSlot]))return 0;
    equipped=*held;
    equipped.stackSize=1;
    equipped.animationsToGo=5;
    inventory->armorInventory[armorSlot]=equipped;
    --held->stackSize;
    if(held->stackSize<=0)CloneMCJ_ItemStack_Clear(held);
    inventory->inventoryChanged=1;
    return 1;
}

void CloneMCJ_ItemArmor_Register(void)
{
}

const char *CloneMCJ_ItemArmor_JavaName(void)
{
    return "net.minecraft.src.ItemArmor";
}

const char *CloneMCJ_ItemArmor_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemArmor_JavaSourceHash32(void)
{
    return 0xF208312AUL;
}
