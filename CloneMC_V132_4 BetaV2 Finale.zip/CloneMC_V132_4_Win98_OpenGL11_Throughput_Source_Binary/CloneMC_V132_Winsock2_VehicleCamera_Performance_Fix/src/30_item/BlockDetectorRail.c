/*
 * CloneMC Java port scaffold: BlockDetectorRail
 *
 * Java source: BlockDetectorRail.java
 * Java type: class BlockDetectorRail
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockRail
 * Implements: (none declared)
 * Source SHA-256: b273b893a132f0a336bded193bb059c2ed78f423deb5ea3d274311d02ed58a01
 * Java lines: 113
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: BlockRail, World, IBlockAccess, EntityMinecart, AxisAlignedBB, Entity, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockDetectorRail(int i, int j)
 * - public int tickRate()
 * - public boolean canProvidePower()
 * - public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public boolean isPoweringTo(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public boolean isIndirectlyPoweringTo(World world, int i, int j, int k, int l)
 * - private void setStateIfMinecartInteractsWithRail(World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockDetectorRail_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockDetectorRail_JavaName(void)
{
    return "net.minecraft.src.BlockDetectorRail";
}

const char *CloneMCJ_BlockDetectorRail_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockDetectorRail_JavaSourceHash32(void)
{
    return 0xB273B893UL;
}
