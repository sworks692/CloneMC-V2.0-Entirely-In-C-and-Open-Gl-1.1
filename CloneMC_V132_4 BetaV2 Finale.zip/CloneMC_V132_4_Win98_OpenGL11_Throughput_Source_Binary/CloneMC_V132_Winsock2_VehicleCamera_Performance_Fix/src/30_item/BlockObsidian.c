/*
 * CloneMC Java port scaffold: BlockObsidian
 *
 * Java source: BlockObsidian.java
 * Java type: class BlockObsidian
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockStone
 * Implements: (none declared)
 * Source SHA-256: af030db8ea6de3c8d6acfa1147bb6344f96a27e0fc8f8d7be8680c2ffec5a4f5
 * Java lines: 30
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: BlockStone, Block
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockObsidian(int i, int j)
 * - public int quantityDropped(Random random)
 * - public int idDropped(int i, Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockObsidian_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockObsidian_JavaName(void)
{
    return "net.minecraft.src.BlockObsidian";
}

const char *CloneMCJ_BlockObsidian_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockObsidian_JavaSourceHash32(void)
{
    return 0xAF030DB8UL;
}
