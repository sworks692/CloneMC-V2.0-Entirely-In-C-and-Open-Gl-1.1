/*
 * Direct C89 conversion of the uploaded Beta BlockRail.java, RailLogic.java,
 * and BlockDetectorRail.java behavior.  Rails are non-colliding surface blocks;
 * metadata 0..9 stores the Java connection shape, and bit 3 stores powered
 * state for powered/detector rails.
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <string.h>
#include <stdlib.h>

#define CLONEMC_J_RAIL_POWERED 27
#define CLONEMC_J_RAIL_DETECTOR 28
#define CLONEMC_J_RAIL_NORMAL 66

static int g_cloneMCRailUpdateDepth=0;

static int CloneMCJ_BlockRail_IsRailID(int id)
{
    return id==CLONEMC_J_RAIL_NORMAL||id==CLONEMC_J_RAIL_POWERED||
        id==CLONEMC_J_RAIL_DETECTOR;
}

int CloneMCJ_BlockRail_IsRailAtNative(CloneMCJ_World *world,int x,int y,int z)
{
    return world&&CloneMCJ_BlockRail_IsRailID(CloneMCJ_World_GetBlockId(world,x,y,z));
}

static int CloneMCJ_BlockRail_IsNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

/* RailLogic.isMinecartTrack: a neighboring rail may be one block above or
 * below the requested coordinate. */
static int CloneMCJ_BlockRail_FindY(CloneMCJ_World *world,int x,int y,int z)
{
    if(CloneMCJ_BlockRail_IsRailAtNative(world,x,y,z))return y;
    if(CloneMCJ_BlockRail_IsRailAtNative(world,x,y+1,z))return y+1;
    if(CloneMCJ_BlockRail_IsRailAtNative(world,x,y-1,z))return y-1;
    return -9999;
}

static int CloneMCJ_BlockRail_DirectPowered(CloneMCJ_World *world,int x,int y,int z)
{
    return CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y,z)||
        CloneMCJ_World_IsBlockIndirectlyGettingPowered(world,x,y+1,z);
}

static int CloneMCJ_BlockRail_SelectShape(CloneMCJ_World *world,int x,int y,int z,
    int id,int metadata)
{
    int north,south,west,east,shape,poweredRail,directPower;
    north=CloneMCJ_BlockRail_FindY(world,x,y,z-1)!=-9999;
    south=CloneMCJ_BlockRail_FindY(world,x,y,z+1)!=-9999;
    west=CloneMCJ_BlockRail_FindY(world,x-1,y,z)!=-9999;
    east=CloneMCJ_BlockRail_FindY(world,x+1,y,z)!=-9999;
    poweredRail=id==CLONEMC_J_RAIL_POWERED||id==CLONEMC_J_RAIL_DETECTOR;
    directPower=CloneMCJ_BlockRail_DirectPowered(world,x,y,z);
    shape=-1;
    if((north||south)&&!west&&!east)shape=0;
    if((west||east)&&!north&&!south)shape=1;
    if(!poweredRail){
        if(south&&east&&!north&&!west)shape=6;
        if(south&&west&&!north&&!east)shape=7;
        if(north&&west&&!south&&!east)shape=8;
        if(north&&east&&!south&&!west)shape=9;
    }
    if(shape<0){
        if(north||south)shape=0;
        if(west||east)shape=1;
        if(!poweredRail){
            /* RailLogic.func_792_a uses indirect power only to resolve an
             * otherwise ambiguous four-way curve.  Preserve its assignment
             * order exactly. */
            if(directPower){
                if(south&&east)shape=6;
                if(west&&south)shape=7;
                if(east&&north)shape=9;
                if(north&&west)shape=8;
            }else{
                if(north&&west)shape=8;
                if(east&&north)shape=9;
                if(west&&south)shape=7;
                if(south&&east)shape=6;
            }
        }
    }
    if(shape<0)shape=(metadata&7)==1?1:0;
    if(shape==0){
        if(CloneMCJ_BlockRail_IsRailAtNative(world,x,y+1,z-1))shape=4;
        if(CloneMCJ_BlockRail_IsRailAtNative(world,x,y+1,z+1))shape=5;
    }else if(shape==1){
        if(CloneMCJ_BlockRail_IsRailAtNative(world,x+1,y+1,z))shape=2;
        if(CloneMCJ_BlockRail_IsRailAtNative(world,x-1,y+1,z))shape=3;
    }
    return shape;
}

static int CloneMCJ_BlockRail_OrientationCompatible(int expected,int actual)
{
    if(expected==0)return actual==0||actual==4||actual==5;
    return actual==1||actual==2||actual==3;
}

static int CloneMCJ_BlockRail_PropagatesPower(CloneMCJ_World *world,int x,int y,
    int z,int metadata,int forward,int depth)
{
    int shape,expected,tryBelow,nx,ny,nz,id,nextMeta,nextShape;
    if(depth>=8)return 0;
    shape=metadata&7;expected=shape==0||shape==4||shape==5?0:1;
    nx=x;ny=y;nz=z;tryBelow=1;
    switch(shape){
    case 0: nz+=forward?1:-1;break;
    case 1: nx+=forward?-1:1;break;
    case 2:
        if(forward)nx-=1;else{nx+=1;ny+=1;tryBelow=0;}expected=1;break;
    case 3:
        if(forward){nx-=1;ny+=1;tryBelow=0;}else nx+=1;expected=1;break;
    case 4:
        if(forward)nz+=1;else{nz-=1;ny+=1;tryBelow=0;}expected=0;break;
    case 5:
        if(forward){nz+=1;ny+=1;tryBelow=0;}else nz-=1;expected=0;break;
    default:return 0;
    }
    id=CloneMCJ_World_GetBlockId(world,nx,ny,nz);
    if(id!=CLONEMC_J_RAIL_POWERED&&tryBelow){--ny;id=CloneMCJ_World_GetBlockId(world,nx,ny,nz);}
    if(id!=CLONEMC_J_RAIL_POWERED)return 0;
    nextMeta=CloneMCJ_World_GetBlockMetadata(world,nx,ny,nz);
    nextShape=nextMeta&7;
    if(!CloneMCJ_BlockRail_OrientationCompatible(expected,nextShape)||
       (nextMeta&8)==0)return 0;
    if(CloneMCJ_BlockRail_DirectPowered(world,nx,ny,nz))return 1;
    return CloneMCJ_BlockRail_PropagatesPower(world,nx,ny,nz,nextMeta,
        forward,depth+1);
}

static void CloneMCJ_BlockRail_UpdatePowered(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata,shape,powered,oldPowered;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_RAIL_POWERED)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);shape=metadata&7;
    oldPowered=(metadata&8)!=0;
    powered=CloneMCJ_BlockRail_DirectPowered(world,x,y,z)||
        CloneMCJ_BlockRail_PropagatesPower(world,x,y,z,metadata,1,0)||
        CloneMCJ_BlockRail_PropagatesPower(world,x,y,z,metadata,0,0);
    if(powered!=oldPowered){
        CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,shape|(powered?8:0));
        CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,
            CLONEMC_J_RAIL_POWERED);
        if(shape>=2&&shape<=5)
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y+1,z,
                CLONEMC_J_RAIL_POWERED);
    }
}

static void CloneMCJ_BlockRail_UpdateShape(CloneMCJ_World *world,int x,int y,int z,
    int force)
{
    static const int dx[4]={0,0,-1,1};
    static const int dz[4]={-1,1,0,0};
    int id,metadata,shape,newMetadata,i,ny;
    if(!world||world->multiplayerWorld||g_cloneMCRailUpdateDepth>=12)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(!CloneMCJ_BlockRail_IsRailID(id))return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    shape=CloneMCJ_BlockRail_SelectShape(world,x,y,z,id,metadata);
    newMetadata=(id==CLONEMC_J_RAIL_NORMAL)?shape:((metadata&8)|shape);
    ++g_cloneMCRailUpdateDepth;
    if(force||newMetadata!=metadata)
        CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,newMetadata);
    /* RailLogic informs each connected neighbor after its own connection list
     * changes.  Resolve same/above/below without loading hidden chunks. */
    for(i=0;i<4;++i){
        ny=CloneMCJ_BlockRail_FindY(world,x+dx[i],y,z+dz[i]);
        if(ny!=-9999&&g_cloneMCRailUpdateDepth<12)
            CloneMCJ_BlockRail_UpdateShape(world,x+dx[i],ny,z+dz[i],0);
    }
    --g_cloneMCRailUpdateDepth;
    if(id==CLONEMC_J_RAIL_POWERED)CloneMCJ_BlockRail_UpdatePowered(world,x,y,z);
}

static int CloneMCJ_BlockRail_HasSupport(CloneMCJ_World *world,int x,int y,int z,
    int shape)
{
    if(!CloneMCJ_BlockRail_IsNormalCube(world,x,y-1,z))return 0;
    if(shape==2&&!CloneMCJ_BlockRail_IsNormalCube(world,x+1,y,z))return 0;
    if(shape==3&&!CloneMCJ_BlockRail_IsNormalCube(world,x-1,y,z))return 0;
    if(shape==4&&!CloneMCJ_BlockRail_IsNormalCube(world,x,y,z-1))return 0;
    if(shape==5&&!CloneMCJ_BlockRail_IsNormalCube(world,x,y,z+1))return 0;
    return 1;
}

static void CloneMCJ_BlockRail_Added(CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_BlockRail_UpdateShape(world,x,y,z,1);
}

static void CloneMCJ_BlockRail_Neighbor(CloneMCJ_World *world,int x,int y,int z,
    int neighborID)
{
    CloneMCJ_GameplayState *gameplay;
    CloneMCJ_ItemStack drop;
    int id,metadata,shape;
    (void)neighborID;
    if(!world||world->multiplayerWorld)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    if(!CloneMCJ_BlockRail_IsRailID(id))return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);shape=metadata&7;
    if(!CloneMCJ_BlockRail_HasSupport(world,x,y,z,shape)){
        /* Java BlockRail drops its own item only for real support loss.  This
         * path is deliberately separate from cart traversal; a slope must not
         * be destroyed merely because a cart crosses its upper boundary. */
        gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
        if(gameplay){
            CloneMCJ_ItemStack_Initialize(&drop,id,1,0);
            (void)CloneMCJ_Gameplay_SpawnDrop(gameplay,(double)x+0.5,
                (double)y+0.25,(double)z+0.5,&drop,10,0);
        }
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);return;
    }
    CloneMCJ_BlockRail_UpdateShape(world,x,y,z,0);
    if(id==CLONEMC_J_RAIL_POWERED)CloneMCJ_BlockRail_UpdatePowered(world,x,y,z);
}

static int CloneMCJ_BlockDetectorRail_HasMinecart(CloneMCJ_World *world,int x,int y,int z)
{
    CloneMCJ_GameplayState *gameplay;CloneMCAxisAlignedBB box;int i;
    if(!world)return 0;gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
    if(!gameplay)return 0;
    box=CloneMCAABB_Create((double)x+0.125,(double)y,(double)z+0.125,
        (double)x+0.875,(double)y+0.25,(double)z+0.875);
    for(i=0;i<CLONEMC_J_MAX_VEHICLES;++i){
        if(gameplay->vehicles[i].active&&
           gameplay->vehicles[i].type==CLONEMC_J_VEHICLE_MINECART&&
           CloneMCAABB_Intersects(&gameplay->vehicles[i].entity.boundingBox,&box))
            return 1;
    }
    return 0;
}

static void CloneMCJ_BlockDetectorRail_Update(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata,wasPowered,occupied;
    if(!world||world->multiplayerWorld||
       CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_RAIL_DETECTOR)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    wasPowered=(metadata&8)!=0;occupied=CloneMCJ_BlockDetectorRail_HasMinecart(world,x,y,z);
    if(occupied&&!wasPowered){
        CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,metadata|8);
        CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z,
            CLONEMC_J_RAIL_DETECTOR);
        CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,
            CLONEMC_J_RAIL_DETECTOR);
    }else if(!occupied&&wasPowered){
        CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,metadata&7);
        CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z,
            CLONEMC_J_RAIL_DETECTOR);
        CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,
            CLONEMC_J_RAIL_DETECTOR);
    }
    if(occupied)CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,
        CLONEMC_J_RAIL_DETECTOR,20);
}

static void CloneMCJ_BlockDetectorRail_Tick(CloneMCJ_World *world,int x,int y,int z,
    int blockID,CloneMCJavaRandom *random,void *userData)
{
    (void)blockID;(void)random;(void)userData;
    CloneMCJ_BlockDetectorRail_Update(world,x,y,z);
}

void CloneMCJ_BlockDetectorRail_MinecartCollisionNative(CloneMCJ_World *world,
    int x,int y,int z)
{
    if(world&&CloneMCJ_World_GetBlockId(world,x,y,z)==CLONEMC_J_RAIL_DETECTOR)
        CloneMCJ_BlockDetectorRail_Update(world,x,y,z);
}

void CloneMCJ_BlockRail_RegisterRuntime(CloneMCJ_World *world)
{
    int ids[3];int i;CloneMCJ_BlockDefinition *block;
    ids[0]=CLONEMC_J_RAIL_POWERED;ids[1]=CLONEMC_J_RAIL_DETECTOR;
    ids[2]=CLONEMC_J_RAIL_NORMAL;
    for(i=0;i<3;++i){
        block=CloneMCJ_BlockRegistry_GetMutable(ids[i]);
        if(block){
            block->material=CLONEMC_J_MATERIAL_CIRCUITS;
            block->solid=0;block->opaque=0;block->collidable=0;
            block->minX=0.0;block->minY=0.0;block->minZ=0.0;
            block->maxX=1.0;block->maxY=0.125;block->maxZ=1.0;
            block->neighborChanged=CloneMCJ_BlockRail_Neighbor;
            block->onBlockAdded=CloneMCJ_BlockRail_Added;
        }
    }
    CloneMCJ_World_RegisterBlockTick(world,CLONEMC_J_RAIL_DETECTOR,1,
        CloneMCJ_BlockDetectorRail_Tick,0);
}

static int CloneMCJ_BlockRail_TestSlopeTraversal(CloneMCJ_World *world,
    CloneMCJ_GameplayState *gameplay,int shape,int baseX,int baseZ,int ascending)
{
    CloneMCJ_Vehicle cart;
    CloneMCVec3D railPoint;
    int lowX,lowZ,highX,highZ,flatShape,tick;
    double startX,startY,startZ,travelX,travelZ,startAxis,endAxis;
    if(!world||!gameplay)return 0;
    lowX=highX=baseX;lowZ=highZ=baseZ;flatShape=0;
    if(shape==2){--lowX;++highX;flatShape=1;}
    else if(shape==3){++lowX;--highX;flatShape=1;}
    else if(shape==4){++lowZ;--highZ;}
    else if(shape==5){--lowZ;++highZ;}
    else return 0;
    CloneMCJ_World_SetBlockWithMetadata(world,baseX,79,baseZ,1,0);
    CloneMCJ_World_SetBlockWithMetadata(world,lowX,79,lowZ,1,0);
    CloneMCJ_World_SetBlockWithMetadata(world,highX,80,highZ,1,0);
    CloneMCJ_World_SetBlockWithMetadata(world,baseX,80,baseZ,66,shape);
    CloneMCJ_World_SetBlockWithMetadata(world,lowX,80,lowZ,66,flatShape);
    CloneMCJ_World_SetBlockWithMetadata(world,highX,81,highZ,66,flatShape);
    startX=(double)baseX+0.5;startZ=(double)baseZ+0.5;
    if(ascending){
        startX+=(double)(lowX-baseX)*0.42;
        startZ+=(double)(lowZ-baseZ)*0.42;
        startY=80.0;travelX=(double)(highX-baseX)*0.22;
        travelZ=(double)(highZ-baseZ)*0.22;
    }else{
        startX+=(double)(highX-baseX)*0.42;
        startZ+=(double)(highZ-baseZ)*0.42;
        startY=81.0;travelX=(double)(lowX-baseX)*0.22;
        travelZ=(double)(lowZ-baseZ)*0.22;
    }
    CloneMCJ_Vehicle_Initialize(&cart,CLONEMC_J_VEHICLE_MINECART,
        world,startX,startY,startZ,0);
    cart.entity.motionX=travelX;cart.entity.motionZ=travelZ;
    cart.riderEntityId=gameplay->player.entity.entityId;
    gameplay->player.ridingEntityId=cart.entity.entityId;
    startAxis=flatShape?cart.entity.posX:cart.entity.posZ;
    for(tick=0;tick<8;++tick){
        CloneMCJ_Vehicle_Tick(&cart,gameplay);
        if(!cart.active||cart.entity.collidedHorizontally||
           gameplay->player.ridingEntityId!=cart.entity.entityId||
           cart.riderEntityId!=gameplay->player.entity.entityId||
           !CloneMCJ_EntityMinecart_RailPositionNative(world,
                cart.entity.posX,cart.entity.posY,cart.entity.posZ,&railPoint))
            return 0;
    }
    endAxis=flatShape?cart.entity.posX:cart.entity.posZ;
    if((flatShape?travelX:travelZ)>0.0){
        if(endAxis<=startAxis+0.05)return 0;
    }else if(endAxis>=startAxis-0.05)return 0;
    return CloneMCJ_World_GetBlockId(world,baseX,80,baseZ)==66&&
        CloneMCJ_World_GetBlockId(world,lowX,80,lowZ)==66&&
        CloneMCJ_World_GetBlockId(world,highX,81,highZ)==66;
}

int CloneMCJ_BlockRail_RunV127SelfTests(char *message,unsigned int capacity)
{
    CloneMCJ_World *world;CloneMCJ_GameplayState gameplay;int ok,meta,shape;
    double cartStartX;
    world=(CloneMCJ_World *)malloc(sizeof(CloneMCJ_World));ok=world!=0;
    if(ok){
        CloneMCJ_World_InitializeDeferred(world,271828,8);
        memset(&gameplay,0,sizeof(gameplay));gameplay.world=world;
        world->gameplayUserData=&gameplay;
        CloneMCJ_BlockSimulation_RegisterWorld(world);
        CloneMCJ_World_SetBlockWithMetadata(world,0,63,0,1,0);
        CloneMCJ_World_SetBlockWithMetadata(world,0,63,1,1,0);
        CloneMCJ_World_SetBlockWithMetadataNotify(world,0,64,0,66,0);
        CloneMCJ_World_SetBlockWithMetadataNotify(world,0,64,1,66,0);
        meta=CloneMCJ_World_GetBlockMetadata(world,0,64,0);
        if(meta!=0)ok=0;
        if(CloneMCJ_BlockRegistry_Get(66)->collidable||
           CloneMCJ_BlockRegistry_Get(66)->opaque)ok=0;
        CloneMCJ_World_SetBlockWithMetadata(world,2,63,0,1,0);
        CloneMCJ_World_SetBlockWithMetadataNotify(world,2,64,0,28,1);
        CloneMCJ_Vehicle_Initialize(&gameplay.vehicles[0],CLONEMC_J_VEHICLE_MINECART,
            world,2.5,64.0,0.5,0);gameplay.vehicleCount=1;
        CloneMCJ_BlockDetectorRail_MinecartCollisionNative(world,2,64,0);
        if((CloneMCJ_World_GetBlockMetadata(world,2,64,0)&8)==0)ok=0;
        /* A powered lever beside the rail must set metadata bit 3.  A stopped
         * cart then receives Java's 0.02 launch nudge away from a solid bumper
         * and advances on the following tick. */
        CloneMCJ_World_SetBlockWithMetadata(world,4,64,0,1,0);
        CloneMCJ_World_SetBlockWithMetadata(world,6,63,0,1,0);
        CloneMCJ_World_SetBlockWithMetadataNotify(world,5,64,0,69,0);
        if(!CloneMCJ_BlockLever_OnPlacedNative(world,5,64,0,5)||
           !CloneMCJ_BlockLever_ActivateNative(world,5,64,0))ok=0;
        CloneMCJ_World_SetBlockWithMetadataNotify(world,6,64,0,27,1);
        CloneMCJ_World_SetBlockWithMetadata(world,7,64,0,1,0);
        if((CloneMCJ_World_GetBlockMetadata(world,6,64,0)&8)==0)ok=0;
        CloneMCJ_Vehicle_Initialize(&gameplay.vehicles[1],CLONEMC_J_VEHICLE_MINECART,
            world,6.5,64.5,0.5,0);gameplay.vehicleCount=2;
        cartStartX=gameplay.vehicles[1].entity.posX;
        CloneMCJ_Vehicle_Tick(&gameplay.vehicles[1],&gameplay);
        if(gameplay.vehicles[1].entity.motionX>=-0.01)ok=0;
        CloneMCJ_Vehicle_Tick(&gameplay.vehicles[1],&gameplay);
        if(gameplay.vehicles[1].entity.posX>=cartStartX)ok=0;
        CloneMCJ_EntityPlayer_Initialize(&gameplay.player,world,"SlopeTest");
        for(shape=2;shape<=5&&ok;++shape){
            if(!CloneMCJ_BlockRail_TestSlopeTraversal(world,&gameplay,
                shape,20+shape*8,0,1)||
               !CloneMCJ_BlockRail_TestSlopeTraversal(world,&gameplay,
                shape,20+shape*8,12,0))ok=0;
        }
    }
    if(world){CloneMCJ_World_Destroy(world);free(world);}
    if(message&&capacity){
        strncpy(message,ok?
            "V130 Java rail shape, four-slope ascent/descent, rider continuity, detector, lever power and stopped-cart launch tests passed":
            "V127 rail lifecycle regression test failed",capacity-1U);
        message[capacity-1U]='\0';
    }
    return ok;
}

void CloneMCJ_BlockRail_Register(void){}
const char *CloneMCJ_BlockRail_JavaName(void){return "net.minecraft.src.BlockRail";}
const char *CloneMCJ_BlockRail_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockRail_JavaSourceHash32(void){return 0xF8D9AC82UL;}
