/*
 * CloneMC Java port scaffold: BlockFluid
 *
 * Java source: BlockFluid.java
 * Java type: class BlockFluid
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 287f8173e629b0b39de9eadd87860b766c77a9a17c8e9ec66fd81e57cc740f8c
 * Java lines: 380
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 27
 * Referenced Java classes: Block, Material, World, IBlockAccess, Vec3D, AxisAlignedBB, Entity, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockFluid(int i, Material material)
 * - public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
 * - public static float getPercentAir(int i)
 * - public int getBlockTextureFromSide(int i)
 * - protected int getFlowDecay(World world, int i, int j, int k)
 * - protected int getEffectiveFlowDecay(IBlockAccess iblockaccess, int i, int j, int k)
 * - public boolean renderAsNormalBlock()
 * - public boolean isOpaqueCube()
 * - public boolean canCollideCheck(int i, boolean flag)
 * - public boolean getIsBlockSolid(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public int getRenderType()
 * - public int idDropped(int i, Random random)
 * - public int quantityDropped(Random random)
 * - private Vec3D getFlowVector(IBlockAccess iblockaccess, int i, int j, int k)
 * - public void velocityToAddToEntity(World world, int i, int j, int k, Entity entity, Vec3D vec3d)
 * - public int tickRate()
 * - public float getBlockBrightness(IBlockAccess iblockaccess, int i, int j, int k)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public int getRenderBlockPass()
 * - public void randomDisplayTick(World world, int i, int j, int k, Random random)
 * - public static double func_293_a(IBlockAccess iblockaccess, int i, int j, int k, Material material)
 * - public void onBlockAdded(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - private void checkForHarden(World world, int i, int j, int k)
 * - protected void triggerLavaMixEffects(World world, int i, int j, int k)
 *
 * Priority 11 directly implements the Java fluid decay, tick rate and lava/water
 * hardening behavior below while retaining the Open Watcom unity topology.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockFluid_IsWaterID(int id)
{
    return id == CLONEMC_J_BLOCK_WATER_MOVING || id == CLONEMC_J_BLOCK_WATER_STILL;
}

static int CloneMCJ_BlockFluid_IsLavaID(int id)
{
    return id == CLONEMC_J_BLOCK_LAVA_MOVING || id == CLONEMC_J_BLOCK_LAVA_STILL;
}

int CloneMCJ_BlockFluid_GetFlowDecay(CloneMCJ_World *world, int x, int y, int z,
    int liquidID)
{
    int id;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (CloneMCJ_BlockFluid_IsWaterID(liquidID)) {
        if (!CloneMCJ_BlockFluid_IsWaterID(id)) return -1;
    } else if (!CloneMCJ_BlockFluid_IsLavaID(id)) return -1;
    return CloneMCJ_World_GetBlockMetadata(world, x, y, z);
}

int CloneMCJ_BlockFluid_GetEffectiveFlowDecay(CloneMCJ_World *world, int x, int y,
    int z, int liquidID)
{
    int decay;
    decay = CloneMCJ_BlockFluid_GetFlowDecay(world, x, y, z, liquidID);
    if (decay >= 8) decay = 0;
    return decay;
}

int CloneMCJ_BlockFluid_TickRate(int liquidID)
{
    return CloneMCJ_BlockFluid_IsWaterID(liquidID) ? 5 : 30;
}

int CloneMCJ_BlockFluid_CheckForHarden(CloneMCJ_World *world, int x, int y, int z)
{
    int id;
    int metadata;
    int touchingWater;
    if (!world) return 0;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (!CloneMCJ_BlockFluid_IsLavaID(id)) return 0;
    touchingWater = CloneMCJ_BlockFluid_IsWaterID(CloneMCJ_World_GetBlockId(world, x - 1, y, z)) ||
        CloneMCJ_BlockFluid_IsWaterID(CloneMCJ_World_GetBlockId(world, x + 1, y, z)) ||
        CloneMCJ_BlockFluid_IsWaterID(CloneMCJ_World_GetBlockId(world, x, y, z - 1)) ||
        CloneMCJ_BlockFluid_IsWaterID(CloneMCJ_World_GetBlockId(world, x, y, z + 1)) ||
        CloneMCJ_BlockFluid_IsWaterID(CloneMCJ_World_GetBlockId(world, x, y + 1, z));
    if (!touchingWater) return 0;
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (metadata == 0)
        return CloneMCJ_World_SetBlockNotify(world, x, y, z, CLONEMC_J_BLOCK_OBSIDIAN);
    if (metadata <= 4)
        return CloneMCJ_World_SetBlockNotify(world, x, y, z, CLONEMC_J_BLOCK_COBBLESTONE);
    return 0;
}

void CloneMCJ_BlockFluid_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockFluid_JavaName(void)
{
    return "net.minecraft.src.BlockFluid";
}

const char *CloneMCJ_BlockFluid_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockFluid_JavaSourceHash32(void)
{
    return 0x287F8173UL;
}
