/*
 * CloneMC Java port scaffold: ItemShears
 *
 * Java source: ItemShears.java
 * Java type: class ItemShears
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 4638207b53c7f09e383c5b20eab1637e7e06ae5269a36f434aa3f5844e315797
 * Java lines: 51
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: Item, Block, BlockLeaves, ItemStack, EntityLiving, i, j, k, l
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemShears(int i)
 * - public boolean onBlockDestroyed(ItemStack itemstack, int i, int j, int k, int l, EntityLiving entityliving)
 * - public boolean canHarvestBlock(Block block)
 * - public float getStrVsBlock(ItemStack itemstack, Block block)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemShears_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemShears_JavaName(void)
{
    return "net.minecraft.src.ItemShears";
}

const char *CloneMCJ_ItemShears_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemShears_JavaSourceHash32(void)
{
    return 0x4638207BUL;
}
