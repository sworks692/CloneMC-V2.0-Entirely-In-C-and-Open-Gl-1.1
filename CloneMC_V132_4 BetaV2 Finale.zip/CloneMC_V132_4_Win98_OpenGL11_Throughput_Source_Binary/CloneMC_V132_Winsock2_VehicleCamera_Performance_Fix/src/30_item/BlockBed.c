/*
 * Direct C89 conversion of the Beta BlockBed metadata, support, occupancy and
 * safe-respawn helpers.  Sleeping itself is owned by EntityPlayerSP so the
 * player, world-time and dimension transition remain one authoritative state.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

#define CLONEMC_J_BED_BLOCK 26

static const int CloneMCJ_BedDirection[4][2]={{0,1},{-1,0},{0,-1},{1,0}};

int CloneMCJ_BlockBed_GetDirection(int metadata){return metadata&3;}
int CloneMCJ_BlockBed_IsFoot(int metadata){return (metadata&8)!=0;}
int CloneMCJ_BlockBed_IsOccupied(int metadata){return (metadata&4)!=0;}

void CloneMCJ_BlockBed_SetOccupied(CloneMCJ_World *world,int x,int y,int z,int occupied)
{
    int metadata,direction;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_BED_BLOCK)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    direction=CloneMCJ_BlockBed_GetDirection(metadata);
    if(!CloneMCJ_BlockBed_IsFoot(metadata)){
        x+=CloneMCJ_BedDirection[direction][0];z+=CloneMCJ_BedDirection[direction][1];
        if(CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_BED_BLOCK)return;
        metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    }
    if(occupied)metadata|=4;else metadata&=~4;
    CloneMCJ_World_SetBlockWithMetadata(world,x,y,z,CLONEMC_J_BED_BLOCK,metadata);
}

static void CloneMCJ_BlockBed_Neighbor(CloneMCJ_World *world,int x,int y,int z,int neighborID)
{
    int metadata,direction,otherX,otherZ;
    (void)neighborID;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_BED_BLOCK)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    direction=CloneMCJ_BlockBed_GetDirection(metadata);
    if(CloneMCJ_BlockBed_IsFoot(metadata)){
        otherX=x-CloneMCJ_BedDirection[direction][0];
        otherZ=z-CloneMCJ_BedDirection[direction][1];
    }else{
        otherX=x+CloneMCJ_BedDirection[direction][0];
        otherZ=z+CloneMCJ_BedDirection[direction][1];
    }
    if(CloneMCJ_World_GetBlockId(world,otherX,y,otherZ)!=CLONEMC_J_BED_BLOCK||
       !CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,x,y-1,z)))
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
}

void CloneMCJ_BlockBed_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;block=CloneMCJ_BlockRegistry_GetMutable(CLONEMC_J_BED_BLOCK);
    if(!block)return;
    block->solid=0;block->opaque=0;block->collidable=1;block->lightOpacity=0;
    block->minX=0.0;block->minY=0.0;block->minZ=0.0;
    block->maxX=1.0;block->maxY=0.5625;block->maxZ=1.0;
    block->neighborChanged=CloneMCJ_BlockBed_Neighbor;
}

void CloneMCJ_BlockBed_Register(void){}
const char *CloneMCJ_BlockBed_JavaName(void){return "net.minecraft.src.BlockBed";}
const char *CloneMCJ_BlockBed_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockBed_JavaSourceHash32(void){return 0xC48298A3UL;}
