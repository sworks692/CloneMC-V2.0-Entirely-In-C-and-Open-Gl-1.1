/*
 * CloneMC Java port scaffold: BlockGrass
 *
 * Java source: BlockGrass.java
 * Java type: class BlockGrass
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: e672bc139dacbf9339c8c255fb185b802024b7f5c667f1bb125ce90c1404534b
 * Java lines: 77
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: Block, Material, IBlockAccess, WorldChunkManager, ColorizerGrass, World, k, j, i1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockGrass(int i)
 * - public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public int idDropped(int i, Random random)
 *
 * Priority 11 directly ports Java low-light death and one-attempt dirt spread.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_BlockGrass_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int xx;
    int yy;
    int zz;
    int above;
    (void)blockID; (void)userData;
    if (!world || !random || world->multiplayerWorld) return;
    above = CloneMCJ_World_GetBlockId(world, x, y + 1, z);
    if (CloneMCJ_World_GetBlockLightValue(world, x, y + 1, z) < 4 &&
        CloneMCJ_World_GetBlockLightOpacity(above) > 2) {
        if (CloneMCJavaRandom_NextIntBound(random, 4) == 0)
            CloneMCJ_World_SetBlockNotify(world, x, y, z, 3);
    } else if (CloneMCJ_World_GetBlockLightValue(world, x, y + 1, z) >= 9) {
        xx = x + CloneMCJavaRandom_NextIntBound(random, 3) - 1;
        yy = y + CloneMCJavaRandom_NextIntBound(random, 5) - 3;
        zz = z + CloneMCJavaRandom_NextIntBound(random, 3) - 1;
        above = CloneMCJ_World_GetBlockId(world, xx, yy + 1, zz);
        if (CloneMCJ_World_GetBlockId(world, xx, yy, zz) == 3 &&
            CloneMCJ_World_GetBlockLightValue(world, xx, yy + 1, zz) >= 4 &&
            CloneMCJ_World_GetBlockLightOpacity(above) <= 2)
            CloneMCJ_World_SetBlockNotify(world, xx, yy, zz, 2);
    }
}

void CloneMCJ_BlockGrass_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(2);
    if (block) block->tickRandomly = 1;
    CloneMCJ_World_RegisterBlockTick(world, 2, 1, CloneMCJ_BlockGrass_UpdateTick, 0);
}

void CloneMCJ_BlockGrass_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockGrass_JavaName(void)
{
    return "net.minecraft.src.BlockGrass";
}

const char *CloneMCJ_BlockGrass_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockGrass_JavaSourceHash32(void)
{
    return 0xE672BC13UL;
}
