/*
 * CloneMC Java port scaffold: MapInfo
 *
 * Java source: MapInfo.java
 * Java type: class MapInfo
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 196ed11463574424c4f6f6c832cc00b485fdad78171917b530653ff441711706
 * Java lines: 38
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: EntityPlayer, MapData
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final EntityPlayer entityplayerObj
 * - public int field_28119_b[]
 * - public int field_28124_c[]
 * - private int field_28122_e
 * - private int field_28121_f
 *
 * Java method/constructor inventory:
 * - public MapInfo(MapData mapdata, EntityPlayer entityplayer)
 *
 * Direct bounded transcription of the Java constructor.  The fixed observer
 * capacity replaces ArrayList allocation without changing each observer's
 * 128-column dirty-range state.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_MapInfo_Initialize(CloneMCJ_MapInfo *info,
    struct CloneMCJ_EntityPlayerTag *player)
{
    int index;
    if(!info)return;
    info->player=player;info->packetColumn=0;info->iconTick=0;
    for(index=0;index<CLONEMC_J_MAP_SIZE;++index){
        info->minDirty[index]=0;info->maxDirty[index]=127;
    }
}

void CloneMCJ_MapInfo_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MapInfo_JavaName(void)
{
    return "net.minecraft.src.MapInfo";
}

const char *CloneMCJ_MapInfo_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_MapInfo_JavaSourceHash32(void)
{
    return 0x196ED114UL;
}
