/*
 * CloneMC Java port scaffold: BlockDeadBush
 *
 * Java source: BlockDeadBush.java
 * Java type: class BlockDeadBush
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockFlower
 * Implements: (none declared)
 * Source SHA-256: 85bf6a7a01c5587d4038e338093621400cbffa10b71063f43244ffa1d6c20dcb
 * Java lines: 37
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: BlockFlower, Block
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockDeadBush(int i, int j)
 * - protected boolean canThisPlantGrowOnThisBlockID(int i)
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public int idDropped(int i, Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockDeadBush_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockDeadBush_JavaName(void)
{
    return "net.minecraft.src.BlockDeadBush";
}

const char *CloneMCJ_BlockDeadBush_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockDeadBush_JavaSourceHash32(void)
{
    return 0x85BF6A7AUL;
}
