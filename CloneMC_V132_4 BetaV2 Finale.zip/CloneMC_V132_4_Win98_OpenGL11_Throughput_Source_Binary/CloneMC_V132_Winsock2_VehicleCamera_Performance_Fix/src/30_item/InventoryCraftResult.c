/*
 * Direct Open Watcom C89 port of InventoryCraftResult.java.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_InventoryCraftResult_Initialize(CloneMCJ_InventoryCraftResult *inventory)
{
    if (!inventory) return;
    CloneMCJ_ItemStack_Clear(&inventory->result);
    inventory->changeSerial = 0UL;
}

void CloneMCJ_InventoryCraftResult_Set(CloneMCJ_InventoryCraftResult *inventory,
    const CloneMCJ_ItemStack *stack)
{
    if (!inventory) return;
    if (stack) inventory->result = *stack;
    else CloneMCJ_ItemStack_Clear(&inventory->result);
    ++inventory->changeSerial;
}

CloneMCJ_ItemStack *CloneMCJ_InventoryCraftResult_Get(
    CloneMCJ_InventoryCraftResult *inventory)
{
    return inventory ? &inventory->result : (CloneMCJ_ItemStack *)0;
}

void CloneMCJ_InventoryCraftResult_Register(void) { }
const char *CloneMCJ_InventoryCraftResult_JavaName(void)
{ return "net.minecraft.src.InventoryCraftResult"; }
const char *CloneMCJ_InventoryCraftResult_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_InventoryCraftResult_JavaSourceHash32(void)
{ return 0x5952BE53UL; }
