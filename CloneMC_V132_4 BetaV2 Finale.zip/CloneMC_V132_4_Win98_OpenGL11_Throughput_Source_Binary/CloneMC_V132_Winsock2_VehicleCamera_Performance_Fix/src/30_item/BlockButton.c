/*
 * Direct C89 conversion of the uploaded Beta BlockButton.java behavior.
 * The button is a non-colliding wall attachment, carries its orientation in
 * metadata bits 0..2, and uses bit 3 as the temporary powered state.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockButton_IsNormalCube(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->opaque&&block->collidable;
}

int CloneMCJ_BlockButton_CanPlaceOnSideNative(CloneMCJ_World *world,
    int x,int y,int z,int side)
{
    if(!world)return 0;
    if(side==2)return CloneMCJ_BlockButton_IsNormalCube(world,x,y,z+1);
    if(side==3)return CloneMCJ_BlockButton_IsNormalCube(world,x,y,z-1);
    if(side==4)return CloneMCJ_BlockButton_IsNormalCube(world,x+1,y,z);
    if(side==5)return CloneMCJ_BlockButton_IsNormalCube(world,x-1,y,z);
    return 0;
}

int CloneMCJ_BlockButton_CanPlaceAtNative(CloneMCJ_World *world,int x,int y,int z)
{
    if(!world)return 0;
    return CloneMCJ_BlockButton_IsNormalCube(world,x-1,y,z)||
        CloneMCJ_BlockButton_IsNormalCube(world,x+1,y,z)||
        CloneMCJ_BlockButton_IsNormalCube(world,x,y,z-1)||
        CloneMCJ_BlockButton_IsNormalCube(world,x,y,z+1);
}

static int CloneMCJ_BlockButton_HasSupport(CloneMCJ_World *world,
    int x,int y,int z,int orientation)
{
    if(orientation==1)return CloneMCJ_BlockButton_IsNormalCube(world,x-1,y,z);
    if(orientation==2)return CloneMCJ_BlockButton_IsNormalCube(world,x+1,y,z);
    if(orientation==3)return CloneMCJ_BlockButton_IsNormalCube(world,x,y,z-1);
    if(orientation==4)return CloneMCJ_BlockButton_IsNormalCube(world,x,y,z+1);
    return 0;
}

static void CloneMCJ_BlockButton_NotifyAttached(CloneMCJ_World *world,
    int x,int y,int z,int metadata)
{
    int orientation;
    if(!world)return;
    orientation=metadata&7;
    CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z,77);
    if(orientation==1)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x-1,y,z,77);
    else if(orientation==2)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x+1,y,z,77);
    else if(orientation==3)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z-1,77);
    else if(orientation==4)CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y,z+1,77);
    else CloneMCJ_World_NotifyBlocksOfNeighborChange(world,x,y-1,z,77);
}

static void CloneMCJ_BlockButton_UpdateTick(CloneMCJ_World *world,int x,int y,int z,
    int blockID,CloneMCJavaRandom *random,void *userData)
{
    int metadata;
    (void)random;(void)userData;
    if(!world||world->multiplayerWorld||blockID!=77||
       CloneMCJ_World_GetBlockId(world,x,y,z)!=77)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if((metadata&8)==0)return;
    if(CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,metadata&7))
        CloneMCJ_BlockButton_NotifyAttached(world,x,y,z,metadata);
}

static void CloneMCJ_BlockButton_Neighbor(CloneMCJ_World *world,int x,int y,int z,
    int neighborID)
{
    int metadata;
    (void)neighborID;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=77)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(!CloneMCJ_BlockButton_CanPlaceAtNative(world,x,y,z)||
       !CloneMCJ_BlockButton_HasSupport(world,x,y,z,metadata&7)){
        if(metadata&8)CloneMCJ_BlockButton_NotifyAttached(world,x,y,z,metadata);
        /* The gameplay harvester handles player drops; support loss removes
         * the unsupported attachment exactly when its backing cube vanishes. */
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
    }
}

static void CloneMCJ_BlockButton_Removed(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata;
    if(!world)return;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(metadata&8)CloneMCJ_BlockButton_NotifyAttached(world,x,y,z,metadata);
}

void CloneMCJ_BlockButton_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block=CloneMCJ_BlockRegistry_GetMutable(77);
    if(block){
        block->solid=0;block->opaque=0;block->collidable=0;
        block->minX=0.3125;block->minY=0.375;block->minZ=0.4375;
        block->maxX=0.6875;block->maxY=0.625;block->maxZ=0.5625;
        block->neighborChanged=CloneMCJ_BlockButton_Neighbor;
        block->onBlockRemoved=CloneMCJ_BlockButton_Removed;
    }
    CloneMCJ_World_RegisterBlockTick(world,77,1,
        CloneMCJ_BlockButton_UpdateTick,(void *)0);
}

int CloneMCJ_BlockButton_ActivateNative(CloneMCJ_World *world,int x,int y,int z)
{
    int metadata;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=77)return 0;
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(metadata&8)return 1;
    if(!CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,metadata|8))return 0;
    CloneMCJ_BlockButton_NotifyAttached(world,x,y,z,metadata|8);
    CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,77,20);
    return 1;
}

void CloneMCJ_BlockButton_Register(void){}
const char *CloneMCJ_BlockButton_JavaName(void){return "net.minecraft.src.BlockButton";}
const char *CloneMCJ_BlockButton_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockButton_JavaSourceHash32(void){return 0x1F4E9B7EUL;}
