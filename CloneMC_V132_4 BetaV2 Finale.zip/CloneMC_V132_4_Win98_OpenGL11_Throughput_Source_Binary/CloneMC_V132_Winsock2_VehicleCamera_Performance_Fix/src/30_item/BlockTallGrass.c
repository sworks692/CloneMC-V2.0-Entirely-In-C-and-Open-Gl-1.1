/*
 * CloneMC Java port scaffold: BlockTallGrass
 *
 * Java source: BlockTallGrass.java
 * Java type: class BlockTallGrass
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockFlower
 * Implements: (none declared)
 * Source SHA-256: 1a0c8aeb5e13c3e45def5b2c1eab1b969ccfca978e7159a01805a70e4f71ffce
 * Java lines: 73
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: BlockFlower, IBlockAccess, WorldChunkManager, ColorizerGrass, Item, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockTallGrass(int i, int j)
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
 * - public int idDropped(int i, Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockTallGrass_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockTallGrass_JavaName(void)
{
    return "net.minecraft.src.BlockTallGrass";
}

const char *CloneMCJ_BlockTallGrass_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockTallGrass_JavaSourceHash32(void)
{
    return 0x1A0C8AEBUL;
}
