/*
 * Direct C89 conversion of ItemFlintAndSteel.onItemUse.
 *
 * Java source: ItemFlintAndSteel.java
 * Java type: class ItemFlintAndSteel
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 0e72d131fe2574a7d0ab82a6f63597e17545db4ebe890d249dc520c30f6f2f47
 * Java lines: 59
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, World, Block, BlockFire, ItemStack, EntityPlayer, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemFlintAndSteel(int i)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

int CloneMCJ_ItemFlintAndSteel_UseNative(CloneMCJ_World *world,
    CloneMCJ_ItemStack *stack,CloneMCJ_EntityPlayer *player,
    int x,int y,int z,int side)
{
    (void)player;
    if(!world||!stack||CloneMCJ_ItemStack_IsEmpty(stack)||
       stack->itemID!=259)return 0;
    if(side==0)--y;else if(side==1)++y;
    else if(side==2)--z;else if(side==3)++z;
    else if(side==4)--x;else if(side==5)++x;
    else return 0;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)==0)
        CloneMCJ_World_SetBlockNotify(world,x,y,z,51);
    /* Java damages the tool and returns true even if the offset cell was not
     * air.  ItemStack_Damage clears the stack at maxDamage=64. */
    CloneMCJ_ItemStack_Damage(stack,1);
    return 1;
}

void CloneMCJ_ItemFlintAndSteel_Register(void)
{
    /* Item use is dispatched by the singleplayer gameplay controller. */
}

const char *CloneMCJ_ItemFlintAndSteel_JavaName(void)
{
    return "net.minecraft.src.ItemFlintAndSteel";
}

const char *CloneMCJ_ItemFlintAndSteel_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemFlintAndSteel_JavaSourceHash32(void)
{
    return 0x0E72D131UL;
}
