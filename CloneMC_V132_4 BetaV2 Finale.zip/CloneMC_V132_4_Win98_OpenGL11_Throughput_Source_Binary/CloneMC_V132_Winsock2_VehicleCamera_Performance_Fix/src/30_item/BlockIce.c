/*
 * CloneMC Java port scaffold: BlockIce
 *
 * Java source: BlockIce.java
 * Java type: class BlockIce
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockBreakable
 * Implements: (none declared)
 * Source SHA-256: 74d3069e8fd96163fac2cadf0f7a3173500a5fab69887912f5d4f82082c1558d
 * Java lines: 62
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: BlockBreakable, Material, World, Block, EnumSkyBlock, IBlockAccess, EntityPlayer, j, Material.ice, i, k, entityplayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockIce(int i, int j)
 * - public int getRenderBlockPass()
 * - public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l)
 * - public void harvestBlock(World world, EntityPlayer entityplayer, int i, int j, int k, int l)
 * - public int quantityDropped(Random random)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public int getMobilityFlag()
 *
 * Priority 11 directly ports Java block-light melting into still water.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_BlockIce_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    (void)random; (void)userData;
    if (!world) return;
    if (CloneMCJ_World_GetSavedLightValue(world, CLONEMC_J_ENUM_SKY_BLOCK_BLOCK,
            x, y, z) > 11 - CloneMCJ_World_GetBlockLightOpacity(blockID))
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 9);
}

void CloneMCJ_BlockIce_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(79);
    if (block) block->tickRandomly = 1;
    CloneMCJ_World_RegisterBlockTick(world, 79, 1, CloneMCJ_BlockIce_UpdateTick, 0);
}

void CloneMCJ_BlockIce_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockIce_JavaName(void)
{
    return "net.minecraft.src.BlockIce";
}

const char *CloneMCJ_BlockIce_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockIce_JavaSourceHash32(void)
{
    return 0x74D3069EUL;
}
