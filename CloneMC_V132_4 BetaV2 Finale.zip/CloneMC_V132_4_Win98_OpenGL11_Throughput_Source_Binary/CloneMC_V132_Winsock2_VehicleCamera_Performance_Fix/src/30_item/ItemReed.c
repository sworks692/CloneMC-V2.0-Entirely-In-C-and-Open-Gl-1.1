/*
 * CloneMC Java port scaffold: ItemReed
 *
 * Java source: ItemReed.java
 * Java type: class ItemReed
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: abbfa84de6251ca8904be3e49502531f823d0bd30724452c2629eb6e3d85b90a
 * Java lines: 73
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, Block, World, ItemStack, StepSound, EntityPlayer, j, i, k, false
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_320_a
 *
 * Java method/constructor inventory:
 * - public ItemReed(int i, Block block)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemReed_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemReed_JavaName(void)
{
    return "net.minecraft.src.ItemReed";
}

const char *CloneMCJ_ItemReed_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemReed_JavaSourceHash32(void)
{
    return 0xABBFA84DUL;
}
