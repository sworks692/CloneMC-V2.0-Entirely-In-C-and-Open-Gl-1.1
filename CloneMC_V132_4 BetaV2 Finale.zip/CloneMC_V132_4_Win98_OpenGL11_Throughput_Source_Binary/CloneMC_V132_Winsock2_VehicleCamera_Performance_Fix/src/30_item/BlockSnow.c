/*
 * CloneMC Java port scaffold: BlockSnow
 *
 * Java source: BlockSnow.java
 * Java type: class BlockSnow
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: dba276d62eb7838c98d9ca4074bfbb7f3edbf9616d1fa03a11d1aa209143d937
 * Java lines: 127
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: Block, Material, World, AxisAlignedBB, IBlockAccess, Item, EntityItem, ItemStack, StatList, EntityPlayer, EnumSkyBlock, j, f, i, k, world.s
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockSnow(int i, int j)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int i, int j, int k)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - private boolean func_314_h(World world, int i, int j, int k)
 * - public void harvestBlock(World world, EntityPlayer entityplayer, int i, int j, int k, int l)
 * - public int idDropped(int i, Random random)
 * - public int quantityDropped(Random random)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l)
 *
 * Priority 11 directly ports Java opaque-solid support and block-light melting.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static int CloneMCJ_BlockSnow_CanStay(CloneMCJ_World *world, int x, int y, int z)
{
    int below;
    const CloneMCJ_BlockDefinition *block;
    if (!world || y <= 0) return 0;
    below = CloneMCJ_World_GetBlockId(world, x, y - 1, z);
    if (below == 0) return 0;
    block = CloneMCJ_BlockRegistry_Get(below);
    return block && block->opaque && block->solid;
}

static void CloneMCJ_BlockSnow_Neighbor(CloneMCJ_World *world, int x, int y,
    int z, int neighborID)
{
    (void)neighborID;
    if (!CloneMCJ_BlockSnow_CanStay(world, x, y, z))
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
}

static void CloneMCJ_BlockSnow_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    (void)blockID; (void)random; (void)userData;
    if (world && CloneMCJ_World_GetSavedLightValue(world,
            CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, x, y, z) > 11)
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
}

void CloneMCJ_BlockSnow_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(78);
    if (block) { block->tickRandomly = 1; block->neighborChanged = CloneMCJ_BlockSnow_Neighbor; }
    CloneMCJ_World_RegisterBlockTick(world, 78, 1, CloneMCJ_BlockSnow_UpdateTick, 0);
}

void CloneMCJ_BlockSnow_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockSnow_JavaName(void)
{
    return "net.minecraft.src.BlockSnow";
}

const char *CloneMCJ_BlockSnow_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockSnow_JavaSourceHash32(void)
{
    return 0xDBA276D6UL;
}
