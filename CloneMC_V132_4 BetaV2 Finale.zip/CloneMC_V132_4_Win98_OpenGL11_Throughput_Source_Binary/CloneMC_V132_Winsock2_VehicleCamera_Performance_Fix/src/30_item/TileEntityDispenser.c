/*
 * CloneMC Java port scaffold: TileEntityDispenser
 *
 * Java source: TileEntityDispenser.java
 * Java type: class TileEntityDispenser
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: TileEntity
 * Implements: IInventory
 * Source SHA-256: 714e75e8ab9a8ccf509cb430105058f73a75a3612f4d254414854b7e7f6bb0e8
 * Java lines: 145
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: TileEntity, IInventory, ItemStack, NBTTagCompound, NBTTagList, World, EntityPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private ItemStack dispenserContents[]
 * - private Random dispenserRandom
 *
 * Java method/constructor inventory:
 * - public TileEntityDispenser()
 * - public int getSizeInventory()
 * - public ItemStack getStackInSlot(int i)
 * - public ItemStack decrStackSize(int i, int j)
 * - public ItemStack getRandomStackFromInventory()
 * - public void setInventorySlotContents(int i, ItemStack itemstack)
 * - public String getInvName()
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 * - public int getInventoryStackLimit()
 * - public boolean canInteractWith(EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_TileEntityDispenser_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_TileEntityDispenser_JavaName(void)
{
    return "net.minecraft.src.TileEntityDispenser";
}

const char *CloneMCJ_TileEntityDispenser_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_TileEntityDispenser_JavaSourceHash32(void)
{
    return 0x714E75E8UL;
}
