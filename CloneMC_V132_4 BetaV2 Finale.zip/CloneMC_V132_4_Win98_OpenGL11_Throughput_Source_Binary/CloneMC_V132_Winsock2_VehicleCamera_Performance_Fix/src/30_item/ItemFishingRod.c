/*
 * CloneMC Java port scaffold: ItemFishingRod
 *
 * Java source: ItemFishingRod.java
 * Java type: class ItemFishingRod
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 0d4ec6f6a381c4cdf43d6ae887935a479705a0956a3c211619023040bed8a4c7
 * Java lines: 52
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: Item, EntityPlayer, EntityFish, ItemStack, World
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemFishingRod(int i)
 * - public boolean isFull3D()
 * - public boolean shouldRotateAroundWhenRendering()
 * - public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemFishingRod_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemFishingRod_JavaName(void)
{
    return "net.minecraft.src.ItemFishingRod";
}

const char *CloneMCJ_ItemFishingRod_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemFishingRod_JavaSourceHash32(void)
{
    return 0x0D4EC6F6UL;
}
