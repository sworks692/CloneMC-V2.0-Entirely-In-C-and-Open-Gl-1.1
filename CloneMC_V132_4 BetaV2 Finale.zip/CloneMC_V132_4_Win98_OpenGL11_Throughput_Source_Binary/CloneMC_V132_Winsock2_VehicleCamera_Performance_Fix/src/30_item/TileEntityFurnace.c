/*
 * CloneMC Java port scaffold: TileEntityFurnace
 *
 * Java source: TileEntityFurnace.java
 * Java type: class TileEntityFurnace
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: TileEntity
 * Implements: IInventory
 * Source SHA-256: 97786ee2ea6bb550eb6140e663ebbaafea45ad0e978cea388ac546df968cb536
 * Java lines: 274
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 17
 * Referenced Java classes: TileEntity, IInventory, ItemStack, NBTTagCompound, NBTTagList, World, BlockFurnace, FurnaceRecipes, Item, Block, Material, EntityPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private ItemStack furnaceItemStacks[]
 * - public int furnaceBurnTime
 * - public int currentItemBurnTime
 * - public int furnaceCookTime
 *
 * Java method/constructor inventory:
 * - public TileEntityFurnace()
 * - public int getSizeInventory()
 * - public ItemStack getStackInSlot(int i)
 * - public ItemStack decrStackSize(int i, int j)
 * - public void setInventorySlotContents(int i, ItemStack itemstack)
 * - public String getInvName()
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 * - public int getInventoryStackLimit()
 * - public int getCookProgressScaled(int i)
 * - public int getBurnTimeRemainingScaled(int i)
 * - public boolean isBurning()
 * - public void updateEntity()
 * - private boolean canSmelt()
 * - public void smeltItem()
 * - private int getItemBurnTime(ItemStack itemstack)
 * - public boolean canInteractWith(EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_TileEntityFurnace_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_TileEntityFurnace_JavaName(void)
{
    return "net.minecraft.src.TileEntityFurnace";
}

const char *CloneMCJ_TileEntityFurnace_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_TileEntityFurnace_JavaSourceHash32(void)
{
    return 0x97786EE2UL;
}
