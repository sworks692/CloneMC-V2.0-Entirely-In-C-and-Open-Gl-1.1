/*
 * CloneMC Java port scaffold: ItemSpade
 *
 * Java source: ItemSpade.java
 * Java type: class ItemSpade
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemTool
 * Implements: (none declared)
 * Source SHA-256: 74938ca0a9067a542b4999cd1d21fe9967bb6d5de134f830e4e133e846a478e0
 * Java lines: 37
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: ItemTool, Block, EnumToolMaterial, enumtoolmaterial, static, Block.grass, Block.dirt, Block.sand, Block.gravel, Block.snow, Block.blockSnow, Block.blockClay, Block.tilledField
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static Block blocksEffectiveAgainst[]
 *
 * Java method/constructor inventory:
 * - public ItemSpade(int i, EnumToolMaterial enumtoolmaterial)
 * - public boolean canHarvestBlock(Block block)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemSpade_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemSpade_JavaName(void)
{
    return "net.minecraft.src.ItemSpade";
}

const char *CloneMCJ_ItemSpade_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemSpade_JavaSourceHash32(void)
{
    return 0x74938CA0UL;
}
