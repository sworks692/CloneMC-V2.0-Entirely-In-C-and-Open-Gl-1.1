/*
 * CloneMC Java port scaffold: TileEntityRecordPlayer
 *
 * Java source: TileEntityRecordPlayer.java
 * Java type: class TileEntityRecordPlayer
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: TileEntity
 * Implements: (none declared)
 * Source SHA-256: b63436ac48504188890d15b9fa149259461fcd15ce8b217bf77dfaba3855e34c
 * Java lines: 35
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: TileEntity, NBTTagCompound
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int record
 *
 * Java method/constructor inventory:
 * - public TileEntityRecordPlayer()
 * - public void readFromNBT(NBTTagCompound nbttagcompound)
 * - public void writeToNBT(NBTTagCompound nbttagcompound)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_TileEntityRecordPlayer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_TileEntityRecordPlayer_JavaName(void)
{
    return "net.minecraft.src.TileEntityRecordPlayer";
}

const char *CloneMCJ_TileEntityRecordPlayer_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_TileEntityRecordPlayer_JavaSourceHash32(void)
{
    return 0xB63436ACUL;
}
