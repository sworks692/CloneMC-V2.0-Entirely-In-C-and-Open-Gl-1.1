/*
 * Direct C89 recipe registrations ported from RecipesArmor.java.
 */
#include "clonemc_java_port_30_item.h"

static const short g_cloneMCRecipesArmorRecipeData[][25] = {
    {1, 298, 0, 1, 3, 2, 6, 334, 0, 334, 0, 334, 0, 334, 0, 0, 0, 334, 0, 0, 0, 0, 0, 0, 0},
    {1, 299, 0, 1, 3, 3, 9, 334, 0, 0, 0, 334, 0, 334, 0, 334, 0, 334, 0, 334, 0, 334, 0, 334, 0},
    {1, 300, 0, 1, 3, 3, 9, 334, 0, 334, 0, 334, 0, 334, 0, 0, 0, 334, 0, 334, 0, 0, 0, 334, 0},
    {1, 301, 0, 1, 3, 2, 6, 334, 0, 0, 0, 334, 0, 334, 0, 0, 0, 334, 0, 0, 0, 0, 0, 0, 0},
    {1, 302, 0, 1, 3, 2, 6, 51, -1, 51, -1, 51, -1, 51, -1, 0, 0, 51, -1, 0, 0, 0, 0, 0, 0},
    {1, 303, 0, 1, 3, 3, 9, 51, -1, 0, 0, 51, -1, 51, -1, 51, -1, 51, -1, 51, -1, 51, -1, 51, -1},
    {1, 304, 0, 1, 3, 3, 9, 51, -1, 51, -1, 51, -1, 51, -1, 0, 0, 51, -1, 51, -1, 0, 0, 51, -1},
    {1, 305, 0, 1, 3, 2, 6, 51, -1, 0, 0, 51, -1, 51, -1, 0, 0, 51, -1, 0, 0, 0, 0, 0, 0},
    {1, 306, 0, 1, 3, 2, 6, 265, 0, 265, 0, 265, 0, 265, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0},
    {1, 307, 0, 1, 3, 3, 9, 265, 0, 0, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0, 265, 0},
    {1, 308, 0, 1, 3, 3, 9, 265, 0, 265, 0, 265, 0, 265, 0, 0, 0, 265, 0, 265, 0, 0, 0, 265, 0},
    {1, 309, 0, 1, 3, 2, 6, 265, 0, 0, 0, 265, 0, 265, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0},
    {1, 310, 0, 1, 3, 2, 6, 264, 0, 264, 0, 264, 0, 264, 0, 0, 0, 264, 0, 0, 0, 0, 0, 0, 0},
    {1, 311, 0, 1, 3, 3, 9, 264, 0, 0, 0, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0, 264, 0},
    {1, 312, 0, 1, 3, 3, 9, 264, 0, 264, 0, 264, 0, 264, 0, 0, 0, 264, 0, 264, 0, 0, 0, 264, 0},
    {1, 313, 0, 1, 3, 2, 6, 264, 0, 0, 0, 264, 0, 264, 0, 0, 0, 264, 0, 0, 0, 0, 0, 0, 0},
    {1, 314, 0, 1, 3, 2, 6, 266, 0, 266, 0, 266, 0, 266, 0, 0, 0, 266, 0, 0, 0, 0, 0, 0, 0},
    {1, 315, 0, 1, 3, 3, 9, 266, 0, 0, 0, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0, 266, 0},
    {1, 316, 0, 1, 3, 3, 9, 266, 0, 266, 0, 266, 0, 266, 0, 0, 0, 266, 0, 266, 0, 0, 0, 266, 0},
    {1, 317, 0, 1, 3, 2, 6, 266, 0, 0, 0, 266, 0, 266, 0, 0, 0, 266, 0, 0, 0, 0, 0, 0, 0}
};

void CloneMCJ_RecipesArmor_AddNative(void)
{
    CloneMCJ_ItemStack output;
    CloneMCJ_RecipeIngredient ingredients[CLONEMC_J_MAX_RECIPE_CELLS];
    int recipeIndex;
    int ingredientIndex;
    const short *data;
    for (recipeIndex = 0; recipeIndex < (int)(sizeof(g_cloneMCRecipesArmorRecipeData) /
        sizeof(g_cloneMCRecipesArmorRecipeData[0])); ++recipeIndex) {
        data = g_cloneMCRecipesArmorRecipeData[recipeIndex];
        CloneMCJ_ItemStack_Initialize(&output, data[1], data[3], data[2]);
        for (ingredientIndex = 0;
             ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
             ++ingredientIndex) {
            ingredients[ingredientIndex].itemID =
                data[7 + ingredientIndex * 2];
            ingredients[ingredientIndex].itemDamage =
                data[8 + ingredientIndex * 2];
        }
        if (data[0])
            CloneMCJ_CraftingManager_AddShapedNative(&output,
                data[4], data[5], ingredients);
        else
            CloneMCJ_CraftingManager_AddShapelessNative(&output,
                data[6], ingredients);
    }
}

void CloneMCJ_RecipesArmor_Register(void) { }
const char *CloneMCJ_RecipesArmor_JavaName(void)
{ return "net.minecraft.src.RecipesArmor"; }
const char *CloneMCJ_RecipesArmor_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_RecipesArmor_JavaSourceHash32(void)
{ return 0x6225D20AUL; }
