/*
 * CloneMC Java port scaffold: BlockFlower
 *
 * Java source: BlockFlower.java
 * Java type: class BlockFlower
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 0853790e23789ac504089c3907db8ede45c39f8b97b75c729c699adfb0f40b4c
 * Java lines: 80
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: Block, Material, World, BlockGrass, AxisAlignedBB, i, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockFlower(int i, int j)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - protected boolean canThisPlantGrowOnThisBlockID(int i)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - protected final void func_268_h(World world, int i, int j, int k)
 * - public boolean canBlockStay(World world, int i, int j, int k)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public int getRenderType()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockFlower_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockFlower_JavaName(void)
{
    return "net.minecraft.src.BlockFlower";
}

const char *CloneMCJ_BlockFlower_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockFlower_JavaSourceHash32(void)
{
    return 0x0853790EUL;
}
