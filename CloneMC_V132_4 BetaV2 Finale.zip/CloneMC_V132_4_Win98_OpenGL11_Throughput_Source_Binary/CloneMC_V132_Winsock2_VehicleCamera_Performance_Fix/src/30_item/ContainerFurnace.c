/*
 * Direct C89 port of ContainerFurnace.java.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ContainerFurnace_InitializeNative(CloneMCJ_Container *container,
    CloneMCJ_InventoryPlayer *inventory, CloneMCJ_TileEntity *tile)
{
    int row;
    int column;
    int index;
    if (!container || !inventory || !tile ||
        tile->type != CLONEMC_J_TILE_FURNACE) return;
    CloneMCJ_Container_Initialize(container);
    container->type = CLONEMC_J_CONTAINER_FURNACE;
    container->playerInventory = inventory;
    container->tileEntity = tile;
    container->tileSlotStart = container->slotCount;
    CloneMCJ_Container_AddTypedSlot(container, &tile->items[0], 64,
        CLONEMC_J_SLOT_FURNACE_INPUT, -1, 0, 56, 17);
    CloneMCJ_Container_AddTypedSlot(container, &tile->items[1], 64,
        CLONEMC_J_SLOT_FURNACE_FUEL, -1, 1, 56, 53);
    CloneMCJ_Container_AddTypedSlot(container, &tile->items[2], 64,
        CLONEMC_J_SLOT_FURNACE_OUTPUT, -1, 2, 116, 35);
    container->tileSlotEnd = container->slotCount - 1;
    container->playerSlotStart = container->slotCount;
    for (row = 0; row < 3; ++row)
        for (column = 0; column < 9; ++column) {
            index = column + (row + 1) * 9;
            CloneMCJ_Container_AddTypedSlot(container,
                &inventory->mainInventory[index], 64, CLONEMC_J_SLOT_NORMAL,
                -1, index, 8 + column * 18, 84 + row * 18);
        }
    container->hotbarSlotStart = container->slotCount;
    for (column = 0; column < 9; ++column)
        CloneMCJ_Container_AddTypedSlot(container,
            &inventory->mainInventory[column], 64, CLONEMC_J_SLOT_NORMAL,
            -1, column, 8 + column * 18, 142);
    container->hotbarSlotEnd = container->slotCount - 1;
    container->playerSlotEnd = container->hotbarSlotEnd;
}

void CloneMCJ_ContainerFurnace_Register(void) { }
const char *CloneMCJ_ContainerFurnace_JavaName(void)
{ return "net.minecraft.src.ContainerFurnace"; }
const char *CloneMCJ_ContainerFurnace_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_ContainerFurnace_JavaSourceHash32(void)
{ return 0x26EF1423UL; }
