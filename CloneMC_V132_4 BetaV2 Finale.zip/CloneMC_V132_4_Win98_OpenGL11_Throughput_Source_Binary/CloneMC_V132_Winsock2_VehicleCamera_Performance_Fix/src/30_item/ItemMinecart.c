/*
 * CloneMC Java port scaffold: ItemMinecart
 *
 * Java source: ItemMinecart.java
 * Java type: class ItemMinecart
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: d1e6be163f38c154660808aefd33e5b5daf94ab00d8133cd6d04da22756d6636
 * Java lines: 41
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, World, BlockRail, EntityMinecart, ItemStack, EntityPlayer, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int minecartType
 *
 * Java method/constructor inventory:
 * - public ItemMinecart(int i, int j)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemMinecart_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemMinecart_JavaName(void)
{
    return "net.minecraft.src.ItemMinecart";
}

const char *CloneMCJ_ItemMinecart_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemMinecart_JavaSourceHash32(void)
{
    return 0xD1E6BE16UL;
}
