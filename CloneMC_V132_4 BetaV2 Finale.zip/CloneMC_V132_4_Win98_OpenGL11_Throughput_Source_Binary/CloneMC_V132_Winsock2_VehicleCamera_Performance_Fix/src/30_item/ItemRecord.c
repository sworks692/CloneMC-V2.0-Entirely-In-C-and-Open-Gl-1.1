/*
 * CloneMC Java port scaffold: ItemRecord
 *
 * Java source: ItemRecord.java
 * Java type: class ItemRecord
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: eacbdbb1b406d4d750a3f0a08b45f5b95ae60b8e991df0e5c63968bef79027a2
 * Java lines: 44
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, World, Block, BlockJukeBox, ItemStack, EntityPlayer, j, i, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final String recordName
 *
 * Java method/constructor inventory:
 * - protected ItemRecord(int i, String s)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemRecord_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemRecord_JavaName(void)
{
    return "net.minecraft.src.ItemRecord";
}

const char *CloneMCJ_ItemRecord_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemRecord_JavaSourceHash32(void)
{
    return 0xEACBDBB1UL;
}
