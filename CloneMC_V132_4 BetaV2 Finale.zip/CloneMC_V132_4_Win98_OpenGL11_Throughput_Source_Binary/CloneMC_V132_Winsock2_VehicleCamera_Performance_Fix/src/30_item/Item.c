/*
 * CloneMC Java port scaffold: Item
 *
 * Java source: Item.java
 * Java type: class Item
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: dfe753be3e0d2c4ca02f1b06e1823241528b03c93d2eede1dd5826832dc91982
 * Java lines: 373
 * Discovered declared fields: 44
 * Discovered declared methods/constructors: 106
 * Referenced Java classes: ItemStack, StatCollector, ItemSpade, EnumToolMaterial, ItemPickaxe, ItemAxe, ItemFlintAndSteel, ItemFood, ItemBow, ItemCoal, ItemSword, ItemSoup, ItemHoe, ItemSeeds, Block, ItemArmor, ItemPainting, ItemSign, ItemDoor, Material, ItemBucket, ItemMinecart, ItemSaddle, ItemRedstone, ItemSnowball, ItemBoat, ItemReed, ItemEgg, ItemFishingRod, ItemDye, ItemBed, ItemCookie, ItemMap, ItemShears, ItemRecord, StatList, EntityPlayer, World, EntityLiving, Entity
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static Item itemsList[] = new Item[32000]
 * - public static Item shovelSteel
 * - public static Item pickaxeSteel
 * - public static Item axeSteel
 * - public static Item swordSteel
 * - public static Item swordWood
 * - public static Item shovelWood
 * - public static Item pickaxeWood
 * - public static Item axeWood
 * - public static Item swordStone
 * - public static Item shovelStone
 * - public static Item pickaxeStone
 * - public static Item axeStone
 * - public static Item swordDiamond
 * - public static Item shovelDiamond
 * - public static Item pickaxeDiamond
 * - public static Item axeDiamond
 * - public static Item swordGold
 * - public static Item shovelGold
 * - public static Item pickaxeGold
 * - public static Item axeGold
 * - public static Item hoeWood
 * - public static Item hoeStone
 * - public static Item hoeSteel
 * - public static Item hoeDiamond
 * - public static Item hoeGold
 * - public static Item seeds
 * - public static Item doorWood
 * - public static Item bucketEmpty
 * - public static Item bucketWater
 * - public static Item bucketLava
 * - public static Item doorSteel
 * - public static Item bucketMilk
 * - public static Item reed
 * - public static Item cake
 * - public static Item redstoneRepeater
 * - public final int shiftedIndex
 * - protected int maxStackSize
 * - private int maxDamage
 * - protected int iconIndex
 * - protected boolean bFull3D
 * - protected boolean hasSubtypes
 * - private Item containerItem
 * - private String itemName
 *
 * Java method/constructor inventory:
 * - protected Item(int i)
 * - public Item setIconIndex(int i)
 * - public Item setMaxStackSize(int i)
 * - public Item setIconCoord(int i, int j)
 * - public int getIconFromDamage(int i)
 * - public final int getIconIndex(ItemStack itemstack)
 * - public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
 * - public float getStrVsBlock(ItemStack itemstack, Block block)
 * - public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
 * - public int getItemStackLimit()
 * - public int getPlacedBlockMetadata(int i)
 * - public boolean getHasSubtypes()
 * - protected Item setHasSubtypes(boolean flag)
 * - public int getMaxDamage()
 * - protected Item setMaxDamage(int i)
 * - public boolean isDamagable()
 * - public boolean hitEntity(ItemStack itemstack, EntityLiving entityliving, EntityLiving entityliving1)
 * - public boolean onBlockDestroyed(ItemStack itemstack, int i, int j, int k, int l, EntityLiving entityliving)
 * - public int getDamageVsEntity(Entity entity)
 * - public boolean canHarvestBlock(Block block)
 * - public void saddleEntity(ItemStack itemstack, EntityLiving entityliving)
 * - public Item setFull3D()
 * - public boolean isFull3D()
 * - public boolean shouldRotateAroundWhenRendering()
 * - public Item setItemName(String s)
 * - public String getItemName()
 * - public String getItemNameIS(ItemStack itemstack)
 * - public Item setContainerItem(Item item)
 * - public Item getContainerItem()
 * - public boolean hasContainerItem()
 * - public String getStatName()
 * - public int getColorFromDamage(int i)
 * - public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
 * - public void onCreated(ItemStack itemstack, World world, EntityPlayer entityplayer)
 * - protected static Random itemRand = new Random()
 * - public static Item flintAndSteel = (new ItemFlintAndSteel(3)).setIconCoord(5, 0).setItemName("flintAndSteel")
 * - public static Item appleRed = (new ItemFood(4, 4, false)).setIconCoord(10, 0).setItemName("apple")
 * - public static Item bow = (new ItemBow(5)).setIconCoord(5, 1).setItemName("bow")
 * - public static Item arrow = (new Item(6)).setIconCoord(5, 2).setItemName("arrow")
 * - public static Item coal = (new ItemCoal(7)).setIconCoord(7, 0).setItemName("coal")
 * - public static Item diamond = (new Item(8)).setIconCoord(7, 3).setItemName("emerald")
 * - public static Item ingotIron = (new Item(9)).setIconCoord(7, 1).setItemName("ingotIron")
 * - public static Item ingotGold = (new Item(10)).setIconCoord(7, 2).setItemName("ingotGold")
 * - public static Item stick = (new Item(24)).setIconCoord(5, 3).setFull3D().setItemName("stick")
 * - public static Item bowlEmpty = (new Item(25)).setIconCoord(7, 4).setItemName("bowl")
 * - public static Item bowlSoup = (new ItemSoup(26, 10)).setIconCoord(8, 4).setItemName("mushroomStew")
 * - public static Item silk = (new Item(31)).setIconCoord(8, 0).setItemName("string")
 * - public static Item feather = (new Item(32)).setIconCoord(8, 1).setItemName("feather")
 * - public static Item gunpowder = (new Item(33)).setIconCoord(8, 2).setItemName("sulphur")
 * - public static Item wheat = (new Item(40)).setIconCoord(9, 1).setItemName("wheat")
 * - public static Item bread = (new ItemFood(41, 5, false)).setIconCoord(9, 2).setItemName("bread")
 * - public static Item helmetLeather = (new ItemArmor(42, 0, 0, 0)).setIconCoord(0, 0).setItemName("helmetCloth")
 * - public static Item plateLeather = (new ItemArmor(43, 0, 0, 1)).setIconCoord(0, 1).setItemName("chestplateCloth")
 * - public static Item legsLeather = (new ItemArmor(44, 0, 0, 2)).setIconCoord(0, 2).setItemName("leggingsCloth")
 * - public static Item bootsLeather = (new ItemArmor(45, 0, 0, 3)).setIconCoord(0, 3).setItemName("bootsCloth")
 * - public static Item helmetChain = (new ItemArmor(46, 1, 1, 0)).setIconCoord(1, 0).setItemName("helmetChain")
 * - public static Item plateChain = (new ItemArmor(47, 1, 1, 1)).setIconCoord(1, 1).setItemName("chestplateChain")
 * - public static Item legsChain = (new ItemArmor(48, 1, 1, 2)).setIconCoord(1, 2).setItemName("leggingsChain")
 * - public static Item bootsChain = (new ItemArmor(49, 1, 1, 3)).setIconCoord(1, 3).setItemName("bootsChain")
 * - public static Item helmetSteel = (new ItemArmor(50, 2, 2, 0)).setIconCoord(2, 0).setItemName("helmetIron")
 * - public static Item plateSteel = (new ItemArmor(51, 2, 2, 1)).setIconCoord(2, 1).setItemName("chestplateIron")
 * - public static Item legsSteel = (new ItemArmor(52, 2, 2, 2)).setIconCoord(2, 2).setItemName("leggingsIron")
 * - public static Item bootsSteel = (new ItemArmor(53, 2, 2, 3)).setIconCoord(2, 3).setItemName("bootsIron")
 * - public static Item helmetDiamond = (new ItemArmor(54, 3, 3, 0)).setIconCoord(3, 0).setItemName("helmetDiamond")
 * - public static Item plateDiamond = (new ItemArmor(55, 3, 3, 1)).setIconCoord(3, 1).setItemName("chestplateDiamond")
 * - public static Item legsDiamond = (new ItemArmor(56, 3, 3, 2)).setIconCoord(3, 2).setItemName("leggingsDiamond")
 * - public static Item bootsDiamond = (new ItemArmor(57, 3, 3, 3)).setIconCoord(3, 3).setItemName("bootsDiamond")
 * - public static Item helmetGold = (new ItemArmor(58, 1, 4, 0)).setIconCoord(4, 0).setItemName("helmetGold")
 * - public static Item plateGold = (new ItemArmor(59, 1, 4, 1)).setIconCoord(4, 1).setItemName("chestplateGold")
 * - public static Item legsGold = (new ItemArmor(60, 1, 4, 2)).setIconCoord(4, 2).setItemName("leggingsGold")
 * - public static Item bootsGold = (new ItemArmor(61, 1, 4, 3)).setIconCoord(4, 3).setItemName("bootsGold")
 * - public static Item flint = (new Item(62)).setIconCoord(6, 0).setItemName("flint")
 * - public static Item porkRaw = (new ItemFood(63, 3, true)).setIconCoord(7, 5).setItemName("porkchopRaw")
 * - public static Item porkCooked = (new ItemFood(64, 8, true)).setIconCoord(8, 5).setItemName("porkchopCooked")
 * - public static Item painting = (new ItemPainting(65)).setIconCoord(10, 1).setItemName("painting")
 * - public static Item appleGold = (new ItemFood(66, 42, false)).setIconCoord(11, 0).setItemName("appleGold")
 * - public static Item sign = (new ItemSign(67)).setIconCoord(10, 2).setItemName("sign")
 * - public static Item minecartEmpty = (new ItemMinecart(72, 0)).setIconCoord(7, 8).setItemName("minecart")
 * - public static Item saddle = (new ItemSaddle(73)).setIconCoord(8, 6).setItemName("saddle")
 * - public static Item redstone = (new ItemRedstone(75)).setIconCoord(8, 3).setItemName("redstone")
 * - public static Item snowball = (new ItemSnowball(76)).setIconCoord(14, 0).setItemName("snowball")
 * - public static Item boat = (new ItemBoat(77)).setIconCoord(8, 8).setItemName("boat")
 * - public static Item leather = (new Item(78)).setIconCoord(7, 6).setItemName("leather")
 * - public static Item brick = (new Item(80)).setIconCoord(6, 1).setItemName("brick")
 * - public static Item clay = (new Item(81)).setIconCoord(9, 3).setItemName("clay")
 * - public static Item paper = (new Item(83)).setIconCoord(10, 3).setItemName("paper")
 * - public static Item book = (new Item(84)).setIconCoord(11, 3).setItemName("book")
 * - public static Item slimeBall = (new Item(85)).setIconCoord(14, 1).setItemName("slimeball")
 * - public static Item minecartCrate = (new ItemMinecart(86, 1)).setIconCoord(7, 9).setItemName("minecartChest")
 * - public static Item minecartPowered = (new ItemMinecart(87, 2)).setIconCoord(7, 10).setItemName("minecartFurnace")
 * - public static Item egg = (new ItemEgg(88)).setIconCoord(12, 0).setItemName("egg")
 * - public static Item compass = (new Item(89)).setIconCoord(6, 3).setItemName("compass")
 * - public static Item fishingRod = (new ItemFishingRod(90)).setIconCoord(5, 4).setItemName("fishingRod")
 * - public static Item pocketSundial = (new Item(91)).setIconCoord(6, 4).setItemName("clock")
 * - public static Item lightStoneDust = (new Item(92)).setIconCoord(9, 4).setItemName("yellowDust")
 * - public static Item fishRaw = (new ItemFood(93, 2, false)).setIconCoord(9, 5).setItemName("fishRaw")
 * - public static Item fishCooked = (new ItemFood(94, 5, false)).setIconCoord(10, 5).setItemName("fishCooked")
 * - public static Item dyePowder = (new ItemDye(95)).setIconCoord(14, 4).setItemName("dyePowder")
 * - public static Item bone = (new Item(96)).setIconCoord(12, 1).setItemName("bone").setFull3D()
 * - public static Item sugar = (new Item(97)).setIconCoord(13, 0).setItemName("sugar").setFull3D()
 * - public static Item bed = (new ItemBed(99)).setMaxStackSize(1).setIconCoord(13, 2).setItemName("bed")
 * - public static Item cookie = (new ItemCookie(101, 1, false, 8)).setIconCoord(12, 5).setItemName("cookie")
 * - public static ItemMap mapItem = (ItemMap)(new ItemMap(102)).setIconCoord(12, 3).setItemName("map")
 * - public static ItemShears shears = (ItemShears)(new ItemShears(103)).setIconCoord(13, 5).setItemName("shears")
 * - public static Item record13 = (new ItemRecord(2000, "13")).setIconCoord(0, 15).setItemName("record")
 * - public static Item recordCat = (new ItemRecord(2001, "cat")).setIconCoord(1, 15).setItemName("record")
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_30_item.h"
#include <string.h>

void CloneMCJ_Item_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Item_JavaName(void)
{
    return "net.minecraft.src.Item";
}

const char *CloneMCJ_Item_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_Item_JavaSourceHash32(void)
{
    return 0xDFE753BEUL;
}

static CloneMCJ_ItemDefinition g_cloneMCItemRegistry[CLONEMC_J_ITEM_REGISTRY_SIZE];
static int g_cloneMCItemRegistryInitialized = 0;

static void CloneMCJ_Item_Set(int id,const char *name,int maxStack,int maxDamage,int damage,
    float efficiency,int tool,int level,int placeBlock)
{
    CloneMCJ_ItemDefinition *item;if(id<0||id>=CLONEMC_J_ITEM_REGISTRY_SIZE)return;
    item=&g_cloneMCItemRegistry[id];item->itemID=id;item->name=name;item->maxStackSize=maxStack;
    item->maxDamage=maxDamage;item->damageVsEntity=damage;item->efficiency=efficiency;
    item->toolClass=(unsigned char)tool;item->harvestLevel=(unsigned char)level;item->placeBlockID=placeBlock;
}

static void CloneMCJ_Item_SetToolSet(int sword,int shovel,int pick,int axe,int hoe,int maxDamage,
    int level,float efficiency,int swordDamage,const char *prefix)
{
    CloneMCJ_Item_Set(sword,prefix,1,maxDamage,swordDamage,1.5F,CLONEMC_J_TOOL_SWORD,level,0);
    CloneMCJ_Item_Set(shovel,prefix,1,maxDamage,2,efficiency,CLONEMC_J_TOOL_SHOVEL,level,0);
    CloneMCJ_Item_Set(pick,prefix,1,maxDamage,2,efficiency,CLONEMC_J_TOOL_PICKAXE,level,0);
    CloneMCJ_Item_Set(axe,prefix,1,maxDamage,3,efficiency,CLONEMC_J_TOOL_AXE,level,0);
    if(hoe>0)CloneMCJ_Item_Set(hoe,prefix,1,maxDamage,1,1.0F,CLONEMC_J_TOOL_HOE,level,0);
}

static void CloneMCJ_Item_SetFood(int id,const char *name,int healAmount,int wolfMeat)
{
    CloneMCJ_Item_Set(id,name,1,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    g_cloneMCItemRegistry[id].healAmount=healAmount;
    g_cloneMCItemRegistry[id].wolfsFavoriteMeat=(unsigned char)(wolfMeat?1:0);
}

void CloneMCJ_ItemRegistry_Initialize(void)
{
    int id;if(g_cloneMCItemRegistryInitialized)return;memset(g_cloneMCItemRegistry,0,sizeof(g_cloneMCItemRegistry));
    for(id=0;id<CLONEMC_J_BLOCK_REGISTRY_SIZE;++id)CloneMCJ_Item_Set(id,"tile",64,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,id);
    for(id=256;id<CLONEMC_J_ITEM_REGISTRY_SIZE;++id)CloneMCJ_Item_Set(id,"item",64,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    for(id=0;id<CLONEMC_J_BLOCK_REGISTRY_SIZE;++id)
        g_cloneMCItemRegistry[id].iconIndex=-1;
    for(id=256;id<CLONEMC_J_ITEM_REGISTRY_SIZE;++id)
        g_cloneMCItemRegistry[id].iconIndex=(id-256)&255;
    CloneMCJ_Item_SetToolSet(267,256,257,258,292,250,2,6.0F,6,"item.swordIron");
    CloneMCJ_Item_SetToolSet(268,269,270,271,290,59,0,2.0F,4,"item.swordWood");
    CloneMCJ_Item_SetToolSet(272,273,274,275,291,131,1,4.0F,5,"item.swordStone");
    CloneMCJ_Item_SetToolSet(276,277,278,279,293,1561,3,8.0F,7,"item.swordDiamond");
    CloneMCJ_Item_SetToolSet(283,284,285,286,294,32,0,12.0F,4,"item.swordGold");
    CloneMCJ_Item_Set(259,"item.flintAndSteel",1,64,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_SetFood(260,"item.apple",4,0);
    CloneMCJ_Item_Set(261,"item.bow",1,384,2,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_SetFood(282,"item.mushroomStew",10,0);
    CloneMCJ_Item_SetFood(297,"item.bread",5,0);
    CloneMCJ_Item_SetFood(319,"item.porkchopRaw",3,1);
    CloneMCJ_Item_SetFood(320,"item.porkchopCooked",8,1);
    CloneMCJ_Item_SetFood(322,"item.appleGold",42,0);
    CloneMCJ_Item_Set(325,"item.bucket",1,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_Set(326,"item.bucketWater",1,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_Set(327,"item.bucketLava",1,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_Set(328,"item.minecart",1,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_Set(329,"item.saddle",1,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_Set(333,"item.boat",1,0,1,1.0F,CLONEMC_J_TOOL_NONE,0,0);
    CloneMCJ_Item_SetFood(349,"item.fishRaw",2,0);
    CloneMCJ_Item_SetFood(350,"item.fishCooked",5,0);
    CloneMCJ_Item_SetFood(357,"item.cookie",1,0);
    CloneMCJ_Item_Set(359,"item.shears",1,238,2,15.0F,CLONEMC_J_TOOL_SHEARS,0,0);
    /* Exact Java Item.setItemName values.  Tool behavior is configured above;
     * labels are assigned independently so every inventory stack localizes. */
    g_cloneMCItemRegistry[256].name="item.shovelIron";
    g_cloneMCItemRegistry[257].name="item.pickaxeIron";
    g_cloneMCItemRegistry[258].name="item.hatchetIron";
    g_cloneMCItemRegistry[259].name="item.flintAndSteel";
    g_cloneMCItemRegistry[260].name="item.apple";
    g_cloneMCItemRegistry[261].name="item.bow";
    g_cloneMCItemRegistry[262].name="item.arrow";
    g_cloneMCItemRegistry[263].name="item.coal";
    g_cloneMCItemRegistry[264].name="item.emerald";
    g_cloneMCItemRegistry[265].name="item.ingotIron";
    g_cloneMCItemRegistry[266].name="item.ingotGold";
    g_cloneMCItemRegistry[267].name="item.swordIron";
    g_cloneMCItemRegistry[268].name="item.swordWood";
    g_cloneMCItemRegistry[269].name="item.shovelWood";
    g_cloneMCItemRegistry[270].name="item.pickaxeWood";
    g_cloneMCItemRegistry[271].name="item.hatchetWood";
    g_cloneMCItemRegistry[272].name="item.swordStone";
    g_cloneMCItemRegistry[273].name="item.shovelStone";
    g_cloneMCItemRegistry[274].name="item.pickaxeStone";
    g_cloneMCItemRegistry[275].name="item.hatchetStone";
    g_cloneMCItemRegistry[276].name="item.swordDiamond";
    g_cloneMCItemRegistry[277].name="item.shovelDiamond";
    g_cloneMCItemRegistry[278].name="item.pickaxeDiamond";
    g_cloneMCItemRegistry[279].name="item.hatchetDiamond";
    g_cloneMCItemRegistry[280].name="item.stick";
    g_cloneMCItemRegistry[281].name="item.bowl";
    g_cloneMCItemRegistry[282].name="item.mushroomStew";
    g_cloneMCItemRegistry[283].name="item.swordGold";
    g_cloneMCItemRegistry[284].name="item.shovelGold";
    g_cloneMCItemRegistry[285].name="item.pickaxeGold";
    g_cloneMCItemRegistry[286].name="item.hatchetGold";
    g_cloneMCItemRegistry[287].name="item.string";
    g_cloneMCItemRegistry[288].name="item.feather";
    g_cloneMCItemRegistry[289].name="item.sulphur";
    g_cloneMCItemRegistry[290].name="item.hoeWood";
    g_cloneMCItemRegistry[291].name="item.hoeStone";
    g_cloneMCItemRegistry[292].name="item.hoeIron";
    g_cloneMCItemRegistry[293].name="item.hoeDiamond";
    g_cloneMCItemRegistry[294].name="item.hoeGold";
    g_cloneMCItemRegistry[295].name="item.seeds";
    g_cloneMCItemRegistry[296].name="item.wheat";
    g_cloneMCItemRegistry[297].name="item.bread";
    g_cloneMCItemRegistry[298].name="item.helmetCloth";
    g_cloneMCItemRegistry[299].name="item.chestplateCloth";
    g_cloneMCItemRegistry[300].name="item.leggingsCloth";
    g_cloneMCItemRegistry[301].name="item.bootsCloth";
    g_cloneMCItemRegistry[302].name="item.helmetChain";
    g_cloneMCItemRegistry[303].name="item.chestplateChain";
    g_cloneMCItemRegistry[304].name="item.leggingsChain";
    g_cloneMCItemRegistry[305].name="item.bootsChain";
    g_cloneMCItemRegistry[306].name="item.helmetIron";
    g_cloneMCItemRegistry[307].name="item.chestplateIron";
    g_cloneMCItemRegistry[308].name="item.leggingsIron";
    g_cloneMCItemRegistry[309].name="item.bootsIron";
    g_cloneMCItemRegistry[310].name="item.helmetDiamond";
    g_cloneMCItemRegistry[311].name="item.chestplateDiamond";
    g_cloneMCItemRegistry[312].name="item.leggingsDiamond";
    g_cloneMCItemRegistry[313].name="item.bootsDiamond";
    g_cloneMCItemRegistry[314].name="item.helmetGold";
    g_cloneMCItemRegistry[315].name="item.chestplateGold";
    g_cloneMCItemRegistry[316].name="item.leggingsGold";
    g_cloneMCItemRegistry[317].name="item.bootsGold";
    g_cloneMCItemRegistry[318].name="item.flint";
    g_cloneMCItemRegistry[319].name="item.porkchopRaw";
    g_cloneMCItemRegistry[320].name="item.porkchopCooked";
    g_cloneMCItemRegistry[321].name="item.painting";
    g_cloneMCItemRegistry[322].name="item.appleGold";
    g_cloneMCItemRegistry[323].name="item.sign";
    g_cloneMCItemRegistry[324].name="item.doorWood";
    g_cloneMCItemRegistry[325].name="item.bucket";
    g_cloneMCItemRegistry[326].name="item.bucketWater";
    g_cloneMCItemRegistry[327].name="item.bucketLava";
    g_cloneMCItemRegistry[328].name="item.minecart";
    g_cloneMCItemRegistry[329].name="item.saddle";
    g_cloneMCItemRegistry[330].name="item.doorIron";
    g_cloneMCItemRegistry[331].name="item.redstone";
    g_cloneMCItemRegistry[332].name="item.snowball";
    g_cloneMCItemRegistry[333].name="item.boat";
    g_cloneMCItemRegistry[334].name="item.leather";
    g_cloneMCItemRegistry[335].name="item.milk";
    g_cloneMCItemRegistry[336].name="item.brick";
    g_cloneMCItemRegistry[337].name="item.clay";
    g_cloneMCItemRegistry[338].name="item.reeds";
    g_cloneMCItemRegistry[339].name="item.paper";
    g_cloneMCItemRegistry[340].name="item.book";
    g_cloneMCItemRegistry[341].name="item.slimeball";
    g_cloneMCItemRegistry[342].name="item.minecartChest";
    g_cloneMCItemRegistry[343].name="item.minecartFurnace";
    g_cloneMCItemRegistry[344].name="item.egg";
    g_cloneMCItemRegistry[345].name="item.compass";
    g_cloneMCItemRegistry[346].name="item.fishingRod";
    g_cloneMCItemRegistry[347].name="item.clock";
    g_cloneMCItemRegistry[348].name="item.yellowDust";
    g_cloneMCItemRegistry[349].name="item.fishRaw";
    g_cloneMCItemRegistry[350].name="item.fishCooked";
    g_cloneMCItemRegistry[351].name="item.dyePowder";
    g_cloneMCItemRegistry[352].name="item.bone";
    g_cloneMCItemRegistry[353].name="item.sugar";
    g_cloneMCItemRegistry[354].name="item.cake";
    g_cloneMCItemRegistry[355].name="item.bed";
    g_cloneMCItemRegistry[356].name="item.diode";
    g_cloneMCItemRegistry[357].name="item.cookie";
    g_cloneMCItemRegistry[358].name="item.map";
    g_cloneMCItemRegistry[359].name="item.shears";
    g_cloneMCItemRegistry[2256].name="item.record";
    g_cloneMCItemRegistry[2257].name="item.record";
    /* Item.java setIconCoord values; item IDs are not atlas indexes. */
    g_cloneMCItemRegistry[256].iconIndex=82;
    g_cloneMCItemRegistry[257].iconIndex=98;
    g_cloneMCItemRegistry[258].iconIndex=114;
    g_cloneMCItemRegistry[259].iconIndex=5;
    g_cloneMCItemRegistry[260].iconIndex=10;
    g_cloneMCItemRegistry[261].iconIndex=21;
    g_cloneMCItemRegistry[262].iconIndex=37;
    g_cloneMCItemRegistry[263].iconIndex=7;
    g_cloneMCItemRegistry[264].iconIndex=55;
    g_cloneMCItemRegistry[265].iconIndex=23;
    g_cloneMCItemRegistry[266].iconIndex=39;
    g_cloneMCItemRegistry[267].iconIndex=66;
    g_cloneMCItemRegistry[268].iconIndex=64;
    g_cloneMCItemRegistry[269].iconIndex=80;
    g_cloneMCItemRegistry[270].iconIndex=96;
    g_cloneMCItemRegistry[271].iconIndex=112;
    g_cloneMCItemRegistry[272].iconIndex=65;
    g_cloneMCItemRegistry[273].iconIndex=81;
    g_cloneMCItemRegistry[274].iconIndex=97;
    g_cloneMCItemRegistry[275].iconIndex=113;
    g_cloneMCItemRegistry[276].iconIndex=67;
    g_cloneMCItemRegistry[277].iconIndex=83;
    g_cloneMCItemRegistry[278].iconIndex=99;
    g_cloneMCItemRegistry[279].iconIndex=115;
    g_cloneMCItemRegistry[280].iconIndex=53;
    g_cloneMCItemRegistry[281].iconIndex=71;
    g_cloneMCItemRegistry[282].iconIndex=72;
    g_cloneMCItemRegistry[283].iconIndex=68;
    g_cloneMCItemRegistry[284].iconIndex=84;
    g_cloneMCItemRegistry[285].iconIndex=100;
    g_cloneMCItemRegistry[286].iconIndex=116;
    g_cloneMCItemRegistry[287].iconIndex=8;
    g_cloneMCItemRegistry[288].iconIndex=24;
    g_cloneMCItemRegistry[289].iconIndex=40;
    g_cloneMCItemRegistry[290].iconIndex=128;
    g_cloneMCItemRegistry[291].iconIndex=129;
    g_cloneMCItemRegistry[292].iconIndex=130;
    g_cloneMCItemRegistry[293].iconIndex=131;
    g_cloneMCItemRegistry[294].iconIndex=132;
    g_cloneMCItemRegistry[295].iconIndex=9;
    g_cloneMCItemRegistry[296].iconIndex=25;
    g_cloneMCItemRegistry[297].iconIndex=41;
    g_cloneMCItemRegistry[298].iconIndex=0;
    g_cloneMCItemRegistry[299].iconIndex=16;
    g_cloneMCItemRegistry[300].iconIndex=32;
    g_cloneMCItemRegistry[301].iconIndex=48;
    g_cloneMCItemRegistry[302].iconIndex=1;
    g_cloneMCItemRegistry[303].iconIndex=17;
    g_cloneMCItemRegistry[304].iconIndex=33;
    g_cloneMCItemRegistry[305].iconIndex=49;
    g_cloneMCItemRegistry[306].iconIndex=2;
    g_cloneMCItemRegistry[307].iconIndex=18;
    g_cloneMCItemRegistry[308].iconIndex=34;
    g_cloneMCItemRegistry[309].iconIndex=50;
    g_cloneMCItemRegistry[310].iconIndex=3;
    g_cloneMCItemRegistry[311].iconIndex=19;
    g_cloneMCItemRegistry[312].iconIndex=35;
    g_cloneMCItemRegistry[313].iconIndex=51;
    g_cloneMCItemRegistry[314].iconIndex=4;
    g_cloneMCItemRegistry[315].iconIndex=20;
    g_cloneMCItemRegistry[316].iconIndex=36;
    g_cloneMCItemRegistry[317].iconIndex=52;
    g_cloneMCItemRegistry[318].iconIndex=6;
    g_cloneMCItemRegistry[319].iconIndex=87;
    g_cloneMCItemRegistry[320].iconIndex=88;
    g_cloneMCItemRegistry[321].iconIndex=26;
    g_cloneMCItemRegistry[322].iconIndex=11;
    g_cloneMCItemRegistry[323].iconIndex=42;
    g_cloneMCItemRegistry[324].iconIndex=43;
    g_cloneMCItemRegistry[325].iconIndex=74;
    g_cloneMCItemRegistry[326].iconIndex=75;
    g_cloneMCItemRegistry[327].iconIndex=76;
    g_cloneMCItemRegistry[328].iconIndex=135;
    g_cloneMCItemRegistry[329].iconIndex=104;
    g_cloneMCItemRegistry[330].iconIndex=44;
    g_cloneMCItemRegistry[331].iconIndex=56;
    g_cloneMCItemRegistry[332].iconIndex=14;
    g_cloneMCItemRegistry[333].iconIndex=136;
    g_cloneMCItemRegistry[334].iconIndex=103;
    g_cloneMCItemRegistry[335].iconIndex=77;
    g_cloneMCItemRegistry[336].iconIndex=22;
    g_cloneMCItemRegistry[337].iconIndex=57;
    g_cloneMCItemRegistry[338].iconIndex=27;
    g_cloneMCItemRegistry[339].iconIndex=58;
    g_cloneMCItemRegistry[340].iconIndex=59;
    g_cloneMCItemRegistry[341].iconIndex=30;
    g_cloneMCItemRegistry[342].iconIndex=151;
    g_cloneMCItemRegistry[343].iconIndex=167;
    g_cloneMCItemRegistry[344].iconIndex=12;
    g_cloneMCItemRegistry[345].iconIndex=54;
    g_cloneMCItemRegistry[346].iconIndex=69;
    g_cloneMCItemRegistry[347].iconIndex=70;
    g_cloneMCItemRegistry[348].iconIndex=73;
    g_cloneMCItemRegistry[349].iconIndex=89;
    g_cloneMCItemRegistry[350].iconIndex=90;
    g_cloneMCItemRegistry[351].iconIndex=78;
    g_cloneMCItemRegistry[352].iconIndex=28;
    g_cloneMCItemRegistry[353].iconIndex=13;
    g_cloneMCItemRegistry[354].iconIndex=29;
    g_cloneMCItemRegistry[355].iconIndex=45;
    g_cloneMCItemRegistry[356].iconIndex=86;
    g_cloneMCItemRegistry[357].iconIndex=92;
    g_cloneMCItemRegistry[358].iconIndex=60;
    g_cloneMCItemRegistry[359].iconIndex=93;
    g_cloneMCItemRegistry[2256].iconIndex=240;
    g_cloneMCItemRegistry[2257].iconIndex=241;
    g_cloneMCItemRegistry[263].hasSubtypes=1;
    g_cloneMCItemRegistry[351].hasSubtypes=1;
    g_cloneMCItemRegistry[323].placeBlockID=63;
    g_cloneMCItemRegistry[324].placeBlockID=64;
    g_cloneMCItemRegistry[330].placeBlockID=71;
    g_cloneMCItemRegistry[338].placeBlockID=83;
    g_cloneMCItemRegistry[354].placeBlockID=92;
    g_cloneMCItemRegistry[355].placeBlockID=26;
    g_cloneMCItemRegistry[356].placeBlockID=93;
    g_cloneMCItemRegistry[2256].maxStackSize=1;
    g_cloneMCItemRegistry[2257].maxStackSize=1;
    g_cloneMCItemRegistry[261].maxStackSize=1;
    g_cloneMCItemRegistry[323].maxStackSize=16;
    g_cloneMCItemRegistry[324].maxStackSize=1;
    g_cloneMCItemRegistry[330].maxStackSize=1;
    g_cloneMCItemRegistry[335].maxStackSize=1;
    g_cloneMCItemRegistry[342].maxStackSize=1;
    g_cloneMCItemRegistry[343].maxStackSize=1;
    g_cloneMCItemRegistry[346].maxStackSize=1;
    g_cloneMCItemRegistry[354].maxStackSize=1;
    g_cloneMCItemRegistry[355].maxStackSize=1;
    g_cloneMCItemRegistry[358].maxStackSize=1;
    for(id=298;id<=317;++id)g_cloneMCItemRegistry[id].maxStackSize=1;
    g_cloneMCItemRegistryInitialized=1;
}

const CloneMCJ_ItemDefinition *CloneMCJ_ItemRegistry_Get(int itemID)
{
    CloneMCJ_ItemRegistry_Initialize();if(itemID<0||itemID>=CLONEMC_J_ITEM_REGISTRY_SIZE)return 0;return &g_cloneMCItemRegistry[itemID];
}

int CloneMCJ_ItemRegistry_GetIconIndex(int itemID,int damage)
{
    const CloneMCJ_ItemDefinition *definition;
    CloneMCJ_ItemRegistry_Initialize();
    if(itemID<0||itemID>=CLONEMC_J_ITEM_REGISTRY_SIZE)return 0;
    if(itemID<256)return -1;
    definition=&g_cloneMCItemRegistry[itemID];
    if(itemID==351)return definition->iconIndex+(damage&7)*16+((damage>>3)&1);
    return definition->iconIndex>=0?definition->iconIndex:((itemID-256)&255);
}
