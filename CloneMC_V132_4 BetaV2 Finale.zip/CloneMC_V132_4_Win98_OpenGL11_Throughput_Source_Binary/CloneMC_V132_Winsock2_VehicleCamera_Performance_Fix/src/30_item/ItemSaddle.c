/*
 * CloneMC Java port scaffold: ItemSaddle
 *
 * Java source: ItemSaddle.java
 * Java type: class ItemSaddle
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: 450c3ec88aaa6da10ec318e5343b627f8a14ca8c723f042a67b75168e786612c
 * Java lines: 39
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Item, EntityPig, ItemStack, EntityLiving
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemSaddle(int i)
 * - public void saddleEntity(ItemStack itemstack, EntityLiving entityliving)
 * - public boolean hitEntity(ItemStack itemstack, EntityLiving entityliving, EntityLiving entityliving1)
 *
 * Direct conversion: saddleEntity/hitEntity now apply a saddle only to an
 * unsaddled pig and consume the one-item saddle stack.
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"

int CloneMCJ_ItemSaddle_UseOnMob(CloneMCJ_ItemStack *stack,CloneMCJ_Mob *mob)
{
    if(!stack||CloneMCJ_ItemStack_IsEmpty(stack)||stack->itemID!=329||!mob||
        mob->type!=CLONEMC_J_MOB_PIG||mob->saddled)return 0;
    mob->saddled=1;
    --stack->stackSize;
    if(stack->stackSize<=0)CloneMCJ_ItemStack_Clear(stack);
    return 1;
}

void CloneMCJ_ItemSaddle_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemSaddle_JavaName(void)
{
    return "net.minecraft.src.ItemSaddle";
}

const char *CloneMCJ_ItemSaddle_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemSaddle_JavaSourceHash32(void)
{
    return 0x450C3EC8UL;
}
