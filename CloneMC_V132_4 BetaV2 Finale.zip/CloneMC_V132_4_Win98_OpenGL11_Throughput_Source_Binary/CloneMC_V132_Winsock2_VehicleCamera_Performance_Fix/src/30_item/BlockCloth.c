/*
 * CloneMC Java port scaffold: BlockCloth
 *
 * Java source: BlockCloth.java
 * Java type: class BlockCloth
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: c09d83fe39513231cc1681c755221aa24c40b48ea7ebcc384ba1f1f2f0bdef5e
 * Java lines: 46
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: Block, Material
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockCloth()
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - protected int damageDropped(int i)
 * - public static int func_21034_c(int i)
 * - public static int func_21035_d(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

int CloneMCJ_BlockCloth_TextureNative(int metadata)
{
    int value;
    metadata&=15;
    if(metadata==0)return 64;
    value=~metadata;
    return 113+((value&8)>>3)+(value&7)*16;
}

int CloneMCJ_BlockCloth_DamageDroppedNative(int metadata)
{
    return metadata&15;
}

int CloneMCJ_BlockCloth_DyeToBlockMetadataNative(int dyeDamage)
{
    return (~dyeDamage)&15;
}

int CloneMCJ_BlockCloth_BlockMetadataToDyeNative(int metadata)
{
    return (~metadata)&15;
}

void CloneMCJ_BlockCloth_Register(void)
{
    /* BlockCloth.java behavior is provided by the helpers above. */
}

const char *CloneMCJ_BlockCloth_JavaName(void)
{
    return "net.minecraft.src.BlockCloth";
}

const char *CloneMCJ_BlockCloth_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockCloth_JavaSourceHash32(void)
{
    return 0xC09D83FEUL;
}
