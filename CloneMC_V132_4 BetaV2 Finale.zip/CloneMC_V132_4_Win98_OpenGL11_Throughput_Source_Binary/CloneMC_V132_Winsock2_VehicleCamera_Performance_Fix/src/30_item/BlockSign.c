/*
 * Direct C89 conversion of the uploaded Beta BlockSign.java support,
 * selection-shape and non-cubic registry behavior.
 *
 * Java source: BlockSign.java
 * Java type: class BlockSign
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockContainer
 * Implements: (none declared)
 * Source SHA-256: ca6e828534cd3b5511de55fa9bbe22f76217dcdff118e9a5b27261dd42175867
 * Java lines: 142
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 10
 * Referenced Java classes: BlockContainer, Material, IBlockAccess, TileEntity, Item, World, AxisAlignedBB, f1, i, j, f, f3, f2, f4
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Class signEntityClass
 * - private boolean isFreestanding
 *
 * Java method/constructor inventory:
 * - protected BlockSign(int i, Class class1, boolean flag)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k)
 * - public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int i, int j, int k)
 * - public int getRenderType()
 * - public boolean renderAsNormalBlock()
 * - public boolean isOpaqueCube()
 * - protected TileEntity getBlockEntity()
 * - public int idDropped(int i, Random random)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 *
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"

#define CLONEMC_J_SIGN_POST_ID 63
#define CLONEMC_J_SIGN_WALL_ID 68

static int CloneMCJ_BlockSign_HasSolidSupport(CloneMCJ_World *world,
    int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *support;
    int id;
    if(!world||y<0||y>=CLONEMC_J_CHUNK_HEIGHT)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    support=CloneMCJ_BlockRegistry_Get(id);
    return id!=0&&support&&support->solid;
}

int CloneMCJ_BlockSign_CanStayNative(CloneMCJ_World *world,int blockID,
    int x,int y,int z,int metadata)
{
    if(blockID==CLONEMC_J_SIGN_POST_ID)
        return CloneMCJ_BlockSign_HasSolidSupport(world,x,y-1,z);
    if(blockID!=CLONEMC_J_SIGN_WALL_ID)return 0;
    if(metadata==2)return CloneMCJ_BlockSign_HasSolidSupport(world,x,y,z+1);
    if(metadata==3)return CloneMCJ_BlockSign_HasSolidSupport(world,x,y,z-1);
    if(metadata==4)return CloneMCJ_BlockSign_HasSolidSupport(world,x+1,y,z);
    if(metadata==5)return CloneMCJ_BlockSign_HasSolidSupport(world,x-1,y,z);
    return 0;
}

static void CloneMCJ_BlockSign_Neighbor(CloneMCJ_World *world,
    int x,int y,int z,int neighborID)
{
    CloneMCJ_GameplayState *gameplay;
    CloneMCJ_ItemStack drop;
    int id,metadata;
    (void)neighborID;
    if(!world)return;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z);
    if(!CloneMCJ_BlockSign_CanStayNative(world,id,x,y,z,metadata)){
        /* BlockSign.onNeighborBlockChange drops Item.sign before clearing the
         * unsupported block.  A world-browser/self-test world may not own a
         * gameplay entity pool, in which case removal still remains safe. */
        gameplay=(CloneMCJ_GameplayState *)world->gameplayUserData;
        if(gameplay){
            CloneMCJ_ItemStack_Initialize(&drop,323,1,0);
            (void)CloneMCJ_Gameplay_SpawnDrop(gameplay,(double)x+0.5,
                (double)y+0.5,(double)z+0.5,&drop,10,0);
        }
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
    }
}

void CloneMCJ_BlockSign_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    int id;
    (void)world;
    for(id=CLONEMC_J_SIGN_POST_ID;id<=CLONEMC_J_SIGN_WALL_ID;
        id+=(CLONEMC_J_SIGN_WALL_ID-CLONEMC_J_SIGN_POST_ID)){
        block=CloneMCJ_BlockRegistry_GetMutable(id);
        if(!block)continue;
        block->material=CLONEMC_J_MATERIAL_WOOD;
        block->hardness=1.0F;
        block->solid=0;block->opaque=0;block->collidable=0;
        block->hasTileEntity=1;
        block->droppedItemID=323;block->droppedCount=1;
        block->neighborChanged=CloneMCJ_BlockSign_Neighbor;
        if(id==CLONEMC_J_SIGN_POST_ID){
            block->minX=0.25;block->minY=0.0;block->minZ=0.25;
            block->maxX=0.75;block->maxY=1.0;block->maxZ=0.75;
        }else{
            /* Metadata-dependent wall bounds are supplied by
             * CloneMCJ_Block_GetSelectionBox. */
            block->minX=0.0;block->minY=0.28125;block->minZ=0.0;
            block->maxX=1.0;block->maxY=0.78125;block->maxZ=1.0;
        }
    }
}

void CloneMCJ_BlockSign_Register(void)
{
    /* Runtime installation is world-owned through BlockSimulation_RegisterWorld. */
}

const char *CloneMCJ_BlockSign_JavaName(void)
{
    return "net.minecraft.src.BlockSign";
}

const char *CloneMCJ_BlockSign_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockSign_JavaSourceHash32(void)
{
    return 0xCA6E8285UL;
}
