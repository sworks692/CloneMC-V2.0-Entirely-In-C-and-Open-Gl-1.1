/*
 * CloneMC Java port scaffold: BlockGravel
 *
 * Java source: BlockGravel.java
 * Java type: class BlockGravel
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: BlockSand
 * Implements: (none declared)
 * Source SHA-256: 34b3d94033433adccb930e35cb308ceb537dcad0c83ad1fa92d03b6355af5c85
 * Java lines: 31
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: BlockSand, Item
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockGravel(int i, int j)
 * - public int idDropped(int i, Random random)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockGravel_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockGravel_JavaName(void)
{
    return "net.minecraft.src.BlockGravel";
}

const char *CloneMCJ_BlockGravel_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockGravel_JavaSourceHash32(void)
{
    return 0x34B3D940UL;
}
