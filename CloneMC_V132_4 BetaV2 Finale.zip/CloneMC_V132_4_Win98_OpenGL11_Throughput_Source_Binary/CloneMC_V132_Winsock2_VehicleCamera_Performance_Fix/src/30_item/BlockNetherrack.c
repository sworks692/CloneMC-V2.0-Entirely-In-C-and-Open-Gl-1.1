/*
 * CloneMC Java port scaffold: BlockNetherrack
 *
 * Java source: BlockNetherrack.java
 * Java type: class BlockNetherrack
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 250e9fb9297e148ad1821dcea0ebd72d693d0fac1bd33a7d726f70147eaa6467
 * Java lines: 19
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: Block, Material, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockNetherrack(int i, int j)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockNetherrack_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockNetherrack_JavaName(void)
{
    return "net.minecraft.src.BlockNetherrack";
}

const char *CloneMCJ_BlockNetherrack_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockNetherrack_JavaSourceHash32(void)
{
    return 0x250E9FB9UL;
}
