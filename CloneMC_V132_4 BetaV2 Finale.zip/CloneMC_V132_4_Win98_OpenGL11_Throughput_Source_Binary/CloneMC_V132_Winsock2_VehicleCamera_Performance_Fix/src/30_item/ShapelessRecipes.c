/*
 * Direct C89 implementation of ShapelessRecipes.java matching.
 */
#include "clonemc_java_port_30_item.h"

int CloneMCJ_ShapelessRecipes_MatchesNative(const CloneMCJ_Recipe *recipe,
    const CloneMCJ_InventoryCrafting *inventory)
{
    unsigned char used[CLONEMC_J_MAX_RECIPE_CELLS];
    const CloneMCJ_ItemStack *stack;
    const CloneMCJ_RecipeIngredient *ingredient;
    int inventorySize;
    int stackIndex;
    int ingredientIndex;
    int found;
    int occupied;
    if (!recipe || !inventory || recipe->shaped) return 0;
    for (ingredientIndex = 0; ingredientIndex < CLONEMC_J_MAX_RECIPE_CELLS;
        ++ingredientIndex) used[ingredientIndex] = 0;
    inventorySize = CloneMCJ_InventoryCrafting_GetSize(inventory);
    occupied = 0;
    for (stackIndex = 0; stackIndex < inventorySize; ++stackIndex) {
        stack = CloneMCJ_InventoryCrafting_GetSlotConst(inventory, stackIndex);
        if (!stack || CloneMCJ_ItemStack_IsEmpty(stack)) continue;
        ++occupied;
        found = 0;
        for (ingredientIndex = 0; ingredientIndex < recipe->ingredientCount;
            ++ingredientIndex) {
            if (used[ingredientIndex]) continue;
            ingredient = &recipe->ingredients[ingredientIndex];
            if (stack->itemID != ingredient->itemID) continue;
            if (ingredient->itemDamage != CLONEMC_J_ITEM_DAMAGE_WILDCARD &&
                stack->itemDamage != ingredient->itemDamage) continue;
            used[ingredientIndex] = 1;
            found = 1;
            break;
        }
        if (!found) return 0;
    }
    return occupied == recipe->ingredientCount;
}

void CloneMCJ_ShapelessRecipes_Register(void) { }
const char *CloneMCJ_ShapelessRecipes_JavaName(void)
{ return "net.minecraft.src.ShapelessRecipes"; }
const char *CloneMCJ_ShapelessRecipes_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_ShapelessRecipes_JavaSourceHash32(void)
{ return 0xE518E668UL; }
