/*
 * CloneMC Java port scaffold: BlockReed
 *
 * Java source: BlockReed.java
 * Java type: class BlockReed
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 0e0a4ac32e75e53b27c6a61730d4418023d15463e395affbea61a968a557609c
 * Java lines: 116
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: Block, Material, World, BlockGrass, Item, AxisAlignedBB, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockReed(int i, int j)
 * - public void updateTick(World world, int i, int j, int k, Random random)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - protected final void checkBlockCoordValid(World world, int i, int j, int k)
 * - public boolean canBlockStay(World world, int i, int j, int k)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public int idDropped(int i, Random random)
 * - public boolean isOpaqueCube()
 * - public boolean renderAsNormalBlock()
 * - public int getRenderType()
 *
 * Priority 11 directly ports Java age-15 growth, three-block height limit and
 * water-adjacent support validation.
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

static void CloneMCJ_BlockReed_UpdateTick(CloneMCJ_World *world, int x, int y,
    int z, int blockID, CloneMCJavaRandom *random, void *userData)
{
    int height;
    int metadata;
    (void)random; (void)userData;
    if (!world || !CloneMCJ_World_IsAirBlock(world, x, y + 1, z)) return;
    height = 1;
    while (y - height >= 0 && CloneMCJ_World_GetBlockId(world, x, y - height, z) == blockID)
        ++height;
    if (height >= 3) return;
    metadata = CloneMCJ_World_GetBlockMetadata(world, x, y, z);
    if (metadata == 15) {
        CloneMCJ_World_SetBlockNotify(world, x, y + 1, z, blockID);
        CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, 0);
    } else CloneMCJ_World_SetBlockMetadataNotify(world, x, y, z, metadata + 1);
}

static void CloneMCJ_BlockReed_Neighbor(CloneMCJ_World *world, int x, int y,
    int z, int neighborID)
{
    (void)neighborID;
    if (!CloneMCJ_World_CanReedStay(world, x, y, z))
        CloneMCJ_World_SetBlockNotify(world, x, y, z, 0);
}

void CloneMCJ_BlockReed_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    block = CloneMCJ_BlockRegistry_GetMutable(83);
    if (block) { block->tickRandomly = 1; block->neighborChanged = CloneMCJ_BlockReed_Neighbor; }
    CloneMCJ_World_RegisterBlockTick(world, 83, 1, CloneMCJ_BlockReed_UpdateTick, 0);
}

void CloneMCJ_BlockReed_Register(void)
{
    CloneMCJ_BlockRegistry_Initialize();
}

const char *CloneMCJ_BlockReed_JavaName(void)
{
    return "net.minecraft.src.BlockReed";
}

const char *CloneMCJ_BlockReed_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockReed_JavaSourceHash32(void)
{
    return 0x0E0A4AC3UL;
}
