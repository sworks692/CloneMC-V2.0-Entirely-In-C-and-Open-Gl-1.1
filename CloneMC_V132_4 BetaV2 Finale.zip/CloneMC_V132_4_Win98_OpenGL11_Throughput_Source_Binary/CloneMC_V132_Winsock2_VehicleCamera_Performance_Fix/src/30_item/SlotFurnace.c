/*
 * CloneMC Java port scaffold: SlotFurnace
 *
 * Java source: SlotFurnace.java
 * Java type: class SlotFurnace
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Slot
 * Implements: (none declared)
 * Source SHA-256: a1abdff6026e8c96ba5790187c974287de7f9b371b841b7b8f3eb871f6678ebe
 * Java lines: 42
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Slot, EntityPlayer, ItemStack, Item, AchievementList, IInventory, i, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private EntityPlayer thePlayer
 *
 * Java method/constructor inventory:
 * - public SlotFurnace(EntityPlayer entityplayer, IInventory iinventory, int i, int j, int k)
 * - public boolean isItemValid(ItemStack itemstack)
 * - public void onPickupFromSlot(ItemStack itemstack)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_SlotFurnace_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_SlotFurnace_JavaName(void)
{
    return "net.minecraft.src.SlotFurnace";
}

const char *CloneMCJ_SlotFurnace_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_SlotFurnace_JavaSourceHash32(void)
{
    return 0xA1ABDFF6UL;
}
