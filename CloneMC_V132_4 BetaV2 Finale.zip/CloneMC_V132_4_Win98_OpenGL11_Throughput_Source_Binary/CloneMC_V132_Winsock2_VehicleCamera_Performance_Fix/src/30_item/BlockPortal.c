/*
 * Direct C89 port of the Beta BlockPortal frame, support and collision rules.
 * Java source: BlockPortal.java (protocol-14/Beta target supplied by the user).
 */
#include "clonemc_java_port_30_item.h"
#include "../40_world/clonemc_java_port_40_world.h"

#define CLONEMC_J_PORTAL_ID 90
#define CLONEMC_J_OBSIDIAN_ID 49
#define CLONEMC_J_FIRE_ID 51

static int CloneMCJ_BlockPortal_IsInterior(int id)
{
    /* BlockPortal.tryToCreatePortal accepts only air or fire while validating
     * a new frame.  Existing portal blocks are deliberately not a substitute
     * for a complete, newly ignited interior. */
    return id==0||id==CLONEMC_J_FIRE_ID;
}

int CloneMCJ_BlockPortal_TryCreate(CloneMCJ_World *world,int x,int y,int z)
{
    int dx,dz,width,height,id;
    if(!world||y<1||y>124)return 0;
    dx=dz=0;
    if(CloneMCJ_World_GetBlockId(world,x-1,y,z)==CLONEMC_J_OBSIDIAN_ID||
       CloneMCJ_World_GetBlockId(world,x+1,y,z)==CLONEMC_J_OBSIDIAN_ID)dx=1;
    if(CloneMCJ_World_GetBlockId(world,x,y,z-1)==CLONEMC_J_OBSIDIAN_ID||
       CloneMCJ_World_GetBlockId(world,x,y,z+1)==CLONEMC_J_OBSIDIAN_ID)dz=1;
    if(dx==dz)return 0;
    if(CloneMCJ_World_GetBlockId(world,x-dx,y,z-dz)==0){x-=dx;z-=dz;}
    for(width=-1;width<=2;++width){
        for(height=-1;height<=3;++height){
            int border;
            border=(width==-1||width==2||height==-1||height==3);
            if((width==-1||width==2)&&(height==-1||height==3))continue;
            id=CloneMCJ_World_GetBlockId(world,x+dx*width,y+height,z+dz*width);
            if(border){if(id!=CLONEMC_J_OBSIDIAN_ID)return 0;}
            else if(!CloneMCJ_BlockPortal_IsInterior(id))return 0;
        }
    }
    world->editingBlocks=1;
    for(width=0;width<2;++width)for(height=0;height<3;++height)
        CloneMCJ_World_SetBlockWithMetadataNotify(world,x+dx*width,y+height,z+dz*width,
            CLONEMC_J_PORTAL_ID,dx?1:2);
    world->editingBlocks=0;
    return 1;
}

int CloneMCJ_BlockPortal_IsValid(CloneMCJ_World *world,int x,int y,int z)
{
    int horizontalX,horizontalZ,bottom,height,portalAlongX,portalAlongZ;
    int neighborA,neighborB;
    if(!world||CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_PORTAL_ID)return 0;
    horizontalX=0;horizontalZ=1;
    if(CloneMCJ_World_GetBlockId(world,x-1,y,z)==CLONEMC_J_PORTAL_ID||
       CloneMCJ_World_GetBlockId(world,x+1,y,z)==CLONEMC_J_PORTAL_ID){horizontalX=1;horizontalZ=0;}
    bottom=y;
    while(bottom>0&&CloneMCJ_World_GetBlockId(world,x,bottom-1,z)==CLONEMC_J_PORTAL_ID)--bottom;
    if(CloneMCJ_World_GetBlockId(world,x,bottom-1,z)!=CLONEMC_J_OBSIDIAN_ID)return 0;
    height=0;
    while(height<4&&CloneMCJ_World_GetBlockId(world,x,bottom+height,z)==CLONEMC_J_PORTAL_ID)++height;
    if(height!=3||CloneMCJ_World_GetBlockId(world,x,bottom+height,z)!=CLONEMC_J_OBSIDIAN_ID)return 0;
    portalAlongX=(CloneMCJ_World_GetBlockId(world,x-1,y,z)==CLONEMC_J_PORTAL_ID||
        CloneMCJ_World_GetBlockId(world,x+1,y,z)==CLONEMC_J_PORTAL_ID);
    portalAlongZ=(CloneMCJ_World_GetBlockId(world,x,y,z-1)==CLONEMC_J_PORTAL_ID||
        CloneMCJ_World_GetBlockId(world,x,y,z+1)==CLONEMC_J_PORTAL_ID);
    if(portalAlongX&&portalAlongZ)return 0;
    neighborA=CloneMCJ_World_GetBlockId(world,x+horizontalX,y,z+horizontalZ);
    neighborB=CloneMCJ_World_GetBlockId(world,x-horizontalX,y,z-horizontalZ);
    return (neighborA==CLONEMC_J_OBSIDIAN_ID&&neighborB==CLONEMC_J_PORTAL_ID)||
           (neighborB==CLONEMC_J_OBSIDIAN_ID&&neighborA==CLONEMC_J_PORTAL_ID);
}

static void CloneMCJ_BlockPortal_Neighbor(CloneMCJ_World *world,int x,int y,int z,int neighborID)
{
    (void)neighborID;
    if(!CloneMCJ_BlockPortal_IsValid(world,x,y,z))
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
}

void CloneMCJ_BlockPortal_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(CLONEMC_J_PORTAL_ID);
    if(block){
        block->solid=0;block->opaque=0;block->collidable=0;block->replaceable=0;
        block->lightEmission=11;block->lightOpacity=0;
        block->neighborChanged=CloneMCJ_BlockPortal_Neighbor;
    }
}

void CloneMCJ_BlockPortal_Register(void){}
const char *CloneMCJ_BlockPortal_JavaName(void){return "net.minecraft.src.BlockPortal";}
const char *CloneMCJ_BlockPortal_AssignedFolder(void){return "src/30_item";}
unsigned long CloneMCJ_BlockPortal_JavaSourceHash32(void){return 0xEFD78402UL;}
