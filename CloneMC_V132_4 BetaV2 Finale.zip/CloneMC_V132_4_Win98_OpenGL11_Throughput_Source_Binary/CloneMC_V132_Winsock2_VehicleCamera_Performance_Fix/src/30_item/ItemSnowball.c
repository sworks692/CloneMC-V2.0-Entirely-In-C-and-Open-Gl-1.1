/*
 * CloneMC Java port scaffold: ItemSnowball
 *
 * Java source: ItemSnowball.java
 * Java type: class ItemSnowball
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Item
 * Implements: (none declared)
 * Source SHA-256: a6fc6c404dcef7734554612e9d0ef9e0f598a873fd8b708bca48e6dd6dfecf98
 * Java lines: 33
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Item, ItemStack, World, EntitySnowball, EntityPlayer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemSnowball(int i)
 * - public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemSnowball_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemSnowball_JavaName(void)
{
    return "net.minecraft.src.ItemSnowball";
}

const char *CloneMCJ_ItemSnowball_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemSnowball_JavaSourceHash32(void)
{
    return 0xA6FC6C40UL;
}
