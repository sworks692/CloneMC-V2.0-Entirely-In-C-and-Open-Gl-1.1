/*
 * Direct C89 conversion of the uploaded Beta BlockCake.java geometry,
 * support and six-slice eating behavior.
 *
 * Java source: BlockCake.java
 * Java type: class BlockCake
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 502a171ef9ec321218530ef134c6b8648c37774693e4cda7b69f8f54361bb33c
 * Java lines: 163
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 17
 * Referenced Java classes: Block, Material, IBlockAccess, World, AxisAlignedBB, EntityPlayer, j, f, f2, f1, r
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected BlockCake(int i, int j)
 * - public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int i, int j, int k)
 * - public void setBlockBoundsForItemRender()
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k)
 * - public int getBlockTextureFromSideAndMetadata(int i, int j)
 * - public int getBlockTextureFromSide(int i)
 * - public boolean renderAsNormalBlock()
 * - public boolean isOpaqueCube()
 * - public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - public void onBlockClicked(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - private void eatCakeSlice(World world, int i, int j, int k, EntityPlayer entityplayer)
 * - public boolean canPlaceBlockAt(World world, int i, int j, int k)
 * - public void onNeighborBlockChange(World world, int i, int j, int k, int l)
 * - public boolean canBlockStay(World world, int i, int j, int k)
 * - public int quantityDropped(Random random)
 * - public int idDropped(int i, Random random)
 *
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"

#define CLONEMC_J_CAKE_ID 92

int CloneMCJ_BlockCake_CanStayNative(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *support;
    int id;
    if(!world||y<=0)return 0;
    id=CloneMCJ_World_GetBlockId(world,x,y-1,z);
    support=CloneMCJ_BlockRegistry_Get(id);
    return id!=0&&support&&support->solid;
}

int CloneMCJ_BlockCake_ActivateNative(CloneMCJ_World *world,int x,int y,int z,
    CloneMCJ_EntityPlayer *player)
{
    int metadata;
    if(!world||!player||
       CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_CAKE_ID)return 0;
    /* BlockCake.blockActivated always consumes the click.  A full-health
     * player leaves the cake unchanged, exactly as the Java method does. */
    if(player->health<20){
        player->health+=3;
        if(player->health>20)player->health=20;
        metadata=CloneMCJ_World_GetBlockMetadata(world,x,y,z)+1;
        if(metadata>=6)CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
        else CloneMCJ_World_SetBlockMetadataNotify(world,x,y,z,metadata);
    }
    return 1;
}

static void CloneMCJ_BlockCake_Neighbor(CloneMCJ_World *world,
    int x,int y,int z,int neighborID)
{
    (void)neighborID;
    if(world&&!CloneMCJ_BlockCake_CanStayNative(world,x,y,z))
        CloneMCJ_World_SetBlockNotify(world,x,y,z,0);
}

void CloneMCJ_BlockCake_RegisterRuntime(CloneMCJ_World *world)
{
    CloneMCJ_BlockDefinition *block;
    (void)world;
    block=CloneMCJ_BlockRegistry_GetMutable(CLONEMC_J_CAKE_ID);
    if(!block)return;
    /* The compact native material enum has no dedicated cake entry.  Cloth is
     * the closest non-rock, solid-support material and collision is controlled
     * independently below. */
    block->material=CLONEMC_J_MATERIAL_CLOTH;
    block->hardness=0.5F;
    block->solid=1;block->opaque=0;block->collidable=1;
    block->droppedItemID=0;block->droppedCount=0;
    block->minX=0.0625;block->minY=0.0;block->minZ=0.0625;
    block->maxX=0.9375;block->maxY=0.5;block->maxZ=0.9375;
    block->neighborChanged=CloneMCJ_BlockCake_Neighbor;
    block->activate=CloneMCJ_BlockCake_ActivateNative;
}

void CloneMCJ_BlockCake_Register(void)
{
    /* Runtime installation is world-owned through BlockSimulation_RegisterWorld. */
}

const char *CloneMCJ_BlockCake_JavaName(void)
{
    return "net.minecraft.src.BlockCake";
}

const char *CloneMCJ_BlockCake_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockCake_JavaSourceHash32(void)
{
    return 0x502A171EUL;
}
