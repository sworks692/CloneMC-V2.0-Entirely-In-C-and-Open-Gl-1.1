/*
 * CloneMC Java port scaffold: ItemPickaxe
 *
 * Java source: ItemPickaxe.java
 * Java type: class ItemPickaxe
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemTool
 * Implements: (none declared)
 * Source SHA-256: 39e4385ce819be06aa06f82d1ea992657f9f1d1675c904ba9eec848acd54688a
 * Java lines: 62
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: ItemTool, Block, EnumToolMaterial, Material, enumtoolmaterial, static, Block.cobblestone, Block.stairDouble, Block.stairSingle, Block.stone, Block.sandStone, Block.cobblestoneMossy, Block.oreIron, Block.blockSteel, Block.oreCoal, Block.blockGold, Block.oreGold, Block.oreDiamond, Block.blockDiamond, Block.ice, Block.netherrack, Block.oreLapis, Block.blockLapis
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static Block blocksEffectiveAgainst[]
 *
 * Java method/constructor inventory:
 * - protected ItemPickaxe(int i, EnumToolMaterial enumtoolmaterial)
 * - public boolean canHarvestBlock(Block block)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_ItemPickaxe_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemPickaxe_JavaName(void)
{
    return "net.minecraft.src.ItemPickaxe";
}

const char *CloneMCJ_ItemPickaxe_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemPickaxe_JavaSourceHash32(void)
{
    return 0x39E4385CUL;
}
