/*
 * CloneMC Java port scaffold: ItemMap
 *
 * Java source: ItemMap.java
 * Java type: class ItemMap
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemMapBase
 * Implements: (none declared)
 * Source SHA-256: 28e9240c7e55879f44a52870771b8f29af5efe2d4bdddcad327d0d718b59d313
 * Java lines: 268
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: ItemMapBase, MapData, World, ItemStack, WorldInfo, WorldProvider, Entity, MathHelper, Block, Chunk, Material, MapColor, EntityPlayer, public
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - protected ItemMap(int i)
 * - public static MapData func_28013_a(short word0, World world)
 * - public MapData func_28012_a(ItemStack itemstack, World world)
 * - public void func_28011_a(World world, Entity entity, MapData mapdata)
 * - public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
 * - public void onCreated(ItemStack itemstack, World world, EntityPlayer entityplayer)
 *
 * Native implementation owns map allocation, player tracking and the Java
 * staggered terrain sampler.  Persistence remains in MapStorage.c and pixel/
 * decoration state in MapData.c.
 */
#include "clonemc_java_port_30_item.h"
#include "../10_save/clonemc_java_port_10_save.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

static int CloneMCJ_ItemMap_MapColor(int blockID)
{
    const CloneMCJ_BlockDefinition *block;
    if(blockID<=0)return 0;
    if(blockID==CLONEMC_J_BLOCK_GRASS)return 1;
    if(blockID==CLONEMC_J_BLOCK_SAND||
       blockID==CLONEMC_J_BLOCK_SANDSTONE)return 2;
    if(blockID==46||blockID==CLONEMC_J_BLOCK_LAVA_MOVING||
       blockID==CLONEMC_J_BLOCK_LAVA_STILL||
       blockID==CLONEMC_J_BLOCK_FIRE)return 4;
    if(blockID==CLONEMC_J_BLOCK_ICE)return 5;
    if(blockID==CLONEMC_J_BLOCK_LEAVES||
       blockID==CLONEMC_J_BLOCK_TALL_GRASS||
       blockID==CLONEMC_J_BLOCK_DEAD_BUSH||
       (blockID>=CLONEMC_J_BLOCK_PLANT_YELLOW&&
        blockID<=CLONEMC_J_BLOCK_MUSHROOM_RED))return 7;
    if(blockID==CLONEMC_J_BLOCK_SNOW)return 8;
    if(blockID==CLONEMC_J_BLOCK_CLAY)return 9;
    if(blockID==CLONEMC_J_BLOCK_DIRT||
       blockID==CLONEMC_J_BLOCK_SOUL_SAND)return 10;
    if(blockID==CLONEMC_J_BLOCK_WATER_MOVING||
       blockID==CLONEMC_J_BLOCK_WATER_STILL)return 12;
    if(blockID==CLONEMC_J_BLOCK_LOG)return 13;
    block=CloneMCJ_BlockRegistry_Get(blockID);
    if(!block)return 0;
    switch(block->material){
    case CLONEMC_J_MATERIAL_ROCK:return 11;
    case CLONEMC_J_MATERIAL_EARTH:return 10;
    case CLONEMC_J_MATERIAL_WOOD:return 13;
    case CLONEMC_J_MATERIAL_PLANT:return 7;
    case CLONEMC_J_MATERIAL_WATER:return 12;
    case CLONEMC_J_MATERIAL_LAVA:return 4;
    case CLONEMC_J_MATERIAL_CLOTH:return 3;
    case CLONEMC_J_MATERIAL_ICE:return 5;
    case CLONEMC_J_MATERIAL_SAND:return 2;
    case CLONEMC_J_MATERIAL_METAL:return 6;
    default:return 0;
    }
}

static int CloneMCJ_ItemMap_IsLiquid(int blockID)
{
    const CloneMCJ_BlockDefinition *block;
    block=CloneMCJ_BlockRegistry_Get(blockID);
    return block&&(block->material==CLONEMC_J_MATERIAL_WATER||
        block->material==CLONEMC_J_MATERIAL_LAVA);
}

CloneMCJ_MapData *CloneMCJ_ItemMap_GetById(CloneMCJ_MapStorage *storage,
    int mapID,int create)
{
    char name[48];
    CloneMCJ_MapDataBase *base;
    CloneMCJ_MapData *map;
    if(!storage||mapID<0)return 0;
    sprintf(name,"map_%d",mapID);
    base=CloneMCJ_MapStorage_LoadData(storage,name,
        CloneMCJ_MapData_Factory,0);
    if(base)return (CloneMCJ_MapData *)base;
    if(!create)return 0;
    map=CloneMCJ_MapData_Create(name);
    if(!map)return 0;
    if(!CloneMCJ_MapStorage_SetData(storage,name,&map->base)){
        map->base.destroy(&map->base);return 0;
    }
    return map;
}

CloneMCJ_MapData *CloneMCJ_ItemMap_GetOrCreate(CloneMCJ_MapStorage *storage,
    CloneMCJ_ItemStack *stack,CloneMCJ_World *world,int createAtSpawn)
{
    CloneMCJ_MapData *map;
    int id;
    (void)createAtSpawn;
    if(!storage||!stack||!world)return 0;
    map=CloneMCJ_ItemMap_GetById(storage,stack->itemDamage,0);
    if(map)return map;
    id=CloneMCJ_MapStorage_GetUniqueDataId(storage,"map");
    stack->itemDamage=id;
    map=CloneMCJ_ItemMap_GetById(storage,id,1);
    if(!map)return 0;
    map->xCenter=world->worldInfo.spawnX;
    map->zCenter=world->worldInfo.spawnZ;
    map->scale=3;
    map->dimension=CloneMCJava_CastByte(world->worldProvider.worldType);
    CloneMCJ_MapDataBase_MarkDirty(&map->base);
    return map;
}

void CloneMCJ_ItemMap_UpdateTerrain(CloneMCJ_MapData *map,
    CloneMCJ_World *world,const CloneMCJ_EntityPlayer *player)
{
    int scale,centerX,centerZ,mapX,mapZ,radius,column,row;
    int relativeX,relativeZ,worldX,worldZ,sampleX,sampleZ;
    int height,blockID,dominantBlock,dominantCount,colorIndex,mapColor;
    int counts[256],liquidDepth,totalLiquid,minDirty,maxDirty;
    int innerOutside,pixel,shade;
    double previousHeight,heightSum,slope,waterSlope;
    unsigned char nextColor;
    if(!map||!world||!player||
       world->worldProvider.worldType!=map->dimension)return;
    scale=1<<map->scale;centerX=map->xCenter;centerZ=map->zCenter;
    mapX=CloneMCJava_FloorDouble(player->entity.posX-(double)centerX)/
        scale+64;
    mapZ=CloneMCJava_FloorDouble(player->entity.posZ-(double)centerZ)/
        scale+64;
    radius=128/scale;if(world->worldProvider.hasNoSky)radius/=2;
    ++map->updateCounter;
    for(column=mapX-radius+1;column<mapX+radius;++column){
        if((column&15)!=(map->updateCounter&15))continue;
        minDirty=255;maxDirty=0;previousHeight=0.0;
        for(row=mapZ-radius-1;row<mapZ+radius;++row){
            if(column<0||row<-1||column>=128||row>=128)continue;
            relativeX=column-mapX;relativeZ=row-mapZ;
            innerOutside=relativeX*relativeX+relativeZ*relativeZ>
                (radius-2)*(radius-2);
            worldX=((centerX/scale+column)-64)*scale;
            worldZ=((centerZ/scale+row)-64)*scale;
            memset(counts,0,sizeof(counts));
            totalLiquid=0;heightSum=0.0;
            if(world->worldProvider.hasNoSky){
                CloneMCJInt mixed;
                mixed=CloneMCJava_AddInt((CloneMCJInt)worldX,
                    CloneMCJava_MulInt((CloneMCJInt)worldZ,
                        (CloneMCJInt)0x000389BFL));
                mixed=CloneMCJava_AddInt(CloneMCJava_MulInt(
                    CloneMCJava_MulInt(mixed,mixed),
                    (CloneMCJInt)0x01DD6751L),
                    CloneMCJava_MulInt(mixed,11));
                counts[((CloneMCJUInt)mixed>>20)&1U?
                    CLONEMC_J_BLOCK_STONE:CLONEMC_J_BLOCK_DIRT]+=10;
                heightSum=100.0;
            }else for(sampleX=0;sampleX<scale;++sampleX)
                for(sampleZ=0;sampleZ<scale;++sampleZ){
                    int scanY,mapColor;
                    height=CloneMCJ_World_FindTopSolidBlock(world,
                        worldX+sampleX,worldZ+sampleZ)+1;
                    if(height<1)height=1;if(height>128)height=128;
                    scanY=height-1;
                    blockID=CloneMCJ_World_GetBlockId(world,
                        worldX+sampleX,scanY,worldZ+sampleZ);
                    mapColor=CloneMCJ_ItemMap_MapColor(blockID);
                    while(scanY>0&&mapColor==0){
                        --scanY;
                        blockID=CloneMCJ_World_GetBlockId(world,
                            worldX+sampleX,scanY,worldZ+sampleZ);
                        mapColor=CloneMCJ_ItemMap_MapColor(blockID);
                    }
                    height=scanY+1;
                    if(CloneMCJ_ItemMap_IsLiquid(blockID)){
                        int liquidY;
                        liquidY=scanY;
                        while(liquidY>0&&CloneMCJ_ItemMap_IsLiquid(
                            CloneMCJ_World_GetBlockId(world,worldX+sampleX,
                            liquidY,worldZ+sampleZ))){
                            ++totalLiquid;--liquidY;
                        }
                    }
                    heightSum+=(double)height/(double)(scale*scale);
                    if(blockID>=0&&blockID<256)++counts[blockID];
                }
            liquidDepth=totalLiquid/(scale*scale);
            dominantBlock=0;dominantCount=0;
            for(colorIndex=0;colorIndex<256;++colorIndex)
                if(counts[colorIndex]>dominantCount){
                    dominantCount=counts[colorIndex];
                    dominantBlock=colorIndex;
                }
            mapColor=CloneMCJ_ItemMap_MapColor(dominantBlock);
            slope=((heightSum-previousHeight)*4.0)/(double)(scale+4)+
                ((double)((column+row)&1)-0.5)*0.4;
            shade=1;if(slope>0.6)shade=2;if(slope<-0.6)shade=0;
            if(mapColor==12){
                waterSlope=(double)liquidDepth*0.1+
                    (double)((column+row)&1)*0.2;
                shade=1;if(waterSlope<0.5)shade=2;
                if(waterSlope>0.9)shade=0;
            }
            previousHeight=heightSum;
            if(row<0||relativeX*relativeX+relativeZ*relativeZ>=
               radius*radius||(innerOutside&&((column+row)&1)==0))continue;
            pixel=column+row*128;
            nextColor=(unsigned char)(mapColor*4+shade);
            if(map->colors[pixel]==nextColor)continue;
            map->colors[pixel]=nextColor;
            if(minDirty>row)minDirty=row;if(maxDirty<row)maxDirty=row;
        }
        if(minDirty<=maxDirty)
            CloneMCJ_MapData_MarkDirtyColumn(map,column,minDirty,maxDirty);
    }
}

void CloneMCJ_ItemMap_TickInventory(CloneMCJ_MapStorage *storage,
    CloneMCJ_World *world,CloneMCJ_EntityPlayer *player)
{
    CloneMCJ_ItemStack *stack;
    CloneMCJ_MapData *map;
    int slot;
    if(!storage||!world||!player||world->multiplayerWorld)return;
    for(slot=0;slot<CLONEMC_J_MAIN_INVENTORY_SIZE;++slot){
        stack=&player->inventory.mainInventory[slot];
        if(stack->itemID!=358||stack->stackSize<=0)continue;
        map=CloneMCJ_ItemMap_GetOrCreate(storage,stack,world,1);
        if(!map)continue;
        CloneMCJ_MapData_UpdatePlayer(map,player,stack);
        if(slot==player->inventory.currentItem)
            CloneMCJ_ItemMap_UpdateTerrain(map,world,player);
    }
}

void CloneMCJ_ItemMap_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemMap_JavaName(void)
{
    return "net.minecraft.src.ItemMap";
}

const char *CloneMCJ_ItemMap_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemMap_JavaSourceHash32(void)
{
    return 0x28E9240CUL;
}
