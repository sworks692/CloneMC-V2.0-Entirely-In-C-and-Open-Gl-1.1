/*
 * CloneMC Java port scaffold: ItemSoup
 *
 * Java source: ItemSoup.java
 * Java type: class ItemSoup
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: ItemFood
 * Implements: (none declared)
 * Source SHA-256: 8fad8298aaad5d4adacf22a059806cc5711b8c107d254c10ff6c77e1e38377d4
 * Java lines: 26
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: ItemFood, ItemStack, Item, World, EntityPlayer, j, world
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public ItemSoup(int i, int j)
 * - public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
 *
 * Direct conversion: onItemRightClick delegates to ItemFood and returns the
 * empty bowl stack, represented by CloneMCJ_ItemSoup_Use/CloneMCJ_ItemFood_Use.
 */
#include "clonemc_java_port_30_item.h"
#include "../20_entity/clonemc_java_port_20_entity.h"

int CloneMCJ_ItemSoup_Use(CloneMCJ_ItemStack *stack,CloneMCJ_EntityPlayer *player)
{
    if(!stack||stack->itemID!=282)return 0;
    return CloneMCJ_ItemFood_Use(stack,player);
}

void CloneMCJ_ItemSoup_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ItemSoup_JavaName(void)
{
    return "net.minecraft.src.ItemSoup";
}

const char *CloneMCJ_ItemSoup_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_ItemSoup_JavaSourceHash32(void)
{
    return 0x8FAD8298UL;
}
