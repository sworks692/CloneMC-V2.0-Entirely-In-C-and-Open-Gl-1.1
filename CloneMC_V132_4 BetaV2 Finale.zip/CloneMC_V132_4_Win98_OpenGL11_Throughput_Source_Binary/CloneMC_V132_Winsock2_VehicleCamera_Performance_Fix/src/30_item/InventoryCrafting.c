/*
 * Direct Open Watcom C89 port of InventoryCrafting.java.
 * Priority 13 keeps the matrix fixed at nine cells so player 2x2 and workbench
 * 3x3 crafting share one allocation-free implementation.
 */
#include "clonemc_java_port_30_item.h"
#include <string.h>

void CloneMCJ_InventoryCrafting_Initialize(CloneMCJ_InventoryCrafting *inventory,
    int width, int height)
{
    int i;
    if (!inventory) return;
    memset(inventory, 0, sizeof(*inventory));
    if (width < 1) width = 1;
    if (height < 1) height = 1;
    if (width > 3) width = 3;
    if (height > 3) height = 3;
    inventory->width = width;
    inventory->height = height;
    for (i = 0; i < CLONEMC_J_MAX_RECIPE_CELLS; ++i)
        CloneMCJ_ItemStack_Clear(&inventory->stackList[i]);
}

int CloneMCJ_InventoryCrafting_GetSize(const CloneMCJ_InventoryCrafting *inventory)
{
    if (!inventory) return 0;
    return inventory->width * inventory->height;
}

CloneMCJ_ItemStack *CloneMCJ_InventoryCrafting_GetSlot(
    CloneMCJ_InventoryCrafting *inventory, int slot)
{
    int size;
    if (!inventory) return (CloneMCJ_ItemStack *)0;
    size = CloneMCJ_InventoryCrafting_GetSize(inventory);
    if (slot < 0 || slot >= size) return (CloneMCJ_ItemStack *)0;
    return &inventory->stackList[slot];
}

const CloneMCJ_ItemStack *CloneMCJ_InventoryCrafting_GetSlotConst(
    const CloneMCJ_InventoryCrafting *inventory, int slot)
{
    int size;
    if (!inventory) return (const CloneMCJ_ItemStack *)0;
    size = CloneMCJ_InventoryCrafting_GetSize(inventory);
    if (slot < 0 || slot >= size) return (const CloneMCJ_ItemStack *)0;
    return &inventory->stackList[slot];
}

int CloneMCJ_InventoryCrafting_SetSlot(CloneMCJ_InventoryCrafting *inventory,
    int slot, const CloneMCJ_ItemStack *stack)
{
    CloneMCJ_ItemStack *destination;
    destination = CloneMCJ_InventoryCrafting_GetSlot(inventory, slot);
    if (!destination) return 0;
    if (stack) *destination = *stack;
    else CloneMCJ_ItemStack_Clear(destination);
    if (destination->stackSize > CloneMCJ_ItemStack_GetMaxStackSize(destination))
        destination->stackSize = CloneMCJ_ItemStack_GetMaxStackSize(destination);
    ++inventory->changeSerial;
    return 1;
}

CloneMCJ_ItemStack CloneMCJ_InventoryCrafting_DecrStack(
    CloneMCJ_InventoryCrafting *inventory, int slot, int amount)
{
    CloneMCJ_ItemStack empty;
    CloneMCJ_ItemStack *source;
    CloneMCJ_ItemStack_Clear(&empty);
    source = CloneMCJ_InventoryCrafting_GetSlot(inventory, slot);
    if (!source || amount <= 0) return empty;
    empty = CloneMCJ_ItemStack_Split(source, amount);
    ++inventory->changeSerial;
    return empty;
}

void CloneMCJ_InventoryCrafting_Clear(CloneMCJ_InventoryCrafting *inventory)
{
    int i;
    int size;
    if (!inventory) return;
    size = CloneMCJ_InventoryCrafting_GetSize(inventory);
    for (i = 0; i < size; ++i) CloneMCJ_ItemStack_Clear(&inventory->stackList[i]);
    ++inventory->changeSerial;
}

void CloneMCJ_InventoryCrafting_Register(void) { }
const char *CloneMCJ_InventoryCrafting_JavaName(void)
{ return "net.minecraft.src.InventoryCrafting"; }
const char *CloneMCJ_InventoryCrafting_AssignedFolder(void) { return "src/30_item"; }
unsigned long CloneMCJ_InventoryCrafting_JavaSourceHash32(void)
{ return 0xB90F0BD0UL; }
