/*
 * CloneMC Java port scaffold: BlockSoulSand
 *
 * Java source: BlockSoulSand.java
 * Java type: class BlockSoulSand
 * Package: net.minecraft.src
 * Assigned subsystem: src/30_item
 * Mapping reason: block, item, inventory, recipe, container, or tile-entity class
 * Extends: Block
 * Implements: (none declared)
 * Source SHA-256: 4992fac4962a3ff23a206a44007f7635e3e7a3559d0aaed168911baaab92101c
 * Java lines: 32
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: Block, Material, AxisAlignedBB, Entity, World, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BlockSoulSand(int i, int j)
 * - public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
 * - public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_30_item.h"

void CloneMCJ_BlockSoulSand_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BlockSoulSand_JavaName(void)
{
    return "net.minecraft.src.BlockSoulSand";
}

const char *CloneMCJ_BlockSoulSand_AssignedFolder(void)
{
    return "src/30_item";
}

unsigned long CloneMCJ_BlockSoulSand_JavaSourceHash32(void)
{
    return 0x4992FAC4UL;
}
