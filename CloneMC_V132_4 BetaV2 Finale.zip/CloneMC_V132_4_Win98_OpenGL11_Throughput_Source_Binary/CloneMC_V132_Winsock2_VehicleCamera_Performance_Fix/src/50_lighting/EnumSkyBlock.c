/*
 * CloneMC Java port scaffold: EnumSkyBlock
 *
 * Java source: EnumSkyBlock.java
 * Java type: enum EnumSkyBlock
 * Package: net.minecraft.src
 * Assigned subsystem: src/50_lighting
 * Mapping reason: skylight, blocklight, or packed-nibble lighting class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 483b135665468ee541687a7453c7fe4c38f339d89638b0297b2e201565bc0f84
 * Java lines: 46
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final int field_1722_c
 * - private static final EnumSkyBlock field_1721_d[]
 *
 * Java method/constructor inventory:
 * - private EnumSkyBlock(String s, int i, int j)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_50_lighting.h"

void CloneMCJ_EnumSkyBlock_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumSkyBlock_JavaName(void)
{
    return "net.minecraft.src.EnumSkyBlock";
}

const char *CloneMCJ_EnumSkyBlock_AssignedFolder(void)
{
    return "src/50_lighting";
}

unsigned long CloneMCJ_EnumSkyBlock_JavaSourceHash32(void)
{
    return 0x483B1356UL;
}

/* Priority 3 EnumSkyBlock implementation. */
static const CloneMCJ_EnumSkyBlock CloneMCJ_EnumSkyBlock_SkyValue = { CLONEMC_J_ENUM_SKY_BLOCK_SKY, 15, "Sky" };
static const CloneMCJ_EnumSkyBlock CloneMCJ_EnumSkyBlock_BlockValue = { CLONEMC_J_ENUM_SKY_BLOCK_BLOCK, 0, "Block" };

const CloneMCJ_EnumSkyBlock *CloneMCJ_EnumSkyBlock_Sky(void)
{
    return &CloneMCJ_EnumSkyBlock_SkyValue;
}

const CloneMCJ_EnumSkyBlock *CloneMCJ_EnumSkyBlock_Block(void)
{
    return &CloneMCJ_EnumSkyBlock_BlockValue;
}

const CloneMCJ_EnumSkyBlock *CloneMCJ_EnumSkyBlock_ByID(int skyBlock)
{
    return skyBlock == CLONEMC_J_ENUM_SKY_BLOCK_BLOCK ? &CloneMCJ_EnumSkyBlock_BlockValue : &CloneMCJ_EnumSkyBlock_SkyValue;
}

int CloneMCJ_EnumSkyBlock_DefaultLightValue(int skyBlock)
{
    return CloneMCJ_EnumSkyBlock_ByID(skyBlock)->defaultLightValue;
}
