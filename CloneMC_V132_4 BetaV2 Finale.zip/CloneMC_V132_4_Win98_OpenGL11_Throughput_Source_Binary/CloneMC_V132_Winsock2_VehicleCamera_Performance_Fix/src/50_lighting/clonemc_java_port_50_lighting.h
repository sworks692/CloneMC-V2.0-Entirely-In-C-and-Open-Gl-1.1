/*
 * CloneMC V90 shared lighting declarations.
 *
 * Header architecture rule: the project intentionally exposes only ten shared
 * headers.  EnumSkyBlock.java, MetadataChunkBlock.java and NibbleArray.java
 * remain separate Java-named C implementation files, but their public C types
 * and prototypes live here rather than in class-by-class headers.
 */
#ifndef CLONEMC_JAVA_PORT_50_LIGHTING_H
#define CLONEMC_JAVA_PORT_50_LIGHTING_H

#include "../00_core/clonemc_java_port_00_core.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CLONEMC_J_CHUNK_BLOCK_COUNT 32768UL
#define CLONEMC_J_CHUNK_NIBBLE_BYTES 16384UL
#define CLONEMC_J_ENUM_SKY_BLOCK_SKY   0
#define CLONEMC_J_ENUM_SKY_BLOCK_BLOCK 1

typedef struct CloneMCJ_NibbleArrayTag {
    unsigned char *data;
    unsigned long byteLength;
    unsigned char ownsData;
} CloneMCJ_NibbleArray;

typedef struct CloneMCJ_MetadataChunkBlockTag {
    int skyBlock;
    int minX;
    int minY;
    int minZ;
    int maxX;
    int maxY;
    int maxZ;
} CloneMCJ_MetadataChunkBlock;

typedef struct CloneMCJ_EnumSkyBlockTag {
    int ordinal;
    int defaultLightValue;
    const char *name;
} CloneMCJ_EnumSkyBlock;

struct CloneMCJ_WorldTag;

int CloneMCJ_NibbleArray_Initialize(CloneMCJ_NibbleArray *self, unsigned long blockCount);
int CloneMCJ_NibbleArray_Wrap(CloneMCJ_NibbleArray *self, unsigned char *bytes, unsigned long byteLength);
void CloneMCJ_NibbleArray_Destroy(CloneMCJ_NibbleArray *self);
int CloneMCJ_NibbleArray_IsValid(const CloneMCJ_NibbleArray *self);
unsigned long CloneMCJ_NibbleArray_Index(int localX, int y, int localZ);
int CloneMCJ_NibbleArray_GetNibble(const CloneMCJ_NibbleArray *self, int localX, int y, int localZ);
void CloneMCJ_NibbleArray_SetNibble(CloneMCJ_NibbleArray *self, int localX, int y, int localZ, int value);

void CloneMCJ_MetadataChunkBlock_Initialize(CloneMCJ_MetadataChunkBlock *region, int skyBlock,
    int minX, int minY, int minZ, int maxX, int maxY, int maxZ);
int CloneMCJ_MetadataChunkBlock_CanCombine(CloneMCJ_MetadataChunkBlock *region,
    int minX, int minY, int minZ, int maxX, int maxY, int maxZ);
int CloneMCJ_MetadataChunkBlock_Process(CloneMCJ_MetadataChunkBlock *region,
    struct CloneMCJ_WorldTag *world);

const CloneMCJ_EnumSkyBlock *CloneMCJ_EnumSkyBlock_Sky(void);
const CloneMCJ_EnumSkyBlock *CloneMCJ_EnumSkyBlock_Block(void);
const CloneMCJ_EnumSkyBlock *CloneMCJ_EnumSkyBlock_ByID(int skyBlock);
int CloneMCJ_EnumSkyBlock_DefaultLightValue(int skyBlock);

/* EnumSkyBlock.java: enum, 46 Java lines. */
void CloneMCJ_EnumSkyBlock_Register(void);
const char *CloneMCJ_EnumSkyBlock_JavaName(void);
const char *CloneMCJ_EnumSkyBlock_AssignedFolder(void);
unsigned long CloneMCJ_EnumSkyBlock_JavaSourceHash32(void);

/* MetadataChunkBlock.java: class, 238 Java lines. */
void CloneMCJ_MetadataChunkBlock_Register(void);
const char *CloneMCJ_MetadataChunkBlock_JavaName(void);
const char *CloneMCJ_MetadataChunkBlock_AssignedFolder(void);
unsigned long CloneMCJ_MetadataChunkBlock_JavaSourceHash32(void);

/* NibbleArray.java: class, 56 Java lines. */
void CloneMCJ_NibbleArray_Register(void);
const char *CloneMCJ_NibbleArray_JavaName(void);
const char *CloneMCJ_NibbleArray_AssignedFolder(void);
unsigned long CloneMCJ_NibbleArray_JavaSourceHash32(void);

#ifdef __cplusplus
}
#endif
#endif /* CLONEMC_JAVA_PORT_50_LIGHTING_H */
