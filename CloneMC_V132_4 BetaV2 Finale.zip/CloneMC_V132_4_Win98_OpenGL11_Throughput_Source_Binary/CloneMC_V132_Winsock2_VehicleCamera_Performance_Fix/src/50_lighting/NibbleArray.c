/*
 * CloneMC Java port scaffold: NibbleArray
 *
 * Java source: NibbleArray.java
 * Java type: class NibbleArray
 * Package: net.minecraft.src
 * Assigned subsystem: src/50_lighting
 * Mapping reason: skylight, blocklight, or packed-nibble lighting class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 276e431e3522d2963a462b5de0ac66388469c054fee60cd9496ee0a3626faddd
 * Java lines: 56
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final byte data[]
 *
 * Java method/constructor inventory:
 * - public NibbleArray(int i)
 * - public NibbleArray(byte abyte0[])
 * - public int getNibble(int i, int j, int k)
 * - public void setNibble(int i, int j, int k, int l)
 * - public boolean isValid()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_50_lighting.h"

void CloneMCJ_NibbleArray_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_NibbleArray_JavaName(void)
{
    return "net.minecraft.src.NibbleArray";
}

const char *CloneMCJ_NibbleArray_AssignedFolder(void)
{
    return "src/50_lighting";
}

unsigned long CloneMCJ_NibbleArray_JavaSourceHash32(void)
{
    return 0x276E431EUL;
}

/* Priority 3 direct implementation from NibbleArray.java. */
#include <stdlib.h>
#include <string.h>

int CloneMCJ_NibbleArray_Initialize(CloneMCJ_NibbleArray *self, unsigned long blockCount)
{
    unsigned long byteCount;
    if (!self) { return 0; }
    byteCount = blockCount >> 1;
    self->data = (unsigned char *)malloc((size_t)byteCount);
    if (!self->data) {
        self->byteLength = 0;
        self->ownsData = 0;
        return 0;
    }
    memset(self->data, 0, (size_t)byteCount);
    self->byteLength = byteCount;
    self->ownsData = 1;
    return 1;
}

int CloneMCJ_NibbleArray_Wrap(CloneMCJ_NibbleArray *self, unsigned char *bytes, unsigned long byteLength)
{
    if (!self) { return 0; }
    self->data = bytes;
    self->byteLength = byteLength;
    self->ownsData = 0;
    return bytes != 0;
}

void CloneMCJ_NibbleArray_Destroy(CloneMCJ_NibbleArray *self)
{
    if (!self) { return; }
    if (self->ownsData && self->data) { free(self->data); }
    self->data = 0;
    self->byteLength = 0;
    self->ownsData = 0;
}

int CloneMCJ_NibbleArray_IsValid(const CloneMCJ_NibbleArray *self)
{
    return self && self->data && self->byteLength > 0;
}

unsigned long CloneMCJ_NibbleArray_Index(int localX, int y, int localZ)
{
    return (unsigned long)((localX << 11) | (localZ << 7) | y);
}

int CloneMCJ_NibbleArray_GetNibble(const CloneMCJ_NibbleArray *self, int localX, int y, int localZ)
{
    unsigned long index;
    unsigned long byteIndex;
    if (!CloneMCJ_NibbleArray_IsValid(self)) { return 0; }
    if (localX < 0 || localX >= 16 || localZ < 0 || localZ >= 16 || y < 0 || y >= 128) { return 0; }
    index = CloneMCJ_NibbleArray_Index(localX, y, localZ);
    byteIndex = index >> 1;
    if (byteIndex >= self->byteLength) { return 0; }
    if ((index & 1UL) == 0UL) { return self->data[byteIndex] & 0x0F; }
    return (self->data[byteIndex] >> 4) & 0x0F;
}

void CloneMCJ_NibbleArray_SetNibble(CloneMCJ_NibbleArray *self, int localX, int y, int localZ, int value)
{
    unsigned long index;
    unsigned long byteIndex;
    unsigned char packed;
    if (!CloneMCJ_NibbleArray_IsValid(self)) { return; }
    if (localX < 0 || localX >= 16 || localZ < 0 || localZ >= 16 || y < 0 || y >= 128) { return; }
    index = CloneMCJ_NibbleArray_Index(localX, y, localZ);
    byteIndex = index >> 1;
    if (byteIndex >= self->byteLength) { return; }
    packed = (unsigned char)(value & 0x0F);
    if ((index & 1UL) == 0UL) {
        self->data[byteIndex] = (unsigned char)((self->data[byteIndex] & 0xF0) | packed);
    } else {
        self->data[byteIndex] = (unsigned char)((self->data[byteIndex] & 0x0F) | (packed << 4));
    }
}
