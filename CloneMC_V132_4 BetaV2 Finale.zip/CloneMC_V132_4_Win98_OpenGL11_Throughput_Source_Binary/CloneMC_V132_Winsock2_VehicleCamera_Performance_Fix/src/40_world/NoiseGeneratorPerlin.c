/*
 * CloneMC direct Java-compatible port: NoiseGeneratorPerlin
 *
 * Java source: NoiseGeneratorPerlin.java
 * Java type: class NoiseGeneratorPerlin
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: NoiseGenerator
 * Implements: (none declared)
 * Source SHA-256: afc4927fb114c9f558176531c64f149532a1d47fe021851514bc1b292d814ef4
 * Java lines: 233
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: NoiseGenerator, d3, d4
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int permutations[]
 * - public double xCoord
 * - public double yCoord
 * - public double zCoord
 *
 * Java method/constructor inventory:
 * - public NoiseGeneratorPerlin()
 * - public NoiseGeneratorPerlin(Random random)
 * - public double generateNoise(double d, double d1, double d2)
 * - public final double lerp(double d, double d1, double d2)
 * - public final double func_4110_a(int i, double d, double d1)
 * - public final double grad(int i, double d, double d1, double d2)
 * - public double func_801_a(double d, double d1)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_NoiseGeneratorPerlin_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_NoiseGeneratorPerlin_JavaName(void)
{
    return "net.minecraft.src.NoiseGeneratorPerlin";
}

const char *CloneMCJ_NoiseGeneratorPerlin_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_NoiseGeneratorPerlin_JavaSourceHash32(void)
{
    return 0xAFC4927FUL;
}

static double CloneMCNoisePerlin_Lerp(double amount, double left, double right)
{
    return left + amount * (right - left);
}

static double CloneMCNoisePerlin_Grad2(int hash, double x, double z)
{
    int value;
    double first;
    double second;
    value = hash & 15;
    first = (double)(1 - ((value & 8) >> 3)) * x;
    second = value >= 4 ? ((value != 12 && value != 14) ? z : x) : 0.0;
    return ((value & 1) ? -first : first) + ((value & 2) ? -second : second);
}

static double CloneMCNoisePerlin_Grad3(int hash, double x, double y, double z)
{
    int value;
    double first;
    double second;
    value = hash & 15;
    first = value >= 8 ? y : x;
    second = value >= 4 ? ((value != 12 && value != 14) ? z : x) : y;
    return ((value & 1) ? -first : first) + ((value & 2) ? -second : second);
}

void CloneMCNoisePerlin_Initialize(CloneMCNoisePerlin *noise, CloneMCJavaRandom *random)
{
    int index;
    int swapIndex;
    int temporary;
    if (!noise || !random) { return; }
    noise->xCoord = CloneMCJavaRandom_NextDouble(random) * 256.0;
    noise->yCoord = CloneMCJavaRandom_NextDouble(random) * 256.0;
    noise->zCoord = CloneMCJavaRandom_NextDouble(random) * 256.0;
    for (index = 0; index < 256; ++index) { noise->permutations[index] = index; }
    for (index = 0; index < 256; ++index) {
        swapIndex = (int)CloneMCJavaRandom_NextIntBound(random, (CloneMCJInt)(256 - index)) + index;
        temporary = noise->permutations[index];
        noise->permutations[index] = noise->permutations[swapIndex];
        noise->permutations[swapIndex] = temporary;
        noise->permutations[index + 256] = noise->permutations[index];
    }
}

double CloneMCNoisePerlin_Generate(const CloneMCNoisePerlin *noise,
                                   double x, double y, double z)
{
    double localX;
    double localY;
    double localZ;
    double fadeX;
    double fadeY;
    double fadeZ;
    int floorX;
    int floorY;
    int floorZ;
    int hashX;
    int hashY;
    int hashZ;
    int a;
    int aa;
    int ab;
    int b;
    int ba;
    int bb;
    if (!noise) { return 0.0; }
    localX = x + noise->xCoord;
    localY = y + noise->yCoord;
    localZ = z + noise->zCoord;
    floorX = CloneMCJava_FloorDouble(localX);
    floorY = CloneMCJava_FloorDouble(localY);
    floorZ = CloneMCJava_FloorDouble(localZ);
    hashX = floorX & 255;
    hashY = floorY & 255;
    hashZ = floorZ & 255;
    localX -= (double)floorX;
    localY -= (double)floorY;
    localZ -= (double)floorZ;
    fadeX = localX * localX * localX * (localX * (localX * 6.0 - 15.0) + 10.0);
    fadeY = localY * localY * localY * (localY * (localY * 6.0 - 15.0) + 10.0);
    fadeZ = localZ * localZ * localZ * (localZ * (localZ * 6.0 - 15.0) + 10.0);
    a = noise->permutations[hashX] + hashY;
    aa = noise->permutations[a] + hashZ;
    ab = noise->permutations[a + 1] + hashZ;
    b = noise->permutations[hashX + 1] + hashY;
    ba = noise->permutations[b] + hashZ;
    bb = noise->permutations[b + 1] + hashZ;
    return CloneMCNoisePerlin_Lerp(fadeZ,
        CloneMCNoisePerlin_Lerp(fadeY,
            CloneMCNoisePerlin_Lerp(fadeX,
                CloneMCNoisePerlin_Grad3(noise->permutations[aa], localX, localY, localZ),
                CloneMCNoisePerlin_Grad3(noise->permutations[ba], localX - 1.0, localY, localZ)),
            CloneMCNoisePerlin_Lerp(fadeX,
                CloneMCNoisePerlin_Grad3(noise->permutations[ab], localX, localY - 1.0, localZ),
                CloneMCNoisePerlin_Grad3(noise->permutations[bb], localX - 1.0, localY - 1.0, localZ))),
        CloneMCNoisePerlin_Lerp(fadeY,
            CloneMCNoisePerlin_Lerp(fadeX,
                CloneMCNoisePerlin_Grad3(noise->permutations[aa + 1], localX, localY, localZ - 1.0),
                CloneMCNoisePerlin_Grad3(noise->permutations[ba + 1], localX - 1.0, localY, localZ - 1.0)),
            CloneMCNoisePerlin_Lerp(fadeX,
                CloneMCNoisePerlin_Grad3(noise->permutations[ab + 1], localX, localY - 1.0, localZ - 1.0),
                CloneMCNoisePerlin_Grad3(noise->permutations[bb + 1], localX - 1.0, localY - 1.0, localZ - 1.0))));
}

double CloneMCNoisePerlin_Generate2D(const CloneMCNoisePerlin *noise, double x, double z)
{
    return CloneMCNoisePerlin_Generate(noise, x, z, 0.0);
}

static double CloneMCNoisePerlin_GenerateBulk2D(const CloneMCNoisePerlin *noise,
                                                 double x, double z)
{
    double localX;
    double localZ;
    double fadeX;
    double fadeZ;
    double low;
    double high;
    int floorX;
    int floorZ;
    int hashX;
    int hashZ;
    int a;
    int b;
    localX = x + noise->xCoord;
    localZ = z + noise->zCoord;
    floorX = CloneMCJava_FloorDouble(localX);
    floorZ = CloneMCJava_FloorDouble(localZ);
    hashX = floorX & 255;
    hashZ = floorZ & 255;
    localX -= (double)floorX;
    localZ -= (double)floorZ;
    fadeX = localX * localX * localX * (localX * (localX * 6.0 - 15.0) + 10.0);
    fadeZ = localZ * localZ * localZ * (localZ * (localZ * 6.0 - 15.0) + 10.0);
    a = noise->permutations[noise->permutations[hashX]] + hashZ;
    b = noise->permutations[noise->permutations[hashX + 1]] + hashZ;
    low = CloneMCNoisePerlin_Lerp(fadeX,
        CloneMCNoisePerlin_Grad2(noise->permutations[a], localX, localZ),
        CloneMCNoisePerlin_Grad3(noise->permutations[b], localX - 1.0, 0.0, localZ));
    high = CloneMCNoisePerlin_Lerp(fadeX,
        CloneMCNoisePerlin_Grad3(noise->permutations[a + 1], localX, 0.0, localZ - 1.0),
        CloneMCNoisePerlin_Grad3(noise->permutations[b + 1], localX - 1.0, 0.0, localZ - 1.0));
    return CloneMCNoisePerlin_Lerp(fadeZ, low, high);
}

void CloneMCNoisePerlin_Add(const CloneMCNoisePerlin *noise, double *values,
                            double x, double y, double z, int xSize, int ySize, int zSize,
                            double xScale, double yScale, double zScale, double amplitude)
{
    int outputIndex;
    double inverseAmplitude;
    int previousHashY;
    double lerpX00;
    double lerpX10;
    double lerpX01;
    double lerpX11;
    int ix;
    int iz;
    int iy;
    if (!noise || !values || xSize <= 0 || ySize <= 0 || zSize <= 0 || amplitude == 0.0) { return; }

    /*
     * Direct port of NoiseGeneratorPerlin.func_805_a.  The 3-D branch is kept
     * in the same operation order as Java rather than calling generateNoise()
     * for every sample.  That distinction is important: Java's cached Y-cell
     * interpolation produces bit-identical double results that are used by the
     * terrain density threshold.
     */
    if (ySize == 1) {
        int index2D;
        double inverse2D;
        index2D = 0;
        inverse2D = 1.0 / amplitude;
        for (ix = 0; ix < xSize; ++ix) {
            double localX;
            int floorX;
            int hashX;
            double fadeX;
            localX = (x + (double)ix) * xScale + noise->xCoord;
            floorX = (int)localX;
            if (localX < (double)floorX) { --floorX; }
            hashX = floorX & 255;
            localX -= (double)floorX;
            fadeX = localX * localX * localX * (localX * (localX * 6.0 - 15.0) + 10.0);
            for (iz = 0; iz < zSize; ++iz) {
                double localZ;
                int floorZ;
                int hashZ;
                double fadeZ;
                int permutationX0;
                int corner00;
                int permutationX1;
                int corner10;
                double low;
                double high;
                double result;
                localZ = (z + (double)iz) * zScale + noise->zCoord;
                floorZ = (int)localZ;
                if (localZ < (double)floorZ) { --floorZ; }
                hashZ = floorZ & 255;
                localZ -= (double)floorZ;
                fadeZ = localZ * localZ * localZ * (localZ * (localZ * 6.0 - 15.0) + 10.0);
                permutationX0 = noise->permutations[hashX];
                corner00 = noise->permutations[permutationX0] + hashZ;
                permutationX1 = noise->permutations[hashX + 1];
                corner10 = noise->permutations[permutationX1] + hashZ;
                low = CloneMCNoisePerlin_Lerp(fadeX,
                    CloneMCNoisePerlin_Grad2(noise->permutations[corner00], localX, localZ),
                    CloneMCNoisePerlin_Grad3(noise->permutations[corner10], localX - 1.0, 0.0, localZ));
                high = CloneMCNoisePerlin_Lerp(fadeX,
                    CloneMCNoisePerlin_Grad3(noise->permutations[corner00 + 1], localX, 0.0, localZ - 1.0),
                    CloneMCNoisePerlin_Grad3(noise->permutations[corner10 + 1], localX - 1.0, 0.0, localZ - 1.0));
                result = CloneMCNoisePerlin_Lerp(fadeZ, low, high);
                values[index2D++] += result * inverse2D;
            }
        }
        return;
    }

    outputIndex = 0;
    inverseAmplitude = 1.0 / amplitude;
    previousHashY = -1;
    lerpX00 = 0.0;
    lerpX10 = 0.0;
    lerpX01 = 0.0;
    lerpX11 = 0.0;
    for (ix = 0; ix < xSize; ++ix) {
        double localX;
        int floorX;
        int hashX;
        double fadeX;
        localX = (x + (double)ix) * xScale + noise->xCoord;
        floorX = (int)localX;
        if (localX < (double)floorX) { --floorX; }
        hashX = floorX & 255;
        localX -= (double)floorX;
        fadeX = localX * localX * localX * (localX * (localX * 6.0 - 15.0) + 10.0);
        for (iz = 0; iz < zSize; ++iz) {
            double localZ;
            int floorZ;
            int hashZ;
            double fadeZ;
            localZ = (z + (double)iz) * zScale + noise->zCoord;
            floorZ = (int)localZ;
            if (localZ < (double)floorZ) { --floorZ; }
            hashZ = floorZ & 255;
            localZ -= (double)floorZ;
            fadeZ = localZ * localZ * localZ * (localZ * (localZ * 6.0 - 15.0) + 10.0);
            for (iy = 0; iy < ySize; ++iy) {
                double localY;
                int floorY;
                int hashY;
                double fadeY;
                double yBlend0;
                double yBlend1;
                double result;
                localY = (y + (double)iy) * yScale + noise->yCoord;
                floorY = (int)localY;
                if (localY < (double)floorY) { --floorY; }
                hashY = floorY & 255;
                localY -= (double)floorY;
                fadeY = localY * localY * localY * (localY * (localY * 6.0 - 15.0) + 10.0);
                if (iy == 0 || hashY != previousHashY) {
                    int x0;
                    int x0y0;
                    int x0y1;
                    int x1;
                    int x1y0;
                    int x1y1;
                    previousHashY = hashY;
                    x0 = noise->permutations[hashX] + hashY;
                    x0y0 = noise->permutations[x0] + hashZ;
                    x0y1 = noise->permutations[x0 + 1] + hashZ;
                    x1 = noise->permutations[hashX + 1] + hashY;
                    x1y0 = noise->permutations[x1] + hashZ;
                    x1y1 = noise->permutations[x1 + 1] + hashZ;
                    lerpX00 = CloneMCNoisePerlin_Lerp(fadeX,
                        CloneMCNoisePerlin_Grad3(noise->permutations[x0y0], localX, localY, localZ),
                        CloneMCNoisePerlin_Grad3(noise->permutations[x1y0], localX - 1.0, localY, localZ));
                    lerpX10 = CloneMCNoisePerlin_Lerp(fadeX,
                        CloneMCNoisePerlin_Grad3(noise->permutations[x0y1], localX, localY - 1.0, localZ),
                        CloneMCNoisePerlin_Grad3(noise->permutations[x1y1], localX - 1.0, localY - 1.0, localZ));
                    lerpX01 = CloneMCNoisePerlin_Lerp(fadeX,
                        CloneMCNoisePerlin_Grad3(noise->permutations[x0y0 + 1], localX, localY, localZ - 1.0),
                        CloneMCNoisePerlin_Grad3(noise->permutations[x1y0 + 1], localX - 1.0, localY, localZ - 1.0));
                    lerpX11 = CloneMCNoisePerlin_Lerp(fadeX,
                        CloneMCNoisePerlin_Grad3(noise->permutations[x0y1 + 1], localX, localY - 1.0, localZ - 1.0),
                        CloneMCNoisePerlin_Grad3(noise->permutations[x1y1 + 1], localX - 1.0, localY - 1.0, localZ - 1.0));
                }
                yBlend0 = CloneMCNoisePerlin_Lerp(fadeY, lerpX00, lerpX10);
                yBlend1 = CloneMCNoisePerlin_Lerp(fadeY, lerpX01, lerpX11);
                result = CloneMCNoisePerlin_Lerp(fadeZ, yBlend0, yBlend1);
                values[outputIndex++] += result * inverseAmplitude;
            }
        }
    }
}
