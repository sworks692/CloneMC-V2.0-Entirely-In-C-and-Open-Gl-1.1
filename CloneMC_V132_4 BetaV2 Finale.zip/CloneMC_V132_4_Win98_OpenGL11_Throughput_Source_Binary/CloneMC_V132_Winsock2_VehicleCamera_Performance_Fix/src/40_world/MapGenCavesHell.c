/*
 * CloneMC Java port scaffold: MapGenCavesHell
 *
 * Java source: MapGenCavesHell.java
 * Java type: class MapGenCavesHell
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: MapGenBase
 * Implements: (none declared)
 * Source SHA-256: 7eb98de893112d219d399e395776a8d75cf15b3c7a589c0dc4812fe5daf3dacb
 * Java lines: 215
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: MapGenBase, MathHelper, Block, BlockGrass, World, j, abyte0, d, d1, d2
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public MapGenCavesHell()
 * - protected void func_868_a(World world, int i, int j, int k, int l, byte abyte0[])
 *
 * Priority 11 directly implements the uploaded Hell cave count, source seeding,
 * doubled tunnel radius, lava rejection and netherrack carving below.
 */
#include "clonemc_java_port_40_world.h"

static void CloneMCJ_MapGenCavesHell_FromSource(CloneMCJavaRandom *random,
    int sourceChunkX, int sourceChunkZ, int targetChunkX, int targetChunkZ,
    CloneMCJ_Chunk *chunk)
{
    int caveCount;
    int cave;
    caveCount = CloneMCJavaRandom_NextIntBound(random,
        CloneMCJavaRandom_NextIntBound(random,
            CloneMCJavaRandom_NextIntBound(random, 10) + 1) + 1);
    if (CloneMCJavaRandom_NextIntBound(random, 5) != 0) caveCount = 0;
    for (cave = 0; cave < caveCount; ++cave) {
        double x;
        double y;
        double z;
        int tunnels;
        int tunnel;
        x = sourceChunkX * 16.0 + CloneMCJavaRandom_NextIntBound(random, 16);
        y = (double)CloneMCJavaRandom_NextIntBound(random, 128);
        z = sourceChunkZ * 16.0 + CloneMCJavaRandom_NextIntBound(random, 16);
        tunnels = 1;
        if (CloneMCJavaRandom_NextIntBound(random, 4) == 0) {
            CloneMCJ_MapGenCaves_CarveHellTunnel(random, targetChunkX, targetChunkZ,
                chunk, x, y, z, 1.0F + CloneMCJavaRandom_NextFloat(random) * 6.0F,
                0.0F, 0.0F, -1, -1, 0.5);
            tunnels += CloneMCJavaRandom_NextIntBound(random, 4);
        }
        for (tunnel = 0; tunnel < tunnels; ++tunnel) {
            float yaw;
            float pitch;
            float radius;
            yaw = CloneMCJavaRandom_NextFloat(random) * 3.141593F * 2.0F;
            pitch = ((CloneMCJavaRandom_NextFloat(random) - 0.5F) * 2.0F) / 8.0F;
            radius = (CloneMCJavaRandom_NextFloat(random) * 2.0F +
                CloneMCJavaRandom_NextFloat(random)) * 2.0F;
            CloneMCJ_MapGenCaves_CarveHellTunnel(random, targetChunkX, targetChunkZ,
                chunk, x, y, z, radius, yaw, pitch, 0, 0, 0.5);
        }
    }
}

void CloneMCJ_MapGenCavesHell_Generate(CloneMCJLong worldSeed, int targetChunkX,
    int targetChunkZ, CloneMCJ_Chunk *chunk)
{
    CloneMCJavaRandom random;
    CloneMCJLong oddX;
    CloneMCJLong oddZ;
    int sourceX;
    int sourceZ;
    if (!chunk) return;
    CloneMCJavaRandom_SetSeed(&random, worldSeed);
    oddX = (CloneMCJavaRandom_NextLong(&random) / (CloneMCJLong)2) *
        (CloneMCJLong)2 + (CloneMCJLong)1;
    oddZ = (CloneMCJavaRandom_NextLong(&random) / (CloneMCJLong)2) *
        (CloneMCJLong)2 + (CloneMCJLong)1;
    for (sourceX = targetChunkX - 8; sourceX <= targetChunkX + 8; ++sourceX)
        for (sourceZ = targetChunkZ - 8; sourceZ <= targetChunkZ + 8; ++sourceZ) {
            CloneMCJULong sourceSeed;
            sourceSeed = (CloneMCJULong)(CloneMCJLong)sourceX * (CloneMCJULong)oddX +
                (CloneMCJULong)(CloneMCJLong)sourceZ * (CloneMCJULong)oddZ;
            CloneMCJavaRandom_SetSeed(&random, (CloneMCJLong)(sourceSeed ^
                (CloneMCJULong)worldSeed));
            CloneMCJ_MapGenCavesHell_FromSource(&random, sourceX, sourceZ,
                targetChunkX, targetChunkZ, chunk);
        }
}

void CloneMCJ_MapGenCavesHell_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MapGenCavesHell_JavaName(void)
{
    return "net.minecraft.src.MapGenCavesHell";
}

const char *CloneMCJ_MapGenCavesHell_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_MapGenCavesHell_JavaSourceHash32(void)
{
    return 0x7EB98DE8UL;
}
