/*
 * CloneMC direct Java-compatible port: BiomeGenBase
 *
 * Java source: BiomeGenBase.java
 * Java type: class BiomeGenBase
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: d64a703661e5b38e2fecda36a1731ccb542a6459c2be3fe1ee94534f4cd475fa
 * Java lines: 237
 * Discovered declared fields: 11
 * Discovered declared methods/constructors: 27
 * Referenced Java classes: Block, BlockGrass, SpawnListEntry, EntitySpider, EntityZombie, EntitySkeleton, EntityCreeper, EntitySlime, EntitySheep, EntityPig, EntityChicken, EntityCow, EntitySquid, WorldGenBigTree, WorldGenTrees, EnumCreatureType, BiomeGenRainforest, BiomeGenSwamp, BiomeGenForest, BiomeGenDesert, BiomeGenTaiga, BiomeGenHell, BiomeGenSky, WorldGenerator
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public String biomeName
 * - public int color
 * - public byte topBlock
 * - public byte fillerBlock
 * - public int field_6502_q
 * - protected List spawnableMonsterList
 * - protected List spawnableCreatureList
 * - protected List spawnableWaterCreatureList
 * - private boolean enableSnow
 * - private boolean enableRain
 * - private static BiomeGenBase biomeLookupTable[] = new BiomeGenBase[4096]
 *
 * Java method/constructor inventory:
 * - protected BiomeGenBase()
 * - private BiomeGenBase setDisableRain()
 * - public static void generateBiomeLookup()
 * - public WorldGenerator getRandomWorldGenForTrees(Random random)
 * - protected BiomeGenBase setEnableSnow()
 * - protected BiomeGenBase setBiomeName(String s)
 * - protected BiomeGenBase func_4124_a(int i)
 * - protected BiomeGenBase setColor(int i)
 * - public static BiomeGenBase getBiomeFromLookup(double d, double d1)
 * - public static BiomeGenBase getBiome(float f, float f1)
 * - public int getSkyColorByTemp(float f)
 * - public List getSpawnableList(EnumCreatureType enumcreaturetype)
 * - public boolean getEnableSnow()
 * - public boolean canSpawnLightningBolt()
 * - public static final BiomeGenBase rainforest = (new BiomeGenRainforest()).setColor(0x8fa36).setBiomeName("Rainforest").func_4124_a(0x1ff458)
 * - public static final BiomeGenBase swampland = (new BiomeGenSwamp()).setColor(0x7f9b2).setBiomeName("Swampland").func_4124_a(0x8baf48)
 * - public static final BiomeGenBase seasonalForest = (new BiomeGenBase()).setColor(0x9be023).setBiomeName("Seasonal Forest")
 * - public static final BiomeGenBase forest = (new BiomeGenForest()).setColor(0x56621).setBiomeName("Forest").func_4124_a(0x4eba31)
 * - public static final BiomeGenBase savanna = (new BiomeGenDesert()).setColor(0xd9e023).setBiomeName("Savanna")
 * - public static final BiomeGenBase shrubland = (new BiomeGenBase()).setColor(0xa1ad20).setBiomeName("Shrubland")
 * - public static final BiomeGenBase taiga = (new BiomeGenTaiga()).setColor(0x2eb153).setBiomeName("Taiga").setEnableSnow().func_4124_a(0x7bb731)
 * - public static final BiomeGenBase desert = (new BiomeGenDesert()).setColor(0xfa9418).setBiomeName("Desert").setDisableRain()
 * - public static final BiomeGenBase plains = (new BiomeGenDesert()).setColor(0xffd910).setBiomeName("Plains")
 * - public static final BiomeGenBase iceDesert = (new BiomeGenDesert()).setColor(0xffed93).setBiomeName("Ice Desert").setEnableSnow().setDisableRain().func_4124_a(0xc4d339)
 * - public static final BiomeGenBase tundra = (new BiomeGenBase()).setColor(0x57ebf9).setBiomeName("Tundra").setEnableSnow().func_4124_a(0xc4d339)
 * - public static final BiomeGenBase hell = (new BiomeGenHell()).setColor(0xff0000).setBiomeName("Hell").setDisableRain()
 * - public static final BiomeGenBase sky = (new BiomeGenSky()).setColor(0x8080ff).setBiomeName("Sky").setDisableRain()
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <string.h>

static CloneMCJ_BiomeGenBase g_cloneMCJBiomes[CLONEMC_J_BIOME_COUNT];
static const CloneMCJ_BiomeGenBase *g_cloneMCJBiomeLookup[4096];
static int g_cloneMCJBiomeTableReady = 0;

void CloneMCJ_BiomeGenBase_Register(void)
{
    CloneMCJ_BiomeGenBase_InitializeTable();
}

const char *CloneMCJ_BiomeGenBase_JavaName(void)
{
    return "net.minecraft.src.BiomeGenBase";
}

const char *CloneMCJ_BiomeGenBase_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_BiomeGenBase_JavaSourceHash32(void)
{
    return 0xD64A7036UL;
}

static void CloneMCJ_BiomeGenBase_Set(CloneMCJ_BiomeGenBase *b, int id, const char *name, int color, int grassColor, int snow, int rain, int top, int filler)
{
    if (!b) { return; }
    b->biomeID = id;
    b->biomeName = name;
    b->color = color;
    b->field_6502_q = grassColor;
    b->enableSnow = (unsigned char)(snow ? 1 : 0);
    b->enableRain = (unsigned char)(rain ? 1 : 0);
    b->topBlock = (unsigned char)(top & 0xFF);
    b->fillerBlock = (unsigned char)(filler & 0xFF);
}

const CloneMCJ_BiomeGenBase *CloneMCJ_BiomeGenBase_GetBiome(float f, float f1)
{
    CloneMCJ_BiomeGenBase_InitializeTable();
    f1 *= f;
    if (f < 0.1F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_TUNDRA]; }
    if (f1 < 0.2F) {
        if (f < 0.5F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_TUNDRA]; }
        if (f < 0.95F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_SAVANNA]; }
        return &g_cloneMCJBiomes[CLONEMC_J_BIOME_DESERT];
    }
    if (f1 > 0.5F && f < 0.7F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_SWAMPLAND]; }
    if (f < 0.5F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_TAIGA]; }
    if (f < 0.97F) {
        if (f1 < 0.35F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_SHRUBLAND]; }
        return &g_cloneMCJBiomes[CLONEMC_J_BIOME_FOREST];
    }
    if (f1 < 0.45F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_PLAINS]; }
    if (f1 < 0.9F) { return &g_cloneMCJBiomes[CLONEMC_J_BIOME_SEASONAL_FOREST]; }
    return &g_cloneMCJBiomes[CLONEMC_J_BIOME_RAINFOREST];
}

void CloneMCJ_BiomeGenBase_InitializeTable(void)
{
    int i;
    int j;
    if (g_cloneMCJBiomeTableReady) { return; }
    g_cloneMCJBiomeTableReady = 1;
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_RAINFOREST], CLONEMC_J_BIOME_RAINFOREST, "Rainforest", 0x08FA36, 0x1FF458, 0, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_SWAMPLAND], CLONEMC_J_BIOME_SWAMPLAND, "Swampland", 0x07F9B2, 0x8BAF48, 0, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_SEASONAL_FOREST], CLONEMC_J_BIOME_SEASONAL_FOREST, "Seasonal Forest", 0x9BE023, 0x4EE031, 0, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_FOREST], CLONEMC_J_BIOME_FOREST, "Forest", 0x056621, 0x4EBA31, 0, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_SAVANNA], CLONEMC_J_BIOME_SAVANNA, "Savanna", 0xD9E023, 0x4EE031, 0, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_SHRUBLAND], CLONEMC_J_BIOME_SHRUBLAND, "Shrubland", 0xA1AD20, 0x4EE031, 0, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_TAIGA], CLONEMC_J_BIOME_TAIGA, "Taiga", 0x2EB153, 0x7BB731, 1, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_DESERT], CLONEMC_J_BIOME_DESERT, "Desert", 0xFA9418, 0x4EE031, 0, 0, CLONEMC_J_BLOCK_SAND, CLONEMC_J_BLOCK_SAND);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_PLAINS], CLONEMC_J_BIOME_PLAINS, "Plains", 0xFFD910, 0x4EE031, 0, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_ICE_DESERT], CLONEMC_J_BIOME_ICE_DESERT, "Ice Desert", 0xFFED93, 0xC4D339, 1, 0, CLONEMC_J_BLOCK_SAND, CLONEMC_J_BLOCK_SAND);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_TUNDRA], CLONEMC_J_BIOME_TUNDRA, "Tundra", 0x57EBF9, 0xC4D339, 1, 1, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_HELL], CLONEMC_J_BIOME_HELL, "Hell", 0xFF0000, 0x4EE031, 0, 0, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    CloneMCJ_BiomeGenBase_Set(&g_cloneMCJBiomes[CLONEMC_J_BIOME_SKY], CLONEMC_J_BIOME_SKY, "Sky", 0x8080FF, 0x4EE031, 0, 0, CLONEMC_J_BLOCK_GRASS, CLONEMC_J_BLOCK_DIRT);
    for (i = 0; i < 64; ++i) {
        for (j = 0; j < 64; ++j) {
            g_cloneMCJBiomeLookup[i + j * 64] = CloneMCJ_BiomeGenBase_GetBiome((float)i / 63.0F, (float)j / 63.0F);
        }
    }
}

const CloneMCJ_BiomeGenBase *CloneMCJ_BiomeGenBase_GetByID(int biomeID)
{
    CloneMCJ_BiomeGenBase_InitializeTable();
    if (biomeID < 0 || biomeID >= CLONEMC_J_BIOME_COUNT) { biomeID = CLONEMC_J_BIOME_PLAINS; }
    return &g_cloneMCJBiomes[biomeID];
}

const CloneMCJ_BiomeGenBase *CloneMCJ_BiomeGenBase_GetBiomeFromLookup(double temperature, double humidity)
{
    int i;
    int j;
    CloneMCJ_BiomeGenBase_InitializeTable();
    if (temperature < 0.0) { temperature = 0.0; }
    if (humidity < 0.0) { humidity = 0.0; }
    if (temperature > 1.0) { temperature = 1.0; }
    if (humidity > 1.0) { humidity = 1.0; }
    i = (int)(temperature * 63.0);
    j = (int)(humidity * 63.0);
    return g_cloneMCJBiomeLookup[i + j * 64];
}

int CloneMCJ_BiomeGenBase_GetEnableSnow(const CloneMCJ_BiomeGenBase *biome)
{
    return biome ? biome->enableSnow != 0 : 0;
}

int CloneMCJ_BiomeGenBase_CanSpawnLightningBolt(const CloneMCJ_BiomeGenBase *biome)
{
    if (!biome) { return 0; }
    if (biome->enableSnow) { return 0; }
    return biome->enableRain != 0;
}

static void CloneMCJ_Biome_TestMessage(char *message, unsigned int capacity, const char *text)
{
    if (!message || capacity == 0U) { return; }
    strncpy(message, text ? text : "", (size_t)capacity - 1U);
    message[capacity - 1U] = '\0';
}

int CloneMCJ_BiomeGenBase_RunSelfTests(char *message, unsigned int messageCapacity)
{
    const CloneMCJ_BiomeGenBase *desert;
    const CloneMCJ_BiomeGenBase *tundra;
    CloneMCJ_BiomeGenBase_InitializeTable();
    desert = CloneMCJ_BiomeGenBase_GetBiome(1.0F, 0.0F);
    tundra = CloneMCJ_BiomeGenBase_GetBiome(0.0F, 1.0F);
    if (!desert || desert->biomeID != CLONEMC_J_BIOME_DESERT || desert->topBlock != CLONEMC_J_BLOCK_SAND) {
        CloneMCJ_Biome_TestMessage(message, messageCapacity, "Biome lookup desert path failed");
        return 0;
    }
    if (!tundra || tundra->biomeID != CLONEMC_J_BIOME_TUNDRA || !tundra->enableSnow) {
        CloneMCJ_Biome_TestMessage(message, messageCapacity, "Biome lookup tundra path failed");
        return 0;
    }
    CloneMCJ_Biome_TestMessage(message, messageCapacity, "Priority4 biome lookup self-tests passed");
    return 1;
}


int CloneMCJ_BiomeGenBase_GenerateDefaultTree(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z)
{
    if (!world || !random) { return 0; }
    if (CloneMCJavaRandom_NextIntBound(random, 10) == 0) {
        return CloneMCJ_WorldGenBigTree_Generate(world, random, x, y, z);
    }
    return CloneMCJ_WorldGenTrees_Generate(world, random, x, y, z);
}

int CloneMCJ_BiomeGenBase_GenerateTree(const CloneMCJ_BiomeGenBase *biome, CloneMCJ_World *world,
    CloneMCJavaRandom *random, int x, int y, int z)
{
    int id;
    if (!world || !random) { return 0; }
    id = biome ? biome->biomeID : CLONEMC_J_BIOME_PLAINS;
    if (id == CLONEMC_J_BIOME_FOREST) {
        return CloneMCJ_BiomeGenForest_GenerateTree(world, random, x, y, z);
    }
    if (id == CLONEMC_J_BIOME_RAINFOREST) {
        return CloneMCJ_BiomeGenRainforest_GenerateTree(world, random, x, y, z);
    }
    if (id == CLONEMC_J_BIOME_TAIGA) {
        return CloneMCJ_BiomeGenTaiga_GenerateTree(world, random, x, y, z);
    }
    return CloneMCJ_BiomeGenBase_GenerateDefaultTree(world, random, x, y, z);
}
