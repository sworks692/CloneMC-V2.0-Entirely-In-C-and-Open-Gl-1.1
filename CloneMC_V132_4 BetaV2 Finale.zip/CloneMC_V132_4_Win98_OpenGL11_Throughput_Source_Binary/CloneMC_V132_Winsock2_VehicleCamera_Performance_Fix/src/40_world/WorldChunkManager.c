/*
 * CloneMC direct Java-compatible port: WorldChunkManager
 *
 * Java source: WorldChunkManager.java
 * Java type: class WorldChunkManager
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 6bd4f7b1e9ef89713ac0fe890541e6fdc11a91d726cbdbf9f5c21de7bf87ba82
 * Java lines: 139
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: NoiseGeneratorOctaves2, World, ChunkCoordIntPair, BiomeGenBase, j, i, k, l
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private NoiseGeneratorOctaves2 field_4194_e
 * - private NoiseGeneratorOctaves2 field_4193_f
 * - private NoiseGeneratorOctaves2 field_4192_g
 * - public double temperature[]
 * - public double humidity[]
 * - public double field_4196_c[]
 * - public BiomeGenBase field_4195_d[]
 *
 * Java method/constructor inventory:
 * - protected WorldChunkManager()
 * - public WorldChunkManager(World world)
 * - public BiomeGenBase getBiomeGenAtChunkCoord(ChunkCoordIntPair chunkcoordintpair)
 * - public BiomeGenBase getBiomeGenAt(int i, int j)
 * - public double getTemperature(int i, int j)
 * - public BiomeGenBase[] func_4069_a(int i, int j, int k, int l)
 * - public double[] getTemperatures(double ad[], int i, int j, int k, int l)
 * - public BiomeGenBase[] loadBlockGeneratorData(BiomeGenBase abiomegenbase[], int i, int j, int k, int l)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <string.h>

void CloneMCJ_WorldChunkManager_Register(void)
{
    CloneMCJ_BiomeGenBase_InitializeTable();
}

const char *CloneMCJ_WorldChunkManager_JavaName(void)
{
    return "net.minecraft.src.WorldChunkManager";
}

const char *CloneMCJ_WorldChunkManager_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldChunkManager_JavaSourceHash32(void)
{
    return 0x6BD4F7B1UL;
}

static CloneMCJLong CloneMCJ_WCM_MulLong(CloneMCJLong a, CloneMCJLong b)
{
    return (CloneMCJLong)((CloneMCJULong)a * (CloneMCJULong)b);
}

int CloneMCJ_WorldChunkManager_Initialize(CloneMCJ_WorldChunkManager *manager, CloneMCJLong worldSeed)
{
    CloneMCJavaRandom random;
    if (!manager) { return 0; }
    memset(manager, 0, sizeof(*manager));
    CloneMCJ_BiomeGenBase_InitializeTable();
    manager->worldSeed = worldSeed;
    CloneMCJavaRandom_SetSeed(&random, CloneMCJ_WCM_MulLong(worldSeed, (CloneMCJLong)9871L));
    if (!CloneMCNoiseOctaves2_Initialize(&manager->field_4194_e, &random, 4)) { return 0; }
    CloneMCJavaRandom_SetSeed(&random, CloneMCJ_WCM_MulLong(worldSeed, (CloneMCJLong)39811L));
    if (!CloneMCNoiseOctaves2_Initialize(&manager->field_4193_f, &random, 4)) { CloneMCNoiseOctaves2_Destroy(&manager->field_4194_e); return 0; }
    CloneMCJavaRandom_SetSeed(&random, CloneMCJ_WCM_MulLong(worldSeed, (CloneMCJLong)543321L));
    if (!CloneMCNoiseOctaves2_Initialize(&manager->field_4192_g, &random, 2)) { CloneMCNoiseOctaves2_Destroy(&manager->field_4194_e); CloneMCNoiseOctaves2_Destroy(&manager->field_4193_f); return 0; }
    manager->initialized = 1;
    return 1;
}

void CloneMCJ_WorldChunkManager_Destroy(CloneMCJ_WorldChunkManager *manager)
{
    if (!manager || !manager->initialized) { return; }
    if (!manager->fixedMode) {
        CloneMCNoiseOctaves2_Destroy(&manager->field_4194_e);
        CloneMCNoiseOctaves2_Destroy(&manager->field_4193_f);
        CloneMCNoiseOctaves2_Destroy(&manager->field_4192_g);
    }
    manager->initialized = 0;
    manager->fixedMode = 0;
}

double *CloneMCJ_WorldChunkManager_GetTemperatures(CloneMCJ_WorldChunkManager *manager, double *outValues, int blockX, int blockZ, int width, int depth)
{
    int index;
    int x;
    int z;
    double d;
    double d1;
    double d2;
    double d3;
    if (!manager || !manager->initialized || width <= 0 || depth <= 0) { return 0; }
    if (!outValues) { outValues = manager->temperature; }
    if (manager->fixedMode) {
        for (index = 0; index < width * depth; ++index)
            outValues[index] = manager->fixedTemperature;
        return outValues;
    }
    CloneMCNoiseOctaves2_Generate(&manager->field_4194_e, outValues, (unsigned long)(width * depth), (double)blockX, (double)blockZ, width, depth, 0.02500000037252903, 0.02500000037252903, 0.25, 0.5);
    CloneMCNoiseOctaves2_Generate(&manager->field_4192_g, manager->field_4196_c, (unsigned long)(width * depth), (double)blockX, (double)blockZ, width, depth, 0.25, 0.25, 0.58823529411764708, 0.5);
    index = 0;
    for (x = 0; x < width; ++x) {
        for (z = 0; z < depth; ++z) {
            d = manager->field_4196_c[index] * 1.1000000000000001 + 0.5;
            d1 = 0.01;
            d2 = 1.0 - d1;
            d3 = (outValues[index] * 0.14999999999999999 + 0.69999999999999996) * d2 + d * d1;
            d3 = 1.0 - (1.0 - d3) * (1.0 - d3);
            if (d3 < 0.0) { d3 = 0.0; }
            if (d3 > 1.0) { d3 = 1.0; }
            outValues[index] = d3;
            ++index;
        }
    }
    return outValues;
}

double CloneMCJ_WorldChunkManager_GetTemperature(CloneMCJ_WorldChunkManager *manager, int blockX, int blockZ)
{
    double temp[1];
    if (!manager || !manager->initialized) { return 0.5; }
    if (manager->fixedMode) return manager->fixedTemperature;
    if (!CloneMCNoiseOctaves2_Generate(&manager->field_4194_e, temp, 1UL,
        (double)blockX, (double)blockZ, 1, 1,
        0.02500000037252903, 0.02500000037252903, 0.5, 0.5)) {
        return 0.5;
    }
    return temp[0];
}

double CloneMCJ_WorldChunkManager_GetHumidity(CloneMCJ_WorldChunkManager *manager, int blockX, int blockZ)
{
    const CloneMCJ_BiomeGenBase *biomes[1];
    if (!manager || !manager->initialized) return 0.5;
    if (manager->fixedMode) return manager->fixedHumidity;
    if (!CloneMCJ_WorldChunkManager_LoadBlockGeneratorData(manager, biomes,
        blockX, blockZ, 1, 1)) return 0.5;
    return manager->humidity[0];
}

const CloneMCJ_BiomeGenBase **CloneMCJ_WorldChunkManager_LoadBlockGeneratorData(CloneMCJ_WorldChunkManager *manager, const CloneMCJ_BiomeGenBase **outBiomes, int blockX, int blockZ, int width, int depth)
{
    int index;
    int x;
    int z;
    double d;
    double d1;
    double d2;
    double d3;
    double d4;
    if (!manager || !manager->initialized || width <= 0 || depth <= 0) { return 0; }
    if (!outBiomes) { outBiomes = manager->field_4195_d; }
    if (manager->fixedMode) {
        const CloneMCJ_BiomeGenBase *fixed;
        fixed = CloneMCJ_BiomeGenBase_GetByID(manager->fixedBiomeID);
        for (index = 0; index < width * depth; ++index) {
            outBiomes[index] = fixed;
            manager->temperature[index] = manager->fixedTemperature;
            manager->humidity[index] = manager->fixedHumidity;
        }
        return outBiomes;
    }
    CloneMCNoiseOctaves2_Generate(&manager->field_4194_e, manager->temperature, (unsigned long)(width * depth), (double)blockX, (double)blockZ, width, depth, 0.02500000037252903, 0.02500000037252903, 0.25, 0.5);
    CloneMCNoiseOctaves2_Generate(&manager->field_4193_f, manager->humidity, (unsigned long)(width * depth), (double)blockX, (double)blockZ, width, depth, 0.05000000074505806, 0.05000000074505806, 0.33333333333333331, 0.5);
    CloneMCNoiseOctaves2_Generate(&manager->field_4192_g, manager->field_4196_c, (unsigned long)(width * depth), (double)blockX, (double)blockZ, width, depth, 0.25, 0.25, 0.58823529411764708, 0.5);
    index = 0;
    for (x = 0; x < width; ++x) {
        for (z = 0; z < depth; ++z) {
            d = manager->field_4196_c[index] * 1.1000000000000001 + 0.5;
            d1 = 0.01;
            d2 = 1.0 - d1;
            d3 = (manager->temperature[index] * 0.14999999999999999 + 0.69999999999999996) * d2 + d * d1;
            d1 = 0.002;
            d2 = 1.0 - d1;
            d4 = (manager->humidity[index] * 0.14999999999999999 + 0.5) * d2 + d * d1;
            d3 = 1.0 - (1.0 - d3) * (1.0 - d3);
            if (d3 < 0.0) { d3 = 0.0; }
            if (d4 < 0.0) { d4 = 0.0; }
            if (d3 > 1.0) { d3 = 1.0; }
            if (d4 > 1.0) { d4 = 1.0; }
            manager->temperature[index] = d3;
            manager->humidity[index] = d4;
            outBiomes[index] = CloneMCJ_BiomeGenBase_GetBiomeFromLookup(d3, d4);
            ++index;
        }
    }
    return outBiomes;
}

const CloneMCJ_BiomeGenBase *CloneMCJ_WorldChunkManager_GetBiomeGenAt(CloneMCJ_WorldChunkManager *manager, int blockX, int blockZ)
{
    const CloneMCJ_BiomeGenBase **biomes;
    if (manager && manager->initialized && manager->fixedMode)
        return CloneMCJ_BiomeGenBase_GetByID(manager->fixedBiomeID);
    biomes = CloneMCJ_WorldChunkManager_LoadBlockGeneratorData(manager, manager ? manager->field_4195_d : 0, blockX, blockZ, 1, 1);
    if (!biomes) { return CloneMCJ_BiomeGenBase_GetByID(CLONEMC_J_BIOME_PLAINS); }
    return biomes[0];
}

static void CloneMCJ_WCM_TestMessage(char *message, unsigned int capacity, const char *text)
{
    if (!message || capacity == 0U) { return; }
    strncpy(message, text ? text : "", (size_t)capacity - 1U);
    message[capacity - 1U] = '\0';
}

int CloneMCJ_WorldChunkManager_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJ_WorldChunkManager manager;
    const CloneMCJ_BiomeGenBase **biomes;
    double *temps;
    if (!CloneMCJ_WorldChunkManager_Initialize(&manager, (CloneMCJLong)12345L)) {
        CloneMCJ_WCM_TestMessage(message, messageCapacity, "WorldChunkManager allocation failed");
        return 0;
    }
    biomes = CloneMCJ_WorldChunkManager_LoadBlockGeneratorData(&manager, 0, -32, 48, 16, 16);
    temps = CloneMCJ_WorldChunkManager_GetTemperatures(&manager, 0, -32, 48, 16, 16);
    if (!biomes || !temps || !biomes[0] || temps[0] < 0.0 || temps[0] > 1.0) {
        CloneMCJ_WorldChunkManager_Destroy(&manager);
        CloneMCJ_WCM_TestMessage(message, messageCapacity, "WorldChunkManager climate output invalid");
        return 0;
    }
    CloneMCJ_WorldChunkManager_Destroy(&manager);
    CloneMCJ_WCM_TestMessage(message, messageCapacity, "Priority4 WorldChunkManager self-tests passed");
    return 1;
}
