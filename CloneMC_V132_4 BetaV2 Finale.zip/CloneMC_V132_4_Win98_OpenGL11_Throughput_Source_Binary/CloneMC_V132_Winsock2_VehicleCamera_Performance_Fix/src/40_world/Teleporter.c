/*
 * Direct, bounded C89 conversion of Teleporter.java for the Beta Nether path.
 * Existing portals are searched only in resident chunks so entering a portal
 * cannot synchronously generate thousands of chunks.  When no portal exists,
 * the Java 4x5 obsidian/portal shape is constructed in a safe loaded area.
 */
#include "clonemc_java_port_40_world.h"
#include "../20_entity/clonemc_java_port_20_entity.h"
#include "../30_item/clonemc_java_port_30_item.h"
#include <math.h>

#define CLONEMC_J_TELEPORTER_PORTAL 90
#define CLONEMC_J_TELEPORTER_OBSIDIAN 49

static int CloneMCJ_Teleporter_Solid(CloneMCJ_World *world,int x,int y,int z)
{
    const CloneMCJ_BlockDefinition *block;
    int id;
    id=CloneMCJ_World_GetBlockId(world,x,y,z);
    block=CloneMCJ_BlockRegistry_Get(id);
    return block&&block->solid;
}

static int CloneMCJ_Teleporter_ChunkWithinRadius(const CloneMCJ_Chunk *chunk,
    int baseX,int baseZ,int radius)
{
    int minX,maxX,minZ,maxZ,nearestX,nearestZ,dx,dz;
    if(!chunk)return 0;
    minX=chunk->xPosition<<4;maxX=minX+15;
    minZ=chunk->zPosition<<4;maxZ=minZ+15;
    nearestX=baseX<minX?minX:(baseX>maxX?maxX:baseX);
    nearestZ=baseZ<minZ?minZ:(baseZ>maxZ?maxZ:baseZ);
    dx=nearestX-baseX;dz=nearestZ-baseZ;
    return dx*dx+dz*dz<=radius*radius;
}

int CloneMCJ_Teleporter_FindPortal(CloneMCJ_World *world,CloneMCJ_Entity *entity,int radius)
{
    double best,distance,dx,dy,dz;
    int baseX,baseZ,slotIndex,localX,localZ,y,x,z,bestX,bestY,bestZ,found;
    CloneMCJ_ChunkCacheSlot *slot;
    CloneMCJ_Chunk *chunk;
    if(!world||!entity)return 0;
    if(radius<1)radius=1;if(radius>128)radius=128;
    baseX=CloneMCJava_FloorDouble(entity->posX);
    baseZ=CloneMCJava_FloorDouble(entity->posZ);
    best=-1.0;bestX=bestY=bestZ=0;found=0;

    /* Java searches 128 blocks around the entity.  Scanning every possible
     * coordinate through World_GetLoadedBlockId is prohibitively expensive in
     * a bounded 2,304-slot provider because each lookup itself must locate a
     * resident chunk.  Iterate the resident chunks directly instead.  This
     * preserves the Java search radius, never generates terrain, and makes a
     * dimension transfer proportional to the chunks that actually exist. */
    for(slotIndex=0;slotIndex<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slotIndex){
        slot=&world->chunkProvider.slots[slotIndex];
        if(!slot->used||!slot->chunk||!slot->chunk->loaded)continue;
        chunk=slot->chunk;
        if(!CloneMCJ_Teleporter_ChunkWithinRadius(chunk,baseX,baseZ,radius))continue;
        for(localX=0;localX<16;++localX){
            x=(chunk->xPosition<<4)+localX;
            dx=(double)x+0.5-entity->posX;
            if(dx*dx>(double)radius*(double)radius)continue;
            for(localZ=0;localZ<16;++localZ){
                z=(chunk->zPosition<<4)+localZ;
                dz=(double)z+0.5-entity->posZ;
                if(dx*dx+dz*dz>(double)radius*(double)radius)continue;
                for(y=127;y>=0;--y){
                    if(CloneMCJ_Chunk_GetBlockID(chunk,localX,y,localZ)!=CLONEMC_J_TELEPORTER_PORTAL)continue;
                    while(y>0&&CloneMCJ_Chunk_GetBlockID(chunk,localX,y-1,localZ)==CLONEMC_J_TELEPORTER_PORTAL)--y;
                    dy=(double)y+0.5-entity->posY;
                    distance=dx*dx+dy*dy+dz*dz;
                    if(best<0.0||distance<best){best=distance;bestX=x;bestY=y;bestZ=z;found=1;}
                }
            }
        }
    }
    if(!found)return 0;
    entity->motionX=entity->motionY=entity->motionZ=0.0;
    CloneMCJ_Entity_SetPosition(entity,(double)bestX+0.5,(double)bestY+0.5,(double)bestZ+0.5);
    if(CloneMCJ_World_GetLoadedBlockId(world,bestX-1,bestY,bestZ)==CLONEMC_J_TELEPORTER_PORTAL)
        CloneMCJ_Entity_SetPosition(entity,entity->posX-0.5,entity->posY,entity->posZ);
    if(CloneMCJ_World_GetLoadedBlockId(world,bestX+1,bestY,bestZ)==CLONEMC_J_TELEPORTER_PORTAL)
        CloneMCJ_Entity_SetPosition(entity,entity->posX+0.5,entity->posY,entity->posZ);
    if(CloneMCJ_World_GetLoadedBlockId(world,bestX,bestY,bestZ-1)==CLONEMC_J_TELEPORTER_PORTAL)
        CloneMCJ_Entity_SetPosition(entity,entity->posX,entity->posY,entity->posZ-0.5);
    if(CloneMCJ_World_GetLoadedBlockId(world,bestX,bestY,bestZ+1)==CLONEMC_J_TELEPORTER_PORTAL)
        CloneMCJ_Entity_SetPosition(entity,entity->posX,entity->posY,entity->posZ+0.5);
    entity->rotationPitch=0.0F;
    return 1;
}

static int CloneMCJ_Teleporter_AreaFits(CloneMCJ_World *world,int x,int y,int z,int dx,int dz)
{
    int width,side,height,wx,wy,wz;
    for(side=-1;side<=1;++side)for(width=0;width<4;++width)for(height=-1;height<4;++height){
        wx=x+(width-1)*dx+side*dz;
        wy=y+height;
        wz=z+(width-1)*dz-side*dx;
        if(wy<1||wy>=127)return 0;
        if(height<0){if(!CloneMCJ_Teleporter_Solid(world,wx,wy,wz))return 0;}
        else if(CloneMCJ_World_GetBlockId(world,wx,wy,wz)!=0)return 0;
    }
    return 1;
}

static void CloneMCJ_Teleporter_Build(CloneMCJ_World *world,int x,int y,int z,int dx,int dz)
{
    int width,height,wx,wy,wz,border,pass;
    for(pass=0;pass<2;++pass){
        world->editingBlocks=1;
        for(width=0;width<4;++width)for(height=-1;height<4;++height){
            wx=x+(width-1)*dx;wy=y+height;wz=z+(width-1)*dz;
            border=(width==0||width==3||height==-1||height==3);
            CloneMCJ_World_SetBlockWithMetadataNotify(world,wx,wy,wz,
                border?CLONEMC_J_TELEPORTER_OBSIDIAN:CLONEMC_J_TELEPORTER_PORTAL,dx?1:2);
        }
        world->editingBlocks=0;
        for(width=0;width<4;++width)for(height=-1;height<4;++height){
            wx=x+(width-1)*dx;wy=y+height;wz=z+(width-1)*dz;
            CloneMCJ_World_NotifyBlocksOfNeighborChange(world,wx,wy,wz,
                CloneMCJ_World_GetBlockId(world,wx,wy,wz));
        }
    }
}

int CloneMCJ_Teleporter_CreatePortal(CloneMCJ_World *world,CloneMCJ_Entity *entity)
{
    double best,distance,dxDistance,dyDistance,dzDistance;
    int baseX,baseY,baseZ,slotIndex,localX,localZ,x,y,z,orientation,dx,dz;
    int bestX,bestY,bestZ,bestOrientation;
    CloneMCJ_ChunkCacheSlot *slot;
    CloneMCJ_Chunk *chunk;
    if(!world||!entity)return 0;
    baseX=CloneMCJava_FloorDouble(entity->posX);
    baseY=CloneMCJava_FloorDouble(entity->posY);
    baseZ=CloneMCJava_FloorDouble(entity->posZ);
    best=-1.0;bestX=baseX;bestY=baseY;bestZ=baseZ;bestOrientation=0;

    /* Search only currently resident terrain within Java's 16-block portal
     * construction radius.  Direct chunk iteration avoids millions of cache
     * probes during the transfer frame and guarantees that portal lookup does
     * not become an implicit chunk-generation burst. */
    for(slotIndex=0;slotIndex<CLONEMC_J_CHUNK_CACHE_CAPACITY;++slotIndex){
        slot=&world->chunkProvider.slots[slotIndex];
        if(!slot->used||!slot->chunk||!slot->chunk->loaded)continue;
        chunk=slot->chunk;
        if(!CloneMCJ_Teleporter_ChunkWithinRadius(chunk,baseX,baseZ,16))continue;
        for(localX=0;localX<16;++localX){
            x=(chunk->xPosition<<4)+localX;
            if(x<baseX-16||x>baseX+16)continue;
            for(localZ=0;localZ<16;++localZ){
                z=(chunk->zPosition<<4)+localZ;
                if(z<baseZ-16||z>baseZ+16)continue;
                for(y=127;y>=1;--y){
                    if(CloneMCJ_Chunk_GetBlockID(chunk,localX,y,localZ)!=0)continue;
                    while(y>1&&CloneMCJ_Chunk_GetBlockID(chunk,localX,y-1,localZ)==0)--y;
                    for(orientation=0;orientation<2;++orientation){
                        dx=orientation;dz=1-orientation;
                        if(!CloneMCJ_Teleporter_AreaFits(world,x,y,z,dx,dz))continue;
                        dxDistance=(double)x+0.5-entity->posX;
                        dyDistance=(double)y+0.5-entity->posY;
                        dzDistance=(double)z+0.5-entity->posZ;
                        distance=dxDistance*dxDistance+dyDistance*dyDistance+dzDistance*dzDistance;
                        if(best<0.0||distance<best){best=distance;bestX=x;bestY=y;bestZ=z;bestOrientation=orientation;}
                    }
                }
            }
        }
    }
    if(best<0.0){
        bestY=baseY;if(bestY<70)bestY=70;if(bestY>118)bestY=118;
        bestX=baseX;bestZ=baseZ;bestOrientation=(CloneMCJavaRandom_NextIntBound(&world->rand,2));
        dx=bestOrientation;dz=1-bestOrientation;
        /* Java fallback platform: guarantee solid floor and clear headroom. */
        for(x=-1;x<=1;++x)for(z=0;z<2;++z)for(y=-1;y<4;++y){
            int wx,wz;wx=bestX+(z-1)*dx+x*dz;wz=bestZ+(z-1)*dz-x*dx;
            CloneMCJ_World_SetBlockNotify(world,wx,bestY+y,wz,y<0?CLONEMC_J_TELEPORTER_OBSIDIAN:0);
        }
    }
    dx=bestOrientation;dz=1-bestOrientation;
    CloneMCJ_Teleporter_Build(world,bestX,bestY,bestZ,dx,dz);
    CloneMCJ_Entity_SetPosition(entity,(double)bestX+0.5,(double)bestY+0.5,(double)bestZ+0.5);
    entity->motionX=entity->motionY=entity->motionZ=0.0;
    return 1;
}

int CloneMCJ_Teleporter_PlaceInPortal(CloneMCJ_World *world,CloneMCJ_Entity *entity)
{
    if(CloneMCJ_Teleporter_FindPortal(world,entity,128))return 1;
    if(!CloneMCJ_Teleporter_CreatePortal(world,entity))return 0;
    return CloneMCJ_Teleporter_FindPortal(world,entity,32);
}

void CloneMCJ_Teleporter_Register(void){}
const char *CloneMCJ_Teleporter_JavaName(void){return "net.minecraft.src.Teleporter";}
const char *CloneMCJ_Teleporter_AssignedFolder(void){return "src/40_world";}
unsigned long CloneMCJ_Teleporter_JavaSourceHash32(void){return 0xD43C86BFUL;}
