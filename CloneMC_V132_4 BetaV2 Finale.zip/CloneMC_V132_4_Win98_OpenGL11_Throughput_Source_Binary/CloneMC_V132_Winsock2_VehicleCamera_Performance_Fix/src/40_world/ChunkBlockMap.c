/*
 * CloneMC Java port scaffold: ChunkBlockMap
 *
 * Java source: ChunkBlockMap.java
 * Java type: class ChunkBlockMap
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 972f49e78524e33ea2b8794148eb7ca77eea990b242b753fb1579e2e48a1fe40
 * Java lines: 51
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: Block, static, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static byte field_26003_a[]
 *
 * Java method/constructor inventory:
 * - public ChunkBlockMap()
 * - public static void func_26002_a(byte abyte0[])
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_ChunkBlockMap_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkBlockMap_JavaName(void)
{
    return "net.minecraft.src.ChunkBlockMap";
}

const char *CloneMCJ_ChunkBlockMap_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkBlockMap_JavaSourceHash32(void)
{
    return 0x972F49E7UL;
}

/* Priority 3 ChunkBlockMap implementation. */
static unsigned char CloneMCJ_ChunkBlockMap_Table[CLONEMC_J_CHUNK_BLOCK_MAP_SIZE];
static unsigned char CloneMCJ_ChunkBlockMap_Initialized = 0;

void CloneMCJ_ChunkBlockMap_Reset(void)
{
    unsigned int i;
    for (i = 0; i < CLONEMC_J_CHUNK_BLOCK_MAP_SIZE; ++i) {
        CloneMCJ_ChunkBlockMap_Table[i] = (unsigned char)i;
    }
    CloneMCJ_ChunkBlockMap_Initialized = 1;
}

void CloneMCJ_ChunkBlockMap_CopyFrom(const unsigned char *source, unsigned int count)
{
    unsigned int i;
    CloneMCJ_ChunkBlockMap_Reset();
    if (!source) { return; }
    if (count > CLONEMC_J_CHUNK_BLOCK_MAP_SIZE) { count = CLONEMC_J_CHUNK_BLOCK_MAP_SIZE; }
    for (i = 0; i < count; ++i) { CloneMCJ_ChunkBlockMap_Table[i] = source[i]; }
}

unsigned char CloneMCJ_ChunkBlockMap_MapBlock(unsigned char blockID)
{
    if (!CloneMCJ_ChunkBlockMap_Initialized) { CloneMCJ_ChunkBlockMap_Reset(); }
    return CloneMCJ_ChunkBlockMap_Table[blockID & 0xFFU];
}

void CloneMCJ_ChunkBlockMap_Func26002A(unsigned char *blocks, unsigned long count)
{
    unsigned long i;
    if (!blocks) { return; }
    if (!CloneMCJ_ChunkBlockMap_Initialized) { CloneMCJ_ChunkBlockMap_Reset(); }
    for (i = 0; i < count; ++i) { blocks[i] = CloneMCJ_ChunkBlockMap_MapBlock(blocks[i]); }
}
