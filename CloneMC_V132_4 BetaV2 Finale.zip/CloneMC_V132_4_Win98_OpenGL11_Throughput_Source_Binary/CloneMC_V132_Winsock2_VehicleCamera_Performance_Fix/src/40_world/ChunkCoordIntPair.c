/*
 * CloneMC Java port scaffold: ChunkCoordIntPair
 *
 * Java source: ChunkCoordIntPair.java
 * Java type: class ChunkCoordIntPair
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 946712c75472e0a73e92d8ff37e01c8564347df695ecdfdbe86dd13a9b865d55
 * Java lines: 36
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final int chunkXPos
 * - public final int chunkZPos
 *
 * Java method/constructor inventory:
 * - public ChunkCoordIntPair(int i, int j)
 * - public static int chunkXZ2Int(int i, int j)
 * - public int hashCode()
 * - public boolean equals(Object obj)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_ChunkCoordIntPair_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkCoordIntPair_JavaName(void)
{
    return "net.minecraft.src.ChunkCoordIntPair";
}

const char *CloneMCJ_ChunkCoordIntPair_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkCoordIntPair_JavaSourceHash32(void)
{
    return 0x946712C7UL;
}

/* Priority 3 direct implementation from ChunkCoordIntPair.java. */
void CloneMCJ_ChunkCoordIntPair_Initialize(CloneMCJ_ChunkCoordIntPair *pair, int chunkX, int chunkZ)
{
    if (!pair) { return; }
    pair->chunkXPos = chunkX;
    pair->chunkZPos = chunkZ;
}

CloneMCJInt CloneMCJ_ChunkCoordIntPair_ChunkXZ2Int(int chunkX, int chunkZ)
{
    CloneMCJUInt xPart;
    CloneMCJUInt zPart;
    xPart = ((CloneMCJUInt)(chunkX & 0x7FFF)) << 16;
    zPart = (CloneMCJUInt)(chunkZ & 0x7FFF);
    if (chunkX < 0) { xPart |= (CloneMCJUInt)0x80000000UL; }
    if (chunkZ < 0) { zPart |= (CloneMCJUInt)0x00008000UL; }
    return (CloneMCJInt)(xPart | zPart);
}

CloneMCJInt CloneMCJ_ChunkCoordIntPair_HashCode(const CloneMCJ_ChunkCoordIntPair *pair)
{
    if (!pair) { return 0; }
    return CloneMCJ_ChunkCoordIntPair_ChunkXZ2Int(pair->chunkXPos, pair->chunkZPos);
}

int CloneMCJ_ChunkCoordIntPair_Equals(const CloneMCJ_ChunkCoordIntPair *left, const CloneMCJ_ChunkCoordIntPair *right)
{
    if (!left || !right) { return 0; }
    return left->chunkXPos == right->chunkXPos && left->chunkZPos == right->chunkZPos;
}
