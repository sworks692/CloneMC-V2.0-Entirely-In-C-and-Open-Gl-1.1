/*
 * CloneMC direct Java-compatible port: WorldGenLiquids
 *
 * Java source: WorldGenLiquids.java
 * Java type: class WorldGenLiquids
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: a3c43c28cf33200c6d5445f90b7ade07462b061c94f3e6c1da575fdb6f70e862
 * Java lines: 80
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, j, k, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int liquidBlockId
 *
 * Java method/constructor inventory:
 * - public WorldGenLiquids(int i)
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldGenLiquids_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenLiquids_JavaName(void)
{
    return "net.minecraft.src.WorldGenLiquids";
}

const char *CloneMCJ_WorldGenLiquids_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenLiquids_JavaSourceHash32(void)
{
    return 0xA3C43C28UL;
}

int CloneMCJ_WorldGenLiquids_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z, int liquidID)
{
    int stoneSides,airSides;
    (void)random;
    if(!world||y<=0||y>=127) return 0;
    if(CloneMCJ_World_GetBlockId(world,x,y+1,z)!=CLONEMC_J_BLOCK_STONE) return 0;
    if(CloneMCJ_World_GetBlockId(world,x,y-1,z)!=CLONEMC_J_BLOCK_STONE) return 0;
    if(CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_BLOCK_AIR&&CloneMCJ_World_GetBlockId(world,x,y,z)!=CLONEMC_J_BLOCK_STONE) return 0;
    stoneSides=0; airSides=0;
    if(CloneMCJ_World_GetBlockId(world,x-1,y,z)==CLONEMC_J_BLOCK_STONE) ++stoneSides; else if(CloneMCJ_World_IsAirBlock(world,x-1,y,z)) ++airSides;
    if(CloneMCJ_World_GetBlockId(world,x+1,y,z)==CLONEMC_J_BLOCK_STONE) ++stoneSides; else if(CloneMCJ_World_IsAirBlock(world,x+1,y,z)) ++airSides;
    if(CloneMCJ_World_GetBlockId(world,x,y,z-1)==CLONEMC_J_BLOCK_STONE) ++stoneSides; else if(CloneMCJ_World_IsAirBlock(world,x,y,z-1)) ++airSides;
    if(CloneMCJ_World_GetBlockId(world,x,y,z+1)==CLONEMC_J_BLOCK_STONE) ++stoneSides; else if(CloneMCJ_World_IsAirBlock(world,x,y,z+1)) ++airSides;
    if(stoneSides==3&&airSides==1){ CloneMCJ_World_SetBlock(world,x,y,z,liquidID); CloneMCJ_World_ScheduleBlockUpdate(world,x,y,z,liquidID,1); }
    return 1;
}
