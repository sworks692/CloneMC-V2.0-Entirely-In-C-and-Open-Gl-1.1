/*
 * CloneMC Java port scaffold: WorldGenGlowStone1
 *
 * Java source: WorldGenGlowStone1.java
 * Java type: class WorldGenGlowStone1
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 0360eaaf0cc1db0056d71a0b1d9c5483514ba51432ae5aa2de6264897eedfd87
 * Java lines: 82
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, j, k, j1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldGenGlowStone1()
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 11 directly implements the uploaded ceiling-seeded, single-neighbor
 * glowstone cluster generator below.
 */
#include "clonemc_java_port_40_world.h"

static int CloneMCJ_WorldGenGlowStone_Cluster(CloneMCJ_World *world,
    CloneMCJavaRandom *random, int x, int y, int z)
{
    int attempt;
    int direction;
    int xx;
    int yy;
    int zz;
    int neighbors;
    if (!world || !random || !CloneMCJ_World_IsAirBlock(world, x, y, z) ||
        CloneMCJ_World_GetBlockId(world, x, y + 1, z) != 87) return 0;
    CloneMCJ_World_SetBlock(world, x, y, z, 89);
    for (attempt = 0; attempt < 1500; ++attempt) {
        xx = x + CloneMCJavaRandom_NextIntBound(random, 8) - CloneMCJavaRandom_NextIntBound(random, 8);
        yy = y - CloneMCJavaRandom_NextIntBound(random, 12);
        zz = z + CloneMCJavaRandom_NextIntBound(random, 8) - CloneMCJavaRandom_NextIntBound(random, 8);
        if (!CloneMCJ_World_IsAirBlock(world, xx, yy, zz)) continue;
        neighbors = 0;
        for (direction = 0; direction < 6; ++direction)
            if (CloneMCJ_World_GetBlockId(world,
                xx + (direction == 0 ? -1 : direction == 1 ? 1 : 0),
                yy + (direction == 2 ? -1 : direction == 3 ? 1 : 0),
                zz + (direction == 4 ? -1 : direction == 5 ? 1 : 0)) == 89) ++neighbors;
        if (neighbors == 1) CloneMCJ_World_SetBlock(world, xx, yy, zz, 89);
    }
    return 1;
}

int CloneMCJ_WorldGenGlowStone1_Generate(CloneMCJ_World *world,
    CloneMCJavaRandom *random, int x, int y, int z)
{
    return CloneMCJ_WorldGenGlowStone_Cluster(world, random, x, y, z);
}

void CloneMCJ_WorldGenGlowStone1_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenGlowStone1_JavaName(void)
{
    return "net.minecraft.src.WorldGenGlowStone1";
}

const char *CloneMCJ_WorldGenGlowStone1_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenGlowStone1_JavaSourceHash32(void)
{
    return 0x0360EAAFUL;
}
