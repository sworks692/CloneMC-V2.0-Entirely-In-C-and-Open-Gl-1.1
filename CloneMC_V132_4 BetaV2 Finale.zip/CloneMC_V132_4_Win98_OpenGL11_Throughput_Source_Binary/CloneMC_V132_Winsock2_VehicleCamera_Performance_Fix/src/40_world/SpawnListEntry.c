/*
 * CloneMC Java port scaffold: SpawnListEntry
 *
 * Java source: SpawnListEntry.java
 * Java type: class SpawnListEntry
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: explicit architectural assignment after class responsibility review
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 4c58cf381501f75b90bee1dd8833807b2fa4cbad9363c160e3cb06af97829a60
 * Java lines: 20
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public Class entityClass
 * - public int spawnRarityRate
 *
 * Java method/constructor inventory:
 * - public SpawnListEntry(Class class1, int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_SpawnListEntry_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_SpawnListEntry_JavaName(void)
{
    return "net.minecraft.src.SpawnListEntry";
}

const char *CloneMCJ_SpawnListEntry_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_SpawnListEntry_JavaSourceHash32(void)
{
    return 0x4C58CF38UL;
}
