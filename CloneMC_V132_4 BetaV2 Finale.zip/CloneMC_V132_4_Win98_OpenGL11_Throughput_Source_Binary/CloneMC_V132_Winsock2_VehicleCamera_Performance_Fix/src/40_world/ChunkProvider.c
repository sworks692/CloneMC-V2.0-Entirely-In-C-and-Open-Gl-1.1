/*
 * CloneMC Java port scaffold: ChunkProvider
 *
 * Java source: ChunkProvider.java
 * Java type: class ChunkProvider
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IChunkProvider
 * Source SHA-256: 5ac22607f2749616c74ceb0c55bb36b7e55875e257778d5462019c6c219218c9
 * Java lines: 235
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: IChunkProvider, EmptyChunk, ChunkCoordIntPair, Chunk, IChunkLoader, World, IProgressUpdate, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Set droppedChunksSet
 * - private Chunk field_28064_b
 * - private IChunkProvider chunkProvider
 * - private IChunkLoader chunkLoader
 * - private Map chunkMap
 * - private List chunkList
 * - private World field_28066_g
 *
 * Java method/constructor inventory:
 * - public ChunkProvider(World world, IChunkLoader ichunkloader, IChunkProvider ichunkprovider)
 * - public boolean chunkExists(int i, int j)
 * - public Chunk prepareChunk(int i, int j)
 * - public Chunk provideChunk(int i, int j)
 * - private Chunk loadChunkFromFile(int i, int j)
 * - private void func_28063_a(Chunk chunk)
 * - private void func_28062_b(Chunk chunk)
 * - public void populate(IChunkProvider ichunkprovider, int i, int j)
 * - public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
 * - public boolean unload100OldestChunks()
 * - public boolean canSave()
 * - public String makeString()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_ChunkProvider_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkProvider_JavaName(void)
{
    return "net.minecraft.src.ChunkProvider";
}

const char *CloneMCJ_ChunkProvider_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkProvider_JavaSourceHash32(void)
{
    return 0x5AC22607UL;
}

/* Priority 3 ChunkProvider implementation. */
#include <string.h>

void CloneMCJ_ChunkProvider_Initialize(CloneMCJ_ChunkProvider *provider, CloneMCJLong seed)
{
    if (!provider) { return; }
    memset(provider, 0, sizeof(*provider));
    CloneMCJ_ChunkProviderLoadOrGenerate_Initialize(&provider->backing, seed);
}

void CloneMCJ_ChunkProvider_Destroy(CloneMCJ_ChunkProvider *provider)
{
    if (!provider) { return; }
    CloneMCJ_ChunkProviderLoadOrGenerate_Destroy(&provider->backing);
}

void CloneMCJ_ChunkProvider_SetCallbacks(CloneMCJ_ChunkProvider *provider,
    CloneMCJ_ChunkLoaderProc loader, void *loaderUser,
    CloneMCJ_ChunkGeneratorProc generator, void *generatorUser,
    CloneMCJ_ChunkSaverProc saver, void *saverUser)
{
    if (!provider) { return; }
    CloneMCJ_ChunkProviderLoadOrGenerate_SetCallbacks(&provider->backing, loader, loaderUser, generator, generatorUser, saver, saverUser);
}

int CloneMCJ_ChunkProvider_ChunkExists(CloneMCJ_ChunkProvider *provider, int chunkX, int chunkZ)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&provider->backing, chunkX, chunkZ) : 0; }
CloneMCJ_Chunk *CloneMCJ_ChunkProvider_PrepareChunk(CloneMCJ_ChunkProvider *provider, int chunkX, int chunkZ)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&provider->backing, chunkX, chunkZ) : 0; }
CloneMCJ_Chunk *CloneMCJ_ChunkProvider_ProvideChunk(CloneMCJ_ChunkProvider *provider, int chunkX, int chunkZ)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_ProvideChunk(&provider->backing, chunkX, chunkZ) : 0; }
void CloneMCJ_ChunkProvider_Populate(CloneMCJ_ChunkProvider *provider, int chunkX, int chunkZ)
{ if (provider) { CloneMCJ_ChunkProviderLoadOrGenerate_Populate(&provider->backing, chunkX, chunkZ); } }
int CloneMCJ_ChunkProvider_SaveChunks(CloneMCJ_ChunkProvider *provider, int force)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_SaveChunks(&provider->backing, force) : 0; }
int CloneMCJ_ChunkProvider_Unload100OldestChunks(CloneMCJ_ChunkProvider *provider)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_Unload100OldestChunks(&provider->backing) : 0; }
int CloneMCJ_ChunkProvider_CanSave(CloneMCJ_ChunkProvider *provider)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_CanSave(&provider->backing) : 0; }
const char *CloneMCJ_ChunkProvider_MakeString(CloneMCJ_ChunkProvider *provider)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_MakeString(&provider->backing) : "ChunkProvider: null"; }
CloneMCJ_IChunkProvider *CloneMCJ_ChunkProvider_AsIChunkProvider(CloneMCJ_ChunkProvider *provider)
{ return provider ? CloneMCJ_ChunkProviderLoadOrGenerate_AsIChunkProvider(&provider->backing) : 0; }

void CloneMCJ_ChunkProvider_DropChunk(CloneMCJ_ChunkProvider *provider, int chunkX, int chunkZ)
{
    unsigned short i;
    if (!provider) { return; }
    if (provider->droppedCount >= 128) { provider->droppedCount = 0; }
    i = provider->droppedCount++;
    provider->droppedChunkX[i] = chunkX;
    provider->droppedChunkZ[i] = chunkZ;
    provider->droppedUsed[i] = 1;
}
