/* Java source: WorldGenBigTree.java; Source SHA-256: b36725698404f83a3a9a970dc765dfc280933854ac12ffad499166d0c85092a3; Java lines: 454. */
/*
 * Direct bounded C89 port of Minecraft Beta WorldGenBigTree.java.
 * Uses a fixed foliage-node array for Windows 98/Open Watcom compatibility.
 */
#include "clonemc_java_port_40_world.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

void CloneMCJ_WorldGenBigTree_Register(void)
{
    /* Priority 4 direct port of WorldGenBigTree.java. */
}

const char *CloneMCJ_WorldGenBigTree_JavaName(void)
{
    return "net.minecraft.src.WorldGenBigTree";
}

const char *CloneMCJ_WorldGenBigTree_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenBigTree_JavaSourceHash32(void)
{
    return 0xB3672569UL;
}

#define CLONEMC_J_BIGTREE_MAX_NODES 256

typedef struct CloneMCJ_BigTreeContextTag {
    CloneMCJavaRandom random;
    CloneMCJ_World *world;
    int base[3];
    int totalHeight;
    int trunkHeight;
    double heightAttenuation;
    double branchSlope;
    double scaleWidth;
    double leafDensity;
    int trunkSize;
    int heightLimitLimit;
    int leafDistanceLimit;
    int nodes[CLONEMC_J_BIGTREE_MAX_NODES][4];
    int nodeCount;
} CloneMCJ_BigTreeContext;

static const signed char g_cloneMCJBigTreeAxes[6] = { 2, 0, 0, 1, 2, 1 };

static float CloneMCJ_BigTree_LayerSize(const CloneMCJ_BigTreeContext *ctx, int layer)
{
    float half;
    float delta;
    float result;
    if ((double)layer < (double)(float)ctx->totalHeight * 0.3) { return -1.618F; }
    half = (float)ctx->totalHeight / 2.0F;
    delta = half - (float)layer;
    if (delta == 0.0F) { result = half; }
    else if ((float)fabs((double)delta) >= half) { result = 0.0F; }
    else { result = (float)sqrt((double)(half * half - delta * delta)); }
    return result * 0.5F;
}

static float CloneMCJ_BigTree_LeafSize(const CloneMCJ_BigTreeContext *ctx, int layer)
{
    if (layer < 0 || layer >= ctx->leafDistanceLimit) { return -1.0F; }
    return layer != 0 && layer != ctx->leafDistanceLimit - 1 ? 3.0F : 2.0F;
}

static int CloneMCJ_BigTree_CheckLine(CloneMCJ_BigTreeContext *ctx, const int start[3], const int end[3])
{
    int delta[3];
    int point[3];
    int major;
    int axis;
    int direction;
    int offset;
    int finish;
    signed char axisA;
    signed char axisB;
    double slopeA;
    double slopeB;

    major = 0;
    for (axis = 0; axis < 3; ++axis) {
        delta[axis] = end[axis] - start[axis];
        if (abs(delta[axis]) > abs(delta[major])) { major = axis; }
    }
    if (delta[major] == 0) { return -1; }
    axisA = g_cloneMCJBigTreeAxes[major];
    axisB = g_cloneMCJBigTreeAxes[major + 3];
    direction = delta[major] > 0 ? 1 : -1;
    slopeA = (double)delta[(int)axisA] / (double)delta[major];
    slopeB = (double)delta[(int)axisB] / (double)delta[major];
    offset = 0;
    finish = delta[major] + direction;
    while (offset != finish) {
        int block;
        point[major] = start[major] + offset;
        point[(int)axisA] = CloneMCJava_FloorDouble((double)start[(int)axisA] + (double)offset * slopeA);
        point[(int)axisB] = CloneMCJava_FloorDouble((double)start[(int)axisB] + (double)offset * slopeB);
        block = CloneMCJ_World_GetBlockId(ctx->world, point[0], point[1], point[2]);
        if (block != CLONEMC_J_BLOCK_AIR && block != CLONEMC_J_BLOCK_LEAVES) { break; }
        offset += direction;
    }
    if (offset == finish) { return -1; }
    return abs(offset);
}

static void CloneMCJ_BigTree_PlaceLine(CloneMCJ_BigTreeContext *ctx, const int start[3], const int end[3], int blockID)
{
    int delta[3];
    int point[3];
    int major;
    int axis;
    int direction;
    int offset;
    int finish;
    signed char axisA;
    signed char axisB;
    double slopeA;
    double slopeB;

    major = 0;
    for (axis = 0; axis < 3; ++axis) {
        delta[axis] = end[axis] - start[axis];
        if (abs(delta[axis]) > abs(delta[major])) { major = axis; }
    }
    if (delta[major] == 0) { return; }
    axisA = g_cloneMCJBigTreeAxes[major];
    axisB = g_cloneMCJBigTreeAxes[major + 3];
    direction = delta[major] > 0 ? 1 : -1;
    slopeA = (double)delta[(int)axisA] / (double)delta[major];
    slopeB = (double)delta[(int)axisB] / (double)delta[major];
    offset = 0;
    finish = delta[major] + direction;
    while (offset != finish) {
        point[major] = CloneMCJava_FloorDouble((double)(start[major] + offset) + 0.5);
        point[(int)axisA] = CloneMCJava_FloorDouble((double)start[(int)axisA] + (double)offset * slopeA + 0.5);
        point[(int)axisB] = CloneMCJava_FloorDouble((double)start[(int)axisB] + (double)offset * slopeB + 0.5);
        CloneMCJ_World_SetBlock(ctx->world, point[0], point[1], point[2], blockID);
        offset += direction;
    }
}

static void CloneMCJ_BigTree_PlaceLayer(CloneMCJ_BigTreeContext *ctx, int x, int y, int z,
    float radius, int axis, int blockID)
{
    int integerRadius;
    signed char axisA;
    signed char axisB;
    int center[3];
    int point[3];
    int offsetA;
    int offsetB;

    integerRadius = (int)((double)radius + 0.618);
    axisA = g_cloneMCJBigTreeAxes[axis];
    axisB = g_cloneMCJBigTreeAxes[axis + 3];
    center[0] = x;
    center[1] = y;
    center[2] = z;
    point[axis] = center[axis];
    for (offsetA = -integerRadius; offsetA <= integerRadius; ++offsetA) {
        point[(int)axisA] = center[(int)axisA] + offsetA;
        for (offsetB = -integerRadius; offsetB <= integerRadius; ++offsetB) {
            double distance;
            int existing;
            distance = sqrt(pow((double)abs(offsetA) + 0.5, 2.0) +
                pow((double)abs(offsetB) + 0.5, 2.0));
            if (distance > (double)radius) { continue; }
            point[(int)axisB] = center[(int)axisB] + offsetB;
            existing = CloneMCJ_World_GetBlockId(ctx->world, point[0], point[1], point[2]);
            if (existing == CLONEMC_J_BLOCK_AIR || existing == CLONEMC_J_BLOCK_LEAVES) {
                CloneMCJ_World_SetBlock(ctx->world, point[0], point[1], point[2], blockID);
            }
        }
    }
}

static void CloneMCJ_BigTree_GenerateLeafNode(CloneMCJ_BigTreeContext *ctx, int x, int y, int z)
{
    int layer;
    for (layer = y; layer < y + ctx->leafDistanceLimit; ++layer) {
        CloneMCJ_BigTree_PlaceLayer(ctx, x, layer, z,
            CloneMCJ_BigTree_LeafSize(ctx, layer - y), 1, CLONEMC_J_BLOCK_LEAVES);
    }
}

static void CloneMCJ_BigTree_GenerateLeafNodeList(CloneMCJ_BigTreeContext *ctx)
{
    int nodesPerLayer;
    int currentY;
    int nodeCount;
    int trunkTop;
    int relativeY;

    ctx->trunkHeight = (int)((double)ctx->totalHeight * ctx->heightAttenuation);
    if (ctx->trunkHeight >= ctx->totalHeight) { ctx->trunkHeight = ctx->totalHeight - 1; }
    nodesPerLayer = (int)(1.382 + pow((ctx->leafDensity * (double)ctx->totalHeight) / 13.0, 2.0));
    if (nodesPerLayer < 1) { nodesPerLayer = 1; }
    currentY = (ctx->base[1] + ctx->totalHeight) - ctx->leafDistanceLimit;
    nodeCount = 1;
    trunkTop = ctx->base[1] + ctx->trunkHeight;
    relativeY = currentY - ctx->base[1];
    ctx->nodes[0][0] = ctx->base[0];
    ctx->nodes[0][1] = currentY;
    ctx->nodes[0][2] = ctx->base[2];
    ctx->nodes[0][3] = trunkTop;
    --currentY;

    while (relativeY >= 0) {
        int nodeIndex;
        float layerSize;
        layerSize = CloneMCJ_BigTree_LayerSize(ctx, relativeY);
        if (layerSize < 0.0F) {
            --currentY;
            --relativeY;
            continue;
        }
        for (nodeIndex = 0; nodeIndex < nodesPerLayer; ++nodeIndex) {
            double distance;
            double angle;
            int leafStart[3];
            int leafEnd[3];
            int branchStart[3];
            double horizontalDistance;
            double branchDrop;
            if (nodeCount >= CLONEMC_J_BIGTREE_MAX_NODES) { break; }
            distance = ctx->scaleWidth * ((double)layerSize *
                ((double)CloneMCJavaRandom_NextFloat(&ctx->random) + 0.328));
            angle = (double)CloneMCJavaRandom_NextFloat(&ctx->random) * 2.0 * 3.14159;
            leafStart[0] = CloneMCJava_FloorDouble(distance * sin(angle) + (double)ctx->base[0] + 0.5);
            leafStart[1] = currentY;
            leafStart[2] = CloneMCJava_FloorDouble(distance * cos(angle) + (double)ctx->base[2] + 0.5);
            leafEnd[0] = leafStart[0];
            leafEnd[1] = currentY + ctx->leafDistanceLimit;
            leafEnd[2] = leafStart[2];
            if (CloneMCJ_BigTree_CheckLine(ctx, leafStart, leafEnd) != -1) { continue; }
            branchStart[0] = ctx->base[0];
            branchStart[1] = ctx->base[1];
            branchStart[2] = ctx->base[2];
            horizontalDistance = sqrt(pow((double)abs(ctx->base[0] - leafStart[0]), 2.0) +
                pow((double)abs(ctx->base[2] - leafStart[2]), 2.0));
            branchDrop = horizontalDistance * ctx->branchSlope;
            if ((double)leafStart[1] - branchDrop > (double)trunkTop) { branchStart[1] = trunkTop; }
            else { branchStart[1] = (int)((double)leafStart[1] - branchDrop); }
            if (CloneMCJ_BigTree_CheckLine(ctx, branchStart, leafStart) == -1) {
                ctx->nodes[nodeCount][0] = leafStart[0];
                ctx->nodes[nodeCount][1] = currentY;
                ctx->nodes[nodeCount][2] = leafStart[2];
                ctx->nodes[nodeCount][3] = branchStart[1];
                ++nodeCount;
            }
        }
        --currentY;
        --relativeY;
    }
    ctx->nodeCount = nodeCount;
}

static int CloneMCJ_BigTree_ValidLocation(CloneMCJ_BigTreeContext *ctx)
{
    int start[3];
    int end[3];
    int ground;
    int obstruction;
    start[0] = ctx->base[0]; start[1] = ctx->base[1]; start[2] = ctx->base[2];
    end[0] = ctx->base[0]; end[1] = ctx->base[1] + ctx->totalHeight - 1; end[2] = ctx->base[2];
    ground = CloneMCJ_World_GetBlockId(ctx->world, ctx->base[0], ctx->base[1] - 1, ctx->base[2]);
    if (ground != CLONEMC_J_BLOCK_GRASS && ground != CLONEMC_J_BLOCK_DIRT) { return 0; }
    obstruction = CloneMCJ_BigTree_CheckLine(ctx, start, end);
    if (obstruction == -1) { return 1; }
    if (obstruction < 6) { return 0; }
    ctx->totalHeight = obstruction;
    return 1;
}

static int CloneMCJ_BigTree_ShouldBranch(const CloneMCJ_BigTreeContext *ctx, int height)
{
    return (double)height >= (double)ctx->totalHeight * 0.2;
}

static void CloneMCJ_BigTree_GenerateLeaves(CloneMCJ_BigTreeContext *ctx)
{
    int index;
    for (index = 0; index < ctx->nodeCount; ++index) {
        CloneMCJ_BigTree_GenerateLeafNode(ctx, ctx->nodes[index][0], ctx->nodes[index][1], ctx->nodes[index][2]);
    }
}

static void CloneMCJ_BigTree_GenerateTrunk(CloneMCJ_BigTreeContext *ctx)
{
    int start[3];
    int end[3];
    start[0] = ctx->base[0]; start[1] = ctx->base[1]; start[2] = ctx->base[2];
    end[0] = ctx->base[0]; end[1] = ctx->base[1] + ctx->trunkHeight; end[2] = ctx->base[2];
    CloneMCJ_BigTree_PlaceLine(ctx, start, end, CLONEMC_J_BLOCK_LOG);
    if (ctx->trunkSize == 2) {
        ++start[0]; ++end[0]; CloneMCJ_BigTree_PlaceLine(ctx, start, end, CLONEMC_J_BLOCK_LOG);
        ++start[2]; ++end[2]; CloneMCJ_BigTree_PlaceLine(ctx, start, end, CLONEMC_J_BLOCK_LOG);
        --start[0]; --end[0]; CloneMCJ_BigTree_PlaceLine(ctx, start, end, CLONEMC_J_BLOCK_LOG);
    }
}

static void CloneMCJ_BigTree_GenerateBranches(CloneMCJ_BigTreeContext *ctx)
{
    int index;
    int start[3];
    int end[3];
    start[0] = ctx->base[0]; start[1] = ctx->base[1]; start[2] = ctx->base[2];
    for (index = 0; index < ctx->nodeCount; ++index) {
        end[0] = ctx->nodes[index][0];
        end[1] = ctx->nodes[index][1];
        end[2] = ctx->nodes[index][2];
        start[1] = ctx->nodes[index][3];
        if (CloneMCJ_BigTree_ShouldBranch(ctx, start[1] - ctx->base[1])) {
            CloneMCJ_BigTree_PlaceLine(ctx, start, end, CLONEMC_J_BLOCK_LOG);
        }
    }
}

int CloneMCJ_WorldGenBigTree_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z)
{
    CloneMCJ_BigTreeContext ctx;
    if (!world || !random) { return 0; }
    memset(&ctx, 0, sizeof(ctx));
    ctx.world = world;
    CloneMCJavaRandom_SetSeed(&ctx.random, CloneMCJavaRandom_NextLong(random));
    ctx.base[0] = x;
    ctx.base[1] = y;
    ctx.base[2] = z;
    ctx.heightAttenuation = 0.618;
    ctx.branchSlope = 0.381;
    ctx.scaleWidth = 1.0;
    ctx.leafDensity = 1.0;
    ctx.trunkSize = 1;
    ctx.heightLimitLimit = 12;
    ctx.leafDistanceLimit = 5; /* func_517_a(1,1,1) in ChunkProviderGenerate.populate */
    ctx.totalHeight = 5 + CloneMCJavaRandom_NextIntBound(&ctx.random, ctx.heightLimitLimit);
    if (!CloneMCJ_BigTree_ValidLocation(&ctx)) { return 0; }
    CloneMCJ_BigTree_GenerateLeafNodeList(&ctx);
    CloneMCJ_BigTree_GenerateLeaves(&ctx);
    CloneMCJ_BigTree_GenerateTrunk(&ctx);
    CloneMCJ_BigTree_GenerateBranches(&ctx);
    return 1;
}
