/*
 * CloneMC direct Java-compatible port: WorldGenReed
 *
 * Java source: WorldGenReed.java
 * Java type: class WorldGenReed
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 2a03ab8f5bc47cca70adda5df2f83beaa742371a5872001d5c3c14f4367f2ac6
 * Java lines: 44
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Material, Block, j1, i1, k1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldGenReed()
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldGenReed_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenReed_JavaName(void)
{
    return "net.minecraft.src.WorldGenReed";
}

const char *CloneMCJ_WorldGenReed_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenReed_JavaSourceHash32(void)
{
    return 0x2A03AB8FUL;
}

int CloneMCJ_WorldGenReed_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random, int x, int y, int z)
{
    int i;
    if(!world||!random) return 0;
    for(i=0;i<20;++i){
        int px=(x+CloneMCJavaRandom_NextIntBound(random,4))-CloneMCJavaRandom_NextIntBound(random,4);
        int pz=(z+CloneMCJavaRandom_NextIntBound(random,4))-CloneMCJavaRandom_NextIntBound(random,4);
        int h,j;
        if(!CloneMCJ_World_IsAirBlock(world,px,y,pz)||!CloneMCJ_World_CanReedStay(world,px,y,pz)) continue;
        h=2+CloneMCJavaRandom_NextIntBound(random,CloneMCJavaRandom_NextIntBound(random,3)+1);
        for(j=0;j<h;++j) if(CloneMCJ_World_CanReedStay(world,px,y+j,pz)) CloneMCJ_World_SetBlock(world,px,y+j,pz,CLONEMC_J_BLOCK_REED);
    }
    return 1;
}
