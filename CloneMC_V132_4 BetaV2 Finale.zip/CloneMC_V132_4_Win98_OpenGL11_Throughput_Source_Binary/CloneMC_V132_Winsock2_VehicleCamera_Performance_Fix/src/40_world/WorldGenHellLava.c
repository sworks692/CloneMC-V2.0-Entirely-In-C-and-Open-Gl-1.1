/*
 * CloneMC Java port scaffold: WorldGenHellLava
 *
 * Java source: WorldGenHellLava.java
 * Java type: class WorldGenHellLava
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 85e53d3e65ffa29e38e1d8e9a211cf3450da9280abec23a1c5dc54254fb126f7
 * Java lines: 84
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, j, k, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_4158_a
 *
 * Java method/constructor inventory:
 * - public WorldGenHellLava(int i)
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 11 directly implements the uploaded netherrack/air enclosure test,
 * moving-lava placement and immediate first update below.
 */
#include "clonemc_java_port_40_world.h"
#include "../30_item/clonemc_java_port_30_item.h"

int CloneMCJ_WorldGenHellLava_Generate(CloneMCJ_World *world,
    CloneMCJavaRandom *random, int x, int y, int z, int liquidID)
{
    int netherrack;
    int air;
    int id;
    if (!world || !random) return 0;
    if (CloneMCJ_World_GetBlockId(world, x, y + 1, z) != 87) return 0;
    id = CloneMCJ_World_GetBlockId(world, x, y, z);
    if (id != 0 && id != 87) return 0;
    netherrack = 0; air = 0;
    id = CloneMCJ_World_GetBlockId(world, x - 1, y, z); netherrack += id == 87; air += id == 0;
    id = CloneMCJ_World_GetBlockId(world, x + 1, y, z); netherrack += id == 87; air += id == 0;
    id = CloneMCJ_World_GetBlockId(world, x, y, z - 1); netherrack += id == 87; air += id == 0;
    id = CloneMCJ_World_GetBlockId(world, x, y, z + 1); netherrack += id == 87; air += id == 0;
    id = CloneMCJ_World_GetBlockId(world, x, y - 1, z); netherrack += id == 87; air += id == 0;
    if (netherrack == 4 && air == 1) {
        CloneMCJ_World_SetBlockNotify(world, x, y, z, liquidID);
        CloneMCJ_BlockFlowing_UpdateTick(world, x, y, z, liquidID, random, 0);
    }
    return 1;
}

void CloneMCJ_WorldGenHellLava_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenHellLava_JavaName(void)
{
    return "net.minecraft.src.WorldGenHellLava";
}

const char *CloneMCJ_WorldGenHellLava_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenHellLava_JavaSourceHash32(void)
{
    return 0x85E53D3EUL;
}
