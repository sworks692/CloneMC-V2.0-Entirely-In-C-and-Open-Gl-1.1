/*
 * CloneMC Java port scaffold: WorldClient
 *
 * Java source: WorldClient.java
 * Java type: class WorldClient
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: World
 * Implements: (none declared)
 * Source SHA-256: ac4e02bce74fdcfec4f946f0c699377d4828d004391d9efd11ddef17294f7d3c
 * Java lines: 296
 * Discovered declared fields: 6
 * Discovered declared methods/constructors: 22
 * Referenced Java classes: World, SaveHandlerMP, WorldProvider, MCHash, ChunkCoordinates, NetClientHandler, IWorldAccess, Entity, WorldBlockPositionType, ChunkProviderClient, Packet255KickDisconnect, WorldInfo, IChunkProvider, worldblockpositiontype.field_1201_b, worldblockpositiontype.field_1207_c, worldblockpositiontype.field_1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private LinkedList field_1057_z
 * - private NetClientHandler sendQueue
 * - private ChunkProviderClient field_20915_C
 * - private MCHash field_1055_D
 * - private Set field_20914_E
 * - private Set field_1053_F
 *
 * Java method/constructor inventory:
 * - public WorldClient(NetClientHandler netclienthandler, long l, int i)
 * - public void tick()
 * - public void func_711_c(int i, int j, int k, int l, int i1, int j1)
 * - protected IChunkProvider getChunkProvider()
 * - public void setSpawnLocation()
 * - protected void updateBlocksAndPlayCaveSounds()
 * - public void scheduleBlockUpdate(int i, int j, int k, int l, int i1)
 * - public boolean TickUpdates(boolean flag)
 * - public void doPreChunk(int i, int j, boolean flag)
 * - public boolean entityJoinedWorld(Entity entity)
 * - public void setEntityDead(Entity entity)
 * - protected void obtainEntitySkin(Entity entity)
 * - protected void releaseEntitySkin(Entity entity)
 * - public void func_712_a(int i, Entity entity)
 * - public Entity func_709_b(int i)
 * - public Entity removeEntityFromWorld(int i)
 * - public boolean setBlockMetadata(int i, int j, int k, int l)
 * - public boolean setBlockAndMetadata(int i, int j, int k, int l, int i1)
 * - public boolean setBlock(int i, int j, int k, int l)
 * - public boolean func_714_c(int i, int j, int k, int l, int i1)
 * - public void sendQuittingDisconnectingPacket()
 * - protected void updateWeather()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldClient_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldClient_JavaName(void)
{
    return "net.minecraft.src.WorldClient";
}

const char *CloneMCJ_WorldClient_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldClient_JavaSourceHash32(void)
{
    return 0xAC4E02BCUL;
}

/* Priority 3 WorldClient implementation. */
#include <string.h>

void CloneMCJ_WorldClient_Initialize(CloneMCJ_WorldClient *client, void *sendQueue, CloneMCJLong seed, int dimension)
{
    if (!client) { return; }
    memset(client, 0, sizeof(*client));
    client->sendQueue = sendQueue;
    client->dimension = dimension;
    CloneMCJ_World_Initialize(&client->baseWorld, seed, 0);
    client->baseWorld.multiplayerWorld = 1;
    CloneMCJ_ChunkProviderClient_Initialize(&client->clientChunkProvider, client);
}

void CloneMCJ_WorldClient_Destroy(CloneMCJ_WorldClient *client)
{
    if (!client) { return; }
    CloneMCJ_ChunkProviderClient_Destroy(&client->clientChunkProvider);
    CloneMCJ_World_Destroy(&client->baseWorld);
}

void CloneMCJ_WorldClient_DoPreChunk(CloneMCJ_WorldClient *client, int chunkX, int chunkZ, int load)
{
    if (!client) { return; }
    CloneMCJ_ChunkProviderClient_DoPreChunk(&client->clientChunkProvider, chunkX, chunkZ, load);
}

CloneMCJ_Chunk *CloneMCJ_WorldClient_GetChunkFromChunkCoords(CloneMCJ_WorldClient *client, int chunkX, int chunkZ)
{
    return client ? CloneMCJ_ChunkProviderClient_ProvideChunk(&client->clientChunkProvider, chunkX, chunkZ) : 0;
}

int CloneMCJ_WorldClient_SetBlockAndMetadata(CloneMCJ_WorldClient *client, int x, int y, int z, int blockID, int metadata)
{
    CloneMCJ_Chunk *chunk;
    CloneMCJ_Chunk *neighbor;
    CloneMCJ_TileEntity *tile;
    int chunkX,chunkZ,localX,localZ,oldID,changed;
    if (!client || y < 0 || y >= CLONEMC_J_CHUNK_HEIGHT) { return 0; }
    chunkX=CloneMCJ_World_GlobalToChunk(x);
    chunkZ=CloneMCJ_World_GlobalToChunk(z);
    localX=CloneMCJ_World_GlobalToLocal(x);
    localZ=CloneMCJ_World_GlobalToLocal(z);
    chunk = CloneMCJ_WorldClient_GetChunkFromChunkCoords(client,chunkX,chunkZ);
    if (!chunk || CloneMCJ_EmptyChunk_IsEmptyReadOnly(chunk)) { return 0; }
    oldID=CloneMCJ_Chunk_GetBlockID(chunk,localX,y,localZ);
    changed=CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk,localX,y,localZ,
        blockID,metadata,0,0);
    if(!changed)return 0;
    chunk->meshDirty=1;
    /* A server correction that replaces a container/sign must also remove its
     * stale client tile entity before a later Packet130/Packet105 arrives. */
    if(oldID!=blockID){
        tile=(CloneMCJ_TileEntity*)CloneMCJ_Chunk_GetTileEntity(chunk,localX,y,localZ);
        if(tile){CloneMCJ_Chunk_RemoveTileEntity(chunk,localX,y,localZ);
            CloneMCJ_TileEntity_Destroy(tile);}
    }
    if(localX==0&&CloneMCJ_ChunkProviderClient_ChunkExists(
        &client->clientChunkProvider,chunkX-1,chunkZ)){
        neighbor=CloneMCJ_WorldClient_GetChunkFromChunkCoords(client,chunkX-1,chunkZ);
        if(neighbor)neighbor->meshDirty=1;
    }
    if(localX==15&&CloneMCJ_ChunkProviderClient_ChunkExists(
        &client->clientChunkProvider,chunkX+1,chunkZ)){
        neighbor=CloneMCJ_WorldClient_GetChunkFromChunkCoords(client,chunkX+1,chunkZ);
        if(neighbor)neighbor->meshDirty=1;
    }
    if(localZ==0&&CloneMCJ_ChunkProviderClient_ChunkExists(
        &client->clientChunkProvider,chunkX,chunkZ-1)){
        neighbor=CloneMCJ_WorldClient_GetChunkFromChunkCoords(client,chunkX,chunkZ-1);
        if(neighbor)neighbor->meshDirty=1;
    }
    if(localZ==15&&CloneMCJ_ChunkProviderClient_ChunkExists(
        &client->clientChunkProvider,chunkX,chunkZ+1)){
        neighbor=CloneMCJ_WorldClient_GetChunkFromChunkCoords(client,chunkX,chunkZ+1);
        if(neighbor)neighbor->meshDirty=1;
    }
    return 1;
}

int CloneMCJ_WorldClient_SetBlock(CloneMCJ_WorldClient *client, int x, int y, int z, int blockID)
{
    return CloneMCJ_WorldClient_SetBlockAndMetadata(client, x, y, z, blockID, 0);
}
