/*
 * CloneMC Java port scaffold: ChunkPosition
 *
 * Java source: ChunkPosition.java
 * Java type: class ChunkPosition
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 09ad937e937c92abfbc54e5c7e60ddcfb33b80f9cdd685a3d2eaa8c8b8c08174
 * Java lines: 39
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public final int x
 * - public final int y
 * - public final int z
 *
 * Java method/constructor inventory:
 * - public ChunkPosition(int i, int j, int k)
 * - public boolean equals(Object obj)
 * - public int hashCode()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_ChunkPosition_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkPosition_JavaName(void)
{
    return "net.minecraft.src.ChunkPosition";
}

const char *CloneMCJ_ChunkPosition_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkPosition_JavaSourceHash32(void)
{
    return 0x09AD937EUL;
}

/* Priority 3 ChunkPosition implementation. */
void CloneMCJ_ChunkPosition_Initialize(CloneMCJ_ChunkPosition *pos, int x, int y, int z)
{
    if (!pos) { return; }
    pos->x = x; pos->y = y; pos->z = z;
}

int CloneMCJ_ChunkPosition_Equals(const CloneMCJ_ChunkPosition *a, const CloneMCJ_ChunkPosition *b)
{
    return a && b && a->x == b->x && a->y == b->y && a->z == b->z;
}

CloneMCJInt CloneMCJ_ChunkPosition_HashCode(const CloneMCJ_ChunkPosition *pos)
{
    if (!pos) { return 0; }
    return (CloneMCJInt)(pos->x * 8976890 + pos->y * 981131 + pos->z);
}
