/*
 * CloneMC Java port scaffold: Chunk
 *
 * Java source: Chunk.java
 * Java type: class Chunk
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: d034c688989b200bdab240cc6b038ed65107ea9e91fc09151191c9b50c56d20f
 * Java lines: 696
 * Discovered declared fields: 18
 * Discovered declared methods/constructors: 36
 * Referenced Java classes: NibbleArray, Block, World, WorldProvider, EnumSkyBlock, Entity, MathHelper, ChunkPosition, TileEntity, BlockContainer, AxisAlignedBB, ChunkBlockMap, i
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public static boolean isLit
 * - public byte blocks[]
 * - public boolean isChunkLoaded
 * - public World worldObj
 * - public NibbleArray data
 * - public NibbleArray skylightMap
 * - public NibbleArray blocklightMap
 * - public byte heightMap[]
 * - public int lowestBlockHeight
 * - public final int xPosition
 * - public final int zPosition
 * - public Map chunkTileEntityMap
 * - public List entities[]
 * - public boolean isTerrainPopulated
 * - public boolean isModified
 * - public boolean neverSave
 * - public boolean hasEntities
 * - public long lastSaveTime
 *
 * Java method/constructor inventory:
 * - public Chunk(World world, int i, int j)
 * - public Chunk(World world, byte abyte0[], int i, int j)
 * - public boolean isAtLocation(int i, int j)
 * - public int getHeightValue(int i, int j)
 * - public void func_1014_a()
 * - public void generateHeightMap()
 * - public void func_1024_c()
 * - public void func_4143_d()
 * - private void func_996_c(int i, int j)
 * - private void func_1020_f(int i, int j, int k)
 * - private void func_1003_g(int i, int j, int k)
 * - public int getBlockID(int i, int j, int k)
 * - public boolean setBlockIDWithMetadata(int i, int j, int k, int l, int i1)
 * - public boolean setBlockID(int i, int j, int k, int l)
 * - public int getBlockMetadata(int i, int j, int k)
 * - public void setBlockMetadata(int i, int j, int k, int l)
 * - public int getSavedLightValue(EnumSkyBlock enumskyblock, int i, int j, int k)
 * - public void setLightValue(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
 * - public int getBlockLightValue(int i, int j, int k, int l)
 * - public void addEntity(Entity entity)
 * - public void removeEntity(Entity entity)
 * - public void removeEntityAtIndex(Entity entity, int i)
 * - public boolean canBlockSeeTheSky(int i, int j, int k)
 * - public TileEntity getChunkBlockTileEntity(int i, int j, int k)
 * - public void addTileEntity(TileEntity tileentity)
 * - public void setChunkBlockTileEntity(int i, int j, int k, TileEntity tileentity)
 * - public void removeChunkBlockTileEntity(int i, int j, int k)
 * - public void onChunkLoad()
 * - public void onChunkUnload()
 * - public void setChunkModified()
 * - public void getEntitiesWithinAABBForEntity(Entity entity, AxisAlignedBB axisalignedbb, List list)
 * - public void getEntitiesOfTypeWithinAAAB(Class class1, AxisAlignedBB axisalignedbb, List list)
 * - public boolean needsSaving(boolean flag)
 * - public Random func_997_a(long l)
 * - public boolean func_21167_h()
 * - public void func_25124_i()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_Chunk_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Chunk_JavaName(void)
{
    return "net.minecraft.src.Chunk";
}

const char *CloneMCJ_Chunk_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_Chunk_JavaSourceHash32(void)
{
    return 0xD034C688UL;
}

/* Priority 3 real chunk implementation from Chunk.java ownership rules. */
#include <stdlib.h>
#include <string.h>

static int CloneMCJ_Chunk_DefaultOpacity(int blockID, void *userData)
{
    (void)userData;
    return CloneMCJ_World_GetBlockLightOpacity(blockID);
}

unsigned long CloneMCJ_Chunk_BlockIndex(int localX, int y, int localZ)
{
    return (unsigned long)((localX << 11) | (localZ << 7) | y);
}

int CloneMCJ_Chunk_IsLocalPositionValid(int localX, int y, int localZ)
{
    return localX >= 0 && localX < 16 && localZ >= 0 && localZ < 16 && y >= 0 && y < 128;
}

static void CloneMCJ_Chunk_WrapNibbleArrays(CloneMCJ_Chunk *chunk)
{
    CloneMCJ_NibbleArray_Wrap(&chunk->data, chunk->dataBytes, CLONEMC_J_CHUNK_NIBBLE_BYTES);
    CloneMCJ_NibbleArray_Wrap(&chunk->skylightMap, chunk->skylightBytes, CLONEMC_J_CHUNK_NIBBLE_BYTES);
    CloneMCJ_NibbleArray_Wrap(&chunk->blocklightMap, chunk->blocklightBytes, CLONEMC_J_CHUNK_NIBBLE_BYTES);
}

void CloneMCJ_Chunk_Initialize(CloneMCJ_Chunk *chunk, int chunkX, int chunkZ)
{
    if (!chunk) { return; }
    memset(chunk, 0, sizeof(*chunk));
    chunk->xPosition = chunkX;
    chunk->zPosition = chunkZ;
    chunk->lowestBlockHeight = 127;
    chunk->isChunkLoaded = 1;
    chunk->loaded = 1;
    chunk->state = CLONEMC_J_CHUNK_STATE_LOADING;
    CloneMCJ_Chunk_WrapNibbleArrays(chunk);
    CloneMCJ_Chunk_GenerateHeightMap(chunk, CloneMCJ_Chunk_DefaultOpacity, 0);
    chunk->state = CLONEMC_J_CHUNK_STATE_READY;
}

void CloneMCJ_Chunk_InitializeWithBlocks(CloneMCJ_Chunk *chunk, const unsigned char *blocks, int chunkX, int chunkZ)
{
    CloneMCJ_Chunk_Initialize(chunk, chunkX, chunkZ);
    if (chunk && blocks) { memcpy(chunk->blocks, blocks, CLONEMC_J_CHUNK_BLOCK_COUNT); }
    if (chunk) { CloneMCJ_Chunk_GenerateHeightMap(chunk, CloneMCJ_Chunk_DefaultOpacity, 0); }
}

void CloneMCJ_Chunk_Destroy(CloneMCJ_Chunk *chunk)
{
    if (!chunk) { return; }
    chunk->isChunkLoaded = 0;
    chunk->loaded = 0;
    chunk->state = CLONEMC_J_CHUNK_STATE_UNLOADED;
}

int CloneMCJ_Chunk_IsAtLocation(const CloneMCJ_Chunk *chunk, int chunkX, int chunkZ)
{
    return chunk && chunk->xPosition == chunkX && chunk->zPosition == chunkZ;
}

int CloneMCJ_Chunk_GetHeightValue(const CloneMCJ_Chunk *chunk, int localX, int localZ)
{
    if (!chunk || localX < 0 || localX >= 16 || localZ < 0 || localZ >= 16) { return 0; }
    return (int)(chunk->heightMap[(localZ << 4) | localX] & 0xFF);
}

void CloneMCJ_Chunk_GenerateHeightMap(CloneMCJ_Chunk *chunk, CloneMCJ_BlockLightOpacityProc opacityProc, void *userData)
{
    int x;
    int z;
    int y;
    int lowest;
    int height;
    int blockID;
    int skyLight;
    if (!chunk) { return; }
    if (!opacityProc) { opacityProc = CloneMCJ_Chunk_DefaultOpacity; }
    lowest = 127;
    for (x = 0; x < 16; ++x) {
        for (z = 0; z < 16; ++z) {
            height = 127;
            while (height > 0) {
                blockID = chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, height - 1, z)] & 0xFF;
                if (opacityProc(blockID, userData) != 0) { break; }
                --height;
            }
            chunk->heightMap[(z << 4) | x] = (unsigned char)(height & 0xFF);
            if (height < lowest) { lowest = height; }
            skyLight = 15;
            for (y = 127; y > 0; --y) {
                skyLight -= opacityProc(chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] & 0xFF, userData);
                if (skyLight < 0) { skyLight = 0; }
                CloneMCJ_NibbleArray_SetNibble(&chunk->skylightMap, x, y, z, skyLight);
            }
        }
    }
    chunk->lowestBlockHeight = lowest;
    chunk->isModified = 1;
    chunk->lightDirty = 1;
    chunk->meshDirty = 1;
}

static void CloneMCJ_Chunk_UpdateColumnHeight(CloneMCJ_Chunk *chunk, int localX, int localZ, CloneMCJ_BlockLightOpacityProc opacityProc, void *userData)
{
    int column;
    int height;
    int blockID;
    int oldHeight;
    int lowest;
    int skyLight;
    int x;
    int z;
    int y;
    if (!chunk) { return; }
    if (!opacityProc) { opacityProc = CloneMCJ_Chunk_DefaultOpacity; }
    oldHeight = CloneMCJ_Chunk_GetHeightValue(chunk, localX, localZ);
    height = 127;
    while (height > 0) {
        blockID = chunk->blocks[CloneMCJ_Chunk_BlockIndex(localX, height - 1, localZ)] & 0xFF;
        if (opacityProc(blockID, userData) != 0) { break; }
        --height;
    }
    column=(localZ<<4)|localX;
    chunk->heightMap[column]=(unsigned char)(height&0xFF);
    if(height==oldHeight)return;

    /* V128: a block edit changes one vertical column.  The old path called
     * GenerateHeightMap, rescanning all 32,768 blocks and rewriting skylight
     * for all 256 columns.  Recompute only this column, then find the minimum
     * from the already maintained 256-byte height map. */
    skyLight=15;
    for(y=127;y>0;--y){
        blockID=chunk->blocks[CloneMCJ_Chunk_BlockIndex(localX,y,localZ)]&0xFF;
        skyLight-=opacityProc(blockID,userData);
        if(skyLight<0)skyLight=0;
        CloneMCJ_NibbleArray_SetNibble(&chunk->skylightMap,
            localX,y,localZ,skyLight);
    }
    lowest=127;
    for(z=0;z<16;++z)for(x=0;x<16;++x){
        height=(int)(chunk->heightMap[(z<<4)|x]&0xFF);
        if(height<lowest)lowest=height;
    }
    chunk->lowestBlockHeight=lowest;
}

int CloneMCJ_Chunk_GetBlockID(const CloneMCJ_Chunk *chunk, int localX, int y, int localZ)
{
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return 0; }
    return chunk->blocks[CloneMCJ_Chunk_BlockIndex(localX, y, localZ)] & 0xFF;
}

int CloneMCJ_Chunk_SetBlockIDWithMetadata(CloneMCJ_Chunk *chunk, int localX, int y, int localZ, int blockID, int metadata, CloneMCJ_BlockLightOpacityProc opacityProc, void *userData)
{
    unsigned long index;
    int oldBlock;
    int oldMeta;
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return 0; }
    index = CloneMCJ_Chunk_BlockIndex(localX, y, localZ);
    oldBlock = chunk->blocks[index] & 0xFF;
    oldMeta = CloneMCJ_NibbleArray_GetNibble(&chunk->data, localX, y, localZ);
    if (oldBlock == blockID && oldMeta == (metadata & 0x0F)) { return 0; }
    chunk->blocks[index] = (unsigned char)(blockID & 0xFF);
    CloneMCJ_NibbleArray_SetNibble(&chunk->data, localX, y, localZ, metadata);
    CloneMCJ_Chunk_UpdateColumnHeight(chunk, localX, localZ, opacityProc, userData);
    chunk->isModified = 1;
    chunk->lightDirty = 1;
    chunk->meshDirty = 1;
    if (chunk->state == CLONEMC_J_CHUNK_STATE_READY) { chunk->state = CLONEMC_J_CHUNK_STATE_DIRTY_SAVE_QUEUED; }
    return 1;
}

int CloneMCJ_Chunk_SetBlockID(CloneMCJ_Chunk *chunk, int localX, int y, int localZ, int blockID, CloneMCJ_BlockLightOpacityProc opacityProc, void *userData)
{
    return CloneMCJ_Chunk_SetBlockIDWithMetadata(chunk, localX, y, localZ, blockID, 0, opacityProc, userData);
}

int CloneMCJ_Chunk_GetBlockMetadata(const CloneMCJ_Chunk *chunk, int localX, int y, int localZ)
{
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return 0; }
    return CloneMCJ_NibbleArray_GetNibble(&chunk->data, localX, y, localZ);
}

void CloneMCJ_Chunk_SetBlockMetadata(CloneMCJ_Chunk *chunk, int localX, int y, int localZ, int metadata)
{
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return; }
    CloneMCJ_NibbleArray_SetNibble(&chunk->data, localX, y, localZ, metadata);
    chunk->isModified = 1;
    chunk->meshDirty = 1;
    if (chunk->state == CLONEMC_J_CHUNK_STATE_READY)
        chunk->state = CLONEMC_J_CHUNK_STATE_DIRTY_SAVE_QUEUED;
}

int CloneMCJ_Chunk_GetSavedLightValue(const CloneMCJ_Chunk *chunk, int skyBlock, int localX, int y, int localZ)
{
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return 0; }
    if (skyBlock == 0) { return CloneMCJ_NibbleArray_GetNibble(&chunk->skylightMap, localX, y, localZ); }
    return CloneMCJ_NibbleArray_GetNibble(&chunk->blocklightMap, localX, y, localZ);
}

void CloneMCJ_Chunk_SetLightValue(CloneMCJ_Chunk *chunk, int skyBlock, int localX, int y, int localZ, int value)
{
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return; }
    if (skyBlock == 0) { CloneMCJ_NibbleArray_SetNibble(&chunk->skylightMap, localX, y, localZ, value); }
    else { CloneMCJ_NibbleArray_SetNibble(&chunk->blocklightMap, localX, y, localZ, value); }
    chunk->isModified = 1;
    chunk->meshDirty = 1;
}

int CloneMCJ_Chunk_GetBlockLightValue(const CloneMCJ_Chunk *chunk, int localX, int y, int localZ, int skylightSubtracted)
{
    int sky;
    int block;
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return 0; }
    sky = CloneMCJ_NibbleArray_GetNibble(&chunk->skylightMap, localX, y, localZ) - skylightSubtracted;
    if (sky < 0) { sky = 0; }
    block = CloneMCJ_NibbleArray_GetNibble(&chunk->blocklightMap, localX, y, localZ);
    return block > sky ? block : sky;
}

int CloneMCJ_Chunk_CanBlockSeeTheSky(const CloneMCJ_Chunk *chunk, int localX, int y, int localZ)
{
    return chunk && y >= CloneMCJ_Chunk_GetHeightValue(chunk, localX, localZ);
}

void CloneMCJ_Chunk_SetModified(CloneMCJ_Chunk *chunk)
{
    if (!chunk) { return; }
    chunk->isModified = 1;
    chunk->state = CLONEMC_J_CHUNK_STATE_DIRTY_SAVE_QUEUED;
}

int CloneMCJ_Chunk_NeedsSaving(const CloneMCJ_Chunk *chunk, int force, CloneMCJLong worldTime)
{
    if (!chunk || chunk->neverSave) { return 0; }
    /* Direct Java Chunk.needsSaving parity.  The old C condition returned true
     * for every entity-bearing chunk during a forced save, even immediately
     * after that chunk had been written and lastSaveTime updated.  The save
     * progress counter therefore never reached zero and large worlds waited
     * for the 30-second watchdog.  Normal autosaves were also writing entity
     * chunks on practically every pass instead of using Java's 600-tick grace. */
    if (force) {
        if (chunk->hasEntities && worldTime != chunk->lastSaveTime) { return 1; }
    } else if (chunk->hasEntities && worldTime >= chunk->lastSaveTime + 600) {
        return 1;
    }
    return chunk->isModified;
}

int CloneMCJ_Chunk_AddEntity(CloneMCJ_Chunk *chunk, void *entity, double entityY)
{
    int slice;
    if (!chunk || !entity) { return 0; }
    slice = (int)(entityY / 16.0);
    if (slice < 0) { slice = 0; }
    if (slice >= CLONEMC_J_CHUNK_ENTITY_SLICES) { slice = CLONEMC_J_CHUNK_ENTITY_SLICES - 1; }
    if (chunk->entityCount[slice] >= CLONEMC_J_CHUNK_MAX_ENTITIES_PER_SLICE) { return 0; }
    chunk->entities[slice][chunk->entityCount[slice]++] = entity;
    chunk->hasEntities = 1;
    return 1;
}

int CloneMCJ_Chunk_RemoveEntity(CloneMCJ_Chunk *chunk, void *entity, int forcedSlice)
{
    int startSlice;
    int endSlice;
    int slice;
    int i;
    int j;
    if (!chunk || !entity) { return 0; }
    startSlice = forcedSlice >= 0 ? forcedSlice : 0;
    endSlice = forcedSlice >= 0 ? forcedSlice + 1 : CLONEMC_J_CHUNK_ENTITY_SLICES;
    for (slice = startSlice; slice < endSlice; ++slice) {
        if (slice < 0 || slice >= CLONEMC_J_CHUNK_ENTITY_SLICES) { continue; }
        for (i = 0; i < (int)chunk->entityCount[slice]; ++i) {
            if (chunk->entities[slice][i] == entity) {
                for (j = i + 1; j < (int)chunk->entityCount[slice]; ++j) { chunk->entities[slice][j - 1] = chunk->entities[slice][j]; }
                chunk->entityCount[slice]--;
                return 1;
            }
        }
    }
    return 0;
}

int CloneMCJ_Chunk_SetTileEntity(CloneMCJ_Chunk *chunk, int localX, int y, int localZ, void *tileEntity)
{
    int i;
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return 0; }
    for (i = 0; i < (int)chunk->tileEntityCount; ++i) {
        if (chunk->tileEntityX[i] == localX && chunk->tileEntityY[i] == y && chunk->tileEntityZ[i] == localZ) {
            chunk->tileEntities[i] = tileEntity;
            CloneMCJ_Chunk_SetModified(chunk);
            return 1;
        }
    }
    if (chunk->tileEntityCount >= CLONEMC_J_CHUNK_MAX_TILE_ENTITIES) { return 0; }
    i = chunk->tileEntityCount++;
    chunk->tileEntityX[i] = localX;
    chunk->tileEntityY[i] = y;
    chunk->tileEntityZ[i] = localZ;
    chunk->tileEntities[i] = tileEntity;
    CloneMCJ_Chunk_SetModified(chunk);
    return 1;
}

void *CloneMCJ_Chunk_GetTileEntity(const CloneMCJ_Chunk *chunk, int localX, int y, int localZ)
{
    int i;
    if (!chunk) { return 0; }
    for (i = 0; i < (int)chunk->tileEntityCount; ++i) {
        if (chunk->tileEntityX[i] == localX && chunk->tileEntityY[i] == y && chunk->tileEntityZ[i] == localZ) { return chunk->tileEntities[i]; }
    }
    return 0;
}

void CloneMCJ_Chunk_RemoveTileEntity(CloneMCJ_Chunk *chunk, int localX, int y, int localZ)
{
    int i;
    int j;
    if (!chunk) { return; }
    for (i = 0; i < (int)chunk->tileEntityCount; ++i) {
        if (chunk->tileEntityX[i] == localX && chunk->tileEntityY[i] == y && chunk->tileEntityZ[i] == localZ) {
            for (j = i + 1; j < (int)chunk->tileEntityCount; ++j) {
                chunk->tileEntityX[j - 1] = chunk->tileEntityX[j];
                chunk->tileEntityY[j - 1] = chunk->tileEntityY[j];
                chunk->tileEntityZ[j - 1] = chunk->tileEntityZ[j];
                chunk->tileEntities[j - 1] = chunk->tileEntities[j];
            }
            chunk->tileEntityCount--;
            CloneMCJ_Chunk_SetModified(chunk);
            return;
        }
    }
}

int CloneMCJ_Chunk_ScheduleTick(CloneMCJ_Chunk *chunk, int localX, int y, int localZ, int blockID, CloneMCJLong scheduledTime)
{
    CloneMCJ_NextTickListEntry *entry;
    if (!chunk || !CloneMCJ_Chunk_IsLocalPositionValid(localX, y, localZ)) { return 0; }
    if (chunk->scheduledTickCount >= CLONEMC_J_CHUNK_MAX_SCHEDULED_TICKS) { return 0; }
    entry = &chunk->scheduledTicks[chunk->scheduledTickCount++];
    CloneMCJ_NextTickListEntry_Initialize(entry, chunk->xPosition * 16 + localX, y, chunk->zPosition * 16 + localZ, blockID);
    CloneMCJ_NextTickListEntry_SetScheduledTime(entry, scheduledTime);
    CloneMCJ_Chunk_SetModified(chunk);
    return 1;
}

CloneMCJavaRandom CloneMCJ_Chunk_CreateRandom(const CloneMCJ_Chunk *chunk, CloneMCJLong worldSeed, CloneMCJLong salt)
{
    CloneMCJavaRandom random;
    CloneMCJLong seed;
    int x;
    int z;
    x = chunk ? chunk->xPosition : 0;
    z = chunk ? chunk->zPosition : 0;
    seed = worldSeed + (CloneMCJLong)(x * x * 0x4C1906) + (CloneMCJLong)(x * 0x5AC0DB) + (CloneMCJLong)(z * z) * (CloneMCJLong)0x4307A7 + (CloneMCJLong)(z * 0x5F24F);
    seed = seed ^ salt;
    CloneMCJavaRandom_SetSeed(&random, seed);
    return random;
}

static int CloneMCChunk_SelfTestOpacity(int blockID, void *userData)
{
    (void)userData;
    return blockID == 0 ? 0 : 255;
}

int CloneMCChunk_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJ_Chunk chunk;
    CloneMCJ_World world;
    int ok;
    ok = 1;
    CloneMCJ_Chunk_Initialize(&chunk, -1, 2);
    if (CloneMCJ_Chunk_BlockIndex(1, 2, 3) != (unsigned long)((1 << 11) | (3 << 7) | 2)) { ok = 0; }
    if (!CloneMCJ_Chunk_SetBlockIDWithMetadata(&chunk, 1, 64, 3, 2, 7, CloneMCChunk_SelfTestOpacity, 0)) { ok = 0; }
    if (CloneMCJ_Chunk_GetBlockID(&chunk, 1, 64, 3) != 2) { ok = 0; }
    if (CloneMCJ_Chunk_GetBlockMetadata(&chunk, 1, 64, 3) != 7) { ok = 0; }
    if (CloneMCJ_Chunk_GetHeightValue(&chunk, 1, 3) != 65) { ok = 0; }
    if (!CloneMCJ_Chunk_CanBlockSeeTheSky(&chunk, 1, 65, 3)) { ok = 0; }
    chunk.isModified = 0;
    chunk.hasEntities = 1;
    chunk.lastSaveTime = (CloneMCJLong)1000;
    if (CloneMCJ_Chunk_NeedsSaving(&chunk, 1, (CloneMCJLong)1000)) { ok = 0; }
    if (!CloneMCJ_Chunk_NeedsSaving(&chunk, 1, (CloneMCJLong)1001)) { ok = 0; }
    if (CloneMCJ_Chunk_NeedsSaving(&chunk, 0, (CloneMCJLong)1599)) { ok = 0; }
    if (!CloneMCJ_Chunk_NeedsSaving(&chunk, 0, (CloneMCJLong)1600)) { ok = 0; }
    chunk.hasEntities = 0;
    CloneMCJ_Chunk_SetModified(&chunk);
    if (!CloneMCJ_Chunk_NeedsSaving(&chunk, 1, (CloneMCJLong)1600)) { ok = 0; }
    CloneMCJ_Chunk_Destroy(&chunk);
    CloneMCJ_World_Initialize(&world, (CloneMCJLong)12345, 1);
    CloneMCJ_World_SetBlockWithMetadata(&world, -1, 70, -1, 5, 4);
    if (CloneMCJ_World_GetBlockId(&world, -1, 70, -1) != 5) { ok = 0; }
    if (CloneMCJ_World_GetBlockMetadata(&world, -1, 70, -1) != 4) { ok = 0; }
    CloneMCJ_World_SetPlayerGlobalPosition(&world, 513.0, -513.0);
    if (CloneMCJ_World_CountLoadedChunks(&world) <= 0) { ok = 0; }
    CloneMCJ_World_Destroy(&world);
    if (message && messageCapacity > 0) {
        if (ok) { strncpy(message, "Priority 3 Java chunk and bounded entity-save tests passed.", messageCapacity - 1); }
        else { strncpy(message, "Priority 3 Java chunk model self-tests failed.", messageCapacity - 1); }
        message[messageCapacity - 1] = '\0';
    }
    return ok;
}
