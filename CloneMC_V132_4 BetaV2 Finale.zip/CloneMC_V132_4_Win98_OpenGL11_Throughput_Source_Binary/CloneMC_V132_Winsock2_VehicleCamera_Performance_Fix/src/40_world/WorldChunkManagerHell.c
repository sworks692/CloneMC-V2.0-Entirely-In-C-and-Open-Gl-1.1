/*
 * CloneMC Java port scaffold: WorldChunkManagerHell
 *
 * Java source: WorldChunkManagerHell.java
 * Java type: class WorldChunkManagerHell
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldChunkManager
 * Implements: (none declared)
 * Source SHA-256: 796bebcc5f29ed7166a7132f6bdf53226bc537ba0993adc8185873e4546d314d
 * Java lines: 74
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: WorldChunkManager, BiomeGenBase, ChunkCoordIntPair, i, j, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private BiomeGenBase field_4201_e
 * - private double field_4200_f
 * - private double field_4199_g
 *
 * Java method/constructor inventory:
 * - public WorldChunkManagerHell(BiomeGenBase biomegenbase, double d, double d1)
 * - public BiomeGenBase getBiomeGenAtChunkCoord(ChunkCoordIntPair chunkcoordintpair)
 * - public BiomeGenBase getBiomeGenAt(int i, int j)
 * - public double getTemperature(int i, int j)
 * - public BiomeGenBase[] func_4069_a(int i, int j, int k, int l)
 * - public double[] getTemperatures(double ad[], int i, int j, int k, int l)
 * - public BiomeGenBase[] loadBlockGeneratorData(BiomeGenBase abiomegenbase[], int i, int j, int k, int l)
 *
 * Priority 11 directly implements the Java fixed-biome/fixed-climate manager.
 */
#include "clonemc_java_port_40_world.h"
#include <string.h>

int CloneMCJ_WorldChunkManager_InitializeFixed(CloneMCJ_WorldChunkManager *manager,
    int biomeID, double temperature, double humidity)
{
    if (!manager) return 0;
    memset(manager, 0, sizeof(*manager));
    CloneMCJ_BiomeGenBase_InitializeTable();
    manager->fixedBiomeID = biomeID;
    manager->fixedTemperature = temperature;
    manager->fixedHumidity = humidity;
    manager->fixedMode = 1;
    manager->initialized = 1;
    return 1;
}

void CloneMCJ_WorldChunkManagerHell_Register(void)
{
    CloneMCJ_BiomeGenBase_InitializeTable();
}

const char *CloneMCJ_WorldChunkManagerHell_JavaName(void)
{
    return "net.minecraft.src.WorldChunkManagerHell";
}

const char *CloneMCJ_WorldChunkManagerHell_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldChunkManagerHell_JavaSourceHash32(void)
{
    return 0x796BEBCCUL;
}
