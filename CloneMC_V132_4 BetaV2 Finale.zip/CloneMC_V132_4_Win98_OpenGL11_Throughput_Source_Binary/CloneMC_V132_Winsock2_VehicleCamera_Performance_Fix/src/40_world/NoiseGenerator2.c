/*
 * CloneMC direct Java-compatible port: NoiseGenerator2
 *
 * Java source: NoiseGenerator2.java
 * Java type: class NoiseGenerator2
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: fd270b164d60640d27cda97d3efce931993bd653c2c655923c0ca7e32dfa50d8
 * Java lines: 159
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_4295_e[]
 * - public double field_4292_a
 * - public double field_4291_b
 * - public double field_4297_c
 *
 * Java method/constructor inventory:
 * - public NoiseGenerator2()
 * - public NoiseGenerator2(Random random)
 * - private static int wrap(double d)
 * - private static double func_4156_a(int ai[], double d, double d1)
 * - private static final double field_4294_f = 0.5 * (Math.sqrt(3) - 1.0)
 * - private static final double field_4293_g = (3 - Math.sqrt(3)) / 6
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <math.h>

void CloneMCJ_NoiseGenerator2_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_NoiseGenerator2_JavaName(void)
{
    return "net.minecraft.src.NoiseGenerator2";
}

const char *CloneMCJ_NoiseGenerator2_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_NoiseGenerator2_JavaSourceHash32(void)
{
    return 0xFD270B16UL;
}

static const int g_cloneMCSimplexGradients[12][3] = {
    { 1, 1, 0}, {-1, 1, 0}, { 1,-1, 0}, {-1,-1, 0},
    { 1, 0, 1}, {-1, 0, 1}, { 1, 0,-1}, {-1, 0,-1},
    { 0, 1, 1}, { 0,-1, 1}, { 0, 1,-1}, { 0,-1,-1}
};

static int CloneMCNoiseSimplex_Wrap(double value)
{
    return value <= 0.0 ? (int)value - 1 : (int)value;
}

static double CloneMCNoiseSimplex_Dot(const int gradient[3], double x, double z)
{
    return (double)gradient[0] * x + (double)gradient[1] * z;
}

void CloneMCNoiseSimplex_Initialize(CloneMCNoiseSimplex *noise, CloneMCJavaRandom *random)
{
    int index;
    int swapIndex;
    int temporary;
    if (!noise || !random) { return; }
    noise->xCoord = CloneMCJavaRandom_NextDouble(random) * 256.0;
    noise->yCoord = CloneMCJavaRandom_NextDouble(random) * 256.0;
    noise->zCoord = CloneMCJavaRandom_NextDouble(random) * 256.0;
    for (index = 0; index < 256; ++index) { noise->permutations[index] = index; }
    for (index = 0; index < 256; ++index) {
        swapIndex = (int)CloneMCJavaRandom_NextIntBound(random, (CloneMCJInt)(256 - index)) + index;
        temporary = noise->permutations[index];
        noise->permutations[index] = noise->permutations[swapIndex];
        noise->permutations[swapIndex] = temporary;
        noise->permutations[index + 256] = noise->permutations[index];
    }
}

void CloneMCNoiseSimplex_Add(const CloneMCNoiseSimplex *noise, double *values,
                             double x, double z, int xSize, int zSize,
                             double xScale, double zScale, double amplitude)
{
    double skewFactor;
    double unskewFactor;
    double sampleX;
    double sampleZ;
    double skew;
    double unskew;
    double x0;
    double z0;
    double x1;
    double z1;
    double x2;
    double z2;
    double attenuation;
    double n0;
    double n1;
    double n2;
    int ix;
    int iz;
    int gridX;
    int gridZ;
    int stepX;
    int stepZ;
    int hashX;
    int hashZ;
    int gradient0;
    int gradient1;
    int gradient2;
    unsigned long output;
    if (!noise || !values || xSize <= 0 || zSize <= 0) { return; }
    skewFactor = 0.5 * (sqrt(3.0) - 1.0);
    unskewFactor = (3.0 - sqrt(3.0)) / 6.0;
    output = 0UL;
    for (ix = 0; ix < xSize; ++ix) {
        sampleX = (x + (double)ix) * xScale + noise->xCoord;
        for (iz = 0; iz < zSize; ++iz) {
            sampleZ = (z + (double)iz) * zScale + noise->yCoord;
            skew = (sampleX + sampleZ) * skewFactor;
            gridX = CloneMCNoiseSimplex_Wrap(sampleX + skew);
            gridZ = CloneMCNoiseSimplex_Wrap(sampleZ + skew);
            unskew = (double)(gridX + gridZ) * unskewFactor;
            x0 = sampleX - ((double)gridX - unskew);
            z0 = sampleZ - ((double)gridZ - unskew);
            if (x0 > z0) { stepX = 1; stepZ = 0; }
            else { stepX = 0; stepZ = 1; }
            x1 = (x0 - (double)stepX) + unskewFactor;
            z1 = (z0 - (double)stepZ) + unskewFactor;
            x2 = (x0 - 1.0) + 2.0 * unskewFactor;
            z2 = (z0 - 1.0) + 2.0 * unskewFactor;
            hashX = gridX & 255;
            hashZ = gridZ & 255;
            gradient0 = noise->permutations[hashX + noise->permutations[hashZ]] % 12;
            gradient1 = noise->permutations[hashX + stepX +
                noise->permutations[hashZ + stepZ]] % 12;
            gradient2 = noise->permutations[hashX + 1 + noise->permutations[hashZ + 1]] % 12;
            attenuation = 0.5 - x0 * x0 - z0 * z0;
            if (attenuation < 0.0) { n0 = 0.0; }
            else { attenuation *= attenuation; n0 = attenuation * attenuation *
                CloneMCNoiseSimplex_Dot(g_cloneMCSimplexGradients[gradient0], x0, z0); }
            attenuation = 0.5 - x1 * x1 - z1 * z1;
            if (attenuation < 0.0) { n1 = 0.0; }
            else { attenuation *= attenuation; n1 = attenuation * attenuation *
                CloneMCNoiseSimplex_Dot(g_cloneMCSimplexGradients[gradient1], x1, z1); }
            attenuation = 0.5 - x2 * x2 - z2 * z2;
            if (attenuation < 0.0) { n2 = 0.0; }
            else { attenuation *= attenuation; n2 = attenuation * attenuation *
                CloneMCNoiseSimplex_Dot(g_cloneMCSimplexGradients[gradient2], x2, z2); }
            values[output++] += 70.0 * (n0 + n1 + n2) * amplitude;
        }
    }
}
