/*
 * CloneMC Java port scaffold: WorldProvider
 *
 * Java source: WorldProvider.java
 * Java type: class WorldProvider
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: d31e96917f52974daee1f238f6d0d413397b2da6bfb6f34f256684de8f47dfbc
 * Java lines: 162
 * Discovered declared fields: 8
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: WorldChunkManager, ChunkProviderGenerate, World, Block, MathHelper, Vec3D, WorldProviderHell, WorldProviderSurface, WorldProviderSky, IChunkProvider, float
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public World worldObj
 * - public WorldChunkManager worldChunkMgr
 * - public boolean isNether
 * - public boolean isHellWorld
 * - public boolean hasNoSky
 * - public float lightBrightnessTable[]
 * - public int worldType
 * - private float colorsSunriseSunset[]
 *
 * Java method/constructor inventory:
 * - public WorldProvider()
 * - public final void registerWorld(World world)
 * - protected void generateLightBrightnessTable()
 * - protected void registerWorldChunkManager()
 * - public IChunkProvider getChunkProvider()
 * - public boolean canCoordinateBeSpawn(int i, int j)
 * - public float calculateCelestialAngle(long l, float f)
 * - public float[] calcSunriseSunsetColors(float f, float f1)
 * - public Vec3D func_4096_a(float f, float f1)
 * - public boolean canRespawnHere()
 * - public static WorldProvider getProviderForDimension(int i)
 * - public float getCloudHeight()
 * - public boolean func_28112_c()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"
#include <math.h>
#include <string.h>

void CloneMCJ_WorldProvider_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldProvider_JavaName(void)
{
    return "net.minecraft.src.WorldProvider";
}

const char *CloneMCJ_WorldProvider_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldProvider_JavaSourceHash32(void)
{
    return 0xD31E9691UL;
}

/* Priority 6 direct behavior from WorldProvider.java.  The provider remains a
 * value owned by World so no allocation or vtable is required by Open Watcom. */
void CloneMCJ_WorldProvider_GenerateLightBrightnessTable(CloneMCJ_WorldProvider *provider)
{
    int i;
    float ambient;
    float inverse;
    if (!provider) { return; }
    ambient = 0.05F;
    for (i = 0; i <= 15; ++i) {
        inverse = 1.0F - (float)i / 15.0F;
        provider->lightBrightnessTable[i] =
            ((1.0F - inverse) / (inverse * 3.0F + 1.0F)) * (1.0F - ambient) + ambient;
    }
}

void CloneMCJ_WorldProvider_InitializeSurface(CloneMCJ_WorldProvider *provider)
{
    if (!provider) { return; }
    memset(provider, 0, sizeof(*provider));
    provider->worldType = 0;
    CloneMCJ_WorldProvider_GenerateLightBrightnessTable(provider);
}

float CloneMCJ_WorldProvider_CalculateCelestialAngle(CloneMCJLong worldTime, float partialTick)
{
    int dayTick;
    float linear;
    float original;
    dayTick = (int)(worldTime % (CloneMCJLong)CLONEMC_J_WORLD_DAY_TICKS);
    linear = ((float)dayTick + partialTick) / 24000.0F - 0.25F;
    if (linear < 0.0F) { linear += 1.0F; }
    if (linear > 1.0F) { linear -= 1.0F; }
    original = linear;
    linear = 1.0F - (float)((cos((double)linear * 3.1415926535897931) + 1.0) / 2.0);
    return original + (linear - original) / 3.0F;
}

int CloneMCJ_WorldProvider_CalcSunriseSunsetColors(CloneMCJ_WorldProvider *provider,
    float celestialAngle, float partialTick, float *colors)
{
    float width;
    float cosine;
    float center;
    float phase;
    float alpha;
    (void)partialTick;
    if (!provider) { return 0; }
    width = 0.4F;
    cosine = CloneMCMathHelper_Cos(celestialAngle * 3.141593F * 2.0F);
    center = 0.0F;
    if (cosine < center - width || cosine > center + width) { return 0; }
    phase = ((cosine - center) / width) * 0.5F + 0.5F;
    alpha = 1.0F - (1.0F - CloneMCMathHelper_Sin(phase * 3.141593F)) * 0.99F;
    alpha *= alpha;
    provider->colorsSunriseSunset[0] = phase * 0.3F + 0.7F;
    provider->colorsSunriseSunset[1] = phase * phase * 0.7F + 0.2F;
    provider->colorsSunriseSunset[2] = 0.2F;
    provider->colorsSunriseSunset[3] = alpha;
    if (colors) { memcpy(colors, provider->colorsSunriseSunset, sizeof(provider->colorsSunriseSunset)); }
    return 1;
}

void CloneMCJ_WorldProvider_GetFogColor(float celestialAngle, float partialTick,
    float *red, float *green, float *blue)
{
    float brightness;
    (void)partialTick;
    brightness = CloneMCMathHelper_Cos(celestialAngle * 3.141593F * 2.0F) * 2.0F + 0.5F;
    if (brightness < 0.0F) { brightness = 0.0F; }
    if (brightness > 1.0F) { brightness = 1.0F; }
    if (red) { *red = 0.7529412F * (brightness * 0.94F + 0.06F); }
    if (green) { *green = 0.8470588F * (brightness * 0.94F + 0.06F); }
    if (blue) { *blue = 1.0F * (brightness * 0.91F + 0.09F); }
}
