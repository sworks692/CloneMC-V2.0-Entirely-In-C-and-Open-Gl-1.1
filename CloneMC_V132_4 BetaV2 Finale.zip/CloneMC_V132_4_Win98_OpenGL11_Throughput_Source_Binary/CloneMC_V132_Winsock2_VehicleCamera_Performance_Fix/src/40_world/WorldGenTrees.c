/*
 * CloneMC direct Java-compatible port: WorldGenTrees
 *
 * Java source: WorldGenTrees.java
 * Java type: class WorldGenTrees
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 13cf0503751af1667f51a82be4689b7d92b0075407adb9021e4e18bbb618e118
 * Java lines: 102
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, BlockLeaves, BlockGrass, i1, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldGenTrees()
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <stdlib.h>

void CloneMCJ_WorldGenTrees_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenTrees_JavaName(void)
{
    return "net.minecraft.src.WorldGenTrees";
}

const char *CloneMCJ_WorldGenTrees_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenTrees_JavaSourceHash32(void)
{
    return 0x13CF0503UL;
}

static int CloneMCJ_Tree_CheckSpace(CloneMCJ_World *world,int x,int y,int z,int height,int topRadius)
{
    int yy,xx,zz,r;
    if(y<1||y+height+1>128) return 0;
    for(yy=y;yy<=y+height+1;++yy){
        r=1; if(yy==y) r=0; if(yy>=(y+height)-1) r=topRadius;
        for(xx=x-r;xx<=x+r;++xx) for(zz=z-r;zz<=z+r;++zz)
            if(yy<0||yy>=128||!CloneMCJ_World_IsReplaceableForTree(CloneMCJ_World_GetBlockId(world,xx,yy,zz))) return 0;
    }
    return 1;
}

static int CloneMCJ_Tree_GenerateVariant(CloneMCJ_World *world,CloneMCJavaRandom *random,int x,int y,int z,int variant)
{
    int height,ground,yy,xx,zz,r,meta;
    if(!world||!random) return 0;
    meta=0;
    if(variant==1){ height=5+CloneMCJavaRandom_NextIntBound(random,3); meta=2; }
    else if(variant==2){ height=7+CloneMCJavaRandom_NextIntBound(random,5); }
    else { height=4+CloneMCJavaRandom_NextIntBound(random,3); }
    if(!CloneMCJ_Tree_CheckSpace(world,x,y,z,height,2)) return 0;
    ground=CloneMCJ_World_GetBlockId(world,x,y-1,z);
    if((ground!=CLONEMC_J_BLOCK_GRASS&&ground!=CLONEMC_J_BLOCK_DIRT)||y>=128-height-1) return 0;
    CloneMCJ_World_SetBlock(world,x,y-1,z,CLONEMC_J_BLOCK_DIRT);
    for(yy=(y-3)+height;yy<=y+height;++yy){
        int rel=yy-(y+height); r=1-rel/2;
        if(variant==2&&yy<y+height-2) ++r;
        for(xx=x-r;xx<=x+r;++xx) for(zz=z-r;zz<=z+r;++zz){
            int dx=xx-x,dz=zz-z;
            if((abs(dx)!=r||abs(dz)!=r||CloneMCJavaRandom_NextIntBound(random,2)!=0||rel==0) &&
               !CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,xx,yy,zz)))
                CloneMCJ_World_SetBlockWithMetadata(world,xx,yy,zz,CLONEMC_J_BLOCK_LEAVES,meta);
        }
    }
    for(yy=0;yy<height;++yy){
        int id=CloneMCJ_World_GetBlockId(world,x,y+yy,z);
        if(id==CLONEMC_J_BLOCK_AIR||id==CLONEMC_J_BLOCK_LEAVES)
            CloneMCJ_World_SetBlockWithMetadata(world,x,y+yy,z,CLONEMC_J_BLOCK_LOG,meta);
    }
    return 1;
}

int CloneMCJ_WorldGenTrees_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random, int x, int y, int z)
{ return CloneMCJ_Tree_GenerateVariant(world,random,x,y,z,0); }
