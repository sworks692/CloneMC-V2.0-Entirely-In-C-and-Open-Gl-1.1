/*
 * CloneMC direct Java-compatible port: BiomeGenDesert
 *
 * Java source: BiomeGenDesert.java
 * Java type: class BiomeGenDesert
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: BiomeGenBase
 * Implements: (none declared)
 * Source SHA-256: 101ad835a95a9a325f0bb9ebf318593209d77e72bd8270ddd613e772b1e849bd
 * Java lines: 18
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: BiomeGenBase
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BiomeGenDesert()
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_BiomeGenDesert_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BiomeGenDesert_JavaName(void)
{
    return "net.minecraft.src.BiomeGenDesert";
}

const char *CloneMCJ_BiomeGenDesert_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_BiomeGenDesert_JavaSourceHash32(void)
{
    return 0x101AD835UL;
}
