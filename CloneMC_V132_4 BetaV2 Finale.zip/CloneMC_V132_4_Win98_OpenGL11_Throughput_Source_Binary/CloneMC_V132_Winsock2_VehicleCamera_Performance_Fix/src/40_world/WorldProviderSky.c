/*
 * CloneMC Java port scaffold: WorldProviderSky
 *
 * Java source: WorldProviderSky.java
 * Java type: class WorldProviderSky
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldProvider
 * Implements: (none declared)
 * Source SHA-256: 38a24cf7826b141ebb267954daaf253f40f59490f3dc2d161aad207b03a76374
 * Java lines: 84
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: WorldProvider, WorldChunkManagerHell, BiomeGenBase, ChunkProviderSky, World, MathHelper, Vec3D, Block, Material, IChunkProvider, f4
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldProviderSky()
 * - public void registerWorldChunkManager()
 * - public IChunkProvider getChunkProvider()
 * - public float calculateCelestialAngle(long l, float f)
 * - public float[] calcSunriseSunsetColors(float f, float f1)
 * - public Vec3D func_4096_a(float f, float f1)
 * - public boolean func_28112_c()
 * - public float getCloudHeight()
 * - public boolean canCoordinateBeSpawn(int i, int j)
 *
 * Priority 11 directly implements dimension-one provider selection, fixed time,
 * Java sky tint and the ordinary 0.05 ambient-light table.
 */
#include "clonemc_java_port_40_world.h"
#include <string.h>

void CloneMCJ_WorldProviderSky_Initialize(CloneMCJ_WorldProvider *provider)
{
    if (!provider) return;
    memset(provider, 0, sizeof(*provider));
    provider->worldType = 1;
    CloneMCJ_WorldProvider_GenerateLightBrightnessTable(provider);
}

void CloneMCJ_WorldProviderSky_GetSkyColor(float celestialAngle,
    float *red, float *green, float *blue)
{
    float brightness;
    brightness = CloneMCMathHelper_Cos(celestialAngle * 3.141593F * 2.0F) * 2.0F + 0.5F;
    if (brightness < 0.0F) brightness = 0.0F;
    if (brightness > 1.0F) brightness = 1.0F;
    if (red) *red = (128.0F / 255.0F) * (brightness * 0.94F + 0.06F);
    if (green) *green = (128.0F / 255.0F) * (brightness * 0.94F + 0.06F);
    if (blue) *blue = (160.0F / 255.0F) * (brightness * 0.91F + 0.09F);
}

void CloneMCJ_WorldProviderSky_Register(void)
{
    /* Runtime state is value-owned by World. */
}

const char *CloneMCJ_WorldProviderSky_JavaName(void)
{
    return "net.minecraft.src.WorldProviderSky";
}

const char *CloneMCJ_WorldProviderSky_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldProviderSky_JavaSourceHash32(void)
{
    return 0x38A24CF7UL;
}
