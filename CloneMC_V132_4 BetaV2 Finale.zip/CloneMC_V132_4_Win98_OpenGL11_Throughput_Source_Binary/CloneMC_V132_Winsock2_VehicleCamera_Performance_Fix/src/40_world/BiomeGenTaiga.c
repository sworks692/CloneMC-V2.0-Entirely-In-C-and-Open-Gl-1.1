/*
 * CloneMC direct Java-compatible port: BiomeGenTaiga
 *
 * Java source: BiomeGenTaiga.java
 * Java type: class BiomeGenTaiga
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: BiomeGenBase
 * Implements: (none declared)
 * Source SHA-256: 758c593c00d3917641b844562c92d4790e6611a21d0208315480a6361f288f4f
 * Java lines: 33
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: BiomeGenBase, SpawnListEntry, EntityWolf, WorldGenTaiga1, WorldGenTaiga2, WorldGenerator
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BiomeGenTaiga()
 * - public WorldGenerator getRandomWorldGenForTrees(Random random)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_BiomeGenTaiga_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BiomeGenTaiga_JavaName(void)
{
    return "net.minecraft.src.BiomeGenTaiga";
}

const char *CloneMCJ_BiomeGenTaiga_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_BiomeGenTaiga_JavaSourceHash32(void)
{
    return 0x758C593CUL;
}

int CloneMCJ_BiomeGenTaiga_GenerateTree(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z)
{
    if (!world || !random) { return 0; }
    if (CloneMCJavaRandom_NextIntBound(random, 3) == 0) {
        return CloneMCJ_WorldGenTaiga1_Generate(world, random, x, y, z);
    }
    return CloneMCJ_WorldGenTaiga2_Generate(world, random, x, y, z);
}

