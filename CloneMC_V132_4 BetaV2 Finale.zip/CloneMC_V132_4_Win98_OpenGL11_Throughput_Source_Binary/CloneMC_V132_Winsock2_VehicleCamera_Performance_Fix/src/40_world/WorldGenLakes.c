/*
 * CloneMC direct Java-compatible port: WorldGenLakes
 *
 * Java source: WorldGenLakes.java
 * Java type: class WorldGenLakes
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: ca2b119ac97b7592f27d02f16fe0fe9a59738d1fa05790759a737f16ecff9871
 * Java lines: 141
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Material, Block, EnumSkyBlock, BlockGrass, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_15235_a
 *
 * Java method/constructor inventory:
 * - public WorldGenLakes(int i)
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldGenLakes_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenLakes_JavaName(void)
{
    return "net.minecraft.src.WorldGenLakes";
}

const char *CloneMCJ_WorldGenLakes_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenLakes_JavaSourceHash32(void)
{
    return 0xCA2B119AUL;
}

#include <string.h>
int CloneMCJ_WorldGenLakes_Generate(CloneMCJ_World *world,CloneMCJavaRandom *random,int x,int y,int z,int liquidID)
{
    unsigned char carved[2048]; int ellipses,e,a,b,c;
    if(!world||!random)return 0;
    x-=8;z-=8;while(y>0&&CloneMCJ_World_IsAirBlock(world,x,y,z))--y;y-=4;
    memset(carved,0,sizeof(carved));ellipses=CloneMCJavaRandom_NextIntBound(random,4)+4;
    for(e=0;e<ellipses;++e){
        double sx=CloneMCJavaRandom_NextDouble(random)*6.0+3.0;
        double sy=CloneMCJavaRandom_NextDouble(random)*4.0+2.0;
        double sz=CloneMCJavaRandom_NextDouble(random)*6.0+3.0;
        double cx=CloneMCJavaRandom_NextDouble(random)*(16.0-sx-2.0)+1.0+sx/2.0;
        double cy=CloneMCJavaRandom_NextDouble(random)*(8.0-sy-4.0)+2.0+sy/2.0;
        double cz=CloneMCJavaRandom_NextDouble(random)*(16.0-sz-2.0)+1.0+sz/2.0;
        for(a=1;a<15;++a)for(b=1;b<15;++b)for(c=1;c<7;++c){double dx=((double)a-cx)/(sx/2.0),dy=((double)c-cy)/(sy/2.0),dz=((double)b-cz)/(sz/2.0);if(dx*dx+dy*dy+dz*dz<1.0)carved[(a*16+b)*8+c]=1;}
    }
    for(a=0;a<16;++a)for(b=0;b<16;++b)for(c=0;c<8;++c){
        int idx=(a*16+b)*8+c;int edge=!carved[idx]&&((a<15&&carved[((a+1)*16+b)*8+c])||(a>0&&carved[((a-1)*16+b)*8+c])||(b<15&&carved[(a*16+b+1)*8+c])||(b>0&&carved[(a*16+b-1)*8+c])||(c<7&&carved[idx+1])||(c>0&&carved[idx-1]));
        if(edge){int id=CloneMCJ_World_GetBlockId(world,x+a,y+c,z+b);if(c>=4&&CloneMCJ_World_IsLiquidBlock(id))return 0;if(c<4&&!CloneMCJ_World_IsSolidBlockID(id)&&id!=liquidID)return 0;}
    }
    for(a=0;a<16;++a)for(b=0;b<16;++b)for(c=0;c<8;++c)if(carved[(a*16+b)*8+c])CloneMCJ_World_SetBlock(world,x+a,y+c,z+b,c<4?liquidID:CLONEMC_J_BLOCK_AIR);
    for(a=0;a<16;++a)for(b=0;b<16;++b)for(c=4;c<8;++c)if(carved[(a*16+b)*8+c]&&CloneMCJ_World_GetBlockId(world,x+a,y+c-1,z+b)==CLONEMC_J_BLOCK_DIRT&&CloneMCJ_World_GetSavedLightValue(world,CLONEMC_J_ENUM_SKY_BLOCK_SKY,x+a,y+c,z+b)>0)CloneMCJ_World_SetBlock(world,x+a,y+c-1,z+b,CLONEMC_J_BLOCK_GRASS);
    if(liquidID==CLONEMC_J_BLOCK_LAVA_STILL||liquidID==CLONEMC_J_BLOCK_LAVA_MOVING){
        for(a=0;a<16;++a)for(b=0;b<16;++b)for(c=0;c<8;++c){int idx=(a*16+b)*8+c;int edge=!carved[idx]&&((a<15&&carved[((a+1)*16+b)*8+c])||(a>0&&carved[((a-1)*16+b)*8+c])||(b<15&&carved[(a*16+b+1)*8+c])||(b>0&&carved[(a*16+b-1)*8+c])||(c<7&&carved[idx+1])||(c>0&&carved[idx-1]));if(edge&&(c<4||CloneMCJavaRandom_NextIntBound(random,2)!=0)&&CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,x+a,y+c,z+b)))CloneMCJ_World_SetBlock(world,x+a,y+c,z+b,CLONEMC_J_BLOCK_STONE);}
    }
    return 1;
}
