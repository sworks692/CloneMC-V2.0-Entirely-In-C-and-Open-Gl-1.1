/*
 * CloneMC direct Java-compatible port: ChunkProviderGenerate
 *
 * Java source: ChunkProviderGenerate.java
 * Java type: class ChunkProviderGenerate
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IChunkProvider
 * Source SHA-256: 190573316929b8d3ea6bcc1d02571ce566639d971bda56ab5076162ecf25fbb4
 * Java lines: 700
 * Discovered declared fields: 17
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: IChunkProvider, MapGenCaves, NoiseGeneratorOctaves, Block, BiomeGenBase, Chunk, World, WorldChunkManager, MapGenBase, BlockSand, WorldGenLakes, WorldGenDungeons, WorldGenClay, WorldGenMinable, WorldGenerator, WorldGenFlowers, BlockFlower, WorldGenTallGrass, BlockTallGrass, WorldGenDeadBush, BlockDeadBush, WorldGenReed, WorldGenPumpkin, WorldGenCactus, WorldGenLiquids, Material, IProgressUpdate, k, byte2
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Random rand
 * - private NoiseGeneratorOctaves field_912_k
 * - private NoiseGeneratorOctaves field_911_l
 * - private NoiseGeneratorOctaves field_910_m
 * - private NoiseGeneratorOctaves field_909_n
 * - private NoiseGeneratorOctaves field_908_o
 * - public NoiseGeneratorOctaves field_922_a
 * - public NoiseGeneratorOctaves field_921_b
 * - public NoiseGeneratorOctaves mobSpawnerNoise
 * - private World worldObj
 * - private double field_4180_q[]
 * - private double sandNoise[]
 * - private double gravelNoise[]
 * - private double stoneNoise[]
 * - private MapGenBase field_902_u
 * - private BiomeGenBase biomesForGeneration[]
 * - private double generatedTemperatures[]
 *
 * Java method/constructor inventory:
 * - public ChunkProviderGenerate(World world, long l)
 * - public void generateTerrain(int i, int j, byte abyte0[], BiomeGenBase abiomegenbase[], double ad[])
 * - public void replaceBlocksForBiome(int i, int j, byte abyte0[], BiomeGenBase abiomegenbase[])
 * - public Chunk prepareChunk(int i, int j)
 * - public Chunk provideChunk(int i, int j)
 * - private double[] func_4061_a(double ad[], int i, int j, int k, int l, int i1, int j1)
 * - public boolean chunkExists(int i, int j)
 * - public void populate(IChunkProvider ichunkprovider, int i, int j)
 * - public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
 * - public boolean unload100OldestChunks()
 * - public boolean canSave()
 * - public String makeString()
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <math.h>
#include <string.h>

void CloneMCJ_ChunkProviderGenerate_Register(void)
{
    /* Priority 4: behavior is implemented by CloneMCJ_ChunkProviderGenerate_* APIs. */
}

const char *CloneMCJ_ChunkProviderGenerate_JavaName(void)
{
    return "net.minecraft.src.ChunkProviderGenerate";
}

const char *CloneMCJ_ChunkProviderGenerate_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkProviderGenerate_JavaSourceHash32(void)
{
    return 0x19057331UL;
}

static CloneMCJLong CloneMCJ_CPG_SeedA(void)
{
    return ((CloneMCJLong)0x4F9939F5L << 8) | (CloneMCJLong)0x08L;
}

static CloneMCJLong CloneMCJ_CPG_SeedB(void)
{
    return ((CloneMCJLong)0x1EF1565BL << 8) | (CloneMCJLong)0xD5L;
}

static void CloneMCJ_CPG_ClearDouble(double *values, int count)
{
    int i;
    for (i = 0; i < count; ++i) { values[i] = 0.0; }
}

int CloneMCJ_ChunkProviderGenerate_Initialize(CloneMCJ_ChunkProviderGenerate *provider, CloneMCJLong worldSeed, CloneMCJ_WorldChunkManager *manager)
{
    CloneMCJavaRandom random;
    if (!provider || !manager) { return 0; }
    memset(provider, 0, sizeof(*provider));
    provider->worldSeed = worldSeed;
    provider->worldChunkManager = manager;
    CloneMCJavaRandom_SetSeed(&random, worldSeed);
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_912_k, &random, 16)) { return 0; }
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_911_l, &random, 16)) { CloneMCNoiseOctaves_Destroy(&provider->field_912_k); return 0; }
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_910_m, &random, 8)) { CloneMCNoiseOctaves_Destroy(&provider->field_912_k); CloneMCNoiseOctaves_Destroy(&provider->field_911_l); return 0; }
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_909_n, &random, 4)) { CloneMCJ_ChunkProviderGenerate_Destroy(provider); return 0; }
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_908_o, &random, 4)) { CloneMCJ_ChunkProviderGenerate_Destroy(provider); return 0; }
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_922_a, &random, 10)) { CloneMCJ_ChunkProviderGenerate_Destroy(provider); return 0; }
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_921_b, &random, 16)) { CloneMCJ_ChunkProviderGenerate_Destroy(provider); return 0; }
    if (!CloneMCNoiseOctaves_Initialize(&provider->mobSpawnerNoise, &random, 8)) { CloneMCJ_ChunkProviderGenerate_Destroy(provider); return 0; }
    CloneMCJavaRandom_SetSeed(&provider->rand, worldSeed);
    provider->initialized = 1;
    return 1;
}

void CloneMCJ_ChunkProviderGenerate_Destroy(CloneMCJ_ChunkProviderGenerate *provider)
{
    if (!provider || !provider->initialized) { return; }
    CloneMCNoiseOctaves_Destroy(&provider->field_912_k);
    CloneMCNoiseOctaves_Destroy(&provider->field_911_l);
    CloneMCNoiseOctaves_Destroy(&provider->field_910_m);
    CloneMCNoiseOctaves_Destroy(&provider->field_909_n);
    CloneMCNoiseOctaves_Destroy(&provider->field_908_o);
    CloneMCNoiseOctaves_Destroy(&provider->field_922_a);
    CloneMCNoiseOctaves_Destroy(&provider->field_921_b);
    CloneMCNoiseOctaves_Destroy(&provider->mobSpawnerNoise);
    provider->initialized = 0;
}

double *CloneMCJ_ChunkProviderGenerate_InitializeNoiseField(CloneMCJ_ChunkProviderGenerate *provider, int startX, int startY, int startZ, int xSize, int ySize, int zSize)
{
    double d;
    double d1;
    double *temps;
    double *humidity;
    int index;
    int climateIndex;
    int x;
    int z;
    int y;
    int climateStep;
    double temp;
    double humid;
    double climate;
    double heightNoise;
    double weirdNoise;
    double densityYOffset;
    double densityHeight;
    double vertical;
    double n1;
    double n2;
    double selector;
    double density;
    d = 684.41200000000003;
    d1 = 684.41200000000003;
    temps = provider->worldChunkManager->temperature;
    humidity = provider->worldChunkManager->humidity;
    CloneMCNoiseOctaves_Generate(&provider->field_922_a, provider->field_4182_g, (unsigned long)(xSize * zSize), (double)startX, 10.0, (double)startZ, xSize, 1, zSize, 1.121, 1.0, 1.121);
    CloneMCNoiseOctaves_Generate(&provider->field_921_b, provider->field_4181_h, (unsigned long)(xSize * zSize), (double)startX, 10.0, (double)startZ, xSize, 1, zSize, 200.0, 1.0, 200.0);
    CloneMCNoiseOctaves_Generate(&provider->field_910_m, provider->field_4185_d, (unsigned long)(xSize * ySize * zSize), (double)startX, (double)startY, (double)startZ, xSize, ySize, zSize, d / 80.0, d1 / 160.0, d / 80.0);
    CloneMCNoiseOctaves_Generate(&provider->field_912_k, provider->field_4184_e, (unsigned long)(xSize * ySize * zSize), (double)startX, (double)startY, (double)startZ, xSize, ySize, zSize, d, d1, d);
    CloneMCNoiseOctaves_Generate(&provider->field_911_l, provider->field_4183_f, (unsigned long)(xSize * ySize * zSize), (double)startX, (double)startY, (double)startZ, xSize, ySize, zSize, d, d1, d);
    index = 0;
    climateIndex = 0;
    climateStep = 16 / xSize;
    for (x = 0; x < xSize; ++x) {
        int climateX;
        climateX = x * climateStep + climateStep / 2;
        for (z = 0; z < zSize; ++z) {
            int climateZ;
            climateZ = z * climateStep + climateStep / 2;
            temp = temps[climateX * 16 + climateZ];
            humid = humidity[climateX * 16 + climateZ] * temp;
            climate = 1.0 - humid;
            climate *= climate;
            climate *= climate;
            climate = 1.0 - climate;
            heightNoise = (provider->field_4182_g[climateIndex] + 256.0) / 512.0;
            heightNoise *= climate;
            if (heightNoise > 1.0) { heightNoise = 1.0; }
            weirdNoise = provider->field_4181_h[climateIndex] / 8000.0;
            if (weirdNoise < 0.0) { weirdNoise = -weirdNoise * 0.29999999999999999; }
            weirdNoise = weirdNoise * 3.0 - 2.0;
            if (weirdNoise < 0.0) {
                weirdNoise /= 2.0;
                if (weirdNoise < -1.0) { weirdNoise = -1.0; }
                weirdNoise /= 1.3999999999999999;
                weirdNoise /= 2.0;
                heightNoise = 0.0;
            } else {
                if (weirdNoise > 1.0) { weirdNoise = 1.0; }
                weirdNoise /= 8.0;
            }
            if (heightNoise < 0.0) { heightNoise = 0.0; }
            heightNoise += 0.5;
            densityYOffset = (weirdNoise * (double)ySize) / 16.0;
            densityHeight = (double)ySize / 2.0 + densityYOffset * 4.0;
            ++climateIndex;
            for (y = 0; y < ySize; ++y) {
                vertical = (((double)y - densityHeight) * 12.0) / heightNoise;
                if (vertical < 0.0) { vertical *= 4.0; }
                n1 = provider->field_4184_e[index] / 512.0;
                n2 = provider->field_4183_f[index] / 512.0;
                selector = (provider->field_4185_d[index] / 10.0 + 1.0) / 2.0;
                if (selector < 0.0) { density = n1; }
                else if (selector > 1.0) { density = n2; }
                else { density = n1 + (n2 - n1) * selector; }
                density -= vertical;
                if (y > ySize - 4) {
                    double topFade;
                    topFade = (double)(y - (ySize - 4)) / 3.0;
                    density = density * (1.0 - topFade) + -10.0 * topFade;
                }
                provider->field_4180_q[index] = density;
                ++index;
            }
        }
    }
    return provider->field_4180_q;
}

void CloneMCJ_ChunkProviderGenerate_GenerateTerrain(CloneMCJ_ChunkProviderGenerate *provider, int chunkX, int chunkZ, CloneMCJ_Chunk *chunk)
{
    int cellX;
    int cellZ;
    int cellY;
    int stepY;
    int stepX;
    int stepZ;
    int k;
    int l;
    int xCells;
    int zCells;
    int yCells;
    double *density;
    (void)k; (void)l;
    xCells = 4;
    zCells = 4;
    yCells = 17;
    density = CloneMCJ_ChunkProviderGenerate_InitializeNoiseField(provider, chunkX * xCells, 0, chunkZ * zCells, xCells + 1, yCells, zCells + 1);
    for (cellX = 0; cellX < xCells; ++cellX) {
        for (cellZ = 0; cellZ < zCells; ++cellZ) {
            for (cellY = 0; cellY < 16; ++cellY) {
                double d1;
                double d2;
                double d3;
                double d4;
                double yd1;
                double yd2;
                double yd3;
                double yd4;
                d1 = density[((cellX + 0) * (zCells + 1) + (cellZ + 0)) * yCells + cellY];
                d2 = density[((cellX + 0) * (zCells + 1) + (cellZ + 1)) * yCells + cellY];
                d3 = density[((cellX + 1) * (zCells + 1) + (cellZ + 0)) * yCells + cellY];
                d4 = density[((cellX + 1) * (zCells + 1) + (cellZ + 1)) * yCells + cellY];
                yd1 = (density[((cellX + 0) * (zCells + 1) + (cellZ + 0)) * yCells + (cellY + 1)] - d1) * 0.125;
                yd2 = (density[((cellX + 0) * (zCells + 1) + (cellZ + 1)) * yCells + (cellY + 1)] - d2) * 0.125;
                yd3 = (density[((cellX + 1) * (zCells + 1) + (cellZ + 0)) * yCells + (cellY + 1)] - d3) * 0.125;
                yd4 = (density[((cellX + 1) * (zCells + 1) + (cellZ + 1)) * yCells + (cellY + 1)] - d4) * 0.125;
                for (stepY = 0; stepY < 8; ++stepY) {
                    double x0;
                    double x1;
                    double xd0;
                    double xd1;
                    x0 = d1;
                    x1 = d2;
                    xd0 = (d3 - d1) * 0.25;
                    xd1 = (d4 - d2) * 0.25;
                    for (stepX = 0; stepX < 4; ++stepX) {
                        double zDensity;
                        double zd;
                        int localX;
                        int y;
                        localX = cellX * 4 + stepX;
                        zDensity = x0;
                        zd = (x1 - x0) * 0.25;
                        for (stepZ = 0; stepZ < 4; ++stepZ) {
                            int localZ;
                            int blockID;
                            double temp;
                            localZ = cellZ * 4 + stepZ;
                            y = cellY * 8 + stepY;
                            temp = provider->worldChunkManager->temperature[localX * 16 + localZ];
                            blockID = CLONEMC_J_BLOCK_AIR;
                            if (y < 64) {
                                if (temp < 0.5 && y >= 63) { blockID = CLONEMC_J_BLOCK_ICE; }
                                else { blockID = CLONEMC_J_BLOCK_WATER_STILL; }
                            }
                            if (zDensity > 0.0) { blockID = CLONEMC_J_BLOCK_STONE; }
                            chunk->blocks[CloneMCJ_Chunk_BlockIndex(localX, y, localZ)] = (unsigned char)blockID;
                            zDensity += zd;
                        }
                        x0 += xd0;
                        x1 += xd1;
                    }
                    d1 += yd1;
                    d2 += yd2;
                    d3 += yd3;
                    d4 += yd4;
                }
            }
        }
    }
}

void CloneMCJ_ChunkProviderGenerate_ReplaceBlocksForBiome(CloneMCJ_ChunkProviderGenerate *provider, int chunkX, int chunkZ, CloneMCJ_Chunk *chunk)
{
    int x;
    int z;
    int y;
    double scale;
    scale = 0.03125;
    CloneMCNoiseOctaves_Generate(&provider->field_909_n, provider->sandNoise, 256UL, (double)(chunkX * 16), (double)(chunkZ * 16), 0.0, 16, 16, 1, scale, scale, 1.0);
    CloneMCNoiseOctaves_Generate(&provider->field_909_n, provider->gravelNoise, 256UL, (double)(chunkX * 16), 109.0134, (double)(chunkZ * 16), 16, 1, 16, scale, 1.0, scale);
    CloneMCNoiseOctaves_Generate(&provider->field_908_o, provider->stoneNoise, 256UL, (double)(chunkX * 16), (double)(chunkZ * 16), 0.0, 16, 16, 1, scale * 2.0, scale * 2.0, scale * 2.0);
    /* ChunkProviderGenerate.replaceBlocksForBiome iterates local X first,
     * then local Z.  This preserves Java Random consumption and shoreline
     * placement for identical seeds. */
    for (x = 0; x < 16; ++x) {
        for (z = 0; z < 16; ++z) {
            const CloneMCJ_BiomeGenBase *biome;
            int idx;
            int top;
            int filler;
            int layer;
            int thickness;
            int sand;
            int gravel;
            /* The Java surface pass addresses abiome[x + z * 16], even
             * though the density-temperature arrays use x * 16 + z. */
            idx = x + z * 16;
            biome = provider->biomesForGeneration[idx];
            if (!biome) { biome = CloneMCJ_BiomeGenBase_GetByID(CLONEMC_J_BIOME_PLAINS); }
            sand = provider->sandNoise[idx] + CloneMCJavaRandom_NextDouble(&provider->rand) * 0.2 > 0.0;
            gravel = provider->gravelNoise[idx] + CloneMCJavaRandom_NextDouble(&provider->rand) * 0.2 > 3.0;
            thickness = (int)(provider->stoneNoise[idx] / 3.0 + 3.0 + CloneMCJavaRandom_NextDouble(&provider->rand) * 0.25);
            layer = -1;
            top = biome->topBlock;
            filler = biome->fillerBlock;
            for (y = 127; y >= 0; --y) {
                int block;
                if (y <= CloneMCJavaRandom_NextIntBound(&provider->rand, 5)) {
                    chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)CLONEMC_J_BLOCK_BEDROCK;
                    continue;
                }
                block = CloneMCJ_Chunk_GetBlockID(chunk, x, y, z);
                if (block == CLONEMC_J_BLOCK_AIR) { layer = -1; continue; }
                if (block != CLONEMC_J_BLOCK_STONE) { continue; }
                if (layer == -1) {
                    if (thickness <= 0) { top = CLONEMC_J_BLOCK_AIR; filler = CLONEMC_J_BLOCK_STONE; }
                    else if (y >= 60 && y <= 65) {
                        top = biome->topBlock;
                        filler = biome->fillerBlock;
                        if (gravel) { top = CLONEMC_J_BLOCK_AIR; filler = CLONEMC_J_BLOCK_GRAVEL; }
                        if (sand) { top = CLONEMC_J_BLOCK_SAND; filler = CLONEMC_J_BLOCK_SAND; }
                    }
                    if (y < 64 && top == CLONEMC_J_BLOCK_AIR) { top = CLONEMC_J_BLOCK_WATER_STILL; }
                    layer = thickness;
                    if (y >= 63) { chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)top; }
                    else { chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)filler; }
                } else if (layer > 0) {
                    --layer;
                    chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)filler;
                    if (layer == 0 && filler == CLONEMC_J_BLOCK_SAND) {
                        layer = CloneMCJavaRandom_NextIntBound(&provider->rand, 4);
                        filler = CLONEMC_J_BLOCK_SANDSTONE;
                    }
                }
            }
        }
    }
}


static int CloneMCJ_CPG_TreeCount(CloneMCJ_ChunkProviderGenerate *provider, CloneMCJavaRandom *random,
    const CloneMCJ_BiomeGenBase *biome, int baseX, int baseZ)
{
    int noiseCount;
    int count;
    noiseCount=(int)((CloneMCNoiseOctaves_Generate2D(&provider->mobSpawnerNoise,(double)baseX*0.5,(double)baseZ*0.5)/8.0+
        CloneMCJavaRandom_NextDouble(random)*4.0+4.0)/3.0);
    count=0;
    if(CloneMCJavaRandom_NextIntBound(random,10)==0) ++count;
    if(!biome) return count;
    if(biome->biomeID==CLONEMC_J_BIOME_FOREST||biome->biomeID==CLONEMC_J_BIOME_RAINFOREST) count+=noiseCount+5;
    if(biome->biomeID==CLONEMC_J_BIOME_SEASONAL_FOREST) count+=noiseCount+2;
    if(biome->biomeID==CLONEMC_J_BIOME_TAIGA) count+=noiseCount+5;
    if(biome->biomeID==CLONEMC_J_BIOME_DESERT||biome->biomeID==CLONEMC_J_BIOME_TUNDRA||biome->biomeID==CLONEMC_J_BIOME_PLAINS) count-=20;
    return count;
}

void CloneMCJ_ChunkProviderGenerate_PopulateJavaOrder(CloneMCJ_ChunkProviderGenerate *provider,
    CloneMCJ_World *world, int chunkX, int chunkZ, int skyMode)
{
    CloneMCJavaRandom *random;
    CloneMCJLong oddX,oddZ;
    int baseX,baseZ,i,x,y,z,count;
    const CloneMCJ_BiomeGenBase *biome;
    double *temps;
    if(!provider||!world) return;
    random=&provider->rand;baseX=chunkX*16;baseZ=chunkZ*16;
    biome=CloneMCJ_WorldChunkManager_GetBiomeGenAt(provider->worldChunkManager,baseX+16,baseZ+16);
    CloneMCJavaRandom_SetSeed(random,provider->worldSeed);
    oddX=(CloneMCJavaRandom_NextLong(random)/(CloneMCJLong)2)*(CloneMCJLong)2+(CloneMCJLong)1;
    oddZ=(CloneMCJavaRandom_NextLong(random)/(CloneMCJLong)2)*(CloneMCJLong)2+(CloneMCJLong)1;
    CloneMCJavaRandom_SetSeed(random,((CloneMCJLong)chunkX*oddX+(CloneMCJLong)chunkZ*oddZ)^provider->worldSeed);

    if(CloneMCJavaRandom_NextIntBound(random,4)==0){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenLakes_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_WATER_STILL);}
    if(CloneMCJavaRandom_NextIntBound(random,8)==0){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,CloneMCJavaRandom_NextIntBound(random,120)+8);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;if(y<64||CloneMCJavaRandom_NextIntBound(random,10)==0)CloneMCJ_WorldGenLakes_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_LAVA_STILL);}
    for(i=0;i<8;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenDungeons_Generate(world,random,x,y,z);}
    for(i=0;i<10;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenClay_Generate(world,random,x,y,z,32);}
    for(i=0;i<20;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_DIRT,32);}
    for(i=0;i<10;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_GRAVEL,32);}
    for(i=0;i<20;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_ORE_COAL,16);}
    for(i=0;i<20;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,64);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_ORE_IRON,8);}
    for(i=0;i<2;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,32);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_ORE_GOLD,8);}
    for(i=0;i<8;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,16);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_ORE_REDSTONE,7);}
    x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,16);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_ORE_DIAMOND,7);
    x=baseX+CloneMCJavaRandom_NextIntBound(random,16);y=CloneMCJavaRandom_NextIntBound(random,16)+CloneMCJavaRandom_NextIntBound(random,16);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16);CloneMCJ_WorldGenMinable_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_ORE_LAPIS,6);

    count=CloneMCJ_CPG_TreeCount(provider,random,biome,baseX,baseZ);
    for(i=0;i<count;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJ_World_FindTopSolidBlock(world,x,z);CloneMCJ_WorldGenerator_SetScale(1.0,1.0,1.0);CloneMCJ_BiomeGenBase_GenerateTree(biome,world,random,x,y,z);}

    count=skyMode?2:0;if(!skyMode&&biome){if(biome->biomeID==CLONEMC_J_BIOME_FOREST)count=2;if(biome->biomeID==CLONEMC_J_BIOME_SEASONAL_FOREST)count=4;if(biome->biomeID==CLONEMC_J_BIOME_TAIGA)count=2;if(biome->biomeID==CLONEMC_J_BIOME_PLAINS)count=3;}
    for(i=0;i<count;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenFlowers_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_PLANT_YELLOW);}
    count=0;if(biome){if(biome->biomeID==CLONEMC_J_BIOME_FOREST)count=2;if(biome->biomeID==CLONEMC_J_BIOME_RAINFOREST)count=10;if(biome->biomeID==CLONEMC_J_BIOME_SEASONAL_FOREST)count=2;if(biome->biomeID==CLONEMC_J_BIOME_TAIGA)count=1;if(biome->biomeID==CLONEMC_J_BIOME_PLAINS)count=10;}
    for(i=0;i<count;++i){int meta=1;if(biome&&biome->biomeID==CLONEMC_J_BIOME_RAINFOREST&&CloneMCJavaRandom_NextIntBound(random,3)!=0)meta=2;x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenTallGrass_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_TALL_GRASS,meta);}
    count=(biome&&biome->biomeID==CLONEMC_J_BIOME_DESERT)?2:0;
    for(i=0;i<count;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenDeadBush_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_DEAD_BUSH);}
    if(CloneMCJavaRandom_NextIntBound(random,2)==0){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenFlowers_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_PLANT_RED);}
    if(CloneMCJavaRandom_NextIntBound(random,4)==0){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenFlowers_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_MUSHROOM_BROWN);}
    if(CloneMCJavaRandom_NextIntBound(random,8)==0){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenFlowers_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_MUSHROOM_RED);}
    for(i=0;i<10;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenReed_Generate(world,random,x,y,z);}
    if(CloneMCJavaRandom_NextIntBound(random,32)==0){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenPumpkin_Generate(world,random,x,y,z);}
    count=(biome&&biome->biomeID==CLONEMC_J_BIOME_DESERT)?10:0;
    for(i=0;i<count;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,128);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenCactus_Generate(world,random,x,y,z);}
    for(i=0;i<50;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,CloneMCJavaRandom_NextIntBound(random,120)+8);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenLiquids_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_WATER_MOVING);}
    for(i=0;i<20;++i){x=baseX+CloneMCJavaRandom_NextIntBound(random,16)+8;y=CloneMCJavaRandom_NextIntBound(random,CloneMCJavaRandom_NextIntBound(random,CloneMCJavaRandom_NextIntBound(random,112)+8)+8);z=baseZ+CloneMCJavaRandom_NextIntBound(random,16)+8;CloneMCJ_WorldGenLiquids_Generate(world,random,x,y,z,CLONEMC_J_BLOCK_LAVA_MOVING);}

    temps=CloneMCJ_WorldChunkManager_GetTemperatures(provider->worldChunkManager,provider->generatedTemperatures,baseX+8,baseZ+8,16,16);
    for(x=baseX+8;x<baseX+24;++x)for(z=baseZ+8;z<baseZ+24;++z){int ix=x-(baseX+8),iz=z-(baseZ+8),top=CloneMCJ_World_FindTopSolidBlock(world,x,z);double t=temps[ix*16+iz]-((double)(top-64)/64.0)*0.3;int below=CloneMCJ_World_GetBlockId(world,x,top-1,z);if(t<0.5&&top>0&&top<128&&CloneMCJ_World_IsAirBlock(world,x,top,z)&&CloneMCJ_World_IsSolidBlockID(below)&&below!=CLONEMC_J_BLOCK_ICE)CloneMCJ_World_SetBlock(world,x,top,z,CLONEMC_J_BLOCK_SNOW);}
}

int CloneMCJ_ChunkProviderGenerate_GenerateChunk(CloneMCJ_ChunkProviderGenerate *provider, CloneMCJ_Chunk *chunk, int chunkX, int chunkZ)
{
    if (!provider || !provider->initialized || !chunk) { return 0; }
    CloneMCJ_Chunk_Initialize(chunk, chunkX, chunkZ);
    chunk->state = CLONEMC_J_CHUNK_STATE_GENERATING_BASE;
    CloneMCJavaRandom_SetSeed(&provider->rand, (CloneMCJLong)chunkX * CloneMCJ_CPG_SeedA() + (CloneMCJLong)chunkZ * CloneMCJ_CPG_SeedB());
    CloneMCJ_WorldChunkManager_LoadBlockGeneratorData(provider->worldChunkManager, provider->biomesForGeneration, chunkX * 16, chunkZ * 16, 16, 16);
    CloneMCJ_ChunkProviderGenerate_GenerateTerrain(provider, chunkX, chunkZ, chunk);
    CloneMCJ_ChunkProviderGenerate_ReplaceBlocksForBiome(provider, chunkX, chunkZ, chunk);
    CloneMCJ_MapGenBase_GenerateCaves(provider->worldSeed, chunkX, chunkZ, chunk);
    CloneMCJ_Chunk_GenerateHeightMap(chunk, 0, 0);
    chunk->isTerrainPopulated = 0;
    chunk->state = CLONEMC_J_CHUNK_STATE_WAITING_FOR_NEIGHBORS;
    chunk->isModified = 0;
    return 1;
}

void CloneMCJ_ChunkProviderGenerate_PopulateWorldChunk(CloneMCJ_ChunkProviderGenerate *provider, CloneMCJ_World *world, int chunkX, int chunkZ)
{
    CloneMCJ_Chunk *chunk;
    if(!provider||!world) return;
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,chunkX,chunkZ) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,chunkX+1,chunkZ) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,chunkX,chunkZ+1) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider,chunkX+1,chunkZ+1)) return;
    chunk=CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider,chunkX,chunkZ);
    if(!chunk||chunk->neverSave||chunk->isTerrainPopulated) return;
    chunk->state=CLONEMC_J_CHUNK_STATE_POPULATING;
    chunk->isTerrainPopulated=1;
    CloneMCJ_ChunkProviderGenerate_PopulateJavaOrder(provider,world,chunkX,chunkZ,0);
    CloneMCJ_Chunk_GenerateHeightMap(chunk,0,0);
    chunk->lightDirty=1;chunk->meshDirty=1;chunk->isModified=1;
    chunk->state=CLONEMC_J_CHUNK_STATE_READY;
}

const char *CloneMCJ_ChunkProviderGenerate_MakeString(const CloneMCJ_ChunkProviderGenerate *provider)
{
    (void)provider;
    return "RandomLevelSource";
}

static CloneMCJUInt CloneMCJ_CPG_ChunkHash(const CloneMCJ_Chunk *chunk)
{
    CloneMCJUInt h;
    unsigned long i;
    h = (CloneMCJUInt)2166136261UL;
    for (i = 0; i < CLONEMC_J_CHUNK_BLOCK_COUNT; ++i)
        h = (CloneMCJUInt)((h ^ (CloneMCJUInt)chunk->blocks[i]) *
            (CloneMCJUInt)16777619UL);
    return h;
}

static void CloneMCJ_CPG_TestMessage(char *message, unsigned int capacity, const char *text)
{
    if (!message || capacity == 0U) { return; }
    strncpy(message, text ? text : "", (size_t)capacity - 1U);
    message[capacity - 1U] = '\0';
}

int CloneMCJ_ChunkProviderGenerate_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJ_WorldChunkManager manager;
    CloneMCJ_ChunkProviderGenerate provider;
    CloneMCJ_Chunk a;
    CloneMCJ_Chunk b;
    CloneMCJUInt ha;
    CloneMCJUInt hb;
    int hasStone;
    int x;
    int z;
    int y;
    if (!CloneMCJ_WorldChunkManager_Initialize(&manager, (CloneMCJLong)12345L)) { CloneMCJ_CPG_TestMessage(message, messageCapacity, "WCM init failed"); return 0; }
    if (!CloneMCJ_ChunkProviderGenerate_Initialize(&provider, (CloneMCJLong)12345L, &manager)) { CloneMCJ_WorldChunkManager_Destroy(&manager); CloneMCJ_CPG_TestMessage(message, messageCapacity, "CPG init failed"); return 0; }
    CloneMCJ_ChunkProviderGenerate_GenerateChunk(&provider, &a, 0, 0);
    CloneMCJ_ChunkProviderGenerate_GenerateChunk(&provider, &b, 0, 0);
    ha = CloneMCJ_CPG_ChunkHash(&a);
    hb = CloneMCJ_CPG_ChunkHash(&b);
    hasStone = 0;
    for (x = 0; x < 16; ++x) for (z = 0; z < 16; ++z) for (y = 1; y < 128; ++y) {
        int id;
        id = CloneMCJ_Chunk_GetBlockID(&a, x, y, z);
        if (id == CLONEMC_J_BLOCK_STONE || id == CLONEMC_J_BLOCK_GRASS || id == CLONEMC_J_BLOCK_DIRT) { hasStone = 1; }
    }
    CloneMCJ_ChunkProviderGenerate_Destroy(&provider);
    CloneMCJ_WorldChunkManager_Destroy(&manager);
    /* Seed 12345, chunk 0/0 locks the Java x-then-z surface replacement
     * order and its biome array addressing. */
    if (ha != hb || ha != (CloneMCJUInt)0x61A2F702UL || !hasStone) {
        CloneMCJ_CPG_TestMessage(message, messageCapacity,
            "V126 Java terrain/biome surface hash or material test failed");return 0;}
    CloneMCJ_CPG_TestMessage(message, messageCapacity,
        "V126 Java terrain density, biome surface order, and chunk hash passed");
    return 1;
}
