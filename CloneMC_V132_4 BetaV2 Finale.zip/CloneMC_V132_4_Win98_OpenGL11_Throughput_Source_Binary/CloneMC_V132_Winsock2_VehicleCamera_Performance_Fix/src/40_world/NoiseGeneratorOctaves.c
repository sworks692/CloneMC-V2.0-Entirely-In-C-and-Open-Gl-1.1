/*
 * CloneMC direct Java-compatible port: NoiseGeneratorOctaves
 *
 * Java source: NoiseGeneratorOctaves.java
 * Java type: class NoiseGeneratorOctaves
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: NoiseGenerator
 * Implements: (none declared)
 * Source SHA-256: 4944ab21b8e7831e4b834c3d41182b7dac91a68ae94ce0a07dac264ba6926d83
 * Java lines: 73
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: NoiseGenerator, NoiseGeneratorPerlin, d, d1, d2, i, j, k, l
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private NoiseGeneratorPerlin generatorCollection[]
 * - private int field_1191_b
 *
 * Java method/constructor inventory:
 * - public NoiseGeneratorOctaves(Random random, int i)
 * - public double func_806_a(double d, double d1)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <stdlib.h>

void CloneMCJ_NoiseGeneratorOctaves_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_NoiseGeneratorOctaves_JavaName(void)
{
    return "net.minecraft.src.NoiseGeneratorOctaves";
}

const char *CloneMCJ_NoiseGeneratorOctaves_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_NoiseGeneratorOctaves_JavaSourceHash32(void)
{
    return 0x4944AB21UL;
}

int CloneMCNoiseOctaves_Initialize(CloneMCNoiseOctaves *noise,
                                   CloneMCJavaRandom *random, int octaveCount)
{
    int index;
    if (!noise || !random || octaveCount <= 0) { return 0; }
    noise->generators = (CloneMCNoisePerlin *)malloc((size_t)octaveCount * sizeof(CloneMCNoisePerlin));
    if (!noise->generators) { noise->octaveCount = 0; return 0; }
    noise->octaveCount = octaveCount;
    for (index = 0; index < octaveCount; ++index) {
        CloneMCNoisePerlin_Initialize(&noise->generators[index], random);
    }
    return 1;
}

void CloneMCNoiseOctaves_Destroy(CloneMCNoiseOctaves *noise)
{
    if (!noise) { return; }
    if (noise->generators) { free(noise->generators); }
    noise->generators = 0;
    noise->octaveCount = 0;
}

double CloneMCNoiseOctaves_Generate2D(const CloneMCNoiseOctaves *noise, double x, double z)
{
    double result;
    double scale;
    int index;
    if (!noise || !noise->generators) { return 0.0; }
    result = 0.0;
    scale = 1.0;
    for (index = 0; index < noise->octaveCount; ++index) {
        result += CloneMCNoisePerlin_Generate2D(&noise->generators[index], x * scale, z * scale) / scale;
        scale /= 2.0;
    }
    return result;
}

int CloneMCNoiseOctaves_Generate(const CloneMCNoiseOctaves *noise, double *values,
                                 unsigned long valueCount, double x, double y, double z,
                                 int xSize, int ySize, int zSize,
                                 double xScale, double yScale, double zScale)
{
    unsigned long required;
    unsigned long index;
    double octaveScale;
    int octave;
    if (!noise || !noise->generators || !values || xSize <= 0 || ySize <= 0 || zSize <= 0) { return 0; }
    required = (unsigned long)xSize * (unsigned long)ySize * (unsigned long)zSize;
    if (valueCount < required) { return 0; }
    for (index = 0UL; index < valueCount; ++index) { values[index] = 0.0; }
    octaveScale = 1.0;
    for (octave = 0; octave < noise->octaveCount; ++octave) {
        CloneMCNoisePerlin_Add(&noise->generators[octave], values, x, y, z,
            xSize, ySize, zSize, xScale * octaveScale, yScale * octaveScale,
            zScale * octaveScale, octaveScale);
        octaveScale /= 2.0;
    }
    return 1;
}
