/*
 * CloneMC direct Java-compatible port: BiomeGenForest
 *
 * Java source: BiomeGenForest.java
 * Java type: class BiomeGenForest
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: BiomeGenBase
 * Implements: (none declared)
 * Source SHA-256: 0a9641916ebb511f585b9c952d7904ba54573429be3a9903fb76569985ade82c
 * Java lines: 37
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: BiomeGenBase, SpawnListEntry, EntityWolf, WorldGenForest, WorldGenBigTree, WorldGenTrees, WorldGenerator
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public BiomeGenForest()
 * - public WorldGenerator getRandomWorldGenForTrees(Random random)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_BiomeGenForest_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_BiomeGenForest_JavaName(void)
{
    return "net.minecraft.src.BiomeGenForest";
}

const char *CloneMCJ_BiomeGenForest_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_BiomeGenForest_JavaSourceHash32(void)
{
    return 0x0A964191UL;
}

int CloneMCJ_BiomeGenForest_GenerateTree(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z)
{
    if (!world || !random) { return 0; }
    if (CloneMCJavaRandom_NextIntBound(random, 5) == 0) {
        return CloneMCJ_WorldGenForest_Generate(world, random, x, y, z);
    }
    if (CloneMCJavaRandom_NextIntBound(random, 3) == 0) {
        return CloneMCJ_WorldGenBigTree_Generate(world, random, x, y, z);
    }
    return CloneMCJ_WorldGenTrees_Generate(world, random, x, y, z);
}

