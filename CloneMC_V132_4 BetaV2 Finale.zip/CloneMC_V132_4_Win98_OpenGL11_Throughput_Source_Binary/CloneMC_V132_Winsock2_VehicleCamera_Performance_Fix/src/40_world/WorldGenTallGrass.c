/*
 * CloneMC direct Java-compatible port: WorldGenTallGrass
 *
 * Java source: WorldGenTallGrass.java
 * Java type: class WorldGenTallGrass
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: c1a7f96f3edd3993a90236af9650585a09e73faf79f51dbcd3b85b9415acafcc
 * Java lines: 42
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, BlockLeaves, BlockFlower, j, k1, j1, l1, field_28060_a
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int field_28060_a
 * - private int field_28059_b
 *
 * Java method/constructor inventory:
 * - public WorldGenTallGrass(int i, int j)
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldGenTallGrass_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenTallGrass_JavaName(void)
{
    return "net.minecraft.src.WorldGenTallGrass";
}

const char *CloneMCJ_WorldGenTallGrass_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenTallGrass_JavaSourceHash32(void)
{
    return 0xC1A7F96FUL;
}

int CloneMCJ_WorldGenTallGrass_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z, int blockID, int metadata)
{
    int i,id;
    if(!world||!random) return 0;
    while(y>0){ id=CloneMCJ_World_GetBlockId(world,x,y,z); if(id!=CLONEMC_J_BLOCK_AIR&&id!=CLONEMC_J_BLOCK_LEAVES) break; --y; }
    for(i=0;i<128;++i){
        int px=(x+CloneMCJavaRandom_NextIntBound(random,8))-CloneMCJavaRandom_NextIntBound(random,8);
        int py=(y+CloneMCJavaRandom_NextIntBound(random,4))-CloneMCJavaRandom_NextIntBound(random,4);
        int pz=(z+CloneMCJavaRandom_NextIntBound(random,8))-CloneMCJavaRandom_NextIntBound(random,8);
        if(CloneMCJ_World_CanPlantStay(world,px,py,pz,blockID)) CloneMCJ_World_SetBlockWithMetadata(world,px,py,pz,blockID,metadata);
    }
    return 1;
}
