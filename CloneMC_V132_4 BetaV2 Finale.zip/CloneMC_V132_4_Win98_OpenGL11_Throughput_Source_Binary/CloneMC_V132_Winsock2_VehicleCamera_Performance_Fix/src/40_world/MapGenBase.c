/*
 * CloneMC direct Java-compatible port: MapGenBase
 *
 * Java source: MapGenBase.java
 * Java type: class MapGenBase
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 455a591587afe5f2f46d060a7b2d01a80d3e4ed6051bfe10036433986bb4f90f
 * Java lines: 46
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 3
 * Referenced Java classes: World, IChunkProvider, i1, j1, i, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - protected int field_1306_a
 * - protected Random rand
 *
 * Java method/constructor inventory:
 * - public MapGenBase()
 * - public void func_867_a(IChunkProvider ichunkprovider, World world, int i, int j, byte abyte0[])
 * - protected void func_868_a(World world, int i, int j, int k, int l, byte abyte0[])
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_MapGenBase_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MapGenBase_JavaName(void)
{
    return "net.minecraft.src.MapGenBase";
}

const char *CloneMCJ_MapGenBase_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_MapGenBase_JavaSourceHash32(void)
{
    return 0x455A5915UL;
}


void CloneMCJ_MapGenBase_GenerateCaves(CloneMCJLong worldSeed, int targetChunkX, int targetChunkZ, CloneMCJ_Chunk *chunk)
{
    CloneMCJavaRandom random;
    CloneMCJLong oddX,oddZ;
    int sourceX,sourceZ;
    if(!chunk)return;
    CloneMCJavaRandom_SetSeed(&random,worldSeed);
    oddX=(CloneMCJavaRandom_NextLong(&random)/(CloneMCJLong)2)*(CloneMCJLong)2+(CloneMCJLong)1;
    oddZ=(CloneMCJavaRandom_NextLong(&random)/(CloneMCJLong)2)*(CloneMCJLong)2+(CloneMCJLong)1;
    for(sourceX=targetChunkX-8;sourceX<=targetChunkX+8;++sourceX){
        for(sourceZ=targetChunkZ-8;sourceZ<=targetChunkZ+8;++sourceZ){
            CloneMCJULong sourceSeed;
            sourceSeed=(CloneMCJULong)(CloneMCJLong)sourceX*(CloneMCJULong)oddX+
                (CloneMCJULong)(CloneMCJLong)sourceZ*(CloneMCJULong)oddZ;
            CloneMCJavaRandom_SetSeed(&random,(CloneMCJLong)(sourceSeed^
                (CloneMCJULong)worldSeed));
            CloneMCJ_MapGenCaves_CarveFromSource(&random,sourceX,sourceZ,targetChunkX,targetChunkZ,chunk);
        }
    }
}
