/*
 * CloneMC Java port scaffold: NextTickListEntry
 *
 * Java source: NextTickListEntry.java
 * Java type: class NextTickListEntry
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: Comparable
 * Source SHA-256: 915e8288fe499d79d1fb8e4b181c665a3aa954128d9d349aaf44ed87f8c2bf09
 * Java lines: 75
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 6
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static long nextTickEntryID = 0L
 * - public int xCoord
 * - public int yCoord
 * - public int zCoord
 * - public int blockID
 * - public long scheduledTime
 * - private long tickEntryID
 *
 * Java method/constructor inventory:
 * - public NextTickListEntry(int i, int j, int k, int l)
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - public NextTickListEntry setScheduledTime(long l)
 * - public int comparer(NextTickListEntry nextticklistentry)
 * - public int compareTo(Object obj)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_NextTickListEntry_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_NextTickListEntry_JavaName(void)
{
    return "net.minecraft.src.NextTickListEntry";
}

const char *CloneMCJ_NextTickListEntry_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_NextTickListEntry_JavaSourceHash32(void)
{
    return 0x915E8288UL;
}

/* Priority 3 direct implementation from NextTickListEntry.java. */
static CloneMCJLong g_cloneMCJNextTickEntryID = (CloneMCJLong)0;

void CloneMCJ_NextTickListEntry_Initialize(CloneMCJ_NextTickListEntry *entry, int x, int y, int z, int blockID)
{
    if (!entry) { return; }
    entry->xCoord = x;
    entry->yCoord = y;
    entry->zCoord = z;
    entry->blockID = blockID;
    entry->scheduledTime = (CloneMCJLong)0;
    entry->tickEntryID = g_cloneMCJNextTickEntryID;
    g_cloneMCJNextTickEntryID = g_cloneMCJNextTickEntryID + (CloneMCJLong)1;
}

CloneMCJ_NextTickListEntry *CloneMCJ_NextTickListEntry_SetScheduledTime(CloneMCJ_NextTickListEntry *entry, CloneMCJLong time)
{
    if (entry) { entry->scheduledTime = time; }
    return entry;
}

int CloneMCJ_NextTickListEntry_Equals(const CloneMCJ_NextTickListEntry *left, const CloneMCJ_NextTickListEntry *right)
{
    if (!left || !right) { return 0; }
    return left->xCoord == right->xCoord && left->yCoord == right->yCoord && left->zCoord == right->zCoord && left->blockID == right->blockID;
}

CloneMCJInt CloneMCJ_NextTickListEntry_HashCode(const CloneMCJ_NextTickListEntry *entry)
{
    CloneMCJInt h;
    if (!entry) { return 0; }
    h = CloneMCJava_MulInt((CloneMCJInt)entry->xCoord, (CloneMCJInt)(128 * 1024));
    h = CloneMCJava_AddInt(h, CloneMCJava_MulInt((CloneMCJInt)entry->zCoord, (CloneMCJInt)128));
    h = CloneMCJava_AddInt(h, (CloneMCJInt)entry->yCoord);
    h = CloneMCJava_MulInt(h, (CloneMCJInt)256);
    h = CloneMCJava_AddInt(h, (CloneMCJInt)entry->blockID);
    return h;
}

int CloneMCJ_NextTickListEntry_Compare(const CloneMCJ_NextTickListEntry *left, const CloneMCJ_NextTickListEntry *right)
{
    if (!left || !right) { return 0; }
    if (left->scheduledTime < right->scheduledTime) { return -1; }
    if (left->scheduledTime > right->scheduledTime) { return 1; }
    if (left->tickEntryID < right->tickEntryID) { return -1; }
    if (left->tickEntryID > right->tickEntryID) { return 1; }
    return 0;
}

void CloneMCJ_NextTickListEntry_ResetIDsForTest(void)
{
    g_cloneMCJNextTickEntryID = (CloneMCJLong)0;
}
