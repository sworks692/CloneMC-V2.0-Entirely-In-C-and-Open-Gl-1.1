/*
 * CloneMC direct Java-compatible port: WorldGenTaiga1
 *
 * Java source: WorldGenTaiga1.java
 * Java type: class WorldGenTaiga1
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 90e4f932aa0177da9c9f236494c0e09fa7e7e0cab8cddc6e1b4f44e57f066cad
 * Java lines: 112
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, BlockLeaves, BlockGrass, l1, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldGenTaiga1()
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <stdlib.h>

void CloneMCJ_WorldGenTaiga1_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenTaiga1_JavaName(void)
{
    return "net.minecraft.src.WorldGenTaiga1";
}

const char *CloneMCJ_WorldGenTaiga1_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenTaiga1_JavaSourceHash32(void)
{
    return 0x90E4F932UL;
}

int CloneMCJ_WorldGenTaiga1_Generate(CloneMCJ_World *world,CloneMCJavaRandom *random,int x,int y,int z)
{
    int h,trunkTop,leafHeight,maxR,yy,xx,zz,r,ground;
    if(!world||!random)return 0;
    h=CloneMCJavaRandom_NextIntBound(random,5)+7; trunkTop=h-CloneMCJavaRandom_NextIntBound(random,2)-3; leafHeight=h-trunkTop; maxR=1+CloneMCJavaRandom_NextIntBound(random,leafHeight+1);
    if(y<1||y+h+1>128)return 0;
    for(yy=y;yy<=y+1+h;++yy){r=(yy-y<trunkTop)?0:maxR;for(xx=x-r;xx<=x+r;++xx)for(zz=z-r;zz<=z+r;++zz)if(!CloneMCJ_World_IsReplaceableForTree(CloneMCJ_World_GetBlockId(world,xx,yy,zz)))return 0;}
    ground=CloneMCJ_World_GetBlockId(world,x,y-1,z);if(ground!=CLONEMC_J_BLOCK_GRASS&&ground!=CLONEMC_J_BLOCK_DIRT)return 0;CloneMCJ_World_SetBlock(world,x,y-1,z,CLONEMC_J_BLOCK_DIRT);
    r=0;for(yy=y+h;yy>=y+trunkTop;--yy){for(xx=x-r;xx<=x+r;++xx)for(zz=z-r;zz<=z+r;++zz)if((abs(xx-x)!=r||abs(zz-z)!=r||r<=0)&&!CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,xx,yy,zz)))CloneMCJ_World_SetBlockWithMetadata(world,xx,yy,zz,CLONEMC_J_BLOCK_LEAVES,1);if(r>=1&&yy==y+trunkTop+1)--r;else if(r<maxR)++r;}
    for(yy=0;yy<h-1;++yy){int id=CloneMCJ_World_GetBlockId(world,x,y+yy,z);if(id==0||id==CLONEMC_J_BLOCK_LEAVES)CloneMCJ_World_SetBlockWithMetadata(world,x,y+yy,z,CLONEMC_J_BLOCK_LOG,1);}return 1;
}
