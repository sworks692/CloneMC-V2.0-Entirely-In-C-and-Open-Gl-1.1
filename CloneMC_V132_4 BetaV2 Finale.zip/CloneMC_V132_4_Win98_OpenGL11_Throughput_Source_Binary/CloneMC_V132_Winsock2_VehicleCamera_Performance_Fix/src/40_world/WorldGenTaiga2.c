/*
 * CloneMC direct Java-compatible port: WorldGenTaiga2
 *
 * Java source: WorldGenTaiga2.java
 * Java type: class WorldGenTaiga2
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 31080b79eef266a73116141a98a11f7f756c9b041cf16d763470f3d61bc91f0d
 * Java lines: 119
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, BlockLeaves, BlockGrass, l1, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldGenTaiga2()
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <stdlib.h>

void CloneMCJ_WorldGenTaiga2_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenTaiga2_JavaName(void)
{
    return "net.minecraft.src.WorldGenTaiga2";
}

const char *CloneMCJ_WorldGenTaiga2_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenTaiga2_JavaSourceHash32(void)
{
    return 0x31080B79UL;
}

int CloneMCJ_WorldGenTaiga2_Generate(CloneMCJ_World *world,CloneMCJavaRandom *random,int x,int y,int z)
{
    int h,bare,leafHeight,maxR,yy,xx,zz,r,nextR,toggle,ground,cut;
    if(!world||!random)return 0;
    h=CloneMCJavaRandom_NextIntBound(random,4)+6;bare=1+CloneMCJavaRandom_NextIntBound(random,2);leafHeight=h-bare;maxR=2+CloneMCJavaRandom_NextIntBound(random,2);
    if(y<1||y+h+1>128)return 0;
    for(yy=y;yy<=y+1+h;++yy){r=(yy-y<bare)?0:maxR;for(xx=x-r;xx<=x+r;++xx)for(zz=z-r;zz<=z+r;++zz)if(!CloneMCJ_World_IsReplaceableForTree(CloneMCJ_World_GetBlockId(world,xx,yy,zz)))return 0;}
    ground=CloneMCJ_World_GetBlockId(world,x,y-1,z);if(ground!=CLONEMC_J_BLOCK_GRASS&&ground!=CLONEMC_J_BLOCK_DIRT)return 0;CloneMCJ_World_SetBlock(world,x,y-1,z,CLONEMC_J_BLOCK_DIRT);
    r=CloneMCJavaRandom_NextIntBound(random,2);nextR=1;toggle=0;
    for(yy=0;yy<=leafHeight;++yy){int py=y+h-yy;for(xx=x-r;xx<=x+r;++xx)for(zz=z-r;zz<=z+r;++zz)if((abs(xx-x)!=r||abs(zz-z)!=r||r<=0)&&!CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,xx,py,zz)))CloneMCJ_World_SetBlockWithMetadata(world,xx,py,zz,CLONEMC_J_BLOCK_LEAVES,1);if(r>=nextR){r=toggle?1:0;toggle=1;if(++nextR>maxR)nextR=maxR;}else ++r;}
    cut=CloneMCJavaRandom_NextIntBound(random,3);for(yy=0;yy<h-cut;++yy){int id=CloneMCJ_World_GetBlockId(world,x,y+yy,z);if(id==0||id==CLONEMC_J_BLOCK_LEAVES)CloneMCJ_World_SetBlockWithMetadata(world,x,y+yy,z,CLONEMC_J_BLOCK_LOG,1);}return 1;
}
