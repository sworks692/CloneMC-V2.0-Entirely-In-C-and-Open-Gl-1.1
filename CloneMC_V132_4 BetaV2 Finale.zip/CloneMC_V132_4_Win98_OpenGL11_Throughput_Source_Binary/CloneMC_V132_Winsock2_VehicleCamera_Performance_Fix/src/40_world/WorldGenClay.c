/*
 * CloneMC direct Java-compatible port: WorldGenClay
 *
 * Java source: WorldGenClay.java
 * Java type: class WorldGenClay
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: bb7dcd4fd93488e63b3eb325b17665d72b71b01d9b65d161e5b5983971f248b7
 * Java lines: 81
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, Block, World, Material, MathHelper, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int clayBlockId
 * - private int numberOfBlocks
 *
 * Java method/constructor inventory:
 * - public WorldGenClay(int i)
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldGenClay_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenClay_JavaName(void)
{
    return "net.minecraft.src.WorldGenClay";
}

const char *CloneMCJ_WorldGenClay_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenClay_JavaSourceHash32(void)
{
    return 0xBB7DCD4FUL;
}

int CloneMCJ_WorldGenClay_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z, int numberOfBlocks)
{
    float angle;
    double x0, x1, z0, z1, y0, y1;
    int step;
    if (!world || !random || !CloneMCJ_World_IsWaterBlock(CloneMCJ_World_GetBlockId(world, x, y, z))) { return 0; }
    angle = CloneMCJavaRandom_NextFloat(random) * 3.141593F;
    x0 = (double)(x + 8) + (double)(CloneMCMathHelper_Sin(angle) * (float)numberOfBlocks) / 8.0;
    x1 = (double)(x + 8) - (double)(CloneMCMathHelper_Sin(angle) * (float)numberOfBlocks) / 8.0;
    z0 = (double)(z + 8) + (double)(CloneMCMathHelper_Cos(angle) * (float)numberOfBlocks) / 8.0;
    z1 = (double)(z + 8) - (double)(CloneMCMathHelper_Cos(angle) * (float)numberOfBlocks) / 8.0;
    y0 = (double)y + (double)CloneMCJavaRandom_NextIntBound(random, 3) + 2.0;
    y1 = (double)y + (double)CloneMCJavaRandom_NextIntBound(random, 3) + 2.0;
    for (step = 0; step <= numberOfBlocks; ++step) {
        double cx, cy, cz, n, rx, ry;
        int minX,maxX,minY,maxY,minZ,maxZ,bx,by,bz;
        cx=x0+(x1-x0)*(double)step/(double)numberOfBlocks;
        cy=y0+(y1-y0)*(double)step/(double)numberOfBlocks;
        cz=z0+(z1-z0)*(double)step/(double)numberOfBlocks;
        n=CloneMCJavaRandom_NextDouble(random)*(double)numberOfBlocks/16.0;
        rx=((double)CloneMCMathHelper_Sin((float)step*3.141593F/(float)numberOfBlocks)+1.0)*n+1.0;
        ry=rx;
        minX=CloneMCJava_FloorDouble(cx-rx/2.0); maxX=CloneMCJava_FloorDouble(cx+rx/2.0);
        minY=CloneMCJava_FloorDouble(cy-ry/2.0); maxY=CloneMCJava_FloorDouble(cy+ry/2.0);
        minZ=CloneMCJava_FloorDouble(cz-rx/2.0); maxZ=CloneMCJava_FloorDouble(cz+rx/2.0);
        for(bx=minX;bx<=maxX;++bx) for(by=minY;by<=maxY;++by) for(bz=minZ;bz<=maxZ;++bz){
            double dx,dy,dz;
            dx=((double)bx+0.5-cx)/(rx/2.0); dy=((double)by+0.5-cy)/(ry/2.0); dz=((double)bz+0.5-cz)/(rx/2.0);
            if(dx*dx+dy*dy+dz*dz<1.0 && CloneMCJ_World_GetBlockId(world,bx,by,bz)==CLONEMC_J_BLOCK_SAND)
                CloneMCJ_World_SetBlock(world,bx,by,bz,CLONEMC_J_BLOCK_CLAY);
        }
    }
    return 1;
}
