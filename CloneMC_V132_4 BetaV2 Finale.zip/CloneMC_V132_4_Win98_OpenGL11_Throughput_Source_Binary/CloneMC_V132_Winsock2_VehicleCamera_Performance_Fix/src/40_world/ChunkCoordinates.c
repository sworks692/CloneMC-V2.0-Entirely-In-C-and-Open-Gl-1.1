/*
 * CloneMC Java port scaffold: ChunkCoordinates
 *
 * Java source: ChunkCoordinates.java
 * Java type: class ChunkCoordinates
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: Comparable
 * Source SHA-256: d9c37a7a42af38389c9a10648b4389a1a1b8339d8d3c2074cb1a850164a60c1f
 * Java lines: 81
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - public int x
 * - public int y
 * - public int z
 *
 * Java method/constructor inventory:
 * - public ChunkCoordinates()
 * - public ChunkCoordinates(int i, int j, int k)
 * - public ChunkCoordinates(ChunkCoordinates chunkcoordinates)
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - public int compareChunkCoordinate(ChunkCoordinates chunkcoordinates)
 * - public double getSqDistanceTo(int i, int j, int k)
 * - public int compareTo(Object obj)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_ChunkCoordinates_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkCoordinates_JavaName(void)
{
    return "net.minecraft.src.ChunkCoordinates";
}

const char *CloneMCJ_ChunkCoordinates_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkCoordinates_JavaSourceHash32(void)
{
    return 0xD9C37A7AUL;
}

/* Priority 3 ChunkCoordinates implementation. */
#include <math.h>

void CloneMCJ_ChunkCoordinates_Initialize(CloneMCJ_ChunkCoordinates *coords, int x, int y, int z)
{
    if (!coords) { return; }
    coords->x = x; coords->y = y; coords->z = z;
}

void CloneMCJ_ChunkCoordinates_Copy(CloneMCJ_ChunkCoordinates *dst, const CloneMCJ_ChunkCoordinates *src)
{
    if (!dst) { return; }
    if (!src) { CloneMCJ_ChunkCoordinates_Initialize(dst, 0, 0, 0); return; }
    *dst = *src;
}

int CloneMCJ_ChunkCoordinates_Equals(const CloneMCJ_ChunkCoordinates *a, const CloneMCJ_ChunkCoordinates *b)
{
    return a && b && a->x == b->x && a->y == b->y && a->z == b->z;
}

CloneMCJInt CloneMCJ_ChunkCoordinates_HashCode(const CloneMCJ_ChunkCoordinates *coords)
{
    if (!coords) { return 0; }
    return (CloneMCJInt)(coords->x + (coords->z << 8) + (coords->y << 16));
}

int CloneMCJ_ChunkCoordinates_Compare(const CloneMCJ_ChunkCoordinates *a, const CloneMCJ_ChunkCoordinates *b)
{
    if (!a && !b) { return 0; }
    if (!a) { return -1; }
    if (!b) { return 1; }
    if (a->y != b->y) { return a->y - b->y; }
    if (a->z != b->z) { return a->z - b->z; }
    return a->x - b->x;
}

double CloneMCJ_ChunkCoordinates_GetSqDistanceTo(const CloneMCJ_ChunkCoordinates *coords, int x, int y, int z)
{
    double dx, dy, dz;
    if (!coords) { return 0.0; }
    dx = (double)(coords->x - x);
    dy = (double)(coords->y - y);
    dz = (double)(coords->z - z);
    return dx * dx + dy * dy + dz * dz;
}
