/*
 * CloneMC Java port scaffold: WorldProviderSurface
 *
 * Java source: WorldProviderSurface.java
 * Java type: class WorldProviderSurface
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldProvider
 * Implements: (none declared)
 * Source SHA-256: 7328b98f8a0914a3d0ab01f1b175db8e1fd9960ec6361461e7e8db9f53504bcd
 * Java lines: 18
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: WorldProvider
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldProviderSurface()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldProviderSurface_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldProviderSurface_JavaName(void)
{
    return "net.minecraft.src.WorldProviderSurface";
}

const char *CloneMCJ_WorldProviderSurface_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldProviderSurface_JavaSourceHash32(void)
{
    return 0x7328B98FUL;
}
