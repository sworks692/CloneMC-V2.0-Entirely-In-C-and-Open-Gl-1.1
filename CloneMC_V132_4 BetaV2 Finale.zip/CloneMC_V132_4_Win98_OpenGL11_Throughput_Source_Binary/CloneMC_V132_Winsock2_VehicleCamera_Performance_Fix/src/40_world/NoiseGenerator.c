/*
 * CloneMC direct Java-compatible port: NoiseGenerator
 *
 * Java source: NoiseGenerator.java
 * Java type: class NoiseGenerator
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: eac123869e2ac0d6dd90407562e9d5a34be45a0040d32e969d02009711b0db12
 * Java lines: 15
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public NoiseGenerator()
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <math.h>
#include <string.h>

void CloneMCJ_NoiseGenerator_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_NoiseGenerator_JavaName(void)
{
    return "net.minecraft.src.NoiseGenerator";
}

const char *CloneMCJ_NoiseGenerator_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_NoiseGenerator_JavaSourceHash32(void)
{
    return 0xEAC12386UL;
}

static void CloneMCNoise_TestMessage(char *message, unsigned int capacity, const char *text)
{
    if (!message || capacity == 0U) { return; }
    strncpy(message, text ? text : "", (size_t)capacity - 1U);
    message[capacity - 1U] = '\0';
}

int CloneMCNoise_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJavaRandom random;
    CloneMCNoisePerlin perlin;
    CloneMCNoiseSimplex simplex;
    CloneMCNoiseOctaves octaves;
    double values[4];
    double sampleA;
    double sampleB;
    int index;

    CloneMCJavaRandom_SetSeed(&random, (CloneMCJLong)12345);
    CloneMCNoisePerlin_Initialize(&perlin, &random);
    sampleA = CloneMCNoisePerlin_Generate(&perlin, 1.25, 2.5, -3.75);
    sampleB = CloneMCNoisePerlin_Generate(&perlin, -1000.125, 64.5, 2048.75);
    if (perlin.permutations[0] != 83 || perlin.permutations[255] != 14 ||
        fabs(sampleA - (-0.36563796152787570)) > 1.0E-12 ||
        fabs(sampleB - (-0.34593192149872232)) > 1.0E-12) {
        CloneMCNoise_TestMessage(message, messageCapacity,
            "Perlin permutation/value compatibility test failed");
        return 0;
    }

    CloneMCJavaRandom_SetSeed(&random, (CloneMCJLong)-987654321);
    CloneMCNoiseSimplex_Initialize(&simplex, &random);
    for (index = 0; index < 4; ++index) { values[index] = 0.0; }
    CloneMCNoiseSimplex_Add(&simplex, values, -32.0, 17.0, 2, 2, 0.25, 0.5, 0.55);
    if (simplex.permutations[0] != 11 || simplex.permutations[255] != 80 ||
        fabs(values[0] - 0.11136188375199495) > 1.0E-12 ||
        fabs(values[3] - (-0.025923520208952274)) > 1.0E-12) {
        CloneMCNoise_TestMessage(message, messageCapacity,
            "Simplex negative-coordinate compatibility test failed");
        return 0;
    }

    octaves.generators = 0;
    octaves.octaveCount = 0;
    CloneMCJavaRandom_SetSeed(&random, (CloneMCJLong)8675309);
    if (!CloneMCNoiseOctaves_Initialize(&octaves, &random, 4)) {
        CloneMCNoise_TestMessage(message, messageCapacity, "Octave allocation test failed");
        return 0;
    }
    for (index = 0; index < 4; ++index) { values[index] = 99.0; }
    if (!CloneMCNoiseOctaves_Generate(&octaves, values, 4UL, -2.0, 5.0, 7.0,
                                      2, 1, 2, 0.125, 1.0, 0.25)) {
        CloneMCNoiseOctaves_Destroy(&octaves);
        CloneMCNoise_TestMessage(message, messageCapacity, "Octave buffer contract test failed");
        return 0;
    }
    CloneMCNoiseOctaves_Destroy(&octaves);
    if (values[0] == 99.0 || values[1] == 99.0 || values[2] == 99.0 || values[3] == 99.0) {
        CloneMCNoise_TestMessage(message, messageCapacity, "Octave output initialization test failed");
        return 0;
    }
    CloneMCNoise_TestMessage(message, messageCapacity,
        "Priority 2 Java terrain-noise compatibility: PASS");
    return 1;
}
