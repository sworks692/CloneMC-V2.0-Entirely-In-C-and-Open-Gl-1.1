/*
 * CloneMC Java port scaffold: ChunkProviderSky
 *
 * Java source: ChunkProviderSky.java
 * Java type: class ChunkProviderSky
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IChunkProvider
 * Source SHA-256: 4e61921947fdb13a240f4a7b2a28c8d5a591a10468667eb9cdbe302f28c3383e
 * Java lines: 586
 * Discovered declared fields: 17
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: IChunkProvider, MapGenCaves, NoiseGeneratorOctaves, Block, BiomeGenBase, Chunk, World, WorldChunkManager, MapGenBase, BlockSand, WorldGenLakes, WorldGenDungeons, WorldGenClay, WorldGenMinable, WorldGenerator, WorldGenFlowers, BlockFlower, WorldGenReed, WorldGenPumpkin, WorldGenCactus, WorldGenLiquids, Material, IProgressUpdate, k, byte1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private Random field_28087_j
 * - private NoiseGeneratorOctaves field_28086_k
 * - private NoiseGeneratorOctaves field_28085_l
 * - private NoiseGeneratorOctaves field_28084_m
 * - private NoiseGeneratorOctaves field_28083_n
 * - private NoiseGeneratorOctaves field_28082_o
 * - public NoiseGeneratorOctaves field_28096_a
 * - public NoiseGeneratorOctaves field_28095_b
 * - public NoiseGeneratorOctaves field_28094_c
 * - private World field_28081_p
 * - private double field_28080_q[]
 * - private double field_28079_r[]
 * - private double field_28078_s[]
 * - private double field_28077_t[]
 * - private MapGenBase field_28076_u
 * - private BiomeGenBase field_28075_v[]
 * - private double field_28074_w[]
 *
 * Java method/constructor inventory:
 * - public ChunkProviderSky(World world, long l)
 * - public void func_28071_a(int i, int j, byte abyte0[], BiomeGenBase abiomegenbase[], double ad[])
 * - public void func_28072_a(int i, int j, byte abyte0[], BiomeGenBase abiomegenbase[])
 * - public Chunk prepareChunk(int i, int j)
 * - public Chunk provideChunk(int i, int j)
 * - private double[] func_28073_a(double ad[], int i, int j, int k, int l, int i1, int j1)
 * - public boolean chunkExists(int i, int j)
 * - public void populate(IChunkProvider ichunkprovider, int i, int j)
 * - public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
 * - public boolean unload100OldestChunks()
 * - public boolean canSave()
 * - public String makeString()
 *
 * Priority 11 directly implements the uploaded dimension-one density lattice,
 * 8x4x8 interpolation, surface replacement, caves and Java-order population.
 */
#include "clonemc_java_port_40_world.h"
#include <string.h>

static CloneMCJLong CloneMCJ_CPS_SeedA(void)
{
    return ((CloneMCJLong)0x4F9939F5L << 8) | (CloneMCJLong)0x08L;
}

static CloneMCJLong CloneMCJ_CPS_SeedB(void)
{
    return ((CloneMCJLong)0x1EF1565BL << 8) | (CloneMCJLong)0xD5L;
}

int CloneMCJ_ChunkProviderSky_Initialize(CloneMCJ_ChunkProviderSky *provider,
    CloneMCJLong worldSeed)
{
    CloneMCJavaRandom random;
    if (!provider) return 0;
    memset(provider, 0, sizeof(*provider));
    provider->worldSeed = worldSeed;
    CloneMCJavaRandom_SetSeed(&random, worldSeed);
    if (!CloneMCNoiseOctaves_Initialize(&provider->field_28086_k, &random, 16) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_28085_l, &random, 16) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_28084_m, &random, 8) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_28083_n, &random, 4) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_28082_o, &random, 4) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_28096_a, &random, 10) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_28095_b, &random, 16) ||
        !CloneMCNoiseOctaves_Initialize(&provider->field_28094_c, &random, 8)) {
        CloneMCJ_ChunkProviderSky_Destroy(provider);
        return 0;
    }
    provider->skyRNG = random;
    provider->initialized = 1;
    return 1;
}

void CloneMCJ_ChunkProviderSky_Destroy(CloneMCJ_ChunkProviderSky *provider)
{
    if (!provider) return;
    CloneMCNoiseOctaves_Destroy(&provider->field_28086_k);
    CloneMCNoiseOctaves_Destroy(&provider->field_28085_l);
    CloneMCNoiseOctaves_Destroy(&provider->field_28084_m);
    CloneMCNoiseOctaves_Destroy(&provider->field_28083_n);
    CloneMCNoiseOctaves_Destroy(&provider->field_28082_o);
    CloneMCNoiseOctaves_Destroy(&provider->field_28096_a);
    CloneMCNoiseOctaves_Destroy(&provider->field_28095_b);
    CloneMCNoiseOctaves_Destroy(&provider->field_28094_c);
    provider->initialized = 0;
}

static void CloneMCJ_CPS_InitializeDensity(CloneMCJ_ChunkProviderSky *provider,
    int startX, int startZ)
{
    double d;
    double d1;
    int x;
    int z;
    int y;
    int index;
    int column;
    d = 684.41200000000003;
    d1 = 684.41200000000003;
    CloneMCNoiseOctaves_Generate(&provider->field_28096_a, provider->scale, 9UL,
        (double)startX, 10.0, (double)startZ, 3, 1, 3, 1.121, 1.0, 1.121);
    CloneMCNoiseOctaves_Generate(&provider->field_28095_b, provider->depth, 9UL,
        (double)startX, 10.0, (double)startZ, 3, 1, 3, 200.0, 1.0, 200.0);
    d *= 2.0;
    CloneMCNoiseOctaves_Generate(&provider->field_28084_m, provider->blend, 297UL,
        (double)startX, 0.0, (double)startZ, 3, 33, 3,
        d / 80.0, d1 / 160.0, d / 80.0);
    CloneMCNoiseOctaves_Generate(&provider->field_28086_k, provider->lower, 297UL,
        (double)startX, 0.0, (double)startZ, 3, 33, 3, d, d1, d);
    CloneMCNoiseOctaves_Generate(&provider->field_28085_l, provider->upper, 297UL,
        (double)startX, 0.0, (double)startZ, 3, 33, 3, d, d1, d);
    index = 0;
    column = 0;
    for (x = 0; x < 3; ++x) for (z = 0; z < 3; ++z) {
        double climate;
        double scale;
        double depth;
        climate = 0.0;
        scale = (provider->scale[column] + 256.0) / 512.0;
        scale *= 1.0 - climate;
        if (scale > 1.0) scale = 1.0;
        if (scale < 0.0) scale = 0.0;
        scale += 0.5;
        depth = provider->depth[column] / 8000.0;
        if (depth < 0.0) depth = -depth * 0.3;
        depth = depth * 3.0 - 2.0;
        if (depth > 1.0) depth = 1.0;
        depth /= 8.0;
        depth = 0.0;
        (void)scale; (void)depth;
        ++column;
        for (y = 0; y < 33; ++y) {
            double lower;
            double upper;
            double selector;
            double density;
            lower = provider->lower[index] / 512.0;
            upper = provider->upper[index] / 512.0;
            selector = (provider->blend[index] / 10.0 + 1.0) / 2.0;
            if (selector < 0.0) density = lower;
            else if (selector > 1.0) density = upper;
            else density = lower + (upper - lower) * selector;
            density -= 8.0;
            if (y > 1) {
                double fade;
                fade = (double)(y - 1) / 31.0;
                if (fade < 0.0) fade = 0.0;
                if (fade > 1.0) fade = 1.0;
                density = density * (1.0 - fade) - 30.0 * fade;
            }
            if (y < 8) {
                double fade;
                fade = (double)(8 - y) / 7.0;
                if (fade < 0.0) fade = 0.0;
                if (fade > 1.0) fade = 1.0;
                density = density * (1.0 - fade) - 30.0 * fade;
            }
            provider->density[index++] = density;
        }
    }
}

static void CloneMCJ_CPS_GenerateTerrain(CloneMCJ_ChunkProviderSky *provider,
    int chunkX, int chunkZ, CloneMCJ_Chunk *chunk)
{
    int cellX;
    int cellZ;
    int cellY;
    int stepY;
    int stepX;
    int stepZ;
    CloneMCJ_CPS_InitializeDensity(provider, chunkX * 2, chunkZ * 2);
    for (cellX = 0; cellX < 2; ++cellX) for (cellZ = 0; cellZ < 2; ++cellZ)
        for (cellY = 0; cellY < 32; ++cellY) {
            double d1, d2, d3, d4, yd1, yd2, yd3, yd4;
            d1 = provider->density[((cellX + 0) * 3 + cellZ + 0) * 33 + cellY];
            d2 = provider->density[((cellX + 0) * 3 + cellZ + 1) * 33 + cellY];
            d3 = provider->density[((cellX + 1) * 3 + cellZ + 0) * 33 + cellY];
            d4 = provider->density[((cellX + 1) * 3 + cellZ + 1) * 33 + cellY];
            yd1 = (provider->density[((cellX + 0) * 3 + cellZ + 0) * 33 + cellY + 1] - d1) * 0.25;
            yd2 = (provider->density[((cellX + 0) * 3 + cellZ + 1) * 33 + cellY + 1] - d2) * 0.25;
            yd3 = (provider->density[((cellX + 1) * 3 + cellZ + 0) * 33 + cellY + 1] - d3) * 0.25;
            yd4 = (provider->density[((cellX + 1) * 3 + cellZ + 1) * 33 + cellY + 1] - d4) * 0.25;
            for (stepY = 0; stepY < 4; ++stepY) {
                double x0, x1, xd0, xd1;
                x0 = d1; x1 = d2;
                xd0 = (d3 - d1) * 0.125;
                xd1 = (d4 - d2) * 0.125;
                for (stepX = 0; stepX < 8; ++stepX) {
                    double value, zd;
                    value = x0;
                    zd = (x1 - x0) * 0.125;
                    for (stepZ = 0; stepZ < 8; ++stepZ) {
                        int xx, yy, zz;
                        xx = cellX * 8 + stepX;
                        yy = cellY * 4 + stepY;
                        zz = cellZ * 8 + stepZ;
                        chunk->blocks[CloneMCJ_Chunk_BlockIndex(xx, yy, zz)] =
                            (unsigned char)(value > 0.0 ? 1 : 0);
                        value += zd;
                    }
                    x0 += xd0; x1 += xd1;
                }
                d1 += yd1; d2 += yd2; d3 += yd3; d4 += yd4;
            }
        }
}

static void CloneMCJ_CPS_ReplaceSurface(CloneMCJ_ChunkProviderSky *provider,
    int chunkX, int chunkZ, CloneMCJ_Chunk *chunk)
{
    int x;
    int z;
    int y;
    double scale;
    scale = 0.03125;
    CloneMCNoiseOctaves_Generate(&provider->field_28083_n, provider->surfaceA, 256UL,
        chunkX * 16.0, chunkZ * 16.0, 0.0, 16, 16, 1, scale, scale, 1.0);
    CloneMCNoiseOctaves_Generate(&provider->field_28083_n, provider->surfaceB, 256UL,
        chunkX * 16.0, 109.0134, chunkZ * 16.0, 16, 1, 16, scale, 1.0, scale);
    CloneMCNoiseOctaves_Generate(&provider->field_28082_o, provider->surfaceDepth, 256UL,
        chunkX * 16.0, chunkZ * 16.0, 0.0, 16, 16, 1,
        scale * 2.0, scale * 2.0, scale * 2.0);
    for (x = 0; x < 16; ++x) for (z = 0; z < 16; ++z) {
        int thickness;
        int layer;
        int top;
        int filler;
        thickness = (int)(provider->surfaceDepth[x + z * 16] / 3.0 + 3.0 +
            CloneMCJavaRandom_NextDouble(&provider->skyRNG) * 0.25);
        layer = -1;
        top = 2;
        filler = 3;
        for (y = 127; y >= 0; --y) {
            int id;
            id = CloneMCJ_Chunk_GetBlockID(chunk, x, y, z);
            if (id == 0) { layer = -1; continue; }
            if (id != 1) continue;
            if (layer == -1) {
                if (thickness <= 0) { top = 0; filler = 1; }
                layer = thickness;
                chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)top;
            } else if (layer > 0) {
                --layer;
                chunk->blocks[CloneMCJ_Chunk_BlockIndex(x, y, z)] = (unsigned char)filler;
            }
        }
    }
}

int CloneMCJ_ChunkProviderSky_GenerateChunk(CloneMCJ_ChunkProviderSky *provider,
    CloneMCJ_Chunk *chunk, int chunkX, int chunkZ)
{
    if (!provider || !provider->initialized || !chunk) return 0;
    CloneMCJ_Chunk_Initialize(chunk, chunkX, chunkZ);
    chunk->state = CLONEMC_J_CHUNK_STATE_GENERATING_BASE;
    CloneMCJavaRandom_SetSeed(&provider->skyRNG,
        (CloneMCJLong)chunkX * CloneMCJ_CPS_SeedA() +
        (CloneMCJLong)chunkZ * CloneMCJ_CPS_SeedB());
    CloneMCJ_CPS_GenerateTerrain(provider, chunkX, chunkZ, chunk);
    CloneMCJ_CPS_ReplaceSurface(provider, chunkX, chunkZ, chunk);
    CloneMCJ_MapGenBase_GenerateCaves(provider->worldSeed, chunkX, chunkZ, chunk);
    CloneMCJ_Chunk_GenerateHeightMap(chunk, 0, 0);
    chunk->isTerrainPopulated = 0;
    chunk->state = CLONEMC_J_CHUNK_STATE_WAITING_FOR_NEIGHBORS;
    chunk->isModified = 0;
    return 1;
}

void CloneMCJ_ChunkProviderSky_PopulateWorldChunk(CloneMCJ_ChunkProviderSky *provider,
    CloneMCJ_World *world, int chunkX, int chunkZ)
{
    CloneMCJ_Chunk *chunk;
    if (!provider || !provider->initialized || !world) return;
    if (!CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX, chunkZ) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX + 1, chunkZ) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX, chunkZ + 1) ||
        !CloneMCJ_ChunkProviderLoadOrGenerate_ChunkExists(&world->chunkProvider, chunkX + 1, chunkZ + 1)) return;
    chunk = CloneMCJ_ChunkProviderLoadOrGenerate_PrepareChunk(&world->chunkProvider, chunkX, chunkZ);
    if (!chunk || chunk->neverSave || chunk->isTerrainPopulated) return;
    chunk->state = CLONEMC_J_CHUNK_STATE_POPULATING;
    chunk->isTerrainPopulated = 1;
    CloneMCJ_ChunkProviderGenerate_PopulateJavaOrder(&world->terrainProvider,
        world, chunkX, chunkZ, 1);
    CloneMCJ_Chunk_GenerateHeightMap(chunk, 0, 0);
    chunk->lightDirty = 1;
    chunk->meshDirty = 1;
    chunk->isModified = 1;
    chunk->state = CLONEMC_J_CHUNK_STATE_READY;
}

void CloneMCJ_ChunkProviderSky_Register(void)
{
    /* Runtime state is value-owned by World. */
}

const char *CloneMCJ_ChunkProviderSky_JavaName(void)
{
    return "net.minecraft.src.ChunkProviderSky";
}

const char *CloneMCJ_ChunkProviderSky_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkProviderSky_JavaSourceHash32(void)
{
    return 0x4E619219UL;
}
