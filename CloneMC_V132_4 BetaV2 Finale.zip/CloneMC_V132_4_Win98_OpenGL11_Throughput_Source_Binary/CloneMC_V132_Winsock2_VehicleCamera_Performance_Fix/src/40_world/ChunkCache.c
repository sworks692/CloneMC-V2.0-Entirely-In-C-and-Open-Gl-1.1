/*
 * CloneMC Java port scaffold: ChunkCache
 *
 * Java source: ChunkCache.java
 * Java type: class ChunkCache
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: IBlockAccess
 * Source SHA-256: 3a6540e084ecc910f1d3d02d2ad4594e015257bf408dd8e982bae7a37ba499ee
 * Java lines: 206
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 12
 * Referenced Java classes: IBlockAccess, World, Chunk, WorldProvider, Block, Material, TileEntity, WorldChunkManager, j
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int chunkX
 * - private int chunkZ
 * - private Chunk chunkArray[][]
 * - private World worldObj
 *
 * Java method/constructor inventory:
 * - public ChunkCache(World world, int i, int j, int k, int l, int i1, int j1)
 * - public int getBlockId(int i, int j, int k)
 * - public TileEntity getBlockTileEntity(int i, int j, int k)
 * - public float getBrightness(int i, int j, int k, int l)
 * - public float getLightBrightness(int i, int j, int k)
 * - public int getLightValue(int i, int j, int k)
 * - public int getLightValueExt(int i, int j, int k, boolean flag)
 * - public int getBlockMetadata(int i, int j, int k)
 * - public Material getBlockMaterial(int i, int j, int k)
 * - public WorldChunkManager getWorldChunkManager()
 * - public boolean isBlockOpaqueCube(int i, int j, int k)
 * - public boolean isBlockNormalCube(int i, int j, int k)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_ChunkCache_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_ChunkCache_JavaName(void)
{
    return "net.minecraft.src.ChunkCache";
}

const char *CloneMCJ_ChunkCache_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_ChunkCache_JavaSourceHash32(void)
{
    return 0x3A6540E0UL;
}

/* Priority 3 read-only ChunkCache.java companion. */
#include <string.h>

int CloneMCJ_ChunkCache_Initialize(CloneMCJ_ChunkCacheView *cache, CloneMCJ_World *world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
{
    int cx0;
    int cz0;
    int cx1;
    int cz1;
    int x;
    int z;
    (void)minY;
    (void)maxY;
    if (!cache || !world) { return 0; }
    memset(cache, 0, sizeof(*cache));
    cx0 = CloneMCJ_World_GlobalToChunk(minX);
    cz0 = CloneMCJ_World_GlobalToChunk(minZ);
    cx1 = CloneMCJ_World_GlobalToChunk(maxX);
    cz1 = CloneMCJ_World_GlobalToChunk(maxZ);
    cache->worldObj = world;
    cache->chunkX = cx0;
    cache->chunkZ = cz0;
    cache->xCount = cx1 - cx0 + 1;
    cache->zCount = cz1 - cz0 + 1;
    if (cache->xCount > CLONEMC_J_CHUNK_CACHE_VIEW_MAX || cache->zCount > CLONEMC_J_CHUNK_CACHE_VIEW_MAX) { return 0; }
    for (x = 0; x < cache->xCount; ++x) {
        for (z = 0; z < cache->zCount; ++z) { cache->chunkArray[x][z] = CloneMCJ_World_GetChunkFromChunkCoords(world, cx0 + x, cz0 + z); }
    }
    return 1;
}

static CloneMCJ_Chunk *CloneMCJ_ChunkCache_GetChunk(CloneMCJ_ChunkCacheView *cache, int blockX, int blockZ)
{
    int cx;
    int cz;
    int ix;
    int iz;
    if (!cache) { return 0; }
    cx = CloneMCJ_World_GlobalToChunk(blockX);
    cz = CloneMCJ_World_GlobalToChunk(blockZ);
    ix = cx - cache->chunkX;
    iz = cz - cache->chunkZ;
    if (ix < 0 || iz < 0 || ix >= cache->xCount || iz >= cache->zCount) { return 0; }
    return cache->chunkArray[ix][iz];
}

int CloneMCJ_ChunkCache_GetBlockId(CloneMCJ_ChunkCacheView *cache, int blockX, int y, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    if (!cache || y < 0 || y >= 128) { return 0; }
    chunk = CloneMCJ_ChunkCache_GetChunk(cache, blockX, blockZ);
    return CloneMCJ_Chunk_GetBlockID(chunk, CloneMCJ_World_GlobalToLocal(blockX), y, CloneMCJ_World_GlobalToLocal(blockZ));
}

int CloneMCJ_ChunkCache_GetBlockMetadata(CloneMCJ_ChunkCacheView *cache, int blockX, int y, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    if (!cache || y < 0 || y >= 128) { return 0; }
    chunk = CloneMCJ_ChunkCache_GetChunk(cache, blockX, blockZ);
    return CloneMCJ_Chunk_GetBlockMetadata(chunk, CloneMCJ_World_GlobalToLocal(blockX), y, CloneMCJ_World_GlobalToLocal(blockZ));
}

int CloneMCJ_ChunkCache_GetLightValue(CloneMCJ_ChunkCacheView *cache, int blockX, int y, int blockZ)
{
    CloneMCJ_Chunk *chunk;
    if (!cache) { return 15; }
    if (y < 0) { return 0; }
    if (y >= 128) { return 15; }
    chunk = CloneMCJ_ChunkCache_GetChunk(cache, blockX, blockZ);
    return CloneMCJ_Chunk_GetBlockLightValue(chunk, CloneMCJ_World_GlobalToLocal(blockX), y, CloneMCJ_World_GlobalToLocal(blockZ), cache->worldObj ? cache->worldObj->skylightSubtracted : 0);
}
