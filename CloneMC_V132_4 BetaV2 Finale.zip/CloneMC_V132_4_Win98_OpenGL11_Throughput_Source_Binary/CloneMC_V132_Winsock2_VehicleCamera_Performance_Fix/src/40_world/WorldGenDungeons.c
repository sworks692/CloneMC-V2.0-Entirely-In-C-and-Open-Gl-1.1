/*
 * CloneMC direct Java-compatible port: WorldGenDungeons
 *
 * Java source: WorldGenDungeons.java
 * Java type: class WorldGenDungeons
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 8eb7138cc00b179a0af6eac1ded36da8860c5163aa0102095430a97febeae2f0
 * Java lines: 224
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: WorldGenerator, World, Material, Block, TileEntityChest, TileEntityMobSpawner, ItemStack, Item, j2
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldGenDungeons()
 * - public boolean generate(World world, Random random, int i, int j, int k)
 * - private ItemStack pickCheckLootItem(Random random)
 * - private String pickMobSpawner(Random random)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include "../30_item/clonemc_java_port_30_item.h"
#include <string.h>

void CloneMCJ_WorldGenDungeons_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenDungeons_JavaName(void)
{
    return "net.minecraft.src.WorldGenDungeons";
}

const char *CloneMCJ_WorldGenDungeons_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenDungeons_JavaSourceHash32(void)
{
    return 0x8EB7138CUL;
}

static int CloneMCJ_WorldGenDungeons_Loot(CloneMCJavaRandom *random, CloneMCJ_ItemStack *stack)
{
    int choice;
    CloneMCJ_ItemStack_Clear(stack);
    choice = CloneMCJavaRandom_NextIntBound(random, 11);
    if (choice == 0) CloneMCJ_ItemStack_Initialize(stack, 329, 1, 0);
    else if (choice == 1) CloneMCJ_ItemStack_Initialize(stack, 265, CloneMCJavaRandom_NextIntBound(random, 4) + 1, 0);
    else if (choice == 2) CloneMCJ_ItemStack_Initialize(stack, 297, 1, 0);
    else if (choice == 3) CloneMCJ_ItemStack_Initialize(stack, 296, CloneMCJavaRandom_NextIntBound(random, 4) + 1, 0);
    else if (choice == 4) CloneMCJ_ItemStack_Initialize(stack, 289, CloneMCJavaRandom_NextIntBound(random, 4) + 1, 0);
    else if (choice == 5) CloneMCJ_ItemStack_Initialize(stack, 287, CloneMCJavaRandom_NextIntBound(random, 4) + 1, 0);
    else if (choice == 6) CloneMCJ_ItemStack_Initialize(stack, 325, 1, 0);
    else if (choice == 7 && CloneMCJavaRandom_NextIntBound(random, 100) == 0) CloneMCJ_ItemStack_Initialize(stack, 322, 1, 0);
    else if (choice == 8 && CloneMCJavaRandom_NextIntBound(random, 2) == 0) CloneMCJ_ItemStack_Initialize(stack, 331, CloneMCJavaRandom_NextIntBound(random, 4) + 1, 0);
    else if (choice == 9 && CloneMCJavaRandom_NextIntBound(random, 10) == 0) CloneMCJ_ItemStack_Initialize(stack, 2256 + CloneMCJavaRandom_NextIntBound(random, 2), 1, 0);
    else if (choice == 10) CloneMCJ_ItemStack_Initialize(stack, 351, 1, 3);
    return !CloneMCJ_ItemStack_IsEmpty(stack);
}

static const char *CloneMCJ_WorldGenDungeons_Mob(CloneMCJavaRandom *random)
{
    int choice;
    choice = CloneMCJavaRandom_NextIntBound(random, 4);
    if (choice == 0) return "Skeleton";
    if (choice == 3) return "Spider";
    return "Zombie";
}

static int CloneMCJ_WorldGenDungeons_AddTile(CloneMCJ_World *world, CloneMCJ_TileEntity *tile)
{
    CloneMCJ_Chunk *chunk;
    if (!world || !tile) return 0;
    chunk = CloneMCJ_World_GetChunkFromBlockCoords(world, tile->xCoord, tile->zCoord);
    return chunk && CloneMCJ_Chunk_SetTileEntity(chunk,
        CloneMCJ_World_GlobalToLocal(tile->xCoord), tile->yCoord,
        CloneMCJ_World_GlobalToLocal(tile->zCoord), tile);
}

int CloneMCJ_WorldGenDungeons_Generate(CloneMCJ_World *world,CloneMCJavaRandom *random,int x,int y,int z)
{
    int height=3,rx,rz,openings=0,xx,yy,zz,chestTry;
    if(!world||!random)return 0;
    rx=CloneMCJavaRandom_NextIntBound(random,2)+2;rz=CloneMCJavaRandom_NextIntBound(random,2)+2;
    for(xx=x-rx-1;xx<=x+rx+1;++xx)for(yy=y-1;yy<=y+height+1;++yy)for(zz=z-rz-1;zz<=z+rz+1;++zz){
        int id=CloneMCJ_World_GetBlockId(world,xx,yy,zz);
        if((yy==y-1||yy==y+height+1)&&!CloneMCJ_World_IsSolidBlockID(id))return 0;
        if((xx==x-rx-1||xx==x+rx+1||zz==z-rz-1||zz==z+rz+1)&&yy==y&&id==0&&CloneMCJ_World_IsAirBlock(world,xx,yy+1,zz))++openings;
    }
    if(openings<1||openings>5)return 0;
    for(xx=x-rx-1;xx<=x+rx+1;++xx)for(yy=y+height;yy>=y-1;--yy)for(zz=z-rz-1;zz<=z+rz+1;++zz){
        int wall=(xx==x-rx-1||xx==x+rx+1||zz==z-rz-1||zz==z+rz+1||yy==y-1||yy==y+height+1);
        if(wall){if(yy>=0&&!CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,xx,yy-1,zz)))CloneMCJ_World_SetBlock(world,xx,yy,zz,0);else if(CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,xx,yy,zz)))CloneMCJ_World_SetBlock(world,xx,yy,zz,(yy==y-1&&CloneMCJavaRandom_NextIntBound(random,4)!=0)?CLONEMC_J_BLOCK_COBBLESTONE_MOSSY:CLONEMC_J_BLOCK_COBBLESTONE);}
        else CloneMCJ_World_SetBlock(world,xx,yy,zz,0);
    }
    for(chestTry=0;chestTry<2;++chestTry){int attempt;for(attempt=0;attempt<3;++attempt){int cx=x+CloneMCJavaRandom_NextIntBound(random,rx*2+1)-rx,cz=z+CloneMCJavaRandom_NextIntBound(random,rz*2+1)-rz,solid=0;if(!CloneMCJ_World_IsAirBlock(world,cx,y,cz))continue;if(CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,cx-1,y,cz)))++solid;if(CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,cx+1,y,cz)))++solid;if(CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,cx,y,cz-1)))++solid;if(CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,cx,y,cz+1)))++solid;if(solid==1){CloneMCJ_TileEntity *chest;int lootTry;CloneMCJ_World_SetBlock(world,cx,y,cz,CLONEMC_J_BLOCK_CHEST);chest=CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_CHEST,world,cx,y,cz);if(chest&&CloneMCJ_WorldGenDungeons_AddTile(world,chest)){for(lootTry=0;lootTry<8;++lootTry){CloneMCJ_ItemStack loot;if(CloneMCJ_WorldGenDungeons_Loot(random,&loot))CloneMCJ_TileEntity_SetStack(chest,CloneMCJavaRandom_NextIntBound(random,chest->itemCount),&loot);}}else CloneMCJ_TileEntity_Destroy(chest);break;}}}
    CloneMCJ_World_SetBlock(world,x,y,z,CLONEMC_J_BLOCK_MOB_SPAWNER);
    {
        CloneMCJ_TileEntity *spawner;
        const char *mob;
        mob = CloneMCJ_WorldGenDungeons_Mob(random);
        spawner = CloneMCJ_TileEntity_Create(CLONEMC_J_TILE_MOB_SPAWNER,world,x,y,z);
        if(spawner){strncpy(spawner->mobID,mob,sizeof(spawner->mobID)-1U);spawner->mobID[sizeof(spawner->mobID)-1U]='\0';if(!CloneMCJ_WorldGenDungeons_AddTile(world,spawner))CloneMCJ_TileEntity_Destroy(spawner);}
    }
    return 1;
}
