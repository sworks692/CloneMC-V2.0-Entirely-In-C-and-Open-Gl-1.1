/*
 * CloneMC Java port scaffold: EnumCreatureType
 *
 * Java source: EnumCreatureType.java
 * Java type: enum EnumCreatureType
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: b1b1a7524aa33decfbaf4fdf2da724f5310fe3b7747f05f23cbb51d281fa9b6a
 * Java lines: 78
 * Discovered declared fields: 5
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: IMob, Material, EntityAnimal, EntityWaterMob, net.minecraft.src.IMob.class, Material.air, net.minecraft.src.EntityAnimal.class, net.minecraft.src.EntityWaterMob.class, Material.water, static, net.minecraft.src.En
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final Class creatureClass
 * - private final int maxNumberOfCreature
 * - private final Material creatureMaterial
 * - private final boolean isPeacefulCreature
 * - private static final EnumCreatureType field_6518_e[]
 *
 * Java method/constructor inventory:
 * - private EnumCreatureType(String s, int i, Class class1, int j, Material material, boolean flag)
 * - public Class getCreatureClass()
 * - public int getMaxNumberOfCreature()
 * - public Material getCreatureMaterial()
 * - public boolean getPeacefulCreature()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_EnumCreatureType_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumCreatureType_JavaName(void)
{
    return "net.minecraft.src.EnumCreatureType";
}

const char *CloneMCJ_EnumCreatureType_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_EnumCreatureType_JavaSourceHash32(void)
{
    return 0xB1B1A752UL;
}
