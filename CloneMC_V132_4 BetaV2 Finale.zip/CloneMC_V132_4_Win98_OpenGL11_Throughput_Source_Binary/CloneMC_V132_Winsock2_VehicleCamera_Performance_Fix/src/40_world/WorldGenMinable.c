/*
 * CloneMC direct Java-compatible port: WorldGenMinable
 *
 * Java source: WorldGenMinable.java
 * Java type: class WorldGenMinable
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: a59e1722a6f7c0ef35b8ef78eb1a40800754debd9f308cb888f8ebd321bf73b5
 * Java lines: 79
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, MathHelper, World, Block
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private int minableBlockId
 * - private int numberOfBlocks
 *
 * Java method/constructor inventory:
 * - public WorldGenMinable(int i, int j)
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"

void CloneMCJ_WorldGenMinable_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenMinable_JavaName(void)
{
    return "net.minecraft.src.WorldGenMinable";
}

const char *CloneMCJ_WorldGenMinable_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenMinable_JavaSourceHash32(void)
{
    return 0xA59E1722UL;
}

#include <math.h>

int CloneMCJ_WorldGenMinable_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random,
    int x, int y, int z, int blockID, int numberOfBlocks)
{
    float angle;
    double x0, x1, z0, z1, y0, y1;
    int step;
    if (!world || !random || numberOfBlocks <= 0) { return 0; }
    angle = CloneMCJavaRandom_NextFloat(random) * 3.141593F;
    x0 = (double)(x + 8) + (double)(CloneMCMathHelper_Sin(angle) * (float)numberOfBlocks) / 8.0;
    x1 = (double)(x + 8) - (double)(CloneMCMathHelper_Sin(angle) * (float)numberOfBlocks) / 8.0;
    z0 = (double)(z + 8) + (double)(CloneMCMathHelper_Cos(angle) * (float)numberOfBlocks) / 8.0;
    z1 = (double)(z + 8) - (double)(CloneMCMathHelper_Cos(angle) * (float)numberOfBlocks) / 8.0;
    y0 = (double)y + (double)CloneMCJavaRandom_NextIntBound(random, 3) + 2.0;
    y1 = (double)y + (double)CloneMCJavaRandom_NextIntBound(random, 3) + 2.0;
    for (step = 0; step <= numberOfBlocks; ++step) {
        double cx, cy, cz, sizeNoise, radiusXZ, radiusY;
        int minX, maxX, minY, maxY, minZ, maxZ, bx, by, bz;
        cx = x0 + (x1 - x0) * (double)step / (double)numberOfBlocks;
        cy = y0 + (y1 - y0) * (double)step / (double)numberOfBlocks;
        cz = z0 + (z1 - z0) * (double)step / (double)numberOfBlocks;
        sizeNoise = CloneMCJavaRandom_NextDouble(random) * (double)numberOfBlocks / 16.0;
        radiusXZ = ((double)CloneMCMathHelper_Sin((float)step * 3.141593F / (float)numberOfBlocks) + 1.0) * sizeNoise + 1.0;
        radiusY = radiusXZ;
        minX = CloneMCJava_FloorDouble(cx - radiusXZ / 2.0);
        maxX = CloneMCJava_FloorDouble(cx + radiusXZ / 2.0);
        minY = CloneMCJava_FloorDouble(cy - radiusY / 2.0);
        maxY = CloneMCJava_FloorDouble(cy + radiusY / 2.0);
        minZ = CloneMCJava_FloorDouble(cz - radiusXZ / 2.0);
        maxZ = CloneMCJava_FloorDouble(cz + radiusXZ / 2.0);
        for (bx = minX; bx <= maxX; ++bx) {
            double dx;
            dx = ((double)bx + 0.5 - cx) / (radiusXZ / 2.0);
            if (dx * dx >= 1.0) { continue; }
            for (by = minY; by <= maxY; ++by) {
                double dy;
                dy = ((double)by + 0.5 - cy) / (radiusY / 2.0);
                if (dx * dx + dy * dy >= 1.0) { continue; }
                for (bz = minZ; bz <= maxZ; ++bz) {
                    double dz;
                    dz = ((double)bz + 0.5 - cz) / (radiusXZ / 2.0);
                    if (dx * dx + dy * dy + dz * dz < 1.0 &&
                        CloneMCJ_World_GetBlockId(world, bx, by, bz) == CLONEMC_J_BLOCK_STONE) {
                        CloneMCJ_World_SetBlock(world, bx, by, bz, blockID);
                    }
                }
            }
        }
    }
    return 1;
}
