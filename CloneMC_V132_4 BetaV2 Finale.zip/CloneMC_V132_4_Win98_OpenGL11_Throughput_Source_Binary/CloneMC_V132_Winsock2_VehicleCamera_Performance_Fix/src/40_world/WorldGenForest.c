/*
 * CloneMC direct Java-compatible port: WorldGenForest
 *
 * Java source: WorldGenForest.java
 * Java type: class WorldGenForest
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: WorldGenerator
 * Implements: (none declared)
 * Source SHA-256: 9facf9d549c490cc49fb90e758a7663ab1dd3a1196c23fbf78e8a76b9fb17f46
 * Java lines: 102
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: WorldGenerator, World, Block, BlockLeaves, BlockGrass, i1, k
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public WorldGenForest()
 * - public boolean generate(World world, Random random, int i, int j, int k)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <stdlib.h>

void CloneMCJ_WorldGenForest_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_WorldGenForest_JavaName(void)
{
    return "net.minecraft.src.WorldGenForest";
}

const char *CloneMCJ_WorldGenForest_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_WorldGenForest_JavaSourceHash32(void)
{
    return 0x9FACF9D5UL;
}

int CloneMCJ_WorldGenForest_Generate(CloneMCJ_World *world, CloneMCJavaRandom *random, int x, int y, int z)
{
    int h,yy,xx,zz,ground;
    if(!world||!random) return 0;
    h=5+CloneMCJavaRandom_NextIntBound(random,3);
    if(y<1||y+h+1>128) return 0;
    for(yy=y;yy<=y+h+1;++yy){
        int r=1; if(yy==y)r=0; if(yy>=(y+1+h)-2)r=2;
        for(xx=x-r;xx<=x+r;++xx)for(zz=z-r;zz<=z+r;++zz)
            if(!CloneMCJ_World_IsReplaceableForTree(CloneMCJ_World_GetBlockId(world,xx,yy,zz))) return 0;
    }
    ground=CloneMCJ_World_GetBlockId(world,x,y-1,z);
    if(ground!=CLONEMC_J_BLOCK_GRASS&&ground!=CLONEMC_J_BLOCK_DIRT) return 0;
    CloneMCJ_World_SetBlock(world,x,y-1,z,CLONEMC_J_BLOCK_DIRT);
    for(yy=(y-3)+h;yy<=y+h;++yy){
        int rel=yy-(y+h),r=1-rel/2;
        for(xx=x-r;xx<=x+r;++xx)for(zz=z-r;zz<=z+r;++zz){
            int dx=xx-x,dz=zz-z;
            if((abs(dx)!=r||abs(dz)!=r||(CloneMCJavaRandom_NextIntBound(random,2)!=0&&rel!=0))&&
               !CloneMCJ_World_IsSolidBlockID(CloneMCJ_World_GetBlockId(world,xx,yy,zz)))
                CloneMCJ_World_SetBlockWithMetadata(world,xx,yy,zz,CLONEMC_J_BLOCK_LEAVES,2);
        }
    }
    for(yy=0;yy<h;++yy){int id=CloneMCJ_World_GetBlockId(world,x,y+yy,z);if(id==0||id==CLONEMC_J_BLOCK_LEAVES)CloneMCJ_World_SetBlockWithMetadata(world,x,y+yy,z,CLONEMC_J_BLOCK_LOG,2);}
    return 1;
}
