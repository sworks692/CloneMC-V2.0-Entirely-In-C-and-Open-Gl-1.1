/*
 * CloneMC direct Java-compatible port: NoiseGeneratorOctaves2
 *
 * Java source: NoiseGeneratorOctaves2.java
 * Java type: class NoiseGeneratorOctaves2
 * Package: net.minecraft.src
 * Assigned subsystem: src/40_world
 * Mapping reason: world, chunk, biome, terrain generation, ticking, or spawning class
 * Extends: NoiseGenerator
 * Implements: (none declared)
 * Source SHA-256: 2eb5878e7363d449fb4ab17cc880020d91a2dc537cb9324fd5ab171436ac64be
 * Java lines: 63
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: NoiseGenerator, NoiseGenerator2, d, d1, i, j, d2, d3, d4
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private NoiseGenerator2 field_4234_a[]
 * - private int field_4233_b
 *
 * Java method/constructor inventory:
 * - public NoiseGeneratorOctaves2(Random random, int i)
 *
 * Priority 4 status: the direct C behavior for this Java terrain class is
 * implemented below and is linked through the shared world unity manifest.
 * Declarations remain in the original shared world header to preserve the
 * project-wide ten-header architecture.
 */
#include "clonemc_java_port_40_world.h"
#include <stdlib.h>

void CloneMCJ_NoiseGeneratorOctaves2_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_NoiseGeneratorOctaves2_JavaName(void)
{
    return "net.minecraft.src.NoiseGeneratorOctaves2";
}

const char *CloneMCJ_NoiseGeneratorOctaves2_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_NoiseGeneratorOctaves2_JavaSourceHash32(void)
{
    return 0x2EB5878EUL;
}

int CloneMCNoiseOctaves2_Initialize(CloneMCNoiseOctaves2 *noise,
                                    CloneMCJavaRandom *random, int octaveCount)
{
    int index;
    if (!noise || !random || octaveCount <= 0) { return 0; }
    noise->generators = (CloneMCNoiseSimplex *)malloc((size_t)octaveCount * sizeof(CloneMCNoiseSimplex));
    if (!noise->generators) { noise->octaveCount = 0; return 0; }
    noise->octaveCount = octaveCount;
    for (index = 0; index < octaveCount; ++index) {
        CloneMCNoiseSimplex_Initialize(&noise->generators[index], random);
    }
    return 1;
}

void CloneMCNoiseOctaves2_Destroy(CloneMCNoiseOctaves2 *noise)
{
    if (!noise) { return; }
    if (noise->generators) { free(noise->generators); }
    noise->generators = 0;
    noise->octaveCount = 0;
}

int CloneMCNoiseOctaves2_Generate(const CloneMCNoiseOctaves2 *noise, double *values,
                                  unsigned long valueCount, double x, double z,
                                  int xSize, int zSize, double xScale, double zScale,
                                  double frequencyMultiplier, double amplitudeMultiplier)
{
    unsigned long required;
    unsigned long index;
    double amplitude;
    double frequency;
    int octave;
    if (!noise || !noise->generators || !values || xSize <= 0 || zSize <= 0) { return 0; }
    required = (unsigned long)xSize * (unsigned long)zSize;
    if (valueCount < required) { return 0; }
    for (index = 0UL; index < valueCount; ++index) { values[index] = 0.0; }
    xScale /= 1.5;
    zScale /= 1.5;
    amplitude = 1.0;
    frequency = 1.0;
    for (octave = 0; octave < noise->octaveCount; ++octave) {
        CloneMCNoiseSimplex_Add(&noise->generators[octave], values, x, z,
            xSize, zSize, xScale * frequency, zScale * frequency, 0.55 / amplitude);
        frequency *= frequencyMultiplier;
        amplitude *= amplitudeMultiplier;
    }
    return 1;
}
