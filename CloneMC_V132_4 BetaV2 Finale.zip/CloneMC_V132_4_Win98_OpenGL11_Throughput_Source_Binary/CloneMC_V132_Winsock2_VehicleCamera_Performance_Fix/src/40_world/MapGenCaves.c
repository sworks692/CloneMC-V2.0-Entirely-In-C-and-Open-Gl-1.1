/* Java source: MapGenCaves.java; Source SHA-256: 634c31ffe177ec7fb2c6ac784fdec698fad18fd6ed0c44b5bc5e234038572d5d; Java lines: 239. */
/*
 * Direct Open Watcom C89 port of Minecraft Beta MapGenCaves.java.
 * Preserves MapGenBase source-chunk seeding, recursive branching, Java RNG
 * call order, water rejection, lava floor, and grass restoration.
 */
#include "clonemc_java_port_40_world.h"
#include <math.h>

void CloneMCJ_MapGenCaves_Register(void)
{
    /* Priority 4 direct port of MapGenCaves.java. */
}

const char *CloneMCJ_MapGenCaves_JavaName(void)
{
    return "net.minecraft.src.MapGenCaves";
}

const char *CloneMCJ_MapGenCaves_AssignedFolder(void)
{
    return "src/40_world";
}

unsigned long CloneMCJ_MapGenCaves_JavaSourceHash32(void)
{
    return 0x634C31FFUL;
}

static int CloneMCJ_MapGenCaves_Index(int x, int y, int z)
{
    return (x << 11) | (z << 7) | y;
}

static int g_cloneMCMapGenCavesHellMode;

static void CloneMCJ_MapGenCaves_Tunnel(int targetChunkX, int targetChunkZ,
    unsigned char *blocks, CloneMCJavaRandom *sourceRandom,
    double x, double y, double z, float radius, float yaw, float pitch,
    int step, int maxStep, double verticalScale)
{
    double centerX;
    double centerZ;
    float yawVelocity;
    float pitchVelocity;
    CloneMCJavaRandom random;
    int isRoot;
    int branchStep;
    int gentlePitch;

    centerX = (double)(targetChunkX * 16 + 8);
    centerZ = (double)(targetChunkZ * 16 + 8);
    yawVelocity = 0.0F;
    pitchVelocity = 0.0F;
    CloneMCJavaRandom_SetSeed(&random, CloneMCJavaRandom_NextLong(sourceRandom));

    if (maxStep <= 0) {
        int range;
        range = 8 * 16 - 16;
        maxStep = range - CloneMCJavaRandom_NextIntBound(&random, range / 4);
    }

    isRoot = 0;
    if (step == -1) {
        step = maxStep / 2;
        isRoot = 1;
    }

    branchStep = CloneMCJavaRandom_NextIntBound(&random, maxStep / 2) + maxStep / 4;
    gentlePitch = CloneMCJavaRandom_NextIntBound(&random, 6) == 0;

    for (; step < maxStep; ++step) {
        double horizontalRadius;
        double verticalRadius;
        float cosPitch;
        float sinPitch;
        double dxCenter;
        double dzCenter;
        double remaining;
        double maximumReach;
        int minX;
        int maxX;
        int minY;
        int maxY;
        int minZ;
        int maxZ;
        int ix;
        int iz;
        int iy;
        int foundWater;

        horizontalRadius = 1.5 + (double)(CloneMCMathHelper_Sin(((float)step * 3.141593F) / (float)maxStep) * radius);
        verticalRadius = horizontalRadius * verticalScale;
        cosPitch = CloneMCMathHelper_Cos(pitch);
        sinPitch = CloneMCMathHelper_Sin(pitch);
        x += (double)(CloneMCMathHelper_Cos(yaw) * cosPitch);
        y += (double)sinPitch;
        z += (double)(CloneMCMathHelper_Sin(yaw) * cosPitch);

        if (gentlePitch) { pitch *= 0.92F; }
        else { pitch *= 0.7F; }
        pitch += pitchVelocity * 0.1F;
        yaw += yawVelocity * 0.1F;
        pitchVelocity *= 0.9F;
        yawVelocity *= 0.75F;
        pitchVelocity += (CloneMCJavaRandom_NextFloat(&random) - CloneMCJavaRandom_NextFloat(&random)) *
            CloneMCJavaRandom_NextFloat(&random) * 2.0F;
        yawVelocity += (CloneMCJavaRandom_NextFloat(&random) - CloneMCJavaRandom_NextFloat(&random)) *
            CloneMCJavaRandom_NextFloat(&random) * 4.0F;

        if (!isRoot && step == branchStep && radius > 1.0F) {
            CloneMCJ_MapGenCaves_Tunnel(targetChunkX, targetChunkZ, blocks, sourceRandom,
                x, y, z, CloneMCJavaRandom_NextFloat(&random) * 0.5F + 0.5F,
                yaw - 1.570796F, pitch / 3.0F, step, maxStep, 1.0);
            CloneMCJ_MapGenCaves_Tunnel(targetChunkX, targetChunkZ, blocks, sourceRandom,
                x, y, z, CloneMCJavaRandom_NextFloat(&random) * 0.5F + 0.5F,
                yaw + 1.570796F, pitch / 3.0F, step, maxStep, 1.0);
            return;
        }

        if (!isRoot && CloneMCJavaRandom_NextIntBound(&random, 4) == 0) { continue; }

        dxCenter = x - centerX;
        dzCenter = z - centerZ;
        remaining = (double)(maxStep - step);
        maximumReach = (double)radius + 18.0;
        if (dxCenter * dxCenter + dzCenter * dzCenter - remaining * remaining > maximumReach * maximumReach) { return; }

        if (x < centerX - 16.0 - horizontalRadius * 2.0 ||
            z < centerZ - 16.0 - horizontalRadius * 2.0 ||
            x > centerX + 16.0 + horizontalRadius * 2.0 ||
            z > centerZ + 16.0 + horizontalRadius * 2.0) {
            continue;
        }

        minX = CloneMCJava_FloorDouble(x - horizontalRadius) - targetChunkX * 16 - 1;
        maxX = CloneMCJava_FloorDouble(x + horizontalRadius) - targetChunkX * 16 + 1;
        minY = CloneMCJava_FloorDouble(y - verticalRadius) - 1;
        maxY = CloneMCJava_FloorDouble(y + verticalRadius) + 1;
        minZ = CloneMCJava_FloorDouble(z - horizontalRadius) - targetChunkZ * 16 - 1;
        maxZ = CloneMCJava_FloorDouble(z + horizontalRadius) - targetChunkZ * 16 + 1;
        if (minX < 0) { minX = 0; }
        if (maxX > 16) { maxX = 16; }
        if (minY < 1) { minY = 1; }
        if (maxY > 120) { maxY = 120; }
        if (minZ < 0) { minZ = 0; }
        if (maxZ > 16) { maxZ = 16; }

        foundWater = 0;
        for (ix = minX; !foundWater && ix < maxX; ++ix) {
            for (iz = minZ; !foundWater && iz < maxZ; ++iz) {
                for (iy = maxY + 1; !foundWater && iy >= minY - 1; --iy) {
                    int block;
                    if (iy < 0 || iy >= 128) { continue; }
                    block = blocks[CloneMCJ_MapGenCaves_Index(ix, iy, iz)];
                    if ((!g_cloneMCMapGenCavesHellMode &&
                         (block == CLONEMC_J_BLOCK_WATER_MOVING || block == CLONEMC_J_BLOCK_WATER_STILL)) ||
                        (g_cloneMCMapGenCavesHellMode &&
                         (block == CLONEMC_J_BLOCK_LAVA_MOVING || block == CLONEMC_J_BLOCK_LAVA_STILL))) {
                        foundWater = 1;
                    }
                    if (iy != minY - 1 && ix != minX && ix != maxX - 1 && iz != minZ && iz != maxZ - 1) {
                        iy = minY;
                    }
                }
            }
        }
        if (foundWater) { continue; }

        for (ix = minX; ix < maxX; ++ix) {
            double nx;
            nx = (((double)(ix + targetChunkX * 16) + 0.5) - x) / horizontalRadius;
            for (iz = minZ; iz < maxZ; ++iz) {
                double nz;
                int blockIndex;
                int grassSeen;
                nz = (((double)(iz + targetChunkZ * 16) + 0.5) - z) / horizontalRadius;
                if (nx * nx + nz * nz >= 1.0) { continue; }
                blockIndex = CloneMCJ_MapGenCaves_Index(ix, maxY, iz);
                grassSeen = 0;
                for (iy = maxY - 1; iy >= minY; --iy) {
                    double ny;
                    int block;
                    ny = (((double)iy + 0.5) - y) / verticalRadius;
                    if (ny > -0.7 && nx * nx + ny * ny + nz * nz < 1.0) {
                        block = blocks[blockIndex];
                        if (block == CLONEMC_J_BLOCK_GRASS) { grassSeen = 1; }
                        if ((!g_cloneMCMapGenCavesHellMode &&
                             (block == CLONEMC_J_BLOCK_STONE || block == CLONEMC_J_BLOCK_DIRT || block == CLONEMC_J_BLOCK_GRASS)) ||
                            (g_cloneMCMapGenCavesHellMode &&
                             (block == CLONEMC_J_BLOCK_NETHERRACK || block == CLONEMC_J_BLOCK_DIRT || block == CLONEMC_J_BLOCK_GRASS))) {
                            if (g_cloneMCMapGenCavesHellMode) { blocks[blockIndex] = (unsigned char)CLONEMC_J_BLOCK_AIR; }
                            else if (iy < 10) { blocks[blockIndex] = (unsigned char)CLONEMC_J_BLOCK_LAVA_MOVING; }
                            else {
                                blocks[blockIndex] = (unsigned char)CLONEMC_J_BLOCK_AIR;
                                if (grassSeen && blocks[blockIndex - 1] == CLONEMC_J_BLOCK_DIRT) {
                                    blocks[blockIndex - 1] = (unsigned char)CLONEMC_J_BLOCK_GRASS;
                                }
                            }
                        }
                    }
                    --blockIndex;
                }
            }
        }
        if (isRoot) { break; }
    }
}

void CloneMCJ_MapGenCaves_CarveHellTunnel(CloneMCJavaRandom *random,
    int targetChunkX, int targetChunkZ, CloneMCJ_Chunk *chunk, double x, double y,
    double z, float radius, float yaw, float pitch, int step, int maxStep,
    double verticalScale)
{
    if (!random || !chunk) return;
    g_cloneMCMapGenCavesHellMode = 1;
    CloneMCJ_MapGenCaves_Tunnel(targetChunkX, targetChunkZ, chunk->blocks, random,
        x, y, z, radius, yaw, pitch, step, maxStep, verticalScale);
    g_cloneMCMapGenCavesHellMode = 0;
}

static void CloneMCJ_MapGenCaves_LargeNode(int targetChunkX, int targetChunkZ,
    unsigned char *blocks, CloneMCJavaRandom *sourceRandom, double x, double y, double z)
{
    CloneMCJ_MapGenCaves_Tunnel(targetChunkX, targetChunkZ, blocks, sourceRandom,
        x, y, z, 1.0F + CloneMCJavaRandom_NextFloat(sourceRandom) * 6.0F,
        0.0F, 0.0F, -1, -1, 0.5);
}

void CloneMCJ_MapGenCaves_CarveFromSource(CloneMCJavaRandom *random, int sourceChunkX, int sourceChunkZ,
    int targetChunkX, int targetChunkZ, CloneMCJ_Chunk *chunk)
{
    int caveCount;
    int caveIndex;
    if (!random || !chunk) { return; }
    caveCount = CloneMCJavaRandom_NextIntBound(random,
        CloneMCJavaRandom_NextIntBound(random,
            CloneMCJavaRandom_NextIntBound(random, 40) + 1) + 1);
    if (CloneMCJavaRandom_NextIntBound(random, 15) != 0) { caveCount = 0; }

    for (caveIndex = 0; caveIndex < caveCount; ++caveIndex) {
        double x;
        double y;
        double z;
        int tunnelCount;
        int tunnel;
        x = (double)(sourceChunkX * 16 + CloneMCJavaRandom_NextIntBound(random, 16));
        y = (double)CloneMCJavaRandom_NextIntBound(random, CloneMCJavaRandom_NextIntBound(random, 120) + 8);
        z = (double)(sourceChunkZ * 16 + CloneMCJavaRandom_NextIntBound(random, 16));
        tunnelCount = 1;
        if (CloneMCJavaRandom_NextIntBound(random, 4) == 0) {
            CloneMCJ_MapGenCaves_LargeNode(targetChunkX, targetChunkZ, chunk->blocks, random, x, y, z);
            tunnelCount += CloneMCJavaRandom_NextIntBound(random, 4);
        }
        for (tunnel = 0; tunnel < tunnelCount; ++tunnel) {
            float yaw;
            float pitch;
            float radius;
            yaw = CloneMCJavaRandom_NextFloat(random) * 3.141593F * 2.0F;
            pitch = ((CloneMCJavaRandom_NextFloat(random) - 0.5F) * 2.0F) / 8.0F;
            radius = CloneMCJavaRandom_NextFloat(random) * 2.0F + CloneMCJavaRandom_NextFloat(random);
            CloneMCJ_MapGenCaves_Tunnel(targetChunkX, targetChunkZ, chunk->blocks, random,
                x, y, z, radius, yaw, pitch, 0, 0, 1.0);
        }
    }
}

void CloneMCJ_MapGenCaves_Carve(CloneMCJLong worldSeed, int chunkX, int chunkZ, CloneMCJ_Chunk *chunk)
{
    CloneMCJ_MapGenBase_GenerateCaves(worldSeed, chunkX, chunkZ, chunk);
}
