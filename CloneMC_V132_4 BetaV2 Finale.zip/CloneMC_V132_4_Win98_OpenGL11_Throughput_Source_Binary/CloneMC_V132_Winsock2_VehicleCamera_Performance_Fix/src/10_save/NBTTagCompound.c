/* Java source: NBTTagCompound.java; Source SHA-256: 1f9a5517de614396b6aea834c18140f3ae866f32c0d22fa6404fc77c9f4d2aef; Java lines: 234. */
/* Direct C89 port of NBTTagCompound.java. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
CloneMCJ_NBTTagCompound *CloneMCJ_NBTTagCompound_Create(void){return (CloneMCJ_NBTTagCompound*)CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_COMPOUND);}
static CloneMCJInt Compound_Find(const CloneMCJ_NBTTagCompound *c,const char *key){CloneMCJInt i;if(!c||c->type!=10||!key)return -1;for(i=0;i<c->value.compoundValue.count;++i){if(strcmp(CloneMCJ_NBTBase_GetKey(c->value.compoundValue.entries[i]),key)==0)return i;}return -1;}
void CloneMCJ_NBTTagCompound_SetTag(CloneMCJ_NBTTagCompound *c,const char *key,CloneMCJ_NBTBase *tag)
{
    CloneMCJInt i,cap;
    CloneMCJ_NBTBase **next;
    if(!c||c->type!=10||!key||!tag)return;
    /* NBT_ReadContents passes tag->key as key.  Locate an existing map entry
     * before SetKey replaces/frees that allocation; retaining the aliased
     * parameter after SetKey was a use-after-free on every compound load. */
    i=Compound_Find(c,key);
    CloneMCJ_NBTBase_SetKey(tag,key);
    if(i>=0){
        if(c->value.compoundValue.entries[i]!=tag)
            CloneMCJ_NBTBase_Free(c->value.compoundValue.entries[i]);
        c->value.compoundValue.entries[i]=tag;
        return;
    }
    if(c->value.compoundValue.count>=c->value.compoundValue.capacity){
        cap=c->value.compoundValue.capacity?
            c->value.compoundValue.capacity*2:8;
        next=(CloneMCJ_NBTBase**)realloc(c->value.compoundValue.entries,
            (unsigned long)cap*sizeof(CloneMCJ_NBTBase*));
        if(!next){CloneMCJ_NBTBase_Free(tag);return;}
        c->value.compoundValue.entries=next;
        c->value.compoundValue.capacity=cap;
    }
    c->value.compoundValue.entries[c->value.compoundValue.count++]=tag;
}
void CloneMCJ_NBTTagCompound_SetByte(CloneMCJ_NBTTagCompound*c,const char*k,CloneMCJByte v){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagByte_Create(v));}
void CloneMCJ_NBTTagCompound_SetShort(CloneMCJ_NBTTagCompound*c,const char*k,CloneMCJShort v){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagShort_Create(v));}
void CloneMCJ_NBTTagCompound_SetInteger(CloneMCJ_NBTTagCompound*c,const char*k,CloneMCJInt v){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagInt_Create(v));}
void CloneMCJ_NBTTagCompound_SetLong(CloneMCJ_NBTTagCompound*c,const char*k,CloneMCJLong v){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagLong_Create(v));}
void CloneMCJ_NBTTagCompound_SetFloat(CloneMCJ_NBTTagCompound*c,const char*k,float v){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagFloat_Create(v));}
void CloneMCJ_NBTTagCompound_SetDouble(CloneMCJ_NBTTagCompound*c,const char*k,double v){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagDouble_Create(v));}
void CloneMCJ_NBTTagCompound_SetString(CloneMCJ_NBTTagCompound*c,const char*k,const char*v){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagString_Create(v));}
void CloneMCJ_NBTTagCompound_SetByteArray(CloneMCJ_NBTTagCompound*c,const char*k,const unsigned char*d,CloneMCJInt n){CloneMCJ_NBTTagCompound_SetTag(c,k,(CloneMCJ_NBTBase*)CloneMCJ_NBTTagByteArray_Create(d,n));}
void CloneMCJ_NBTTagCompound_SetBoolean(CloneMCJ_NBTTagCompound*c,const char*k,int v){CloneMCJ_NBTTagCompound_SetByte(c,k,(CloneMCJByte)(v?1:0));}
int CloneMCJ_NBTTagCompound_HasKey(const CloneMCJ_NBTTagCompound*c,const char*k){return Compound_Find(c,k)>=0;}
CloneMCJ_NBTBase *CloneMCJ_NBTTagCompound_GetTag(const CloneMCJ_NBTTagCompound*c,const char*k){CloneMCJInt i=Compound_Find(c,k);return i>=0?c->value.compoundValue.entries[i]:0;}
#define GETNUM(fn,typeid,field,ctype) ctype fn(const CloneMCJ_NBTTagCompound*c,const char*k){CloneMCJ_NBTBase*t=CloneMCJ_NBTTagCompound_GetTag(c,k);return t&&t->type==typeid?(ctype)t->value.field:(ctype)0;}
GETNUM(CloneMCJ_NBTTagCompound_GetByte,1,byteValue,CloneMCJByte)
GETNUM(CloneMCJ_NBTTagCompound_GetShort,2,shortValue,CloneMCJShort)
GETNUM(CloneMCJ_NBTTagCompound_GetInteger,3,intValue,CloneMCJInt)
GETNUM(CloneMCJ_NBTTagCompound_GetLong,4,longValue,CloneMCJLong)
GETNUM(CloneMCJ_NBTTagCompound_GetFloat,5,floatValue,float)
GETNUM(CloneMCJ_NBTTagCompound_GetDouble,6,doubleValue,double)
const char *CloneMCJ_NBTTagCompound_GetString(const CloneMCJ_NBTTagCompound*c,const char*k){CloneMCJ_NBTBase*t=CloneMCJ_NBTTagCompound_GetTag(c,k);return t&&t->type==8&&t->value.stringValue?t->value.stringValue:"";}
const unsigned char *CloneMCJ_NBTTagCompound_GetByteArray(const CloneMCJ_NBTTagCompound*c,const char*k,CloneMCJInt*n){CloneMCJ_NBTBase*t=CloneMCJ_NBTTagCompound_GetTag(c,k);if(n)*n=t&&t->type==7?t->value.byteArray.length:0;return t&&t->type==7?t->value.byteArray.data:0;}
CloneMCJ_NBTTagCompound *CloneMCJ_NBTTagCompound_GetCompoundTag(const CloneMCJ_NBTTagCompound*c,const char*k){CloneMCJ_NBTBase*t=CloneMCJ_NBTTagCompound_GetTag(c,k);return t&&t->type==10?(CloneMCJ_NBTTagCompound*)t:0;}
CloneMCJ_NBTTagList *CloneMCJ_NBTTagCompound_GetTagList(const CloneMCJ_NBTTagCompound*c,const char*k){CloneMCJ_NBTBase*t=CloneMCJ_NBTTagCompound_GetTag(c,k);return t&&t->type==9?(CloneMCJ_NBTTagList*)t:0;}
int CloneMCJ_NBTTagCompound_GetBoolean(const CloneMCJ_NBTTagCompound*c,const char*k){return CloneMCJ_NBTTagCompound_GetByte(c,k)!=0;}

void CloneMCJ_NBTTagCompound_Register(void) { }
const char *CloneMCJ_NBTTagCompound_JavaName(void) { return "net.minecraft.src.NBTTagCompound"; }
const char *CloneMCJ_NBTTagCompound_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagCompound_JavaSourceHash32(void) { return 0x1F9A5517UL; }
