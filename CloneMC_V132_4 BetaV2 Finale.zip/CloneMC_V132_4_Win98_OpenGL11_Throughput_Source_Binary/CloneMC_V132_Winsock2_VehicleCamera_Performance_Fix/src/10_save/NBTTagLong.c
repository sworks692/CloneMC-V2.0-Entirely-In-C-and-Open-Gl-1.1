/* Java source: NBTTagLong.java; Source SHA-256: 660171a1375b6c4e1076f0e088ad3ed3683ae9023ce0f5b5a0192a8e5e8ce508; Java lines: 47. */
/* Direct C89 port of NBTTagLong.java. */
#include "clonemc_java_port_10_save.h"
CloneMCJ_NBTTagLong *CloneMCJ_NBTTagLong_Create(CloneMCJLong value){CloneMCJ_NBTBase *tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_LONG);if(tag){tag->value.longValue=value;}return (CloneMCJ_NBTTagLong*)tag;}

void CloneMCJ_NBTTagLong_Register(void) { }
const char *CloneMCJ_NBTTagLong_JavaName(void) { return "net.minecraft.src.NBTTagLong"; }
const char *CloneMCJ_NBTTagLong_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagLong_JavaSourceHash32(void) { return 0x660171A1UL; }
