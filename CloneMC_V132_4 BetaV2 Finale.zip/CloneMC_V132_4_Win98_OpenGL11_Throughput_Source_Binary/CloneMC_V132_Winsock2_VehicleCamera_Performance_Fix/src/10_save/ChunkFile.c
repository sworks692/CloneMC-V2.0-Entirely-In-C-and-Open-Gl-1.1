/* Java source: ChunkFile.java; Source SHA-256: e8f78473a541a78d544ebbd440c08e216750573c9a59a168af690d9beae32fa6; Java lines: 71. */
/* Direct C89 port of ChunkFile.java. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
static int CF_Digit(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='z')return c-'a'+10;return -1;}
static int CF_Parse36(const char*s,int n,int*out){unsigned long v=0;int sign=1,i,d;if(!s||n<1||!out)return 0;i=0;if(s[0]=='-'){sign=-1;i=1;}if(i>=n)return 0;for(;i<n;++i){d=CF_Digit(s[i]);if(d<0)return 0;v=v*36UL+(unsigned long)d;}*out=(int)(sign*(long)v);return 1;}
int CloneMCJ_ChunkFile_Initialize(CloneMCJ_ChunkFile*f,const char*p){const char*n,*a,*b,*e;if(!f||!p)return 0;memset(f,0,sizeof(*f));strncpy(f->path,p,sizeof(f->path)-1);n=strrchr(p,'/');{const char*w=strrchr(p,'\\');if(w&&(!n||w>n))n=w;}n=n?n+1:p;if(!CloneMCJ_ChunkFilePattern_Accept(n))return 0;a=n+2;b=strchr(a,'.');e=strrchr(b+1,'.');if(!CF_Parse36(a,(int)(b-a),&f->chunkX)||!CF_Parse36(b+1,(int)(e-b-1),&f->chunkZ))return 0;return 1;}
int CloneMCJ_ChunkFile_Compare(const CloneMCJ_ChunkFile*a,const CloneMCJ_ChunkFile*b){int ar,br;if(!a||!b)return 0;ar=a->chunkX>>5;br=b->chunkX>>5;if(ar==br)return (a->chunkZ>>5)-(b->chunkZ>>5);return ar-br;}
void CloneMCJ_ChunkFile_Register(void){}
const char *CloneMCJ_ChunkFile_JavaName(void){return "net.minecraft.src.ChunkFile";}
const char *CloneMCJ_ChunkFile_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_ChunkFile_JavaSourceHash32(void){return 0xE8F78473UL;}
