/* Java source: IChunkLoader.java; Source SHA-256: 5b90e19afae5cca07ce6c3e2d8fd5d6fb7089a21a7756ae9c9a4f87e6e1b3286; Java lines: 27. */
/* Direct C89 adapter for IChunkLoader.java. */
#include "clonemc_java_port_10_save.h"
static int ICL_Load(void*i,CloneMCJ_Chunk*c,int x,int z){return CloneMCJ_McRegionChunkLoader_Load((CloneMCJ_McRegionChunkLoader*)i,c,x,z);}
static int ICL_Save(void*i,const CloneMCJ_Chunk*c,CloneMCJLong t){return CloneMCJ_McRegionChunkLoader_Save((CloneMCJ_McRegionChunkLoader*)i,c,t);}
static void ICL_Flush(void*i){CloneMCJ_McRegionChunkLoader*l=(CloneMCJ_McRegionChunkLoader*)i;if(l&&l->cache)CloneMCJ_RegionFileCache_CloseAll(l->cache);}
CloneMCJ_IChunkLoader CloneMCJ_IChunkLoader_FromMcRegion(CloneMCJ_McRegionChunkLoader*l){CloneMCJ_IChunkLoader i;i.instance=l;i.loadChunk=ICL_Load;i.saveChunk=ICL_Save;i.flush=ICL_Flush;return i;}
static int ICL_OldLoad(void*i,CloneMCJ_Chunk*c,int x,int z){return CloneMCJ_ChunkLoader_Load((CloneMCJ_ChunkLoader*)i,c,x,z);}
static int ICL_OldSave(void*i,const CloneMCJ_Chunk*c,CloneMCJLong t){return CloneMCJ_ChunkLoader_Save((CloneMCJ_ChunkLoader*)i,c,t);}
static void ICL_OldFlush(void*i){(void)i;}
CloneMCJ_IChunkLoader CloneMCJ_IChunkLoader_FromOldChunkLoader(CloneMCJ_ChunkLoader*l){CloneMCJ_IChunkLoader i;i.instance=l;i.loadChunk=ICL_OldLoad;i.saveChunk=ICL_OldSave;i.flush=ICL_OldFlush;return i;}
void CloneMCJ_IChunkLoader_Register(void){}
const char *CloneMCJ_IChunkLoader_JavaName(void){return "net.minecraft.src.IChunkLoader";}
const char *CloneMCJ_IChunkLoader_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_IChunkLoader_JavaSourceHash32(void){return 0x5B90E19AUL;}
