/* Java source: NBTTagEnd.java; Source SHA-256: 3d7e468d943d472a7dce82f4a086c6d75171b673893aa54e649dc3304ee5e042; Java lines: 38. */
/* Direct C89 port of NBTTagEnd.java. */
#include "clonemc_java_port_10_save.h"
CloneMCJ_NBTTagEnd *CloneMCJ_NBTTagEnd_Create(void){return (CloneMCJ_NBTTagEnd*)CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_END);}

void CloneMCJ_NBTTagEnd_Register(void) { }
const char *CloneMCJ_NBTTagEnd_JavaName(void) { return "net.minecraft.src.NBTTagEnd"; }
const char *CloneMCJ_NBTTagEnd_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagEnd_JavaSourceHash32(void) { return 0x3D7E468DUL; }
