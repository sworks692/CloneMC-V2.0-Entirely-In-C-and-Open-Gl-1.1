/* Java source: RegionFileCache.java; Source SHA-256: fa9e9a33137a52804a8f5fe39c6dd65a3b3073675abf2f95e5f6d0f21f226808; Java lines: 94. */
/* C89 bounded LRU cache with checked eviction, retry, and detailed diagnostics. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#if defined(_WIN32)
#include <direct.h>
#define CMC_MKDIR(p) _mkdir(p)
#else
#include <sys/stat.h>
#define CMC_MKDIR(p) mkdir((p),0755)
#endif
static int RFC_FloorDiv32(int v){return v>=0?v/32:-((31-v)/32);}
static int RFC_Mod32(int v){int q=RFC_FloorDiv32(v);return v-q*32;}
static void RFC_MakeDir(const char*p){CMC_MKDIR(p);}
static void RFC_CopyRegionError(CloneMCJ_RegionFileCache*c,const CloneMCJ_RegionFile*r,int x,int z){if(!c)return;c->lastChunkX=x;c->lastChunkZ=z;if(r){c->lastError=r->lastError;c->lastSystemError=r->lastSystemError;strncpy(c->lastPath,r->path,sizeof(c->lastPath)-1);c->lastPath[sizeof(c->lastPath)-1]='\0';strncpy(c->lastOperation,r->lastOperation,sizeof(c->lastOperation)-1);c->lastOperation[sizeof(c->lastOperation)-1]='\0';}else{c->lastError=CLONEMC_J_REGION_ERROR_OPEN;c->lastSystemError=0;c->lastPath[0]='\0';strcpy(c->lastOperation,"open region");}}
void CloneMCJ_RegionFileCache_Initialize(CloneMCJ_RegionFileCache*c)
{if(c){memset(c,0,sizeof(*c));c->activeLimit=CLONEMC_J_REGION_CACHE_SIZE;}}
void CloneMCJ_RegionFileCache_SetLimit(CloneMCJ_RegionFileCache*c,int limit)
{if(!c)return;if(limit<1)limit=1;if(limit>CLONEMC_J_REGION_CACHE_SIZE)
limit=CLONEMC_J_REGION_CACHE_SIZE;c->activeLimit=limit;}
int CloneMCJ_RegionFileCache_FlushAll(CloneMCJ_RegionFileCache*c,int durable){int i,ok;if(!c)return 0;ok=1;for(i=0;i<CLONEMC_J_REGION_CACHE_SIZE;++i)if(c->entries[i].used){if(!CloneMCJ_RegionFile_Flush(&c->entries[i].region,durable)){RFC_CopyRegionError(c,&c->entries[i].region,c->entries[i].region.lastChunkX,c->entries[i].region.lastChunkZ);ok=0;}}return ok;}
void CloneMCJ_RegionFileCache_CloseAll(CloneMCJ_RegionFileCache*c){int i;if(!c)return;
/* Save-and-quit has an absolute UI deadline.  Do not perform a second
 * device-level durable flush while closing every cached region: each chunk
 * payload/header was already stdio-flushed and read-back verified before its
 * location entry became authoritative.  A normal buffered flush plus fclose
 * is sufficient for Java RandomAccessFile compatibility and avoids legacy
 * Windows storage/filter drivers trapping the title transition forever. */
CloneMCJ_RegionFileCache_FlushAll(c,0);for(i=0;i<CLONEMC_J_REGION_CACHE_SIZE;++i)if(c->entries[i].used){CloneMCJ_RegionFile_Close(&c->entries[i].region);c->entries[i].used=0;}}
CloneMCJ_RegionFile *CloneMCJ_RegionFileCache_GetRegion(CloneMCJ_RegionFileCache*c,const char*world,int cx,int cz){char dir[CLONEMC_J_PATH_MAX],path[CLONEMC_J_PATH_MAX];int rx,rz,i,slot,limit;unsigned long oldest;if(!c||!world)return 0;limit=c->activeLimit;if(limit<1||limit>CLONEMC_J_REGION_CACHE_SIZE)limit=CLONEMC_J_REGION_CACHE_SIZE;rx=RFC_FloorDiv32(cx);rz=RFC_FloorDiv32(cz);if(strlen(world)+8UL>=sizeof(dir))return 0;strcpy(dir,world);strcat(dir,"/region");RFC_MakeDir(world);RFC_MakeDir(dir);if(strlen(dir)+40UL>=sizeof(path))return 0;{char tail[64];sprintf(tail,"/r.%d.%d.mcr",rx,rz);strcpy(path,dir);strcat(path,tail);}for(i=0;i<limit;++i){if(c->entries[i].used&&strcmp(c->entries[i].path,path)==0){c->entries[i].accessStamp=++c->accessClock;return &c->entries[i].region;}}slot=-1;oldest=0xFFFFFFFFUL;for(i=0;i<limit;++i){if(!c->entries[i].used){slot=i;break;}if(c->entries[i].accessStamp<oldest){oldest=c->entries[i].accessStamp;slot=i;}}if(slot<0)return 0;if(c->entries[slot].used){if(!CloneMCJ_RegionFile_Flush(&c->entries[slot].region,1)){RFC_CopyRegionError(c,&c->entries[slot].region,cx,cz);return 0;}CloneMCJ_RegionFile_Close(&c->entries[slot].region);}memset(&c->entries[slot],0,sizeof(c->entries[slot]));if(!CloneMCJ_RegionFile_Open(&c->entries[slot].region,path)){RFC_CopyRegionError(c,&c->entries[slot].region,cx,cz);return 0;}c->entries[slot].used=1;c->entries[slot].accessStamp=++c->accessClock;strncpy(c->entries[slot].path,path,sizeof(c->entries[slot].path)-1);return &c->entries[slot].region;}
int CloneMCJ_RegionFileCache_HasChunk(CloneMCJ_RegionFileCache*c,const char*w,int x,int z){CloneMCJ_RegionFile*r=CloneMCJ_RegionFileCache_GetRegion(c,w,x,z);return r?CloneMCJ_RegionFile_HasChunk(r,RFC_Mod32(x),RFC_Mod32(z)):-1;}
int CloneMCJ_RegionFileCache_ReadChunk(CloneMCJ_RegionFileCache*c,const char*w,int x,int z,unsigned char**d,unsigned long*n){CloneMCJ_RegionFile*r=CloneMCJ_RegionFileCache_GetRegion(c,w,x,z);int ok;if(!r)return 0;ok=CloneMCJ_RegionFile_ReadChunk(r,RFC_Mod32(x),RFC_Mod32(z),d,n);if(!ok&&CloneMCJ_RegionFile_HasChunk(r,RFC_Mod32(x),RFC_Mod32(z)))RFC_CopyRegionError(c,r,x,z);return ok;}
int CloneMCJ_RegionFileCache_WriteChunkEx(CloneMCJ_RegionFileCache*c,const char*w,int x,int z,const unsigned char*d,unsigned long n,int durable){CloneMCJ_RegionFile*r;int ok;if(!c)return 0;++c->writeAttempts;r=CloneMCJ_RegionFileCache_GetRegion(c,w,x,z);if(!r){++c->writeFailures;return 0;}ok=CloneMCJ_RegionFile_WriteChunkEx(r,RFC_Mod32(x),RFC_Mod32(z),d,n,durable);if(!ok){RFC_CopyRegionError(c,r,x,z);++c->writeRetries;++r->writeRetries;clearerr(r->file);ok=CloneMCJ_RegionFile_WriteChunkEx(r,RFC_Mod32(x),RFC_Mod32(z),d,n,durable);if(!ok){RFC_CopyRegionError(c,r,x,z);++c->writeFailures;return 0;}}c->lastError=0;c->lastSystemError=0;c->lastPath[0]='\0';c->lastOperation[0]='\0';return 1;}
int CloneMCJ_RegionFileCache_WriteChunk(CloneMCJ_RegionFileCache*c,const char*w,int x,int z,const unsigned char*d,unsigned long n){return CloneMCJ_RegionFileCache_WriteChunkEx(c,w,x,z,d,n,0);}
long CloneMCJ_RegionFileCache_GetSizeDelta(CloneMCJ_RegionFileCache*c,const char*w,int x,int z){CloneMCJ_RegionFile*r=CloneMCJ_RegionFileCache_GetRegion(c,w,x,z);return r?CloneMCJ_RegionFile_GetSizeDelta(r):0;}
void CloneMCJ_RegionFileCache_Register(void) { }
const char *CloneMCJ_RegionFileCache_JavaName(void) { return "net.minecraft.src.RegionFileCache"; }
const char *CloneMCJ_RegionFileCache_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_RegionFileCache_JavaSourceHash32(void) { return 0xFA9E9A33UL; }
