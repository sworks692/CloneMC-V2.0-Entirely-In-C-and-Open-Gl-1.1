/* Java source: NBTTagString.java; Source SHA-256: dba9612ac9955b8a651b3361ea70a8e3a53c215ff9193984e5d988d488325b4e; Java lines: 54. */
/* Direct C89 port of NBTTagString.java. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
CloneMCJ_NBTTagString *CloneMCJ_NBTTagString_Create(const char *value)
{
    CloneMCJ_NBTBase *tag;char *copy;unsigned long n;if(!value)value="";tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_STRING);if(!tag)return 0;n=(unsigned long)strlen(value);copy=(char*)malloc(n+1UL);if(!copy){CloneMCJ_NBTBase_Free(tag);return 0;}memcpy(copy,value,n+1UL);free(tag->value.stringValue);tag->value.stringValue=copy;return (CloneMCJ_NBTTagString*)tag;
}

void CloneMCJ_NBTTagString_Register(void) { }
const char *CloneMCJ_NBTTagString_JavaName(void) { return "net.minecraft.src.NBTTagString"; }
const char *CloneMCJ_NBTTagString_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagString_JavaSourceHash32(void) { return 0xDBA9612AUL; }
