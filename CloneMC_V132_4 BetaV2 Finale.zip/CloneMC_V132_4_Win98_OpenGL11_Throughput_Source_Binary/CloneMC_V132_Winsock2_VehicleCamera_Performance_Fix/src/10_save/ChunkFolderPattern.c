/* Java source: ChunkFolderPattern.java; Source SHA-256: 821a213a4b0424b6cb09037a54ba3ea3bf414b206af861fef91a6d7485253dd2; Java lines: 42. */
/* Direct C89 port of ChunkFolderPattern.java. */
#include "clonemc_java_port_10_save.h"
#include <string.h>
static int CFolderDigit(char c){return (c>='0'&&c<='9')||(c>='a'&&c<='z');}
int CloneMCJ_ChunkFolderPattern_Accept(const char*n){size_t z;if(!n)return 0;z=strlen(n);return (z==1&&CFolderDigit(n[0]))||(z==2&&CFolderDigit(n[0])&&CFolderDigit(n[1]));}
void CloneMCJ_ChunkFolderPattern_Register(void){}
const char *CloneMCJ_ChunkFolderPattern_JavaName(void){return "net.minecraft.src.ChunkFolderPattern";}
const char *CloneMCJ_ChunkFolderPattern_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_ChunkFolderPattern_JavaSourceHash32(void){return 0x821A213AUL;}
