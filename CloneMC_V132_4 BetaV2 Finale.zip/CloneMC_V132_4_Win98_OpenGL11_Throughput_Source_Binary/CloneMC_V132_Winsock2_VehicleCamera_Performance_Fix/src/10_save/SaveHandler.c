/* Java source: SaveHandler.java; Source SHA-256: a64198c1607dcc50bc11fdf2ce66b4b086aaa8f02817b4e1d7576992608a3b0c; Java lines: 206. */
/* Direct C89 port of SaveHandler.java with transactional level.dat updates. */
#include "clonemc_java_port_10_save.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#if defined(_WIN32)
#include <direct.h>
#include <io.h>
#define SH_MKDIR(p) _mkdir(p)
#define SH_RMDIR(p) _rmdir(p)
#else
#include <sys/stat.h>
#include <unistd.h>
#define SH_MKDIR(p) mkdir((p),0755)
#define SH_RMDIR(p) rmdir(p)
#endif

static void SH_SetError(CloneMCJ_SaveHandler *handler, const char *message)
{
    if (!handler) return;
    if (!message) message = "";
    strncpy(handler->lastError, message, sizeof(handler->lastError) - 1);
    handler->lastError[sizeof(handler->lastError) - 1] = '\0';
}

static void SH_SetErrorPath(CloneMCJ_SaveHandler *handler, const char *message,
    const char *path)
{
    unsigned long used;
    SH_SetError(handler, message);
    if (!handler || !path || !*path) return;
    used = (unsigned long)strlen(handler->lastError);
    if (used + 2UL < sizeof(handler->lastError)) {
        handler->lastError[used++] = ':';
        handler->lastError[used++] = ' ';
        handler->lastError[used] = '\0';
    }
    if (used + 1UL < sizeof(handler->lastError)) {
        strncpy(handler->lastError + used, path,
            sizeof(handler->lastError) - used - 1UL);
        handler->lastError[sizeof(handler->lastError) - 1] = '\0';
    }
}

static int SH_Join(char *output, const char *parent, const char *child)
{
    unsigned long required;
    if (!output || !parent || !child) return 0;
    required = (unsigned long)strlen(parent) + (unsigned long)strlen(child) + 2UL;
    if (required > CLONEMC_J_PATH_MAX) { output[0] = '\0'; return 0; }
    strcpy(output, parent);
    if (output[0] && output[strlen(output) - 1] != '/' &&
        output[strlen(output) - 1] != '\\') strcat(output, "/");
    strcat(output, child);
    return 1;
}

static int SH_Exists(const char *path)
{
    FILE *file;
    file = fopen(path, "rb");
    if (!file) return 0;
    fclose(file);
    return 1;
}

static int SH_MakeDirectory(const char *path)
{
    if (!path || !*path) return 0;
    if (SH_MKDIR(path) == 0) return 1;
#if defined(_WIN32)
    return _access(path, 0) == 0;
#else
    return access(path, F_OK) == 0;
#endif
}

static int SH_SafeLeafName(const char *text)
{
    const unsigned char *cursor;
    if (!text || !*text || !strcmp(text, ".") || !strcmp(text, "..")) return 0;
    cursor = (const unsigned char *)text;
    for (; *cursor; ++cursor) {
        if (*cursor < 32 || *cursor == '/' || *cursor == '\\' || *cursor == ':' ||
            *cursor == '<' || *cursor == '>' || *cursor == '"' || *cursor == '|' ||
            *cursor == '?' || *cursor == '*') return 0;
    }
    return 1;
}

/* Java's GZIPOutputStream.close() makes a successful close the transaction
 * boundary.  Some Win32 CRT combinations reject _commit() for a separately
 * reopened append descriptor even though the file is valid.  Retain the
 * durability hint, but never turn that optional hint into "Unable to load". */
static int SH_FlushPath(const char *path)
{
    FILE *file;
    int ok;
    file = fopen(path, "ab");
    if (!file) return 0;
    ok = fflush(file) == 0;
#if defined(_WIN32)
    if (ok) (void)_commit(_fileno(file));
#else
    if (ok) (void)fsync(fileno(file));
#endif
    if (fclose(file) != 0) ok = 0;
    return ok;
}

int CloneMCJ_SaveHandler_Initialize(CloneMCJ_SaveHandler *handler,
    const char *baseDirectory, const char *worldName, int storePlayers)
{
    char lockPath[CLONEMC_J_PATH_MAX];
    FILE *file;
    unsigned char bytes[8];
    CloneMCJULong value;
    int index;
    if (!handler) return 0;
    memset(handler, 0, sizeof(*handler));
    if (!baseDirectory || !*baseDirectory || !SH_SafeLeafName(worldName)) {
        SH_SetError(handler, "The world folder name is empty or unsafe");
        return 0;
    }
    if (!SH_MakeDirectory(baseDirectory)) {
        SH_SetErrorPath(handler, "Cannot create or open the save root", baseDirectory);
        return 0;
    }
    if (!SH_Join(handler->saveDirectory, baseDirectory, worldName)) {
        SH_SetError(handler, "The world save path is too long");
        return 0;
    }
    if (!SH_MakeDirectory(handler->saveDirectory)) {
        SH_SetErrorPath(handler, "Cannot create or open the world directory",
            handler->saveDirectory);
        return 0;
    }
    if (!SH_Join(handler->playersDirectory, handler->saveDirectory, "players") ||
        !SH_Join(handler->dataDirectory, handler->saveDirectory, "data")) {
        SH_SetError(handler, "A world subdirectory path is too long");
        return 0;
    }
    if (!SH_MakeDirectory(handler->dataDirectory)) {
        SH_SetErrorPath(handler, "Cannot create the world data directory",
            handler->dataDirectory);
        return 0;
    }
    if (storePlayers && !SH_MakeDirectory(handler->playersDirectory)) {
        SH_SetErrorPath(handler, "Cannot create the player data directory",
            handler->playersDirectory);
        return 0;
    }
    handler->sessionId = ((CloneMCJLong)time(0) << 32) ^ (CloneMCJLong)clock();
    if (!SH_Join(lockPath, handler->saveDirectory, "session.lock")) {
        SH_SetError(handler, "The session-lock path is too long");
        return 0;
    }
    file = fopen(lockPath, "wb");
    if (!file) {
        SH_SetErrorPath(handler, "Cannot write the world session lock", lockPath);
        return 0;
    }
    value = (CloneMCJULong)handler->sessionId;
    for (index = 0; index < 8; ++index)
        bytes[index] = (unsigned char)(value >> ((7 - index) * 8));
    index = fwrite(bytes, 1, 8, file) == 8;
    if (fflush(file) != 0) index = 0;
    if (fclose(file) != 0) index = 0;
    if (!index) {
        remove(lockPath);
        SH_SetErrorPath(handler, "The world session lock could not be completed", lockPath);
        return 0;
    }
    CloneMCJ_RegionFileCache_Initialize(&handler->regionCache);
    CloneMCJ_McRegionChunkLoader_Initialize(&handler->chunkLoader,
        handler->saveDirectory, &handler->regionCache);
    handler->initialized = 1;
    if (!CloneMCJ_SaveHandler_CheckSessionLock(handler)) {
        CloneMCJ_RegionFileCache_CloseAll(&handler->regionCache);
        handler->initialized = 0;
        return 0;
    }
    SH_SetError(handler, "");
    return 1;
}

void CloneMCJ_SaveHandler_Destroy(CloneMCJ_SaveHandler *handler)
{
    if (!handler) return;
    CloneMCJ_RegionFileCache_CloseAll(&handler->regionCache);
    memset(handler, 0, sizeof(*handler));
}

int CloneMCJ_SaveHandler_CheckSessionLock(CloneMCJ_SaveHandler *handler)
{
    char path[CLONEMC_J_PATH_MAX];
    FILE *file;
    unsigned char bytes[8];
    CloneMCJULong value;
    int index;
    if (!handler || !handler->initialized) return 0;
    if (!SH_Join(path, handler->saveDirectory, "session.lock")) {
        SH_SetError(handler, "The session-lock path is too long");
        return 0;
    }
    file = fopen(path, "rb");
    if (!file) {
        SH_SetErrorPath(handler, "The world session lock is missing", path);
        return 0;
    }
    if (fread(bytes, 1, 8, file) != 8) {
        fclose(file);
        SH_SetErrorPath(handler, "The world session lock is incomplete", path);
        return 0;
    }
    fclose(file);
    value = 0;
    for (index = 0; index < 8; ++index) value = (value << 8) | bytes[index];
    if ((CloneMCJLong)value != handler->sessionId) {
        SH_SetError(handler, "The world is already open in another CloneMC session");
        return 0;
    }
    SH_SetError(handler, "");
    return 1;
}

static int SH_NBTBaseEqual(const CloneMCJ_NBTBase *left,
    const CloneMCJ_NBTBase *right)
{
    int i;
    int j;
    const CloneMCJ_NBTBase *leftEntry;
    const CloneMCJ_NBTBase *rightEntry;
    if(!left||!right)return left==right;
    if(left->type!=right->type)return 0;
    switch(left->type){
    case CLONEMC_J_NBT_TAG_END:return 1;
    case CLONEMC_J_NBT_TAG_BYTE:
        return left->value.byteValue==right->value.byteValue;
    case CLONEMC_J_NBT_TAG_SHORT:
        return left->value.shortValue==right->value.shortValue;
    case CLONEMC_J_NBT_TAG_INT:
        return left->value.intValue==right->value.intValue;
    case CLONEMC_J_NBT_TAG_LONG:
        return left->value.longValue==right->value.longValue;
    case CLONEMC_J_NBT_TAG_FLOAT:
        return left->value.floatValue==right->value.floatValue;
    case CLONEMC_J_NBT_TAG_DOUBLE:
        return left->value.doubleValue==right->value.doubleValue;
    case CLONEMC_J_NBT_TAG_BYTE_ARRAY:
        return left->value.byteArray.length==right->value.byteArray.length&&
            (left->value.byteArray.length==0||
             memcmp(left->value.byteArray.data,right->value.byteArray.data,
                (size_t)left->value.byteArray.length)==0);
    case CLONEMC_J_NBT_TAG_STRING:
        if(!left->value.stringValue||!right->value.stringValue)
            return left->value.stringValue==right->value.stringValue;
        return strcmp(left->value.stringValue,right->value.stringValue)==0;
    case CLONEMC_J_NBT_TAG_LIST:
        if(left->value.listValue.count!=right->value.listValue.count)return 0;
        /* The element type of an empty NBT list carries no values and old
         * Beta writers/parsers may normalize it differently (commonly TAG_End
         * versus TAG_Byte).  Compare the declared type only when elements are
         * actually present.  Otherwise Save and quit can reject a perfectly
         * valid empty Inventory/ActiveEffects list after read-back. */
        if(left->value.listValue.count>0&&
           left->value.listValue.tagType!=right->value.listValue.tagType)return 0;
        for(i=0;i<left->value.listValue.count;++i)
            if(!SH_NBTBaseEqual(left->value.listValue.items[i],
                right->value.listValue.items[i]))return 0;
        return 1;
    case CLONEMC_J_NBT_TAG_COMPOUND:
        if(left->value.compoundValue.count!=right->value.compoundValue.count)
            return 0;
        /* NBT compound ordering is not semantic. The parser may reinsert tags
         * in a different order, so serialized-byte comparison can reject a
         * perfectly durable player snapshot and make Save and quit fail. */
        for(i=0;i<left->value.compoundValue.count;++i){
            leftEntry=left->value.compoundValue.entries[i];
            if(!leftEntry||!leftEntry->key)return 0;
            rightEntry=(const CloneMCJ_NBTBase *)0;
            for(j=0;j<right->value.compoundValue.count;++j){
                const CloneMCJ_NBTBase *candidate;
                candidate=right->value.compoundValue.entries[j];
                if(candidate&&candidate->key&&
                   strcmp(leftEntry->key,candidate->key)==0){
                    rightEntry=candidate;break;
                }
            }
            if(!rightEntry||!SH_NBTBaseEqual(leftEntry,rightEntry))return 0;
        }
        return 1;
    default:return 0;
    }
}

static int SH_NBTValueEqual(const CloneMCJ_NBTBase *left,
    const CloneMCJ_NBTBase *right)
{
    CloneMCJInt index;
    CloneMCJ_NBTBase *rightEntry;
    if (!left || !right) return left == right;
    if (left->type != right->type) return 0;
    switch (left->type) {
    case CLONEMC_J_NBT_TAG_END:
        return 1;
    case CLONEMC_J_NBT_TAG_BYTE:
        return left->value.byteValue == right->value.byteValue;
    case CLONEMC_J_NBT_TAG_SHORT:
        return left->value.shortValue == right->value.shortValue;
    case CLONEMC_J_NBT_TAG_INT:
        return left->value.intValue == right->value.intValue;
    case CLONEMC_J_NBT_TAG_LONG:
        return left->value.longValue == right->value.longValue;
    case CLONEMC_J_NBT_TAG_FLOAT:
        return memcmp(&left->value.floatValue,
            &right->value.floatValue,sizeof(float)) == 0;
    case CLONEMC_J_NBT_TAG_DOUBLE:
        return memcmp(&left->value.doubleValue,
            &right->value.doubleValue,sizeof(double)) == 0;
    case CLONEMC_J_NBT_TAG_BYTE_ARRAY:
        if (left->value.byteArray.length != right->value.byteArray.length)
            return 0;
        return left->value.byteArray.length == 0 ||
            memcmp(left->value.byteArray.data,right->value.byteArray.data,
                (unsigned long)left->value.byteArray.length) == 0;
    case CLONEMC_J_NBT_TAG_STRING:
        return strcmp(left->value.stringValue ? left->value.stringValue : "",
            right->value.stringValue ? right->value.stringValue : "") == 0;
    case CLONEMC_J_NBT_TAG_LIST:
        if (left->value.listValue.count != right->value.listValue.count)
            return 0;
        if (left->value.listValue.count > 0 &&
            left->value.listValue.tagType != right->value.listValue.tagType)
            return 0;
        for (index = 0; index < left->value.listValue.count; ++index)
            if (!SH_NBTValueEqual(left->value.listValue.items[index],
                    right->value.listValue.items[index])) return 0;
        return 1;
    case CLONEMC_J_NBT_TAG_COMPOUND:
        if (left->value.compoundValue.count !=
            right->value.compoundValue.count) return 0;
        for (index = 0; index < left->value.compoundValue.count; ++index) {
            const CloneMCJ_NBTBase *leftEntry;
            leftEntry = left->value.compoundValue.entries[index];
            rightEntry = CloneMCJ_NBTTagCompound_GetTag(
                (const CloneMCJ_NBTTagCompound *)right,
                CloneMCJ_NBTBase_GetKey(leftEntry));
            if (!rightEntry || !SH_NBTValueEqual(leftEntry,rightEntry))
                return 0;
        }
        return 1;
    default:
        return 0;
    }
}

/* Java NBTTagCompound is a map.  The compound's own outer name and the
 * insertion order of its children are not part of its value.  Comparing the
 * raw named-tag byte stream made a valid Player compound fail verification
 * after it acquired the name "Player" inside level.dat. */
static int SH_NBTCompoundEqual(const CloneMCJ_NBTTagCompound *left,
    const CloneMCJ_NBTTagCompound *right)
{
    return SH_NBTValueEqual((const CloneMCJ_NBTBase *)left,
        (const CloneMCJ_NBTBase *)right);
}

static int SH_LoadInfoPath(const char *path, CloneMCJ_WorldInfo *info)
{
    CloneMCJ_NBTTagCompound *root;
    CloneMCJ_NBTTagCompound *data;
    int ok;
    root = CloneMCJ_CompressedStreamTools_ReadGzipFile(path);
    if (!root) return 0;
    data = CloneMCJ_NBTTagCompound_GetCompoundTag(root, "Data");
    ok = data ? CloneMCJ_WorldInfo_LoadFromNBT(info, (CloneMCJ_NBTBase *)data) : 0;
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)root);
    return ok;
}

int CloneMCJ_SaveHandler_LoadWorldInfo(CloneMCJ_SaveHandler *handler,
    CloneMCJ_WorldInfo *info)
{
    char currentPath[CLONEMC_J_PATH_MAX];
    char oldPath[CLONEMC_J_PATH_MAX];
    int currentExists;
    int oldExists;
    if (!handler || !info) return 0;
    if (!SH_Join(currentPath, handler->saveDirectory, "level.dat") ||
        !SH_Join(oldPath, handler->saveDirectory, "level.dat_old")) {
        SH_SetError(handler, "The level metadata path is too long");
        return 0;
    }
    currentExists = SH_Exists(currentPath);
    oldExists = SH_Exists(oldPath);
    if (currentExists && SH_LoadInfoPath(currentPath, info)) {
        SH_SetError(handler, "");
        return 1;
    }
    if (oldExists && SH_LoadInfoPath(oldPath, info)) {
        SH_SetError(handler, "");
        return 1;
    }
    if (currentExists || oldExists) {
        if (!CloneMCJ_CompressedStreamTools_IsAvailable())
            SH_SetError(handler, "level.dat needs a compatible 32-bit zlib1.dll or zlib.dll");
        else SH_SetError(handler,
            "level.dat and its backup could not be decoded as Java GZIP NBT");
    } else SH_SetError(handler, "");
    return 0;
}

int CloneMCJ_SaveHandler_SaveWorldInfo(CloneMCJ_SaveHandler *handler,
    const CloneMCJ_WorldInfo *info, const CloneMCJ_NBTTagCompound *playerTag)
{
    char newPath[CLONEMC_J_PATH_MAX];
    char oldPath[CLONEMC_J_PATH_MAX];
    char currentPath[CLONEMC_J_PATH_MAX];
    CloneMCJ_NBTTagCompound *root;
    CloneMCJ_NBTBase *data;
    CloneMCJ_WorldInfo verifiedInfo;
    int ok;
    if (!handler || !info) return 0;
    if (!CloneMCJ_SaveHandler_CheckSessionLock(handler)) return 0;
    if (!CloneMCJ_CompressedStreamTools_IsAvailable()) {
        SH_SetError(handler, "Cannot save level.dat: no compatible 32-bit zlib1.dll or zlib.dll was found");
        return 0;
    }
    if (!SH_Join(newPath, handler->saveDirectory, "level.dat_new") ||
        !SH_Join(oldPath, handler->saveDirectory, "level.dat_old") ||
        !SH_Join(currentPath, handler->saveDirectory, "level.dat")) {
        SH_SetError(handler, "The level metadata path is too long");
        return 0;
    }
    root = CloneMCJ_NBTTagCompound_Create();
    data = CloneMCJ_WorldInfo_CreateNBT(info, (const CloneMCJ_NBTBase *)playerTag);
    if (!root || !data) {
        CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)root);
        CloneMCJ_NBTBase_Free(data);
        SH_SetError(handler, "Out of memory while building level.dat NBT");
        return 0;
    }
    CloneMCJ_NBTTagCompound_SetTag(root, "Data", data);
    ok = CloneMCJ_CompressedStreamTools_WriteGzipFile(root, newPath);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)root);
    if (!ok) {
        remove(newPath);
        SH_SetErrorPath(handler, "Could not write compressed level.dat_new", newPath);
        return 0;
    }
    if (!SH_FlushPath(newPath)) {
        remove(newPath);
        SH_SetErrorPath(handler, "Could not close level.dat_new safely", newPath);
        return 0;
    }
    /* Validate the exact temporary file before touching either known-good
     * generation.  A short write, unavailable decompressor, or malformed NBT
     * must leave level.dat and level.dat_old untouched. */
    memset(&verifiedInfo,0,sizeof(verifiedInfo));
    if (!SH_LoadInfoPath(newPath,&verifiedInfo)) {
        CloneMCJ_WorldInfo_Destroy(&verifiedInfo);
        remove(newPath);
        SH_SetErrorPath(handler,"level.dat_new could not be decoded after writing",newPath);
        return 0;
    }
    if (verifiedInfo.randomSeed != info->randomSeed) {
        CloneMCJ_WorldInfo_Destroy(&verifiedInfo); remove(newPath);
        SH_SetErrorPath(handler,"level.dat_new changed RandomSeed during read-back",newPath);
        return 0;
    }
    if (verifiedInfo.worldTime != info->worldTime) {
        CloneMCJ_WorldInfo_Destroy(&verifiedInfo); remove(newPath);
        SH_SetErrorPath(handler,"level.dat_new changed Time during read-back",newPath);
        return 0;
    }
    if (verifiedInfo.spawnX != info->spawnX ||
        verifiedInfo.spawnY != info->spawnY ||
        verifiedInfo.spawnZ != info->spawnZ) {
        CloneMCJ_WorldInfo_Destroy(&verifiedInfo); remove(newPath);
        SH_SetErrorPath(handler,"level.dat_new changed spawn coordinates during read-back",newPath);
        return 0;
    }
    if (playerTag && !verifiedInfo.playerTag) {
        CloneMCJ_WorldInfo_Destroy(&verifiedInfo); remove(newPath);
        SH_SetErrorPath(handler,"level.dat_new lost the Player compound during read-back",newPath);
        return 0;
    }
    if (playerTag && !SH_NBTCompoundEqual(playerTag,
            (const CloneMCJ_NBTTagCompound *)verifiedInfo.playerTag)) {
        CloneMCJ_WorldInfo_Destroy(&verifiedInfo); remove(newPath);
        SH_SetErrorPath(handler,"level.dat_new changed Player NBT during read-back",newPath);
        return 0;
    }
    CloneMCJ_WorldInfo_Destroy(&verifiedInfo);
    remove(oldPath);
    if (SH_Exists(currentPath) && rename(currentPath, oldPath) != 0) {
        remove(newPath);
        SH_SetErrorPath(handler, "Could not rotate level.dat to its backup", currentPath);
        return 0;
    }
    if (rename(newPath, currentPath) != 0) {
        if (SH_Exists(oldPath)) (void)rename(oldPath, currentPath);
        remove(newPath);
        SH_SetErrorPath(handler, "Could not promote level.dat_new", currentPath);
        return 0;
    }
    (void)SH_FlushPath(currentPath);
    SH_SetError(handler, "");
    return 1;
}


int CloneMCJ_SaveHandler_VerifyWorldInfo(CloneMCJ_SaveHandler *handler,
    const CloneMCJ_WorldInfo *info,const CloneMCJ_NBTTagCompound *playerTag)
{
    CloneMCJ_WorldInfo loaded;
    char currentPath[CLONEMC_J_PATH_MAX];
    int ok;
    if(!handler||!info)return 0;
    memset(&loaded,0,sizeof(loaded));
    if(!SH_Join(currentPath,handler->saveDirectory,"level.dat")||
        !SH_LoadInfoPath(currentPath,&loaded)){
        SH_SetError(handler,"The current level.dat could not be decoded during verification");
        return 0;
    }
    ok=loaded.randomSeed==info->randomSeed&&
        loaded.spawnX==info->spawnX&&loaded.spawnY==info->spawnY&&
        loaded.spawnZ==info->spawnZ&&loaded.worldTime==info->worldTime&&
        loaded.dimension==info->dimension&&loaded.saveVersion==info->saveVersion&&
        loaded.raining==info->raining&&loaded.thundering==info->thundering&&
        loaded.rainTime==info->rainTime&&loaded.thunderTime==info->thunderTime&&
        strcmp(loaded.levelName,info->levelName)==0;
    if(ok&&playerTag){
        ok=loaded.playerTag&&SH_NBTCompoundEqual(playerTag,
            (const CloneMCJ_NBTTagCompound *)loaded.playerTag);
    }
    if(!ok)SH_SetError(handler,
        "level.dat verification did not match the current world/player snapshot");
    else SH_SetError(handler,"");
    CloneMCJ_WorldInfo_Destroy(&loaded);
    return ok;
}

CloneMCJ_McRegionChunkLoader *CloneMCJ_SaveHandler_GetChunkLoader(
    CloneMCJ_SaveHandler *handler, int dimension)
{
    char directory[CLONEMC_J_PATH_MAX];
    if (!handler) return 0;
    if (dimension == -1) {
        if (!SH_Join(directory, handler->saveDirectory, "DIM-1") ||
            !SH_MakeDirectory(directory)) {
            SH_SetError(handler, "Cannot create or open the DIM-1 directory");
            return 0;
        }
    } else {
        strncpy(directory,handler->saveDirectory,sizeof(directory)-1);
        directory[sizeof(directory)-1]='\0';
    }
    /* The provider, gameplay hooks, and entity/tile factories all retain this
     * loader pointer.  Reinitializing it for repeated same-dimension lookups
     * erased its hooks and world-time pointers, making later chunk saves omit
     * entities or use time zero.  Preserve the initialized object unless the
     * requested dimension actually changes its directory. */
    if(handler->chunkLoader.cache==&handler->regionCache&&
       strcmp(handler->chunkLoader.worldDir,directory)==0)
        return &handler->chunkLoader;
    CloneMCJ_McRegionChunkLoader_Initialize(&handler->chunkLoader,directory,
        &handler->regionCache);
    return &handler->chunkLoader;
}

int CloneMCJ_SaveHandler_FlushChunkData(CloneMCJ_SaveHandler *handler)
{
    if(!handler||!handler->initialized)return 0;
    if(!CloneMCJ_SaveHandler_CheckSessionLock(handler))return 0;
    /* The chunk writer has already flushed and read-back verified every
     * payload and region header.  Use a bounded buffered cache flush here;
     * device-level FlushFileBuffers is not allowed to hold the save GUI beyond
     * its absolute 25-second deadline. */
    if(!CloneMCJ_RegionFileCache_FlushAll(&handler->regionCache,0)){
        char detail[192];
        sprintf(detail,"Region flush failed for chunk %d,%d: %s (%s, system %d)",
            handler->regionCache.lastChunkX,handler->regionCache.lastChunkZ,
            CloneMCJ_RegionFile_ErrorText(handler->regionCache.lastError),
            handler->regionCache.lastPath[0]?handler->regionCache.lastPath:"unknown region",
            handler->regionCache.lastSystemError);
        SH_SetError(handler,detail);
        return 0;
    }
    CloneMCJ_RegionFileCache_CloseAll(&handler->regionCache);
    SH_SetError(handler,"");
    return 1;
}

const char *CloneMCJ_SaveHandler_GetLastError(const CloneMCJ_SaveHandler *handler)
{
    return handler ? handler->lastError : "";
}

void CloneMCJ_SaveHandler_Register(void) { }
const char *CloneMCJ_SaveHandler_JavaName(void) { return "net.minecraft.src.SaveHandler"; }
const char *CloneMCJ_SaveHandler_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_SaveHandler_JavaSourceHash32(void) { return 0xA64198C1UL; }

int CloneMCJ_SaveHandler_GetDataFile(const CloneMCJ_SaveHandler*h,const char*n,char*out,unsigned long cap){size_t need;if(!h||!n||!out||cap==0||!SH_SafeLeafName(n))return 0;need=strlen(h->dataDirectory)+strlen(n)+6UL;if(need>cap)return 0;strcpy(out,h->dataDirectory);strcat(out,"/");strcat(out,n);strcat(out,".dat");return 1;}
int CloneMCJ_SaveHandler_SavePlayerTag(CloneMCJ_SaveHandler*h,const char*n,const CloneMCJ_NBTTagCompound*t){char p[CLONEMC_J_PATH_MAX],tmp[CLONEMC_J_PATH_MAX];if(!h||!t||!SH_SafeLeafName(n)||!CloneMCJ_SaveHandler_CheckSessionLock(h))return 0;SH_MKDIR(h->playersDirectory);if(strlen(h->playersDirectory)+strlen(n)+6UL>=sizeof(p))return 0;strcpy(p,h->playersDirectory);strcat(p,"/");strcat(p,n);strcat(p,".dat");if(strlen(p)+5UL>=sizeof(tmp))return 0;strcpy(tmp,p);strcat(tmp,".tmp");if(!CloneMCJ_CompressedStreamTools_WriteGzipFile(t,tmp)||!SH_FlushPath(tmp)){remove(tmp);return 0;}{char bak[CLONEMC_J_PATH_MAX];if(strlen(p)+5UL>=sizeof(bak)){remove(tmp);return 0;}strcpy(bak,p);strcat(bak,".old");remove(bak);if(SH_Exists(p)&&rename(p,bak)!=0){remove(tmp);return 0;}if(rename(tmp,p)!=0){if(SH_Exists(bak))rename(bak,p);remove(tmp);return 0;}remove(bak);}return SH_FlushPath(p);}
CloneMCJ_NBTTagCompound *CloneMCJ_SaveHandler_LoadPlayerTag(CloneMCJ_SaveHandler*h,const char*n){char p[CLONEMC_J_PATH_MAX];if(!h||!SH_SafeLeafName(n))return 0;if(strlen(h->playersDirectory)+strlen(n)+6UL>=sizeof(p))return 0;strcpy(p,h->playersDirectory);strcat(p,"/");strcat(p,n);strcat(p,".dat");return CloneMCJ_CompressedStreamTools_ReadGzipFile(p);}


static void SH_SelfTestMessage(char *message, unsigned int capacity,
    const char *text)
{
    if (!message || capacity == 0U) return;
    strncpy(message, text ? text : "", capacity - 1U);
    message[capacity - 1U] = '\0';
}

static void SH_SelfTestCleanup(const char *root)
{
    char path[CLONEMC_J_PATH_MAX];
    if (!root || !*root) return;
#define SH_REMOVE_CHILD(suffix) do { \
    if (SH_Join(path, root, suffix)) remove(path); \
} while (0)
    SH_REMOVE_CHILD("World/region/r.0.0.mcr");
    SH_REMOVE_CHILD("World/level.dat_new");
    SH_REMOVE_CHILD("World/level.dat_old");
    SH_REMOVE_CHILD("World/level.dat");
    SH_REMOVE_CHILD("World/session.lock");
#undef SH_REMOVE_CHILD
    if (SH_Join(path, root, "World/region")) (void)SH_RMDIR(path);
    if (SH_Join(path, root, "World/players")) (void)SH_RMDIR(path);
    if (SH_Join(path, root, "World/data")) (void)SH_RMDIR(path);
    if (SH_Join(path, root, "World")) (void)SH_RMDIR(path);
    (void)SH_RMDIR(root);
}

int CloneMCJ_SaveHandler_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJ_SaveHandler handler;
    CloneMCJ_WorldInfo info;
    CloneMCJ_WorldInfo loadedInfo;
    CloneMCJ_McRegionChunkLoader *loader;
    CloneMCJ_Chunk sourceChunk;
    CloneMCJ_Chunk sourceChunk2;
    CloneMCJ_Chunk loadedChunk;
    CloneMCJ_Chunk loadedChunk2;
    CloneMCJ_NBTTagCompound *playerTag;
    CloneMCJ_NBTTagList *position;
    CloneMCJ_NBTTagList *rotation;
    CloneMCJ_NBTTagList *inventoryList;
    CloneMCJ_NBTTagCompound *inventoryEntry;
    CloneMCJ_NBTBase *positionTag;
    char root[96];
    char failureDetail[256];
    const char *stage;
    int ok;
    int repetition;
    int handlerReady;
    int sourceReady;
    int source2Ready;
    int loadedReady;
    int loaded2Ready;
    unsigned long nonce;
    playerTag = (CloneMCJ_NBTTagCompound *)0;
    position = rotation = inventoryList = (CloneMCJ_NBTTagList *)0;
    inventoryEntry = (CloneMCJ_NBTTagCompound *)0;
    positionTag = (CloneMCJ_NBTBase *)0;
    nonce = (unsigned long)time(0) ^ ((unsigned long)clock() << 1);
    sprintf(root, "v120_save_selftest_%lu", nonce);
    failureDetail[0] = '\0';
    stage = "save-handler initialization";
    SH_SelfTestCleanup(root);
    memset(&handler, 0, sizeof(handler));
    memset(&info, 0, sizeof(info));
    memset(&loadedInfo, 0, sizeof(loadedInfo));
    memset(&sourceChunk, 0, sizeof(sourceChunk));
    memset(&sourceChunk2, 0, sizeof(sourceChunk2));
    memset(&loadedChunk, 0, sizeof(loadedChunk));
    memset(&loadedChunk2, 0, sizeof(loadedChunk2));
    handlerReady = sourceReady = source2Ready = loadedReady = loaded2Ready = 0;
    ok = CloneMCJ_SaveHandler_Initialize(&handler, root, "World", 1);
    if (ok) handlerReady = 1;
    if (ok) {
        CloneMCJ_WorldInfo_Initialize(&info, (CloneMCJLong)0x12345678L,
            "V120 Save Round Trip");
        info.spawnX = 17; info.spawnY = 65; info.spawnZ = -9;
        info.worldTime = (CloneMCJLong)54321;
        info.raining = 1; info.rainTime = 777;
        playerTag = CloneMCJ_NBTTagCompound_Create();
        position = CloneMCJ_NBTTagList_Create();
        rotation = CloneMCJ_NBTTagList_Create();
        inventoryList = CloneMCJ_NBTTagList_Create();
        inventoryEntry = CloneMCJ_NBTTagCompound_Create();
        if (!playerTag || !position || !rotation || !inventoryList ||
            !inventoryEntry) ok = 0;
        if (ok) {
            ok = CloneMCJ_NBTTagList_Append(position,
                (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(321.25)) &&
                CloneMCJ_NBTTagList_Append(position,
                (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(72.0)) &&
                CloneMCJ_NBTTagList_Append(position,
                (CloneMCJ_NBTBase *)CloneMCJ_NBTTagDouble_Create(-144.75)) &&
                CloneMCJ_NBTTagList_Append(rotation,
                (CloneMCJ_NBTBase *)CloneMCJ_NBTTagFloat_Create(135.0F)) &&
                CloneMCJ_NBTTagList_Append(rotation,
                (CloneMCJ_NBTBase *)CloneMCJ_NBTTagFloat_Create(-20.0F));
        }
        if (ok) {
            CloneMCJ_NBTTagCompound_SetTag(playerTag,"Pos",
                (CloneMCJ_NBTBase *)position); position = (CloneMCJ_NBTTagList *)0;
            CloneMCJ_NBTTagCompound_SetTag(playerTag,"Rotation",
                (CloneMCJ_NBTBase *)rotation); rotation = (CloneMCJ_NBTTagList *)0;
            CloneMCJ_NBTTagCompound_SetInteger(playerTag,"Dimension",0);
            CloneMCJ_NBTTagCompound_SetShort(playerTag,"Health",17);
            CloneMCJ_NBTTagCompound_SetInteger(playerTag,"SelectedItemSlot",4);
            CloneMCJ_NBTTagCompound_SetByte(inventoryEntry,"Slot",4);
            CloneMCJ_NBTTagCompound_SetShort(inventoryEntry,"id",5);
            CloneMCJ_NBTTagCompound_SetByte(inventoryEntry,"Count",37);
            CloneMCJ_NBTTagCompound_SetShort(inventoryEntry,"Damage",2);
            ok = CloneMCJ_NBTTagList_Append(inventoryList,
                (CloneMCJ_NBTBase *)inventoryEntry);
            if (ok) inventoryEntry = (CloneMCJ_NBTTagCompound *)0;
            if (ok) {
                CloneMCJ_NBTTagCompound_SetTag(playerTag,"Inventory",
                    (CloneMCJ_NBTBase *)inventoryList);
                inventoryList = (CloneMCJ_NBTTagList *)0;
                stage = "transactional level.dat write and read-back";
                ok = CloneMCJ_SaveHandler_SaveWorldInfo(&handler,&info,playerTag);
            }
        }
    }
    if(ok){
        stage="read-only level.dat semantic verification";
        ok=CloneMCJ_SaveHandler_VerifyWorldInfo(&handler,&info,playerTag);
    }
    if(ok){
        /* Reproduce repeated autosave/pause/quit metadata transactions against
         * the same live Player tree.  This catches ownership, backup rotation,
         * and re-read failures that previously surfaced as a crash only after
         * several successful-looking saves. */
        stage="repeated level.dat transaction and backup rotation";
        for(repetition=0;repetition<32&&ok;++repetition){
            ok=CloneMCJ_SaveHandler_SaveWorldInfo(&handler,&info,playerTag)&&
                CloneMCJ_SaveHandler_VerifyWorldInfo(&handler,&info,playerTag);
        }
    }
    if (ok) {
        stage = "level.dat reload";
        ok = CloneMCJ_SaveHandler_LoadWorldInfo(&handler, &loadedInfo);
    }
    if (ok && (loadedInfo.randomSeed != info.randomSeed ||
        loadedInfo.spawnX != 17 || loadedInfo.spawnY != 65 ||
        loadedInfo.spawnZ != -9 || loadedInfo.worldTime != (CloneMCJLong)54321 ||
        strcmp(loadedInfo.levelName, "V120 Save Round Trip") != 0 ||
        !loadedInfo.raining || loadedInfo.rainTime != 777 ||
        !loadedInfo.playerTag ||
        !SH_NBTCompoundEqual(playerTag,
            (const CloneMCJ_NBTTagCompound *)loadedInfo.playerTag))) ok = 0;
    if (ok) {
        position = CloneMCJ_NBTTagCompound_GetTagList(
            (const CloneMCJ_NBTTagCompound *)loadedInfo.playerTag,"Pos");
        positionTag = CloneMCJ_NBTTagList_Get(position,0);
        if (CloneMCJ_NBTTagList_Count(position) != 3 || !positionTag ||
            positionTag->type != CLONEMC_J_NBT_TAG_DOUBLE ||
            positionTag->value.doubleValue != 321.25 ||
            CloneMCJ_NBTTagCompound_GetInteger(
                (const CloneMCJ_NBTTagCompound *)loadedInfo.playerTag,
                "SelectedItemSlot") != 4) {
            stage = "player position/inventory NBT verification";
            ok = 0;
        }
        position = (CloneMCJ_NBTTagList *)0;
        positionTag = (CloneMCJ_NBTBase *)0;
    }
    if (ok) stage = "McRegion loader acquisition";
    loader = ok ? CloneMCJ_SaveHandler_GetChunkLoader(&handler, 0) : 0;
    if (ok && !loader) ok = 0;
    if (ok) {
        stage = "first chunk construction and save";
        CloneMCJ_Chunk_Initialize(&sourceChunk, 0, 0);
        sourceReady = 1;
        sourceChunk.isTerrainPopulated = 1;
        if (!CloneMCJ_Chunk_SetBlockIDWithMetadata(&sourceChunk, 3, 64, 5,
                50, 1, (CloneMCJ_BlockLightOpacityProc)0, (void *)0)) ok = 0;
        if (ok && !CloneMCJ_Chunk_SetBlockIDWithMetadata(&sourceChunk, 4, 64, 5,
                5, 2, (CloneMCJ_BlockLightOpacityProc)0, (void *)0)) ok = 0;
        if (ok) ok = CloneMCJ_McRegionChunkLoader_Save(loader, &sourceChunk,
            (CloneMCJLong)54321);
        /* Keep the region open and force a second append.  V117 marked newly
         * appended sectors free, allowing this write to overwrite chunk 0,0. */
        if(ok){
            CloneMCJ_Chunk_Initialize(&sourceChunk2,1,0);source2Ready=1;
            sourceChunk2.isTerrainPopulated=1;
            if(!CloneMCJ_Chunk_SetBlockIDWithMetadata(&sourceChunk2,7,70,8,
                35,14,(CloneMCJ_BlockLightOpacityProc)0,(void *)0))ok=0;
        }
        if(ok){
            stage = "second same-session McRegion append";
            ok=CloneMCJ_McRegionChunkLoader_Save(loader,&sourceChunk2,
                (CloneMCJLong)54322);
        }
        CloneMCJ_RegionFileCache_CloseAll(&handler.regionCache);
    }
    if (ok) {
        stage = "first chunk reload";
        CloneMCJ_Chunk_Initialize(&loadedChunk, 0, 0);
        loadedReady = 1;
        ok = CloneMCJ_McRegionChunkLoader_Load(loader, &loadedChunk, 0, 0);
    }
    if (ok && (CloneMCJ_Chunk_GetBlockID(&loadedChunk, 3, 64, 5) != 50 ||
        CloneMCJ_Chunk_GetBlockMetadata(&loadedChunk, 3, 64, 5) != 1 ||
        CloneMCJ_Chunk_GetBlockID(&loadedChunk, 4, 64, 5) != 5 ||
        CloneMCJ_Chunk_GetBlockMetadata(&loadedChunk, 4, 64, 5) != 2 ||
        !loadedChunk.isTerrainPopulated)) ok = 0;
    if(ok){stage = "second chunk reload";
        CloneMCJ_Chunk_Initialize(&loadedChunk2,1,0);loaded2Ready=1;
        ok=CloneMCJ_McRegionChunkLoader_Load(loader,&loadedChunk2,1,0)==1;}
    if(ok&&(CloneMCJ_Chunk_GetBlockID(&loadedChunk2,7,70,8)!=35||
        CloneMCJ_Chunk_GetBlockMetadata(&loadedChunk2,7,70,8)!=14||
        !loadedChunk2.isTerrainPopulated))ok=0;
    if (sourceReady) CloneMCJ_Chunk_Destroy(&sourceChunk);
    if (source2Ready) CloneMCJ_Chunk_Destroy(&sourceChunk2);
    if (loadedReady) CloneMCJ_Chunk_Destroy(&loadedChunk);
    if (loaded2Ready) CloneMCJ_Chunk_Destroy(&loadedChunk2);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)position);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)rotation);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)inventoryList);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)inventoryEntry);
    CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase *)playerTag);
    CloneMCJ_WorldInfo_Destroy(&info);
    CloneMCJ_WorldInfo_Destroy(&loadedInfo);
    if (!ok) {
        const char *handlerError;
        handlerError = handlerReady ? CloneMCJ_SaveHandler_GetLastError(&handler) : "";
        if (handlerError && *handlerError)
            sprintf(failureDetail, "V120 save self-test failed during %s: %.150s",
                stage, handlerError);
        else
            sprintf(failureDetail, "V120 save self-test failed during %s", stage);
    }
    if (handlerReady) CloneMCJ_SaveHandler_Destroy(&handler);
    SH_SelfTestCleanup(root);
    SH_SelfTestMessage(message, messageCapacity, ok ?
        "V122 repeated transactional level.dat, player NBT, and same-session multi-chunk McRegion tests passed" :
        failureDetail);
    return ok;
}
