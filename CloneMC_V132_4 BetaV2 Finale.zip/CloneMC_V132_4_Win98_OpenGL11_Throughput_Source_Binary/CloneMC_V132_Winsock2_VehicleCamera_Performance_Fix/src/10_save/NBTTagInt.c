/* Java source: NBTTagInt.java; Source SHA-256: f8b4d19fd57a924ea68fe0ea17682ff42fc5cecb27140acc4e92e330c2ce7389; Java lines: 47. */
/* Direct C89 port of NBTTagInt.java. */
#include "clonemc_java_port_10_save.h"
CloneMCJ_NBTTagInt *CloneMCJ_NBTTagInt_Create(CloneMCJInt value){CloneMCJ_NBTBase *tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_INT);if(tag){tag->value.intValue=value;}return (CloneMCJ_NBTTagInt*)tag;}

void CloneMCJ_NBTTagInt_Register(void) { }
const char *CloneMCJ_NBTTagInt_JavaName(void) { return "net.minecraft.src.NBTTagInt"; }
const char *CloneMCJ_NBTTagInt_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagInt_JavaSourceHash32(void) { return 0xF8B4D19FUL; }
