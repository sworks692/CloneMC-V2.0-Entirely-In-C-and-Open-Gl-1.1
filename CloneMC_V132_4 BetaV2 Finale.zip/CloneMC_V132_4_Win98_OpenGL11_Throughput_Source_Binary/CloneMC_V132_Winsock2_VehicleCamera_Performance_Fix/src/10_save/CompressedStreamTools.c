/* Java source: CompressedStreamTools.java; Source SHA-256: c24a8e873e31d89f2e6990f8ebacd68086bbb421a1e7a6eb892678b5d075bc0e; Java lines: 68. */
/* Direct C89 port of CompressedStreamTools.java using official zlib APIs. */
#include "clonemc_java_port_10_save.h"
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#if defined(_WIN32)
#include <windows.h>
#include <stdio.h>

#ifndef LOAD_WITH_ALTERED_SEARCH_PATH
#define LOAD_WITH_ALTERED_SEARCH_PATH 0x00000008UL
#endif

/*
 * The supplied legacy zlib.dll exports undecorated Win32 stdcall entry points,
 * while normal zlib1.dll builds export cdecl entry points.  Calling one through
 * the other convention corrupts ESP and used to crash the world list/save GUI.
 * Keep raw addresses and dispatch through a convention-correct wrapper.
 */
typedef void *CloneMCJ_gzFile;
typedef void *CloneMCJ_voidpf;
typedef unsigned char CloneMCJ_Bytef;
typedef unsigned int CloneMCJ_uInt;
typedef unsigned long CloneMCJ_uLong;
typedef CloneMCJ_voidpf (__cdecl *CloneMCJ_alloc_func)(CloneMCJ_voidpf,CloneMCJ_uInt,CloneMCJ_uInt);
typedef void (__cdecl *CloneMCJ_free_func)(CloneMCJ_voidpf,CloneMCJ_voidpf);
typedef struct CloneMCJ_z_stream_s {
    CloneMCJ_Bytef *next_in; CloneMCJ_uInt avail_in; CloneMCJ_uLong total_in;
    CloneMCJ_Bytef *next_out; CloneMCJ_uInt avail_out; CloneMCJ_uLong total_out;
    char *msg; void *state; CloneMCJ_alloc_func zalloc; CloneMCJ_free_func zfree;
    CloneMCJ_voidpf opaque; int data_type; CloneMCJ_uLong adler; CloneMCJ_uLong reserved;
} CloneMCJ_z_stream;

typedef CloneMCJ_gzFile (__cdecl *CST_gzopen_cdecl)(const char *,const char *);
typedef int (__cdecl *CST_gzread_cdecl)(CloneMCJ_gzFile,void *,unsigned int);
typedef int (__cdecl *CST_gzwrite_cdecl)(CloneMCJ_gzFile,const void *,unsigned int);
typedef int (__cdecl *CST_gzclose_cdecl)(CloneMCJ_gzFile);
typedef unsigned long (__cdecl *CST_compressBound_cdecl)(unsigned long);
typedef int (__cdecl *CST_compress2_cdecl)(unsigned char *,unsigned long *,const unsigned char *,unsigned long,int);
typedef const char *(__cdecl *CST_zlibVersion_cdecl)(void);
typedef int (__cdecl *CST_inflateInit2_cdecl)(CloneMCJ_z_stream *,int,const char *,int);
typedef int (__cdecl *CST_inflate_cdecl)(CloneMCJ_z_stream *,int);
typedef int (__cdecl *CST_inflateEnd_cdecl)(CloneMCJ_z_stream *);

typedef CloneMCJ_gzFile (__stdcall *CST_gzopen_stdcall)(const char *,const char *);
typedef int (__stdcall *CST_gzread_stdcall)(CloneMCJ_gzFile,void *,unsigned int);
typedef int (__stdcall *CST_gzwrite_stdcall)(CloneMCJ_gzFile,const void *,unsigned int);
typedef int (__stdcall *CST_gzclose_stdcall)(CloneMCJ_gzFile);
typedef unsigned long (__stdcall *CST_compressBound_stdcall)(unsigned long);
typedef int (__stdcall *CST_compress2_stdcall)(unsigned char *,unsigned long *,const unsigned char *,unsigned long,int);
typedef const char *(__stdcall *CST_zlibVersion_stdcall)(void);
typedef int (__stdcall *CST_inflateInit2_stdcall)(CloneMCJ_z_stream *,int,const char *,int);
typedef int (__stdcall *CST_inflate_stdcall)(CloneMCJ_z_stream *,int);
typedef int (__stdcall *CST_inflateEnd_stdcall)(CloneMCJ_z_stream *);

static HMODULE zlibModule;
static FARPROC p_gzopen,p_gzread,p_gzwrite,p_gzclose,p_compressBound,p_compress2;
static FARPROC p_zlibVersion,p_inflateInit2,p_inflate,p_inflateEnd;
static int zlibLoadState;
static int zlibUsesStdcall;
static char zlibLoadedPath[MAX_PATH];

static void CST_Log(const char *message)
{
    FILE *file;
    if(!message)return;
    file=fopen("clonemc_platform.log","at");
    if(file){fputs(message,file);fputs("\n",file);fclose(file);}
    OutputDebugStringA(message);OutputDebugStringA("\r\n");
}

static void CST_ClearZlibBindings(void)
{
    p_gzopen=0;p_gzread=0;p_gzwrite=0;p_gzclose=0;p_compressBound=0;
    p_compress2=0;p_zlibVersion=0;p_inflateInit2=0;p_inflate=0;p_inflateEnd=0;
    zlibUsesStdcall=0;zlibLoadedPath[0]='\0';
}

static int CST_BindZlib(HMODULE module)
{
    CST_ClearZlibBindings();
    if(!module)return 0;
    p_gzopen=GetProcAddress(module,"gzopen");
    p_gzread=GetProcAddress(module,"gzread");
    p_gzwrite=GetProcAddress(module,"gzwrite");
    p_gzclose=GetProcAddress(module,"gzclose");
    p_compressBound=GetProcAddress(module,"compressBound");
    p_compress2=GetProcAddress(module,"compress2");
    p_zlibVersion=GetProcAddress(module,"zlibVersion");
    p_inflateInit2=GetProcAddress(module,"inflateInit2_");
    p_inflate=GetProcAddress(module,"inflate");
    p_inflateEnd=GetProcAddress(module,"inflateEnd");
    return p_gzopen&&p_gzread&&p_gzwrite&&p_gzclose&&p_compress2&&
        p_zlibVersion&&p_inflateInit2&&p_inflate&&p_inflateEnd;
}

static int CST_IsReadableCodePointer(const unsigned char *address,unsigned long *bytesOut)
{
    MEMORY_BASIC_INFORMATION info;
    unsigned long available;
    if(bytesOut)*bytesOut=0;
    if(!address||VirtualQuery((LPCVOID)address,&info,sizeof(info))!=sizeof(info))return 0;
    if(info.State!=MEM_COMMIT||(info.Protect&PAGE_GUARD)||
       (info.Protect&(PAGE_NOACCESS|PAGE_EXECUTE))!=0)return 0;
    available=(unsigned long)(((const unsigned char*)info.BaseAddress+info.RegionSize)-address);
    if(bytesOut)*bytesOut=available;
    return 1;
}

/* Return 1 for stdcall, 0 for cdecl, -1 if the epilogue cannot be identified. */
static int CST_FindCallingConvention(FARPROC procedure,unsigned int stackBytes)
{
    const unsigned char *code;
    unsigned long available,limit,index;
    code=(const unsigned char*)procedure;
    if(!CST_IsReadableCodePointer(code,&available))return -1;
    limit=available<768UL?available:768UL;
    for(index=0;index<limit;++index){
        if(code[index]==0xC2U&&index+2UL<limit){
            unsigned int popped=(unsigned int)code[index+1UL]|
                ((unsigned int)code[index+2UL]<<8);
            if(popped==stackBytes)return 1;
        }
        if(code[index]==0xC3U)return 0;
    }
    return -1;
}

static int CST_DetectStdcall(void)
{
    int stdcallVotes,cdeclVotes,result;
    stdcallVotes=0;cdeclVotes=0;
#define CST_VOTE(proc,bytes) do { result=CST_FindCallingConvention((proc),(bytes)); \
    if(result>0)++stdcallVotes; else if(result==0)++cdeclVotes; } while(0)
    CST_VOTE(p_gzopen,8U);CST_VOTE(p_gzread,12U);CST_VOTE(p_gzwrite,12U);
    CST_VOTE(p_gzclose,4U);CST_VOTE(p_compress2,20U);
    CST_VOTE(p_inflateInit2,16U);CST_VOTE(p_inflate,8U);CST_VOTE(p_inflateEnd,4U);
#undef CST_VOTE
    if(stdcallVotes>=2&&stdcallVotes>cdeclVotes)return 1;
    if(cdeclVotes>=2&&cdeclVotes>stdcallVotes)return 0;
    return -1;
}

static int CST_IsI386Dll(const char *path)
{
    FILE *file;
    IMAGE_DOS_HEADER dosHeader;
    DWORD signature;
    IMAGE_FILE_HEADER fileHeader;
    WORD optionalMagic;
    int valid;
    valid=0;
    file=fopen(path,"rb");
    if(!file)return 0;
    if(fread(&dosHeader,1,sizeof(dosHeader),file)!=sizeof(dosHeader) ||
       dosHeader.e_magic!=IMAGE_DOS_SIGNATURE || dosHeader.e_lfanew<=0)goto done;
    if(fseek(file,dosHeader.e_lfanew,SEEK_SET)!=0)goto done;
    if(fread(&signature,1,sizeof(signature),file)!=sizeof(signature) ||
       signature!=IMAGE_NT_SIGNATURE)goto done;
    if(fread(&fileHeader,1,sizeof(fileHeader),file)!=sizeof(fileHeader))goto done;
    if(fread(&optionalMagic,1,sizeof(optionalMagic),file)!=sizeof(optionalMagic))goto done;
    if(fileHeader.Machine==IMAGE_FILE_MACHINE_I386 &&
       (fileHeader.Characteristics&IMAGE_FILE_DLL)!=0 &&
       optionalMagic==IMAGE_NT_OPTIONAL_HDR32_MAGIC)valid=1;
done:
    fclose(file);return valid;
}

static int CST_IsFile(const char *path)
{
    DWORD attributes;
    if(!path||!*path)return 0;
    attributes=GetFileAttributesA(path);
    return attributes!=0xFFFFFFFFUL&&(attributes&FILE_ATTRIBUTE_DIRECTORY)==0;
}

static int CST_IsDirectory(const char *path)
{
    DWORD attributes;
    if(!path||!*path)return 0;
    attributes=GetFileAttributesA(path);
    return attributes!=0xFFFFFFFFUL&&(attributes&FILE_ATTRIBUTE_DIRECTORY)!=0;
}

static int CST_JoinPath(char *output,const char *directory,const char *name)
{
    unsigned long length;
    if(!output||!directory||!name)return 0;
    length=(unsigned long)strlen(directory);
    if(length+(length&&directory[length-1]!='\\'&&directory[length-1]!='/'?1UL:0UL)+
       (unsigned long)strlen(name)+1UL>MAX_PATH)return 0;
    strcpy(output,directory);
    if(length&&directory[length-1]!='\\'&&directory[length-1]!='/')strcat(output,"\\");
    strcat(output,name);return 1;
}

static int CST_GetModuleDirectory(char *directory)
{
    DWORD length;
    char *slash;
    length=GetModuleFileNameA((HMODULE)0,directory,MAX_PATH);
    if(length==0||length>=MAX_PATH)return 0;
    slash=strrchr(directory,'\\');
    if(!slash)slash=strrchr(directory,'/');
    if(!slash)return 0;
    *slash='\0';return 1;
}

static CloneMCJ_gzFile CST_gzopen(const char *path,const char *mode)
{
    if(zlibUsesStdcall)return ((CST_gzopen_stdcall)p_gzopen)(path,mode);
    return ((CST_gzopen_cdecl)p_gzopen)(path,mode);
}
static int CST_gzread(CloneMCJ_gzFile file,void *buffer,unsigned int length)
{
    if(zlibUsesStdcall)return ((CST_gzread_stdcall)p_gzread)(file,buffer,length);
    return ((CST_gzread_cdecl)p_gzread)(file,buffer,length);
}
static int CST_gzwrite(CloneMCJ_gzFile file,const void *buffer,unsigned int length)
{
    if(zlibUsesStdcall)return ((CST_gzwrite_stdcall)p_gzwrite)(file,buffer,length);
    return ((CST_gzwrite_cdecl)p_gzwrite)(file,buffer,length);
}
static int CST_gzclose(CloneMCJ_gzFile file)
{
    if(zlibUsesStdcall)return ((CST_gzclose_stdcall)p_gzclose)(file);
    return ((CST_gzclose_cdecl)p_gzclose)(file);
}
static unsigned long CST_compressBound(unsigned long length)
{
    if(zlibUsesStdcall)return ((CST_compressBound_stdcall)p_compressBound)(length);
    return ((CST_compressBound_cdecl)p_compressBound)(length);
}
static int CST_compress2(unsigned char *out,unsigned long *outLength,
    const unsigned char *in,unsigned long inLength,int level)
{
    if(zlibUsesStdcall)return ((CST_compress2_stdcall)p_compress2)(out,outLength,in,inLength,level);
    return ((CST_compress2_cdecl)p_compress2)(out,outLength,in,inLength,level);
}
static const char *CST_zlibVersion(void)
{
    if(zlibUsesStdcall)return ((CST_zlibVersion_stdcall)p_zlibVersion)();
    return ((CST_zlibVersion_cdecl)p_zlibVersion)();
}
static int CST_inflateInit2(CloneMCJ_z_stream *stream,int bits,const char *version,int size)
{
    if(zlibUsesStdcall)return ((CST_inflateInit2_stdcall)p_inflateInit2)(stream,bits,version,size);
    return ((CST_inflateInit2_cdecl)p_inflateInit2)(stream,bits,version,size);
}
static int CST_inflate(CloneMCJ_z_stream *stream,int flush)
{
    if(zlibUsesStdcall)return ((CST_inflate_stdcall)p_inflate)(stream,flush);
    return ((CST_inflate_cdecl)p_inflate)(stream,flush);
}
static int CST_inflateEnd(CloneMCJ_z_stream *stream)
{
    if(zlibUsesStdcall)return ((CST_inflateEnd_stdcall)p_inflateEnd)(stream);
    return ((CST_inflateEnd_cdecl)p_inflateEnd)(stream);
}

static int CST_TryCandidate(const char *candidate)
{
    char fullPath[MAX_PATH];
    char line[MAX_PATH+192];
    DWORD length;
    HMODULE module;
    int convention;
    const char *fileName;
    if(!CST_IsFile(candidate))return 0;
    length=GetFullPathNameA(candidate,MAX_PATH,fullPath,0);
    if(length==0||length>=MAX_PATH)return 0;
    if(!CST_IsI386Dll(fullPath)){
        sprintf(line,"ZLIB: rejected non-32-bit or invalid DLL: %s",fullPath);CST_Log(line);return 0;
    }
    module=LoadLibraryExA(fullPath,(HANDLE)0,LOAD_WITH_ALTERED_SEARCH_PATH);
    if(!module){sprintf(line,"ZLIB: LoadLibraryEx failed for %s (error %lu)",
        fullPath,(unsigned long)GetLastError());CST_Log(line);return 0;}
    if(!CST_BindZlib(module)){
        sprintf(line,"ZLIB: required exports are missing in %s",fullPath);CST_Log(line);
        FreeLibrary(module);CST_ClearZlibBindings();return 0;
    }
    convention=CST_DetectStdcall();
    fileName=strrchr(fullPath,'\\');if(!fileName)fileName=fullPath;else ++fileName;
    if(convention<0){
        /* Standard zlib1.dll is cdecl; the supplied historical zlib.dll is stdcall. */
        convention=lstrcmpiA(fileName,"zlib1.dll")==0?0:1;
        sprintf(line,"ZLIB: epilogue detection was inconclusive; using %s for %s",
            convention?"stdcall":"cdecl",fullPath);CST_Log(line);
    }
    zlibUsesStdcall=convention?1:0;
    zlibModule=module;strncpy(zlibLoadedPath,fullPath,MAX_PATH-1);zlibLoadedPath[MAX_PATH-1]='\0';
    sprintf(line,"ZLIB: loaded %s (%s, version %s)",zlibLoadedPath,
        zlibUsesStdcall?"stdcall":"cdecl",CST_zlibVersion());CST_Log(line);
    return 1;
}

static int CST_TryDirectory(const char *directory)
{
    char path[MAX_PATH];
    if(!directory||!*directory)return 0;
    if(CST_JoinPath(path,directory,"zlib1.dll")&&CST_TryCandidate(path))return 1;
    if(CST_JoinPath(path,directory,"zlib.dll")&&CST_TryCandidate(path))return 1;
    if(CST_JoinPath(path,directory,"dlls\\zlib1.dll")&&CST_TryCandidate(path))return 1;
    if(CST_JoinPath(path,directory,"dlls\\zlib.dll")&&CST_TryCandidate(path))return 1;
    if(CST_JoinPath(path,directory,"lib\\zlib1.dll")&&CST_TryCandidate(path))return 1;
    if(CST_JoinPath(path,directory,"lib\\zlib.dll")&&CST_TryCandidate(path))return 1;
    return 0;
}

static int CST_LoadZlib(void)
{
    char environment[MAX_PATH];
    char moduleDirectory[MAX_PATH];
    char currentDirectory[MAX_PATH];
    DWORD length;
    if(zlibLoadState!=0)return zlibLoadState>0;
    length=GetEnvironmentVariableA("CLONEMC_ZLIB",environment,MAX_PATH);
    if(length>0&&length<MAX_PATH){
        if((CST_IsFile(environment)&&CST_TryCandidate(environment))||
           (CST_IsDirectory(environment)&&CST_TryDirectory(environment))){zlibLoadState=1;return 1;}
    }
    if(CST_GetModuleDirectory(moduleDirectory)&&CST_TryDirectory(moduleDirectory)){
        zlibLoadState=1;return 1;
    }
    length=GetCurrentDirectoryA(MAX_PATH,currentDirectory);
    if(length>0&&length<MAX_PATH&&CST_TryDirectory(currentDirectory)){
        zlibLoadState=1;return 1;
    }
    zlibModule=0;CST_ClearZlibBindings();zlibLoadState=-1;
    CST_Log("ZLIB: no compatible 32-bit zlib1.dll or zlib.dll was found");
    return 0;
}

static unsigned long CST_CompressBound(unsigned long sourceLength)
{
    unsigned long extra;
    if(p_compressBound)return CST_compressBound(sourceLength);
    extra=sourceLength/100UL+128UL;
    if(sourceLength>ULONG_MAX-extra)return 0;
    return sourceLength+extra;
}
#else
#include <zlib.h>
static int CST_LoadZlib(void){return 1;}
#endif
int CloneMCJ_CompressedStreamTools_IsAvailable(void){return CST_LoadZlib();}
int CloneMCJ_CompressedStreamTools_WriteCompoundToMemory(const CloneMCJ_NBTTagCompound*c,unsigned char**d,unsigned long*n){CloneMCJ_ByteBuffer b;if(d)*d=0;if(n)*n=0;if(!c||!d||!n)return 0;CloneMCJ_ByteBuffer_InitWrite(&b,4096);if(!CloneMCJ_NBTBase_WriteTag((const CloneMCJ_NBTBase*)c,&b)||b.error){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}*d=b.data;*n=b.size;b.ownsData=0;CloneMCJ_ByteBuffer_Destroy(&b);return 1;}
CloneMCJ_NBTTagCompound *CloneMCJ_CompressedStreamTools_ReadCompoundFromMemory(const unsigned char*d,unsigned long n){CloneMCJ_ByteBuffer b;CloneMCJ_NBTBase*t;if(!d)return 0;CloneMCJ_ByteBuffer_InitRead(&b,d,n);t=CloneMCJ_NBTBase_ReadTag(&b);if(!t||b.error||t->type!=10){CloneMCJ_NBTBase_Free(t);return 0;}return (CloneMCJ_NBTTagCompound*)t;}
int CloneMCJ_CompressedStreamTools_WriteGzipFile(const CloneMCJ_NBTTagCompound*c,const char*path){unsigned char*d;unsigned long n,off;int wrote;if(!CST_LoadZlib()||!CloneMCJ_CompressedStreamTools_WriteCompoundToMemory(c,&d,&n))return 0;
#if defined(_WIN32)
{void *f;f=CST_gzopen(path,"wb9");if(!f){free(d);return 0;}off=0;while(off<n){unsigned int part=(unsigned int)((n-off)>1048576UL?1048576UL:(n-off));wrote=CST_gzwrite(f,d+off,part);if(wrote!=(int)part){CST_gzclose(f);free(d);return 0;}off+=(unsigned long)part;}wrote=CST_gzclose(f)==0;}
#else
{gzFile gz=gzopen(path,"wb9");if(!gz){free(d);return 0;}off=0;while(off<n){unsigned int part=(unsigned int)((n-off)>1048576UL?1048576UL:(n-off));wrote=gzwrite(gz,d+off,part);if(wrote!=(int)part){gzclose(gz);free(d);return 0;}off+=part;}wrote=gzclose(gz)==Z_OK;}
#endif
free(d);return wrote;}
CloneMCJ_NBTTagCompound *CloneMCJ_CompressedStreamTools_ReadGzipFile(const char*path){CloneMCJ_ByteBuffer b;unsigned char temp[8192];int got;CloneMCJ_NBTTagCompound*c;if(!CST_LoadZlib())return 0;CloneMCJ_ByteBuffer_InitWrite(&b,32768);
#if defined(_WIN32)
{void *f;f=CST_gzopen(path,"rb");if(!f){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}while((got=CST_gzread(f,temp,sizeof(temp)))>0){if(!CloneMCJ_ByteBuffer_Write(&b,temp,(unsigned long)got))break;}CST_gzclose(f);}
#else
{gzFile gz=gzopen(path,"rb");if(!gz){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}while((got=gzread(gz,temp,sizeof(temp)))>0){if(!CloneMCJ_ByteBuffer_Write(&b,temp,(unsigned long)got))break;}gzclose(gz);}
#endif
if(got<0||b.error){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}c=CloneMCJ_CompressedStreamTools_ReadCompoundFromMemory(b.data,b.size);CloneMCJ_ByteBuffer_Destroy(&b);return c;}
int CloneMCJ_CompressedStreamTools_DeflateZlib(const unsigned char*in,unsigned long inN,unsigned char**out,unsigned long*outN){unsigned long cap;int rc;if(out)*out=0;if(outN)*outN=0;if(!in||!out||!outN||!CST_LoadZlib())return 0;
#if defined(_WIN32)
cap=CST_CompressBound(inN);if(!cap)return 0;*out=(unsigned char*)malloc(cap);if(!*out)return 0;rc=CST_compress2(*out,&cap,in,inN,6);
#else
cap=compressBound(inN);*out=(unsigned char*)malloc(cap);if(!*out)return 0;rc=compress2(*out,&cap,in,inN,6);
#endif
if(rc!=0){free(*out);*out=0;return 0;}*outN=cap;return 1;}
int CloneMCJ_CompressedStreamTools_Inflate(const unsigned char*in,unsigned long inN,int gzip,unsigned char**out,unsigned long*outN){unsigned long cap,initialCapacity;int rc,done;CloneMCJ_ByteBuffer b;unsigned char temp[16384];if(out)*out=0;if(outN)*outN=0;if(!in||!out||!outN||!CST_LoadZlib())return 0;initialCapacity=inN>43690UL?131072UL:inN*3UL;if(initialCapacity<4096UL)initialCapacity=4096UL;CloneMCJ_ByteBuffer_InitWrite(&b,initialCapacity);
#if defined(_WIN32)
{CloneMCJ_z_stream z;int windowBits;memset(&z,0,sizeof(z));z.next_in=(CloneMCJ_Bytef*)in;z.avail_in=(CloneMCJ_uInt)inN;windowBits=gzip>0?31:(gzip<0?-15:15);rc=CST_inflateInit2(&z,windowBits,CST_zlibVersion(),sizeof(z));if(rc!=0){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}done=0;while(!done){z.next_out=temp;z.avail_out=sizeof(temp);rc=CST_inflate(&z,0);cap=sizeof(temp)-z.avail_out;if(cap&&!CloneMCJ_ByteBuffer_Write(&b,temp,cap)){rc=-1;break;}if(rc==1)done=1;else if(rc!=0)break;}CST_inflateEnd(&z);if(!done){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}}
#else
{z_stream z;int windowBits;memset(&z,0,sizeof(z));z.next_in=(Bytef*)in;z.avail_in=(uInt)inN;windowBits=gzip>0?31:(gzip<0?-15:15);rc=inflateInit2(&z,windowBits);if(rc!=Z_OK){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}done=0;while(!done){z.next_out=temp;z.avail_out=sizeof(temp);rc=inflate(&z,Z_NO_FLUSH);cap=sizeof(temp)-z.avail_out;if(cap&&!CloneMCJ_ByteBuffer_Write(&b,temp,cap)){rc=Z_MEM_ERROR;break;}if(rc==Z_STREAM_END)done=1;else if(rc!=Z_OK)break;}inflateEnd(&z);if(!done){CloneMCJ_ByteBuffer_Destroy(&b);return 0;}}
#endif
*out=b.data;*outN=b.size;b.ownsData=0;CloneMCJ_ByteBuffer_Destroy(&b);return 1;}

void CloneMCJ_CompressedStreamTools_Register(void) { }
const char *CloneMCJ_CompressedStreamTools_JavaName(void) { return "net.minecraft.src.CompressedStreamTools"; }
const char *CloneMCJ_CompressedStreamTools_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_CompressedStreamTools_JavaSourceHash32(void) { return 0xC24A8E87UL; }
