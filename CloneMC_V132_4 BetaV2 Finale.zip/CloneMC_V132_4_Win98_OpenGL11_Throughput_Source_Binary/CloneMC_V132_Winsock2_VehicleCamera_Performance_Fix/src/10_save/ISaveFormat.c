/* Java source: ISaveFormat.java; Source SHA-256: cbe829095a2aa61aa3392c2b6e3c3750fd022037525064d4730b9fcdcaab0316; Java lines: 32. */
/* Direct C89 adapter for ISaveFormat.java. */
#include "clonemc_java_port_10_save.h"
#include <string.h>
void CloneMCJ_ISaveFormat_Initialize(CloneMCJ_ISaveFormat*f,const char*b){if(!f)return;memset(f,0,sizeof(*f));if(b)strncpy(f->baseDirectory,b,sizeof(f->baseDirectory)-1);f->loadWorldInfo=CloneMCJ_SaveFormatOld_LoadWorldInfo;f->renameWorld=CloneMCJ_SaveFormatOld_RenameWorld;}
void CloneMCJ_ISaveFormat_Register(void){}
const char *CloneMCJ_ISaveFormat_JavaName(void){return "net.minecraft.src.ISaveFormat";}
const char *CloneMCJ_ISaveFormat_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_ISaveFormat_JavaSourceHash32(void){return 0xCBE82909UL;}
