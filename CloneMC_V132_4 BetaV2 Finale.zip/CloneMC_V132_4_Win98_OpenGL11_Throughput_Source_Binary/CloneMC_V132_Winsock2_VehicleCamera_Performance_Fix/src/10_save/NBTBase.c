/* Java source: NBTBase.java; Source SHA-256: de43e38d72bcdd1cec7a8935446a8686f41e979514c955fd77b92685593c71d1; Java lines: 159. */
/* Direct C89 port of NBTBase.java plus shared binary stream helpers. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
#include <limits.h>

static char *CloneMCJ_NBT_StrDup(const char *text)
{
    unsigned long length;
    char *copy;
    if (!text) { text = ""; }
    length = (unsigned long)strlen(text);
    copy = (char *)malloc(length + 1UL);
    if (!copy) { return 0; }
    memcpy(copy, text, length + 1UL);
    return copy;
}

void CloneMCJ_ByteBuffer_InitWrite(CloneMCJ_ByteBuffer *buffer, unsigned long initialCapacity)
{
    if (!buffer) { return; }
    memset(buffer, 0, sizeof(*buffer));
    if (initialCapacity < 64UL) { initialCapacity = 64UL; }
    buffer->data = (unsigned char *)malloc(initialCapacity);
    if (!buffer->data) { buffer->error = 1; return; }
    buffer->capacity = initialCapacity;
    buffer->ownsData = 1;
}

void CloneMCJ_ByteBuffer_InitRead(CloneMCJ_ByteBuffer *buffer, const unsigned char *data, unsigned long size)
{
    if (!buffer) { return; }
    memset(buffer, 0, sizeof(*buffer));
    buffer->data = (unsigned char *)data;
    buffer->size = size;
    buffer->capacity = size;
    buffer->ownsData = 0;
}

void CloneMCJ_ByteBuffer_Destroy(CloneMCJ_ByteBuffer *buffer)
{
    if (!buffer) { return; }
    if (buffer->ownsData && buffer->data) { free(buffer->data); }
    memset(buffer, 0, sizeof(*buffer));
}

static int CloneMCJ_ByteBuffer_Reserve(CloneMCJ_ByteBuffer *buffer, unsigned long needed)
{
    unsigned long capacity;
    unsigned char *replacement;
    if (!buffer || buffer->error) { return 0; }
    if (needed <= buffer->capacity) { return 1; }
    if (!buffer->ownsData) { buffer->error = 1; return 0; }
    capacity = buffer->capacity ? buffer->capacity : 64UL;
    while (capacity < needed) {
        if (capacity > ULONG_MAX / 2UL) { buffer->error = 1; return 0; }
        capacity *= 2UL;
    }
    replacement = (unsigned char *)realloc(buffer->data, capacity);
    if (!replacement) { buffer->error = 1; return 0; }
    buffer->data = replacement;
    buffer->capacity = capacity;
    return 1;
}

int CloneMCJ_ByteBuffer_Write(CloneMCJ_ByteBuffer *buffer, const void *data, unsigned long size)
{
    if (!buffer || !data || buffer->error) { return size == 0UL; }
    if (!CloneMCJ_ByteBuffer_Reserve(buffer, buffer->size + size)) { return 0; }
    memcpy(buffer->data + buffer->size, data, size);
    buffer->size += size;
    return 1;
}

int CloneMCJ_ByteBuffer_Read(CloneMCJ_ByteBuffer *buffer, void *data, unsigned long size)
{
    if (!buffer || !data || buffer->error || buffer->position + size > buffer->size) {
        if (buffer) { buffer->error = 1; }
        return 0;
    }
    memcpy(data, buffer->data + buffer->position, size);
    buffer->position += size;
    return 1;
}

static int NBT_WriteU8(CloneMCJ_ByteBuffer *out, unsigned int value)
{
    unsigned char byteValue;
    byteValue = (unsigned char)(value & 255U);
    return CloneMCJ_ByteBuffer_Write(out, &byteValue, 1UL);
}
static int NBT_WriteU16(CloneMCJ_ByteBuffer *out, CloneMCJUShort value)
{
    unsigned char bytes[2];
    bytes[0] = (unsigned char)((value >> 8) & 255U); bytes[1] = (unsigned char)(value & 255U);
    return CloneMCJ_ByteBuffer_Write(out, bytes, 2UL);
}
static int NBT_WriteU32(CloneMCJ_ByteBuffer *out, CloneMCJUInt value)
{
    unsigned char bytes[4];
    bytes[0]=(unsigned char)((value>>24)&255UL); bytes[1]=(unsigned char)((value>>16)&255UL);
    bytes[2]=(unsigned char)((value>>8)&255UL); bytes[3]=(unsigned char)(value&255UL);
    return CloneMCJ_ByteBuffer_Write(out, bytes, 4UL);
}
static int NBT_WriteU64(CloneMCJ_ByteBuffer *out, CloneMCJULong value)
{
    unsigned char bytes[8]; int i;
    for (i=0;i<8;++i) { bytes[i]=(unsigned char)((value >> ((7-i)*8)) & (CloneMCJULong)255); }
    return CloneMCJ_ByteBuffer_Write(out, bytes, 8UL);
}
static unsigned int NBT_ReadU8(CloneMCJ_ByteBuffer *in)
{
    unsigned char b=0; CloneMCJ_ByteBuffer_Read(in,&b,1UL); return b;
}
static CloneMCJUShort NBT_ReadU16(CloneMCJ_ByteBuffer *in)
{
    unsigned char b[2]={0,0}; CloneMCJ_ByteBuffer_Read(in,b,2UL);
    return (CloneMCJUShort)(((CloneMCJUShort)b[0]<<8)|(CloneMCJUShort)b[1]);
}
static CloneMCJUInt NBT_ReadU32(CloneMCJ_ByteBuffer *in)
{
    unsigned char b[4]={0,0,0,0}; CloneMCJ_ByteBuffer_Read(in,b,4UL);
    return ((CloneMCJUInt)b[0]<<24)|((CloneMCJUInt)b[1]<<16)|((CloneMCJUInt)b[2]<<8)|(CloneMCJUInt)b[3];
}
static CloneMCJULong NBT_ReadU64(CloneMCJ_ByteBuffer *in)
{
    unsigned char b[8]; CloneMCJULong value; int i;
    memset(b,0,sizeof(b)); CloneMCJ_ByteBuffer_Read(in,b,8UL); value=0;
    for (i=0;i<8;++i) { value=(value<<8)|(CloneMCJULong)b[i]; }
    return value;
}

/* Java DataOutput.writeUTF modified UTF-8 conversion. */
static int NBT_UTF8Next(const unsigned char *s, unsigned long length, unsigned long *index, unsigned long *cp)
{
    unsigned char a,b,c,d; unsigned long i;
    i=*index; if (i>=length) { return 0; } a=s[i++];
    if (a<0x80) { *cp=a; *index=i; return 1; }
    if ((a&0xE0)==0xC0 && i<length) { b=s[i++]; if((b&0xC0)!=0x80)return 0; *cp=((a&0x1F)<<6)|(b&0x3F); *index=i; return 1; }
    if ((a&0xF0)==0xE0 && i+1<length) { b=s[i++]; c=s[i++]; if((b&0xC0)!=0x80||(c&0xC0)!=0x80)return 0; *cp=((a&0x0F)<<12)|((b&0x3F)<<6)|(c&0x3F); *index=i; return 1; }
    if ((a&0xF8)==0xF0 && i+2<length) { b=s[i++]; c=s[i++]; d=s[i++]; if((b&0xC0)!=0x80||(c&0xC0)!=0x80||(d&0xC0)!=0x80)return 0; *cp=((a&7)<<18)|((b&0x3F)<<12)|((c&0x3F)<<6)|(d&0x3F); *index=i; return 1; }
    return 0;
}
static int NBT_ModifiedUTFWriteUnit(CloneMCJ_ByteBuffer *tmp, unsigned int unit)
{
    unsigned char b[3];
    if (unit >= 1U && unit <= 0x7FU) { b[0]=(unsigned char)unit; return CloneMCJ_ByteBuffer_Write(tmp,b,1UL); }
    if (unit <= 0x7FFU) { b[0]=(unsigned char)(0xC0U|(unit>>6)); b[1]=(unsigned char)(0x80U|(unit&63U)); return CloneMCJ_ByteBuffer_Write(tmp,b,2UL); }
    b[0]=(unsigned char)(0xE0U|(unit>>12)); b[1]=(unsigned char)(0x80U|((unit>>6)&63U)); b[2]=(unsigned char)(0x80U|(unit&63U));
    return CloneMCJ_ByteBuffer_Write(tmp,b,3UL);
}
static int NBT_WriteUTF(CloneMCJ_ByteBuffer *out, const char *text)
{
    CloneMCJ_ByteBuffer tmp; unsigned long index,length,cp; unsigned int high,low;
    if (!text) { text=""; } length=(unsigned long)strlen(text); CloneMCJ_ByteBuffer_InitWrite(&tmp,length+8UL);
    if (tmp.error) { return 0; }
    index=0;
    while (index<length) {
        if(!NBT_UTF8Next((const unsigned char*)text,length,&index,&cp)) { CloneMCJ_ByteBuffer_Destroy(&tmp); return 0; }
        if(cp<=0xFFFFUL) { if(!NBT_ModifiedUTFWriteUnit(&tmp,(unsigned int)cp)){CloneMCJ_ByteBuffer_Destroy(&tmp);return 0;} }
        else { cp-=0x10000UL; high=0xD800U+(unsigned int)(cp>>10); low=0xDC00U+(unsigned int)(cp&1023UL); if(!NBT_ModifiedUTFWriteUnit(&tmp,high)||!NBT_ModifiedUTFWriteUnit(&tmp,low)){CloneMCJ_ByteBuffer_Destroy(&tmp);return 0;} }
    }
    if(tmp.size>65535UL){CloneMCJ_ByteBuffer_Destroy(&tmp);return 0;}
    if(!NBT_WriteU16(out,(CloneMCJUShort)tmp.size)||!CloneMCJ_ByteBuffer_Write(out,tmp.data,tmp.size)){CloneMCJ_ByteBuffer_Destroy(&tmp);return 0;}
    CloneMCJ_ByteBuffer_Destroy(&tmp); return 1;
}
static int NBT_UTF8Append(CloneMCJ_ByteBuffer *out, unsigned long cp)
{
    unsigned char b[4]; unsigned long n;
    if(cp<0x80UL){b[0]=(unsigned char)cp;n=1;} else if(cp<0x800UL){b[0]=(unsigned char)(0xC0|(cp>>6));b[1]=(unsigned char)(0x80|(cp&63));n=2;} else if(cp<0x10000UL){b[0]=(unsigned char)(0xE0|(cp>>12));b[1]=(unsigned char)(0x80|((cp>>6)&63));b[2]=(unsigned char)(0x80|(cp&63));n=3;} else {b[0]=(unsigned char)(0xF0|(cp>>18));b[1]=(unsigned char)(0x80|((cp>>12)&63));b[2]=(unsigned char)(0x80|((cp>>6)&63));b[3]=(unsigned char)(0x80|(cp&63));n=4;}
    return CloneMCJ_ByteBuffer_Write(out,b,n);
}
static char *NBT_ReadUTF(CloneMCJ_ByteBuffer *in)
{
    CloneMCJUShort byteLength; unsigned long end; CloneMCJ_ByteBuffer out; unsigned int unit,pendingHigh; unsigned char a,b,c; unsigned long cp; char zero;
    byteLength=NBT_ReadU16(in); if(in->error||in->position+(unsigned long)byteLength>in->size){in->error=1;return 0;}
    end=in->position+(unsigned long)byteLength; CloneMCJ_ByteBuffer_InitWrite(&out,(unsigned long)byteLength+1UL); pendingHigh=0;
    while(in->position<end&&!in->error){
        a=(unsigned char)NBT_ReadU8(in);
        if((a&0x80)==0){unit=a;}
        else if((a&0xE0)==0xC0){
            if(in->position>=end){in->error=1;break;}
            b=(unsigned char)NBT_ReadU8(in);
            if((b&0xC0)!=0x80){in->error=1;break;}
            unit=((a&31U)<<6)|(b&63U);
        } else if((a&0xF0)==0xE0){
            if(in->position+1UL>=end){in->error=1;break;}
            b=(unsigned char)NBT_ReadU8(in);c=(unsigned char)NBT_ReadU8(in);
            if((b&0xC0)!=0x80||(c&0xC0)!=0x80){in->error=1;break;}
            unit=((a&15U)<<12)|((b&63U)<<6)|(c&63U);
        } else {in->error=1;break;}
        if(pendingHigh){if(unit>=0xDC00U&&unit<=0xDFFFU){cp=0x10000UL+(((unsigned long)pendingHigh-0xD800UL)<<10)+((unsigned long)unit-0xDC00UL);NBT_UTF8Append(&out,cp);pendingHigh=0;continue;}NBT_UTF8Append(&out,pendingHigh);pendingHigh=0;}
        if(unit>=0xD800U&&unit<=0xDBFFU){pendingHigh=unit;}else{NBT_UTF8Append(&out,unit);}
    }
    if(pendingHigh){NBT_UTF8Append(&out,pendingHigh);} zero='\0'; CloneMCJ_ByteBuffer_Write(&out,&zero,1UL); if(in->error||out.error){CloneMCJ_ByteBuffer_Destroy(&out);return 0;} out.ownsData=0; return (char*)out.data;
}

CloneMCJ_NBTBase *CloneMCJ_NBTBase_Create(unsigned char type)
{
    CloneMCJ_NBTBase *tag;
    if(type>CLONEMC_J_NBT_TAG_COMPOUND){return 0;}
    tag=(CloneMCJ_NBTBase*)calloc(1,sizeof(*tag)); if(!tag){return 0;} tag->type=type; tag->key=CloneMCJ_NBT_StrDup(""); if(!tag->key){free(tag);return 0;}
    if(type==CLONEMC_J_NBT_TAG_STRING){tag->value.stringValue=CloneMCJ_NBT_StrDup("");if(!tag->value.stringValue){CloneMCJ_NBTBase_Free(tag);return 0;}}
    return tag;
}
CloneMCJ_NBTBase *CloneMCJ_NBTBase_SetKey(CloneMCJ_NBTBase *tag,const char *key){char *copy;if(!tag)return 0;copy=CloneMCJ_NBT_StrDup(key);if(!copy)return tag;if(tag->key)free(tag->key);tag->key=copy;return tag;}
const char *CloneMCJ_NBTBase_GetKey(const CloneMCJ_NBTBase *tag){return tag&&tag->key?tag->key:"";}
const char *CloneMCJ_NBTBase_GetTagName(unsigned char type){static const char *names[]={"TAG_End","TAG_Byte","TAG_Short","TAG_Int","TAG_Long","TAG_Float","TAG_Double","TAG_Byte_Array","TAG_String","TAG_List","TAG_Compound"};return type<=10?names[type]:"UNKNOWN";}
void CloneMCJ_NBTBase_Free(CloneMCJ_NBTBase *tag)
{
    CloneMCJInt i; if(!tag)return; if(tag->key)free(tag->key);
    if(tag->type==CLONEMC_J_NBT_TAG_BYTE_ARRAY&&tag->value.byteArray.data)free(tag->value.byteArray.data);
    else if(tag->type==CLONEMC_J_NBT_TAG_STRING&&tag->value.stringValue)free(tag->value.stringValue);
    else if(tag->type==CLONEMC_J_NBT_TAG_LIST){for(i=0;i<tag->value.listValue.count;++i)CloneMCJ_NBTBase_Free(tag->value.listValue.items[i]);free(tag->value.listValue.items);}
    else if(tag->type==CLONEMC_J_NBT_TAG_COMPOUND){for(i=0;i<tag->value.compoundValue.count;++i)CloneMCJ_NBTBase_Free(tag->value.compoundValue.entries[i]);free(tag->value.compoundValue.entries);}
    free(tag);
}

static int NBT_WriteContents(const CloneMCJ_NBTBase *tag, CloneMCJ_ByteBuffer *out)
{
    CloneMCJUInt bits32; CloneMCJULong bits64; CloneMCJInt i;
    if(!tag||!out)return 0;
    switch(tag->type){
    case 0:return 1; case 1:return NBT_WriteU8(out,(unsigned int)(unsigned char)tag->value.byteValue);
    case 2:return NBT_WriteU16(out,(CloneMCJUShort)tag->value.shortValue);
    case 3:return NBT_WriteU32(out,(CloneMCJUInt)tag->value.intValue);
    case 4:return NBT_WriteU64(out,(CloneMCJULong)tag->value.longValue);
    case 5:memcpy(&bits32,&tag->value.floatValue,4);return NBT_WriteU32(out,bits32);
    case 6:memcpy(&bits64,&tag->value.doubleValue,8);return NBT_WriteU64(out,bits64);
    case 7:if(tag->value.byteArray.length<0)return 0;if(!NBT_WriteU32(out,(CloneMCJUInt)tag->value.byteArray.length))return 0;return tag->value.byteArray.length==0||CloneMCJ_ByteBuffer_Write(out,tag->value.byteArray.data,(unsigned long)tag->value.byteArray.length);
    case 8:return NBT_WriteUTF(out,tag->value.stringValue?tag->value.stringValue:"");
    case 9:if(!NBT_WriteU8(out,tag->value.listValue.count?tag->value.listValue.tagType:1U)||!NBT_WriteU32(out,(CloneMCJUInt)tag->value.listValue.count))return 0;for(i=0;i<tag->value.listValue.count;++i){if(!NBT_WriteContents(tag->value.listValue.items[i],out))return 0;}return 1;
    case 10:for(i=0;i<tag->value.compoundValue.count;++i){if(!CloneMCJ_NBTBase_WriteTag(tag->value.compoundValue.entries[i],out))return 0;}return NBT_WriteU8(out,0);
    default:return 0;}
}
int CloneMCJ_NBTBase_WriteTag(const CloneMCJ_NBTBase *tag,CloneMCJ_ByteBuffer *out){if(!tag||!NBT_WriteU8(out,tag->type))return 0;if(tag->type==0)return 1;if(!NBT_WriteUTF(out,CloneMCJ_NBTBase_GetKey(tag)))return 0;return NBT_WriteContents(tag,out);}

static CloneMCJ_NBTBase *NBT_ReadContents(CloneMCJ_ByteBuffer *in,unsigned char type)
{
    CloneMCJ_NBTBase *tag; CloneMCJUInt u32; CloneMCJULong u64; CloneMCJInt count,i; unsigned char childType; char *text; CloneMCJ_NBTBase *child;
    tag=CloneMCJ_NBTBase_Create(type);if(!tag)return 0;
    switch(type){
    case 0:break;case 1:tag->value.byteValue=(CloneMCJByte)NBT_ReadU8(in);break;case 2:tag->value.shortValue=(CloneMCJShort)NBT_ReadU16(in);break;case 3:tag->value.intValue=(CloneMCJInt)NBT_ReadU32(in);break;case 4:tag->value.longValue=(CloneMCJLong)NBT_ReadU64(in);break;
    case 5:u32=NBT_ReadU32(in);memcpy(&tag->value.floatValue,&u32,4);break;case 6:u64=NBT_ReadU64(in);memcpy(&tag->value.doubleValue,&u64,8);break;
    case 7:count=(CloneMCJInt)NBT_ReadU32(in);if(count<0||count>67108864){in->error=1;break;}tag->value.byteArray.length=count;if(count){tag->value.byteArray.data=(unsigned char*)malloc((unsigned long)count);if(!tag->value.byteArray.data||!CloneMCJ_ByteBuffer_Read(in,tag->value.byteArray.data,(unsigned long)count)){in->error=1;}}break;
    case 8:text=NBT_ReadUTF(in);if(!text){in->error=1;break;}free(tag->value.stringValue);tag->value.stringValue=text;break;
    case 9:childType=(unsigned char)NBT_ReadU8(in);count=(CloneMCJInt)NBT_ReadU32(in);if(count<0||count>1048576||childType>10){in->error=1;break;}tag->value.listValue.tagType=childType;for(i=0;i<count&&!in->error;++i){child=NBT_ReadContents(in,childType);if(!child||!CloneMCJ_NBTTagList_Append(tag,child)){CloneMCJ_NBTBase_Free(child);in->error=1;break;}}break;
    case 10:while(!in->error){child=CloneMCJ_NBTBase_ReadTag(in);if(!child){in->error=1;break;}if(child->type==0){CloneMCJ_NBTBase_Free(child);break;}CloneMCJ_NBTTagCompound_SetTag(tag,CloneMCJ_NBTBase_GetKey(child),child);}break;
    default:in->error=1;break;}
    if(in->error){CloneMCJ_NBTBase_Free(tag);return 0;}return tag;
}
/* NBT tag wire order is type, name, then contents. */
static CloneMCJ_NBTBase *NBT_ReadNamedTag(CloneMCJ_ByteBuffer *in)
{
    unsigned char type; char *key; CloneMCJ_NBTBase *tag;
    type=(unsigned char)NBT_ReadU8(in);if(in->error)return 0;if(type==0)return CloneMCJ_NBTBase_Create(0);
    key=NBT_ReadUTF(in);if(!key)return 0;tag=NBT_ReadContents(in,type);if(!tag){free(key);return 0;}CloneMCJ_NBTBase_SetKey(tag,key);free(key);return tag;
}
CloneMCJ_NBTBase *CloneMCJ_NBTBase_ReadTag(CloneMCJ_ByteBuffer *in){return NBT_ReadNamedTag(in);}

CloneMCJ_NBTBase *CloneMCJ_NBTBase_Clone(const CloneMCJ_NBTBase *tag)
{
    CloneMCJ_ByteBuffer out,in;CloneMCJ_NBTBase *copy;if(!tag)return 0;CloneMCJ_ByteBuffer_InitWrite(&out,128);if(!CloneMCJ_NBTBase_WriteTag(tag,&out)){CloneMCJ_ByteBuffer_Destroy(&out);return 0;}CloneMCJ_ByteBuffer_InitRead(&in,out.data,out.size);copy=CloneMCJ_NBTBase_ReadTag(&in);CloneMCJ_ByteBuffer_Destroy(&out);return copy;
}

void CloneMCJ_NBTBase_Register(void) { }
const char *CloneMCJ_NBTBase_JavaName(void) { return "net.minecraft.src.NBTBase"; }
const char *CloneMCJ_NBTBase_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTBase_JavaSourceHash32(void) { return 0xDE43E38DUL; }
