/* Java source: SaveFormatOld.java; Source SHA-256: 1c253696a96772a022418c743cae4c257ef1438df628f8178ba18befaf6d78f2; Java lines: 158. */
/* Direct C89 port of SaveFormatOld.java with safer level.dat updates. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
#if defined(_WIN32)
#include <io.h>
#include <direct.h>
#define SFO_RMDIR _rmdir
#else
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#define SFO_RMDIR rmdir
#endif
static int SFO_Exists(const char*p){FILE*f=fopen(p,"rb");if(!f)return 0;fclose(f);return 1;}
static int SFO_Replace(const char*tmp,const char*dst){char bak[CLONEMC_J_PATH_MAX];if(strlen(dst)+12UL>=sizeof(bak))return 0;strcpy(bak,dst);strcat(bak,".rename_old");remove(bak);if(SFO_Exists(dst)&&rename(dst,bak)!=0)return 0;if(rename(tmp,dst)!=0){if(SFO_Exists(bak))rename(bak,dst);return 0;}remove(bak);return 1;}
static int SFO_Path(char*out,unsigned long cap,const char*a,const char*b){size_t na,nb;if(!out||!a||!b)return 0;na=strlen(a);nb=strlen(b);if(na+nb+2>cap)return 0;strcpy(out,a);if(na&&a[na-1]!='/'&&a[na-1]!='\\')strcat(out,"/");strcat(out,b);return 1;}
static int SFO_LoadInfoPath(const char*p,CloneMCJ_WorldInfo*i){CloneMCJ_NBTTagCompound*r,*d;int ok;r=CloneMCJ_CompressedStreamTools_ReadGzipFile(p);if(!r)return 0;d=CloneMCJ_NBTTagCompound_GetCompoundTag(r,"Data");ok=d?CloneMCJ_WorldInfo_LoadFromNBT(i,(CloneMCJ_NBTBase*)d):0;CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase*)r);return ok;}
int CloneMCJ_SaveFormatOld_LoadWorldInfo(const char*b,const char*w,CloneMCJ_WorldInfo*i){char d[CLONEMC_J_PATH_MAX],p[CLONEMC_J_PATH_MAX];if(!b||!w||!i||!SFO_Path(d,sizeof(d),b,w))return 0;if(SFO_Path(p,sizeof(p),d,"level.dat")&&SFO_LoadInfoPath(p,i))return 1;return SFO_Path(p,sizeof(p),d,"level.dat_old")&&SFO_LoadInfoPath(p,i);}
int CloneMCJ_SaveFormatOld_RenameWorld(const char*b,const char*w,const char*n){char d[CLONEMC_J_PATH_MAX],p[CLONEMC_J_PATH_MAX],tmp[CLONEMC_J_PATH_MAX];CloneMCJ_NBTTagCompound*r,*data;int ok;if(!b||!w||!n||!SFO_Path(d,sizeof(d),b,w)||!SFO_Path(p,sizeof(p),d,"level.dat"))return 0;r=CloneMCJ_CompressedStreamTools_ReadGzipFile(p);if(!r)return 0;data=CloneMCJ_NBTTagCompound_GetCompoundTag(r,"Data");if(!data){CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase*)r);return 0;}CloneMCJ_NBTTagCompound_SetString(data,"LevelName",n);if(strlen(p)+5>=sizeof(tmp)){CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase*)r);return 0;}strcpy(tmp,p);strcat(tmp,".tmp");ok=CloneMCJ_CompressedStreamTools_WriteGzipFile(r,tmp);CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase*)r);if(!ok){remove(tmp);return 0;}if(!SFO_Replace(tmp,p)){remove(tmp);return 0;}return 1;}
int CloneMCJ_SaveFormatOld_ListWorlds(const char*b,CloneMCJ_SaveFormatComparator**out,int*count){CloneMCJ_SaveFormatComparator*a;CloneMCJ_WorldInfo i;char n[32];int k,c=0;if(out)*out=0;if(count)*count=0;if(!b||!out||!count)return 0;a=(CloneMCJ_SaveFormatComparator*)calloc(5,sizeof(*a));if(!a)return 0;for(k=1;k<=5;++k){sprintf(n,"World%d",k);memset(&i,0,sizeof(i));if(CloneMCJ_SaveFormatOld_LoadWorldInfo(b,n,&i)){CloneMCJ_SaveFormatComparator_Initialize(&a[c++],n,"",i.lastTimePlayed,i.sizeOnDisk,0);CloneMCJ_WorldInfo_Destroy(&i);}}*out=a;*count=c;return 1;}
void CloneMCJ_SaveFormatOld_FreeWorldList(CloneMCJ_SaveFormatComparator*a){free(a);}
static int SFO_DeleteTree(const char*p){int ok=1;
#if defined(_WIN32)
struct _finddata_t fd;long h;char pat[CLONEMC_J_PATH_MAX],q[CLONEMC_J_PATH_MAX];if(!SFO_Path(pat,sizeof(pat),p,"*"))return 0;h=_findfirst(pat,&fd);if(h!=-1){do{if(strcmp(fd.name,".")&&strcmp(fd.name,"..")&&SFO_Path(q,sizeof(q),p,fd.name)){if(fd.attrib&_A_SUBDIR)ok=SFO_DeleteTree(q)&&ok;else ok=(remove(q)==0)&&ok;}}while(_findnext(h,&fd)==0);_findclose(h);}if(SFO_RMDIR(p)!=0)ok=0;
#else
DIR*d=opendir(p);struct dirent*e;char q[CLONEMC_J_PATH_MAX];struct stat st;if(d){while((e=readdir(d))!=0){if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;if(!SFO_Path(q,sizeof(q),p,e->d_name))continue;if(stat(q,&st)==0&&S_ISDIR(st.st_mode))ok=SFO_DeleteTree(q)&&ok;else ok=(remove(q)==0)&&ok;}closedir(d);}if(SFO_RMDIR(p)!=0)ok=0;
#endif
return ok;}
int CloneMCJ_SaveFormatOld_DeleteWorld(const char*b,const char*w){char p[CLONEMC_J_PATH_MAX];return b&&w&&SFO_Path(p,sizeof(p),b,w)?SFO_DeleteTree(p):0;}
void CloneMCJ_SaveFormatOld_Register(void){}
const char *CloneMCJ_SaveFormatOld_JavaName(void){return "net.minecraft.src.SaveFormatOld";}
const char *CloneMCJ_SaveFormatOld_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_SaveFormatOld_JavaSourceHash32(void){return 0x1C253696UL;}
