/* Java source: NBTTagFloat.java; Source SHA-256: df9c06cfbdd2b8de177abbfa68e3d7af7931c4aed9f78409b1429c944520d163; Java lines: 47. */
/* Direct C89 port of NBTTagFloat.java. */
#include "clonemc_java_port_10_save.h"
CloneMCJ_NBTTagFloat *CloneMCJ_NBTTagFloat_Create(float value){CloneMCJ_NBTBase *tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_FLOAT);if(tag){tag->value.floatValue=value;}return (CloneMCJ_NBTTagFloat*)tag;}

void CloneMCJ_NBTTagFloat_Register(void) { }
const char *CloneMCJ_NBTTagFloat_JavaName(void) { return "net.minecraft.src.NBTTagFloat"; }
const char *CloneMCJ_NBTTagFloat_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagFloat_JavaSourceHash32(void) { return 0xDF9C06CFUL; }
