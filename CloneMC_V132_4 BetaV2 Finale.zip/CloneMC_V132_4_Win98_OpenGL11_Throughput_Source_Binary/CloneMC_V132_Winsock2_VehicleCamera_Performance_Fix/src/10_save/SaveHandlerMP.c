/* Java source: SaveHandlerMP.java; Source SHA-256: b0405d6fa3e8b2331a10b12d1e66604c7ed1ecfde1e1511298607e5f983b48f1; Java lines: 47. */
/* Direct C89 port of SaveHandlerMP.java: deliberate no-op multiplayer save handler. */
#include "clonemc_java_port_10_save.h"
#include <string.h>
void CloneMCJ_SaveHandlerMP_Initialize(CloneMCJ_SaveHandlerMP*h){if(h)memset(h,0,sizeof(*h));}
int CloneMCJ_SaveHandlerMP_LoadWorldInfo(CloneMCJ_SaveHandlerMP*h,CloneMCJ_WorldInfo*i){(void)h;(void)i;return 0;}
int CloneMCJ_SaveHandlerMP_CheckSessionLock(CloneMCJ_SaveHandlerMP*h){(void)h;return 1;}
CloneMCJ_IChunkLoader CloneMCJ_SaveHandlerMP_GetChunkLoader(CloneMCJ_SaveHandlerMP*h,int d){CloneMCJ_IChunkLoader l;(void)h;(void)d;memset(&l,0,sizeof(l));return l;}
int CloneMCJ_SaveHandlerMP_SaveWorldInfo(CloneMCJ_SaveHandlerMP*h,const CloneMCJ_WorldInfo*i,const CloneMCJ_NBTTagCompound*p){(void)h;(void)i;(void)p;return 1;}
void CloneMCJ_SaveHandlerMP_Register(void){}
const char *CloneMCJ_SaveHandlerMP_JavaName(void){return "net.minecraft.src.SaveHandlerMP";}
const char *CloneMCJ_SaveHandlerMP_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_SaveHandlerMP_JavaSourceHash32(void){return 0xB0405D6FUL;}
