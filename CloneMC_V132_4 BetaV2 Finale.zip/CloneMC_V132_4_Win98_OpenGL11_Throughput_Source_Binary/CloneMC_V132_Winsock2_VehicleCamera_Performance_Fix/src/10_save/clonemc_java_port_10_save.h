/*
 * CloneMC V90 Priority 5 shared save/NBT/McRegion declarations.
 *
 * Header architecture rule: the project continues to use exactly ten shared
 * subsystem headers.  Every Java save class remains a same-basename C file,
 * while this single header owns their public C types and prototypes.
 */
#ifndef CLONEMC_JAVA_PORT_10_SAVE_H
#define CLONEMC_JAVA_PORT_10_SAVE_H

#include "../00_core/clonemc_java_port_00_core.h"
#include "../40_world/clonemc_java_port_40_world.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CLONEMC_J_NBT_TAG_END        0
#define CLONEMC_J_NBT_TAG_BYTE       1
#define CLONEMC_J_NBT_TAG_SHORT      2
#define CLONEMC_J_NBT_TAG_INT        3
#define CLONEMC_J_NBT_TAG_LONG       4
#define CLONEMC_J_NBT_TAG_FLOAT      5
#define CLONEMC_J_NBT_TAG_DOUBLE     6
#define CLONEMC_J_NBT_TAG_BYTE_ARRAY 7
#define CLONEMC_J_NBT_TAG_STRING     8
#define CLONEMC_J_NBT_TAG_LIST       9
#define CLONEMC_J_NBT_TAG_COMPOUND  10

#define CLONEMC_J_REGION_SECTOR_BYTES 4096UL
#define CLONEMC_J_REGION_HEADER_BYTES 8192UL
#define CLONEMC_J_REGION_ENTRIES 1024
#define CLONEMC_J_REGION_CACHE_SIZE 64
#define CLONEMC_J_PATH_MAX 1024

typedef struct CloneMCJ_NBTBaseTag CloneMCJ_NBTBase;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagEnd;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagByte;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagShort;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagInt;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagLong;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagFloat;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagDouble;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagByteArray;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagString;
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagList;
#ifndef CLONEMC_J_NBT_TAG_COMPOUND_TYPEDEF
#define CLONEMC_J_NBT_TAG_COMPOUND_TYPEDEF
typedef CloneMCJ_NBTBase CloneMCJ_NBTTagCompound;
#endif

typedef struct CloneMCJ_NBTArrayTag {
    unsigned char *data;
    CloneMCJInt length;
} CloneMCJ_NBTArray;

typedef struct CloneMCJ_NBTListValueTag {
    unsigned char tagType;
    CloneMCJ_NBTBase **items;
    CloneMCJInt count;
    CloneMCJInt capacity;
} CloneMCJ_NBTListValue;

typedef struct CloneMCJ_NBTCompoundValueTag {
    CloneMCJ_NBTBase **entries;
    CloneMCJInt count;
    CloneMCJInt capacity;
} CloneMCJ_NBTCompoundValue;

struct CloneMCJ_NBTBaseTag {
    unsigned char type;
    char *key;
    union {
        CloneMCJByte byteValue;
        CloneMCJShort shortValue;
        CloneMCJInt intValue;
        CloneMCJLong longValue;
        float floatValue;
        double doubleValue;
        CloneMCJ_NBTArray byteArray;
        char *stringValue;
        CloneMCJ_NBTListValue listValue;
        CloneMCJ_NBTCompoundValue compoundValue;
    } value;
};

typedef struct CloneMCJ_ByteBufferTag {
    unsigned char *data;
    unsigned long size;
    unsigned long capacity;
    unsigned long position;
    int error;
    int ownsData;
} CloneMCJ_ByteBuffer;

enum {
    CLONEMC_J_REGION_ERROR_NONE = 0,
    CLONEMC_J_REGION_ERROR_ARGUMENT = 1,
    CLONEMC_J_REGION_ERROR_OPEN = 2,
    CLONEMC_J_REGION_ERROR_COMPRESS = 3,
    CLONEMC_J_REGION_ERROR_TOO_LARGE = 4,
    CLONEMC_J_REGION_ERROR_ALLOCATE = 5,
    CLONEMC_J_REGION_ERROR_SEEK = 6,
    CLONEMC_J_REGION_ERROR_WRITE_PAYLOAD = 7,
    CLONEMC_J_REGION_ERROR_WRITE_PADDING = 8,
    CLONEMC_J_REGION_ERROR_FLUSH_PAYLOAD = 9,
    CLONEMC_J_REGION_ERROR_VERIFY_PAYLOAD = 10,
    CLONEMC_J_REGION_ERROR_WRITE_HEADER = 11,
    CLONEMC_J_REGION_ERROR_FLUSH_HEADER = 12,
    CLONEMC_J_REGION_ERROR_TRUNCATE = 13,
    CLONEMC_J_REGION_ERROR_READ = 14
};

typedef struct CloneMCJ_RegionFileTag {
    FILE *file;
    char path[CLONEMC_J_PATH_MAX];
    CloneMCJUInt offsets[CLONEMC_J_REGION_ENTRIES];
    CloneMCJUInt timestamps[CLONEMC_J_REGION_ENTRIES];
    unsigned char *sectorFree;
    unsigned long sectorCount;
    long sizeDelta;
    int open;
    int dirty;
    int lastError;
    int lastSystemError;
    int lastChunkX, lastChunkZ;
    char lastOperation[48];
    unsigned long writeAttempts, writeRetries, verifiedWrites;
    int testFailStage;
} CloneMCJ_RegionFile;

typedef struct CloneMCJ_RegionFileChunkBufferTag {
    unsigned char *data;
    unsigned long size;
    unsigned long capacity;
    int error;
} CloneMCJ_RegionFileChunkBuffer;

typedef struct CloneMCJ_RegionFileCacheEntryTag {
    unsigned char used;
    unsigned long accessStamp;
    char path[CLONEMC_J_PATH_MAX];
    CloneMCJ_RegionFile region;
} CloneMCJ_RegionFileCacheEntry;

typedef struct CloneMCJ_RegionFileCacheTag {
    CloneMCJ_RegionFileCacheEntry entries[CLONEMC_J_REGION_CACHE_SIZE];
    unsigned long accessClock;
    int lastError;
    int lastSystemError;
    int lastChunkX, lastChunkZ;
    char lastPath[CLONEMC_J_PATH_MAX];
    char lastOperation[48];
    unsigned long writeAttempts, writeRetries, writeFailures;
    int activeLimit;
} CloneMCJ_RegionFileCache;

typedef struct CloneMCJ_ChunkSerializationHooksTag {
    int (*writeEntity)(void *entity, CloneMCJ_NBTTagCompound *compound, void *userData);
    void *(*readEntity)(const CloneMCJ_NBTTagCompound *compound, void *userData);
    double (*getEntityY)(void *entity, void *userData);
    int (*writeTileEntity)(void *tileEntity, CloneMCJ_NBTTagCompound *compound, void *userData);
    void *(*readTileEntity)(const CloneMCJ_NBTTagCompound *compound, void *userData);
    void *userData;
} CloneMCJ_ChunkSerializationHooks;

typedef struct CloneMCJ_ChunkLoaderTag {
    char saveDir[CLONEMC_J_PATH_MAX];
    int createIfNecessary;
    CloneMCJ_ChunkSerializationHooks hooks;
    CloneMCJLong *worldTimePointer;
} CloneMCJ_ChunkLoader;

typedef struct CloneMCJ_McRegionChunkLoaderTag {
    char worldDir[CLONEMC_J_PATH_MAX];
    CloneMCJ_RegionFileCache *cache;
    CloneMCJ_ChunkSerializationHooks hooks;
    CloneMCJLong *worldTimePointer;
    CloneMCJ_WorldInfo *worldInfoPointer;
    int lastLoadError;
    int lastSaveError;
    int lastLoadChunkX, lastLoadChunkZ;
    int lastSaveChunkX, lastSaveChunkZ;
    char lastSaveDetail[192];
    unsigned long corruptChunksRejected;
    unsigned long saveRetries;
} CloneMCJ_McRegionChunkLoader;


typedef struct CloneMCJ_IChunkLoaderTag {
    void *instance;
    int (*loadChunk)(void *, CloneMCJ_Chunk *, int, int);
    int (*saveChunk)(void *, const CloneMCJ_Chunk *, CloneMCJLong);
    void (*flush)(void *);
} CloneMCJ_IChunkLoader;

typedef struct CloneMCJ_ISaveHandlerTag {
    void *instance;
    int (*checkSessionLock)(void *);
    int (*loadWorldInfo)(void *, CloneMCJ_WorldInfo *);
    int (*saveWorldInfo)(void *, const CloneMCJ_WorldInfo *, const CloneMCJ_NBTTagCompound *);
    CloneMCJ_IChunkLoader (*getChunkLoader)(void *, int);
} CloneMCJ_ISaveHandler;

typedef struct CloneMCJ_ISaveFormatTag {
    char baseDirectory[CLONEMC_J_PATH_MAX];
    int (*loadWorldInfo)(const char *, const char *, CloneMCJ_WorldInfo *);
    int (*renameWorld)(const char *, const char *, const char *);
} CloneMCJ_ISaveFormat;


#ifndef CLONEMC_J_MAP_DATA_BASE_TYPEDEF
#define CLONEMC_J_MAP_DATA_BASE_TYPEDEF
typedef struct CloneMCJ_MapDataBaseTag CloneMCJ_MapDataBase;
#endif
typedef struct CloneMCJ_SaveHandlerTag CloneMCJ_SaveHandler;

typedef struct CloneMCJ_ChunkFileTag {
    char path[CLONEMC_J_PATH_MAX];
    int chunkX;
    int chunkZ;
} CloneMCJ_ChunkFile;

typedef struct CloneMCJ_SaveFormatComparatorTag {
    char fileName[256];
    char displayName[256];
    CloneMCJLong lastPlayed;
    CloneMCJLong sizeOnDisk;
    unsigned char requiresConversion;
} CloneMCJ_SaveFormatComparator;

typedef void (*CloneMCJ_ProgressCallback)(int percent, void *userData);

typedef struct CloneMCJ_SaveConverterMcRegionTag {
    char baseDirectory[CLONEMC_J_PATH_MAX];
    CloneMCJ_RegionFileCache regionCache;
} CloneMCJ_SaveConverterMcRegion;

typedef struct CloneMCJ_SaveHandlerMPTag {
    int unused;
} CloneMCJ_SaveHandlerMP;

typedef struct CloneMCJ_MapStorageEntryTag {
    char name[256];
    CloneMCJ_MapDataBase *data;
} CloneMCJ_MapStorageEntry;

typedef struct CloneMCJ_MapStorageIdEntryTag {
    char name[128];
    CloneMCJShort value;
} CloneMCJ_MapStorageIdEntry;

typedef CloneMCJ_MapDataBase *(*CloneMCJ_MapDataFactory)(const char *name, void *userData);

typedef struct CloneMCJ_MapStorageTag {
    CloneMCJ_SaveHandler *saveHandler;
    CloneMCJ_MapStorageEntry *entries;
    int entryCount;
    int entryCapacity;
    CloneMCJ_MapStorageIdEntry *idCounts;
    int idCount;
    int idCapacity;
} CloneMCJ_MapStorage;

struct CloneMCJ_SaveHandlerTag {
    char saveDirectory[CLONEMC_J_PATH_MAX];
    char playersDirectory[CLONEMC_J_PATH_MAX];
    char dataDirectory[CLONEMC_J_PATH_MAX];
    /* Native diagnostic counterpart to Java's thrown save exceptions.  The
     * Win32 front end copies this text before destroying the handler so a
     * failed create/open reports the actual transaction stage. */
    char lastError[192];
    CloneMCJLong sessionId;
    CloneMCJ_RegionFileCache regionCache;
    CloneMCJ_McRegionChunkLoader chunkLoader;
    int initialized;
};

typedef struct CloneMCJ_SaveOldDirTag {
    CloneMCJ_SaveHandler base;
} CloneMCJ_SaveOldDir;

/* Portable memory stream and Java big-endian primitive helpers. */
void CloneMCJ_ByteBuffer_InitWrite(CloneMCJ_ByteBuffer *buffer, unsigned long initialCapacity);
void CloneMCJ_ByteBuffer_InitRead(CloneMCJ_ByteBuffer *buffer, const unsigned char *data, unsigned long size);
void CloneMCJ_ByteBuffer_Destroy(CloneMCJ_ByteBuffer *buffer);
int CloneMCJ_ByteBuffer_Write(CloneMCJ_ByteBuffer *buffer, const void *data, unsigned long size);
int CloneMCJ_ByteBuffer_Read(CloneMCJ_ByteBuffer *buffer, void *data, unsigned long size);


/* Java old-save discovery, listing, conversion, map-data, and no-op MP save APIs. */
int CloneMCJ_ChunkFilePattern_Accept(const char *name);
int CloneMCJ_ChunkFolderPattern_Accept(const char *name);
int CloneMCJ_ChunkFile_Initialize(CloneMCJ_ChunkFile *file, const char *path);
int CloneMCJ_ChunkFile_Compare(const CloneMCJ_ChunkFile *a, const CloneMCJ_ChunkFile *b);

void CloneMCJ_SaveFormatComparator_Initialize(CloneMCJ_SaveFormatComparator *entry, const char *fileName, const char *displayName, CloneMCJLong lastPlayed, CloneMCJLong sizeOnDisk, int requiresConversion);
int CloneMCJ_SaveFormatComparator_Compare(const CloneMCJ_SaveFormatComparator *a, const CloneMCJ_SaveFormatComparator *b);

int CloneMCJ_SaveFormatOld_ListWorlds(const char *baseDirectory, CloneMCJ_SaveFormatComparator **entriesOut, int *countOut);
int CloneMCJ_SaveFormatOld_DeleteWorld(const char *baseDirectory, const char *worldName);
void CloneMCJ_SaveFormatOld_FreeWorldList(CloneMCJ_SaveFormatComparator *entries);

void CloneMCJ_SaveConverterMcRegion_Initialize(CloneMCJ_SaveConverterMcRegion *converter, const char *baseDirectory);
void CloneMCJ_SaveConverterMcRegion_Destroy(CloneMCJ_SaveConverterMcRegion *converter);
int CloneMCJ_SaveConverterMcRegion_ListWorlds(CloneMCJ_SaveConverterMcRegion *converter, CloneMCJ_SaveFormatComparator **entriesOut, int *countOut);
int CloneMCJ_SaveConverterMcRegion_ListWorldsAt(const char *baseDirectory,
    CloneMCJ_SaveFormatComparator **entriesOut, int *countOut);
int CloneMCJ_SaveConverterMcRegion_IsOldMapFormat(CloneMCJ_SaveConverterMcRegion *converter, const char *worldName);
int CloneMCJ_SaveConverterMcRegion_Convert(CloneMCJ_SaveConverterMcRegion *converter, const char *worldName, CloneMCJ_ProgressCallback progress, void *userData);

int CloneMCJ_SaveOldDir_Initialize(CloneMCJ_SaveOldDir *handler, const char *baseDirectory, const char *worldName, int storePlayers);
void CloneMCJ_SaveOldDir_Destroy(CloneMCJ_SaveOldDir *handler);
CloneMCJ_McRegionChunkLoader *CloneMCJ_SaveOldDir_GetChunkLoader(CloneMCJ_SaveOldDir *handler, int dimension);
int CloneMCJ_SaveOldDir_SaveWorldInfo(CloneMCJ_SaveOldDir *handler, CloneMCJ_WorldInfo *info, const CloneMCJ_NBTTagCompound *playerTag);

void CloneMCJ_SaveHandlerMP_Initialize(CloneMCJ_SaveHandlerMP *handler);
int CloneMCJ_SaveHandlerMP_LoadWorldInfo(CloneMCJ_SaveHandlerMP *handler, CloneMCJ_WorldInfo *info);
int CloneMCJ_SaveHandlerMP_CheckSessionLock(CloneMCJ_SaveHandlerMP *handler);
CloneMCJ_IChunkLoader CloneMCJ_SaveHandlerMP_GetChunkLoader(CloneMCJ_SaveHandlerMP *handler, int dimension);
int CloneMCJ_SaveHandlerMP_SaveWorldInfo(CloneMCJ_SaveHandlerMP *handler, const CloneMCJ_WorldInfo *info, const CloneMCJ_NBTTagCompound *playerTag);

int CloneMCJ_SaveHandler_GetDataFile(const CloneMCJ_SaveHandler *handler, const char *name, char *pathOut, unsigned long pathCapacity);
int CloneMCJ_SaveHandler_SavePlayerTag(CloneMCJ_SaveHandler *handler, const char *playerName, const CloneMCJ_NBTTagCompound *playerTag);
CloneMCJ_NBTTagCompound *CloneMCJ_SaveHandler_LoadPlayerTag(CloneMCJ_SaveHandler *handler, const char *playerName);

void CloneMCJ_MapStorage_Initialize(CloneMCJ_MapStorage *storage, CloneMCJ_SaveHandler *handler);
void CloneMCJ_MapStorage_Destroy(CloneMCJ_MapStorage *storage, int freeData);
CloneMCJ_MapDataBase *CloneMCJ_MapStorage_LoadData(CloneMCJ_MapStorage *storage, const char *name, CloneMCJ_MapDataFactory factory, void *userData);
int CloneMCJ_MapStorage_SetData(CloneMCJ_MapStorage *storage, const char *name, CloneMCJ_MapDataBase *data);
int CloneMCJ_MapStorage_SaveAllData(CloneMCJ_MapStorage *storage);
int CloneMCJ_MapStorage_GetUniqueDataId(CloneMCJ_MapStorage *storage, const char *name);

/* Complete NBT type system corresponding to every NBT*.java file. */
CloneMCJ_NBTBase *CloneMCJ_NBTBase_Create(unsigned char type);
CloneMCJ_NBTBase *CloneMCJ_NBTBase_Clone(const CloneMCJ_NBTBase *tag);
void CloneMCJ_NBTBase_Free(CloneMCJ_NBTBase *tag);
CloneMCJ_NBTBase *CloneMCJ_NBTBase_SetKey(CloneMCJ_NBTBase *tag, const char *key);
const char *CloneMCJ_NBTBase_GetKey(const CloneMCJ_NBTBase *tag);
const char *CloneMCJ_NBTBase_GetTagName(unsigned char type);
int CloneMCJ_NBTBase_WriteTag(const CloneMCJ_NBTBase *tag, CloneMCJ_ByteBuffer *out);
CloneMCJ_NBTBase *CloneMCJ_NBTBase_ReadTag(CloneMCJ_ByteBuffer *in);

CloneMCJ_NBTTagEnd *CloneMCJ_NBTTagEnd_Create(void);
CloneMCJ_NBTTagByte *CloneMCJ_NBTTagByte_Create(CloneMCJByte value);
CloneMCJ_NBTTagShort *CloneMCJ_NBTTagShort_Create(CloneMCJShort value);
CloneMCJ_NBTTagInt *CloneMCJ_NBTTagInt_Create(CloneMCJInt value);
CloneMCJ_NBTTagLong *CloneMCJ_NBTTagLong_Create(CloneMCJLong value);
CloneMCJ_NBTTagFloat *CloneMCJ_NBTTagFloat_Create(float value);
CloneMCJ_NBTTagDouble *CloneMCJ_NBTTagDouble_Create(double value);
CloneMCJ_NBTTagByteArray *CloneMCJ_NBTTagByteArray_Create(const unsigned char *data, CloneMCJInt length);
CloneMCJ_NBTTagString *CloneMCJ_NBTTagString_Create(const char *value);
CloneMCJ_NBTTagList *CloneMCJ_NBTTagList_Create(void);
CloneMCJ_NBTTagCompound *CloneMCJ_NBTTagCompound_Create(void);

int CloneMCJ_NBTTagList_Append(CloneMCJ_NBTTagList *list, CloneMCJ_NBTBase *tag);
CloneMCJInt CloneMCJ_NBTTagList_Count(const CloneMCJ_NBTTagList *list);
CloneMCJ_NBTBase *CloneMCJ_NBTTagList_Get(const CloneMCJ_NBTTagList *list, CloneMCJInt index);
unsigned char CloneMCJ_NBTTagList_GetTagType(const CloneMCJ_NBTTagList *list);

void CloneMCJ_NBTTagCompound_SetTag(CloneMCJ_NBTTagCompound *compound, const char *key, CloneMCJ_NBTBase *tag);
void CloneMCJ_NBTTagCompound_SetByte(CloneMCJ_NBTTagCompound *compound, const char *key, CloneMCJByte value);
void CloneMCJ_NBTTagCompound_SetShort(CloneMCJ_NBTTagCompound *compound, const char *key, CloneMCJShort value);
void CloneMCJ_NBTTagCompound_SetInteger(CloneMCJ_NBTTagCompound *compound, const char *key, CloneMCJInt value);
void CloneMCJ_NBTTagCompound_SetLong(CloneMCJ_NBTTagCompound *compound, const char *key, CloneMCJLong value);
void CloneMCJ_NBTTagCompound_SetFloat(CloneMCJ_NBTTagCompound *compound, const char *key, float value);
void CloneMCJ_NBTTagCompound_SetDouble(CloneMCJ_NBTTagCompound *compound, const char *key, double value);
void CloneMCJ_NBTTagCompound_SetString(CloneMCJ_NBTTagCompound *compound, const char *key, const char *value);
void CloneMCJ_NBTTagCompound_SetByteArray(CloneMCJ_NBTTagCompound *compound, const char *key, const unsigned char *data, CloneMCJInt length);
void CloneMCJ_NBTTagCompound_SetBoolean(CloneMCJ_NBTTagCompound *compound, const char *key, int value);
int CloneMCJ_NBTTagCompound_HasKey(const CloneMCJ_NBTTagCompound *compound, const char *key);
CloneMCJ_NBTBase *CloneMCJ_NBTTagCompound_GetTag(const CloneMCJ_NBTTagCompound *compound, const char *key);
CloneMCJByte CloneMCJ_NBTTagCompound_GetByte(const CloneMCJ_NBTTagCompound *compound, const char *key);
CloneMCJShort CloneMCJ_NBTTagCompound_GetShort(const CloneMCJ_NBTTagCompound *compound, const char *key);
CloneMCJInt CloneMCJ_NBTTagCompound_GetInteger(const CloneMCJ_NBTTagCompound *compound, const char *key);
CloneMCJLong CloneMCJ_NBTTagCompound_GetLong(const CloneMCJ_NBTTagCompound *compound, const char *key);
float CloneMCJ_NBTTagCompound_GetFloat(const CloneMCJ_NBTTagCompound *compound, const char *key);
double CloneMCJ_NBTTagCompound_GetDouble(const CloneMCJ_NBTTagCompound *compound, const char *key);
const char *CloneMCJ_NBTTagCompound_GetString(const CloneMCJ_NBTTagCompound *compound, const char *key);
const unsigned char *CloneMCJ_NBTTagCompound_GetByteArray(const CloneMCJ_NBTTagCompound *compound, const char *key, CloneMCJInt *lengthOut);
CloneMCJ_NBTTagCompound *CloneMCJ_NBTTagCompound_GetCompoundTag(const CloneMCJ_NBTTagCompound *compound, const char *key);
CloneMCJ_NBTTagList *CloneMCJ_NBTTagCompound_GetTagList(const CloneMCJ_NBTTagCompound *compound, const char *key);
int CloneMCJ_NBTTagCompound_GetBoolean(const CloneMCJ_NBTTagCompound *compound, const char *key);

/* CompressedStreamTools.java: raw NBT, gzip level.dat and zlib region payloads. */
int CloneMCJ_CompressedStreamTools_WriteCompoundToMemory(const CloneMCJ_NBTTagCompound *compound, unsigned char **dataOut, unsigned long *sizeOut);
CloneMCJ_NBTTagCompound *CloneMCJ_CompressedStreamTools_ReadCompoundFromMemory(const unsigned char *data, unsigned long size);
int CloneMCJ_CompressedStreamTools_WriteGzipFile(const CloneMCJ_NBTTagCompound *compound, const char *path);
CloneMCJ_NBTTagCompound *CloneMCJ_CompressedStreamTools_ReadGzipFile(const char *path);
int CloneMCJ_CompressedStreamTools_DeflateZlib(const unsigned char *input, unsigned long inputSize, unsigned char **output, unsigned long *outputSize);
int CloneMCJ_CompressedStreamTools_Inflate(const unsigned char *input, unsigned long inputSize, int gzipWrapped, unsigned char **output, unsigned long *outputSize);
int CloneMCJ_CompressedStreamTools_IsAvailable(void);

/* Native McRegion region and cache APIs. */
int CloneMCJ_RegionFile_Open(CloneMCJ_RegionFile *region, const char *path);
void CloneMCJ_RegionFile_Close(CloneMCJ_RegionFile *region);
int CloneMCJ_RegionFile_HasChunk(const CloneMCJ_RegionFile *region, int localX, int localZ);
int CloneMCJ_RegionFile_ReadChunk(CloneMCJ_RegionFile *region, int localX, int localZ, unsigned char **dataOut, unsigned long *sizeOut);
int CloneMCJ_RegionFile_WriteChunk(CloneMCJ_RegionFile *region, int localX, int localZ, const unsigned char *data, unsigned long size);
int CloneMCJ_RegionFile_WriteChunkEx(CloneMCJ_RegionFile *region, int localX, int localZ, const unsigned char *data, unsigned long size, int durable);
int CloneMCJ_RegionFile_Flush(CloneMCJ_RegionFile *region, int durable);
const char *CloneMCJ_RegionFile_ErrorText(int errorCode);
long CloneMCJ_RegionFile_GetSizeDelta(CloneMCJ_RegionFile *region);
void CloneMCJ_RegionFileChunkBuffer_Initialize(CloneMCJ_RegionFileChunkBuffer *buffer);
void CloneMCJ_RegionFileChunkBuffer_Destroy(CloneMCJ_RegionFileChunkBuffer *buffer);
int CloneMCJ_RegionFileChunkBuffer_Write(CloneMCJ_RegionFileChunkBuffer *buffer, const void *data, unsigned long size);
void CloneMCJ_RegionFileCache_Initialize(CloneMCJ_RegionFileCache *cache);
void CloneMCJ_RegionFileCache_SetLimit(CloneMCJ_RegionFileCache *cache, int limit);
void CloneMCJ_RegionFileCache_CloseAll(CloneMCJ_RegionFileCache *cache);
int CloneMCJ_RegionFileCache_FlushAll(CloneMCJ_RegionFileCache *cache, int durable);
CloneMCJ_RegionFile *CloneMCJ_RegionFileCache_GetRegion(CloneMCJ_RegionFileCache *cache, const char *worldDir, int chunkX, int chunkZ);
int CloneMCJ_RegionFileCache_HasChunk(CloneMCJ_RegionFileCache *cache, const char *worldDir, int chunkX, int chunkZ);
int CloneMCJ_RegionFileCache_ReadChunk(CloneMCJ_RegionFileCache *cache, const char *worldDir, int chunkX, int chunkZ, unsigned char **dataOut, unsigned long *sizeOut);
int CloneMCJ_RegionFileCache_WriteChunk(CloneMCJ_RegionFileCache *cache, const char *worldDir, int chunkX, int chunkZ, const unsigned char *data, unsigned long size);
int CloneMCJ_RegionFileCache_WriteChunkEx(CloneMCJ_RegionFileCache *cache, const char *worldDir, int chunkX, int chunkZ, const unsigned char *data, unsigned long size, int durable);
long CloneMCJ_RegionFileCache_GetSizeDelta(CloneMCJ_RegionFileCache *cache, const char *worldDir, int chunkX, int chunkZ);

/* ChunkLoader.java and McRegionChunkLoader.java. */
void CloneMCJ_ChunkLoader_Initialize(CloneMCJ_ChunkLoader *loader, const char *saveDir, int createIfNecessary);
void CloneMCJ_ChunkLoader_SetInstanceHooks(CloneMCJ_ChunkLoader *loader, const CloneMCJ_ChunkSerializationHooks *hooks);
void CloneMCJ_ChunkLoader_SetWorldTimePointer(CloneMCJ_ChunkLoader *loader, CloneMCJLong *worldTimePointer);
int CloneMCJ_ChunkLoader_Load(CloneMCJ_ChunkLoader *loader, CloneMCJ_Chunk *chunk, int chunkX, int chunkZ);
int CloneMCJ_ChunkLoader_Save(CloneMCJ_ChunkLoader *loader, const CloneMCJ_Chunk *chunk, CloneMCJLong worldTime);
void CloneMCJ_ChunkLoader_SetHooks(const CloneMCJ_ChunkSerializationHooks *hooks);
CloneMCJ_NBTTagCompound *CloneMCJ_ChunkLoader_StoreChunkInCompound(const CloneMCJ_Chunk *chunk, CloneMCJLong worldTime);
int CloneMCJ_ChunkLoader_LoadChunkFromCompound(CloneMCJ_Chunk *chunk, const CloneMCJ_NBTTagCompound *level, int expectedX, int expectedZ, CloneMCJLong worldTime);
void CloneMCJ_McRegionChunkLoader_Initialize(CloneMCJ_McRegionChunkLoader *loader, const char *worldDir, CloneMCJ_RegionFileCache *cache);
void CloneMCJ_McRegionChunkLoader_SetHooks(CloneMCJ_McRegionChunkLoader *loader, const CloneMCJ_ChunkSerializationHooks *hooks);
void CloneMCJ_McRegionChunkLoader_SetWorldTimePointer(CloneMCJ_McRegionChunkLoader *loader, CloneMCJLong *worldTimePointer);
void CloneMCJ_McRegionChunkLoader_SetWorldInfoPointer(CloneMCJ_McRegionChunkLoader *loader, CloneMCJ_WorldInfo *worldInfoPointer);
int CloneMCJ_McRegionChunkLoader_Load(CloneMCJ_McRegionChunkLoader *loader, CloneMCJ_Chunk *chunk, int chunkX, int chunkZ);
int CloneMCJ_McRegionChunkLoader_Save(CloneMCJ_McRegionChunkLoader *loader, const CloneMCJ_Chunk *chunk, CloneMCJLong worldTime);
int CloneMCJ_McRegionChunkLoader_SaveEx(CloneMCJ_McRegionChunkLoader *loader, const CloneMCJ_Chunk *chunk, CloneMCJLong worldTime, int force);
int CloneMCJ_McRegionChunkLoader_LoadCallback(CloneMCJ_Chunk *chunk, int chunkX, int chunkZ, void *userData);
int CloneMCJ_McRegionChunkLoader_SaveCallback(const CloneMCJ_Chunk *chunk, int force, void *userData);

/* Java interface adapters. */
CloneMCJ_IChunkLoader CloneMCJ_IChunkLoader_FromOldChunkLoader(CloneMCJ_ChunkLoader *loader);
CloneMCJ_IChunkLoader CloneMCJ_IChunkLoader_FromMcRegion(CloneMCJ_McRegionChunkLoader *loader);
CloneMCJ_ISaveHandler CloneMCJ_ISaveHandler_FromSaveHandler(CloneMCJ_SaveHandler *handler);
void CloneMCJ_ISaveFormat_Initialize(CloneMCJ_ISaveFormat *format, const char *baseDirectory);

/* SaveHandler.java, SaveFormatOld.java and session-lock/transaction support. */
int CloneMCJ_SaveHandler_Initialize(CloneMCJ_SaveHandler *handler, const char *baseDirectory, const char *worldName, int storePlayers);
void CloneMCJ_SaveHandler_Destroy(CloneMCJ_SaveHandler *handler);
int CloneMCJ_SaveHandler_CheckSessionLock(CloneMCJ_SaveHandler *handler);
int CloneMCJ_SaveHandler_LoadWorldInfo(CloneMCJ_SaveHandler *handler, CloneMCJ_WorldInfo *info);
int CloneMCJ_SaveHandler_SaveWorldInfo(CloneMCJ_SaveHandler *handler, const CloneMCJ_WorldInfo *info, const CloneMCJ_NBTTagCompound *playerTag);
int CloneMCJ_SaveHandler_VerifyWorldInfo(CloneMCJ_SaveHandler *handler, const CloneMCJ_WorldInfo *info, const CloneMCJ_NBTTagCompound *playerTag);
CloneMCJ_McRegionChunkLoader *CloneMCJ_SaveHandler_GetChunkLoader(CloneMCJ_SaveHandler *handler, int dimension);
const char *CloneMCJ_SaveHandler_GetLastError(const CloneMCJ_SaveHandler *handler);
int CloneMCJ_SaveHandler_FlushChunkData(CloneMCJ_SaveHandler *handler);
int CloneMCJ_SaveHandler_RunSelfTests(char *message, unsigned int messageCapacity);
int CloneMCJ_SaveFormatOld_LoadWorldInfo(const char *baseDirectory, const char *worldName, CloneMCJ_WorldInfo *info);
int CloneMCJ_SaveFormatOld_RenameWorld(const char *baseDirectory, const char *worldName, const char *newDisplayName);

/* Cross-subsystem world integration. */
int CloneMCJ_World_AttachSaveHandler(CloneMCJ_World *world, CloneMCJ_SaveHandler *handler, const char *levelName);
int CloneMCJ_World_SaveAll(CloneMCJ_World *world, int force);

/* Java metadata/registry symbols retained for all same-named C files. */
/* ChunkFile.java: class, 72 Java lines. */
void CloneMCJ_ChunkFile_Register(void);
const char *CloneMCJ_ChunkFile_JavaName(void);
const char *CloneMCJ_ChunkFile_AssignedFolder(void);
unsigned long CloneMCJ_ChunkFile_JavaSourceHash32(void);

/* ChunkFilePattern.java: class, 37 Java lines. */
void CloneMCJ_ChunkFilePattern_Register(void);
const char *CloneMCJ_ChunkFilePattern_JavaName(void);
const char *CloneMCJ_ChunkFilePattern_AssignedFolder(void);
unsigned long CloneMCJ_ChunkFilePattern_JavaSourceHash32(void);

/* ChunkFolderPattern.java: class, 43 Java lines. */
void CloneMCJ_ChunkFolderPattern_Register(void);
const char *CloneMCJ_ChunkFolderPattern_JavaName(void);
const char *CloneMCJ_ChunkFolderPattern_AssignedFolder(void);
unsigned long CloneMCJ_ChunkFolderPattern_JavaSourceHash32(void);

/* ChunkLoader.java: class, 256 Java lines. */
void CloneMCJ_ChunkLoader_Register(void);
const char *CloneMCJ_ChunkLoader_JavaName(void);
const char *CloneMCJ_ChunkLoader_AssignedFolder(void);
unsigned long CloneMCJ_ChunkLoader_JavaSourceHash32(void);

/* CompressedStreamTools.java: class, 69 Java lines. */
void CloneMCJ_CompressedStreamTools_Register(void);
const char *CloneMCJ_CompressedStreamTools_JavaName(void);
const char *CloneMCJ_CompressedStreamTools_AssignedFolder(void);
unsigned long CloneMCJ_CompressedStreamTools_JavaSourceHash32(void);

/* IChunkLoader.java: interface, 28 Java lines. */
void CloneMCJ_IChunkLoader_Register(void);
const char *CloneMCJ_IChunkLoader_JavaName(void);
const char *CloneMCJ_IChunkLoader_AssignedFolder(void);
unsigned long CloneMCJ_IChunkLoader_JavaSourceHash32(void);

/* ISaveFormat.java: interface, 33 Java lines. */
void CloneMCJ_ISaveFormat_Register(void);
const char *CloneMCJ_ISaveFormat_JavaName(void);
const char *CloneMCJ_ISaveFormat_AssignedFolder(void);
unsigned long CloneMCJ_ISaveFormat_JavaSourceHash32(void);

/* ISaveHandler.java: interface, 28 Java lines. */
void CloneMCJ_ISaveHandler_Register(void);
const char *CloneMCJ_ISaveHandler_JavaName(void);
const char *CloneMCJ_ISaveHandler_AssignedFolder(void);
unsigned long CloneMCJ_ISaveHandler_JavaSourceHash32(void);

/* MapStorage.java: class, 213 Java lines. */
void CloneMCJ_MapStorage_Register(void);
const char *CloneMCJ_MapStorage_JavaName(void);
const char *CloneMCJ_MapStorage_AssignedFolder(void);
unsigned long CloneMCJ_MapStorage_JavaSourceHash32(void);

/* McRegionChunkLoader.java: class, 93 Java lines. */
void CloneMCJ_McRegionChunkLoader_Register(void);
const char *CloneMCJ_McRegionChunkLoader_JavaName(void);
const char *CloneMCJ_McRegionChunkLoader_AssignedFolder(void);
unsigned long CloneMCJ_McRegionChunkLoader_JavaSourceHash32(void);

/* NBTBase.java: class, 160 Java lines. */
void CloneMCJ_NBTBase_Register(void);
const char *CloneMCJ_NBTBase_JavaName(void);
const char *CloneMCJ_NBTBase_AssignedFolder(void);
unsigned long CloneMCJ_NBTBase_JavaSourceHash32(void);

/* NBTTagByte.java: class, 48 Java lines. */
void CloneMCJ_NBTTagByte_Register(void);
const char *CloneMCJ_NBTTagByte_JavaName(void);
const char *CloneMCJ_NBTTagByte_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagByte_JavaSourceHash32(void);

/* NBTTagByteArray.java: class, 51 Java lines. */
void CloneMCJ_NBTTagByteArray_Register(void);
const char *CloneMCJ_NBTTagByteArray_JavaName(void);
const char *CloneMCJ_NBTTagByteArray_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagByteArray_JavaSourceHash32(void);

/* NBTTagCompound.java: class, 235 Java lines. */
void CloneMCJ_NBTTagCompound_Register(void);
const char *CloneMCJ_NBTTagCompound_JavaName(void);
const char *CloneMCJ_NBTTagCompound_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagCompound_JavaSourceHash32(void);

/* NBTTagDouble.java: class, 48 Java lines. */
void CloneMCJ_NBTTagDouble_Register(void);
const char *CloneMCJ_NBTTagDouble_JavaName(void);
const char *CloneMCJ_NBTTagDouble_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagDouble_JavaSourceHash32(void);

/* NBTTagEnd.java: class, 39 Java lines. */
void CloneMCJ_NBTTagEnd_Register(void);
const char *CloneMCJ_NBTTagEnd_JavaName(void);
const char *CloneMCJ_NBTTagEnd_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagEnd_JavaSourceHash32(void);

/* NBTTagFloat.java: class, 48 Java lines. */
void CloneMCJ_NBTTagFloat_Register(void);
const char *CloneMCJ_NBTTagFloat_JavaName(void);
const char *CloneMCJ_NBTTagFloat_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagFloat_JavaSourceHash32(void);

/* NBTTagInt.java: class, 48 Java lines. */
void CloneMCJ_NBTTagInt_Register(void);
const char *CloneMCJ_NBTTagInt_JavaName(void);
const char *CloneMCJ_NBTTagInt_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagInt_JavaSourceHash32(void);

/* NBTTagList.java: class, 85 Java lines. */
void CloneMCJ_NBTTagList_Register(void);
const char *CloneMCJ_NBTTagList_JavaName(void);
const char *CloneMCJ_NBTTagList_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagList_JavaSourceHash32(void);

/* NBTTagLong.java: class, 48 Java lines. */
void CloneMCJ_NBTTagLong_Register(void);
const char *CloneMCJ_NBTTagLong_JavaName(void);
const char *CloneMCJ_NBTTagLong_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagLong_JavaSourceHash32(void);

/* NBTTagShort.java: class, 48 Java lines. */
void CloneMCJ_NBTTagShort_Register(void);
const char *CloneMCJ_NBTTagShort_JavaName(void);
const char *CloneMCJ_NBTTagShort_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagShort_JavaSourceHash32(void);

/* NBTTagString.java: class, 55 Java lines. */
void CloneMCJ_NBTTagString_Register(void);
const char *CloneMCJ_NBTTagString_JavaName(void);
const char *CloneMCJ_NBTTagString_AssignedFolder(void);
unsigned long CloneMCJ_NBTTagString_JavaSourceHash32(void);

/* RegionFile.java: class, 335 Java lines. */
void CloneMCJ_RegionFile_Register(void);
const char *CloneMCJ_RegionFile_JavaName(void);
const char *CloneMCJ_RegionFile_AssignedFolder(void);
unsigned long CloneMCJ_RegionFile_JavaSourceHash32(void);

/* RegionFileCache.java: class, 95 Java lines. */
void CloneMCJ_RegionFileCache_Register(void);
const char *CloneMCJ_RegionFileCache_JavaName(void);
const char *CloneMCJ_RegionFileCache_AssignedFolder(void);
unsigned long CloneMCJ_RegionFileCache_JavaSourceHash32(void);

/* RegionFileChunkBuffer.java: class, 32 Java lines. */
void CloneMCJ_RegionFileChunkBuffer_Register(void);
const char *CloneMCJ_RegionFileChunkBuffer_JavaName(void);
const char *CloneMCJ_RegionFileChunkBuffer_AssignedFolder(void);
unsigned long CloneMCJ_RegionFileChunkBuffer_JavaSourceHash32(void);

/* SaveConverterMcRegion.java: class, 191 Java lines. */
void CloneMCJ_SaveConverterMcRegion_Register(void);
const char *CloneMCJ_SaveConverterMcRegion_JavaName(void);
const char *CloneMCJ_SaveConverterMcRegion_AssignedFolder(void);
unsigned long CloneMCJ_SaveConverterMcRegion_JavaSourceHash32(void);

/* SaveFormatComparator.java: class, 72 Java lines. */
void CloneMCJ_SaveFormatComparator_Register(void);
const char *CloneMCJ_SaveFormatComparator_JavaName(void);
const char *CloneMCJ_SaveFormatComparator_AssignedFolder(void);
unsigned long CloneMCJ_SaveFormatComparator_JavaSourceHash32(void);

/* SaveFormatOld.java: class, 159 Java lines. */
void CloneMCJ_SaveFormatOld_Register(void);
const char *CloneMCJ_SaveFormatOld_JavaName(void);
const char *CloneMCJ_SaveFormatOld_AssignedFolder(void);
unsigned long CloneMCJ_SaveFormatOld_JavaSourceHash32(void);

/* SaveHandler.java: class, 207 Java lines. */
void CloneMCJ_SaveHandler_Register(void);
const char *CloneMCJ_SaveHandler_JavaName(void);
const char *CloneMCJ_SaveHandler_AssignedFolder(void);
unsigned long CloneMCJ_SaveHandler_JavaSourceHash32(void);

/* SaveHandlerMP.java: class, 48 Java lines. */
void CloneMCJ_SaveHandlerMP_Register(void);
const char *CloneMCJ_SaveHandlerMP_JavaName(void);
const char *CloneMCJ_SaveHandlerMP_AssignedFolder(void);
unsigned long CloneMCJ_SaveHandlerMP_JavaSourceHash32(void);

/* SaveOldDir.java: class, 42 Java lines. */
void CloneMCJ_SaveOldDir_Register(void);
const char *CloneMCJ_SaveOldDir_JavaName(void);
const char *CloneMCJ_SaveOldDir_AssignedFolder(void);
unsigned long CloneMCJ_SaveOldDir_JavaSourceHash32(void);


#ifdef __cplusplus
}
#endif
#endif /* CLONEMC_JAVA_PORT_10_SAVE_H */
