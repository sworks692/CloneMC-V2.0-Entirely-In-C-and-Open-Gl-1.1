/* Java source: NBTTagByteArray.java; Source SHA-256: 02eda89aabc8d350348ec9d215a8c69d2d492bbb92b6e19dc9eb14c908502948; Java lines: 50. */
/* Direct C89 port of NBTTagByteArray.java. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
CloneMCJ_NBTTagByteArray *CloneMCJ_NBTTagByteArray_Create(const unsigned char *data, CloneMCJInt length)
{
    CloneMCJ_NBTBase *tag;if(length<0)return 0;tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_BYTE_ARRAY);if(!tag)return 0;tag->value.byteArray.length=length;if(length){tag->value.byteArray.data=(unsigned char*)malloc((unsigned long)length);if(!tag->value.byteArray.data){CloneMCJ_NBTBase_Free(tag);return 0;}if(data)memcpy(tag->value.byteArray.data,data,(unsigned long)length);else memset(tag->value.byteArray.data,0,(unsigned long)length);}return (CloneMCJ_NBTTagByteArray*)tag;
}

void CloneMCJ_NBTTagByteArray_Register(void) { }
const char *CloneMCJ_NBTTagByteArray_JavaName(void) { return "net.minecraft.src.NBTTagByteArray"; }
const char *CloneMCJ_NBTTagByteArray_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagByteArray_JavaSourceHash32(void) { return 0x02EDA89AUL; }
