/* Java source: SaveConverterMcRegion.java; Source SHA-256: 108980fb396533d59c16914b6198ef2600647eaba87f7ccb0f8cf4245bde5fde; Java lines: 190. */
/* Direct C89 port of SaveConverterMcRegion.java with crash-safe conversion. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
#if defined(_WIN32)
#include <io.h>
#include <direct.h>
#define SCM_RMDIR _rmdir
#else
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#define SCM_RMDIR rmdir
#endif
typedef struct SCM_ListTag{CloneMCJ_ChunkFile*items;int count,capacity;}SCM_List;
typedef struct SCM_DirListTag{char(*items)[CLONEMC_J_PATH_MAX];int count,capacity;}SCM_DirList;
static int SCM_Path(char*out,unsigned long cap,const char*a,const char*b){size_t na,nb;if(!out||!a||!b)return 0;na=strlen(a);nb=strlen(b);if(na+nb+2>cap)return 0;strcpy(out,a);if(na&&a[na-1]!='/'&&a[na-1]!='\\')strcat(out,"/");strcat(out,b);return 1;}
static int SCM_Push(SCM_List*l,const char*p){void*q;int nc;if(l->count>=l->capacity){nc=l->capacity?l->capacity*2:128;q=realloc(l->items,(size_t)nc*sizeof(*l->items));if(!q)return 0;l->items=(CloneMCJ_ChunkFile*)q;l->capacity=nc;}if(!CloneMCJ_ChunkFile_Initialize(&l->items[l->count],p))return 0;++l->count;return 1;}
static int SCM_PushDir(SCM_DirList*l,const char*p){void*q;int nc;if(l->count>=l->capacity){nc=l->capacity?l->capacity*2:32;q=realloc(l->items,(size_t)nc*CLONEMC_J_PATH_MAX);if(!q)return 0;l->items=(char(*)[CLONEMC_J_PATH_MAX])q;l->capacity=nc;}strncpy(l->items[l->count],p,CLONEMC_J_PATH_MAX-1);l->items[l->count][CLONEMC_J_PATH_MAX-1]=0;++l->count;return 1;}
static int SCM_IsDirPath(const char*p){
#if defined(_WIN32)
struct _finddata_t d;long h=_findfirst(p,&d);if(h==-1)return 0;_findclose(h);return (d.attrib&_A_SUBDIR)!=0;
#else
struct stat st;return stat(p,&st)==0&&S_ISDIR(st.st_mode);
#endif
}
static int SCM_ListNames(const char*dir,int wantDirs,int(*accept)(const char*),SCM_List*chunks,SCM_DirList*dirs,int depth){
#if defined(_WIN32)
struct _finddata_t fd;long h;char pat[CLONEMC_J_PATH_MAX],p[CLONEMC_J_PATH_MAX];if(!SCM_Path(pat,sizeof(pat),dir,"*"))return 0;h=_findfirst(pat,&fd);if(h==-1)return 1;do{if(!strcmp(fd.name,".")||!strcmp(fd.name,".."))continue;if(!SCM_Path(p,sizeof(p),dir,fd.name))continue;if(wantDirs){if((fd.attrib&_A_SUBDIR)&&accept(fd.name)){if(dirs&&!SCM_PushDir(dirs,p)){_findclose(h);return 0;}if(depth==0&&!SCM_ListNames(p,1,accept,chunks,0,1)){_findclose(h);return 0;}else if(depth==1&&!SCM_ListNames(p,0,CloneMCJ_ChunkFilePattern_Accept,chunks,0,2)){_findclose(h);return 0;}}}else if(!(fd.attrib&_A_SUBDIR)&&accept(fd.name)){if(!SCM_Push(chunks,p)){_findclose(h);return 0;}}}while(_findnext(h,&fd)==0);_findclose(h);
#else
DIR*d=opendir(dir);struct dirent*e;char p[CLONEMC_J_PATH_MAX];struct stat st;if(!d)return 1;while((e=readdir(d))!=0){if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;if(!SCM_Path(p,sizeof(p),dir,e->d_name)||stat(p,&st)!=0)continue;if(wantDirs){if(S_ISDIR(st.st_mode)&&accept(e->d_name)){if(dirs&&!SCM_PushDir(dirs,p)){closedir(d);return 0;}if(depth==0&&!SCM_ListNames(p,1,accept,chunks,0,1)){closedir(d);return 0;}else if(depth==1&&!SCM_ListNames(p,0,CloneMCJ_ChunkFilePattern_Accept,chunks,0,2)){closedir(d);return 0;}}}else if(S_ISREG(st.st_mode)&&accept(e->d_name)){if(!SCM_Push(chunks,p)){closedir(d);return 0;}}}closedir(d);
#endif
return 1;}
static int SCM_CompareQ(const void*a,const void*b){return CloneMCJ_ChunkFile_Compare((const CloneMCJ_ChunkFile*)a,(const CloneMCJ_ChunkFile*)b);}
static int SCM_Mod32(int v){int q=v>=0?v/32:-((31-v)/32);return v-q*32;}
static int SCM_ConvertList(CloneMCJ_SaveConverterMcRegion*c,const char*world,SCM_List*l,int*done,int total,CloneMCJ_ProgressCallback cb,void*u){int i,ok=1;unsigned char*raw;unsigned long n;CloneMCJ_NBTTagCompound*root;CloneMCJ_RegionFile*r;qsort(l->items,(size_t)l->count,sizeof(*l->items),SCM_CompareQ);for(i=0;i<l->count;++i){CloneMCJ_ChunkFile*f=&l->items[i];r=CloneMCJ_RegionFileCache_GetRegion(&c->regionCache,world,f->chunkX,f->chunkZ);if(!r){ok=0;break;}if(!CloneMCJ_RegionFile_HasChunk(r,SCM_Mod32(f->chunkX),SCM_Mod32(f->chunkZ))){root=CloneMCJ_CompressedStreamTools_ReadGzipFile(f->path);if(!root||!CloneMCJ_CompressedStreamTools_WriteCompoundToMemory(root,&raw,&n)){CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase*)root);ok=0;break;}CloneMCJ_NBTBase_Free((CloneMCJ_NBTBase*)root);if(!CloneMCJ_RegionFile_WriteChunk(r,SCM_Mod32(f->chunkX),SCM_Mod32(f->chunkZ),raw,n)){free(raw);ok=0;break;}free(raw);}++*done;if(cb)cb(total?(*done*100)/total:100,u);}CloneMCJ_RegionFileCache_CloseAll(&c->regionCache);return ok;}
static int SCM_DeleteTree(const char*p){int ok=1;
#if defined(_WIN32)
struct _finddata_t fd;long h;char pat[CLONEMC_J_PATH_MAX],q[CLONEMC_J_PATH_MAX];if(!SCM_Path(pat,sizeof(pat),p,"*"))return 0;h=_findfirst(pat,&fd);if(h!=-1){do{if(strcmp(fd.name,".")&&strcmp(fd.name,"..")&&SCM_Path(q,sizeof(q),p,fd.name)){if(fd.attrib&_A_SUBDIR)ok=SCM_DeleteTree(q)&&ok;else ok=(remove(q)==0)&&ok;}}while(_findnext(h,&fd)==0);_findclose(h);}if(SCM_RMDIR(p)!=0)ok=0;
#else
DIR*d=opendir(p);struct dirent*e;char q[CLONEMC_J_PATH_MAX];struct stat st;if(d){while((e=readdir(d))!=0){if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;if(!SCM_Path(q,sizeof(q),p,e->d_name))continue;if(stat(q,&st)==0&&S_ISDIR(st.st_mode))ok=SCM_DeleteTree(q)&&ok;else ok=(remove(q)==0)&&ok;}closedir(d);}if(SCM_RMDIR(p)!=0)ok=0;
#endif
return ok;}
void CloneMCJ_SaveConverterMcRegion_Initialize(CloneMCJ_SaveConverterMcRegion*c,const char*b){if(!c)return;memset(c,0,sizeof(*c));if(b)strncpy(c->baseDirectory,b,sizeof(c->baseDirectory)-1);CloneMCJ_RegionFileCache_Initialize(&c->regionCache);}
void CloneMCJ_SaveConverterMcRegion_Destroy(CloneMCJ_SaveConverterMcRegion*c){if(!c)return;CloneMCJ_RegionFileCache_CloseAll(&c->regionCache);memset(c,0,sizeof(*c));}
int CloneMCJ_SaveConverterMcRegion_ListWorldsAt(const char *baseDirectory,
    CloneMCJ_SaveFormatComparator **out,int *count){
CloneMCJ_SaveFormatComparator*a=0;int n=0,cap=0;
if(out)*out=0;if(count)*count=0;
if(!baseDirectory||!out||!count||!baseDirectory[0])return 0;
/* V127.6: the title-screen world browser must never parse level.dat files.
 * A damaged/truncated NBT file, stale session lock, unsupported compression
 * stream, or old Win9x filesystem edge case previously ran inside the GUI
 * click handler and could terminate the whole process.  Enumerate directories
 * only here.  Full metadata/chunk validation remains deferred until the user
 * actually opens that world, where the normal error screen can report failure. */
#if defined(_WIN32)
{
struct _finddata_t fd;long h;char pat[CLONEMC_J_PATH_MAX];
if(!SCM_Path(pat,sizeof(pat),baseDirectory,"*.*"))return 0;
h=_findfirst(pat,&fd);
if(h!=-1){
 do{
  CloneMCJ_SaveFormatComparator*grown;int nc;
  if(!(fd.attrib&_A_SUBDIR)||!strcmp(fd.name,".")||!strcmp(fd.name,".."))continue;
  if(n>=cap){nc=cap?cap*2:16;grown=(CloneMCJ_SaveFormatComparator*)realloc(a,(size_t)nc*sizeof(*a));
   if(!grown){free(a);_findclose(h);return 0;}a=grown;cap=nc;}
  CloneMCJ_SaveFormatComparator_Initialize(&a[n],fd.name,fd.name,(CloneMCJLong)0,(CloneMCJLong)0,0);
  ++n;
 }while(_findnext(h,&fd)==0);
 _findclose(h);
}
}
#else
{
DIR*d=opendir(baseDirectory);struct dirent*e;
if(d){while((e=readdir(d))!=0){char p[CLONEMC_J_PATH_MAX];CloneMCJ_SaveFormatComparator*grown;int nc;
 if(!strcmp(e->d_name,".")||!strcmp(e->d_name,"..")||
    !SCM_Path(p,sizeof(p),baseDirectory,e->d_name)||!SCM_IsDirPath(p))continue;
 if(n>=cap){nc=cap?cap*2:16;grown=(CloneMCJ_SaveFormatComparator*)realloc(a,(size_t)nc*sizeof(*a));
  if(!grown){free(a);closedir(d);return 0;}a=grown;cap=nc;}
 CloneMCJ_SaveFormatComparator_Initialize(&a[n],e->d_name,e->d_name,(CloneMCJLong)0,(CloneMCJLong)0,0);++n;
}closedir(d);}
}
#endif
*out=a;*count=n;return 1;}
int CloneMCJ_SaveConverterMcRegion_ListWorlds(CloneMCJ_SaveConverterMcRegion*c,
    CloneMCJ_SaveFormatComparator **out,int *count){
return CloneMCJ_SaveConverterMcRegion_ListWorldsAt(
    c?c->baseDirectory:(const char *)0,out,count);}
int CloneMCJ_SaveConverterMcRegion_IsOldMapFormat(CloneMCJ_SaveConverterMcRegion*c,const char*w){CloneMCJ_WorldInfo i;int r;if(!c||!w)return 0;memset(&i,0,sizeof(i));r=CloneMCJ_SaveFormatOld_LoadWorldInfo(c->baseDirectory,w,&i)&&i.saveVersion==0;CloneMCJ_WorldInfo_Destroy(&i);return r;}
int CloneMCJ_SaveConverterMcRegion_Convert(CloneMCJ_SaveConverterMcRegion*c,const char*w,CloneMCJ_ProgressCallback cb,void*u){char root[CLONEMC_J_PATH_MAX],hell[CLONEMC_J_PATH_MAX];SCM_List a,b;SCM_DirList da,db;int total,done=0,i,ok;CloneMCJ_WorldInfo wi;CloneMCJ_SaveOldDir sh;if(!c||!w||!SCM_Path(root,sizeof(root),c->baseDirectory,w))return 0;memset(&a,0,sizeof(a));memset(&b,0,sizeof(b));memset(&da,0,sizeof(da));memset(&db,0,sizeof(db));if(cb)cb(0,u);if(!SCM_ListNames(root,1,CloneMCJ_ChunkFolderPattern_Accept,&a,&da,0)){ok=0;goto end;}SCM_Path(hell,sizeof(hell),root,"DIM-1");if(SCM_IsDirPath(hell)&&!SCM_ListNames(hell,1,CloneMCJ_ChunkFolderPattern_Accept,&b,&db,0)){ok=0;goto end;}total=a.count+b.count;ok=SCM_ConvertList(c,root,&a,&done,total,cb,u);if(ok&&b.count)ok=SCM_ConvertList(c,hell,&b,&done,total,cb,u);if(!ok)goto end;memset(&wi,0,sizeof(wi));if(!CloneMCJ_SaveFormatOld_LoadWorldInfo(c->baseDirectory,w,&wi)){ok=0;goto end;}wi.saveVersion=19132;if(!CloneMCJ_SaveOldDir_Initialize(&sh,c->baseDirectory,w,0)){CloneMCJ_WorldInfo_Destroy(&wi);ok=0;goto end;}ok=CloneMCJ_SaveOldDir_SaveWorldInfo(&sh,&wi,0);CloneMCJ_SaveOldDir_Destroy(&sh);CloneMCJ_WorldInfo_Destroy(&wi);if(!ok)goto end;for(i=0;i<da.count;++i)SCM_DeleteTree(da.items[i]);for(i=0;i<db.count;++i)SCM_DeleteTree(db.items[i]);if(cb)cb(100,u);end:free(a.items);free(b.items);free(da.items);free(db.items);return ok;}
void CloneMCJ_SaveConverterMcRegion_Register(void){}
const char *CloneMCJ_SaveConverterMcRegion_JavaName(void){return "net.minecraft.src.SaveConverterMcRegion";}
const char *CloneMCJ_SaveConverterMcRegion_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_SaveConverterMcRegion_JavaSourceHash32(void){return 0x108980FBUL;}
