/* Java source: RegionFile.java; Source SHA-256: 1f5feb44662577c2962cc8b721287f11c1da0f866d4979b8a5eb0c130ffff5ca; Java lines: 334. */
/* C89 McRegion port with Java-compatible layout, header-last publication,
 * bounded durability, rollback, payload verification, and diagnostic errors. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#if defined(_WIN32)
#include <io.h>
#include <windows.h>
#else
#include <unistd.h>
#endif

static CloneMCJUInt RF_ReadBE32(const unsigned char*b){return ((CloneMCJUInt)b[0]<<24)|((CloneMCJUInt)b[1]<<16)|((CloneMCJUInt)b[2]<<8)|(CloneMCJUInt)b[3];}
static void RF_WriteBE32(unsigned char*b,CloneMCJUInt v){b[0]=(unsigned char)(v>>24);b[1]=(unsigned char)(v>>16);b[2]=(unsigned char)(v>>8);b[3]=(unsigned char)v;}
static int RF_Index(int x,int z){return x+(z<<5);}
static int RF_Bounds(int x,int z){return x<0||x>=32||z<0||z>=32;}
static void RF_SetError(CloneMCJ_RegionFile*r,int code,const char*operation,int x,int z){if(!r)return;r->lastError=code;r->lastSystemError=errno;r->lastChunkX=x;r->lastChunkZ=z;strncpy(r->lastOperation,operation?operation:"",sizeof(r->lastOperation)-1);r->lastOperation[sizeof(r->lastOperation)-1]='\0';}
static void RF_AbortOpen(CloneMCJ_RegionFile*r){FILE*f;unsigned char*map;if(!r)return;f=r->file;map=r->sectorFree;r->file=0;r->sectorFree=0;r->open=0;if(f)fclose(f);if(map)free(map);}
static int RF_FlushStdio(FILE*f){return f&&fflush(f)==0;}
static int RF_FlushDurable(FILE*f){
    if(!RF_FlushStdio(f))return 0;
    /* Beta's RegionFile is backed by RandomAccessFile.  Closing/flushing the
     * stream is the required transaction boundary; Java does not call
     * FileDescriptor.sync() after every chunk or on every region close.  Some
     * Windows 2000/XP storage drivers, redirected folders, Wine layers, and
     * antivirus filter drivers reject FlushFileBuffers/_commit even after the
     * buffered bytes can be read back correctly.  Treat the device-sync call as
     * a best-effort durability hint, never as a reason to report a false
     * "chunk payload flush failed" after verified stdio publication. */
#if defined(_WIN32)
    {
        int fd;
        long osHandle;
        fd=_fileno(f);
        if(fd>=0){
            osHandle=_get_osfhandle(fd);
            if(osHandle!=-1L){
                if(!FlushFileBuffers((HANDLE)osHandle))(void)_commit(fd);
            }else (void)_commit(fd);
        }
    }
#else
    (void)fsync(fileno(f));
#endif
    return 1;
}
static int RF_Truncate(FILE*f,unsigned long length){if(!f)return 0;if(!RF_FlushStdio(f))return 0;
#if defined(_WIN32)
return _chsize(_fileno(f),(long)length)==0;
#else
return ftruncate(fileno(f),(off_t)length)==0;
#endif
}
static int RF_WriteZeros(FILE*f,unsigned long n){unsigned char z[4096];unsigned long p;memset(z,0,sizeof(z));while(n){p=n>sizeof(z)?sizeof(z):n;if(fwrite(z,1,p,f)!=p)return 0;n-=p;}return 1;}
static long RF_FindFree(CloneMCJ_RegionFile*r,unsigned long needed){unsigned long start,run,i;start=2;run=0;for(i=2;i<r->sectorCount;++i){if(r->sectorFree[i]){if(!run)start=i;++run;if(run>=needed)return (long)start;}else run=0;}return -1;}
static void RF_ReleaseReservation(CloneMCJ_RegionFile*r,unsigned long sector,unsigned long count,unsigned long oldSectorCount,int appended){unsigned long j;if(!r)return;if(appended){if(RF_Truncate(r->file,oldSectorCount*4096UL)){r->sectorCount=oldSectorCount;if(r->sectorFree){unsigned char*shrunk=(unsigned char*)realloc(r->sectorFree,oldSectorCount?oldSectorCount:1UL);if(shrunk)r->sectorFree=shrunk;}}else RF_SetError(r,CLONEMC_J_REGION_ERROR_TRUNCATE,"rollback truncate",r->lastChunkX,r->lastChunkZ);}else if(r->sectorFree&&sector+count<=r->sectorCount){for(j=0;j<count;++j)r->sectorFree[sector+j]=1;}}
static int RF_VerifyPayload(CloneMCJ_RegionFile*r,unsigned long sector,
    unsigned long needed,const unsigned char*compressed,
    unsigned long compressedSize)
{
    unsigned char h[5];
    unsigned char copy[16384];
    CloneMCJUInt length;
    unsigned long offset;
    unsigned long part;
    if(!r||!r->file)return 0;
    if(fseek(r->file,(long)(sector*4096UL),SEEK_SET)!=0)return 0;
    if(fread(h,1,5,r->file)!=5)return 0;
    length=RF_ReadBE32(h);
    if(length!=compressedSize+1UL||h[4]!=2||
       length>needed*4096UL-4UL)return 0;
    /* Verify in fixed blocks.  The previous code allocated a second full
     * compressed chunk while the serializer and first compressed copy were
     * still live, a costly peak on fragmented Win9x heaps. */
    offset=0UL;
    while(offset<compressedSize){
        part=compressedSize-offset;
        if(part>sizeof(copy))part=sizeof(copy);
        if(fread(copy,1,part,r->file)!=part||
           memcmp(copy,compressed+offset,part)!=0)return 0;
        offset+=part;
    }
    return 1;
}

const char *CloneMCJ_RegionFile_ErrorText(int e){switch(e){case CLONEMC_J_REGION_ERROR_NONE:return "no error";case CLONEMC_J_REGION_ERROR_ARGUMENT:return "invalid region write arguments";case CLONEMC_J_REGION_ERROR_OPEN:return "region file could not be opened";case CLONEMC_J_REGION_ERROR_COMPRESS:return "chunk NBT compression failed";case CLONEMC_J_REGION_ERROR_TOO_LARGE:return "compressed chunk exceeds McRegion sector limit";case CLONEMC_J_REGION_ERROR_ALLOCATE:return "region sector allocation failed";case CLONEMC_J_REGION_ERROR_SEEK:return "region file seek failed";case CLONEMC_J_REGION_ERROR_WRITE_PAYLOAD:return "chunk payload write failed";case CLONEMC_J_REGION_ERROR_WRITE_PADDING:return "chunk sector padding failed";case CLONEMC_J_REGION_ERROR_FLUSH_PAYLOAD:return "chunk payload flush failed";case CLONEMC_J_REGION_ERROR_VERIFY_PAYLOAD:return "chunk payload verification failed";case CLONEMC_J_REGION_ERROR_WRITE_HEADER:return "region location header write failed";case CLONEMC_J_REGION_ERROR_FLUSH_HEADER:return "region header flush failed";case CLONEMC_J_REGION_ERROR_TRUNCATE:return "failed region append rollback";case CLONEMC_J_REGION_ERROR_READ:return "region chunk read failed";default:return "unknown region error";}}

int CloneMCJ_RegionFile_Open(CloneMCJ_RegionFile*r,const char*path){long size;unsigned char head[8192];unsigned long i,sector,number;CloneMCJUInt off;if(!r||!path)return 0;memset(r,0,sizeof(*r));strncpy(r->path,path,sizeof(r->path)-1);r->file=fopen(path,"r+b");if(!r->file)r->file=fopen(path,"w+b");if(!r->file){RF_SetError(r,CLONEMC_J_REGION_ERROR_OPEN,"open",0,0);return 0;}if(fseek(r->file,0,SEEK_END)!=0){RF_SetError(r,CLONEMC_J_REGION_ERROR_SEEK,"open seek",0,0);RF_AbortOpen(r);return 0;}size=ftell(r->file);if(size<0){RF_SetError(r,CLONEMC_J_REGION_ERROR_SEEK,"open length",0,0);RF_AbortOpen(r);return 0;}if(size<8192){fseek(r->file,0,SEEK_END);if(!RF_WriteZeros(r->file,(unsigned long)(8192-size))||!RF_FlushDurable(r->file)){RF_SetError(r,CLONEMC_J_REGION_ERROR_FLUSH_HEADER,"initialize header",0,0);RF_AbortOpen(r);return 0;}size=8192;}if((size&4095L)!=0){unsigned long pad=4096UL-(unsigned long)(size&4095L);fseek(r->file,0,SEEK_END);if(!RF_WriteZeros(r->file,pad)||!RF_FlushDurable(r->file)){RF_SetError(r,CLONEMC_J_REGION_ERROR_FLUSH_PAYLOAD,"align region",0,0);RF_AbortOpen(r);return 0;}size+=(long)pad;}r->sectorCount=(unsigned long)size/4096UL;r->sectorFree=(unsigned char*)malloc(r->sectorCount?r->sectorCount:1UL);if(!r->sectorFree){RF_SetError(r,CLONEMC_J_REGION_ERROR_ALLOCATE,"sector map",0,0);RF_AbortOpen(r);return 0;}memset(r->sectorFree,1,r->sectorCount);r->sectorFree[0]=r->sectorFree[1]=0;if(fseek(r->file,0,SEEK_SET)!=0||fread(head,1,sizeof(head),r->file)!=sizeof(head)){RF_SetError(r,CLONEMC_J_REGION_ERROR_READ,"read header",0,0);RF_AbortOpen(r);return 0;}for(i=0;i<1024;++i){off=RF_ReadBE32(head+i*4);r->offsets[i]=off;r->timestamps[i]=RF_ReadBE32(head+4096+i*4);sector=off>>8;number=off&255UL;if(sector>=2&&number>0&&sector+number<=r->sectorCount){unsigned long j;for(j=0;j<number;++j)r->sectorFree[sector+j]=0;}else if(off){r->offsets[i]=0;}}r->open=1;r->lastError=CLONEMC_J_REGION_ERROR_NONE;return 1;}

int CloneMCJ_RegionFile_Flush(CloneMCJ_RegionFile*r,int durable){int ok;if(!r||!r->file)return 0;if(!r->dirty)return 1;ok=durable?RF_FlushDurable(r->file):RF_FlushStdio(r->file);if(!ok){clearerr(r->file);ok=durable?RF_FlushDurable(r->file):RF_FlushStdio(r->file);if(ok)++r->writeRetries;}if(ok){r->dirty=0;r->lastError=0;r->lastSystemError=0;r->lastOperation[0]='\0';return 1;}RF_SetError(r,durable?CLONEMC_J_REGION_ERROR_FLUSH_HEADER:CLONEMC_J_REGION_ERROR_FLUSH_PAYLOAD,"flush region",r->lastChunkX,r->lastChunkZ);return 0;}
void CloneMCJ_RegionFile_Close(CloneMCJ_RegionFile*r){if(!r)return;if(r->file){
    /* Callers that require durability flush the cache before closing.  A close
     * must not perform a second device-level synchronization and turn an
     * already successful save into a false failure on legacy file systems. */
    RF_FlushStdio(r->file);fclose(r->file);}if(r->sectorFree)free(r->sectorFree);memset(r,0,sizeof(*r));}
int CloneMCJ_RegionFile_HasChunk(const CloneMCJ_RegionFile*r,int x,int z){return r&&!RF_Bounds(x,z)&&r->offsets[RF_Index(x,z)]!=0;}
int CloneMCJ_RegionFile_ReadChunk(CloneMCJ_RegionFile*r,int x,int z,unsigned char**out,unsigned long*outN){CloneMCJUInt off,length;unsigned long sector,count;unsigned char h[5],*compressed;int type,ok;if(out)*out=0;if(outN)*outN=0;if(!r||!r->open||RF_Bounds(x,z)||!out||!outN)return 0;off=r->offsets[RF_Index(x,z)];if(!off)return 0;sector=off>>8;count=off&255UL;if(sector+count>r->sectorCount||count==0){RF_SetError(r,CLONEMC_J_REGION_ERROR_READ,"invalid location",x,z);return 0;}if(fseek(r->file,(long)(sector*4096UL),SEEK_SET)!=0||fread(h,1,5,r->file)!=5){RF_SetError(r,CLONEMC_J_REGION_ERROR_READ,"read payload header",x,z);return 0;}length=RF_ReadBE32(h);type=h[4];if(length<1||length>count*4096UL-4UL||(type!=1&&type!=2)){RF_SetError(r,CLONEMC_J_REGION_ERROR_READ,"invalid payload header",x,z);return 0;}compressed=(unsigned char*)malloc((unsigned long)length-1UL);if(!compressed){RF_SetError(r,CLONEMC_J_REGION_ERROR_ALLOCATE,"read buffer",x,z);return 0;}if(fread(compressed,1,(unsigned long)length-1UL,r->file)!=(unsigned long)length-1UL){free(compressed);RF_SetError(r,CLONEMC_J_REGION_ERROR_READ,"read payload",x,z);return 0;}ok=CloneMCJ_CompressedStreamTools_Inflate(compressed,(unsigned long)length-1UL,type==1,out,outN);free(compressed);if(!ok)RF_SetError(r,CLONEMC_J_REGION_ERROR_READ,"inflate payload",x,z);return ok;}

int CloneMCJ_RegionFile_WriteChunkEx(CloneMCJ_RegionFile*r,int x,int z,const unsigned char*data,unsigned long n,int durable){unsigned char*comp,*newFree,h[5],loc[4],ts[4],oldLoc[4],oldTs[4];unsigned long compN,needed,newSector,oldSector,oldCount,j,pad,oldSectorCount;long found;int idx,appended,headerStarted,ok;if(!r||!r->open||RF_Bounds(x,z)||!data){if(r)RF_SetError(r,CLONEMC_J_REGION_ERROR_ARGUMENT,"write arguments",x,z);return 0;}++r->writeAttempts;r->lastChunkX=x;r->lastChunkZ=z;r->lastError=0;r->lastOperation[0]='\0';errno=0;if(!CloneMCJ_CompressedStreamTools_DeflateZlib(data,n,&comp,&compN)){RF_SetError(r,CLONEMC_J_REGION_ERROR_COMPRESS,"compress",x,z);return 0;}needed=(compN+5UL+4095UL)/4096UL;if(needed>=256UL){free(comp);RF_SetError(r,CLONEMC_J_REGION_ERROR_TOO_LARGE,"sector count",x,z);return 0;}idx=RF_Index(x,z);oldSector=r->offsets[idx]>>8;oldCount=r->offsets[idx]&255UL;oldSectorCount=r->sectorCount;found=RF_FindFree(r,needed);appended=found<0;headerStarted=0;if(appended){newSector=r->sectorCount;newFree=(unsigned char*)realloc(r->sectorFree,r->sectorCount+needed);if(!newFree){free(comp);RF_SetError(r,CLONEMC_J_REGION_ERROR_ALLOCATE,"grow sector map",x,z);return 0;}r->sectorFree=newFree;memset(r->sectorFree+r->sectorCount,0,needed);r->sectorCount+=needed;}else{newSector=(unsigned long)found;for(j=0;j<needed;++j)r->sectorFree[newSector+j]=0;}RF_WriteBE32(h,(CloneMCJUInt)(compN+1UL));h[4]=2;if(r->testFailStage==1||fseek(r->file,(long)(newSector*4096UL),SEEK_SET)!=0){free(comp);RF_SetError(r,CLONEMC_J_REGION_ERROR_SEEK,"seek payload",x,z);RF_ReleaseReservation(r,newSector,needed,oldSectorCount,appended);return 0;}if(r->testFailStage==2||fwrite(h,1,5,r->file)!=5||fwrite(comp,1,compN,r->file)!=compN){free(comp);RF_SetError(r,CLONEMC_J_REGION_ERROR_WRITE_PAYLOAD,"write payload",x,z);clearerr(r->file);RF_ReleaseReservation(r,newSector,needed,oldSectorCount,appended);return 0;}pad=needed*4096UL-(compN+5UL);if((r->testFailStage==3)||(pad&&!RF_WriteZeros(r->file,pad))){free(comp);RF_SetError(r,CLONEMC_J_REGION_ERROR_WRITE_PADDING,"write padding",x,z);clearerr(r->file);RF_ReleaseReservation(r,newSector,needed,oldSectorCount,appended);return 0;}if(r->testFailStage==4||!RF_FlushStdio(r->file)||(durable&&!RF_FlushDurable(r->file))){free(comp);RF_SetError(r,CLONEMC_J_REGION_ERROR_FLUSH_PAYLOAD,"flush payload",x,z);clearerr(r->file);RF_ReleaseReservation(r,newSector,needed,oldSectorCount,appended);return 0;}if(r->testFailStage==5||!RF_VerifyPayload(r,newSector,needed,comp,compN)){free(comp);RF_SetError(r,CLONEMC_J_REGION_ERROR_VERIFY_PAYLOAD,"verify payload",x,z);clearerr(r->file);RF_ReleaseReservation(r,newSector,needed,oldSectorCount,appended);return 0;}++r->verifiedWrites;free(comp);RF_WriteBE32(oldLoc,r->offsets[idx]);RF_WriteBE32(oldTs,r->timestamps[idx]);RF_WriteBE32(loc,(CloneMCJUInt)((newSector<<8)|needed));RF_WriteBE32(ts,(CloneMCJUInt)time(0));if(r->testFailStage==6||fseek(r->file,(long)(idx*4),SEEK_SET)!=0||fwrite(loc,1,4,r->file)!=4){RF_SetError(r,CLONEMC_J_REGION_ERROR_WRITE_HEADER,"write location",x,z);clearerr(r->file);RF_ReleaseReservation(r,newSector,needed,oldSectorCount,appended);return 0;}headerStarted=1;if(r->testFailStage==7||fseek(r->file,(long)(4096+idx*4),SEEK_SET)!=0||fwrite(ts,1,4,r->file)!=4){RF_SetError(r,CLONEMC_J_REGION_ERROR_WRITE_HEADER,"write timestamp",x,z);ok=0;}else ok=1;if(ok&&(r->testFailStage==8||!(durable?RF_FlushDurable(r->file):RF_FlushStdio(r->file)))){RF_SetError(r,CLONEMC_J_REGION_ERROR_FLUSH_HEADER,"flush header",x,z);ok=0;}if(!ok){if(headerStarted){clearerr(r->file);if(fseek(r->file,(long)(idx*4),SEEK_SET)==0)fwrite(oldLoc,1,4,r->file);if(fseek(r->file,(long)(4096+idx*4),SEEK_SET)==0)fwrite(oldTs,1,4,r->file);RF_FlushStdio(r->file);}RF_ReleaseReservation(r,newSector,needed,oldSectorCount,appended);return 0;}r->offsets[idx]=(CloneMCJUInt)((newSector<<8)|needed);r->timestamps[idx]=RF_ReadBE32(ts);if(oldSector>=2&&oldCount&&oldSector+oldCount<=r->sectorCount&&oldSector!=newSector){for(j=0;j<oldCount;++j)r->sectorFree[oldSector+j]=1;}r->sizeDelta+=(long)((r->sectorCount-oldSectorCount)*4096UL);r->dirty=durable?0:1;r->lastError=0;r->lastSystemError=0;r->lastOperation[0]='\0';return 1;}
int CloneMCJ_RegionFile_WriteChunk(CloneMCJ_RegionFile*r,int x,int z,const unsigned char*data,unsigned long n){return CloneMCJ_RegionFile_WriteChunkEx(r,x,z,data,n,0);}
long CloneMCJ_RegionFile_GetSizeDelta(CloneMCJ_RegionFile*r){long d;if(!r)return 0;d=r->sizeDelta;r->sizeDelta=0;return d;}
void CloneMCJ_RegionFile_Register(void) { }
const char *CloneMCJ_RegionFile_JavaName(void) { return "net.minecraft.src.RegionFile"; }
const char *CloneMCJ_RegionFile_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_RegionFile_JavaSourceHash32(void) { return 0x1F5FEB44UL; }
