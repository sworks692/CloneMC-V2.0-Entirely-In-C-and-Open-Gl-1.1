/* Java source: NBTTagDouble.java; Source SHA-256: 41f58083789cf51a4b3f8ef1c71db9eab463d5b501b12dafa949ee35bb25ffc8; Java lines: 47. */
/* Direct C89 port of NBTTagDouble.java. */
#include "clonemc_java_port_10_save.h"
CloneMCJ_NBTTagDouble *CloneMCJ_NBTTagDouble_Create(double value){CloneMCJ_NBTBase *tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_DOUBLE);if(tag){tag->value.doubleValue=value;}return (CloneMCJ_NBTTagDouble*)tag;}

void CloneMCJ_NBTTagDouble_Register(void) { }
const char *CloneMCJ_NBTTagDouble_JavaName(void) { return "net.minecraft.src.NBTTagDouble"; }
const char *CloneMCJ_NBTTagDouble_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagDouble_JavaSourceHash32(void) { return 0x41F58083UL; }
