/* Java source: SaveFormatComparator.java; Source SHA-256: 250fa64e72e978e6274063f29d09a08da7dcaa200be9b2c73dd317e73d27ded3; Java lines: 71. */
/* Direct C89 port of SaveFormatComparator.java. */
#include "clonemc_java_port_10_save.h"
#include <string.h>
void CloneMCJ_SaveFormatComparator_Initialize(CloneMCJ_SaveFormatComparator*e,const char*f,const char*d,CloneMCJLong t,CloneMCJLong s,int c){if(!e)return;memset(e,0,sizeof(*e));if(f)strncpy(e->fileName,f,sizeof(e->fileName)-1);if(d)strncpy(e->displayName,d,sizeof(e->displayName)-1);e->lastPlayed=t;e->sizeOnDisk=s;e->requiresConversion=(unsigned char)(c?1:0);}
int CloneMCJ_SaveFormatComparator_Compare(const CloneMCJ_SaveFormatComparator*a,const CloneMCJ_SaveFormatComparator*b){if(!a||!b)return 0;if(a->lastPlayed<b->lastPlayed)return 1;if(a->lastPlayed>b->lastPlayed)return -1;return strcmp(a->fileName,b->fileName);}
void CloneMCJ_SaveFormatComparator_Register(void){}
const char *CloneMCJ_SaveFormatComparator_JavaName(void){return "net.minecraft.src.SaveFormatComparator";}
const char *CloneMCJ_SaveFormatComparator_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_SaveFormatComparator_JavaSourceHash32(void){return 0x250FA64EUL;}
