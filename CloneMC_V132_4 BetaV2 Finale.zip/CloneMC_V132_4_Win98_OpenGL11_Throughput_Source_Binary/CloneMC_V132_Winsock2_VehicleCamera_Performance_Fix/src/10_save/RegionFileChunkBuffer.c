/* Java source: RegionFileChunkBuffer.java; Source SHA-256: b67d5a0af62042d873f86297ef68e09dfcfc09f8837269065e912156c8c1b1be; Java lines: 31. */
/* Direct C89 port of RegionFileChunkBuffer.java. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
#include <string.h>
void CloneMCJ_RegionFileChunkBuffer_Initialize(CloneMCJ_RegionFileChunkBuffer*b){if(b)memset(b,0,sizeof(*b));}
void CloneMCJ_RegionFileChunkBuffer_Destroy(CloneMCJ_RegionFileChunkBuffer*b){if(!b)return;if(b->data)free(b->data);memset(b,0,sizeof(*b));}
int CloneMCJ_RegionFileChunkBuffer_Write(CloneMCJ_RegionFileChunkBuffer*b,const void*d,unsigned long n){unsigned long cap;unsigned char*p;if(!b||(!d&&n))return 0;if(b->size+n>b->capacity){cap=b->capacity?b->capacity:4096UL;while(cap<b->size+n)cap*=2UL;p=(unsigned char*)realloc(b->data,cap);if(!p){b->error=1;return 0;}b->data=p;b->capacity=cap;}if(n)memcpy(b->data+b->size,d,n);b->size+=n;return 1;}

void CloneMCJ_RegionFileChunkBuffer_Register(void) { }
const char *CloneMCJ_RegionFileChunkBuffer_JavaName(void) { return "net.minecraft.src.RegionFileChunkBuffer"; }
const char *CloneMCJ_RegionFileChunkBuffer_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_RegionFileChunkBuffer_JavaSourceHash32(void) { return 0xB67D5A0AUL; }
