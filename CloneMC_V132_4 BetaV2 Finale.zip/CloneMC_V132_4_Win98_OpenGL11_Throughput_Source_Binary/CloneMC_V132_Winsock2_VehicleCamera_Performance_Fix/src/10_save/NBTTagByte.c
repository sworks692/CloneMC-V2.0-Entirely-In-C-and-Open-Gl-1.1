/* Java source: NBTTagByte.java; Source SHA-256: e735db1879079ff55d30e38ef8c32020b610046eb4a3045a584f134389547e80; Java lines: 47. */
/* Direct C89 port of NBTTagByte.java. */
#include "clonemc_java_port_10_save.h"
CloneMCJ_NBTTagByte *CloneMCJ_NBTTagByte_Create(CloneMCJByte value){CloneMCJ_NBTBase *tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_BYTE);if(tag){tag->value.byteValue=value;}return (CloneMCJ_NBTTagByte*)tag;}

void CloneMCJ_NBTTagByte_Register(void) { }
const char *CloneMCJ_NBTTagByte_JavaName(void) { return "net.minecraft.src.NBTTagByte"; }
const char *CloneMCJ_NBTTagByte_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagByte_JavaSourceHash32(void) { return 0xE735DB18UL; }
