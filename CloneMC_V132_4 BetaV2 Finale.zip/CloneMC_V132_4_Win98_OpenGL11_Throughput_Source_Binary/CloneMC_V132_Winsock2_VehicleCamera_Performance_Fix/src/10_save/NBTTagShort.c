/* Java source: NBTTagShort.java; Source SHA-256: eac6789fd0c2cf1d0f94b2fd327e7de1ca7f84a47970eb88ebb0590ac02a4eb8; Java lines: 47. */
/* Direct C89 port of NBTTagShort.java. */
#include "clonemc_java_port_10_save.h"
CloneMCJ_NBTTagShort *CloneMCJ_NBTTagShort_Create(CloneMCJShort value){CloneMCJ_NBTBase *tag=CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_SHORT);if(tag){tag->value.shortValue=value;}return (CloneMCJ_NBTTagShort*)tag;}

void CloneMCJ_NBTTagShort_Register(void) { }
const char *CloneMCJ_NBTTagShort_JavaName(void) { return "net.minecraft.src.NBTTagShort"; }
const char *CloneMCJ_NBTTagShort_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagShort_JavaSourceHash32(void) { return 0xEAC6789FUL; }
