/* Java source: NBTTagList.java; Source SHA-256: e8a5b35234b08761febadddafba3cd281d654aff96fffb094da6b057bf86ce98; Java lines: 84. */
/* Direct C89 port of NBTTagList.java. */
#include "clonemc_java_port_10_save.h"
#include <stdlib.h>
CloneMCJ_NBTTagList *CloneMCJ_NBTTagList_Create(void){return (CloneMCJ_NBTTagList*)CloneMCJ_NBTBase_Create(CLONEMC_J_NBT_TAG_LIST);}
int CloneMCJ_NBTTagList_Append(CloneMCJ_NBTTagList *list,CloneMCJ_NBTBase *tag)
{
    CloneMCJ_NBTBase **next;CloneMCJInt cap;if(!list||list->type!=CLONEMC_J_NBT_TAG_LIST||!tag)return 0;if(list->value.listValue.count&&list->value.listValue.tagType!=tag->type)return 0;if(!list->value.listValue.count)list->value.listValue.tagType=tag->type;if(list->value.listValue.count>=list->value.listValue.capacity){cap=list->value.listValue.capacity?list->value.listValue.capacity*2:8;next=(CloneMCJ_NBTBase**)realloc(list->value.listValue.items,(unsigned long)cap*sizeof(CloneMCJ_NBTBase*));if(!next)return 0;list->value.listValue.items=next;list->value.listValue.capacity=cap;}list->value.listValue.items[list->value.listValue.count++]=tag;return 1;
}
CloneMCJInt CloneMCJ_NBTTagList_Count(const CloneMCJ_NBTTagList *list){return list&&list->type==9?list->value.listValue.count:0;}
CloneMCJ_NBTBase *CloneMCJ_NBTTagList_Get(const CloneMCJ_NBTTagList *list,CloneMCJInt index){return list&&list->type==9&&index>=0&&index<list->value.listValue.count?list->value.listValue.items[index]:0;}
unsigned char CloneMCJ_NBTTagList_GetTagType(const CloneMCJ_NBTTagList *list){return list&&list->type==9?list->value.listValue.tagType:0;}

void CloneMCJ_NBTTagList_Register(void) { }
const char *CloneMCJ_NBTTagList_JavaName(void) { return "net.minecraft.src.NBTTagList"; }
const char *CloneMCJ_NBTTagList_AssignedFolder(void) { return "src/10_save"; }
unsigned long CloneMCJ_NBTTagList_JavaSourceHash32(void) { return 0xE8A5B352UL; }
