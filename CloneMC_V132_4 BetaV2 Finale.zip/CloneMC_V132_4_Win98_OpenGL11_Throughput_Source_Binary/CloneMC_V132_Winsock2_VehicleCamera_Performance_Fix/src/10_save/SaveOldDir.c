/* Java source: SaveOldDir.java; Source SHA-256: 4e93338353d1f2bacec176013e3b5f053a733c6fed542f78c38b6bf62e397b4e; Java lines: 41. */
/* Direct C89 port of SaveOldDir.java using McRegionChunkLoader. */
#include "clonemc_java_port_10_save.h"
int CloneMCJ_SaveOldDir_Initialize(CloneMCJ_SaveOldDir*h,const char*b,const char*n,int p){return h?CloneMCJ_SaveHandler_Initialize(&h->base,b,n,p):0;}
void CloneMCJ_SaveOldDir_Destroy(CloneMCJ_SaveOldDir*h){if(h)CloneMCJ_SaveHandler_Destroy(&h->base);}
CloneMCJ_McRegionChunkLoader *CloneMCJ_SaveOldDir_GetChunkLoader(CloneMCJ_SaveOldDir*h,int d){return h?CloneMCJ_SaveHandler_GetChunkLoader(&h->base,d):0;}
int CloneMCJ_SaveOldDir_SaveWorldInfo(CloneMCJ_SaveOldDir*h,CloneMCJ_WorldInfo*i,const CloneMCJ_NBTTagCompound*p){if(!h||!i)return 0;i->saveVersion=19132;return CloneMCJ_SaveHandler_SaveWorldInfo(&h->base,i,p);}
void CloneMCJ_SaveOldDir_Register(void){}
const char *CloneMCJ_SaveOldDir_JavaName(void){return "net.minecraft.src.SaveOldDir";}
const char *CloneMCJ_SaveOldDir_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_SaveOldDir_JavaSourceHash32(void){return 0x4E933383UL;}
