/* Java source: ChunkFilePattern.java; Source SHA-256: e205780323aa9618f609dae57f7bd594a89323d3d958c0b8e5bcf2faf5b747bf; Java lines: 36. */
/* Direct C89 port of ChunkFilePattern.java. */
#include "clonemc_java_port_10_save.h"
#include <ctype.h>
#include <string.h>
static int CFP_Base36Part(const char*s,int n){int i;if(!s||n<=0)return 0;i=0;if(s[0]=='-'){if(n==1)return 0;i=1;}for(;i<n;++i)if(!isdigit((unsigned char)s[i])&&(s[i]<'a'||s[i]>'z'))return 0;return 1;}
int CloneMCJ_ChunkFilePattern_Accept(const char*n){const char*a,*b,*e;if(!n||n[0]!='c'||n[1]!='.')return 0;a=n+2;b=strchr(a,'.');if(!b)return 0;e=strrchr(b+1,'.');if(!e||strcmp(e,".dat")!=0||e==b+1)return 0;return CFP_Base36Part(a,(int)(b-a))&&CFP_Base36Part(b+1,(int)(e-(b+1)));}
void CloneMCJ_ChunkFilePattern_Register(void){}
const char *CloneMCJ_ChunkFilePattern_JavaName(void){return "net.minecraft.src.ChunkFilePattern";}
const char *CloneMCJ_ChunkFilePattern_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_ChunkFilePattern_JavaSourceHash32(void){return 0xE2057803UL;}
