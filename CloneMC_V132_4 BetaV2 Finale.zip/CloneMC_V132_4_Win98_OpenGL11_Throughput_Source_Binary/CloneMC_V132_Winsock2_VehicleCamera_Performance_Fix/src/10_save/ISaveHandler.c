/* Java source: ISaveHandler.java; Source SHA-256: 4cc42bc4616f297ab1376da2e1f4c6f7aba09ad15e1cb48f3392755555ae3348; Java lines: 27. */
/* Direct C89 adapter for ISaveHandler.java. */
#include "clonemc_java_port_10_save.h"
static int ISH_Check(void*i){return CloneMCJ_SaveHandler_CheckSessionLock((CloneMCJ_SaveHandler*)i);}
static int ISH_Load(void*i,CloneMCJ_WorldInfo*w){return CloneMCJ_SaveHandler_LoadWorldInfo((CloneMCJ_SaveHandler*)i,w);}
static int ISH_Save(void*i,const CloneMCJ_WorldInfo*w,const CloneMCJ_NBTTagCompound*p){return CloneMCJ_SaveHandler_SaveWorldInfo((CloneMCJ_SaveHandler*)i,w,p);}
static CloneMCJ_IChunkLoader ISH_Loader(void*i,int d){return CloneMCJ_IChunkLoader_FromMcRegion(CloneMCJ_SaveHandler_GetChunkLoader((CloneMCJ_SaveHandler*)i,d));}
CloneMCJ_ISaveHandler CloneMCJ_ISaveHandler_FromSaveHandler(CloneMCJ_SaveHandler*h){CloneMCJ_ISaveHandler i;i.instance=h;i.checkSessionLock=ISH_Check;i.loadWorldInfo=ISH_Load;i.saveWorldInfo=ISH_Save;i.getChunkLoader=ISH_Loader;return i;}
void CloneMCJ_ISaveHandler_Register(void){}
const char *CloneMCJ_ISaveHandler_JavaName(void){return "net.minecraft.src.ISaveHandler";}
const char *CloneMCJ_ISaveHandler_AssignedFolder(void){return "src/10_save";}
unsigned long CloneMCJ_ISaveHandler_JavaSourceHash32(void){return 0x4CC42BC4UL;}
