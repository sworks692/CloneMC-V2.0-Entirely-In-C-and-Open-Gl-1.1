/*
 * CloneMC Java port scaffold: J_JsonEscapedString
 *
 * Java source: J_JsonEscapedString.java
 * Java type: class J_JsonEscapedString
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 914e861124af7062cc270c61a4381c279c1e0f2f9c7861d14bf4c3659a8de14d
 * Java lines: 23
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final String field_27031_a
 *
 * Java method/constructor inventory:
 * - public String toString()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonEscapedString_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonEscapedString_JavaName(void)
{
    return "net.minecraft.src.J_JsonEscapedString";
}

const char *CloneMCJ_J_JsonEscapedString_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonEscapedString_JavaSourceHash32(void)
{
    return 0x914E8611UL;
}
