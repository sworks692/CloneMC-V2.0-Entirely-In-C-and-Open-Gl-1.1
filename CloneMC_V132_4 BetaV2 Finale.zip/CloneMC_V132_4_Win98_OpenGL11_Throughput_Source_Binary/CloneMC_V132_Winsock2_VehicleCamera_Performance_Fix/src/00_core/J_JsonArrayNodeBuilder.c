/*
 * CloneMC Java port scaffold: J_JsonArrayNodeBuilder
 *
 * Java source: J_JsonArrayNodeBuilder.java
 * Java type: class J_JsonArrayNodeBuilder
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: J_JsonNodeBuilder
 * Source SHA-256: 7f1e66b1fb6620414fc876a38afe6fcc35264d5392e96d2843186c93a2faaf6f
 * Java lines: 45
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: J_JsonNodeBuilder, J_JsonNodeFactories, J_JsonRootNode, J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public J_JsonArrayNodeBuilder func_27240_a(J_JsonNodeBuilder j_jsonnodebuilder)
 * - public J_JsonRootNode func_27241_a()
 * - public J_JsonNode func_27234_b()
 * - private final List field_27242_a = new LinkedList()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonArrayNodeBuilder_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonArrayNodeBuilder_JavaName(void)
{
    return "net.minecraft.src.J_JsonArrayNodeBuilder";
}

const char *CloneMCJ_J_JsonArrayNodeBuilder_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonArrayNodeBuilder_JavaSourceHash32(void)
{
    return 0x7F1E66B1UL;
}
