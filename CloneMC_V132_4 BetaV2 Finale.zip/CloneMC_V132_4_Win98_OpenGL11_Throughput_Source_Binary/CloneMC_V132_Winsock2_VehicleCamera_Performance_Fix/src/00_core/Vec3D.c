/*
 * CloneMC Java port scaffold: Vec3D
 *
 * Java source: Vec3D.java
 * Java type: class Vec3D
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 2bee1b0cc34b782346d19b67b374bd61e53ea41cfe404fe17e2b186152d9c661
 * Java lines: 217
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 21
 * Referenced Java classes: MathHelper, d1
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static int nextVector = 0
 * - public double xCoord
 * - public double yCoord
 * - public double zCoord
 *
 * Java method/constructor inventory:
 * - public static Vec3D createVectorHelper(double d, double d1, double d2)
 * - public static void func_28215_a()
 * - public static void initialize()
 * - public static Vec3D createVector(double d, double d1, double d2)
 * - private Vec3D(double d, double d1, double d2)
 * - private Vec3D setComponents(double d, double d1, double d2)
 * - public Vec3D subtract(Vec3D vec3d)
 * - public Vec3D normalize()
 * - public Vec3D crossProduct(Vec3D vec3d)
 * - public Vec3D addVector(double d, double d1, double d2)
 * - public double distanceTo(Vec3D vec3d)
 * - public double squareDistanceTo(Vec3D vec3d)
 * - public double squareDistanceTo(double d, double d1, double d2)
 * - public double lengthVector()
 * - public Vec3D getIntermediateWithXValue(Vec3D vec3d, double d)
 * - public Vec3D getIntermediateWithYValue(Vec3D vec3d, double d)
 * - public Vec3D getIntermediateWithZValue(Vec3D vec3d, double d)
 * - public String toString()
 * - public void rotateAroundX(float f)
 * - public void rotateAroundY(float f)
 * - private static List vectorList = new ArrayList()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_Vec3D_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_Vec3D_JavaName(void)
{
    return "net.minecraft.src.Vec3D";
}

const char *CloneMCJ_Vec3D_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_Vec3D_JavaSourceHash32(void)
{
    return 0x2BEE1B0CUL;
}

CloneMCVec3D CloneMCVec3D_Create(double x, double y, double z)
{
    CloneMCVec3D result;
    if (x == -0.0) { x = 0.0; }
    if (y == -0.0) { y = 0.0; }
    if (z == -0.0) { z = 0.0; }
    result.xCoord = x; result.yCoord = y; result.zCoord = z;
    return result;
}

CloneMCVec3D CloneMCVec3D_Subtract(const CloneMCVec3D *self, const CloneMCVec3D *other)
{
    if (!self || !other) { return CloneMCVec3D_Create(0.0, 0.0, 0.0); }
    return CloneMCVec3D_Create(other->xCoord - self->xCoord,
                              other->yCoord - self->yCoord,
                              other->zCoord - self->zCoord);
}

CloneMCVec3D CloneMCVec3D_Normalize(const CloneMCVec3D *self)
{
    double length;
    if (!self) { return CloneMCVec3D_Create(0.0, 0.0, 0.0); }
    length = (double)CloneMCMathHelper_SqrtDouble(self->xCoord * self->xCoord +
             self->yCoord * self->yCoord + self->zCoord * self->zCoord);
    if (length < 0.0001) { return CloneMCVec3D_Create(0.0, 0.0, 0.0); }
    return CloneMCVec3D_Create(self->xCoord / length, self->yCoord / length,
                              self->zCoord / length);
}

CloneMCVec3D CloneMCVec3D_Cross(const CloneMCVec3D *self, const CloneMCVec3D *other)
{
    if (!self || !other) { return CloneMCVec3D_Create(0.0, 0.0, 0.0); }
    return CloneMCVec3D_Create(self->yCoord * other->zCoord - self->zCoord * other->yCoord,
                              self->zCoord * other->xCoord - self->xCoord * other->zCoord,
                              self->xCoord * other->yCoord - self->yCoord * other->xCoord);
}

CloneMCVec3D CloneMCVec3D_Add(const CloneMCVec3D *self, double x, double y, double z)
{
    if (!self) { return CloneMCVec3D_Create(x, y, z); }
    return CloneMCVec3D_Create(self->xCoord + x, self->yCoord + y, self->zCoord + z);
}

double CloneMCVec3D_SquareDistance(const CloneMCVec3D *self, const CloneMCVec3D *other)
{
    double x;
    double y;
    double z;
    if (!self || !other) { return 0.0; }
    x = other->xCoord - self->xCoord;
    y = other->yCoord - self->yCoord;
    z = other->zCoord - self->zCoord;
    return x * x + y * y + z * z;
}

double CloneMCVec3D_Distance(const CloneMCVec3D *self, const CloneMCVec3D *other)
{
    return (double)CloneMCMathHelper_SqrtDouble(CloneMCVec3D_SquareDistance(self, other));
}

double CloneMCVec3D_Length(const CloneMCVec3D *self)
{
    if (!self) { return 0.0; }
    return (double)CloneMCMathHelper_SqrtDouble(self->xCoord * self->xCoord +
        self->yCoord * self->yCoord + self->zCoord * self->zCoord);
}

static int CloneMCVec3D_Intermediate(const CloneMCVec3D *self, const CloneMCVec3D *other,
                                     double plane, int axis, CloneMCVec3D *result)
{
    double dx;
    double dy;
    double dz;
    double delta;
    double start;
    double fraction;
    if (!self || !other || !result) { return 0; }
    dx = other->xCoord - self->xCoord;
    dy = other->yCoord - self->yCoord;
    dz = other->zCoord - self->zCoord;
    delta = axis == 0 ? dx : (axis == 1 ? dy : dz);
    start = axis == 0 ? self->xCoord : (axis == 1 ? self->yCoord : self->zCoord);
    if (delta * delta < 1.0000000116860974E-007) { return 0; }
    fraction = (plane - start) / delta;
    if (fraction < 0.0 || fraction > 1.0) { return 0; }
    *result = CloneMCVec3D_Create(self->xCoord + dx * fraction,
                                  self->yCoord + dy * fraction,
                                  self->zCoord + dz * fraction);
    return 1;
}

int CloneMCVec3D_IntermediateX(const CloneMCVec3D *self, const CloneMCVec3D *other,
                              double x, CloneMCVec3D *result)
{ return CloneMCVec3D_Intermediate(self, other, x, 0, result); }

int CloneMCVec3D_IntermediateY(const CloneMCVec3D *self, const CloneMCVec3D *other,
                              double y, CloneMCVec3D *result)
{ return CloneMCVec3D_Intermediate(self, other, y, 1, result); }

int CloneMCVec3D_IntermediateZ(const CloneMCVec3D *self, const CloneMCVec3D *other,
                              double z, CloneMCVec3D *result)
{ return CloneMCVec3D_Intermediate(self, other, z, 2, result); }

void CloneMCVec3D_RotateX(CloneMCVec3D *self, float radians)
{
    float cosine;
    float sine;
    double y;
    double z;
    if (!self) { return; }
    cosine = CloneMCMathHelper_Cos(radians);
    sine = CloneMCMathHelper_Sin(radians);
    y = self->yCoord * (double)cosine + self->zCoord * (double)sine;
    z = self->zCoord * (double)cosine - self->yCoord * (double)sine;
    self->yCoord = y; self->zCoord = z;
}

void CloneMCVec3D_RotateY(CloneMCVec3D *self, float radians)
{
    float cosine;
    float sine;
    double x;
    double z;
    if (!self) { return; }
    cosine = CloneMCMathHelper_Cos(radians);
    sine = CloneMCMathHelper_Sin(radians);
    x = self->xCoord * (double)cosine + self->zCoord * (double)sine;
    z = self->zCoord * (double)cosine - self->xCoord * (double)sine;
    self->xCoord = x; self->zCoord = z;
}
