/*
 * CloneMC Java port scaffold: J_SajParser
 *
 * Java source: J_SajParser.java
 * Java type: class J_SajParser
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: c3a37b01c603093d98ca60ccfad72718cb3aaf8831b29786a40b3153cb6267aa
 * Java lines: 534
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 18
 * Referenced Java classes: J_InvalidSyntaxException, J_PositionTrackingPushbackReader, J_JsonListener, IOException
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public J_SajParser()
 * - public void func_27463_a(Reader reader, J_JsonListener j_jsonlistener)
 * - private void func_27455_a(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader, J_JsonListener j_jsonlistener)
 * - private void func_27453_b(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader, J_JsonListener j_jsonlistener)
 * - private void func_27449_c(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader, J_JsonListener j_jsonlistener)
 * - private void func_27464_d(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader, J_JsonListener j_jsonlistener)
 * - private String func_27459_a(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private String func_27451_b(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private char func_27460_c(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private char func_27458_d(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private String func_27456_e(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private String func_27462_f(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private String func_27454_g(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private String func_27461_h(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private String func_27452_i(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private char func_27457_j(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private int func_27450_k(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 * - private int func_27448_l(J_PositionTrackingPushbackReader j_positiontrackingpushbackreader)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_SajParser_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_SajParser_JavaName(void)
{
    return "net.minecraft.src.J_SajParser";
}

const char *CloneMCJ_J_SajParser_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_SajParser_JavaSourceHash32(void)
{
    return 0xC3A37B01UL;
}
