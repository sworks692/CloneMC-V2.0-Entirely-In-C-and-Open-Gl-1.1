/*
 * CloneMC Java port scaffold: J_JsonNodeBuilders
 *
 * Java source: J_JsonNodeBuilders.java
 * Java type: class J_JsonNodeBuilders
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 99e2e5d67ee066328e59ec5c20fae5965e314e9460e6528d7126bc1fa1d8309a
 * Java lines: 54
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: J_JsonNullNodeBuilder, J_JsonTrueNodeBuilder, J_JsonFalseNodeBuilder, J_JsonNumberNodeBuilder, J_JsonStringNodeBuilder, J_JsonObjectNodeBuilder, J_JsonArrayNodeBuilder, J_JsonNodeBuilder
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - private J_JsonNodeBuilders()
 * - public static J_JsonNodeBuilder func_27248_a()
 * - public static J_JsonNodeBuilder func_27251_b()
 * - public static J_JsonNodeBuilder func_27252_c()
 * - public static J_JsonNodeBuilder func_27250_a(String s)
 * - public static J_JsonStringNodeBuilder func_27254_b(String s)
 * - public static J_JsonObjectNodeBuilder func_27253_d()
 * - public static J_JsonArrayNodeBuilder func_27249_e()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNodeBuilders_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNodeBuilders_JavaName(void)
{
    return "net.minecraft.src.J_JsonNodeBuilders";
}

const char *CloneMCJ_J_JsonNodeBuilders_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNodeBuilders_JavaSourceHash32(void)
{
    return 0x99E2E5D6UL;
}
