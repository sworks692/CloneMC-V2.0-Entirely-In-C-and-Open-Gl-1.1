/*
 * CloneMC Java port scaffold: J_JsonStringNode
 *
 * Java source: J_JsonStringNode.java
 * Java type: class J_JsonStringNode
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: J_JsonNode
 * Implements: Comparable
 * Source SHA-256: c6497ed1d410f797f025a6267cb95c2dbcc8ad2044fb395332d2889262518800
 * Java lines: 87
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: J_JsonNode, EnumJsonNodeType
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final String field_27224_a
 *
 * Java method/constructor inventory:
 * - public EnumJsonNodeType func_27218_a()
 * - public String func_27216_b()
 * - public Map func_27214_c()
 * - public List func_27215_d()
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - public String toString()
 * - public int func_27223_a(J_JsonStringNode j_jsonstringnode)
 * - public int compareTo(Object obj)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonStringNode_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonStringNode_JavaName(void)
{
    return "net.minecraft.src.J_JsonStringNode";
}

const char *CloneMCJ_J_JsonStringNode_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonStringNode_JavaSourceHash32(void)
{
    return 0xC6497ED1UL;
}
