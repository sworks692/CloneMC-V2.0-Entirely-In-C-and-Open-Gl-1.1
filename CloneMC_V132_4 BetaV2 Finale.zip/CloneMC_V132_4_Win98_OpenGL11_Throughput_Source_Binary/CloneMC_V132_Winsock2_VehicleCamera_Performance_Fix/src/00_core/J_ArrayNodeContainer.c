/*
 * CloneMC Java port scaffold: J_ArrayNodeContainer
 *
 * Java source: J_ArrayNodeContainer.java
 * Java type: class J_ArrayNodeContainer
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 71b0b9ef8247532cdc9f8c6653f609925d03720f37fdd2a7cab3f5fe7bdc80ed
 * Java lines: 36
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: J_NodeContainer, J_JsonArrayNodeBuilder, J_JsonListenerToJdomAdapter, J_JsonNodeBuilder, J_JsonFieldBuilder
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public void func_27290_a(J_JsonNodeBuilder j_jsonnodebuilder)
 * - public void func_27289_a(J_JsonFieldBuilder j_jsonfieldbuilder)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_ArrayNodeContainer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_ArrayNodeContainer_JavaName(void)
{
    return "net.minecraft.src.J_ArrayNodeContainer";
}

const char *CloneMCJ_J_ArrayNodeContainer_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_ArrayNodeContainer_JavaSourceHash32(void)
{
    return 0x71B0B9EFUL;
}
