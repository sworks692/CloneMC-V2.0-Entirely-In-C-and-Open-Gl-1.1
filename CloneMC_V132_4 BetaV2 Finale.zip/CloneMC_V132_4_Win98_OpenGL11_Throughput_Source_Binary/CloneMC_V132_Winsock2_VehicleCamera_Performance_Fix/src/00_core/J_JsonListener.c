/*
 * CloneMC Java port scaffold: J_JsonListener
 *
 * Java source: J_JsonListener.java
 * Java type: interface J_JsonListener
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 60730cd5b77e1a109b52dd8a5400736af96b858d5ccb56cfe82a5e15e2fbed1a
 * Java lines: 37
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 13
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract void func_27195_b()
 * - public abstract void func_27204_c()
 * - public abstract void func_27200_d()
 * - public abstract void func_27197_e()
 * - public abstract void func_27194_f()
 * - public abstract void func_27203_g()
 * - public abstract void func_27205_a(String s)
 * - public abstract void func_27199_h()
 * - public abstract void func_27198_c(String s)
 * - public abstract void func_27201_b(String s)
 * - public abstract void func_27196_i()
 * - public abstract void func_27193_j()
 * - public abstract void func_27202_k()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonListener_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonListener_JavaName(void)
{
    return "net.minecraft.src.J_JsonListener";
}

const char *CloneMCJ_J_JsonListener_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonListener_JavaSourceHash32(void)
{
    return 0x60730CD5UL;
}
