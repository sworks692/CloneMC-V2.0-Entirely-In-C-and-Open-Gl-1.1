/*
 * CloneMC Java port scaffold: J_JsonFalseNodeBuilder
 *
 * Java source: J_JsonFalseNodeBuilder.java
 * Java type: class J_JsonFalseNodeBuilder
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 01df7f716786588f2ed8f412efe866c95ca331bbe5b5c1e33d26cc699f452f10
 * Java lines: 24
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: J_JsonNodeBuilder, J_JsonNodeFactories, J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public J_JsonNode func_27234_b()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonFalseNodeBuilder_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonFalseNodeBuilder_JavaName(void)
{
    return "net.minecraft.src.J_JsonFalseNodeBuilder";
}

const char *CloneMCJ_J_JsonFalseNodeBuilder_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonFalseNodeBuilder_JavaSourceHash32(void)
{
    return 0x01DF7F71UL;
}
