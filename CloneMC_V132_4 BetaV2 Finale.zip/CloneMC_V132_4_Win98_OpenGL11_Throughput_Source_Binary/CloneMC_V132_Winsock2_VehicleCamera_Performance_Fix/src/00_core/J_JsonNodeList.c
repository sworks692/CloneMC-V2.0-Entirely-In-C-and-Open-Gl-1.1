/*
 * CloneMC Java port scaffold: J_JsonNodeList
 *
 * Java source: J_JsonNodeList.java
 * Java type: class J_JsonNodeList
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 8b911ae1ea06aab7e4ce0237a1cb3a5224ebdf0d16446acf5aa7b4f65cd0671a
 * Java lines: 30
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNodeList_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNodeList_JavaName(void)
{
    return "net.minecraft.src.J_JsonNodeList";
}

const char *CloneMCJ_J_JsonNodeList_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNodeList_JavaSourceHash32(void)
{
    return 0x8B911AE1UL;
}
