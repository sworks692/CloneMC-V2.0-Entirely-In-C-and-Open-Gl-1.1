/*
 * CloneMC Java port scaffold: J_JsonFieldBuilder
 *
 * Java source: J_JsonFieldBuilder.java
 * Java type: class J_JsonFieldBuilder
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 8eea8908aad60885796dcdd0f305683197d933fde265a03f42c18636934a5980
 * Java lines: 48
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: J_JsonNodeBuilder, J_JsonStringNode, J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private J_JsonNodeBuilder field_27306_a
 * - private J_JsonNodeBuilder field_27305_b
 *
 * Java method/constructor inventory:
 * - private J_JsonFieldBuilder()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonFieldBuilder_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonFieldBuilder_JavaName(void)
{
    return "net.minecraft.src.J_JsonFieldBuilder";
}

const char *CloneMCJ_J_JsonFieldBuilder_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonFieldBuilder_JavaSourceHash32(void)
{
    return 0x8EEA8908UL;
}
