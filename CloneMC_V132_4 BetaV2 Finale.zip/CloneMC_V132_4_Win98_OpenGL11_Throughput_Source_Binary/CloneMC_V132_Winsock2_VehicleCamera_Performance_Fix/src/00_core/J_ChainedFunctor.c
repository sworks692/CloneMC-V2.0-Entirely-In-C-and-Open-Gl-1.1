/*
 * CloneMC Java port scaffold: J_ChainedFunctor
 *
 * Java source: J_ChainedFunctor.java
 * Java type: class J_ChainedFunctor
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 8ed2e6607ace94a1f439ba56e4b7054c823eceef6d8afc8e5246afd038d594a9
 * Java lines: 62
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: J_Functor, J_JsonNodeSelector, J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final J_JsonNodeSelector field_27062_a
 * - private final J_JsonNodeSelector field_27061_b
 *
 * Java method/constructor inventory:
 * - public boolean func_27058_a(Object obj)
 * - public Object func_27059_b(Object obj)
 * - public String func_27060_a()
 * - public String toString()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_ChainedFunctor_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_ChainedFunctor_JavaName(void)
{
    return "net.minecraft.src.J_ChainedFunctor";
}

const char *CloneMCJ_J_ChainedFunctor_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_ChainedFunctor_JavaSourceHash32(void)
{
    return 0x8ED2E660UL;
}
