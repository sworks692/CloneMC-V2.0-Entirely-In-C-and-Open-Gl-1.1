/*
 * CloneMC Java port scaffold: J_JsonNumberNodeBuilder
 *
 * Java source: J_JsonNumberNodeBuilder.java
 * Java type: class J_JsonNumberNodeBuilder
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 029ba5b0fa743b2197783324790845f93bf918f459cdddd433e35ecc9a45d966
 * Java lines: 27
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: J_JsonNodeBuilder, J_JsonNodeFactories, J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final J_JsonNode field_27239_a
 *
 * Java method/constructor inventory:
 * - public J_JsonNode func_27234_b()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNumberNodeBuilder_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNumberNodeBuilder_JavaName(void)
{
    return "net.minecraft.src.J_JsonNumberNodeBuilder";
}

const char *CloneMCJ_J_JsonNumberNodeBuilder_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNumberNodeBuilder_JavaSourceHash32(void)
{
    return 0x029BA5B0UL;
}
