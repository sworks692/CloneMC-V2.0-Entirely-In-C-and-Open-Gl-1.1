/*
 * CloneMC Java port scaffold: J_JsonObject
 *
 * Java source: J_JsonObject.java
 * Java type: class J_JsonObject
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 932c90ed8ee55bac7c4683d96ef97d38c2ae9ddd9b2d2d05cc89d200d97556dd
 * Java lines: 68
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: J_JsonRootNode, EnumJsonNodeType
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final Map field_27222_a
 *
 * Java method/constructor inventory:
 * - public Map func_27214_c()
 * - public EnumJsonNodeType func_27218_a()
 * - public String func_27216_b()
 * - public List func_27215_d()
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - public String toString()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonObject_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonObject_JavaName(void)
{
    return "net.minecraft.src.J_JsonObject";
}

const char *CloneMCJ_J_JsonObject_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonObject_JavaSourceHash32(void)
{
    return 0x932C90EDUL;
}
