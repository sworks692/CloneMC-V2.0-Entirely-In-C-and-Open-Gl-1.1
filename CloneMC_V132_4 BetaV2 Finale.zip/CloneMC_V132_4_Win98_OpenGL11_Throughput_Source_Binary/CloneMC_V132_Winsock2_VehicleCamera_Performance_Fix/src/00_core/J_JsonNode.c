/*
 * CloneMC Java port scaffold: J_JsonNode
 *
 * Java source: J_JsonNode.java
 * Java type: class J_JsonNode
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 0f37033bd06ea0e864fdb4349582d07fc0ca42d38caf247fb637bf32f1e273f6
 * Java lines: 53
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 7
 * Referenced Java classes: J_JsonNodeSelectors, J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException, J_JsonNodeSelector, J_JsonNodeFactories, J_JsonNodeDoesNotMatchPathElementsException, EnumJsonNodeType, this, try, aobj, j_jsonnode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract EnumJsonNodeType func_27218_a()
 * - public abstract String func_27216_b()
 * - public abstract Map func_27214_c()
 * - public abstract List func_27215_d()
 * - public final String func_27213_a(Object aobj[])
 * - public final List func_27217_b(Object aobj[])
 * - private Object func_27219_a(J_JsonNodeSelector j_jsonnodeselector, J_JsonNode j_jsonnode, Object aobj[])
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNode_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNode_JavaName(void)
{
    return "net.minecraft.src.J_JsonNode";
}

const char *CloneMCJ_J_JsonNode_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNode_JavaSourceHash32(void)
{
    return 0x0F37033BUL;
}
