/*
 * CloneMC Java port scaffold: J_JsonNodeDoesNotMatchPathElementsException
 *
 * Java source: J_JsonNodeDoesNotMatchPathElementsException.java
 * Java type: class J_JsonNodeDoesNotMatchPathElementsException
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: J_JsonNodeDoesNotMatchJsonNodeSelectorException
 * Implements: (none declared)
 * Source SHA-256: fc8e1dd8d9c1f1f59ce7e3c59ea4a819786bb6ea4592781b22ed5e139b923e48
 * Java lines: 59
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: J_JsonNodeDoesNotMatchJsonNodeSelectorException, J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException, J_JsonFormatter, J_CompactJsonFormatter, J_JsonRootNode, aobj
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - private J_JsonNodeDoesNotMatchPathElementsException(J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException j_jsonnodedoesnotmatchchainedjsonnodeselectorexception, Object aobj[], J_JsonRootNode j_jsonrootnode)
 * - private static String func_27318_b(J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException j_jsonnodedoesnotmatchchainedjsonnodeselectorexception, Object aobj[], J_JsonRootNode j_jsonrootnode)
 * - private static String func_27317_a(Object aobj[])
 * - private static final J_JsonFormatter field_27320_a = new J_CompactJsonFormatter()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_JavaName(void)
{
    return "net.minecraft.src.J_JsonNodeDoesNotMatchPathElementsException";
}

const char *CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_JavaSourceHash32(void)
{
    return 0xFC8E1DD8UL;
}
