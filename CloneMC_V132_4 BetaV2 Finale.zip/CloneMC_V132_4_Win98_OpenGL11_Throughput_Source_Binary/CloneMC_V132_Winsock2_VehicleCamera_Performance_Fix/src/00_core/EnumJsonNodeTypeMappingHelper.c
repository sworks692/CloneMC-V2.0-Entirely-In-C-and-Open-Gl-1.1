/*
 * CloneMC Java port scaffold: EnumJsonNodeTypeMappingHelper
 *
 * Java source: EnumJsonNodeTypeMappingHelper.java
 * Java type: class EnumJsonNodeTypeMappingHelper
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: fd0c1c8436df9159cc8b2d306f52de1de05a869466c919c57174ba0599ab92e4
 * Java lines: 56
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: EnumJsonNodeType, static, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_EnumJsonNodeTypeMappingHelper_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumJsonNodeTypeMappingHelper_JavaName(void)
{
    return "net.minecraft.src.EnumJsonNodeTypeMappingHelper";
}

const char *CloneMCJ_EnumJsonNodeTypeMappingHelper_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_EnumJsonNodeTypeMappingHelper_JavaSourceHash32(void)
{
    return 0xFD0C1C84UL;
}
