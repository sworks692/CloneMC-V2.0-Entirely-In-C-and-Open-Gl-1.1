/*
 * CloneMC Java port scaffold: J_JsonListenerToJdomAdapter
 *
 * Java source: J_JsonListenerToJdomAdapter.java
 * Java type: class J_JsonListenerToJdomAdapter
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: f4835cdcafdf3c55a98c841f7c661e49a0844247e5035f4ff16a774e58b91ca6
 * Java lines: 115
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 16
 * Referenced Java classes: J_JsonListener, J_JsonNodeBuilder, J_JsonRootNode, J_JsonNodeBuilders, J_ArrayNodeContainer, J_ObjectNodeContainer, J_JsonFieldBuilder, J_NodeContainer, J_FieldNodeContainer
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private J_JsonNodeBuilder field_27209_b
 *
 * Java method/constructor inventory:
 * - public void func_27195_b()
 * - public void func_27204_c()
 * - public void func_27200_d()
 * - public void func_27197_e()
 * - public void func_27194_f()
 * - public void func_27203_g()
 * - public void func_27205_a(String s)
 * - public void func_27199_h()
 * - public void func_27201_b(String s)
 * - public void func_27196_i()
 * - public void func_27198_c(String s)
 * - public void func_27193_j()
 * - public void func_27202_k()
 * - private void func_27207_a(J_JsonNodeBuilder j_jsonnodebuilder)
 * - private void func_27206_b(J_JsonNodeBuilder j_jsonnodebuilder)
 * - private final Stack field_27210_a = new Stack()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonListenerToJdomAdapter_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonListenerToJdomAdapter_JavaName(void)
{
    return "net.minecraft.src.J_JsonListenerToJdomAdapter";
}

const char *CloneMCJ_J_JsonListenerToJdomAdapter_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonListenerToJdomAdapter_JavaSourceHash32(void)
{
    return 0xF4835CDCUL;
}
