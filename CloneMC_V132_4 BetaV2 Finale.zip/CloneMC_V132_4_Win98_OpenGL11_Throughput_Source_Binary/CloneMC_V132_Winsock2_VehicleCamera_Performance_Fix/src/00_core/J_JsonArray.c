/*
 * CloneMC Java port scaffold: J_JsonArray
 *
 * Java source: J_JsonArray.java
 * Java type: class J_JsonArray
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 7fb9f281968fb7800bbbb2f560e6e473eac95e756d3920da3996aee55398e507
 * Java lines: 73
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: J_JsonRootNode, EnumJsonNodeType, J_JsonNodeList
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final List field_27221_a
 *
 * Java method/constructor inventory:
 * - public EnumJsonNodeType func_27218_a()
 * - public List func_27215_d()
 * - public String func_27216_b()
 * - public Map func_27214_c()
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - public String toString()
 * - private static List func_27220_a(Iterable iterable)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonArray_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonArray_JavaName(void)
{
    return "net.minecraft.src.J_JsonArray";
}

const char *CloneMCJ_J_JsonArray_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonArray_JavaSourceHash32(void)
{
    return 0x7FB9F281UL;
}
