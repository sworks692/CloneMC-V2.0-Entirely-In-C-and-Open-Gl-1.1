/*
 * CloneMC Java port scaffold: J_JsonStringNodeBuilder
 *
 * Java source: J_JsonStringNodeBuilder.java
 * Java type: class J_JsonStringNodeBuilder
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: J_JsonNodeBuilder
 * Source SHA-256: b8dd41d0c6cd0f4feea3fe1d06c090e9d8aa12b7914c93958b97c73e6f594518
 * Java lines: 32
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: J_JsonNodeBuilder, J_JsonNodeFactories, J_JsonStringNode, J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final String field_27244_a
 *
 * Java method/constructor inventory:
 * - public J_JsonStringNode func_27243_a()
 * - public J_JsonNode func_27234_b()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonStringNodeBuilder_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonStringNodeBuilder_JavaName(void)
{
    return "net.minecraft.src.J_JsonStringNodeBuilder";
}

const char *CloneMCJ_J_JsonStringNodeBuilder_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonStringNodeBuilder_JavaSourceHash32(void)
{
    return 0xB8DD41D0UL;
}
