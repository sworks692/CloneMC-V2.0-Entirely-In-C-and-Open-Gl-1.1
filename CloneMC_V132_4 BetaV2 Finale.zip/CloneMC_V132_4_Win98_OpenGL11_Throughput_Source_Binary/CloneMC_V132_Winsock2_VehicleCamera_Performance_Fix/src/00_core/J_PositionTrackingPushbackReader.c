/*
 * CloneMC Java port scaffold: J_PositionTrackingPushbackReader
 *
 * Java source: J_PositionTrackingPushbackReader.java
 * Java type: class J_PositionTrackingPushbackReader
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 2ca00c063689017cad9bdce0b3573abe70bbbcf2c73786976112b55c977479d5
 * Java lines: 103
 * Discovered declared fields: 4
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: J_ThingWithPosition
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final PushbackReader field_27338_a
 * - private int field_27337_b
 * - private int field_27340_c
 * - private boolean field_27339_d
 *
 * Java method/constructor inventory:
 * - public J_PositionTrackingPushbackReader(Reader reader)
 * - public void func_27334_a(char c)
 * - public void func_27335_a(char ac[])
 * - public int func_27333_c()
 * - public int func_27336_b(char ac[])
 * - private void func_27332_a(int i)
 * - public int func_27331_a()
 * - public int func_27330_b()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_PositionTrackingPushbackReader_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_PositionTrackingPushbackReader_JavaName(void)
{
    return "net.minecraft.src.J_PositionTrackingPushbackReader";
}

const char *CloneMCJ_J_PositionTrackingPushbackReader_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_PositionTrackingPushbackReader_JavaSourceHash32(void)
{
    return 0x2CA00C06UL;
}
