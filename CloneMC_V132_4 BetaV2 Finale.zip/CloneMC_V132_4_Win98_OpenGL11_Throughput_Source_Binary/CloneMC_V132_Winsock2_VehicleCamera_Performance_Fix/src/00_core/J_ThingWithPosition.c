/*
 * CloneMC Java port scaffold: J_ThingWithPosition
 *
 * Java source: J_ThingWithPosition.java
 * Java type: class J_ThingWithPosition
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 2bb531bdf9c158f697cdd3cc7d979201c63113729a9c355ef08c2d8856d2571f
 * Java lines: 15
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract int func_27331_a()
 * - public abstract int func_27330_b()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_ThingWithPosition_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_ThingWithPosition_JavaName(void)
{
    return "net.minecraft.src.J_ThingWithPosition";
}

const char *CloneMCJ_J_ThingWithPosition_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_ThingWithPosition_JavaSourceHash32(void)
{
    return 0x2BB531BDUL;
}
