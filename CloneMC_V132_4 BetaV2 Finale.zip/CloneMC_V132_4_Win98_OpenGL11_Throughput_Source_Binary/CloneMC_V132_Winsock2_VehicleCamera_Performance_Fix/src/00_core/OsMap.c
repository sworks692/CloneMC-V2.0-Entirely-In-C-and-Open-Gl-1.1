/*
 * CloneMC Java port scaffold: OsMap
 *
 * Java source: OsMap.java
 * Java type: class OsMap
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 42ea7c00bc57f03c0bb81b0447f1533faf5fa0e4fe171a71c4c044526e715e85
 * Java lines: 41
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: EnumOS1, static, try
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_OsMap_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_OsMap_JavaName(void)
{
    return "net.minecraft.src.OsMap";
}

const char *CloneMCJ_OsMap_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_OsMap_JavaSourceHash32(void)
{
    return 0x42EA7C00UL;
}
