/*
 * CloneMC Java port scaffold: J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException
 *
 * Java source: J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException.java
 * Java type: class J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: J_JsonNodeDoesNotMatchJsonNodeSelectorException
 * Implements: (none declared)
 * Source SHA-256: 4518fa406abb0be90c474bce3b1ad44a4a398968d1f39520e188782d50ad5dbf
 * Java lines: 65
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: J_JsonNodeDoesNotMatchJsonNodeSelectorException, J_JsonNodeSelector, J_Functor
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - private J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException(J_Functor j_functor, List list)
 * - public String toString()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_JavaName(void)
{
    return "net.minecraft.src.J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException";
}

const char *CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_JavaSourceHash32(void)
{
    return 0x4518FA40UL;
}
