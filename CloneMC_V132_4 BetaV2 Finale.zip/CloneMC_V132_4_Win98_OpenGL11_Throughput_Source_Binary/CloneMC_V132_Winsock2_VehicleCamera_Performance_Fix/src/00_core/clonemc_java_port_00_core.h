/*
 * Shared public declarations for Java modules assigned to src/00_core.
 * 65 class-specific C implementations use this one subsystem header.
 * Detailed Java field/method inventories remain beside the implementation in
 * each same-named class C file, avoiding hundreds of tiny public headers.
 */
#ifndef CLONEMC_JAVA_PORT_00_CORE_H
#define CLONEMC_JAVA_PORT_00_CORE_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Priority 2: Java numerical compatibility layer.
 *
 * Open Watcom 11.x targets Win32 with 8-bit char, 16-bit short, 32-bit long,
 * and a compiler-specific 64-bit integer.  These explicit aliases prevent the
 * host C compiler's native integer widths from silently changing Java data.
 */
#if defined(__WATCOMC__) || defined(_MSC_VER)
typedef signed __int64 CloneMCJLong;
typedef unsigned __int64 CloneMCJULong;
#else
__extension__ typedef signed long long CloneMCJLong;
__extension__ typedef unsigned long long CloneMCJULong;
#endif
typedef signed char CloneMCJByte;
typedef unsigned char CloneMCJUByte;
typedef signed short CloneMCJShort;
typedef unsigned short CloneMCJUShort;
#if defined(__WATCOMC__) || defined(_MSC_VER)
typedef signed long CloneMCJInt;
typedef unsigned long CloneMCJUInt;
#else
typedef signed int CloneMCJInt;
typedef unsigned int CloneMCJUInt;
#endif

typedef char CloneMCJ_Require8BitByte[(sizeof(CloneMCJByte) == 1) ? 1 : -1];
typedef char CloneMCJ_Require16BitShort[(sizeof(CloneMCJShort) == 2) ? 1 : -1];
typedef char CloneMCJ_Require32BitInt[(sizeof(CloneMCJInt) == 4) ? 1 : -1];
typedef char CloneMCJ_Require64BitLong[(sizeof(CloneMCJLong) == 8) ? 1 : -1];

typedef struct CloneMCJavaRandomTag {
    CloneMCJULong seed;
    int haveNextGaussian;
    double nextGaussian;
} CloneMCJavaRandom;

typedef struct CloneMCVec3DTag {
    double xCoord;
    double yCoord;
    double zCoord;
} CloneMCVec3D;

typedef struct CloneMCAxisAlignedBBTag {
    double minX;
    double minY;
    double minZ;
    double maxX;
    double maxY;
    double maxZ;
} CloneMCAxisAlignedBB;

typedef struct CloneMCAABBRayHitTag {
    int hit;
    int side; /* Java sideHit: 0..5; -1 when no hit. */
    CloneMCVec3D point;
} CloneMCAABBRayHit;

/* Java integer, cast, division, floor, and packed-array rules. */
CloneMCJInt CloneMCJava_AddInt(CloneMCJInt left, CloneMCJInt right);
CloneMCJInt CloneMCJava_SubInt(CloneMCJInt left, CloneMCJInt right);
CloneMCJInt CloneMCJava_MulInt(CloneMCJInt left, CloneMCJInt right);
CloneMCJInt CloneMCJava_UnsignedShiftRightInt(CloneMCJInt value, int bits);
CloneMCJLong CloneMCJava_UnsignedShiftRightLong(CloneMCJLong value, int bits);
CloneMCJByte CloneMCJava_CastByte(CloneMCJInt value);
CloneMCJShort CloneMCJava_CastShort(CloneMCJInt value);
int CloneMCJava_FloorFloat(float value);
int CloneMCJava_FloorDouble(double value);
int CloneMCJava_BucketInt(int value, int divisor);
unsigned int CloneMCJava_NibbleGet(const unsigned char *data, unsigned long index);
void CloneMCJava_NibbleSet(unsigned char *data, unsigned long index, unsigned int value);

/* Bit-for-bit java.util.Random 48-bit linear-congruential generator. */
void CloneMCJavaRandom_SetSeed(CloneMCJavaRandom *random, CloneMCJLong seed);
CloneMCJInt CloneMCJavaRandom_NextBits(CloneMCJavaRandom *random, int bits);
CloneMCJInt CloneMCJavaRandom_NextInt(CloneMCJavaRandom *random);
CloneMCJInt CloneMCJavaRandom_NextIntBound(CloneMCJavaRandom *random, CloneMCJInt bound);
CloneMCJLong CloneMCJavaRandom_NextLong(CloneMCJavaRandom *random);
int CloneMCJavaRandom_NextBoolean(CloneMCJavaRandom *random);
float CloneMCJavaRandom_NextFloat(CloneMCJavaRandom *random);
double CloneMCJavaRandom_NextDouble(CloneMCJavaRandom *random);
double CloneMCJavaRandom_NextGaussian(CloneMCJavaRandom *random);

/* Direct MathHelper.java behavior, including its 65,536-entry sine table. */
void CloneMCMathHelper_Initialize(void);
float CloneMCMathHelper_Sin(float value);
float CloneMCMathHelper_Cos(float value);
float CloneMCMathHelper_SqrtFloat(float value);
float CloneMCMathHelper_SqrtDouble(double value);
float CloneMCMathHelper_Abs(float value);
double CloneMCMathHelper_AbsMax(double left, double right);

/* Value-based Vec3D and AxisAlignedBB ports; no hidden allocation is required. */
CloneMCVec3D CloneMCVec3D_Create(double x, double y, double z);
CloneMCVec3D CloneMCVec3D_Subtract(const CloneMCVec3D *self, const CloneMCVec3D *other);
CloneMCVec3D CloneMCVec3D_Normalize(const CloneMCVec3D *self);
CloneMCVec3D CloneMCVec3D_Cross(const CloneMCVec3D *self, const CloneMCVec3D *other);
CloneMCVec3D CloneMCVec3D_Add(const CloneMCVec3D *self, double x, double y, double z);
double CloneMCVec3D_Distance(const CloneMCVec3D *self, const CloneMCVec3D *other);
double CloneMCVec3D_SquareDistance(const CloneMCVec3D *self, const CloneMCVec3D *other);
double CloneMCVec3D_Length(const CloneMCVec3D *self);
int CloneMCVec3D_IntermediateX(const CloneMCVec3D *self, const CloneMCVec3D *other,
                              double x, CloneMCVec3D *result);
int CloneMCVec3D_IntermediateY(const CloneMCVec3D *self, const CloneMCVec3D *other,
                              double y, CloneMCVec3D *result);
int CloneMCVec3D_IntermediateZ(const CloneMCVec3D *self, const CloneMCVec3D *other,
                              double z, CloneMCVec3D *result);
void CloneMCVec3D_RotateX(CloneMCVec3D *self, float radians);
void CloneMCVec3D_RotateY(CloneMCVec3D *self, float radians);

CloneMCAxisAlignedBB CloneMCAABB_Create(double minX, double minY, double minZ,
                                        double maxX, double maxY, double maxZ);
CloneMCAxisAlignedBB CloneMCAABB_AddCoord(const CloneMCAxisAlignedBB *box,
                                          double x, double y, double z);
CloneMCAxisAlignedBB CloneMCAABB_Expand(const CloneMCAxisAlignedBB *box,
                                        double x, double y, double z);
CloneMCAxisAlignedBB CloneMCAABB_OffsetCopy(const CloneMCAxisAlignedBB *box,
                                            double x, double y, double z);
void CloneMCAABB_Offset(CloneMCAxisAlignedBB *box, double x, double y, double z);
double CloneMCAABB_CalculateXOffset(const CloneMCAxisAlignedBB *box,
                                    const CloneMCAxisAlignedBB *moving, double offset);
double CloneMCAABB_CalculateYOffset(const CloneMCAxisAlignedBB *box,
                                    const CloneMCAxisAlignedBB *moving, double offset);
double CloneMCAABB_CalculateZOffset(const CloneMCAxisAlignedBB *box,
                                    const CloneMCAxisAlignedBB *moving, double offset);
int CloneMCAABB_Intersects(const CloneMCAxisAlignedBB *box, const CloneMCAxisAlignedBB *other);
int CloneMCAABB_IsVecInside(const CloneMCAxisAlignedBB *box, const CloneMCVec3D *point);
double CloneMCAABB_AverageEdgeLength(const CloneMCAxisAlignedBB *box);
CloneMCAxisAlignedBB CloneMCAABB_Contract(const CloneMCAxisAlignedBB *box,
                                          double x, double y, double z);
CloneMCAABBRayHit CloneMCAABB_RayTrace(const CloneMCAxisAlignedBB *box,
                                       const CloneMCVec3D *start, const CloneMCVec3D *end);

int CloneMCJavaCore_RunSelfTests(char *message, unsigned int messageCapacity);

/* AxisAlignedBB.java: class, 410 Java lines. */
void CloneMCJ_AxisAlignedBB_Register(void);
const char *CloneMCJ_AxisAlignedBB_JavaName(void);
const char *CloneMCJ_AxisAlignedBB_AssignedFolder(void);
unsigned long CloneMCJ_AxisAlignedBB_JavaSourceHash32(void);

/* Empty1.java: class, 11 Java lines. */
void CloneMCJ_Empty1_Register(void);
const char *CloneMCJ_Empty1_JavaName(void);
const char *CloneMCJ_Empty1_AssignedFolder(void);
unsigned long CloneMCJ_Empty1_JavaSourceHash32(void);

/* Empty2.java: class, 11 Java lines. */
void CloneMCJ_Empty2_Register(void);
const char *CloneMCJ_Empty2_JavaName(void);
const char *CloneMCJ_Empty2_AssignedFolder(void);
unsigned long CloneMCJ_Empty2_JavaSourceHash32(void);

/* EnumJsonNodeType.java: enum, 59 Java lines. */
void CloneMCJ_EnumJsonNodeType_Register(void);
const char *CloneMCJ_EnumJsonNodeType_JavaName(void);
const char *CloneMCJ_EnumJsonNodeType_AssignedFolder(void);
unsigned long CloneMCJ_EnumJsonNodeType_JavaSourceHash32(void);

/* EnumJsonNodeTypeMappingHelper.java: class, 56 Java lines. */
void CloneMCJ_EnumJsonNodeTypeMappingHelper_Register(void);
const char *CloneMCJ_EnumJsonNodeTypeMappingHelper_JavaName(void);
const char *CloneMCJ_EnumJsonNodeTypeMappingHelper_AssignedFolder(void);
unsigned long CloneMCJ_EnumJsonNodeTypeMappingHelper_JavaSourceHash32(void);

/* EnumStatus.java: enum, 53 Java lines. */
void CloneMCJ_EnumStatus_Register(void);
const char *CloneMCJ_EnumStatus_JavaName(void);
const char *CloneMCJ_EnumStatus_AssignedFolder(void);
unsigned long CloneMCJ_EnumStatus_JavaSourceHash32(void);

/* IStatStringFormat.java: interface, 13 Java lines. */
void CloneMCJ_IStatStringFormat_Register(void);
const char *CloneMCJ_IStatStringFormat_JavaName(void);
const char *CloneMCJ_IStatStringFormat_AssignedFolder(void);
unsigned long CloneMCJ_IStatStringFormat_JavaSourceHash32(void);

/* IStatType.java: interface, 13 Java lines. */
void CloneMCJ_IStatType_Register(void);
const char *CloneMCJ_IStatType_JavaName(void);
const char *CloneMCJ_IStatType_AssignedFolder(void);
unsigned long CloneMCJ_IStatType_JavaSourceHash32(void);

/* J_ArrayNodeContainer.java: class, 36 Java lines. */
void CloneMCJ_J_ArrayNodeContainer_Register(void);
const char *CloneMCJ_J_ArrayNodeContainer_JavaName(void);
const char *CloneMCJ_J_ArrayNodeContainer_AssignedFolder(void);
unsigned long CloneMCJ_J_ArrayNodeContainer_JavaSourceHash32(void);

/* J_ChainedFunctor.java: class, 62 Java lines. */
void CloneMCJ_J_ChainedFunctor_Register(void);
const char *CloneMCJ_J_ChainedFunctor_JavaName(void);
const char *CloneMCJ_J_ChainedFunctor_AssignedFolder(void);
unsigned long CloneMCJ_J_ChainedFunctor_JavaSourceHash32(void);

/* J_CompactJsonFormatter.java: class, 107 Java lines. */
void CloneMCJ_J_CompactJsonFormatter_Register(void);
const char *CloneMCJ_J_CompactJsonFormatter_JavaName(void);
const char *CloneMCJ_J_CompactJsonFormatter_AssignedFolder(void);
unsigned long CloneMCJ_J_CompactJsonFormatter_JavaSourceHash32(void);

/* J_FieldNodeContainer.java: class, 35 Java lines. */
void CloneMCJ_J_FieldNodeContainer_Register(void);
const char *CloneMCJ_J_FieldNodeContainer_JavaName(void);
const char *CloneMCJ_J_FieldNodeContainer_AssignedFolder(void);
unsigned long CloneMCJ_J_FieldNodeContainer_JavaSourceHash32(void);

/* J_Functor.java: class, 17 Java lines. */
void CloneMCJ_J_Functor_Register(void);
const char *CloneMCJ_J_Functor_JavaName(void);
const char *CloneMCJ_J_Functor_AssignedFolder(void);
unsigned long CloneMCJ_J_Functor_JavaSourceHash32(void);

/* J_InvalidSyntaxException.java: class, 31 Java lines. */
void CloneMCJ_J_InvalidSyntaxException_Register(void);
const char *CloneMCJ_J_InvalidSyntaxException_JavaName(void);
const char *CloneMCJ_J_InvalidSyntaxException_AssignedFolder(void);
unsigned long CloneMCJ_J_InvalidSyntaxException_JavaSourceHash32(void);

/* J_JdomParser.java: class, 42 Java lines. */
void CloneMCJ_J_JdomParser_Register(void);
const char *CloneMCJ_J_JdomParser_JavaName(void);
const char *CloneMCJ_J_JdomParser_AssignedFolder(void);
unsigned long CloneMCJ_J_JdomParser_JavaSourceHash32(void);

/* J_JsonArray.java: class, 73 Java lines. */
void CloneMCJ_J_JsonArray_Register(void);
const char *CloneMCJ_J_JsonArray_JavaName(void);
const char *CloneMCJ_J_JsonArray_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonArray_JavaSourceHash32(void);

/* J_JsonArrayNodeBuilder.java: class, 45 Java lines. */
void CloneMCJ_J_JsonArrayNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonArrayNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonArrayNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonArrayNodeBuilder_JavaSourceHash32(void);

/* J_JsonArrayNodeSelector.java: class, 49 Java lines. */
void CloneMCJ_J_JsonArrayNodeSelector_Register(void);
const char *CloneMCJ_J_JsonArrayNodeSelector_JavaName(void);
const char *CloneMCJ_J_JsonArrayNodeSelector_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonArrayNodeSelector_JavaSourceHash32(void);

/* J_JsonConstants.java: class, 53 Java lines. */
void CloneMCJ_J_JsonConstants_Register(void);
const char *CloneMCJ_J_JsonConstants_JavaName(void);
const char *CloneMCJ_J_JsonConstants_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonConstants_JavaSourceHash32(void);

/* J_JsonElementNodeSelector.java: class, 53 Java lines. */
void CloneMCJ_J_JsonElementNodeSelector_Register(void);
const char *CloneMCJ_J_JsonElementNodeSelector_JavaName(void);
const char *CloneMCJ_J_JsonElementNodeSelector_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonElementNodeSelector_JavaSourceHash32(void);

/* J_JsonEscapedString.java: class, 23 Java lines. */
void CloneMCJ_J_JsonEscapedString_Register(void);
const char *CloneMCJ_J_JsonEscapedString_JavaName(void);
const char *CloneMCJ_J_JsonEscapedString_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonEscapedString_JavaSourceHash32(void);

/* J_JsonFalseNodeBuilder.java: class, 24 Java lines. */
void CloneMCJ_J_JsonFalseNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonFalseNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonFalseNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonFalseNodeBuilder_JavaSourceHash32(void);

/* J_JsonFieldBuilder.java: class, 48 Java lines. */
void CloneMCJ_J_JsonFieldBuilder_Register(void);
const char *CloneMCJ_J_JsonFieldBuilder_JavaName(void);
const char *CloneMCJ_J_JsonFieldBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonFieldBuilder_JavaSourceHash32(void);

/* J_JsonFieldNodeSelector.java: class, 53 Java lines. */
void CloneMCJ_J_JsonFieldNodeSelector_Register(void);
const char *CloneMCJ_J_JsonFieldNodeSelector_JavaName(void);
const char *CloneMCJ_J_JsonFieldNodeSelector_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonFieldNodeSelector_JavaSourceHash32(void);

/* J_JsonFormatter.java: interface, 16 Java lines. */
void CloneMCJ_J_JsonFormatter_Register(void);
const char *CloneMCJ_J_JsonFormatter_JavaName(void);
const char *CloneMCJ_J_JsonFormatter_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonFormatter_JavaSourceHash32(void);

/* J_JsonListener.java: interface, 37 Java lines. */
void CloneMCJ_J_JsonListener_Register(void);
const char *CloneMCJ_J_JsonListener_JavaName(void);
const char *CloneMCJ_J_JsonListener_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonListener_JavaSourceHash32(void);

/* J_JsonListenerToJdomAdapter.java: class, 115 Java lines. */
void CloneMCJ_J_JsonListenerToJdomAdapter_Register(void);
const char *CloneMCJ_J_JsonListenerToJdomAdapter_JavaName(void);
const char *CloneMCJ_J_JsonListenerToJdomAdapter_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonListenerToJdomAdapter_JavaSourceHash32(void);

/* J_JsonNode.java: class, 53 Java lines. */
void CloneMCJ_J_JsonNode_Register(void);
const char *CloneMCJ_J_JsonNode_JavaName(void);
const char *CloneMCJ_J_JsonNode_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNode_JavaSourceHash32(void);

/* J_JsonNodeBuilder.java: interface, 16 Java lines. */
void CloneMCJ_J_JsonNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeBuilder_JavaSourceHash32(void);

/* J_JsonNodeBuilders.java: class, 54 Java lines. */
void CloneMCJ_J_JsonNodeBuilders_Register(void);
const char *CloneMCJ_J_JsonNodeBuilders_JavaName(void);
const char *CloneMCJ_J_JsonNodeBuilders_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeBuilders_JavaSourceHash32(void);

/* J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException.java: class, 65 Java lines. */
void CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_Register(void);
const char *CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_JavaName(void);
const char *CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeDoesNotMatchChainedJsonNodeSelectorException_JavaSourceHash32(void);

/* J_JsonNodeDoesNotMatchJsonNodeSelectorException.java: class, 16 Java lines. */
void CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_Register(void);
const char *CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_JavaName(void);
const char *CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_JavaSourceHash32(void);

/* J_JsonNodeDoesNotMatchPathElementsException.java: class, 59 Java lines. */
void CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_Register(void);
const char *CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_JavaName(void);
const char *CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeDoesNotMatchPathElementsException_JavaSourceHash32(void);

/* J_JsonNodeFactories.java: class, 61 Java lines. */
void CloneMCJ_J_JsonNodeFactories_Register(void);
const char *CloneMCJ_J_JsonNodeFactories_JavaName(void);
const char *CloneMCJ_J_JsonNodeFactories_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeFactories_JavaSourceHash32(void);

/* J_JsonNodeList.java: class, 30 Java lines. */
void CloneMCJ_J_JsonNodeList_Register(void);
const char *CloneMCJ_J_JsonNodeList_JavaName(void);
const char *CloneMCJ_J_JsonNodeList_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeList_JavaSourceHash32(void);

/* J_JsonNodeSelector.java: class, 46 Java lines. */
void CloneMCJ_J_JsonNodeSelector_Register(void);
const char *CloneMCJ_J_JsonNodeSelector_JavaName(void);
const char *CloneMCJ_J_JsonNodeSelector_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeSelector_JavaSourceHash32(void);

/* J_JsonNodeSelectors.java: class, 88 Java lines. */
void CloneMCJ_J_JsonNodeSelectors_Register(void);
const char *CloneMCJ_J_JsonNodeSelectors_JavaName(void);
const char *CloneMCJ_J_JsonNodeSelectors_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNodeSelectors_JavaSourceHash32(void);

/* J_JsonNullNodeBuilder.java: class, 24 Java lines. */
void CloneMCJ_J_JsonNullNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonNullNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonNullNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNullNodeBuilder_JavaSourceHash32(void);

/* J_JsonNumberNode.java: class, 84 Java lines. */
void CloneMCJ_J_JsonNumberNode_Register(void);
const char *CloneMCJ_J_JsonNumberNode_JavaName(void);
const char *CloneMCJ_J_JsonNumberNode_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNumberNode_JavaSourceHash32(void);

/* J_JsonNumberNodeBuilder.java: class, 27 Java lines. */
void CloneMCJ_J_JsonNumberNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonNumberNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonNumberNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonNumberNodeBuilder_JavaSourceHash32(void);

/* J_JsonObject.java: class, 68 Java lines. */
void CloneMCJ_J_JsonObject_Register(void);
const char *CloneMCJ_J_JsonObject_JavaName(void);
const char *CloneMCJ_J_JsonObject_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonObject_JavaSourceHash32(void);

/* J_JsonObjectNodeBuilder.java: class, 45 Java lines. */
void CloneMCJ_J_JsonObjectNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonObjectNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonObjectNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonObjectNodeBuilder_JavaSourceHash32(void);

/* J_JsonObjectNodeList.java: class, 29 Java lines. */
void CloneMCJ_J_JsonObjectNodeList_Register(void);
const char *CloneMCJ_J_JsonObjectNodeList_JavaName(void);
const char *CloneMCJ_J_JsonObjectNodeList_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonObjectNodeList_JavaSourceHash32(void);

/* J_JsonObjectNodeSelector.java: class, 49 Java lines. */
void CloneMCJ_J_JsonObjectNodeSelector_Register(void);
const char *CloneMCJ_J_JsonObjectNodeSelector_JavaName(void);
const char *CloneMCJ_J_JsonObjectNodeSelector_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonObjectNodeSelector_JavaSourceHash32(void);

/* J_JsonRootNode.java: class, 18 Java lines. */
void CloneMCJ_J_JsonRootNode_Register(void);
const char *CloneMCJ_J_JsonRootNode_JavaName(void);
const char *CloneMCJ_J_JsonRootNode_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonRootNode_JavaSourceHash32(void);

/* J_JsonStringNode.java: class, 87 Java lines. */
void CloneMCJ_J_JsonStringNode_Register(void);
const char *CloneMCJ_J_JsonStringNode_JavaName(void);
const char *CloneMCJ_J_JsonStringNode_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonStringNode_JavaSourceHash32(void);

/* J_JsonStringNodeBuilder.java: class, 32 Java lines. */
void CloneMCJ_J_JsonStringNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonStringNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonStringNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonStringNodeBuilder_JavaSourceHash32(void);

/* J_JsonStringNodeSelector.java: class, 48 Java lines. */
void CloneMCJ_J_JsonStringNodeSelector_Register(void);
const char *CloneMCJ_J_JsonStringNodeSelector_JavaName(void);
const char *CloneMCJ_J_JsonStringNodeSelector_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonStringNodeSelector_JavaSourceHash32(void);

/* J_JsonTrueNodeBuilder.java: class, 24 Java lines. */
void CloneMCJ_J_JsonTrueNodeBuilder_Register(void);
const char *CloneMCJ_J_JsonTrueNodeBuilder_JavaName(void);
const char *CloneMCJ_J_JsonTrueNodeBuilder_AssignedFolder(void);
unsigned long CloneMCJ_J_JsonTrueNodeBuilder_JavaSourceHash32(void);

/* J_LeafFunctor.java: class, 32 Java lines. */
void CloneMCJ_J_LeafFunctor_Register(void);
const char *CloneMCJ_J_LeafFunctor_JavaName(void);
const char *CloneMCJ_J_LeafFunctor_AssignedFolder(void);
unsigned long CloneMCJ_J_LeafFunctor_JavaSourceHash32(void);

/* J_NodeContainer.java: class, 18 Java lines. */
void CloneMCJ_J_NodeContainer_Register(void);
const char *CloneMCJ_J_NodeContainer_JavaName(void);
const char *CloneMCJ_J_NodeContainer_AssignedFolder(void);
unsigned long CloneMCJ_J_NodeContainer_JavaSourceHash32(void);

/* J_ObjectNodeContainer.java: class, 36 Java lines. */
void CloneMCJ_J_ObjectNodeContainer_Register(void);
const char *CloneMCJ_J_ObjectNodeContainer_JavaName(void);
const char *CloneMCJ_J_ObjectNodeContainer_AssignedFolder(void);
unsigned long CloneMCJ_J_ObjectNodeContainer_JavaSourceHash32(void);

/* J_PositionTrackingPushbackReader.java: class, 103 Java lines. */
void CloneMCJ_J_PositionTrackingPushbackReader_Register(void);
const char *CloneMCJ_J_PositionTrackingPushbackReader_JavaName(void);
const char *CloneMCJ_J_PositionTrackingPushbackReader_AssignedFolder(void);
unsigned long CloneMCJ_J_PositionTrackingPushbackReader_JavaSourceHash32(void);

/* J_SajParser.java: class, 534 Java lines. */
void CloneMCJ_J_SajParser_Register(void);
const char *CloneMCJ_J_SajParser_JavaName(void);
const char *CloneMCJ_J_SajParser_AssignedFolder(void);
unsigned long CloneMCJ_J_SajParser_JavaSourceHash32(void);

/* J_ThingWithPosition.java: class, 15 Java lines. */
void CloneMCJ_J_ThingWithPosition_Register(void);
const char *CloneMCJ_J_ThingWithPosition_JavaName(void);
const char *CloneMCJ_J_ThingWithPosition_AssignedFolder(void);
unsigned long CloneMCJ_J_ThingWithPosition_JavaSourceHash32(void);

/* MathHelper.java: class, 93 Java lines. */
void CloneMCJ_MathHelper_Register(void);
const char *CloneMCJ_MathHelper_JavaName(void);
const char *CloneMCJ_MathHelper_AssignedFolder(void);
unsigned long CloneMCJ_MathHelper_JavaSourceHash32(void);

/* MCHash.java: class, 171 Java lines. */
void CloneMCJ_MCHash_Register(void);
const char *CloneMCJ_MCHash_JavaName(void);
const char *CloneMCJ_MCHash_AssignedFolder(void);
unsigned long CloneMCJ_MCHash_JavaSourceHash32(void);

/* MCHashEntry.java: class, 68 Java lines. */
void CloneMCJ_MCHashEntry_Register(void);
const char *CloneMCJ_MCHashEntry_JavaName(void);
const char *CloneMCJ_MCHashEntry_AssignedFolder(void);
unsigned long CloneMCJ_MCHashEntry_JavaSourceHash32(void);

/* MD5String.java: class, 36 Java lines. */
void CloneMCJ_MD5String_Register(void);
const char *CloneMCJ_MD5String_JavaName(void);
const char *CloneMCJ_MD5String_AssignedFolder(void);
unsigned long CloneMCJ_MD5String_JavaSourceHash32(void);

/* MinecraftError.java: class, 15 Java lines. */
void CloneMCJ_MinecraftError_Register(void);
const char *CloneMCJ_MinecraftError_JavaName(void);
const char *CloneMCJ_MinecraftError_AssignedFolder(void);
unsigned long CloneMCJ_MinecraftError_JavaSourceHash32(void);

/* MinecraftException.java: class, 16 Java lines. */
void CloneMCJ_MinecraftException_Register(void);
const char *CloneMCJ_MinecraftException_JavaName(void);
const char *CloneMCJ_MinecraftException_AssignedFolder(void);
unsigned long CloneMCJ_MinecraftException_JavaSourceHash32(void);

/* MouseFilter.java: class, 32 Java lines. */
void CloneMCJ_MouseFilter_Register(void);
const char *CloneMCJ_MouseFilter_JavaName(void);
const char *CloneMCJ_MouseFilter_AssignedFolder(void);
unsigned long CloneMCJ_MouseFilter_JavaSourceHash32(void);

/* OsMap.java: class, 41 Java lines. */
void CloneMCJ_OsMap_Register(void);
const char *CloneMCJ_OsMap_JavaName(void);
const char *CloneMCJ_OsMap_AssignedFolder(void);
unsigned long CloneMCJ_OsMap_JavaSourceHash32(void);

/* Timer.java: class, 82 Java lines. */
void CloneMCJ_Timer_Register(void);
const char *CloneMCJ_Timer_JavaName(void);
const char *CloneMCJ_Timer_AssignedFolder(void);
unsigned long CloneMCJ_Timer_JavaSourceHash32(void);

/* Priority 1: Java Timer-compatible fixed-step Win32 clock. */
#define CLONEMC_TIMER_DEFAULT_TPS 20.0
#define CLONEMC_TIMER_MAX_CATCHUP_TICKS 10

typedef struct CloneMCTimerTag {
    double ticksPerSecond;
    double timerSpeed;
    double elapsedPartialTicks;
    double renderPartialTicks;
    double lastCounterSeconds;
    double fallbackAccumulatedSeconds;
    unsigned long lastFallbackMilliseconds;
    int elapsedTicks;
    int initialized;
    int usingPerformanceCounter;
    int multimediaPeriodActive;
    int timingActive;
} CloneMCTimer;

int CloneMCTimer_Initialize(CloneMCTimer *timer, double ticksPerSecond);
void CloneMCTimer_Shutdown(CloneMCTimer *timer);
void CloneMCTimer_Reset(CloneMCTimer *timer);
void CloneMCTimer_Update(CloneMCTimer *timer);
void CloneMCTimer_SetActive(CloneMCTimer *timer, int active);
double CloneMCTimer_NowSeconds(void);

/* Priority 2 resolves one bounded runtime envelope at startup.  Fixed arrays
 * remain compile-time bounded for old heaps; these limits control how much of
 * those arrays may become resident or active. */
typedef struct CloneMCLegacyProfileTag {
    char name[24];
    unsigned long detectedPhysicalBytes;
    unsigned long processMemoryCeilingBytes;
    unsigned long chunkMemoryCeilingBytes;
    unsigned long meshMemoryCeilingBytes;
    unsigned long networkReadQueueCeilingBytes;
    int residentChunkTarget;
    int particleLimit;
    int regionFileLimit;
    int meshStepsPerFrame;
    double meshWorkSeconds;
} CloneMCLegacyProfile;

/* Vec3D.java: class, 217 Java lines. */
void CloneMCJ_Vec3D_Register(void);
const char *CloneMCJ_Vec3D_JavaName(void);
const char *CloneMCJ_Vec3D_AssignedFolder(void);
unsigned long CloneMCJ_Vec3D_JavaSourceHash32(void);

#ifdef __cplusplus
}
#endif

#endif /* CLONEMC_JAVA_PORT_00_CORE_H */
