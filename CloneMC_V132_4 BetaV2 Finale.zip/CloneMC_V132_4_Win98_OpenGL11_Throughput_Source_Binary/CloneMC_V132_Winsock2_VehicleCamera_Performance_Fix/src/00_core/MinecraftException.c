/*
 * CloneMC Java port scaffold: MinecraftException
 *
 * Java source: MinecraftException.java
 * Java type: class MinecraftException
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: RuntimeException
 * Implements: (none declared)
 * Source SHA-256: 1dfee81d3eff0130a7cf1c86cb5e8c81b8daf79f1e06c80b2cf247c69af8e185
 * Java lines: 16
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public MinecraftException(String s)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_MinecraftException_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MinecraftException_JavaName(void)
{
    return "net.minecraft.src.MinecraftException";
}

const char *CloneMCJ_MinecraftException_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_MinecraftException_JavaSourceHash32(void)
{
    return 0x1DFEE81DUL;
}
