/*
 * CloneMC Java port scaffold: J_JsonRootNode
 *
 * Java source: J_JsonRootNode.java
 * Java type: class J_JsonRootNode
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: J_JsonNode
 * Implements: (none declared)
 * Source SHA-256: 2845d0c3fa8120ef5490145dce11ca0fc663a7c84e58312aa5d2e085860f402a
 * Java lines: 18
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonRootNode_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonRootNode_JavaName(void)
{
    return "net.minecraft.src.J_JsonRootNode";
}

const char *CloneMCJ_J_JsonRootNode_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonRootNode_JavaSourceHash32(void)
{
    return 0x2845D0C3UL;
}
