/*
 * CloneMC Java port scaffold: J_JsonObjectNodeBuilder
 *
 * Java source: J_JsonObjectNodeBuilder.java
 * Java type: class J_JsonObjectNodeBuilder
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: J_JsonNodeBuilder
 * Source SHA-256: 463eb93137e427db455c7fb4fb88215fcb05688cb8bb549deed5503d44dd7914
 * Java lines: 45
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 4
 * Referenced Java classes: J_JsonNodeBuilder, J_JsonObjectNodeList, J_JsonNodeFactories, J_JsonFieldBuilder, J_JsonRootNode, J_JsonNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public J_JsonObjectNodeBuilder func_27237_a(J_JsonFieldBuilder j_jsonfieldbuilder)
 * - public J_JsonRootNode func_27235_a()
 * - public J_JsonNode func_27234_b()
 * - private final List field_27238_a = new LinkedList()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonObjectNodeBuilder_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonObjectNodeBuilder_JavaName(void)
{
    return "net.minecraft.src.J_JsonObjectNodeBuilder";
}

const char *CloneMCJ_J_JsonObjectNodeBuilder_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonObjectNodeBuilder_JavaSourceHash32(void)
{
    return 0x463EB931UL;
}
