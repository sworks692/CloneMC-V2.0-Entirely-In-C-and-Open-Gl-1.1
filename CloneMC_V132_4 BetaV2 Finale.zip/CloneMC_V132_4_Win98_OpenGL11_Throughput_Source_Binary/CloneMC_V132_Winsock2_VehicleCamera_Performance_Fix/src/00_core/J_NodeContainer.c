/*
 * CloneMC Java port scaffold: J_NodeContainer
 *
 * Java source: J_NodeContainer.java
 * Java type: class J_NodeContainer
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: a6a9c6b3793c85d1dafc0f9690dacb1754de0acce0faf203c29f54e0779e8b08
 * Java lines: 18
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: J_JsonNodeBuilder, J_JsonFieldBuilder
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract void func_27290_a(J_JsonNodeBuilder j_jsonnodebuilder)
 * - public abstract void func_27289_a(J_JsonFieldBuilder j_jsonfieldbuilder)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_NodeContainer_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_NodeContainer_JavaName(void)
{
    return "net.minecraft.src.J_NodeContainer";
}

const char *CloneMCJ_J_NodeContainer_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_NodeContainer_JavaSourceHash32(void)
{
    return 0xA6A9C6B3UL;
}
