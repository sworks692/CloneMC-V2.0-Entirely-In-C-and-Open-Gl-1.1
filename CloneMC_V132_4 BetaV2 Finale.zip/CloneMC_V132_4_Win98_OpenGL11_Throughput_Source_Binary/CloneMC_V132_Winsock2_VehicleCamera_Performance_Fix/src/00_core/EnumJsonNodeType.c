/*
 * CloneMC Java port scaffold: EnumJsonNodeType
 *
 * Java source: EnumJsonNodeType.java
 * Java type: enum EnumJsonNodeType
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: d3849d4812f509cdaca9146e9bc1b4708deab5a777d184fc951376c8ac4ae174
 * Java lines: 59
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static final EnumJsonNodeType field_27442_h[]
 *
 * Java method/constructor inventory:
 * - private EnumJsonNodeType(String s, int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_EnumJsonNodeType_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_EnumJsonNodeType_JavaName(void)
{
    return "net.minecraft.src.EnumJsonNodeType";
}

const char *CloneMCJ_EnumJsonNodeType_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_EnumJsonNodeType_JavaSourceHash32(void)
{
    return 0xD3849D48UL;
}
