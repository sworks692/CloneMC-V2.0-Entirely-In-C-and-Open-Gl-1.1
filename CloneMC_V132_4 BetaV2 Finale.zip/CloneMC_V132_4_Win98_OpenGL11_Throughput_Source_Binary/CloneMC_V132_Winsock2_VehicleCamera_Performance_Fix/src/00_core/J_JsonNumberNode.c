/*
 * CloneMC Java port scaffold: J_JsonNumberNode
 *
 * Java source: J_JsonNumberNode.java
 * Java type: class J_JsonNumberNode
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 765a238e6bb0312c4f7c8fc0f6edbffa5a79cc2bb385254685a6eb8dcc6ffe2d
 * Java lines: 84
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 8
 * Referenced Java classes: J_JsonNode, EnumJsonNodeType
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final String field_27225_b
 *
 * Java method/constructor inventory:
 * - public EnumJsonNodeType func_27218_a()
 * - public String func_27216_b()
 * - public Map func_27214_c()
 * - public List func_27215_d()
 * - public boolean equals(Object obj)
 * - public int hashCode()
 * - public String toString()
 * - private static final Pattern field_27226_a = Pattern.compile("(-?)(0|([1-9]([0-9]*)))(\\.[0-9]+)?((e|E)(\\+|-)?[0-9]+)?")
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNumberNode_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNumberNode_JavaName(void)
{
    return "net.minecraft.src.J_JsonNumberNode";
}

const char *CloneMCJ_J_JsonNumberNode_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNumberNode_JavaSourceHash32(void)
{
    return 0x765A238EUL;
}
