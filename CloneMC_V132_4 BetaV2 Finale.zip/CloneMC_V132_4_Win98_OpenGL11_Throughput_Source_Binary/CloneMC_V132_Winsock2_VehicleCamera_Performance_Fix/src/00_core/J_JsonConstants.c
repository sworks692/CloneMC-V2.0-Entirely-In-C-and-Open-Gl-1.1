/*
 * CloneMC Java port scaffold: J_JsonConstants
 *
 * Java source: J_JsonConstants.java
 * Java type: class J_JsonConstants
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 3f174dbea10619e58880815c0b653741966f6205c6ddd2c4aa24634a34578c91
 * Java lines: 53
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: J_JsonNode, EnumJsonNodeType, static
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final EnumJsonNodeType field_27229_d
 *
 * Java method/constructor inventory:
 * - private J_JsonConstants(EnumJsonNodeType enumjsonnodetype)
 * - public EnumJsonNodeType func_27218_a()
 * - public String func_27216_b()
 * - public Map func_27214_c()
 * - public List func_27215_d()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonConstants_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonConstants_JavaName(void)
{
    return "net.minecraft.src.J_JsonConstants";
}

const char *CloneMCJ_J_JsonConstants_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonConstants_JavaSourceHash32(void)
{
    return 0x3F174DBEUL;
}
