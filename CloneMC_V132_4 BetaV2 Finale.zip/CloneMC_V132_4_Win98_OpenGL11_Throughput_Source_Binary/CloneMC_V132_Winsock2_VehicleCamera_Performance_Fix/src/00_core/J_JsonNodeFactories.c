/*
 * CloneMC Java port scaffold: J_JsonNodeFactories
 *
 * Java source: J_JsonNodeFactories.java
 * Java type: class J_JsonNodeFactories
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 524f222cc1da420f29c8204902b1a434c357ad3f02c1af60fd1d32930ffa63d3
 * Java lines: 61
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 9
 * Referenced Java classes: J_JsonConstants, J_JsonStringNode, J_JsonNumberNode, J_JsonArray, J_JsonObject, J_JsonNode, J_JsonRootNode
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - private J_JsonNodeFactories()
 * - public static J_JsonNode func_27310_a()
 * - public static J_JsonNode func_27313_b()
 * - public static J_JsonNode func_27314_c()
 * - public static J_JsonStringNode func_27316_a(String s)
 * - public static J_JsonNode func_27311_b(String s)
 * - public static J_JsonRootNode func_27309_a(Iterable iterable)
 * - public static J_JsonRootNode func_27315_a(J_JsonNode aj_jsonnode[])
 * - public static J_JsonRootNode func_27312_a(Map map)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNodeFactories_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNodeFactories_JavaName(void)
{
    return "net.minecraft.src.J_JsonNodeFactories";
}

const char *CloneMCJ_J_JsonNodeFactories_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNodeFactories_JavaSourceHash32(void)
{
    return 0x524F222CUL;
}
