/*
 * CloneMC Java port scaffold: MouseFilter
 *
 * Java source: MouseFilter.java
 * Java type: class MouseFilter
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 95409d388ab8830c17df7f66d7a5702c0bf7aff83020a1db1b55a1b44fe8d5c8
 * Java lines: 32
 * Discovered declared fields: 3
 * Discovered declared methods/constructors: 2
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private float field_22388_a
 * - private float field_22387_b
 * - private float field_22389_c
 *
 * Java method/constructor inventory:
 * - public MouseFilter()
 * - public float func_22386_a(float f, float f1)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_MouseFilter_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MouseFilter_JavaName(void)
{
    return "net.minecraft.src.MouseFilter";
}

const char *CloneMCJ_MouseFilter_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_MouseFilter_JavaSourceHash32(void)
{
    return 0x95409D38UL;
}
