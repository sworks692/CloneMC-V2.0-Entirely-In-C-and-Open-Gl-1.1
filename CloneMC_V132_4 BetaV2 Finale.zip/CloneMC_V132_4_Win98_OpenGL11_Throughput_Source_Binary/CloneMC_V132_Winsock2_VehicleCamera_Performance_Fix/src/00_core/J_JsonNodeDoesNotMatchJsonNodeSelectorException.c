/*
 * CloneMC Java port scaffold: J_JsonNodeDoesNotMatchJsonNodeSelectorException
 *
 * Java source: J_JsonNodeDoesNotMatchJsonNodeSelectorException.java
 * Java type: class J_JsonNodeDoesNotMatchJsonNodeSelectorException
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: IllegalArgumentException
 * Implements: (none declared)
 * Source SHA-256: 68f6de24e8c85769290d5eb1343d3b1269ce223e1a20050131d913f8e780978b
 * Java lines: 16
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_JavaName(void)
{
    return "net.minecraft.src.J_JsonNodeDoesNotMatchJsonNodeSelectorException";
}

const char *CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_JsonNodeDoesNotMatchJsonNodeSelectorException_JavaSourceHash32(void)
{
    return 0x68F6DE24UL;
}
