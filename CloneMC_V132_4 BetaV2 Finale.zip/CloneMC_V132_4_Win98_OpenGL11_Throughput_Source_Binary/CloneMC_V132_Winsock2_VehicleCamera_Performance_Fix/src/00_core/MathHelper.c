/*
 * CloneMC Java port scaffold: MathHelper
 *
 * Java source: MathHelper.java
 * Java type: class MathHelper
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 5d1c76a4842b3619622de948dfe5c363ba91dfdc79858e446f6aa2ee0a2766eb
 * Java lines: 93
 * Discovered declared fields: 1
 * Discovered declared methods/constructors: 11
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static float SIN_TABLE[]
 *
 * Java method/constructor inventory:
 * - public MathHelper()
 * - public static final float sin(float f)
 * - public static final float cos(float f)
 * - public static final float sqrt_float(float f)
 * - public static final float sqrt_double(double d)
 * - public static int floor_float(float f)
 * - public static int floor_double(double d)
 * - public static float abs(float f)
 * - public static double abs_max(double d, double d1)
 * - public static int bucketInt(int i, int j)
 * - public static boolean stringNullOrLengthZero(String s)
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_00_core.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

#define CLONEMC_JAVA_SIN_TABLE_SIZE 65536UL

static float g_cloneMCJavaSinTable[CLONEMC_JAVA_SIN_TABLE_SIZE];
static int g_cloneMCJavaSinTableReady = 0;

static CloneMCJULong CloneMCJavaRandom_Multiplier(void)
{
    return ((CloneMCJULong)0x00000005UL << 32) | (CloneMCJULong)0xDEECE66DUL;
}

static CloneMCJULong CloneMCJavaRandom_Mask(void)
{
    return ((CloneMCJULong)0x0000FFFFUL << 32) | (CloneMCJULong)0xFFFFFFFFUL;
}

static CloneMCJInt CloneMCJava_SignedIntFromBits(CloneMCJUInt bits)
{
    if (bits <= 0x7FFFFFFFUL) { return (CloneMCJInt)bits; }
    return (CloneMCJInt)(-1L - (CloneMCJInt)(0xFFFFFFFFUL - bits));
}

static void CloneMCJava_TestMessage(char *message, unsigned int capacity, const char *text)
{
    if (!message || capacity == 0U) { return; }
    strncpy(message, text ? text : "", (size_t)capacity - 1U);
    message[capacity - 1U] = '\0';
}

void CloneMCJ_MathHelper_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MathHelper_JavaName(void)
{
    return "net.minecraft.src.MathHelper";
}

const char *CloneMCJ_MathHelper_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_MathHelper_JavaSourceHash32(void)
{
    return 0x5D1C76A4UL;
}

CloneMCJInt CloneMCJava_AddInt(CloneMCJInt left, CloneMCJInt right)
{
    return CloneMCJava_SignedIntFromBits((CloneMCJUInt)left + (CloneMCJUInt)right);
}

CloneMCJInt CloneMCJava_SubInt(CloneMCJInt left, CloneMCJInt right)
{
    return CloneMCJava_SignedIntFromBits((CloneMCJUInt)left - (CloneMCJUInt)right);
}

CloneMCJInt CloneMCJava_MulInt(CloneMCJInt left, CloneMCJInt right)
{
    return CloneMCJava_SignedIntFromBits((CloneMCJUInt)left * (CloneMCJUInt)right);
}

CloneMCJInt CloneMCJava_UnsignedShiftRightInt(CloneMCJInt value, int bits)
{
    CloneMCJUInt shifted;
    bits &= 31;
    shifted = (CloneMCJUInt)value >> bits;
    return CloneMCJava_SignedIntFromBits(shifted);
}

CloneMCJLong CloneMCJava_UnsignedShiftRightLong(CloneMCJLong value, int bits)
{
    bits &= 63;
    return (CloneMCJLong)((CloneMCJULong)value >> bits);
}

CloneMCJByte CloneMCJava_CastByte(CloneMCJInt value)
{
    CloneMCJUInt bits;
    bits = (CloneMCJUInt)value & 0xFFUL;
    if (bits <= 0x7FUL) { return (CloneMCJByte)bits; }
    return (CloneMCJByte)(-1 - (int)(0xFFUL - bits));
}

CloneMCJShort CloneMCJava_CastShort(CloneMCJInt value)
{
    CloneMCJUInt bits;
    bits = (CloneMCJUInt)value & 0xFFFFUL;
    if (bits <= 0x7FFFUL) { return (CloneMCJShort)bits; }
    return (CloneMCJShort)(-1 - (int)(0xFFFFUL - bits));
}

int CloneMCJava_FloorFloat(float value)
{
    int truncated;
    truncated = (int)value;
    return value >= (float)truncated ? truncated : truncated - 1;
}

int CloneMCJava_FloorDouble(double value)
{
    int truncated;
    truncated = (int)value;
    return value >= (double)truncated ? truncated : truncated - 1;
}

int CloneMCJava_BucketInt(int value, int divisor)
{
    unsigned int magnitudeMinusOne;
    unsigned int quotient;
    if (divisor == 0) { return 0; }
    if (value < 0 && divisor > 0) {
        /* -(value + 1) is defined even for Java Integer.MIN_VALUE. */
        magnitudeMinusOne = (unsigned int)(-(value + 1));
        quotient = magnitudeMinusOne / (unsigned int)divisor;
        return -(int)quotient - 1;
    }
    return value / divisor;
}

unsigned int CloneMCJava_NibbleGet(const unsigned char *data, unsigned long index)
{
    unsigned int byteValue;
    if (!data) { return 0U; }
    byteValue = (unsigned int)data[index >> 1];
    return (index & 1UL) ? ((byteValue >> 4) & 15U) : (byteValue & 15U);
}

void CloneMCJava_NibbleSet(unsigned char *data, unsigned long index, unsigned int value)
{
    unsigned int oldValue;
    if (!data) { return; }
    oldValue = (unsigned int)data[index >> 1];
    if (index & 1UL) {
        oldValue = (oldValue & 0x0FU) | ((value & 15U) << 4);
    } else {
        oldValue = (oldValue & 0xF0U) | (value & 15U);
    }
    data[index >> 1] = (unsigned char)oldValue;
}

void CloneMCJavaRandom_SetSeed(CloneMCJavaRandom *random, CloneMCJLong seed)
{
    if (!random) { return; }
    random->seed = ((CloneMCJULong)seed ^ CloneMCJavaRandom_Multiplier()) &
                   CloneMCJavaRandom_Mask();
    random->haveNextGaussian = 0;
    random->nextGaussian = 0.0;
}

CloneMCJInt CloneMCJavaRandom_NextBits(CloneMCJavaRandom *random, int bits)
{
    CloneMCJUInt result;
    if (!random || bits < 1 || bits > 32) { return 0; }
    random->seed = (random->seed * CloneMCJavaRandom_Multiplier() +
                    (CloneMCJULong)0x0BUL) & CloneMCJavaRandom_Mask();
    result = (CloneMCJUInt)(random->seed >> (48 - bits));
    return CloneMCJava_SignedIntFromBits(result);
}

CloneMCJInt CloneMCJavaRandom_NextInt(CloneMCJavaRandom *random)
{
    return CloneMCJavaRandom_NextBits(random, 32);
}

CloneMCJInt CloneMCJavaRandom_NextIntBound(CloneMCJavaRandom *random, CloneMCJInt bound)
{
    CloneMCJInt bits;
    CloneMCJInt value;
    CloneMCJUInt overflowExpression;
    CloneMCJULong product;
    if (!random || bound <= 0) { return -1; }
    if (((CloneMCJUInt)bound & ((CloneMCJUInt)bound - 1UL)) == 0UL) {
        bits = CloneMCJavaRandom_NextBits(random, 31);
        product = (CloneMCJULong)(CloneMCJUInt)bound * (CloneMCJULong)(CloneMCJUInt)bits;
        return (CloneMCJInt)(product >> 31);
    }
    do {
        bits = CloneMCJavaRandom_NextBits(random, 31);
        value = bits % bound;
        overflowExpression = (CloneMCJUInt)bits - (CloneMCJUInt)value +
                             ((CloneMCJUInt)bound - 1UL);
    } while ((overflowExpression & 0x80000000UL) != 0UL);
    return value;
}

CloneMCJLong CloneMCJavaRandom_NextLong(CloneMCJavaRandom *random)
{
    CloneMCJUInt high;
    CloneMCJInt lowSigned;
    CloneMCJULong result;
    high = (CloneMCJUInt)CloneMCJavaRandom_NextBits(random, 32);
    lowSigned = CloneMCJavaRandom_NextBits(random, 32);
    result = ((CloneMCJULong)high << 32) + (CloneMCJULong)((CloneMCJLong)lowSigned);
    return (CloneMCJLong)result;
}

int CloneMCJavaRandom_NextBoolean(CloneMCJavaRandom *random)
{
    return CloneMCJavaRandom_NextBits(random, 1) != 0;
}

float CloneMCJavaRandom_NextFloat(CloneMCJavaRandom *random)
{
    return (float)CloneMCJavaRandom_NextBits(random, 24) / 16777216.0F;
}

double CloneMCJavaRandom_NextDouble(CloneMCJavaRandom *random)
{
    CloneMCJULong high;
    CloneMCJULong low;
    high = (CloneMCJULong)(CloneMCJUInt)CloneMCJavaRandom_NextBits(random, 26);
    low = (CloneMCJULong)(CloneMCJUInt)CloneMCJavaRandom_NextBits(random, 27);
    return (double)((high << 27) + low) / 9007199254740992.0;
}

double CloneMCJavaRandom_NextGaussian(CloneMCJavaRandom *random)
{
    double x;
    double y;
    double radiusSquared;
    double multiplier;
    if (!random) { return 0.0; }
    if (random->haveNextGaussian) {
        random->haveNextGaussian = 0;
        return random->nextGaussian;
    }
    do {
        x = 2.0 * CloneMCJavaRandom_NextDouble(random) - 1.0;
        y = 2.0 * CloneMCJavaRandom_NextDouble(random) - 1.0;
        radiusSquared = x * x + y * y;
    } while (radiusSquared >= 1.0 || radiusSquared == 0.0);
    multiplier = sqrt(-2.0 * log(radiusSquared) / radiusSquared);
    random->nextGaussian = y * multiplier;
    random->haveNextGaussian = 1;
    return x * multiplier;
}

void CloneMCMathHelper_Initialize(void)
{
    unsigned long index;
    if (g_cloneMCJavaSinTableReady) { return; }
    for (index = 0UL; index < CLONEMC_JAVA_SIN_TABLE_SIZE; ++index) {
        g_cloneMCJavaSinTable[index] = (float)sin(((double)index *
            3.1415926535897931 * 2.0) / 65536.0);
    }
    g_cloneMCJavaSinTableReady = 1;
}

float CloneMCMathHelper_Sin(float value)
{
    unsigned int index;
    CloneMCMathHelper_Initialize();
    index = ((unsigned int)(int)(value * 10430.38F)) & 0xFFFFU;
    return g_cloneMCJavaSinTable[index];
}

float CloneMCMathHelper_Cos(float value)
{
    unsigned int index;
    CloneMCMathHelper_Initialize();
    index = ((unsigned int)(int)(value * 10430.38F + 16384.0F)) & 0xFFFFU;
    return g_cloneMCJavaSinTable[index];
}

float CloneMCMathHelper_SqrtFloat(float value) { return (float)sqrt((double)value); }
float CloneMCMathHelper_SqrtDouble(double value) { return (float)sqrt(value); }
float CloneMCMathHelper_Abs(float value) { return value < 0.0F ? -value : value; }

double CloneMCMathHelper_AbsMax(double left, double right)
{
    if (left < 0.0) { left = -left; }
    if (right < 0.0) { right = -right; }
    return left <= right ? right : left;
}

int CloneMCJavaCore_RunSelfTests(char *message, unsigned int messageCapacity)
{
    CloneMCJavaRandom random;
    unsigned char nibbles[2];
    CloneMCJInt value;
    CloneMCVec3D vector;
    CloneMCVec3D normalized;
    CloneMCVec3D rayStart;
    CloneMCVec3D rayEnd;
    CloneMCAxisAlignedBB box;
    CloneMCAxisAlignedBB moving;
    CloneMCAABBRayHit hit;
    nibbles[0] = 0U;
    nibbles[1] = 0U;
    if (sizeof(CloneMCJInt) != 4U || sizeof(CloneMCJLong) != 8U) {
        CloneMCJava_TestMessage(message, messageCapacity, "Java integer width contract failed");
        return 0;
    }
    value = CloneMCJava_AddInt((CloneMCJInt)0x7FFFFFFFL, 1L);
    if ((CloneMCJUInt)value != 0x80000000UL ||
        (CloneMCJUInt)CloneMCJava_UnsignedShiftRightInt(-1L, 1) != 0x7FFFFFFFUL) {
        CloneMCJava_TestMessage(message, messageCapacity, "Java overflow/unsigned-shift test failed");
        return 0;
    }
    if (CloneMCJava_FloorDouble(-0.1) != -1 || CloneMCJava_BucketInt(-17, 16) != -2) {
        CloneMCJava_TestMessage(message, messageCapacity, "Java floor-division test failed");
        return 0;
    }
    CloneMCJava_NibbleSet(nibbles, 0UL, 3U);
    CloneMCJava_NibbleSet(nibbles, 1UL, 12U);
    CloneMCJava_NibbleSet(nibbles, 2UL, 7U);
    if (CloneMCJava_NibbleGet(nibbles, 0UL) != 3U ||
        CloneMCJava_NibbleGet(nibbles, 1UL) != 12U ||
        CloneMCJava_NibbleGet(nibbles, 2UL) != 7U) {
        CloneMCJava_TestMessage(message, messageCapacity, "Packed-nibble test failed");
        return 0;
    }
    CloneMCJavaRandom_SetSeed(&random, (CloneMCJLong)0);
    if (CloneMCJavaRandom_NextInt(&random) != (CloneMCJInt)-1155484576L ||
        CloneMCJavaRandom_NextIntBound(&random, 1000L) != 948L) {
        CloneMCJava_TestMessage(message, messageCapacity, "java.util.Random sequence test failed");
        return 0;
    }
    CloneMCMathHelper_Initialize();
    if (CloneMCMathHelper_Abs(CloneMCMathHelper_Sin(0.0F)) > 0.000001F ||
        CloneMCMathHelper_Abs(CloneMCMathHelper_Cos(0.0F) - 1.0F) > 0.000001F) {
        CloneMCJava_TestMessage(message, messageCapacity, "MathHelper sine-table test failed");
        return 0;
    }
    vector = CloneMCVec3D_Create(3.0, 4.0, 0.0);
    normalized = CloneMCVec3D_Normalize(&vector);
    if (fabs(normalized.xCoord - 0.6) > 0.000001 ||
        fabs(normalized.yCoord - 0.8) > 0.000001) {
        CloneMCJava_TestMessage(message, messageCapacity, "Vec3D normalization test failed");
        return 0;
    }
    box = CloneMCAABB_Create(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
    moving = CloneMCAABB_Create(-2.0, 0.25, 0.25, -1.0, 0.75, 0.75);
    if (fabs(CloneMCAABB_CalculateXOffset(&box, &moving, 4.0) - 1.0) > 0.000001) {
        CloneMCJava_TestMessage(message, messageCapacity, "AxisAlignedBB collision test failed");
        return 0;
    }
    rayStart = CloneMCVec3D_Create(-2.0, 0.5, 0.5);
    rayEnd = CloneMCVec3D_Create(2.0, 0.5, 0.5);
    hit = CloneMCAABB_RayTrace(&box, &rayStart, &rayEnd);
    if (!hit.hit || hit.side != 4 || fabs(hit.point.xCoord) > 0.000001) {
        CloneMCJava_TestMessage(message, messageCapacity, "AxisAlignedBB ray test failed");
        return 0;
    }
    CloneMCJava_TestMessage(message, messageCapacity, "Priority 2 Java core compatibility: PASS");
    return 1;
}
