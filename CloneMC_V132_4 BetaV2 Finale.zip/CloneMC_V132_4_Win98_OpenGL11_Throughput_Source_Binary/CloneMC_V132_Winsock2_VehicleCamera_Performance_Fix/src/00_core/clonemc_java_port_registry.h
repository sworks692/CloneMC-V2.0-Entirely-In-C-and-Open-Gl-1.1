/* Generated registry for all Java-to-C Step 1 class modules. */
#ifndef CLONEMC_JAVA_PORT_REGISTRY_H
#define CLONEMC_JAVA_PORT_REGISTRY_H

typedef void (*CloneMCJavaPortRegisterFn)(void);
typedef struct CloneMCJavaPortModuleTag {
    const char *javaName;
    const char *assignedFolder;
    unsigned long javaSourceHash32;
    CloneMCJavaPortRegisterFn registerModule;
} CloneMCJavaPortModule;

extern const CloneMCJavaPortModule g_cloneMCJavaPortModules[];
extern const unsigned long g_cloneMCJavaPortModuleCount;
void CloneMCJavaPort_RegisterAll(void);

#endif /* CLONEMC_JAVA_PORT_REGISTRY_H */
