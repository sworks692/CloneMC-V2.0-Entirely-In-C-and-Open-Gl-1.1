/*
 * CloneMC Java port scaffold: MCHashEntry
 *
 * Java source: MCHashEntry.java
 * Java type: class MCHashEntry
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: e35a6b684a2f71462e312f8789abcb48ab292a254432a49c13df579f05392360
 * Java lines: 68
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 5
 * Referenced Java classes: MCHash
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public final int getHash()
 * - public final Object getValue()
 * - public final boolean equals(Object obj)
 * - public final int hashCode()
 * - public final String toString()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_MCHashEntry_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MCHashEntry_JavaName(void)
{
    return "net.minecraft.src.MCHashEntry";
}

const char *CloneMCJ_MCHashEntry_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_MCHashEntry_JavaSourceHash32(void)
{
    return 0xE35A6B68UL;
}
