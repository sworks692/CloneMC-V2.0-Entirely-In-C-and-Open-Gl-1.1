/*
 * CloneMC Java port scaffold: MinecraftError
 *
 * Java source: MinecraftError.java
 * Java type: class MinecraftError
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: Error
 * Implements: (none declared)
 * Source SHA-256: 7ef66d188b0524884882a59de2a28612f780e99bbafb91768af170b253621974
 * Java lines: 15
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public MinecraftError()
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_MinecraftError_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_MinecraftError_JavaName(void)
{
    return "net.minecraft.src.MinecraftError";
}

const char *CloneMCJ_MinecraftError_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_MinecraftError_JavaSourceHash32(void)
{
    return 0x7EF66D18UL;
}
