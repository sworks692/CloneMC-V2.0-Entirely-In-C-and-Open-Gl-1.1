/*
 * CloneMC Java port scaffold: J_InvalidSyntaxException
 *
 * Java source: J_InvalidSyntaxException.java
 * Java type: class J_InvalidSyntaxException
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: Exception
 * Implements: (none declared)
 * Source SHA-256: 8e259fd8766277a8dcd7ee2333917c2dde785b5eabb0fb179b91ae460c7e57db
 * Java lines: 31
 * Discovered declared fields: 2
 * Discovered declared methods/constructors: 0
 * Referenced Java classes: J_ThingWithPosition
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private final int field_27191_a
 * - private final int field_27190_b
 *
 * Java method/constructor inventory:
 * - No single-line method declarations were discovered automatically.
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_J_InvalidSyntaxException_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_J_InvalidSyntaxException_JavaName(void)
{
    return "net.minecraft.src.J_InvalidSyntaxException";
}

const char *CloneMCJ_J_InvalidSyntaxException_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_J_InvalidSyntaxException_JavaSourceHash32(void)
{
    return 0x8E259FD8UL;
}
