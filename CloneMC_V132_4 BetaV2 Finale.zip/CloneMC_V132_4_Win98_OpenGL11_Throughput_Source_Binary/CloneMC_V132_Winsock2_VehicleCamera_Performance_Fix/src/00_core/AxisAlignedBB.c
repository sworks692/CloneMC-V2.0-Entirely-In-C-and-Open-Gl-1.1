/*
 * CloneMC Java port scaffold: AxisAlignedBB
 *
 * Java source: AxisAlignedBB.java
 * Java type: class AxisAlignedBB
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared math, collection, enum, parser, or utility class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 2cf1136eb6ea70806aa8481a52e446704943508c39bb5fdab9c91c282518fdf9
 * Java lines: 410
 * Discovered declared fields: 7
 * Discovered declared methods/constructors: 23
 * Referenced Java classes: Vec3D, MovingObjectPosition, d1, d2, d3, d4
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - private static int numBoundingBoxesInUse = 0
 * - public double minX
 * - public double minY
 * - public double minZ
 * - public double maxX
 * - public double maxY
 * - public double maxZ
 *
 * Java method/constructor inventory:
 * - public static void func_28196_a()
 * - public static void clearBoundingBoxPool()
 * - private AxisAlignedBB(double d, double d1, double d2, double d3, double d4, double d5)
 * - public AxisAlignedBB setBounds(double d, double d1, double d2, double d3, double d4, double d5)
 * - public AxisAlignedBB addCoord(double d, double d1, double d2)
 * - public AxisAlignedBB expand(double d, double d1, double d2)
 * - public AxisAlignedBB getOffsetBoundingBox(double d, double d1, double d2)
 * - public double calculateXOffset(AxisAlignedBB axisalignedbb, double d)
 * - public double calculateYOffset(AxisAlignedBB axisalignedbb, double d)
 * - public double calculateZOffset(AxisAlignedBB axisalignedbb, double d)
 * - public boolean intersectsWith(AxisAlignedBB axisalignedbb)
 * - public AxisAlignedBB offset(double d, double d1, double d2)
 * - public boolean isVecInside(Vec3D vec3d)
 * - public double getAverageEdgeLength()
 * - public AxisAlignedBB func_28195_e(double d, double d1, double d2)
 * - public AxisAlignedBB copy()
 * - public MovingObjectPosition func_1169_a(Vec3D vec3d, Vec3D vec3d1)
 * - private boolean isVecInYZ(Vec3D vec3d)
 * - private boolean isVecInXZ(Vec3D vec3d)
 * - private boolean isVecInXY(Vec3D vec3d)
 * - public void setBB(AxisAlignedBB axisalignedbb)
 * - public String toString()
 * - private static List boundingBoxes = new ArrayList()
 *
 * This class now has native runtime behavior in this file; its registry metadata is
 * retained so the implementation remains traceable to the uploaded Java source.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_AxisAlignedBB_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_AxisAlignedBB_JavaName(void)
{
    return "net.minecraft.src.AxisAlignedBB";
}

const char *CloneMCJ_AxisAlignedBB_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_AxisAlignedBB_JavaSourceHash32(void)
{
    return 0x2CF1136EUL;
}

CloneMCAxisAlignedBB CloneMCAABB_Create(double minX, double minY, double minZ,
                                        double maxX, double maxY, double maxZ)
{
    CloneMCAxisAlignedBB box;
    box.minX = minX; box.minY = minY; box.minZ = minZ;
    box.maxX = maxX; box.maxY = maxY; box.maxZ = maxZ;
    return box;
}

CloneMCAxisAlignedBB CloneMCAABB_AddCoord(const CloneMCAxisAlignedBB *box,
                                          double x, double y, double z)
{
    CloneMCAxisAlignedBB result;
    if (!box) { return CloneMCAABB_Create(0.0, 0.0, 0.0, 0.0, 0.0, 0.0); }
    result = *box;
    if (x < 0.0) { result.minX += x; } else if (x > 0.0) { result.maxX += x; }
    if (y < 0.0) { result.minY += y; } else if (y > 0.0) { result.maxY += y; }
    if (z < 0.0) { result.minZ += z; } else if (z > 0.0) { result.maxZ += z; }
    return result;
}

CloneMCAxisAlignedBB CloneMCAABB_Expand(const CloneMCAxisAlignedBB *box,
                                        double x, double y, double z)
{
    if (!box) { return CloneMCAABB_Create(0.0, 0.0, 0.0, 0.0, 0.0, 0.0); }
    return CloneMCAABB_Create(box->minX - x, box->minY - y, box->minZ - z,
                             box->maxX + x, box->maxY + y, box->maxZ + z);
}

CloneMCAxisAlignedBB CloneMCAABB_OffsetCopy(const CloneMCAxisAlignedBB *box,
                                            double x, double y, double z)
{
    if (!box) { return CloneMCAABB_Create(0.0, 0.0, 0.0, 0.0, 0.0, 0.0); }
    return CloneMCAABB_Create(box->minX + x, box->minY + y, box->minZ + z,
                             box->maxX + x, box->maxY + y, box->maxZ + z);
}

void CloneMCAABB_Offset(CloneMCAxisAlignedBB *box, double x, double y, double z)
{
    if (!box) { return; }
    box->minX += x; box->minY += y; box->minZ += z;
    box->maxX += x; box->maxY += y; box->maxZ += z;
}

double CloneMCAABB_CalculateXOffset(const CloneMCAxisAlignedBB *box,
                                    const CloneMCAxisAlignedBB *moving, double offset)
{
    double gap;
    if (!box || !moving) { return offset; }
    if (moving->maxY <= box->minY || moving->minY >= box->maxY ||
        moving->maxZ <= box->minZ || moving->minZ >= box->maxZ) { return offset; }
    if (offset > 0.0 && moving->maxX <= box->minX) {
        gap = box->minX - moving->maxX; if (gap < offset) { offset = gap; }
    }
    if (offset < 0.0 && moving->minX >= box->maxX) {
        gap = box->maxX - moving->minX; if (gap > offset) { offset = gap; }
    }
    return offset;
}

double CloneMCAABB_CalculateYOffset(const CloneMCAxisAlignedBB *box,
                                    const CloneMCAxisAlignedBB *moving, double offset)
{
    double gap;
    if (!box || !moving) { return offset; }
    if (moving->maxX <= box->minX || moving->minX >= box->maxX ||
        moving->maxZ <= box->minZ || moving->minZ >= box->maxZ) { return offset; }
    if (offset > 0.0 && moving->maxY <= box->minY) {
        gap = box->minY - moving->maxY; if (gap < offset) { offset = gap; }
    }
    if (offset < 0.0 && moving->minY >= box->maxY) {
        gap = box->maxY - moving->minY; if (gap > offset) { offset = gap; }
    }
    return offset;
}

double CloneMCAABB_CalculateZOffset(const CloneMCAxisAlignedBB *box,
                                    const CloneMCAxisAlignedBB *moving, double offset)
{
    double gap;
    if (!box || !moving) { return offset; }
    if (moving->maxX <= box->minX || moving->minX >= box->maxX ||
        moving->maxY <= box->minY || moving->minY >= box->maxY) { return offset; }
    if (offset > 0.0 && moving->maxZ <= box->minZ) {
        gap = box->minZ - moving->maxZ; if (gap < offset) { offset = gap; }
    }
    if (offset < 0.0 && moving->minZ >= box->maxZ) {
        gap = box->maxZ - moving->minZ; if (gap > offset) { offset = gap; }
    }
    return offset;
}

int CloneMCAABB_Intersects(const CloneMCAxisAlignedBB *box, const CloneMCAxisAlignedBB *other)
{
    if (!box || !other) { return 0; }
    return other->maxX > box->minX && other->minX < box->maxX &&
           other->maxY > box->minY && other->minY < box->maxY &&
           other->maxZ > box->minZ && other->minZ < box->maxZ;
}

int CloneMCAABB_IsVecInside(const CloneMCAxisAlignedBB *box, const CloneMCVec3D *point)
{
    if (!box || !point) { return 0; }
    return point->xCoord > box->minX && point->xCoord < box->maxX &&
           point->yCoord > box->minY && point->yCoord < box->maxY &&
           point->zCoord > box->minZ && point->zCoord < box->maxZ;
}

double CloneMCAABB_AverageEdgeLength(const CloneMCAxisAlignedBB *box)
{
    if (!box) { return 0.0; }
    return ((box->maxX - box->minX) + (box->maxY - box->minY) +
            (box->maxZ - box->minZ)) / 3.0;
}

CloneMCAxisAlignedBB CloneMCAABB_Contract(const CloneMCAxisAlignedBB *box,
                                          double x, double y, double z)
{
    if (!box) { return CloneMCAABB_Create(0.0, 0.0, 0.0, 0.0, 0.0, 0.0); }
    return CloneMCAABB_Create(box->minX + x, box->minY + y, box->minZ + z,
                             box->maxX - x, box->maxY - y, box->maxZ - z);
}

static int CloneMCAABB_PointOnFace(const CloneMCAxisAlignedBB *box,
                                   const CloneMCVec3D *point, int axis)
{
    if (axis == 0) {
        return point->yCoord >= box->minY && point->yCoord <= box->maxY &&
               point->zCoord >= box->minZ && point->zCoord <= box->maxZ;
    }
    if (axis == 1) {
        return point->xCoord >= box->minX && point->xCoord <= box->maxX &&
               point->zCoord >= box->minZ && point->zCoord <= box->maxZ;
    }
    return point->xCoord >= box->minX && point->xCoord <= box->maxX &&
           point->yCoord >= box->minY && point->yCoord <= box->maxY;
}

CloneMCAABBRayHit CloneMCAABB_RayTrace(const CloneMCAxisAlignedBB *box,
                                       const CloneMCVec3D *start, const CloneMCVec3D *end)
{
    CloneMCAABBRayHit result;
    CloneMCVec3D candidate;
    double bestDistance;
    double distance;
    int valid;
    int face;
    int faceIndex;
    int axis;
    static const int faceOrder[6] = {4, 5, 0, 1, 2, 3};
    result.hit = 0; result.side = -1;
    result.point = CloneMCVec3D_Create(0.0, 0.0, 0.0);
    bestDistance = 0.0;
    if (!box || !start || !end) { return result; }
    /* Preserve Java's minX,maxX,minY,maxY,minZ,maxZ strict tie order. */
    for (faceIndex = 0; faceIndex < 6; ++faceIndex) {
        face = faceOrder[faceIndex];
        axis = face >= 4 ? 0 : (face < 2 ? 1 : 2);
        if (axis == 0) {
            valid = CloneMCVec3D_IntermediateX(start, end,
                    face == 4 ? box->minX : box->maxX, &candidate);
        } else if (axis == 1) {
            valid = CloneMCVec3D_IntermediateY(start, end,
                    face == 0 ? box->minY : box->maxY, &candidate);
        } else {
            valid = CloneMCVec3D_IntermediateZ(start, end,
                    face == 2 ? box->minZ : box->maxZ, &candidate);
        }
        if (!valid || !CloneMCAABB_PointOnFace(box, &candidate, axis)) { continue; }
        distance = CloneMCVec3D_SquareDistance(start, &candidate);
        if (!result.hit || distance < bestDistance) {
            result.hit = 1; result.side = face; result.point = candidate;
            bestDistance = distance;
        }
    }
    return result;
}
