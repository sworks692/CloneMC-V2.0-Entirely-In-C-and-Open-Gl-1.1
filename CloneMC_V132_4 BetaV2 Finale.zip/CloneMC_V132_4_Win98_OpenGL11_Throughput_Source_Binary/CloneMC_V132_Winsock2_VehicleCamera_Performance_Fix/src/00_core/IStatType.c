/*
 * CloneMC Java port scaffold: IStatType
 *
 * Java source: IStatType.java
 * Java type: interface IStatType
 * Package: net.minecraft.src
 * Assigned subsystem: src/00_core
 * Mapping reason: shared interface, utility, registry, or uncategorized support class
 * Extends: (none declared)
 * Implements: (none declared)
 * Source SHA-256: 2652a23a7dbcdb01593b70cfe9844ca5cc570023993837f5a1740909df0b1ab2
 * Java lines: 13
 * Discovered declared fields: 0
 * Discovered declared methods/constructors: 1
 * Referenced Java classes: (none listed by decompiler)
 *
 * Conversion contract for the next implementation step:
 * - Preserve Java field ownership, constructor initialization order, signed overflow,
 *   random-call order, tick ordering, and serialization identifiers.
 * - Keep this module valid as Open Watcom C/Win32 C89 and do not introduce C++,
 *   shaders, OpenGL extensions, or runtime Java dependencies.
 * - Replace this behavior-neutral metadata scaffold only when its direct C behavior
 *   is implemented and covered by deterministic compatibility tests.
 *
 * Java field inventory:
 * - No single-line field declarations were discovered automatically.
 *
 * Java method/constructor inventory:
 * - public abstract String func_27192_a(int i)
 *
 * This file is deliberately behavior-neutral in Step 1. Its symbols are linked
 * through the generated unity aggregators and registry so later direct ports can
 * be implemented class by class without changing the Open Watcom build topology.
 */
#include "clonemc_java_port_00_core.h"

void CloneMCJ_IStatType_Register(void)
{
    /* Step 1: reserved for registry/table installation during direct conversion. */
}

const char *CloneMCJ_IStatType_JavaName(void)
{
    return "net.minecraft.src.IStatType";
}

const char *CloneMCJ_IStatType_AssignedFolder(void)
{
    return "src/00_core";
}

unsigned long CloneMCJ_IStatType_JavaSourceHash32(void)
{
    return 0x2652A23AUL;
}
