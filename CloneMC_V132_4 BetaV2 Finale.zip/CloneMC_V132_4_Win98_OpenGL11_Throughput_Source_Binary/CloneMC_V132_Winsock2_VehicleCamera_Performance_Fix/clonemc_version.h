#ifndef CLONEMC_VERSION_H
#define CLONEMC_VERSION_H

/*
 * Single authoritative build identity for the cumulative V132.4 hotfix.
 * Keep this header C89/preprocessor-only so Open Watcom V2.0 can include it
 * from the unity build, individual development objects, and resource scripts.
 */
#define CLONEMC_VERSION_MAJOR 132
#define CLONEMC_VERSION_MINOR 4
#define CLONEMC_VERSION_PATCH 0
#define CLONEMC_VERSION_TEXT "V132.4.0"
#define CLONEMC_VERSION_CHANNEL "Win9x OpenGL 1.1 Throughput Fix"
#define CLONEMC_VERSION_DISPLAY "CloneMC V132.4.0 Win9x OpenGL 1.1 Throughput Fix"
#define CLONEMC_REFERENCE_JAVA_MODULES 675UL
#define CLONEMC_NATIVE_TEST_MODULES 2UL
#define CLONEMC_TOTAL_C_MODULES 677UL
#define CLONEMC_REFERENCE_ARCHIVE_SHA256 \
    "6fbebcf97d2bbc1f28cdce3a3abe7b6d9267cdfd998c3979ac7a7f712c5a87d2"
#define CLONEMC_REFERENCE_MANIFEST_SHA256 \
    "b3090eb599b003ebc6c5fb15d5c194fc99b9c8eb4398ce32d77d43b20f9f9325"
#define CLONEMC_PARITY_MANIFEST_SHA256 \
    "2033f215d93d53ca5ef9cd870d55ee2013879bb8321de8ec335b0f942a593e40"
#define CLONEMC_SOURCE_ARCHIVE_SHA256 \
    "e320c20b5c264633cad25e856ee9b289aec5e3281aa9480e302f94c249d8582b"
#define CLONEMC_BUILD_PROFILE "win32-x86-c89-opengl11-win98-winsock2-v1324"

#endif
